"""Example suites and adapters shipped with AgentUnit."""
