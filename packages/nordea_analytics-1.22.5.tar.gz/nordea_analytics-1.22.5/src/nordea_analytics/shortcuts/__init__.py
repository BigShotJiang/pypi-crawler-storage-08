"""The Nordea Analytics Python Project - shortcut functions."""
