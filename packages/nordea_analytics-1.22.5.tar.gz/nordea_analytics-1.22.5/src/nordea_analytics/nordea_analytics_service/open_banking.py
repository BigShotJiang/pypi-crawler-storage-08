from .core import NordeaAnalyticsCoreService


class NordeaAnalyticsService(NordeaAnalyticsCoreService):
    """Class that contains public functions."""

    pass
