"""The Nordea Analytics Python Project - Back-end code."""
