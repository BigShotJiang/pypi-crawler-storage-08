"""The Nordea Analytics Python Project - API endpoint connecting code."""
