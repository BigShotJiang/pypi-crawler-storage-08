"""The Nordea Analytics Python Project - Live-Keyfigures code."""
