"""The DTO for Analytics API."""
