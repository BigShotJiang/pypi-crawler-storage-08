# Nordea Analytics
This is the Nordea Analytics python library, which gives you direct access to the best key figures for our Nordic products. To use the library, you will need access to the underlying API. For further information please reach out to <a href="mailto:E-advisorySupport@nordea.com">E-advisorySupport@nordea.com</a>

# Documentation
Latest documentation is available here: https://nordea-analytics.readthedocs.io/en/latest/ 

# License
GPLv3 - GNU General Public License v3.0

# Authors

Nordea Desk Quants and Markets Advisory Tools
