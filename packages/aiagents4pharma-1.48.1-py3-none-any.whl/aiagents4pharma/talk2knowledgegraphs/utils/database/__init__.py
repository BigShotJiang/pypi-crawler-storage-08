"""Database utilities for Talk2KnowledgeGraphs."""

from .milvus_connection_manager import MilvusConnectionManager

__all__ = ["MilvusConnectionManager"]
