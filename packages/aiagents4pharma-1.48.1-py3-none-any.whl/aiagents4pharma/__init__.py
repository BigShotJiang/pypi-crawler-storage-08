"""
This file is used to import aiagents4pharma modules.
"""

from . import (
    talk2aiagents4pharma,
    talk2biomodels,
    talk2cells,
    talk2knowledgegraphs,
    talk2scholars,
)
