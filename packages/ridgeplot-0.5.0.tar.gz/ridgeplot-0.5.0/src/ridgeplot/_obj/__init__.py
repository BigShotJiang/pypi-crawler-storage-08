"""Object-oriented interfaces."""
