"""Color utilities."""
