from setuptools import setup

setup(
    name="jstreams",
    author="Cristian Trohin",
    version="2025.10.1",
    package_data={"jstreams": ["py.typed"]},
    packages=["jstreams"],
)
