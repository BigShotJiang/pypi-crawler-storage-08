"""
Models module for nirs4all operations.

This module contains model classes for operations.
Note: This directory is currently empty.
"""

__all__ = []
