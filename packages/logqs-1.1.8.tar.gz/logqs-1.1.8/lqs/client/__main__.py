import fire

from lqs.client import RESTClient


def main():
    fire.Fire(RESTClient)


if __name__ == "__main__":
    main()
