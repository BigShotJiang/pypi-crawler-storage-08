from lqs.interface.admin.create import CreateInterface
