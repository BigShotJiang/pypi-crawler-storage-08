from lqs.interface.dsm.create import CreateInterface
from lqs.interface.dsm.delete import DeleteInterface
from lqs.interface.dsm.fetch import FetchInterface
from lqs.interface.dsm.list import ListInterface
from lqs.interface.dsm.update import UpdateInterface
