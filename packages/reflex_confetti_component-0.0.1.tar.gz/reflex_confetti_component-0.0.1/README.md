# confetti-component

A Reflex custom component confetti-component.

## Installation

```bash
pip install reflex-confetti-component
```