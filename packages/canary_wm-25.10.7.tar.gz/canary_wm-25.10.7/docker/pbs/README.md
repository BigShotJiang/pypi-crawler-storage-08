# PBS Container

This container builds the version of `canary` specified in the Docker build command.
