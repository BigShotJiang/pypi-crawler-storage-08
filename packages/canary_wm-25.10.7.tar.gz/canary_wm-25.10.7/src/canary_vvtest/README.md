# Canary VVTest Plugin

## Overview

The `canary_vvtest` is a plugin for the [Canary](https://github.com/sandialabs/canary) testing framework. This plugin provides a test case generator for [vvtest](https://github.com/sandialabs/vvtest) `.vvt` files.
