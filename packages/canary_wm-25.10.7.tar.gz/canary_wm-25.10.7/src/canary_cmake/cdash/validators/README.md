# CDash XML Schemas

Schemas downloaded from https://github.com/Kitware/CDash/tree/master/app/Validators/Schemas
