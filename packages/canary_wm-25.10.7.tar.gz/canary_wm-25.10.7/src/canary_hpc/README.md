# Canary HPC Plugin

## Overview

The `canary_hpc` is a plugin for the [Canary](https://github.com/sandialabs/canary) testing framework. This plugin interfaces with [hpc_connect](https://github.com/sandialabs/hpc-connect) to run tests on high performance super computers.
