.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


discover
========

.. automodule:: hpcc_slurm.discover
   :members:
   :undoc-members:
   :show-inheritance:
