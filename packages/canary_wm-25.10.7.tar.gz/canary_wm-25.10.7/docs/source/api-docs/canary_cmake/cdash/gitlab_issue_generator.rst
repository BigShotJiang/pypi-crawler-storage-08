.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


gitlab_issue_generator
======================

.. automodule:: canary_cmake.cdash.gitlab_issue_generator
   :members:
   :undoc-members:
   :show-inheritance:
