.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


interface
=========

.. automodule:: canary_cmake.cdash.interface
   :members:
   :undoc-members:
   :show-inheritance:
