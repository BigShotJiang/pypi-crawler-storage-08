.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


xmlreporter
===========

.. automodule:: canary_cmake.cdash.xmlreporter
   :members:
   :undoc-members:
   :show-inheritance:
