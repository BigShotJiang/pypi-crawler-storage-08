.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


cdash_html_summary
==================

.. automodule:: canary_cmake.cdash.cdash_html_summary
   :members:
   :undoc-members:
   :show-inheritance:
