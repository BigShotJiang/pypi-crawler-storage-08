.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


ctest
=====

.. automodule:: canary_cmake.ctest
   :members:
   :undoc-members:
   :show-inheritance:
