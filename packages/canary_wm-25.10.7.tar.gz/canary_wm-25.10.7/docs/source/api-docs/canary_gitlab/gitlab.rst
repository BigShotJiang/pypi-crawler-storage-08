.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


gitlab
======

.. automodule:: canary_gitlab.gitlab
   :members:
   :undoc-members:
   :show-inheritance:
