.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


reporter
========

.. automodule:: canary_gitlab.reporter
   :members:
   :undoc-members:
   :show-inheritance:
