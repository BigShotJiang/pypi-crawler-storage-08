.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


_difflib
========

.. automodule:: _canary.util._difflib
   :members:
   :undoc-members:
   :show-inheritance:
