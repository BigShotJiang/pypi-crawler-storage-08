.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


_json
=====

.. automodule:: _canary.util._json
   :members:
   :undoc-members:
   :show-inheritance:
