.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


editor
======

.. automodule:: _canary.util.editor
   :members:
   :undoc-members:
   :show-inheritance:
