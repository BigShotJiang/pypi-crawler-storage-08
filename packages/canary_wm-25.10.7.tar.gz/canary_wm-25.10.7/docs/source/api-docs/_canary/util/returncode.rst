.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


returncode
==========

.. automodule:: _canary.util.returncode
   :members:
   :undoc-members:
   :show-inheritance:
