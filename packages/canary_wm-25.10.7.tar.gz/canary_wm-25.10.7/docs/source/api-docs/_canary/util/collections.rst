.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


collections
===========

.. automodule:: _canary.util.collections
   :members:
   :undoc-members:
   :show-inheritance:
