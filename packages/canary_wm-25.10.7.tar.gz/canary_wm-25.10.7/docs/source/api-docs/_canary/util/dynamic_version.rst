.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


dynamic_version
===============

.. automodule:: _canary.util.dynamic_version
   :members:
   :undoc-members:
   :show-inheritance:
