.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


entry_points
============

.. automodule:: _canary.util.entry_points
   :members:
   :undoc-members:
   :show-inheritance:
