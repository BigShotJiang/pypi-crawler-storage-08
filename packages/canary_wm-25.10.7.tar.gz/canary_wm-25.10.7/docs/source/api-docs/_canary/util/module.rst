.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


module
======

.. automodule:: _canary.util.module
   :members:
   :undoc-members:
   :show-inheritance:
