.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


string
======

.. automodule:: _canary.util.string
   :members:
   :undoc-members:
   :show-inheritance:
