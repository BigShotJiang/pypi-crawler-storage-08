.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


shell
=====

.. automodule:: _canary.util.shell
   :members:
   :undoc-members:
   :show-inheritance:
