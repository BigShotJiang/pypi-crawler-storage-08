.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


when
====

.. automodule:: _canary.when
   :members:
   :undoc-members:
   :show-inheritance:
