.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


queue
=====

.. automodule:: _canary.queue
   :members:
   :undoc-members:
   :show-inheritance:
