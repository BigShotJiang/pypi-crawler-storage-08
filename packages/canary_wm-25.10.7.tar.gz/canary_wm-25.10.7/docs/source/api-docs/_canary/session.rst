.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


session
=======

.. automodule:: _canary.session
   :members:
   :undoc-members:
   :show-inheritance:
