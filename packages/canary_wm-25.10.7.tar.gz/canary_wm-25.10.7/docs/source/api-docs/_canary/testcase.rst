.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


testcase
========

.. automodule:: _canary.testcase
   :members:
   :undoc-members:
   :show-inheritance:
