.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


main
====

.. automodule:: _canary.main
   :members:
   :undoc-members:
   :show-inheritance:
