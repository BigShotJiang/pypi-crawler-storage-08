.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


repeat
======

.. automodule:: _canary.plugins.builtin.repeat
   :members:
   :undoc-members:
   :show-inheritance:
