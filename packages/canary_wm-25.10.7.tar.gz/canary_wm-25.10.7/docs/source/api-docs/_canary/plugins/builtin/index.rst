.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

plugins.builtin
===============

.. toctree::
   :maxdepth: 1

   discover
   email
   html
   json
   junit
   markdown
   mask
   oversubscribe
   post_clean
   pyt
   repeat
   reporting
   resource
   runtest_protocol
   runtests
   testcase_generator
