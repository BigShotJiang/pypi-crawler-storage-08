.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


config
======

.. automodule:: _canary.plugins.subcommands.config
   :members:
   :undoc-members:
   :show-inheritance:
