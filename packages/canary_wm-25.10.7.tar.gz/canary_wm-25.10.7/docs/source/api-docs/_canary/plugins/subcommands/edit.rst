.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


edit
====

.. automodule:: _canary.plugins.subcommands.edit
   :members:
   :undoc-members:
   :show-inheritance:
