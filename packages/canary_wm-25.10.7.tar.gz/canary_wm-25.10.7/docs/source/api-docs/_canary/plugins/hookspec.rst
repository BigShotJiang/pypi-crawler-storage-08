.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


hookspec
========

.. automodule:: _canary.plugins.hookspec
   :members:
   :undoc-members:
   :show-inheritance:
