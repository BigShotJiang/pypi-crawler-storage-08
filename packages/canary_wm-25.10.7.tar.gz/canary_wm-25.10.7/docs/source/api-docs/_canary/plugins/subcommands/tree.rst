.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


tree
====

.. automodule:: _canary.plugins.subcommands.tree
   :members:
   :undoc-members:
   :show-inheritance:
