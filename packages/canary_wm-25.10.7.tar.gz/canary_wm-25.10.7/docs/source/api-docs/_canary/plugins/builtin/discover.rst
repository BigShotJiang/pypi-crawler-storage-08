.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


discover
========

.. automodule:: _canary.plugins.builtin.discover
   :members:
   :undoc-members:
   :show-inheritance:
