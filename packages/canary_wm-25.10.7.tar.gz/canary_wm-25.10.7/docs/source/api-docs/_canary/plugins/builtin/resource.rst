.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


resource
========

.. automodule:: _canary.plugins.builtin.resource
   :members:
   :undoc-members:
   :show-inheritance:
