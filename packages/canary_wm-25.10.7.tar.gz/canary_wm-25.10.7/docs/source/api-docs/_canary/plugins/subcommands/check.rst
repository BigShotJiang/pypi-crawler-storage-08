.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


check
=====

.. automodule:: _canary.plugins.subcommands.check
   :members:
   :undoc-members:
   :show-inheritance:
