.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


markdown
========

.. automodule:: _canary.plugins.builtin.markdown
   :members:
   :undoc-members:
   :show-inheritance:
