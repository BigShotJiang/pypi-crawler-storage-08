.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


junit
=====

.. automodule:: _canary.plugins.builtin.junit
   :members:
   :undoc-members:
   :show-inheritance:
