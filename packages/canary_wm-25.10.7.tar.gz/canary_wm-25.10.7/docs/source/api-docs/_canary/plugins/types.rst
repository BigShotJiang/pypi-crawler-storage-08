.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


types
=====

.. automodule:: _canary.plugins.types
   :members:
   :undoc-members:
   :show-inheritance:
