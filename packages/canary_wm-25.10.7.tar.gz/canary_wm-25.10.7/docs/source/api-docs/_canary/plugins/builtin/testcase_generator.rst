.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


testcase_generator
==================

.. automodule:: _canary.plugins.builtin.testcase_generator
   :members:
   :undoc-members:
   :show-inheritance:
