.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

plugins.subcommands.common
==========================

.. toctree::
   :maxdepth: 1

   pathspec
