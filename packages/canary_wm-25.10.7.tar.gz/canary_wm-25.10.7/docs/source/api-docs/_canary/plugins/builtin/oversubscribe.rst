.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


oversubscribe
=============

.. automodule:: _canary.plugins.builtin.oversubscribe
   :members:
   :undoc-members:
   :show-inheritance:
