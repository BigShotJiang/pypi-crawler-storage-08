.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


docs
====

.. automodule:: _canary.plugins.subcommands.docs
   :members:
   :undoc-members:
   :show-inheritance:
