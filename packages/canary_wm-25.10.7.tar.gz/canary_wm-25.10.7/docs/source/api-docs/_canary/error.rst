.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


error
=====

.. automodule:: _canary.error
   :members:
   :undoc-members:
   :show-inheritance:
