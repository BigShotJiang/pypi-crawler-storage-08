.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


macos
=====

.. automodule:: _canary.config.macos
   :members:
   :undoc-members:
   :show-inheritance:
