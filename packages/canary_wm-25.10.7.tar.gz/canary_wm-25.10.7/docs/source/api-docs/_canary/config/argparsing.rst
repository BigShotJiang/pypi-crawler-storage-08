.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


argparsing
==========

.. automodule:: _canary.config.argparsing
   :members:
   :undoc-members:
   :show-inheritance:
