.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


config
======

.. automodule:: _canary.config.config
   :members:
   :undoc-members:
   :show-inheritance:
