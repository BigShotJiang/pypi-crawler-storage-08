.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


_machine
========

.. automodule:: _canary.config._machine
   :members:
   :undoc-members:
   :show-inheritance:
