.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


testinstance
============

.. automodule:: _canary.testinstance
   :members:
   :undoc-members:
   :show-inheritance:
