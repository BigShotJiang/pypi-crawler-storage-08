.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


submit
======

.. automodule:: hpcc_subprocess.submit
   :members:
   :undoc-members:
   :show-inheritance:
