.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


executor
========

.. automodule:: canary_hpc.executor
   :members:
   :undoc-members:
   :show-inheritance:
