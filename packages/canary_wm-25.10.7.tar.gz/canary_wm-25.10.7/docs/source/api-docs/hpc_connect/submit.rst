.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


submit
======

.. automodule:: hpc_connect.submit
   :members:
   :undoc-members:
   :show-inheritance:
