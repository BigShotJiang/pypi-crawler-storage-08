.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


version
=======

.. automodule:: hpc_connect.version
   :members:
   :undoc-members:
   :show-inheritance:
