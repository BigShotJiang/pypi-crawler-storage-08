.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


discover
========

.. automodule:: hpc_connect.discover
   :members:
   :undoc-members:
   :show-inheritance:
