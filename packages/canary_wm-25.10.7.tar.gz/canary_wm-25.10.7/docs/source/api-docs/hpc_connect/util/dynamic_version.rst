.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


dynamic_version
===============

.. automodule:: hpc_connect.util.dynamic_version
   :members:
   :undoc-members:
   :show-inheritance:
