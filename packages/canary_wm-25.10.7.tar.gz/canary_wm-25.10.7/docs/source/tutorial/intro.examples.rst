.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

Getting the examples
====================

All examples used in the tutorial can be obtained via:

.. code-block:: console

    canary fetch examples
