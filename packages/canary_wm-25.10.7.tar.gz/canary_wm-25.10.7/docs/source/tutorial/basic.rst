.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

Getting started
===============

.. toctree::
    :maxdepth: 1

    A first test <basic.first>
    A second test <basic.second>
    basic.other
