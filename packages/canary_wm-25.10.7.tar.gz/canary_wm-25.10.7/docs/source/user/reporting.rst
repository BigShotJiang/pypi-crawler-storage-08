.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

.. _usage:

Reporting test results
======================

.. toctree::
   :maxdepth: 1

   reporting.junit
   reporting.markdown
   reporting.html
   reporting.json
