.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

.. _util-executable:

Executable
==========

.. autoclass:: canary.Executable
    :members:
    :member-order: bysource
    :special-members: __call__
