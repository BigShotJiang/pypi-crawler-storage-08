.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

.. presentation-technical-hierarchical:

Overview of hierarchical parallelism
====================================

- Diagram showing the execution flow from individual tests to large parallel suites.
