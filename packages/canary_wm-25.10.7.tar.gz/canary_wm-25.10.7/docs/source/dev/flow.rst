.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

.. _developers-flow:

canary run program flow
=======================

Below is the program flow for ``canary run``:

.. imagesvg:: ../dot/Design.svg
    :width: 800px
