import FreeSimpleGUI as sg

def default_theme() :
    sg.theme("DarkAmber")
    sg.set_options(font=("Helvetica", 12))