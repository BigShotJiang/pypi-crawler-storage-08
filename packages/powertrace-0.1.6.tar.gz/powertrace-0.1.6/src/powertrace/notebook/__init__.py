from .extension import load_ipython_extension
