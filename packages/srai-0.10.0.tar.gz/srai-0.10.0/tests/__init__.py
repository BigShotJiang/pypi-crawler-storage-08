"""Tests for srai module."""
