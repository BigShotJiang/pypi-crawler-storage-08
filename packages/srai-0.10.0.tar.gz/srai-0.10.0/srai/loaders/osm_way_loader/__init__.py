"""OSMWayloader."""

from .osm_way_loader import OSMNetworkType, OSMWayLoader

__all__ = ["OSMWayLoader", "OSMNetworkType"]
