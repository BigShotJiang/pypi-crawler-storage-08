Project tags are limited to the desired projects.
