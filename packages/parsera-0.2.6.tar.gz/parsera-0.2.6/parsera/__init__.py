from parsera.parsera import Parsera

__all__ = ["Parsera"]
