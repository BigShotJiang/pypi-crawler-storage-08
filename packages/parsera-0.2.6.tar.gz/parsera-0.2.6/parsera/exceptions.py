class PageGotoError(Exception):
    pass


class CookiesValidationException(Exception):
    pass


class PageContentError(ValueError):
    pass
