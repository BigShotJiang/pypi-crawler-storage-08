class NotFoundException(Exception):  # noqa: N818
    "Raised when something was not found"
