# -*- coding: utf-8 -*- {{{
# ===----------------------------------------------------------------------===
#
#                 Installable Component of Eclipse VOLTTRON
#
# ===----------------------------------------------------------------------===
#
# Copyright 2022 Battelle Memorial Institute
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may not
# use this file except in compliance with the License. You may obtain a copy
# of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.
#
# ===----------------------------------------------------------------------===
# }}}
"""Utilities for tracking VIP message statistics at the router."""

import gevent


__all__ = ["BaseTracker"]


def pick(frames, index):
    """Return the frame at index, converted to bytes, or None."""
    try:
        return bytes(frames[index])
    except IndexError:
        return None


def increment(prop, key):
    """Increment or set to 1 the value in prop[key]."""
    try:
        prop[key] += 1
    except KeyError:
        prop[key] = 1


class BaseTracker(object):
    """Object for sharing data between the router and control objects."""

    def __init__(self):
        self._reset()
        self.enabled = False

    def reset(self):
        """Reset all counters to default values and set start time."""
        self._reset()
        self.stats["start"] = gevent.get_hub().loop.now()

    def _reset(self):
        """Initialize statistics counters."""
        self.stats = {
            "error": {
                "error": {},
                "peer": {},
                "user": {},
                "subsystem": {}
            },
            "unroutable": {
                "error": {},
                "peer": {}
            },
            "incoming": {
                "peer": {},
                "user": {},
                "subsystem": {}
            },
            "outgoing": {
                "peer": {},
                "user": {},
                "subsystem": {}
            },
        }

    def enable(self):
        """Enable tracking."""
        if not self.enabled:
            self.reset()
            self.enabled = True

    def disable(self):
        """Disable tracking."""
        if self.enabled:
            self.enabled = False
            self.stats["end"] = gevent.get_hub().loop.now()
