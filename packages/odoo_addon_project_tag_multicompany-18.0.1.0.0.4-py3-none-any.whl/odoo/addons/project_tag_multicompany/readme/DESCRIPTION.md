The module adds the possibility of set a company (or not) to the project
tags, making them visible in all companies or only in the defined one.
