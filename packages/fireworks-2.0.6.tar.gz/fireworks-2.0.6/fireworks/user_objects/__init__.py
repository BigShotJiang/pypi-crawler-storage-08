"""User-facing objects: firetasks, dupefinders, and queue adapters."""
