class B5ExecutionError(RuntimeError):
    pass
