import os

VERSION = '1.4.5'
B5_PATH = os.path.realpath(os.path.dirname(__file__))
B5_BASH_PATH = os.path.join(B5_PATH, 'bash')
B5_TEMPLATES_PATH = os.path.join(B5_PATH, 'templates')
