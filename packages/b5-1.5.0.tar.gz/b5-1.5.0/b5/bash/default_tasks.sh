#!/usr/bin/env bash

task:help() {
    b5:help "$@"
}
