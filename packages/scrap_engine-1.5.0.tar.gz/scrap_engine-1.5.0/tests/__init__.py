from .add_text_test import TextTest
from .circle import CircleTest
from .circler import CirclerTest
from .stack_test import StackTest
