from typing import Literal

type State = Literal["float", "solid"]

DEFAULT_STATE: State = "solid"
