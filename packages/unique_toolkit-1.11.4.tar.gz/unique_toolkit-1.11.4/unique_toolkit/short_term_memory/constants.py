DOMAIN_NAME = "short_term_memory"
