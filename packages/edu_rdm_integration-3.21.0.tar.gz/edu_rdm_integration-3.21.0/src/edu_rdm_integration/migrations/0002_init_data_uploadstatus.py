# flake8: noqa
from django.db import (
    migrations,
)


class Migration(migrations.Migration):
    dependencies = [
        ('edu_rdm_integration', '0001_initial'),
    ]

    operations = []
