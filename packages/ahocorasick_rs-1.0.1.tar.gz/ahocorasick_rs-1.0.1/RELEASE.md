# Release process

1. Update version in Cargo.toml, commit and push.
2. Tag release in GitHub.
