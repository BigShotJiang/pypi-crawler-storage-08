# OpenAI schema package
