# Server module for Mirix
# This module contains all server-related functionality

from .fastapi_server import app

__all__ = ["app"]
