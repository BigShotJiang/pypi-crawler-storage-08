
from mirix.agent import Agent


class ResourceMemoryAgent(Agent):
    def __init__(self, **kwargs):
        # load parent class init
        super().__init__(**kwargs)
