"""
App init
"""

# Django
from django.utils.translation import gettext_lazy as _

__version__ = "2.3.4"
__title__ = _("RSS to Discord")
