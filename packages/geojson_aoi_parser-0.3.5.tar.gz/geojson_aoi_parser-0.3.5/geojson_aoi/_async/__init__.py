"""The main parser package for geojson-aoi-parser."""
