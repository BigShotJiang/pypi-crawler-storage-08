# API Docs

## Main Functions

::: geojson_aoi.parse_aoi
options:
show_source: false
heading_level: 3

::: geojson_aoi.parse_aoi_async
options:
show_source: false
heading_level: 3

## Helpers

::: geojson_aoi.DbConfig
options:
show_source: false
heading_level: 3
