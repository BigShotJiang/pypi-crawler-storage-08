This module extends the functionality of the 'Technical Pricelists for Sales' module (same repository)
to prevent users from selecting technical pricelists on account invoice forms.
