canopy.visualization
====================

canopy.visualization.comparison\_plot
-------------------------------------

.. automodule:: canopy.visualization.comparison_plot
   :members:
   :show-inheritance:
   :undoc-members:

canopy.visualization.map
------------------------

.. automodule:: canopy.visualization.map
   :members:
   :show-inheritance:
   :undoc-members:

canopy.visualization.plot\_functions
------------------------------------

.. automodule:: canopy.visualization.plot_functions
   :members:
   :show-inheritance:
   :undoc-members:

canopy.visualization.projections
--------------------------------

.. automodule:: canopy.visualization.projections
   :members:
   :show-inheritance:
   :undoc-members:

canopy.visualization.static\_plot
---------------------------------

.. automodule:: canopy.visualization.static_plot
   :members:
   :show-inheritance:
   :undoc-members:

canopy.visualization.time\_series
---------------------------------

.. automodule:: canopy.visualization.time_series
   :members:
   :show-inheritance:
   :undoc-members: