canopy.plotting
===============

canopy.plotting.quick\_plot
---------------------------

.. automodule:: canopy.plotting.quick_plot
   :members:
   :show-inheritance:
   :undoc-members:
