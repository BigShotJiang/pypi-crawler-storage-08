import canopy.sources.source_lpjguess
import canopy.sources.source_fluxnet2015
from canopy.sources.registry import register_source, get_source
