"""MDIO templates for known dataset kinds."""
