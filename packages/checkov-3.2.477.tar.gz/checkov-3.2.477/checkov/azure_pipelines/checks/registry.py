from checkov.common.bridgecrew.check_type import CheckType
from checkov.yaml_doc.base_registry import Registry

registry = Registry(CheckType.AZURE_PIPELINES)
