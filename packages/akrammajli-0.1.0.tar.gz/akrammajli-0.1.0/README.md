# AkramMajli
An educational Python package with multiple examples: greetings, math utilities and plotting functions.

## Usage
```python
from AkramMajli import say_hello, add, plot_list

print(say_hello("Majli"))
print(add(5, 3))

plot_list([1,3,2,5,7])
