from oshconnect import OSHConnect, Node

node = Node()
app = OSHConnect()