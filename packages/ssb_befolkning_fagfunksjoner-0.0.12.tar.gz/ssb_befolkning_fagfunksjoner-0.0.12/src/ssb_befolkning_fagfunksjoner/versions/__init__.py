"""Subpackage for versioning of datasets used in production of population statistics."""

from ssb_befolkning_fagfunksjoner.versions.versions import get_next_version_number
from ssb_befolkning_fagfunksjoner.versions.versions import write_versioned_pandas

__all__ = ["get_next_version_number", "write_versioned_pandas"]
