# dødlighetstabell - statbanktabell
# dokumentert: ligger i "om statistikken"

# forventa levealder
# på 1 årig alder: antall fødte året før, middelfolkemengde i året, antall døde før og etter sin bursdag,
# standardiseres, ordnes, beregnes
# håndverk: de eldste (arbitrært satt grense (de over grensa strykes))

# SAS kode: døde området i prod
# loop: flytt flatfil til linux, oppdaterer en annen fil
#
# Regneark: ligger i prodsona
#

# nasjonale bruker dødssannsynlighet for landet på gruppenivå

# produkter:
# forventa gjenstående levealder
# tabell (07902) - nerdetabell
# levende ved alder x, andel døde i alder x til x+1, dødssannsynlighet -> forventet gjenstående levetid

# forventa gjenstående levealder (enkel)
# tabell (05375)

# (05797) - intervaller, skal fjernes (lage 1 års intervaller)

# Dødfødte - fra fødtestatistikken
