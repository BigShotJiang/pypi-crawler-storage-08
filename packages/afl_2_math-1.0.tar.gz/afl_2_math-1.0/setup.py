from setuptools import setup, find_packages

setup(
    name="AFL_2_MATH",
    version="1.0",
    packages=find_packages(),
    install_requires=[
        
    ],
)