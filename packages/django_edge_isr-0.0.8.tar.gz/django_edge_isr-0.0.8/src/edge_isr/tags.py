from __future__ import annotations


def tag(namespace: str, ident) -> str:
    return f"{namespace}:{ident}"
