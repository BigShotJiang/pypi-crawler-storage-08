from griptape.drivers.prompt.dummy_prompt_driver import DummyPromptDriver

__all__ = ["DummyPromptDriver"]
