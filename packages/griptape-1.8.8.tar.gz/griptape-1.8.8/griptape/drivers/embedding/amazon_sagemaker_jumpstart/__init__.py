from griptape.drivers.embedding.amazon_sagemaker_jumpstart_embedding_driver import (
    AmazonSageMakerJumpstartEmbeddingDriver,
)

__all__ = ["AmazonSageMakerJumpstartEmbeddingDriver"]
