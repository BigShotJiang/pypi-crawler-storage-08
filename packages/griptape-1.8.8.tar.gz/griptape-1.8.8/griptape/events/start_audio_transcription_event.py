from griptape.events.base_audio_transcription_event import BaseAudioTranscriptionEvent


class StartAudioTranscriptionEvent(BaseAudioTranscriptionEvent): ...
