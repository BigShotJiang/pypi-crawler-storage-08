from fred.settings import (
    logger_manager,
)


logger = logger_manager.get_logger(name=__name__)


class ModelInterface:
    pass
