"""ShadeMesh Writer.

Note to developers:
Use this module to extend honeybee's ShadeMesh writer for new extensions.
(eg. adding `idf` to this module adds the method `ShadeMesh.to.idf`)
"""
