"""Shade Writer.

Note to developers:
Use this module to extend honeybee's Shade writer for new extensions.
(eg. adding `idf` to this module adds the method `Shade.to.idf`)
"""
