"""Door Writer.

Note to developers:
Use this module to extend honeybee's Door writer for new extensions.
(eg. adding `idf` to this module adds the method `Door.to.idf`)
"""
