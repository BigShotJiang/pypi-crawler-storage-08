"""Test package namespace for shared utilities (markers, fixtures)."""
