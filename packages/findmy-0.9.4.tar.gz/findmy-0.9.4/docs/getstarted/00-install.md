# Installation

FindMy.py is available in the standard PyPi repositories. You can install it using the following command:

```bash
pip install -U findmy
```

We highly recommend using a [virtual environment](https://docs.python.org/3/library/venv.html) for your project
if you want to use FindMy.py. This reduces the chance of dependency conflicts.
