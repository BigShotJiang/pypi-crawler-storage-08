# xwnode/src/xwnode_wrapper.py
"""Redirect package: Please install exonware-xwnode instead."""
raise ImportError(
    "This is a redirect package. "
    "Please install: pip install exonware-xwnode"
)
