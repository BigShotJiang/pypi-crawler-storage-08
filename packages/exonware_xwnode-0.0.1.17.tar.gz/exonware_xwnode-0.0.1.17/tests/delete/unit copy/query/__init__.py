# Query operations tests
