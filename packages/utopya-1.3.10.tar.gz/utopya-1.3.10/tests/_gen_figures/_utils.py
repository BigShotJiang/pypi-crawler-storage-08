"""Utility functions for the figure generation"""
