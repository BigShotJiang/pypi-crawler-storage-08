"""Simple Spring Cloud Config client for Python"""

from .client import SpringConfigClient

__version__ = "0.1.0"
__all__ = ["SpringConfigClient"]