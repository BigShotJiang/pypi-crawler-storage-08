__all__ = ["__version__"]
__version__ = "0.1.1"
# test file at 2025-10-10T11:02:13+08:00
