# toml-fmt-common

Contains Python code common to all formatters under the `toml-fmt` umbrella (meant to only be used by that project).

[![check](https://github.com/tox-dev/toml-fmt-common/actions/workflows/check.yaml/badge.svg)](https://github.com/tox-dev/toml-fmt-common/actions/workflows/check.yaml)
[![PyPI version](https://badge.fury.io/py/toml-fmt-common.svg)](https://badge.fury.io/py/toml-fmt-common)
[![PyPI Supported Python Versions](https://img.shields.io/pypi/pyversions/toml-fmt-common.svg)](https://pypi.python.org/pypi/toml-fmt-common/)
[![Downloads](https://static.pepy.tech/badge/toml-fmt-common/month)](https://pepy.tech/project/toml-fmt-common)
