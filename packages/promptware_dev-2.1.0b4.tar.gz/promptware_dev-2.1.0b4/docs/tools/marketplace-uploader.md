# Marketplace Uploader Tool

Simulate marketplace uploads and return artifact paths.
