**Italiano**

Questo modulo aggiunge alcuni campi, utili come prerequisito per inviare
file XML e ZIP delle fatture elettroniche

<http://www.fatturapa.gov.it/export/fatturazione/it/normativa/f-2.htm>

tramite email PEC, WEB API oppure SFTP al Sistema di Interscambio (SdI).

<http://www.fatturapa.gov.it/export/fatturazione/it/sdi.htm>

**English**

This module add some useful fields as a pre-requisite to send XML and
ZIP files of electronic invoices

<http://www.fatturapa.gov.it/export/fatturazione/en/normativa/f-2.htm>

through mail PEC, WEB API or SFTP to the Exchange System (ES).

<http://www.fatturapa.gov.it/export/fatturazione/en/sdi.htm>
