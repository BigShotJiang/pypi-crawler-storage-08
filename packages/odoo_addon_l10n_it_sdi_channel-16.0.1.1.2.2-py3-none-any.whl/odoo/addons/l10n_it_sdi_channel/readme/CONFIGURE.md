**Italiano**

Andare in Contabilità → Configurazione → Contabilità → Canali SdI

Per la configurazione del canale vedere il modulo l10n_it_fatturapa_pec

**English**

Go to Accounting → Configuration → Accounting → ES Channels

For further details on how to configure a channel have a look at
l10n_it_fatturapa_pec
