from agno.db.mongo.mongo import MongoDb

__all__ = ["MongoDb"]
