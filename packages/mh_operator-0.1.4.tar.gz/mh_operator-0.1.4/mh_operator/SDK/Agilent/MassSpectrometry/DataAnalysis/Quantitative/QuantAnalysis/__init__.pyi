from . import Properties
