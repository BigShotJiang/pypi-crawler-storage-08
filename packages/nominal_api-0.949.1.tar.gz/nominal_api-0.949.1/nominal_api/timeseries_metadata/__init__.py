# coding=utf-8
from .._impl import (
    timeseries_metadata_SeriesMetadataService as SeriesMetadataService,
)

__all__ = [
    'SeriesMetadataService',
]

