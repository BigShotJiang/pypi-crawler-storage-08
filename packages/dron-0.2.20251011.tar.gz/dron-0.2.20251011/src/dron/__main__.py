# NOTE: import needs to be on top level as it's the entry point
from .dron import main

if __name__ == '__main__':
    main()
