# stlg

Sample Test List Generator for SPeTCDB

## Features

- Fetches and filters test paths from SPeTCDB
- Generates configuration files
- Supports simulator and IP name filters
- Command-line interface

## Installation

```bash
pip install stlg
