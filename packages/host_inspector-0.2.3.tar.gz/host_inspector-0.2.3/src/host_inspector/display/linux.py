def get_display_info() -> list[dict]:
    # TODO: Implement Linux display detection
    return [
        {
            "name": "--",
            "display_id": 1,
            "resolution_actual": "--",
            "resolution": "--",
            "refresh_rate": "--",
        }
    ]
