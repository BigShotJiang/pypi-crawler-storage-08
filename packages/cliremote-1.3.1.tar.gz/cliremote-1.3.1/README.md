# Remote
Core Telegram Remote client engine (MrAhmadiRad)
[GitHub-flavored Markdown](https://github.com/MohammadAhmadi-R/CliRemote)