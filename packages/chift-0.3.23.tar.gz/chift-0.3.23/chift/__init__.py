from chift.models import *

# configuration

client_secret = None
client_id = None
environment_id = None
account_id = None
related_chain_execution_id = None
sync_id = None
url_base = "https://api.chift.eu"
test_client = None
