class MessagePrompt(Exception):
    pass
