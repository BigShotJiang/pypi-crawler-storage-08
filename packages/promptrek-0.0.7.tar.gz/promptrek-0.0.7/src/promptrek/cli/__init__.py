"""CLI module for PromptTrek."""

__all__ = []
