::: mkvinfo.MKVInfoError
::: mkvinfo.ExecutableNotFoundError
