class GlobalSettings:
    """
    This is a global object for storing settings used throughout the library.
    """

    aggregates_zero_for_empty_data = False
