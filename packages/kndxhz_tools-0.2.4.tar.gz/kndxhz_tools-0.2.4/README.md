# kndxhz tools
这是一个我自用的实用python工具集

都是自用的便利常用函数罢了

# 函数说明
[点此查看](./docs/function.md)