default_app_config = "chanx.ext.channels.apps.ChanxChannelsConfig"
