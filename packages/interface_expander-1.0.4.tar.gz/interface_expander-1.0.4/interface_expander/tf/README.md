# PonyFrame

A [TinyFrame](https://github.com/MightyPork/TinyFrame) port to Python

This is called PonyFrame because a python package MUST have some pun on "py", but PynyFrame and pyTinyFrame sound odd, so I had to go for a compromise. Also, ponies are cool, right?

This port is developed for use in the GEX python client. It may be incomplete, features needed by that project are implemented first.

The code was written with some haste and my python skills are a bit rusty, so PRs to optimize the code or clean it up are welcome!
