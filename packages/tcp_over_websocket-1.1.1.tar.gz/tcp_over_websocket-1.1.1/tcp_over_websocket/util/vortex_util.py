SERVER_VORTEX_NAME = "vortex_server"
CLIENT_VORTEX_NAME_1 = "vortex_client_1"
CLIENT_VORTEX_NAME_2 = "vortex_client_2"

# Client management constants
CLIENT_KILL_SIGNAL_FILT = "client_kill_signal"
CLIENT_ACTIVE_SIGNAL_FILT = "client_active_signal"
