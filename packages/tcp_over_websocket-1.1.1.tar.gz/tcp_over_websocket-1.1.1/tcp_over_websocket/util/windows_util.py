import platform

isWindows = platform.system() == "Windows"
