from enum import Enum



class MessageEmergencyTypeEnum(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    IMMEDIATE = "immediate"


