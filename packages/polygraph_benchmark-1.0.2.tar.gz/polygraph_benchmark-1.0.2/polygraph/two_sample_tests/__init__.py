from polygraph.two_sample_tests.permutation_mmd import (
    BootStrapMMDTest,
    BootStrapMaxMMDTest,
)

__all__ = ["BootStrapMMDTest", "BootStrapMaxMMDTest"]
