import logging

LOGGERNAME = 'coopgame'
logger = logging.getLogger(LOGGERNAME)
logger.setLevel(logging.INFO)
