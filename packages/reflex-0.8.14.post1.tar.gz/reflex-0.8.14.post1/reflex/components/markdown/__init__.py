"""Markdown components."""

from .markdown import Markdown

markdown = Markdown.create
