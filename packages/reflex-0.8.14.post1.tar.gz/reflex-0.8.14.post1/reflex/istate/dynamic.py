"""A container for dynamically generated states."""

# This page intentionally left blank.
