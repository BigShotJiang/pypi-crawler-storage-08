# Copyright (c) 2025 Datalayer, Inc.
#
# BSD 3-Clause License

VERSION = "0.1.1"
