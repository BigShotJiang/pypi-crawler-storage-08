"""Compatibility shims that re-export the Whale library symbols."""

from whale.pointcloud import PointCloud

__all__ = ["PointCloud"]
