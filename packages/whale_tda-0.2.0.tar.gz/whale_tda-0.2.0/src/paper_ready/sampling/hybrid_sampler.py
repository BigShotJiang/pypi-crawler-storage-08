"""Compatibility shim forwarding to :mod:`whale.sampling.hybrid_sampler`."""

from whale.sampling.hybrid_sampler import *  # noqa: F401,F403
