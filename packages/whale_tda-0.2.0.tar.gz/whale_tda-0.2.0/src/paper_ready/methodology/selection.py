"""Compatibility shim forwarding to :mod:`whale.methodology.selection`."""

from whale.methodology.selection import *  # noqa: F401,F403
