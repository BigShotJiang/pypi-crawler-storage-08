"""Compatibility namespace for :mod:`whale.methodology`."""

from whale.methodology import selection, witness_ph

__all__ = ["selection", "witness_ph"]
