"""Compatibility shim forwarding to :mod:`whale.methodology.witness_ph`."""

from whale.methodology.witness_ph import *  # noqa: F401,F403
