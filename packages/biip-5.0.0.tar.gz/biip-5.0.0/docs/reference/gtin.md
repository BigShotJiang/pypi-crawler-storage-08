# `biip.gtin`

::: biip.gtin
