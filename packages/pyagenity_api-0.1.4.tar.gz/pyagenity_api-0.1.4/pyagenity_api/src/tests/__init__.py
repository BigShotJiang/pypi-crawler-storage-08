"""Tests package for pyagenity_api CLI."""
