from graph_sitter.compiled.resolution import ResolutionStack

__all__ = ["ResolutionStack"]
