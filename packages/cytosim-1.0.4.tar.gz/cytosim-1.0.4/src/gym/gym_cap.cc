// Cytosim was created by Francois Nedelec. Copyright 2022 Cambridge University

#include "gym_cap.h"


GLboolean gym::depth_ = 0;
GLboolean gym::cull_ = 0;
GLboolean gym::blend_ = 0;


GLboolean gym::light_ = 0;
GLboolean gym::alpha_ = 0;


