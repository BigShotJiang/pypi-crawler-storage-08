def dummy():
    return None