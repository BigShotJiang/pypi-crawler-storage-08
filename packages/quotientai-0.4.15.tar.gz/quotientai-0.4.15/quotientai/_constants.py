TRACER_NAME = "quotient.sdk.python"
DEFAULT_TRACING_ENDPOINT = "https://otel.quotientai.co/v1/traces"
