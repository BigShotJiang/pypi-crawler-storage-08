# sage_setup: distribution = sagemath-libecm
# delvewheel: patch

from sage.all__sagemath_categories import *
