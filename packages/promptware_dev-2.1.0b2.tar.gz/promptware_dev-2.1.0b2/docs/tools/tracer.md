# Tracer Tool

Emit simple trace IDs.
