from django.apps import AppConfig


class ReferencesApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'energy_base.references_api'
