from django.apps import AppConfig


class CronTasksConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'energy_base.cron_tasks'
