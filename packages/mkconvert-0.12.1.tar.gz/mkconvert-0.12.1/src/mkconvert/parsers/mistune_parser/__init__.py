"""Mistune Parser."""

from mkconvert.parsers.mistune_parser.parser import MistuneParser

__all__ = ["MistuneParser"]
