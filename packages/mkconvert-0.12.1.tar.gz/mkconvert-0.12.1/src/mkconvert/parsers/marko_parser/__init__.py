"""Marko Parser."""

from mkconvert.parsers.marko_parser.parser import MarkoParser

__all__ = ["MarkoParser"]
