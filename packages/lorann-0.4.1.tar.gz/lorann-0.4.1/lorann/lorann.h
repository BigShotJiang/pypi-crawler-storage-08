#pragma once

typedef double lorann_dist_t;

#include "lorann_base.h"
#include "lorann_fp.h"
#include "lorann_quant.h"