"""
I have conceded that most packages name this kind of module "utils" with the plural s so I will slowly
move all the functionality into this module. But for the time being and for the sake of backwards
compatibility, this module is just an alternative to the "util"
"""

from pycomex.util import *
