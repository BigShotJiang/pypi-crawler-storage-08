import bloqade.analog


def test_version():
    print(bloqade.analog.__version__)
    assert bloqade.analog.__version__
