"""
Firestore CLI package
"""
