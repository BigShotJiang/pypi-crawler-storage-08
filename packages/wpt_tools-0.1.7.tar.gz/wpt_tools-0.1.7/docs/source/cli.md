# Command Line Interface

The ``wpt`` command provides a simple interface to run wireless power tools demos and analyses.

```{eval-rst}
.. click:: wpt_tools.cli.main:cli
   :prog: wpt
   :show-nested:
```
