# SPDX-License-Identifier: GPL-3.0-or-later

"""
Required for Visual Studio as otherwise it does not recognize the tests in the test folder,
for reference see
https://stackoverflow.com/questions/66504420/visual-studio-2019-cannot-run-python-unittests-failed-to-import-test-module
"""
