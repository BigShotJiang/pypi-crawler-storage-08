"""Chat-based popup application (LLM, embeddings, vector store)."""
