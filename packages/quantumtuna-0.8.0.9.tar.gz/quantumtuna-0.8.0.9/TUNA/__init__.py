"""

TUNA

~~~~ Theoretical Unification of Nuclear Arrangements ~~~~

A user-friendly quantum chemistry program for diatomics.

"""

__version__ = "0.8.0.9"
__author__ = "Harry Brough"
