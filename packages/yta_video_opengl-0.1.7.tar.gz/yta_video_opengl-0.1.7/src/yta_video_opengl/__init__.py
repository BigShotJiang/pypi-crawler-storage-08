"""
Module to include video handling with OpenGL.
"""