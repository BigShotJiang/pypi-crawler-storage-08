# Youtube Autonomous Video OpenGL Module

The way to handle videos with OpenGL.

Based on `moderngl`.