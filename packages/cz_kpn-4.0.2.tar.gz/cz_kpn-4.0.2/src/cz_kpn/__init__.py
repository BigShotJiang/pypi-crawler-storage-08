from cz_kpn.rules import KPNCz

__all__ = ["KPNCz"]
