"""Markdown-it-pyrs parser module."""

from mkconvert.parsers.markdown_it_pyrs_parser.parser import MarkdownItPyRSParser

__all__ = ["MarkdownItPyRSParser"]
