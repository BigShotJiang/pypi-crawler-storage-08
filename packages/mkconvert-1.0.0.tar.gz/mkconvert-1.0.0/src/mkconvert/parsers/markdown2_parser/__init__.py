"""Markdown2 Markdown Parser."""

from mkconvert.parsers.markdown2_parser.parser import Markdown2Parser

__all__ = ["Markdown2Parser"]
