"""Comrak Markdown Parser."""

from mkconvert.parsers.comrak_parser.parser import ComrakParser

__all__ = ["ComrakParser"]
