"""GitHub API Markdown Parser."""

from mkconvert.parsers.github_api_parser.parser import GithubApiParser

__all__ = ["GithubApiParser"]
