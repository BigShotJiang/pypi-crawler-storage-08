"""Tests for DLRS scheduler"""
