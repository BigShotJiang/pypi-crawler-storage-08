class InvalidPackFormat(Exception):
    pass
