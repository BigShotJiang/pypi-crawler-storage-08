"""XKNX is a Python 3 library for KNX/IP protocol."""

from .xknx import XKNX

__all__ = [
    "XKNX",
]
