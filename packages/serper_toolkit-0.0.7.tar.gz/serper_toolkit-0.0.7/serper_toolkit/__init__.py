# serper/__init__.py
from .server import main

__all__ = ["main"]