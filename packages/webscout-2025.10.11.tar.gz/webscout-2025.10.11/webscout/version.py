__version__ = "2025.10.11"
__prog__ = "webscout"
