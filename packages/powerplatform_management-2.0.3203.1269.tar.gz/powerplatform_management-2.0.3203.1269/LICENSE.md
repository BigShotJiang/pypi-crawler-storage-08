MICROSOFT SOFTWARE LICENSE TERMS

By installing Microsoft Power Platform Management package, you agree to the terms at: <https://go.microsoft.com/fwlink/?linkid=2160606>
