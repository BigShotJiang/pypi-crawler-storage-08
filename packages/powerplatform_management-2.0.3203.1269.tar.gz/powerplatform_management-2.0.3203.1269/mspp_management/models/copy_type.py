from enum import Enum

class CopyType(str, Enum):
    Minimal = "Minimal",
    Full = "Full",

