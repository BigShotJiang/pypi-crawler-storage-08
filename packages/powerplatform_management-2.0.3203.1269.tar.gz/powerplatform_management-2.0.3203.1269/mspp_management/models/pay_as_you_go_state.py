from enum import Enum

class PayAsYouGoState(str, Enum):
    Enabled = "Enabled",
    Disabled = "Disabled",

