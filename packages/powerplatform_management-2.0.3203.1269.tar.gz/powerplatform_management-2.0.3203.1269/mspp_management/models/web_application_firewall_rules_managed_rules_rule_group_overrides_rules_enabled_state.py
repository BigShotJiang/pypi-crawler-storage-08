from enum import Enum

class WebApplicationFirewallRules_managedRules_RuleGroupOverrides_Rules_EnabledState(str, Enum):
    Enabled = "Enabled",
    Disabled = "Disabled",

