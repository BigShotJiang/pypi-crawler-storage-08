from enum import Enum

class WebsiteDto_siteVisibility(str, Enum):
    Public = "public",
    Private = "private",

