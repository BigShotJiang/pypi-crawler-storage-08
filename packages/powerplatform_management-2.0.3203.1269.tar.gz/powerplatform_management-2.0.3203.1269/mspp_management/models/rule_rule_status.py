from enum import Enum

class Rule_RuleStatus(str, Enum):
    RuleFailed = "RuleFailed",
    RulePassed = "RulePassed",

