from enum import Enum

class ModernFlowType(str, Enum):
    PowerAutomateFlow = "PowerAutomateFlow",
    AgentFlow = "AgentFlow",

