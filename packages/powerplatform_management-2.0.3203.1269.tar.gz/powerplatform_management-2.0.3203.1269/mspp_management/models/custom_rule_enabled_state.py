from enum import Enum

class CustomRule_enabledState(str, Enum):
    Enabled = "Enabled",
    Disabled = "Disabled",

