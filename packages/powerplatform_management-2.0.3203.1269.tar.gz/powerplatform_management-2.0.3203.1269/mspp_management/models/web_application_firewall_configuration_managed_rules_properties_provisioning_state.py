from enum import Enum

class WebApplicationFirewallConfiguration_ManagedRules_properties_provisioningState(str, Enum):
    Succeeded = "Succeeded",
    Failed = "Failed",
    Updating = "Updating",

