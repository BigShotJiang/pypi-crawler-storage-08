from enum import Enum

class BillingPolicyStatus(str, Enum):
    Enabled = "Enabled",
    Disabled = "Disabled",

