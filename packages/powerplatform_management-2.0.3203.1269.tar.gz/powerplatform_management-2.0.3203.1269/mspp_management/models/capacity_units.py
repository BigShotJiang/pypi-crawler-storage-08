from enum import Enum

class CapacityUnits(str, Enum):
    None_ = "None",
    Unit = "Unit",
    MB = "MB",

