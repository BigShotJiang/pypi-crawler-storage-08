from enum import Enum

class WebApplicationFirewallConfiguration_ManagedRules_properties_ruleGroups_rules_defaultState(str, Enum):
    Enabled = "Enabled",
    Disabled = "Disabled",

