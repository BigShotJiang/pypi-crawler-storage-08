from enum import Enum

class IpAddressType(str, Enum):
    IPv4 = "IPv4",
    IPv6 = "IPv6",

