from enum import Enum

class WebsiteDto_type(str, Enum):
    Trial = "Trial",
    Production = "Production",

