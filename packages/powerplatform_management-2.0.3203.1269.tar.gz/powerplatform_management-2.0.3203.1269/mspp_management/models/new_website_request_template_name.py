from enum import Enum

class NewWebsiteRequest_templateName(str, Enum):
    DefaultPortalTemplate = "DefaultPortalTemplate",
    PowerPortals_ProgramRegistration = "PowerPortals_ProgramRegistration",
    PowerPortals_BookMeeting = "PowerPortals_BookMeeting",

