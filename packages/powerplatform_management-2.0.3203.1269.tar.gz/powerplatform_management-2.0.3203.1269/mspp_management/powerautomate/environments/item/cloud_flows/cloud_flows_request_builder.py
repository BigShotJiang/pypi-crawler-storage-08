from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID
from warnings import warn

if TYPE_CHECKING:
    from .....models.error_response import ErrorResponse
    from .cloud_flows_get_response import CloudFlowsGetResponse

class CloudFlowsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /powerautomate/environments/{environmentId}/cloudFlows
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new CloudFlowsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/powerautomate/environments/{environmentId}/cloudFlows?api-version={api%2Dversion}{&createdBy*,createdOnEndDate*,createdOnStartDate*,modifiedOnEndDate*,modifiedOnStartDate*,ownerId*,resourceId*,workflowId*}", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[CloudFlowsRequestBuilderGetQueryParameters]] = None) -> Optional[CloudFlowsGetResponse]:
        """
        Returns a list of cloud flows.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[CloudFlowsGetResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        from .....models.error_response import ErrorResponse

        error_mapping: dict[str, type[ParsableFactory]] = {
            "400": ErrorResponse,
            "404": ErrorResponse,
        }
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .cloud_flows_get_response import CloudFlowsGetResponse

        return await self.request_adapter.send_async(request_info, CloudFlowsGetResponse, error_mapping)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[CloudFlowsRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        Returns a list of cloud flows.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> CloudFlowsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: CloudFlowsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return CloudFlowsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class CloudFlowsRequestBuilderGetQueryParameters():
        """
        Returns a list of cloud flows.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "api_version":
                return "api%2Dversion"
            if original_name == "created_by":
                return "createdBy"
            if original_name == "created_on_end_date":
                return "createdOnEndDate"
            if original_name == "created_on_start_date":
                return "createdOnStartDate"
            if original_name == "modified_on_end_date":
                return "modifiedOnEndDate"
            if original_name == "modified_on_start_date":
                return "modifiedOnStartDate"
            if original_name == "owner_id":
                return "ownerId"
            if original_name == "resource_id":
                return "resourceId"
            if original_name == "workflow_id":
                return "workflowId"
            return original_name
        
        # The API version.
        api_version: Optional[str] = None

        # The creator Dataverse ID.
        created_by: Optional[UUID] = None

        # Filter for created on or before this date.
        created_on_end_date: Optional[datetime.date] = None

        # Filter for created on or after this date.
        created_on_start_date: Optional[datetime.date] = None

        # Filter for modified on or before this date.
        modified_on_end_date: Optional[datetime.date] = None

        # Filter for modified on or after this date.
        modified_on_start_date: Optional[datetime.date] = None

        # The owner Dataverse ID.
        owner_id: Optional[UUID] = None

        # The resource ID.
        resource_id: Optional[UUID] = None

        # The workflow ID.
        workflow_id: Optional[UUID] = None

    
    @dataclass
    class CloudFlowsRequestBuilderGetRequestConfiguration(RequestConfiguration[CloudFlowsRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

