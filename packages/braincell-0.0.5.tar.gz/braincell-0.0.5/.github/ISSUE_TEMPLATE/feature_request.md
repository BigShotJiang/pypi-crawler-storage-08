---
name: Feature Request
about: Suggest a new idea or improvement for ``braincell``
title: ''
labels: enhancement
assignees: ''

---

Please:

- [ ] Check for duplicate requests.
- [ ] Describe your goal, and if possible provide a code snippet with a motivating example.
