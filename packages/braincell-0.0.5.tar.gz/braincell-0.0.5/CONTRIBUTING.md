# Contributing to ``dendritex``

For information on how to contribute to ``dendritex``, see
