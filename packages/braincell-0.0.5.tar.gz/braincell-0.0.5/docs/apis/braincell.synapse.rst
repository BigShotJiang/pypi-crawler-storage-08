``braincell.synapse`` module
============================

.. currentmodule:: braincell.synapse 
.. automodule:: braincell.synapse 

Markov Models
-------------

.. autosummary::
   :toctree: generated/
   :nosignatures:
   :template: classtemplate.rst

   AMPA
   GABAa
   NMDA


