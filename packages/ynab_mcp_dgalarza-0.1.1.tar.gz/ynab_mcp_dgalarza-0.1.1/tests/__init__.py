"""Tests for YNAB MCP server."""
