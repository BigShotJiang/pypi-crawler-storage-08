API Docs
--------

::: interpn
    options:
        docstring_section_style: "table"
