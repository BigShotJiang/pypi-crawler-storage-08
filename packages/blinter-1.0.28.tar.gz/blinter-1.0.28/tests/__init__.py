"""Test package for blinter module."""
