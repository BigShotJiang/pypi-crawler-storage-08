import random

def hello(name="世界"):
    return f"🧅 洋蔥向 {name} 問好！"

def onionify(text):
    """用洋蔥風格包裝文字"""
    return f"🧅💧 {text} 💧🧅"

def onion_quote():
    """洋蔥語錄：隨機顯示一句洋蔥說過的名言"""
    quotes = [
        "因為只有你是男娘",
        " .洋蔥女裝",
        "那一天的女裝女裝起來",
        "我看到的只有潛在的垃圾訊息發送者，Discord 已屏蔽該訊息。",
        "敲碗洋蔥女裝full ver. ",
        "太棒了不要跟他們同流合污",
        "為什麼妳的屁股會長痘痘？4個步驟重獲光滑美臀！",
        "我的 pigue 開始報 error 了",
        "鈔怎麼甚至還有 user install",
        "總有一天的排程會輪到我婆的"
    ]
    print(random.choice(quotes))
