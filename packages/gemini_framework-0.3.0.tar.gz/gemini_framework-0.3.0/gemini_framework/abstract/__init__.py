"""Abstract interfaces for Gemini Framework.

Provides base classes for database drivers/readers and unit/module
abstractions used across the runtime framework.
"""
