from setuptools import setup

setup(
    use_scm_version=True,
)
