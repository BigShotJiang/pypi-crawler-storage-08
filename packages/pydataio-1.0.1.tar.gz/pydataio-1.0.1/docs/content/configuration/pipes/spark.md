---
title: Spark
layout: default
grand_parent: Configuration
parent: Pipes
nav_order: 1
---
# Spark

{% include pipe_description.md pipe=site.data.config.pipes.spark %}


