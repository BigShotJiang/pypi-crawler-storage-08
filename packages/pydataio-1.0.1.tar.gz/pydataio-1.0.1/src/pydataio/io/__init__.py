IO_BASENAME = __name__
