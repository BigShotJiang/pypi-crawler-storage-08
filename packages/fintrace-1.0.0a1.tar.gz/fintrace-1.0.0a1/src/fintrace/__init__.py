""" 
This package combines the ray tracing abilities of gtrace
with the optical modeling of finesse.
"""