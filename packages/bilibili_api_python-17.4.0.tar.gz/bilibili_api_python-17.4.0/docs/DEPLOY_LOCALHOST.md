# 文档本地部署教程

- 1. 基于 `node.js`，所以 `node` 和 `npm` 是一定要安装的。
- 2. 进入 `docs` 文件夹后执行 `npm install` 安装以来，请耐心等待。
- 3. 运行 `npm run localhost` 开启 `docsify` 服务程序。然后进入 `https://127.0.0.1/4000` 查看文档。
