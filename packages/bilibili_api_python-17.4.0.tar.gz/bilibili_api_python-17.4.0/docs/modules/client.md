# Module client.py


bilibili_api.client

IP 终端相关


``` python
from bilibili_api import client
```

- [async def get\_zone()](#async-def-get\_zone)

---

## async def get_zone()

通过 IP 获取地理位置



**Returns:** `dict`:  调用 API 返回的结果




