# 示例：获取课程元数据

``` python
from bilibili_api import cheese, sync

c = cheese.CheeseVideo(epid=5556)

print(c.get_meta())
```
