---
name: 提交需求/新功能
about: 使用该模板进行提交需求/新功能
title: "[新功能] 这里填写标题"
labels: 'features'
assignees: ''

---

在此处写正文
