
# YouTube İndirici Atilla

Bununla YouTube'daki videoları son kalitede kolayca indirebilirsiniz (MP4 ve Sesli).


## Özellikler

- GUI
- Kolay Kullanım
- Versiyon Kontrolü (Kaldırıldı)

  
## Nasıl Kullanılır?

İndirildikten Sonra Konsola Şunu Yazarak Başlatabilirsiniz.
```bash
ytvi
```
### veya
```bash
py -3.13 -m ytvi
```
## Lisans

[MIT](https://choosealicense.com/licenses/mit/)

  