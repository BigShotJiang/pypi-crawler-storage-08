"""Test configuration file."""

import pytest
