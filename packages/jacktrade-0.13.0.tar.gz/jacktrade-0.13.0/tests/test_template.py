import unittest


class Test(unittest.TestCase):
    """
    Tests
    """

    def test_(self):
        """Tests"""


if __name__ == "__main__":
    unittest.main()
