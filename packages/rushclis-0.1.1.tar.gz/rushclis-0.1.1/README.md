﻿# RushCli

Python cli class tools

## Install

``
python.exe scripts/install.py
``

## Use

继承RushCli类即可.