Scratchpad
==========

The ``otter.scratchpad`` package contains the scratchpad models and utilities. The
`Scratchpad` stores variables to be replaced in the Otter configuration files.


scratchpad.model module
-----------------------

.. automodule:: otter.scratchpad.model
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: pattern

Module contents
---------------

.. automodule:: otter.scratchpad
   :members:
   :undoc-members:
   :show-inheritance:
