"""Command-line entry point for rebel-forge."""

from .qlora import main

if __name__ == "__main__":
    main()
