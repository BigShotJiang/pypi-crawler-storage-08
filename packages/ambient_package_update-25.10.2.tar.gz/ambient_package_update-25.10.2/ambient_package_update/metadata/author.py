import dataclasses


@dataclasses.dataclass
class PackageAuthor:
    name: str
    email: str
