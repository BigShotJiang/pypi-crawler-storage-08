"""Magic-API MCP 助手模块初始化。"""

from .magicapi_assistant import create_app

__all__ = ["create_app"]
