"""NAIF PDS4 Bundle Classes Namespace.

The NPB Classes implement the main functionalities of the pipeline.
"""
