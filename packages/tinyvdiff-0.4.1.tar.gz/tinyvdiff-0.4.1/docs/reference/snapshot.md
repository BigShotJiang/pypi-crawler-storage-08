# snapshot utilities

::: tinyvdiff.snapshot
    options:
      members:
        - normalize_svg
        - compare_svgs
        - update_snapshot
      show_root_heading: true
      show_source: false
