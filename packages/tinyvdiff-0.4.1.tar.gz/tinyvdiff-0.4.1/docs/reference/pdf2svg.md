# pdf2svg wrapper

::: tinyvdiff.pdf2svg
    options:
      members:
        - PDF2SVG
      show_root_heading: true
      show_source: false
