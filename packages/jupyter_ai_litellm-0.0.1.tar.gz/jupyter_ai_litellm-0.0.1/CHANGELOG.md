# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 0.0.1

([Full Changelog](https://github.com/jupyter-ai-contrib/jupyter-ai-litellm/compare/47d6d9c4fc5d82ac2dfe9739ecfe2092335b2829...aa4d83dc2c85c5e960b7cb522b9eba0859d48100))

### Enhancements made

- Add LiteLLM dependency and handlers [#1](https://github.com/jupyter-ai-contrib/jupyter-ai-litellm/pull/1) ([@3coins](https://github.com/3coins))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-ai-contrib/jupyter-ai-litellm/graphs/contributors?from=2025-10-08&to=2025-10-08&type=c))

[@3coins](https://github.com/search?q=repo%3Ajupyter-ai-contrib%2Fjupyter-ai-litellm+involves%3A3coins+updated%3A2025-10-08..2025-10-08&type=Issues)

<!-- <END NEW CHANGELOG ENTRY> -->
