# sphinx-theme-shiratama

sphinx-theme-shiratama is a plain sphinx theme.

