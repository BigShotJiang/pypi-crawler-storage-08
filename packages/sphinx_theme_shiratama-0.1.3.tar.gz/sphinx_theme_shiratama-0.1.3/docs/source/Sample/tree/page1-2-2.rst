====================
page 1-2-2
====================

this is page 1-2-2

..  toctree::
    :maxdepth: 1

    page1-2-2-1
    page1-2-2-2