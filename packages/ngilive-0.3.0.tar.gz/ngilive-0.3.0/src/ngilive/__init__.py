from ngilive.api import NGILive

__all__ = ["NGILive"]
