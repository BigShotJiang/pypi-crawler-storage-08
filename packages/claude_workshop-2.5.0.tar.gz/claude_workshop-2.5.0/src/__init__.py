"""
Workshop - Persistent context tool for Claude Code
"""
__version__ = "2.5.0"
