"""Snitch is a tool for monitoring system activity."""

from snitch.snitch import check_activity  # noqa: F401
