from mielto.knowledge.document.base import Document

__all__ = [
    "Document",
]
