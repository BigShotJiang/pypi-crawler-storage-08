# medkey-sdk (Python)

Pre-release placeholder for MedKey Python SDK.

```python
from medkey_sdk import MedKey
client = MedKey(base_url="https://api.usemedkey.com", api_key="YOUR_KEY")
```
