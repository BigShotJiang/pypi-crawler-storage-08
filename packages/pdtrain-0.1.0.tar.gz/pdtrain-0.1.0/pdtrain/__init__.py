"""
pdtrain - Pipedream Training Orchestrator CLI

A command-line interface for managing ML training workflows on AWS SageMaker.
"""

__version__ = "0.1.0"
__author__ = "Pipedream"
__email__ = "support@pipedream.ai"
