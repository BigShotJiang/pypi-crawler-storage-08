# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.9.3
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x015\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M11.5 6.2\
5L8 9.75L4.5 6.2\
5\x22 stroke=\x22#8185\
94\x22 stroke-linec\
ap=\x22round\x22/>\x0a</s\
vg>\x0a\
\x00\x00\x04F\
<\
!-- Copyright 20\
00-2024 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
8.00001 1C11 1 1\
1 2 11 4L11 6.5C\
11 7.32843 10.32\
84 8 9.5 8H6.5C5\
.11929 8 4 9.119\
29 4 10.5V11C2 1\
1 1 11 1 7.99999\
C1 4.99999 2 4.9\
9998 4 4.99998L7\
.5 5C7.77614 5 8\
 4.77614 8 4.5C8\
 4.22386 7.77614\
 4 7.5 4H5.00001\
C5.00001 2 5.000\
01 1 8.00001 1ZM\
6.5 3C6.77614 3 \
7 2.77614 7 2.5C\
7 2.22386 6.7761\
4 2 6.5 2C6.2238\
6 2 6 2.22386 6 \
2.5C6 2.77614 6.\
22386 3 6.5 3Z\x22 \
fill=\x22#4682FA\x22/>\
\x0a<path fill-rule\
=\x22evenodd\x22 clip-\
rule=\x22evenodd\x22 d\
=\x22M12 5V6.5C12 7\
.88071 10.8807 9\
 9.5 9H6.5C5.671\
57 9 5 9.67157 5\
 10.5L5.00001 12\
C4.99946 14 5.00\
001 15 8.00001 1\
5C11 15 11 14 11\
 12L8.5 12C8.223\
86 12 8 11.7761 \
8 11.5C8 11.2239\
 8.22386 11 8.5 \
11L12 11C14 11.0\
005 15 11 15 7.9\
9999C15 5.00002 \
14 5.00001 12 5Z\
M9.5 14C9.77614 \
14 10 13.7761 10\
 13.5C10 13.2239\
 9.77614 13 9.5 \
13C9.22386 13 9 \
13.2239 9 13.5C9\
 13.7761 9.22386\
 14 9.5 14Z\x22 fil\
l=\x22#FFAF0F\x22/>\x0a</\
svg>\x0a\
\x00\x00\x02\x0a\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M8.15132 \
4.35836L8.29689 \
4.5H8.5H13C13.82\
84 4.5 14.5 5.17\
157 14.5 6V12.13\
33C14.5 12.919 1\
3.9104 13.5 13.2\
5 13.5H2.75C2.08\
955 13.5 1.5 12.\
919 1.5 12.1333V\
3.86667C1.5 3.08\
099 2.08955 2.5 \
2.75 2.5H6.03823\
C6.16847 2.5 6.2\
9357 2.55082 6.3\
8691 2.64164L8.1\
5132 4.35836Z\x22 s\
troke=\x22#6C707E\x22/\
>\x0a</svg>\x0a\
\x00\x00\x01\xa1\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M1.5 8C1.\
5 11.5899 4.4101\
5 14.5 8 14.5V1.\
5C4.41015 1.5 1.\
5 4.41015 1.5 8Z\
\x22 fill=\x22#EDF3FF\x22\
/>\x0a<path d=\x22M8 2\
V14\x22 stroke=\x22#35\
74F0\x22/>\x0a<circle \
cx=\x228\x22 cy=\x228\x22 r=\
\x226.5\x22 stroke=\x22#3\
574F0\x22/>\x0a</svg>\x0a\
\
\x00\x00\x03b\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
8.5 5V2.02054C11\
.4149 2.26101 13\
.739 4.5851 13.9\
795 7.5H11C10.72\
39 7.5 10.5 7.72\
386 10.5 8C10.5 \
8.27614 10.7239 \
8.5 11 8.5H13.97\
95C13.739 11.414\
9 11.4149 13.739\
 8.5 13.9795V11C\
8.5 10.7239 8.27\
614 10.5 8 10.5C\
7.72386 10.5 7.5\
 10.7239 7.5 11V\
13.9795C4.5851 1\
3.739 2.26101 11\
.4149 2.02054 8.\
5H5C5.27614 8.5 \
5.5 8.27614 5.5 \
8C5.5 7.72386 5.\
27614 7.5 5 7.5H\
2.02054C2.26101 \
4.5851 4.5851 2.\
26101 7.5 2.0205\
4V5C7.5 5.27614 \
7.72386 5.5 8 5.\
5C8.27614 5.5 8.\
5 5.27614 8.5 5Z\
M1 8C1 4.13401 4\
.13401 1 8 1C11.\
866 1 15 4.13401\
 15 8C15 11.866 \
11.866 15 8 15C4\
.13401 15 1 11.8\
66 1 8Z\x22 fill=\x22#\
6C707E\x22/>\x0a</svg>\
\x0a\
\x00\x00\x00\xec\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 vi\
ewBox=\x220 0 16 16\
\x22>\x0a  <path fill=\
\x22#9AA7B0\x22 fill-o\
pacity=\x22.8\x22 fill\
-rule=\x22evenodd\x22 \
d=\x22M7,6 L7,3 L3,\
3 L3,13 L5,13 L1\
3,13 L13,6 L7,6 \
Z M2,2 L14,2 L14\
,14 L2,14 L2,2 Z\
\x22/>\x0a</svg>\x0a\
\x00\x00\x01e\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M5.5 3V5.\
5H10.5V3M4.5 13V\
9.5H11.5V13M2.5 \
13.5V2.5H11.5L13\
.5 4.5V13.5H2.5Z\
\x22 stroke=\x22#6C707\
E\x22 stroke-linejo\
in=\x22round\x22/>\x0a</s\
vg>\x0a\
\x00\x00\x02m\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M8.93527 \
10.1424L7.63107 \
14.4897C4.33497 \
14.3053 1.69472 \
11.665 1.51029 8\
.36893L5.85762 7\
.06473L8.93527 1\
0.1424Z\x22 stroke=\
\x22#6C707E\x22/>\x0a<pat\
h d=\x22M14.5 1.5L1\
0 6\x22 stroke=\x22#6C\
707E\x22 stroke-lin\
ecap=\x22round\x22/>\x0a<\
path d=\x22M6.85742\
 6.35742L6.96289\
 6.25195C7.73307\
 5.48178 8.98178\
 5.48178 9.75195\
 6.25195V6.25195\
C10.5221 7.02213\
 10.5221 8.27084\
 9.75195 9.04102\
L9.64648 9.14648\
\x22 stroke=\x22#6C707\
E\x22/>\x0a</svg>\x0a\
\x00\x00\x02N\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2228\x22 he\
ight=\x2228\x22 viewBo\
x=\x220 0 28 28\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<c\
ircle cx=\x2214\x22 cy\
=\x2214\x22 r=\x2212\x22 fil\
l=\x22#E55765\x22/>\x0a<p\
ath d=\x22M15 8C15 \
7.44772 14.5523 \
7 14 7C13.4477 7\
 13 7.44771 13 8\
L13 14C13 14.552\
3 13.4477 15 14 \
15C14.5523 15 15\
 14.5523 15 14L1\
5 8Z\x22 fill=\x22whit\
e\x22/>\x0a<path d=\x22M1\
4 21C14.8284 21 \
15.5 20.3284 15.\
5 19.5C15.5 18.6\
716 14.8284 18 1\
4 18C13.1716 18 \
12.5 18.6716 12.\
5 19.5C12.5 20.3\
284 13.1716 21 1\
4 21Z\x22 fill=\x22whi\
te\x22/>\x0a</svg>\x0a\
\x00\x00\x01\xc3\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<c\
ircle cx=\x223\x22 cy=\
\x228\x22 r=\x221\x22 transf\
orm=\x22rotate(-90 \
3 8)\x22 fill=\x22#6C7\
07E\x22/>\x0a<circle c\
x=\x228\x22 cy=\x228\x22 r=\x22\
1\x22 transform=\x22ro\
tate(-90 8 8)\x22 f\
ill=\x22#6C707E\x22/>\x0a\
<circle cx=\x2213\x22 \
cy=\x228\x22 r=\x221\x22 tra\
nsform=\x22rotate(-\
90 13 8)\x22 fill=\x22\
#6C707E\x22/>\x0a</svg\
>\x0a\
\x00\x00\x04\xf9\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
12.157 7.20214C1\
2.4154 6.99461 1\
2.4566 6.61695 1\
2.249 6.35861C12\
.0415 6.10028 11\
.6638 6.0591 11.\
4055 6.26663L8.9\
2772 8.25717C8.6\
568 8.09391 8.33\
937 8 8.00001 8C\
7.0059 8 6.20001\
 8.80589 6.20001\
 9.8C6.20001 10.\
7941 7.0059 11.6\
 8.00001 11.6C8.\
99412 11.6 9.800\
01 10.7941 9.800\
01 9.8C9.80001 9\
.58321 9.76169 9\
.37538 9.69144 9\
.18289L12.157 7.\
20214ZM8.80001 9\
.8C8.80001 10.24\
18 8.44184 10.6 \
8.00001 10.6C7.5\
5818 10.6 7.2000\
1 10.2418 7.2000\
1 9.8C7.20001 9.\
35817 7.55818 9 \
8.00001 9C8.4418\
4 9 8.80001 9.35\
817 8.80001 9.8Z\
\x22 fill=\x22#6C707E\x22\
/>\x0a<path fill-ru\
le=\x22evenodd\x22 cli\
p-rule=\x22evenodd\x22\
 d=\x22M8 3.5C4.410\
15 3.5 1.5 6.410\
15 1.5 10C1.5 10\
.8909 1.76974 12\
.0874 2.13917 13\
H13.8608C14.2303\
 12.0874 14.5 10\
.8909 14.5 10C14\
.5 6.41015 11.58\
99 3.5 8 3.5ZM0.\
5 10C0.5 5.85786\
 3.85786 2.5 8 2\
.5C12.1421 2.5 1\
5.5 5.85786 15.5\
 10C15.5 11.1604\
 15.1228 12.6805\
 14.6336 13.7304\
C14.5554 13.8984\
 14.3841 14 14.1\
987 14H1.80126C1\
.61594 14 1.4446\
3 13.8984 1.3663\
7 13.7304C0.8772\
41 12.6805 0.5 1\
1.1604 0.5 10Z\x22 \
fill=\x22#6C707E\x22/>\
\x0a</svg>\x0a\
\x00\x00\x017\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M12.5 10.\
25L8 5.75L3.5 10\
.25\x22 stroke=\x22#6C\
707E\x22 stroke-lin\
ecap=\x22round\x22/>\x0a<\
/svg>\x0a\
\x00\x00\x01V\
<\
!-- Copyright 20\
00-2021 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license that ca\
n be found in th\
e LICENSE file. \
-->\x0a<svg width=\x22\
16\x22 height=\x2216\x22 \
viewBox=\x220 0 16 \
16\x22 fill=\x22none\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a<path d=\x22M9.\
5 11.5L6 8L9.5 4\
.5\x22 stroke=\x22#969\
AAB\x22 stroke-line\
cap=\x22round\x22/>\x0a</\
svg>\x0a\
\x00\x00\x034\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
11.4939 4.48784C\
11.3002 4.28007 \
10.9724 4.27548 \
10.7729 4.47775L\
8.00074 7.28849L\
5.22871 4.47788C\
5.02922 4.27561 \
4.70143 4.2802 4\
.50768 4.48797C4\
.32506 4.68382 4\
.32933 4.98882 4\
.51736 5.17947L7\
.29908 7.99991L4\
.51756 10.8201C4\
.32953 11.0108 4\
.32526 11.3158 4\
.50788 11.5116C4\
.70163 11.7194 5\
.02942 11.724 5.\
22892 11.5217L8.\
00074 8.71133L10\
.7727 11.5219C10\
.9722 11.7241 11\
.3 11.7196 11.49\
37 11.5118C11.67\
64 11.3159 11.67\
21 11.0109 11.48\
4 10.8203L8.7024\
 7.99991L11.4843\
 5.17934C11.6723\
 4.98869 11.6766\
 4.68368 11.4939\
 4.48784Z\x22 fill=\
\x22#A8ADBD\x22/>\x0a</sv\
g>\x0a\
\x00\x00\x03r\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
8.24408 6.65516C\
8.05415 6.43616 \
7.96859 6.14552 \
8.00959 5.85854L\
8.50238 2.40901L\
3.10978 8.99996H\
6.99954C7.28943 \
8.99996 7.56505 \
9.12576 7.75499 \
9.34476C7.94493 \
9.56376 8.03048 \
9.85441 7.98949 \
10.1414L7.4967 1\
3.5909L12.8893 6\
.99996H8.99954C8\
.70965 6.99996 8\
.43402 6.87416 8\
.24408 6.65516ZM\
9.74593 0.775195\
C9.81752 0.27406\
9 9.18453 -0.003\
92066 8.86398 0.\
387867L1.66768 9\
.18334C1.40057 9\
.50981 1.63285 9\
.99996 2.05466 9\
.99996H6.99954L6\
.25314 15.2247C6\
.18155 15.7259 6\
.81454 16.0038 7\
.1351 15.6121L14\
.3314 6.81658C14\
.5985 6.49012 14\
.3662 5.99996 13\
.9444 5.99996H8.\
99954L9.74593 0.\
775195Z\x22 fill=\x22#\
E66D17\x22/>\x0a</svg>\
\x0a\
\x00\x00\x01\x8f\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M2.00098 \
2H7.00195L7.0009\
8 7H2L2.00098 2Z\
M8.00293 2H13V7H\
8.00293V2ZM2 7.9\
9902L7 8V13.001L\
2 13V7.99902ZM8.\
00195 8H12.999L1\
2.998 13.001H8.0\
0195\x22 fill=\x22#6C7\
07E\x22/>\x0a</svg>\x0a\
\x00\x00\x01\xad\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M4.5 2.5L\
8 6L11.5 2.5\x22 st\
roke=\x22#6C707E\x22 s\
troke-linecap=\x22r\
ound\x22 stroke-lin\
ejoin=\x22round\x22/>\x0a\
<path d=\x22M4.5 13\
.5L8 10L11.5 13.\
5\x22 stroke=\x22#6C70\
7E\x22 stroke-linec\
ap=\x22round\x22 strok\
e-linejoin=\x22roun\
d\x22/>\x0a</svg>\x0a\
\x00\x00\x04\xea\
<\
!-- Copyright 20\
00-2024 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
12.5 9C12.7761 9\
 13 9.22386 13 9\
.5V12H15.5C15.77\
61 12 16 12.2239\
 16 12.5C16 12.7\
761 15.7761 13 1\
5.5 13H13V15.5C1\
3 15.7761 12.776\
1 16 12.5 16C12.\
2239 16 12 15.77\
61 12 15.5V13H9.\
5C9.22386 13 9 1\
2.7761 9 12.5C9 \
12.2239 9.22386 \
12 9.5 12H12V9.5\
C12 9.22386 12.2\
239 9 12.5 9Z\x22 f\
ill=\x22#3574F0\x22/>\x0a\
<path d=\x22M3 13V5\
.82843C3 5.29799\
 3.21071 4.78929\
 3.58579 4.41421\
L6.41421 1.58579\
C6.78929 1.21071\
 7.29799 1 7.828\
43 1H11C12.1046 \
1 13 1.89543 13 \
3V8H12.5C11.6716\
 8 11 8.67157 11\
 9.5V11H9.5C8.67\
157 11 8 11.6716\
 8 12.5V15H5C3.8\
9543 15 3 14.104\
6 3 13Z\x22 fill=\x22#\
EBECF0\x22/>\x0a<path \
fill-rule=\x22eveno\
dd\x22 clip-rule=\x22e\
venodd\x22 d=\x22M3 13\
V5.82843C3 5.297\
99 3.21071 4.789\
29 3.58579 4.414\
21L6.41421 1.585\
79C6.78929 1.210\
71 7.29799 1 7.8\
2843 1H11C12.104\
6 1 13 1.89543 1\
3 3V8H12.5C12.32\
47 8 12.1564 8.0\
3008 12 8.08535V\
3C12 2.44772 11.\
5523 2 11 2H8V4C\
8 5.10457 7.1045\
7 6 6 6H4V13C4 1\
3.5523 4.44772 1\
4 5 14H8V15H5C3.\
89543 15 3 14.10\
46 3 13ZM4.41421\
 5L7 2.41421V4C7\
 4.55228 6.55228\
 5 6 5H4.41421Z\x22\
 fill=\x22#6C707E\x22/\
>\x0a</svg>\x0a\
\x00\x00\x02\x00\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M11.5 10.\
5C12.485 10.5 13\
.4152 10.2623 14\
.2356 9.84137C13\
.4417 12.5343 10\
.9502 14.5 8 14.\
5C4.41015 14.5 1\
.5 11.5899 1.5 8\
C1.5 5.04985 3.4\
6572 2.55829 6.1\
5863 1.76439C5.7\
3766 2.58483 5.5\
 3.51498 5.5 4.5\
C5.5 7.81371 8.1\
8629 10.5 11.5 1\
0.5Z\x22 fill=\x22#EDF\
3FF\x22 stroke=\x22#35\
74F0\x22/>\x0a</svg>\x0a\
\x00\x00\x09\x03\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<g\
 clip-path=\x22url(\
#clip0_6654_5213\
0)\x22>\x0a<path d=\x22M8\
.5 1C8.5 0.72385\
8 8.27614 0.5 8 \
0.5C7.72386 0.5 \
7.5 0.723858 7.5\
 1V3.02469C7.664\
45 3.00836 7.831\
25 3 8 3C8.16875\
 3 8.33555 3.008\
36 8.5 3.02469V1\
Z\x22 fill=\x22#3574F0\
\x22/>\x0a<path d=\x22M3.\
40381 2.6967L4.8\
3563 4.12853C4.5\
7708 4.34011 4.3\
4011 4.57708 4.1\
2853 4.83563L2.6\
967 3.40381C2.50\
144 3.20854 2.50\
144 2.89196 2.69\
67 2.6967C2.8919\
6 2.50144 3.2085\
4 2.50144 3.4038\
1 2.6967Z\x22 fill=\
\x22#3574F0\x22/>\x0a<pat\
h d=\x22M3.02469 7.\
5H1C0.723858 7.5\
 0.5 7.72386 0.5\
 8C0.5 8.27614 0\
.723858 8.5 1 8.\
5H3.02469C3.0083\
6 8.33555 3 8.16\
875 3 8C3 7.8312\
5 3.00836 7.6644\
5 3.02469 7.5Z\x22 \
fill=\x22#3574F0\x22/>\
\x0a<path d=\x22M2.696\
7 12.5962L4.1285\
3 11.1644C4.3401\
1 11.4229 4.5770\
8 11.6599 4.8356\
3 11.8715L3.4038\
1 13.3033C3.2085\
4 13.4986 2.8919\
6 13.4986 2.6967\
 13.3033C2.50144\
 13.108 2.50144 \
12.7915 2.6967 1\
2.5962Z\x22 fill=\x22#\
3574F0\x22/>\x0a<path \
d=\x22M7.5 12.9753V\
15C7.5 15.2761 7\
.72386 15.5 8 15\
.5C8.27614 15.5 \
8.5 15.2761 8.5 \
15V12.9753C8.335\
55 12.9916 8.168\
75 13 8 13C7.831\
25 13 7.66445 12\
.9916 7.5 12.975\
3Z\x22 fill=\x22#3574F\
0\x22/>\x0a<path d=\x22M1\
2.5962 13.3033L1\
1.1644 11.8715C1\
1.4229 11.6599 1\
1.6599 11.4229 1\
1.8715 11.1644L1\
3.3033 12.5962C1\
3.4986 12.7915 1\
3.4986 13.108 13\
.3033 13.3033C13\
.108 13.4986 12.\
7915 13.4986 12.\
5962 13.3033Z\x22 f\
ill=\x22#3574F0\x22/>\x0a\
<path d=\x22M12.975\
3 8.5H15C15.2761\
 8.5 15.5 8.2761\
4 15.5 8C15.5 7.\
72386 15.2761 7.\
5 15 7.5H12.9753\
C12.9916 7.66445\
 13 7.83125 13 8\
C13 8.16875 12.9\
916 8.33555 12.9\
753 8.5Z\x22 fill=\x22\
#3574F0\x22/>\x0a<path\
 d=\x22M13.3033 3.4\
0381L11.8715 4.8\
3563C11.6599 4.5\
7708 11.4229 4.3\
4011 11.1644 4.1\
2853L12.5962 2.6\
967C12.7915 2.50\
144 13.108 2.501\
44 13.3033 2.696\
7C13.4986 2.8919\
6 13.4986 3.2085\
4 13.3033 3.4038\
1Z\x22 fill=\x22#3574F\
0\x22/>\x0a<path fill-\
rule=\x22evenodd\x22 c\
lip-rule=\x22evenod\
d\x22 d=\x22M12 8C12 1\
0.2091 10.2091 1\
2 8 12C5.79086 1\
2 4 10.2091 4 8C\
4 5.79086 5.7908\
6 4 8 4C10.2091 \
4 12 5.79086 12 \
8ZM11 8C11 9.656\
85 9.65685 11 8 \
11C6.34315 11 5 \
9.65685 5 8C5 6.\
34315 6.34315 5 \
8 5C9.65685 5 11\
 6.34315 11 8Z\x22 \
fill=\x22#3574F0\x22/>\
\x0a<circle cx=\x228\x22 \
cy=\x228\x22 r=\x223\x22 fil\
l=\x22#EDF3FF\x22/>\x0a</\
g>\x0a<defs>\x0a<clipP\
ath id=\x22clip0_66\
54_52130\x22>\x0a<rect\
 width=\x2216\x22 heig\
ht=\x2216\x22 fill=\x22wh\
ite\x22/>\x0a</clipPat\
h>\x0a</defs>\x0a</svg\
>\x0a\
\x00\x00\x02\xee\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2228\x22 he\
ight=\x2228\x22 viewBo\
x=\x220 0 28 28\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M12.72 2.\
74194C13.2889 1.\
75269 14.7111 1.\
75269 15.28 2.74\
194L26.7998 22.7\
742C27.3687 23.7\
634 26.6576 25 2\
5.5198 25H2.4802\
C1.34244 25 0.63\
1339 23.7634 1.2\
0022 22.7742L12.\
72 2.74194Z\x22 fil\
l=\x22#FFAF0F\x22/>\x0a<p\
ath d=\x22M15 9C15 \
8.44772 14.5523 \
8 14 8C13.4477 8\
 13 8.44771 13 9\
L13 15C13 15.552\
3 13.4477 16 14 \
16C14.5523 16 15\
 15.5523 15 15L1\
5 9Z\x22 fill=\x22whit\
e\x22/>\x0a<path d=\x22M1\
4 22C14.8284 22 \
15.5 21.3284 15.\
5 20.5C15.5 19.6\
716 14.8284 19 1\
4 19C13.1716 19 \
12.5 19.6716 12.\
5 20.5C12.5 21.3\
284 13.1716 22 1\
4 22Z\x22 fill=\x22whi\
te\x22/>\x0a</svg>\x0a\
\x00\x00\x01\x89\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2228\x22 he\
ight=\x2228\x22 viewBo\
x=\x220 0 28 28\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<c\
ircle cx=\x2214\x22 cy\
=\x2214\x22 r=\x2212\x22 fil\
l=\x22#55A76A\x22/>\x0a<p\
ath d=\x22M20 10.5L\
12.5 18L8.5 14\x22 \
stroke=\x22white\x22 s\
troke-width=\x222\x22 \
stroke-linecap=\x22\
round\x22 stroke-li\
nejoin=\x22round\x22/>\
\x0a</svg>\x0a\
\x00\x00\x04\xa1\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
7 4.5C7 5.42236 \
6.5005 6.22805 5\
.75725 6.66134L7\
.62202 7.45497L1\
3.3045 5.03983C1\
3.5586 4.93182 1\
3.8522 5.05029 1\
3.9602 5.30443C1\
4.0682 5.55857 1\
3.9498 5.85215 1\
3.6956 5.96017L8\
.89943 7.99862L1\
3.6956 10.0398C1\
3.9498 10.1478 1\
4.0682 10.4414 1\
3.9602 10.6956C1\
3.8522 10.9497 1\
3.5586 11.0682 1\
3.3045 10.9602L7\
.62176 8.54165L5\
.75271 9.33603C6\
.49847 9.76867 7\
 10.5758 7 11.5C\
7 12.8807 5.8807\
1 14 4.5 14C3.11\
929 14 2 12.8807\
 2 11.5C2 10.497\
5 2.59009 9.6327\
8 3.44189 9.2343\
L3.44092 9.232L6\
.34435 7.998L3.6\
5731 6.85442C2.6\
9121 6.50859 2 5\
.58501 2 4.5C2 3\
.11929 3.11929 2\
 4.5 2C5.88071 2\
 7 3.11929 7 4.5\
ZM6 4.5C6 5.3284\
3 5.32843 6 4.5 \
6C4.33031 6 4.16\
721 5.97182 4.01\
511 5.9199L3.814\
1 5.83435C3.3306\
4 5.58533 3 5.08\
128 3 4.5C3 3.67\
157 3.67157 3 4.\
5 3C5.32843 3 6 \
3.67157 6 4.5ZM6\
 11.5C6 12.3284 \
5.32843 13 4.5 1\
3C3.67157 13 3 1\
2.3284 3 11.5C3 \
10.6716 3.67157 \
10 4.5 10C5.3284\
3 10 6 10.6716 6\
 11.5Z\x22 fill=\x22#6\
C707E\x22/>\x0a</svg>\x0a\
\
\x00\x00\x04\xa3\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
12.5 9C12.7761 9\
 13 9.22386 13 9\
.5V12H15.5C15.77\
61 12 16 12.2239\
 16 12.5C16 12.7\
761 15.7761 13 1\
5.5 13H13V15.5C1\
3 15.7761 12.776\
1 16 12.5 16C12.\
2239 16 12 15.77\
61 12 15.5V13H9.\
5C9.22386 13 9 1\
2.7761 9 12.5C9 \
12.2239 9.22386 \
12 9.5 12H12V9.5\
C12 9.22386 12.2\
239 9 12.5 9Z\x22 f\
ill=\x22#3574F0\x22/>\x0a\
<path d=\x22M2.6333\
3 2C1.73127 2 1 \
2.83574 1 3.8666\
7V12.1333C1 13.1\
643 1.73127 14 2\
.63333 14H8V12.5\
C8 11.6716 8.671\
57 11 9.5 11H11V\
9.5C11 8.67157 1\
1.6716 8 12.5 8H\
15V6C15 4.89543 \
14.1046 4 13 4L8\
.46667 4L6.84336\
 2.30775C6.65477\
 2.11115 6.39413\
 2 6.1217 2H2.63\
333Z\x22 fill=\x22#EBE\
CF0\x22/>\x0a<path d=\x22\
M6.1217 3L2.6333\
3 3C2.40481 3 2 \
3.25841 2 3.8666\
7V12.1333C2 12.7\
416 2.40481 13 2\
.63333 13H8V14H2\
.63333C1.73127 1\
4 1 13.1643 1 12\
.1333V3.86667C1 \
2.83574 1.73127 \
2 2.63333 2H6.12\
17C6.39413 2 6.6\
5477 2.11115 6.8\
4336 2.30775L8.4\
6667 4L13 4C14.1\
046 4 15 4.89543\
 15 6V8H14V6C14 \
5.44771 13.5523 \
5 13 5H8.04022L6\
.1217 3Z\x22 fill=\x22\
#6C707E\x22/>\x0a</svg\
>\x0a\
\x00\x00\x09\xbe\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M1.62632 \
9.66782C1.44286 \
9.87421 1.46145 \
10.1902 1.66785 \
10.3737C1.87424 \
10.5572 2.19027 \
10.5386 2.37373 \
10.3322L1.62632 \
9.66782ZM14 10.5\
C14 10.7761 14.2\
239 11 14.5 11C1\
4.7761 11 15 10.\
7761 15 10.5H14Z\
M2 7.5C2 7.22386\
 1.77614 7 1.5 7\
C1.22386 7 1 7.2\
2386 1 7.5H2ZM1.\
5 10.5H1V11H1.5V\
10.5ZM4.5 11C4.7\
7614 11 5 10.776\
1 5 10.5C5 10.22\
39 4.77614 10 4.\
5 10V11ZM2.00003\
 10C2.37373 10.3\
322 2.37368 10.3\
322 2.37364 10.3\
323C2.37364 10.3\
323 2.37362 10.3\
323 2.37363 10.3\
323C2.37366 10.3\
323 2.37375 10.3\
322 2.37389 10.3\
32C2.37419 10.33\
17 2.37473 10.33\
11 2.3755 10.330\
2C2.37705 10.328\
5 2.37955 10.325\
7 2.38299 10.321\
9C2.38987 10.314\
2 2.40049 10.302\
5 2.41472 10.287\
C2.44318 10.2558\
 2.48606 10.2094\
 2.54224 10.15C2\
.65466 10.0309 2\
.82016 9.85969 3\
.03001 9.65366C3\
.45029 9.24102 4\
.04545 8.69176 4\
.74568 8.14375C6\
.17384 7.02606 7\
.93178 6 9.50003\
 6V5C7.56827 5 5\
.57621 6.22394 4\
.12937 7.35625C3\
.39211 7.93324 2\
.76851 8.50898 2\
.32942 8.94009C2\
.10958 9.15594 1\
.93524 9.33626 1\
.81523 9.46333C1\
.75521 9.52688 1\
.70873 9.57717 1\
.67689 9.61197C1\
.66096 9.62938 1\
.6487 9.64292 1.\
64023 9.65231C1.\
63599 9.65701 1.\
6327 9.66068 1.6\
3038 9.66327C1.6\
2922 9.66457 1.6\
283 9.6656 1.627\
62 9.66636C1.627\
28 9.66674 1.627\
 9.66705 1.62679\
 9.66729C1.62668\
 9.66742 1.62656\
 9.66755 1.62651\
 9.66761C1.62641\
 9.66772 1.62632\
 9.66782 2.00003\
 10ZM9.50003 6C1\
0.6625 6 11.5012\
 6.28919 12.1133\
 6.69727C12.7285\
 7.10745 13.1449\
 7.65792 13.4278\
 8.22361C13.7116\
 8.79125 13.856 \
9.36494 13.9287 \
9.80095C13.9648 \
10.0178 13.9827 \
10.1974 13.9915 \
10.3208C13.9959 \
10.3824 13.998 1\
0.4298 13.9991 1\
0.4605C13.9996 1\
0.4759 13.9998 1\
0.487 13.9999 10\
.4937C14 10.4971\
 14 10.4993 14 1\
0.5003C14 10.500\
9 14 10.5011 14 \
10.5011C14 10.50\
1 14 10.5009 14 \
10.5008C14 10.50\
07 14 10.5005 14\
 10.5004C14 10.5\
002 14 10.5 14.5\
 10.5C15 10.5 15\
 10.4997 15 10.4\
995C15 10.4993 1\
5 10.499 15 10.4\
988C15 10.4983 1\
5 10.4978 15 10.\
4971C15 10.4959 \
15 10.4943 15 10\
.4924C14.9999 10\
.4887 14.9999 10\
.4837 14.9998 10\
.4776C14.9996 10\
.4654 14.9992 10\
.4485 14.9985 10\
.4272C14.9971 10\
.3847 14.9943 10\
.3246 14.989 10.\
2495C14.9782 10.\
0995 14.9571 9.8\
8848 14.9151 9.6\
3655C14.8315 9.1\
3506 14.6634 8.4\
5875 14.3222 7.7\
7639C13.9801 7.0\
9208 13.459 6.39\
255 12.668 5.865\
23C11.8739 5.335\
81 10.8375 5 9.5\
0003 5V6ZM1 7.5V\
10.5H2V7.5H1ZM1.\
5 11H4.5V10H1.5V\
11Z\x22 fill=\x22#6C70\
7E\x22/>\x0a</svg>\x0a\
\x00\x00\x01\x1f\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x223\x22 y=\x228\x22 \
width=\x2210\x22 heigh\
t=\x221\x22 fill=\x22#A8A\
DBD\x22/>\x0a</svg>\x0a\
\x00\x00\x02\xa3\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M2.5 9V8C\
2.5 4.96243 4.96\
243 2.5 8 2.5C9.\
10679 2.5 10.137\
2 2.82692 11 3.3\
8947\x22 stroke=\x22#6\
C707E\x22 stroke-li\
necap=\x22round\x22/>\x0a\
<path d=\x22M5 12.6\
105C5.86278 13.1\
731 6.89321 13.5\
 8 13.5C11.0376 \
13.5 13.5 11.037\
6 13.5 8V7\x22 stro\
ke=\x22#6C707E\x22 str\
oke-linecap=\x22rou\
nd\x22/>\x0a<path d=\x22M\
0.49997 7.50027L\
2.5 9.5L4.49998 \
7.50023\x22 stroke=\
\x22#6C707E\x22 stroke\
-linecap=\x22round\x22\
/>\x0a<path d=\x22M11.\
5 8.49982L13.5 6\
.5L15.5 8.49982\x22\
 stroke=\x22#6C707E\
\x22 stroke-linecap\
=\x22round\x22/>\x0a</svg\
>\x0a\
\x00\x00\x016\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M12.5 5.7\
5L8 10.25L3.5 5.\
75\x22 stroke=\x22#6C7\
07E\x22 stroke-line\
cap=\x22round\x22/>\x0a</\
svg>\x0a\
\x00\x00\x02N\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2228\x22 he\
ight=\x2228\x22 viewBo\
x=\x220 0 28 28\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<c\
ircle cx=\x2214\x22 cy\
=\x2214\x22 r=\x2212\x22 fil\
l=\x22#4682FA\x22/>\x0a<p\
ath d=\x22M13 20C13\
 20.5523 13.4477\
 21 14 21C14.552\
3 21 15 20.5523 \
15 20L15 14C15 1\
3.4477 14.5523 1\
3 14 13C13.4477 \
13 13 13.4477 13\
 14L13 20Z\x22 fill\
=\x22white\x22/>\x0a<path\
 d=\x22M14 7C13.171\
6 7 12.5 7.67157\
 12.5 8.5C12.5 9\
.32843 13.1716 1\
0 14 10C14.8284 \
10 15.5 9.32843 \
15.5 8.5C15.5 7.\
67157 14.8284 7 \
14 7Z\x22 fill=\x22whi\
te\x22/>\x0a</svg>\x0a\
\x00\x00\x02\xb1\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2218\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 18 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M3.5 9V8C\
3.5 4.96243 5.96\
243 2.5 9 2.5C10\
.1068 2.5 11.137\
2 2.82692 12 3.3\
8947\x22 stroke=\x22#6\
C707E\x22 stroke-li\
necap=\x22round\x22/>\x0a\
<path d=\x22M6 12.6\
105C6.86278 13.1\
731 7.89321 13.5\
 9 13.5C12.0376 \
13.5 14.5 11.037\
6 14.5 8V7\x22 stro\
ke=\x22#6C707E\x22 str\
oke-linecap=\x22rou\
nd\x22/>\x0a<path d=\x22M\
1.37868 7.32133L\
3.5 9.44265L5.62\
132 7.32133\x22 str\
oke=\x22#6C707E\x22 st\
roke-linecap=\x22ro\
und\x22/>\x0a<path d=\x22\
M12.3787 8.67867\
L14.5 6.55735L16\
.6213 8.67867\x22 s\
troke=\x22#6C707E\x22 \
stroke-linecap=\x22\
round\x22/>\x0a</svg>\x0a\
\
\x00\x00\x01\xac\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
5 3H13V11H10V10H\
12V4H6V6H5V3Z\x22 f\
ill=\x22#A8ADBD\x22/>\x0a\
<path fill-rule=\
\x22evenodd\x22 clip-r\
ule=\x22evenodd\x22 d=\
\x22M11 5H3V13H11V5\
ZM10 6H4V12H10V6\
Z\x22 fill=\x22#A8ADBD\
\x22/>\x0a</svg>\x0a\
\x00\x00\x01a\
<\
!-- Copyright 20\
00-2024 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M2.5 8.25\
L6 11.75L13.5 4.\
25\x22 stroke=\x22#6C7\
07E\x22 stroke-widt\
h=\x221.5\x22 stroke-l\
inecap=\x22round\x22 s\
troke-linejoin=\x22\
round\x22/>\x0a</svg>\x0a\
\
\x00\x00\x03\xe2\
<\
!-- Copyright 20\
00-2024 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M4.12642 \
5.16655C4.32168 \
4.97129 4.63827 \
4.97129 4.83353 \
5.16655L7.16698 \
7.5L4.83353 9.83\
345C4.63827 10.0\
287 4.32168 10.0\
287 4.12642 9.83\
345C3.93116 9.63\
819 3.93116 9.32\
161 4.12642 9.12\
635L5.75277 7.5L\
4.12642 5.87365C\
3.93116 5.67839 \
3.93116 5.36181 \
4.12642 5.16655Z\
\x22 fill=\x22#6C707E\x22\
/>\x0a<path d=\x22M7.5\
 10C7.22386 10 7\
 10.2239 7 10.5C\
7 10.7761 7.2238\
6 11 7.5 11H10.5\
C10.7761 11 11 1\
0.7761 11 10.5C1\
1 10.2239 10.776\
1 10 10.5 10L7.5\
 10Z\x22 fill=\x22#6C7\
07E\x22/>\x0a<path fil\
l-rule=\x22evenodd\x22\
 clip-rule=\x22even\
odd\x22 d=\x22M3 2C1.8\
9543 2 1 2.89543\
 1 4V12C1 13.104\
6 1.89543 14 3 1\
4H13C14.1046 14 \
15 13.1046 15 12\
V4C15 2.89543 14\
.1046 2 13 2H3ZM\
13 3H3C2.44772 3\
 2 3.44772 2 4V1\
2C2 12.5523 2.44\
772 13 3 13H13C1\
3.5523 13 14 12.\
5523 14 12V4C14 \
3.44772 13.5523 \
3 13 3Z\x22 fill=\x22#\
6C707E\x22/>\x0a</svg>\
\x0a\
\x00\x00\x01.\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M6 11.5L9\
.5 8L6 4.5\x22 stro\
ke=\x22#818594\x22 str\
oke-linecap=\x22rou\
nd\x22/>\x0a</svg>\x0a\
\x00\x00\x02\xb6\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
12.3536 6.34645C\
12.5488 6.54171 \
12.5488 6.85829 \
12.3536 7.05355C\
12.1583 7.24882 \
11.8417 7.24882 \
11.6464 7.05355L\
8.5 3.9071L8.5 1\
3.5071C8.5 13.78\
32 8.27614 14.00\
71 8 14.0071C7.7\
2386 14.0071 7.5\
 13.7832 7.5 13.\
5071L7.5 3.90711\
L4.35355 7.05355\
C4.15829 7.24882\
 3.84171 7.24882\
 3.64645 7.05355\
C3.45118 6.85829\
 3.45118 6.54171\
 3.64645 6.34645\
L7.64645 2.34644\
L8 1.99289L8.353\
55 2.34644L12.35\
36 6.34645Z\x22 fil\
l=\x22#6C707E\x22/>\x0a</\
svg>\x0a\
\x00\x00\x015\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M4.5 9.75\
L8 6.25L11.5 9.7\
5\x22 stroke=\x22#8185\
94\x22 stroke-linec\
ap=\x22round\x22/>\x0a</s\
vg>\x0a\
\x00\x00\x02\xea\
<\
!-- Copyright 20\
00-2021 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license that ca\
n be found in th\
e LICENSE file. \
-->\x0a<svg xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22 widt\
h=\x2213\x22 height=\x221\
3\x22 viewBox=\x220 0 \
13 13\x22>\x0a  <g fil\
l=\x22#6E6E6E\x22 fill\
-rule=\x22evenodd\x22>\
\x0a    <rect width\
=\x222\x22 height=\x225.6\
57\x22 x=\x228.9\x22 y=\x226\
.869\x22 transform=\
\x22rotate(-45 9.9 \
9.697)\x22/>\x0a    <p\
ath d=\x22M5.25,10 \
C2.62664744,10 0\
.5,7.87335256 0.\
5,5.25 C0.5,2.62\
664744 2.6266474\
4,0.5 5.25,0.5 C\
7.87335256,0.5 1\
0,2.62664744 10,\
5.25 C10,7.87335\
256 7.87335256,1\
0 5.25,10 Z M5.2\
5,8.1 C6.8240115\
4,8.1 8.1,6.8240\
1154 8.1,5.25 C8\
.1,3.67598846 6.\
82401154,2.4 5.2\
5,2.4 C3.6759884\
6,2.4 2.4,3.6759\
8846 2.4,5.25 C2\
.4,6.82401154 3.\
67598846,8.1 5.2\
5,8.1 Z\x22/>\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x01\xcd\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 vi\
ewBox=\x220 0 16 16\
\x22>\x0a  <g fill=\x22#6\
E6E6E\x22 fill-rule\
=\x22evenodd\x22 trans\
form=\x22translate(\
2 3)\x22>\x0a    <rect\
 width=\x226\x22 heigh\
t=\x2210\x22 x=\x223\x22/>\x0a \
   <rect width=\x22\
2\x22 height=\x222\x22 x=\
\x2210\x22 y=\x221\x22/>\x0a   \
 <rect width=\x222\x22\
 height=\x222\x22 x=\x221\
0\x22 y=\x224\x22/>\x0a    <\
rect width=\x222\x22 h\
eight=\x222\x22 x=\x2210\x22\
 y=\x227\x22/>\x0a    <re\
ct width=\x222\x22 hei\
ght=\x222\x22 y=\x221\x22/>\x0a\
    <rect width=\
\x222\x22 height=\x222\x22 y\
=\x224\x22/>\x0a    <rect\
 width=\x222\x22 heigh\
t=\x222\x22 y=\x227\x22/>\x0a  \
</g>\x0a</svg>\x0a\
\x00\x00\x01\xf0\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M9 7L5.5 \
10.5\x22 stroke=\x22#6\
C707E\x22 stroke-li\
necap=\x22round\x22 st\
roke-linejoin=\x22r\
ound\x22/>\x0a<path d=\
\x22M8.5 10.5L5.5 1\
0.5L5.5 7.5\x22 str\
oke=\x22#6C707E\x22 st\
roke-linecap=\x22ro\
und\x22 stroke-line\
join=\x22round\x22/>\x0a<\
rect x=\x222.5\x22 y=\x22\
2.5\x22 width=\x2211\x22 \
height=\x2211\x22 rx=\x22\
1.5\x22 stroke=\x22#6C\
707E\x22/>\x0a</svg>\x0a\
\x00\x00\x02\x0f\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M2.9675 1\
4V12.35H4.6175V1\
4H2.9675Z\x22 fill=\
\x22#6C707E\x22/>\x0a<pat\
h d=\x22M12.905 4.8\
255L13.1855 5.85\
4L10.678 6.449L1\
2.4205 8.404L11.\
613 9.0925L9.972\
5 7.0185L8.3235 \
9.0925L7.516 8.4\
04L9.2585 6.449L\
6.751 5.854L7.03\
15 4.8255L9.505 \
5.565L9.437 3.1H\
10.4995L10.4315 \
5.565L12.905 4.8\
255Z\x22 fill=\x22#6C7\
07E\x22/>\x0a</svg>\x0a\
\x00\x00\x09\xf7\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M1 10.5C1\
 10.7761 1.22386\
 11 1.5 11C1.776\
14 11 2 10.7761 \
2 10.5H1ZM13.626\
3 10.3322C13.809\
8 10.5386 14.125\
8 10.5572 14.332\
2 10.3737C14.538\
6 10.1902 14.557\
2 9.87421 14.373\
7 9.66782L13.626\
3 10.3322ZM11.5 \
9.99999C11.2239 \
9.99999 11 10.22\
38 11 10.5C11 10\
.7761 11.2239 11\
 11.5 11V9.99999\
ZM14.5 10.5V11H1\
5V10.5H14.5ZM15 \
7.49999C15 7.223\
85 14.7761 6.999\
99 14.5 6.99999C\
14.2239 6.99999 \
14 7.22385 14 7.\
49999H15ZM1.5 10\
.5C2 10.5 2 10.5\
002 2 10.5004C2 \
10.5005 2 10.500\
7 2 10.5008C2 10\
.5009 2 10.501 2\
 10.5011C2 10.50\
11 2 10.5009 2 1\
0.5003C2.00001 1\
0.4993 2.00003 1\
0.4971 2.00009 1\
0.4937C2.0002 10\
.487 2.00043 10.\
4759 2.00094 10.\
4605C2.00197 10.\
4298 2.00409 10.\
3824 2.00849 10.\
3208C2.01731 10.\
1974 2.03519 10.\
0178 2.07132 9.8\
0095C2.14399 9.3\
6495 2.28839 8.7\
9125 2.57221 8.2\
2361C2.85506 7.6\
5792 3.27147 7.1\
0745 3.88673 6.6\
9728C4.49885 6.2\
8919 5.33749 6 6\
.5 6V5C5.16251 5\
 4.12615 5.33581\
 3.33203 5.86522\
C2.54103 6.39255\
 2.01994 7.09208\
 1.67779 7.77639\
C1.33661 8.45875\
 1.16851 9.13505\
 1.08493 9.63655\
C1.04294 9.88848\
 1.02175 10.0995\
 1.01104 10.2495\
C1.00567 10.3246\
 1.00292 10.3847\
 1.0015 10.4272C\
1.00079 10.4485 \
1.00041 10.4654 \
1.00022 10.4776C\
1.00012 10.4837 \
1.00006 10.4887 \
1.00003 10.4924C\
1.00002 10.4943 \
1.00001 10.4959 \
1.00001 10.4971C\
1 10.4978 1 10.4\
983 1 10.4988C1 \
10.499 1 10.4993\
 1 10.4995C1 10.\
4997 1 10.5 1.5 \
10.5ZM6.5 6C8.06\
824 6 9.82619 7.\
02606 11.2543 8.\
14375C11.9546 8.\
69176 12.5497 9.\
24102 12.97 9.65\
366C13.1799 9.85\
969 13.3454 10.0\
309 13.4578 10.1\
5C13.514 10.2094\
 13.5568 10.2558\
 13.5853 10.287C\
13.5995 10.3025 \
13.6102 10.3142 \
13.617 10.3219C1\
3.6205 10.3257 1\
3.623 10.3285 13\
.6245 10.3302C13\
.6253 10.3311 13\
.6258 10.3317 13\
.6261 10.332C13.\
6263 10.3322 13.\
6264 10.3323 13.\
6264 10.3323C13.\
6264 10.3323 13.\
6264 10.3323 13.\
6264 10.3323C13.\
6264 10.3322 13.\
6263 10.3322 14 \
10C14.3737 9.667\
82 14.3736 9.667\
72 14.3735 9.667\
61C14.3735 9.667\
55 14.3733 9.667\
42 14.3732 9.667\
29C14.373 9.6670\
5 14.3727 9.6667\
4 14.3724 9.6663\
6C14.3717 9.6656\
 14.3708 9.66457\
 14.3696 9.66327\
C14.3673 9.66068\
 14.364 9.65701 \
14.3598 9.65231C\
14.3513 9.64292 \
14.3391 9.62938 \
14.3231 9.61197C\
14.2913 9.57717 \
14.2448 9.52688 \
14.1848 9.46333C\
14.0648 9.33626 \
13.8904 9.15594 \
13.6706 8.94009C\
13.2315 8.50898 \
12.6079 7.93324 \
11.8707 7.35625C\
10.4238 6.22394 \
8.43176 5 6.5 5V\
6ZM11.5 11H14.5V\
9.99999H11.5V11Z\
M15 10.5V7.49999\
H14V10.5H15Z\x22 fi\
ll=\x22#6C707E\x22/>\x0a<\
/svg>\x0a\
\x00\x00\x05b\
<\
svg width=\x2216\x22 h\
eight=\x2216\x22 viewB\
ox=\x220 0 16 16\x22 f\
ill=\x22none\x22 xmlns\
=\x22http://www.w3.\
org/2000/svg\x22>\x0a<\
path fill-rule=\x22\
evenodd\x22 clip-ru\
le=\x22evenodd\x22 d=\x22\
M14 0.500015C14 \
0.297783 13.8782\
 0.115465 13.691\
4 0.0380748C13.5\
045 -0.0393156 1\
3.2895 0.0034622\
3 13.1465 0.1464\
61L11.1465 2.146\
46C11.0527 2.240\
23 11 2.36741 11\
 2.50001V4.29291\
L9.01602 6.27693\
C8.71825 6.10097\
 8.37092 6 8 6C6\
.89543 6 6 6.895\
43 6 8C6 9.10457\
 6.89543 10 8 10\
C9.10457 10 10 9\
.10457 10 8C10 7\
.62911 9.89904 7\
.2818 9.72311 6.\
98405L11.7071 5.\
00001H13.5C13.63\
26 5.00001 13.75\
98 4.94734 13.85\
36 4.85357L15.85\
36 2.85357C15.99\
66 2.71057 16.03\
94 2.49551 15.96\
2 2.30867C15.884\
6 2.12184 15.702\
3 2.00001 15.5 2\
.00001H14V0.5000\
15ZM13.2929 4.00\
001H12V2.70712L1\
3 1.70712V2.5000\
1C13 2.77616 13.\
2239 3.00001 13.\
5 3.00001H14.292\
9L13.2929 4.0000\
1ZM9 8C9 8.55228\
 8.55228 9 8 9C7\
.44772 9 7 8.552\
28 7 8C7 7.44772\
 7.44772 7 8 7C8\
.55228 7 9 7.447\
72 9 8Z\x22 fill=\x22#\
6C707E\x22/>\x0a<path \
d=\x22M10.0081 2.34\
43C9.38028 2.121\
36 8.70432 2 8 2\
C4.68629 2 2 4.6\
8629 2 8C2 11.31\
37 4.68629 14 8 \
14C11.3137 14 14\
 11.3137 14 8C14\
 7.29572 13.8787\
 6.61978 13.6557\
 5.99195C13.9963\
 5.95641 14.3163\
 5.80507 14.5607\
 5.5607L14.5626 \
5.55883C14.8454 \
6.31891 15 7.141\
4 15 8C15 11.866\
 11.866 15 8 15C\
4.13401 15 1 11.\
866 1 8C1 4.1340\
1 4.13401 1 8 1C\
8.85864 1 9.6811\
8 1.1546 10.4413\
 1.43748L10.4394\
 1.43938C10.195 \
1.68373 10.0437 \
2.00371 10.0081 \
2.3443Z\x22 fill=\x22#\
6C707E\x22/>\x0a</svg>\
\x0a\
\x00\x00\x01\xad\
<\
!-- Copyright 20\
00-2024 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M4.5 5.5L\
8 2L11.5 5.5\x22 st\
roke=\x22#6C707E\x22 s\
troke-linecap=\x22r\
ound\x22 stroke-lin\
ejoin=\x22round\x22/>\x0a\
<path d=\x22M4.5 10\
.5L8 14L11.5 10.\
5\x22 stroke=\x22#6C70\
7E\x22 stroke-linec\
ap=\x22round\x22 strok\
e-linejoin=\x22roun\
d\x22/>\x0a</svg>\x0a\
\x00\x00\x03\x02\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x222\x22 y=\x2212\x22\
 width=\x2212\x22 heig\
ht=\x221\x22 rx=\x220.5\x22 \
fill=\x22#6C707E\x22/>\
\x0a<rect x=\x226\x22 y=\x22\
6\x22 width=\x228\x22 hei\
ght=\x221\x22 rx=\x220.5\x22\
 fill=\x22#6C707E\x22/\
>\x0a<rect x=\x226\x22 y=\
\x229\x22 width=\x228\x22 he\
ight=\x221\x22 rx=\x220.5\
\x22 fill=\x22#6C707E\x22\
/>\x0a<rect x=\x222\x22 y\
=\x223\x22 width=\x2212\x22 \
height=\x221\x22 rx=\x220\
.5\x22 fill=\x22#6C707\
E\x22/>\x0a<path d=\x22M2\
.8 6.1C2.64849 5\
.98637 2.44579 5\
.96809 2.27639 6\
.05279C2.107 6.1\
3749 2 6.31062 2\
 6.5V9.5C2 9.689\
39 2.107 9.86252\
 2.27639 9.94722\
C2.44579 10.0319\
 2.64849 10.0136\
 2.8 9.9L4.8 8.4\
C4.9259 8.30558 \
5 8.15738 5 8C5 \
7.84262 4.9259 7\
.69443 4.8 7.6L2\
.8 6.1Z\x22 fill=\x22#\
4682FA\x22/>\x0a</svg>\
\x0a\
\x00\x00\x01\x1f\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x224\x22 y=\x2212\x22\
 width=\x228\x22 heigh\
t=\x221\x22 fill=\x22#A8A\
DBD\x22/>\x0a</svg>\x0a\
\x00\x00\x0bb\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
3.22655 4.36961C\
2.92233 4.76924 \
2.66735 5.20781 \
2.47037 5.67626L\
3.30992 7.0943C3\
.6406 7.65283 3.\
6406 8.34718 3.3\
0992 8.9057L2.47\
037 10.3237C2.66\
736 10.7922 2.92\
233 11.2308 3.22\
656 11.6304L4.87\
261 11.6124C5.52\
165 11.6053 6.12\
297 11.9524 6.44\
133 12.5181L7.24\
899 13.953C7.495\
93 13.984 7.7479\
2 14 8.00408 14C\
8.2602 14 8.5121\
4 13.984 8.75904\
 13.9531L9.56671\
 12.5181C9.88507\
 11.9524 10.4864\
 11.6053 11.1354\
 11.6124L12.7816\
 11.6304C13.0858\
 11.2308 13.3408\
 10.7923 13.5377\
 10.3239L12.6981\
 8.9057C12.3674 \
8.34718 12.3674 \
7.65283 12.6981 \
7.0943L13.5377 5\
.67613C13.3408 5\
.20773 13.0858 4\
.76921 12.7816 4\
.36961L11.1354 4\
.38764C10.4864 4\
.39475 9.88507 4\
.04758 9.56671 3\
.48194L8.75904 2\
.04693C8.51214 2\
.01599 8.2602 2 \
8.00408 2C7.7479\
2 2 7.49594 2.01\
6 7.24899 2.0469\
5L6.44133 3.4819\
4C6.12297 4.0475\
8 5.52165 4.3947\
5 4.87261 4.3876\
4L3.22655 4.3696\
1ZM10.655 8.0000\
1C10.655 9.46412\
 9.46811 10.651 \
8.004 10.651C6.5\
399 10.651 5.353\
 9.46412 5.353 8\
.00001C5.353 6.5\
3591 6.5399 5.34\
902 8.004 5.3490\
2C9.46811 5.3490\
2 10.655 6.53591\
 10.655 8.00001Z\
M4.88356 3.3877C\
5.16752 3.39081 \
5.4306 3.23892 5\
.56988 2.99146L6\
.43817 1.44875C6\
.54914 1.25159 6\
.7401 1.1101 6.9\
6387 1.07676C7.3\
0327 1.0262 7.65\
062 1 8.00408 1C\
8.3575 1 8.7048 \
1.02619 9.04414 \
1.07674C9.26792 \
1.11007 9.45889 \
1.25157 9.56986 \
1.44873L10.4382 \
2.99146C10.5774 \
3.23892 10.8405 \
3.39081 11.1245 \
3.3877L12.8938 3\
.36832C13.1196 3\
.36585 13.3372 3\
.46012 13.4781 3\
.63661C13.9099 4\
.17766 14.2632 4\
.78416 14.5207 5\
.43884C14.6034 5\
.6491 14.5763 5.\
88489 14.4612 6.\
07931L13.5586 7.\
60376C13.4139 7.\
84811 13.4139 8.\
15189 13.5586 8.\
39625L14.4612 9.\
92069C14.5763 10\
.1151 14.6034 10\
.3509 14.5207 10\
.5612C14.2632 11\
.2158 13.9099 11\
.8223 13.4781 12\
.3634C13.3372 12\
.5399 13.1196 12\
.6342 12.8938 12\
.6317L11.1245 12\
.6123C10.8405 12\
.6092 10.5774 12\
.7611 10.4382 13\
.0085L9.56986 14\
.5513C9.45889 14\
.7484 9.26792 14\
.8899 9.04414 14\
.9233C8.7048 14.\
9738 8.3575 15 8\
.00408 15C7.6506\
2 15 7.30327 14.\
9738 6.96387 14.\
9232C6.7401 14.8\
899 6.54914 14.7\
484 6.43817 14.5\
512L5.56988 13.0\
085C5.4306 12.76\
11 5.16752 12.60\
92 4.88356 12.61\
23L3.1144 12.631\
7C2.8886 12.6342\
 2.67096 12.5399\
 2.5301 12.3634C\
2.09822 11.8223 \
1.74489 11.2158 \
1.48738 10.561C1\
.40469 10.3508 1\
.43184 10.115 1.\
54695 9.92057L2.\
44942 8.39625C2.\
5941 8.15189 2.5\
941 7.84811 2.44\
942 7.60376L1.54\
695 6.07944C1.43\
184 5.88502 1.40\
469 5.64924 1.48\
738 5.43898C1.74\
489 4.78425 2.09\
822 4.1777 2.530\
09 3.63661C2.670\
96 3.46012 2.888\
6 3.36585 3.1144\
 3.36832L4.88356\
 3.3877ZM9.655 8\
.00001C9.655 8.9\
1183 8.91582 9.6\
5101 8.004 9.651\
01C7.09218 9.651\
01 6.353 8.91183\
 6.353 8.00001C6\
.353 7.08819 7.0\
9218 6.34902 8.0\
04 6.34902C8.915\
82 6.34902 9.655\
 7.08819 9.655 8\
.00001Z\x22 fill=\x22#\
6C707E\x22/>\x0a</svg>\
\x0a\
\x00\x00\x02\x9d\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
12.3536 9.65355C\
12.5488 9.45829 \
12.5488 9.14171 \
12.3536 8.94645C\
12.1583 8.75118 \
11.8417 8.75118 \
11.6464 8.94645L\
8.5 12.0929L8.5 \
2.5C8.5 2.22386 \
8.27614 2 8 2C7.\
72386 2 7.5 2.22\
386 7.5 2.5L7.5 \
12.0929L4.35355 \
8.94645C4.15829 \
8.75118 3.84171 \
8.75118 3.64645 \
8.94645C3.45118 \
9.14171 3.45118 \
9.45829 3.64645 \
9.65355L7.64645 \
13.6536L8 14.007\
1L8.35355 13.653\
6L12.3536 9.6535\
5Z\x22 fill=\x22#6C707\
E\x22/>\x0a</svg>\x0a\
\x00\x00\x01\xc8\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x223.75781\x22 \
y=\x223.05029\x22 widt\
h=\x2213\x22 height=\x221\
\x22 transform=\x22rot\
ate(45 3.75781 3\
.05029)\x22 fill=\x22#\
A8ADBD\x22/>\x0a<rect \
width=\x2213\x22 heigh\
t=\x221\x22 transform=\
\x22matrix(-0.70710\
7 0.707107 0.707\
107 0.707107 12.\
2432 3.05029)\x22 f\
ill=\x22#A8ADBD\x22/>\x0a\
</svg>\x0a\
\x00\x00\x05\x00\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M5.5 6C5.\
22386 6 5 6.2238\
6 5 6.5C5 6.7761\
4 5.22386 7 5.5 \
7H10.5C10.7761 7\
 11 6.77614 11 6\
.5C11 6.22386 10\
.7761 6 10.5 6H5\
.5Z\x22 fill=\x22#6C70\
7E\x22/>\x0a<path d=\x22M\
5 8.5C5 8.22386 \
5.22386 8 5.5 8H\
10.5C10.7761 8 1\
1 8.22386 11 8.5\
C11 8.77614 10.7\
761 9 10.5 9H5.5\
C5.22386 9 5 8.7\
7614 5 8.5Z\x22 fil\
l=\x22#6C707E\x22/>\x0a<p\
ath d=\x22M5.5 10C5\
.22386 10 5 10.2\
239 5 10.5C5 10.\
7761 5.22386 11 \
5.5 11H10.5C10.7\
761 11 11 10.776\
1 11 10.5C11 10.\
2239 10.7761 10 \
10.5 10H5.5Z\x22 fi\
ll=\x22#6C707E\x22/>\x0a<\
path fill-rule=\x22\
evenodd\x22 clip-ru\
le=\x22evenodd\x22 d=\x22\
M12 2H10.9146C10\
.7087 1.4174 10.\
1531 1 9.5 1H6.5\
C5.84689 1 5.291\
27 1.4174 5.0853\
5 2H4C2.89543 2 \
2 2.89543 2 4V13\
C2 14.1046 2.895\
43 15 4 15H12C13\
.1046 15 14 14.1\
046 14 13V4C14 2\
.89543 13.1046 2\
 12 2ZM4 3H5.085\
35C5.29127 3.582\
6 5.84689 4 6.5 \
4H9.5C10.1531 4 \
10.7087 3.5826 1\
0.9146 3H12C12.5\
523 3 13 3.44772\
 13 4V13C13 13.5\
523 12.5523 14 1\
2 14H4C3.44772 1\
4 3 13.5523 3 13\
V4C3 3.44772 3.4\
4772 3 4 3ZM6.5 \
2C6.22386 2 6 2.\
22386 6 2.5C6 2.\
77614 6.22386 3 \
6.5 3H9.5C9.7761\
4 3 10 2.77614 1\
0 2.5C10 2.22386\
 9.77614 2 9.5 2\
H6.5Z\x22 fill=\x22#6C\
707E\x22/>\x0a</svg>\x0a\
\x00\x00\x02G\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
4 3H12C12.5523 3\
 13 3.44772 13 4\
V7.5L3 7.5V4C3 3\
.44772 3.44772 3\
 4 3ZM2 8.5V7.5V\
4C2 2.89543 2.89\
543 2 4 2H12C13.\
1046 2 14 2.8954\
3 14 4V7.5V8.5V1\
2C14 13.1046 13.\
1046 14 12 14H4C\
2.89543 14 2 13.\
1046 2 12V8.5ZM1\
3 8.5V12C13 12.5\
523 12.5523 13 1\
2 13H4C3.44772 1\
3 3 12.5523 3 12\
V8.5L13 8.5Z\x22 fi\
ll=\x22#6C707E\x22/>\x0a<\
/svg>\x0a\
\x00\x00\x05Z\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x222.5\x22 y=\x222\
.5\x22 width=\x2211\x22 h\
eight=\x2211\x22 rx=\x221\
.5\x22 fill=\x22#EBECF\
0\x22 stroke=\x22#6C70\
7E\x22/>\x0a<path d=\x22M\
7.32546 9.03C7.3\
2546 8.80334 7.3\
638 8.605 7.4404\
6 8.435C7.52046 \
8.26167 7.61546 \
8.115 7.72546 7.\
995C7.8388 7.871\
67 7.98546 7.731\
67 8.16546 7.575\
C8.32546 7.435 8\
.45046 7.31834 8\
.54046 7.225C8.6\
338 7.12834 8.71\
046 7.01667 8.77\
046 6.89C8.8338 \
6.76334 8.86546 \
6.62167 8.86546 \
6.465C8.86546 6.\
215 8.7888 6.011\
67 8.63546 5.855\
C8.48213 5.695 8\
.2788 5.615 8.02\
546 5.615C7.7454\
6 5.615 7.52046 \
5.705 7.35046 5.\
885C7.1838 6.065\
 7.10213 6.3 7.1\
0546 6.59H5.7254\
6C5.72546 6.13 5\
.8188 5.735 6.00\
546 5.405C6.1921\
3 5.07167 6.4588\
 4.81834 6.80546\
 4.645C7.15546 4\
.46834 7.56713 4\
.38 8.04046 4.38\
C8.49713 4.38 8.\
8938 4.46167 9.2\
3046 4.625C9.567\
13 4.78834 9.825\
46 5.02 10.0055 \
5.32C10.1855 5.6\
1667 10.2738 5.9\
6667 10.2705 6.3\
7C10.2705 6.6733\
4 10.2221 6.935 \
10.1255 7.155C10\
.0288 7.375 9.91\
38 7.555 9.78046\
 7.695C9.64713 7\
.835 9.47213 7.9\
9334 9.25546 8.1\
7C9.10546 8.29 8\
.98713 8.39 8.90\
046 8.47001C8.81\
713 8.55 8.74713\
 8.64167 8.69046\
 8.74501C8.63713\
 8.84501 8.61046\
 8.95667 8.61046\
 9.08V9.255H7.32\
546V9.03ZM8.7404\
6 11.5H7.24046V1\
0H8.74046V11.5Z\x22\
 fill=\x22#6C707E\x22/\
>\x0a</svg>\x0a\
\x00\x00\x03\x9c\
<\
!-- Copyright 20\
00-2024 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
11 1H7.91421C7.5\
1639 1 7.13486 1\
.15803 6.85355 1\
.43934L3.43934 4\
.85355C3.15804 5\
.13486 3 5.51639\
 3 5.91421V13C3 \
14.1046 3.89543 \
15 5 15H11C12.10\
46 15 13 14.1046\
 13 13V3C13 1.89\
543 12.1046 1 11\
 1ZM4 13C4 13.55\
23 4.44772 14 5 \
14H11C11.5523 14\
 12 13.5523 12 1\
3V3C12 2.44772 1\
1.5523 2 11 2H8V\
4.5C8 5.32843 7.\
32843 6 6.5 6H4V\
13ZM4.70711 5L7 \
2.70711V4.5C7 4.\
77614 6.77614 5 \
6.5 5H4.70711Z\x22 \
fill=\x22#6C707E\x22/>\
\x0a<path d=\x22M5 14C\
4.44772 14 4 13.\
5523 4 13V6H6.5C\
7.32843 6 8 5.32\
843 8 4.5V2H11C1\
1.5523 2 12 2.44\
772 12 3V13C12 1\
3.5523 11.5523 1\
4 11 14H5Z\x22 fill\
=\x22#EBECF0\x22/>\x0a<pa\
th d=\x22M7 2.70711\
L4.70711 5H6.5C6\
.77614 5 7 4.776\
14 7 4.5V2.70711\
Z\x22 fill=\x22#EBECF0\
\x22/>\x0a</svg>\x0a\
\x00\x00\x03\xbc\
<\
!-- Copyright 20\
00-2024 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M10.164 1\
0.8717C9.30216 1\
1.5769 8.20049 1\
2 7 12C6.59443 1\
2 6.20013 11.951\
7 5.82255 11.860\
6L5.36279 10.650\
7C5.86252 10.875\
1 6.41668 11 7 1\
1C9.20914 11 11 \
9.20914 11 7C11 \
4.79086 9.20914 \
3 7 3C4.79086 3 \
3 4.79086 3 7C3 \
7.3453 3.04375 7\
.68038 3.12602 8\
H2.10002C2.03443\
 7.67689 2 7.342\
47 2 7C2 4.23858\
 4.23858 2 7 2C9\
.76142 2 12 4.23\
858 12 7C12 8.20\
078 11.5767 9.30\
27 10.8712 10.16\
47L13.8526 13.14\
24C14.0479 13.33\
75 14.0481 13.65\
41 13.853 13.849\
5C13.6578 14.044\
9 13.3413 14.045\
 13.1459 13.8499\
L10.164 10.8717Z\
\x22 fill=\x22#6C707E\x22\
/>\x0a<path fill-ru\
le=\x22evenodd\x22 cli\
p-rule=\x22evenodd\x22\
 d=\x22M3.665 9H2.5\
7L0 16H1.075L1.6\
7 14.22H4.635L5.\
275 16H6.325L3.6\
65 9ZM3.225 10.3\
3L4.335 13.385H1\
.95L3 10.33L3.11\
 9.9L3.225 10.33\
Z\x22 fill=\x22#6C707E\
\x22/>\x0a</svg>\x0a\
\x00\x00\x02A\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
8.5 3H12C12.5523\
 3 13 3.44772 13\
 4V12C13 12.5523\
 12.5523 13 12 1\
3H8.5V3ZM7.5 2H8\
.5H12C13.1046 2 \
14 2.89543 14 4V\
12C14 13.1046 13\
.1046 14 12 14H8\
.5H7.5H4C2.89543\
 14 2 13.1046 2 \
12V4C2 2.89543 2\
.89543 2 4 2H7.5\
ZM7.5 13H4C3.447\
72 13 3 12.5523 \
3 12V4C3 3.44772\
 3.44772 3 4 3H7\
.5V13Z\x22 fill=\x22#6\
C707E\x22/>\x0a</svg>\x0a\
\
\x00\x00\x08=\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2228\x22 he\
ight=\x2228\x22 viewBo\
x=\x220 0 28 28\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<c\
ircle cx=\x2214\x22 cy\
=\x2214\x22 r=\x2212\x22 fil\
l=\x22#4682FA\x22/>\x0a<p\
ath d=\x22M13.9366 \
21.004C13.5872 2\
1.004 13.2868 20\
.8805 13.0353 20\
.6333C12.7839 20\
.3819 12.6582 20\
.0793 12.6582 19\
.7256C12.6582 19\
.3762 12.7839 19\
.0779 13.0353 18\
.8307C13.2868 18\
.5793 13.5872 18\
.4536 13.9366 18\
.4536C14.2818 18\
.4536 14.5801 18\
.5793 14.8315 18\
.8307C15.0872 19\
.0779 15.215 19.\
3762 15.215 19.7\
256C15.215 19.96\
 15.1554 20.1752\
 15.036 20.3712C\
14.921 20.563 14\
.7676 20.7164 14\
.5758 20.8315C14\
.3841 20.9465 14\
.171 21.004 13.9\
366 21.004Z\x22 fil\
l=\x22white\x22/>\x0a<pat\
h d=\x22M13.8358 16\
.5C13.3589 16.5 \
12.9724 16.1134 \
12.9724 15.6366V\
15.6366C12.9809 \
14.8791 13.0597 \
14.6127 13.2089 \
14.1647C13.3623 \
13.7168 13.5796 \
13.3543 13.8609 \
13.0774C14.1421 \
12.8005 14.4809 \
12.548 14.8772 1\
2.3199C15.1329 1\
2.1652 15.363 11\
.9921 15.5676 11\
.8007C15.7721 11\
.6093 15.934 11.\
3894 16.0533 11.\
1409C16.1727 10.\
8925 16.2316 10.\
6123 16.2316 10.\
3109C16.2316 9.9\
4845 16.1421 9.6\
3487 15.9632 9.3\
7016C15.7842 9.1\
0545 15.5455 8.9\
0183 15.2472 8.7\
5929C14.9532 8.6\
1269 14.6251 8.5\
3938 14.2629 8.5\
3938C13.9347 8.5\
3938 13.6215 8.6\
0454 13.3232 8.7\
3486C13.0249 8.8\
6518 12.7778 9.0\
688 12.5818 9.34\
572C12.5422 9.40\
075 12.5061 9.45\
9 12.4733 9.5204\
8C12.2301 9.9768\
2 11.8418 10.402\
5 11.3246 10.402\
5V10.4025C10.765\
5 10.4025 10.299\
7 9.92801 10.465\
8 9.39414C10.562\
9 9.0824 10.7014\
 8.79952 10.8815\
 8.54549C11.2394\
 8.03644 11.7124\
 7.65159 12.3005\
 7.39095C12.8928\
 7.13032 13.547 \
7 14.2629 7C15.0\
47 7 15.733 7.14\
05 16.3211 7.421\
5C16.9092 7.6984\
2 17.3651 8.0873\
4 17.689 8.58825\
C18.0171 9.08509\
 18.1812 9.66541\
 18.1812 10.3292\
C18.1812 10.7853\
 18.1073 11.202 \
17.9582 11.5685C\
17.809 11.931 17\
.596 12.2548 17.\
319 12.5398C17.0\
462 12.8249 16.7\
181 13.0774 16.3\
346 13.2973C15.9\
724 13.5131 15.6\
783 13.7371 15.4\
525 13.9692C15.2\
309 14.2014 15.0\
68 14.4062 14.96\
58 14.7239C14.86\
35 15.0415 14.80\
9 15.1683 14.800\
5 15.6366V15.636\
6C14.8005 16.113\
4 14.4139 16.5 1\
3.9371 16.5H13.8\
358Z\x22 fill=\x22whit\
e\x22/>\x0a</svg>\x0a\
\x00\x00\x0aD\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M4.51619 \
13.0001C3.68538 \
13.0001 2.93338 \
12.7967 2.26021 \
12.3899C1.58704 \
11.9787 1.05873 \
11.4161 0.675276\
 10.702C0.291824\
 9.98794 0.10009\
8 9.1873 0.10009\
8 8.3001C0.10009\
8 7.4129 0.29182\
4 6.61225 0.6752\
76 5.89816C1.058\
73 5.18408 1.587\
04 4.62362 2.260\
21 4.21681C2.933\
38 3.80567 3.685\
38 3.6001 4.5161\
9 3.6001C5.20214\
 3.6001 5.84336 \
3.73642 6.43984 \
4.00908C7.03632 \
4.2774 7.52629 4\
.64743 7.90974 5\
.11916C8.29319 5\
.59089 8.52114 6\
.11455 8.59356 6\
.69015H7.31539C7\
.22592 6.3396 7.\
04271 6.01934 6.\
76578 5.72938C6.\
4931 5.43942 6.1\
5864 5.21221 5.7\
6241 5.04775C5.3\
6618 4.88329 4.9\
5077 4.80106 4.5\
1619 4.80106C3.9\
2823 4.80106 3.3\
9992 4.95037 2.9\
3125 5.24899C2.4\
6259 5.54761 2.0\
9405 5.96308 1.8\
2563 6.4954C1.56\
148 7.02772 1.42\
94 7.62929 1.429\
4 8.3001C1.4294 \
8.97091 1.56148 \
9.57247 1.82563 \
10.1048C2.09405 \
10.6371 2.46259 \
11.0526 2.93125 \
11.3512C3.39992 \
11.6498 3.92823 \
11.7991 4.51619 \
11.7991C4.95077 \
11.7991 5.36618 \
11.7169 5.76241 \
11.5524C6.15864 \
11.388 6.4931 11\
.1629 6.76578 10\
.8773C7.04271 10\
.5873 7.22592 10\
.2671 7.31539 9.\
91653H8.59356C8.\
52114 10.4921 8.\
29319 11.0158 7.\
90974 11.4875C7.\
52629 11.9549 7.\
03632 12.325 6.4\
3984 12.5976C5.8\
4336 12.8659 5.2\
0214 13.0001 4.5\
1619 13.0001Z\x22 f\
ill=\x22#6C707E\x22/>\x0a\
<path d=\x22M12.800\
5 13.0001C12.17 \
13.0001 11.6012 \
12.8486 11.0942 \
12.5457C10.5872 \
12.2427 10.1888 \
11.8273 9.89907 \
11.2993C9.60935 \
10.7669 9.46449 \
10.174 9.46449 9\
.52054C9.46449 8\
.86704 9.60935 8\
.27629 9.89907 7\
.7483C10.1888 7.\
21598 10.5872 6.\
79835 11.0942 6.\
4954C11.6012 6.1\
9245 12.17 6.040\
98 12.8005 6.040\
98C13.3331 6.040\
98 13.8167 6.134\
03 14.2513 6.320\
13C14.6901 6.506\
22 15.0501 6.776\
71 15.3313 7.131\
59C15.6168 7.486\
47 15.8064 7.908\
43 15.9001 8.397\
47H14.6475C14.56\
23 8.1378 14.425\
9 7.91709 14.238\
5 7.73532C14.055\
3 7.55355 13.838\
 7.41722 13.5866\
 7.32634C13.3395\
 7.23113 13.0775\
 7.18352 12.8005\
 7.18352C12.4128\
 7.18352 12.0634\
 7.28306 11.7524\
 7.48214C11.4414\
 7.68122 11.1985\
 7.9582 11.0239 \
8.31308C10.8534 \
8.66796 10.7682 \
9.07045 10.7682 \
9.52054C10.7682 \
9.9663 10.8534 1\
0.3666 11.0239 1\
0.7215C11.1985 1\
1.0764 11.4414 1\
1.3555 11.7524 1\
1.5589C12.0634 1\
1.758 12.4128 11\
.8576 12.8005 11\
.8576C13.0775 11\
.8576 13.3395 11\
.8121 13.5866 11\
.7212C13.838 11.\
626 14.0553 11.4\
875 14.2385 11.3\
058C14.4259 11.1\
24 14.5623 10.90\
33 14.6475 10.64\
36H15.9001C15.81\
06 11.1197 15.61\
89 11.5351 15.32\
49 11.89C15.0352\
 12.2449 14.6709\
 12.5197 14.2321\
 12.7145C13.7975\
 12.9049 13.3203\
 13.0001 12.8005\
 13.0001Z\x22 fill=\
\x22#6C707E\x22/>\x0a</sv\
g>\x0a\
\x00\x00\x02%\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M8.10584 \
4.34613L8.25344 \
4.5H8.46667H13C1\
3.8284 4.5 14.5 \
5.17157 14.5 6V1\
2.1333C14.5 12.9\
529 13.932 13.5 \
13.3667 13.5H2.6\
3333C2.06804 13.\
5 1.5 12.9529 1.\
5 12.1333V3.8666\
7C1.5 3.04707 2.\
06804 2.5 2.6333\
3 2.5H6.1217C6.2\
5792 2.5 6.38824\
 2.55557 6.48253\
 2.65387L8.10584\
 4.34613Z\x22 fill=\
\x22#EBECF0\x22 stroke\
=\x22#6C707E\x22/>\x0a</s\
vg>\x0a\
\x00\x00\x01$\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x223.5\x22 y=\x223\
.5\x22 width=\x229\x22 he\
ight=\x229\x22 stroke=\
\x22#A8ADBD\x22/>\x0a</sv\
g>\x0a\
\x00\x00\x01\xed\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x222\x22 y=\x2212\x22\
 width=\x228\x22 heigh\
t=\x221\x22 rx=\x220.5\x22 f\
ill=\x22#6C707E\x22/>\x0a\
<rect x=\x222\x22 y=\x226\
\x22 width=\x228\x22 heig\
ht=\x221\x22 rx=\x220.5\x22 \
fill=\x22#6C707E\x22/>\
\x0a<rect x=\x222\x22 y=\x22\
9\x22 width=\x2212\x22 he\
ight=\x221\x22 rx=\x220.5\
\x22 fill=\x22#6C707E\x22\
/>\x0a<rect x=\x222\x22 y\
=\x223\x22 width=\x2212\x22 \
height=\x221\x22 rx=\x220\
.5\x22 fill=\x22#6C707\
E\x22/>\x0a</svg>\x0a\
\x00\x00\x03o\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<c\
ircle opacity=\x220\
.1\x22 cx=\x228\x22 cy=\x228\
\x22 r=\x228\x22 fill=\x22#3\
13547\x22/>\x0a<path f\
ill-rule=\x22evenod\
d\x22 clip-rule=\x22ev\
enodd\x22 d=\x22M11.49\
39 4.48784C11.30\
02 4.28007 10.97\
24 4.27548 10.77\
29 4.47775L8.000\
74 7.28849L5.228\
71 4.47788C5.029\
22 4.27561 4.701\
43 4.2802 4.5076\
8 4.48797C4.3250\
6 4.68382 4.3293\
3 4.98882 4.5173\
6 5.17947L7.2990\
8 7.99991L4.5175\
6 10.8201C4.3295\
3 11.0108 4.3252\
6 11.3158 4.5078\
8 11.5116C4.7016\
3 11.7194 5.0294\
2 11.724 5.22892\
 11.5217L8.00074\
 8.71133L10.7727\
 11.5219C10.9722\
 11.7241 11.3 11\
.7196 11.4937 11\
.5118C11.6764 11\
.3159 11.6721 11\
.0109 11.484 10.\
8203L8.7024 7.99\
991L11.4843 5.17\
934C11.6723 4.98\
869 11.6766 4.68\
368 11.4939 4.48\
784Z\x22 fill=\x22#818\
594\x22/>\x0a</svg>\x0a\
\x00\x00\x01\x91\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M4.2695 1\
3L1.299 3.9H2.70\
3L5.043 11.2125L\
7.2725 3.9H8.611\
5L10.8735 11.212\
5L13.155 3.9H14.\
5135L11.543 13H1\
0.1585L7.9225 5.\
7785L5.6475 13H4\
.2695Z\x22 fill=\x22#6\
C707E\x22/>\x0a</svg>\x0a\
\
\x00\x00\x036\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x222.5\x22 y=\x223\
.5\x22 width=\x229\x22 he\
ight=\x2210\x22 rx=\x221.\
5\x22 stroke=\x22#6C70\
7E\x22/>\x0a<rect x=\x225\
\x22 y=\x226\x22 width=\x224\
\x22 height=\x221\x22 rx=\
\x220.5\x22 fill=\x22#6C7\
07E\x22/>\x0a<rect x=\x22\
5\x22 y=\x228\x22 width=\x22\
4\x22 height=\x221\x22 rx\
=\x220.5\x22 fill=\x22#6C\
707E\x22/>\x0a<rect x=\
\x225\x22 y=\x2210\x22 width\
=\x224\x22 height=\x221\x22 \
rx=\x220.5\x22 fill=\x22#\
6C707E\x22/>\x0a<path \
fill-rule=\x22eveno\
dd\x22 clip-rule=\x22e\
venodd\x22 d=\x22M11.0\
017 2H11.5998C12\
.373 2 12.9998 2\
.6268 12.9998 3.\
4V3.91081C13.001\
1 3.94038 13.001\
7 3.97011 13.001\
7 4V11.5482C13.6\
063 11.1124 13.9\
998 10.4021 13.9\
998 9.6V3.4C13.9\
998 2.07452 12.9\
253 1 11.5998 1H\
6.39978C5.59677 \
1 4.88587 1.3943\
7 4.4502 2H6.399\
78H11.0017Z\x22 fil\
l=\x22#6C707E\x22/>\x0a</\
svg>\x0a\
\x00\x00\x03\x1f\
<\
svg width=\x2216\x22 h\
eight=\x2216\x22 viewB\
ox=\x220 0 16 16\x22 f\
ill=\x22none\x22 xmlns\
=\x22http://www.w3.\
org/2000/svg\x22>\x0a<\
path fill-rule=\x22\
evenodd\x22 clip-ru\
le=\x22evenodd\x22 d=\x22\
M4 14C2.89543 14\
 2 13.1046 2 12L\
2 4C2 2.89543 2.\
89543 2 4 2L6.5 \
2C6.77614 2 7 2.\
22386 7 2.5C7 2.\
77614 6.77614 3 \
6.5 3L4 3C3.4477\
2 3 3 3.44772 3 \
4L3 12C3 12.5523\
 3.44772 13 4 13\
H12C12.5523 13 1\
3 12.5523 13 12V\
9.5C13 9.22386 1\
3.2239 9 13.5 9C\
13.7761 9 14 9.2\
2386 14 9.5V12C1\
4 13.1046 13.104\
6 14 12 14H4Z\x22 f\
ill=\x22#6C707E\x22/>\x0a\
<path fill-rule=\
\x22evenodd\x22 clip-r\
ule=\x22evenodd\x22 d=\
\x22M14 2V6.5C14 6.\
77614 13.7761 7 \
13.5 7C13.2239 7\
 13 6.77614 13 6\
.5V3.70711L8.853\
55 7.85355C8.658\
29 8.04882 8.341\
71 8.04882 8.146\
45 7.85355C7.951\
18 7.65829 7.951\
18 7.34171 8.146\
45 7.14645L12.29\
29 3L9.5 3C9.223\
86 3 9 2.77614 9\
 2.5C9 2.22386 9\
.22386 2 9.5 2L1\
4 2Z\x22 fill=\x22#6C7\
07E\x22/>\x0a</svg>\x0a\
\x00\x00\x04\xd3\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
6.48057 5.70711L\
6.26727 7.20016C\
6.19763 7.68767 \
5.90122 8.07205 \
5.53634 8.29289C\
4.78518 8.74751 \
4.39847 9.41436 \
4.19857 10H11.80\
15C11.6016 9.414\
34 11.2149 8.747\
46 10.4637 8.292\
84C10.0988 8.072\
01 9.80236 7.687\
62 9.73272 7.200\
09L9.51943 5.707\
11C9.39072 4.806\
11 10.0899 4 11 \
4V3L5 3V4C5.9101\
4 4 6.60928 4.80\
611 6.48057 5.70\
711ZM5.27732 7.0\
5873C5.25463 7.2\
176 5.15585 7.35\
428 5.01856 7.43\
737C3.84968 8.14\
481 3.35768 9.22\
759 3.15058 10.0\
138C3.0099 10.54\
78 3.44776 11 4.\
00005 11H12C12.5\
523 11 12.9902 1\
0.5478 12.8495 1\
0.0138C12.6424 9\
.22757 12.1504 8\
.14475 10.9814 7\
.43732C10.8442 7\
.35423 10.7454 7\
.21754 10.7227 7\
.05867L10.5094 5\
.56569C10.4667 5\
.26712 10.6984 5\
 11 5C11.5523 5 \
12 4.55228 12 4V\
3C12 2.44772 11.\
5523 2 11 2H5C4.\
44772 2 4 2.4477\
2 4 3V4C4 4.5522\
8 4.44772 5 5 5C\
5.3016 5 5.53327\
 5.26712 5.49062\
 5.56569L5.27732\
 7.05873Z\x22 fill=\
\x22#6C707E\x22/>\x0a<pat\
h d=\x22M7.5 11H8.5\
V14.5C8.5 14.776\
1 8.27614 15 8 1\
5V15C7.72386 15 \
7.5 14.7761 7.5 \
14.5V11Z\x22 fill=\x22\
#6C707E\x22/>\x0a</svg\
>\x0a\
\x00\x00\x015\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M11.5 6.2\
5L8 9.75L4.5 6.2\
5\x22 stroke=\x22#B4B8\
BF\x22 stroke-linec\
ap=\x22round\x22/>\x0a</s\
vg>\x0a\
\x00\x00\x04F\
<\
!-- Copyright 20\
00-2024 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
8.00001 1C11 1 1\
1 2 11 4L11 6.5C\
11 7.32843 10.32\
84 8 9.5 8H6.5C5\
.11929 8 4 9.119\
29 4 10.5V11C2 1\
1 1 11 1 7.99999\
C1 4.99999 2 4.9\
9998 4 4.99998L7\
.5 5C7.77614 5 8\
 4.77614 8 4.5C8\
 4.22386 7.77614\
 4 7.5 4H5.00001\
C5.00001 2 5.000\
01 1 8.00001 1ZM\
6.5 3C6.77614 3 \
7 2.77614 7 2.5C\
7 2.22386 6.7761\
4 2 6.5 2C6.2238\
6 2 6 2.22386 6 \
2.5C6 2.77614 6.\
22386 3 6.5 3Z\x22 \
fill=\x22#548AF7\x22/>\
\x0a<path fill-rule\
=\x22evenodd\x22 clip-\
rule=\x22evenodd\x22 d\
=\x22M12 5V6.5C12 7\
.88071 10.8807 9\
 9.5 9H6.5C5.671\
57 9 5 9.67157 5\
 10.5L5.00001 12\
C4.99946 14 5.00\
001 15 8.00001 1\
5C11 15 11 14 11\
 12L8.5 12C8.223\
86 12 8 11.7761 \
8 11.5C8 11.2239\
 8.22386 11 8.5 \
11L12 11C14 11.0\
005 15 11 15 7.9\
9999C15 5.00002 \
14 5.00001 12 5Z\
M9.5 14C9.77614 \
14 10 13.7761 10\
 13.5C10 13.2239\
 9.77614 13 9.5 \
13C9.22386 13 9 \
13.2239 9 13.5C9\
 13.7761 9.22386\
 14 9.5 14Z\x22 fil\
l=\x22#F2C55C\x22/>\x0a</\
svg>\x0a\
\x00\x00\x02\x0a\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M8.15132 \
4.35836L8.29689 \
4.5H8.5H13C13.82\
84 4.5 14.5 5.17\
157 14.5 6V12.13\
33C14.5 12.919 1\
3.9104 13.5 13.2\
5 13.5H2.75C2.08\
955 13.5 1.5 12.\
919 1.5 12.1333V\
3.86667C1.5 3.08\
099 2.08955 2.5 \
2.75 2.5H6.03823\
C6.16847 2.5 6.2\
9357 2.55082 6.3\
8691 2.64164L8.1\
5132 4.35836Z\x22 s\
troke=\x22#CED0D6\x22/\
>\x0a</svg>\x0a\
\x00\x00\x01\xa1\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M1.5 8C1.\
5 11.5899 4.4101\
5 14.5 8 14.5V1.\
5C4.41015 1.5 1.\
5 4.41015 1.5 8Z\
\x22 fill=\x22#25324D\x22\
/>\x0a<path d=\x22M8 2\
V14\x22 stroke=\x22#54\
8AF7\x22/>\x0a<circle \
cx=\x228\x22 cy=\x228\x22 r=\
\x226.5\x22 stroke=\x22#5\
48AF7\x22/>\x0a</svg>\x0a\
\
\x00\x00\x03b\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
8.5 5V2.02054C11\
.4149 2.26101 13\
.739 4.5851 13.9\
795 7.5H11C10.72\
39 7.5 10.5 7.72\
386 10.5 8C10.5 \
8.27614 10.7239 \
8.5 11 8.5H13.97\
95C13.739 11.414\
9 11.4149 13.739\
 8.5 13.9795V11C\
8.5 10.7239 8.27\
614 10.5 8 10.5C\
7.72386 10.5 7.5\
 10.7239 7.5 11V\
13.9795C4.5851 1\
3.739 2.26101 11\
.4149 2.02054 8.\
5H5C5.27614 8.5 \
5.5 8.27614 5.5 \
8C5.5 7.72386 5.\
27614 7.5 5 7.5H\
2.02054C2.26101 \
4.5851 4.5851 2.\
26101 7.5 2.0205\
4V5C7.5 5.27614 \
7.72386 5.5 8 5.\
5C8.27614 5.5 8.\
5 5.27614 8.5 5Z\
M1 8C1 4.13401 4\
.13401 1 8 1C11.\
866 1 15 4.13401\
 15 8C15 11.866 \
11.866 15 8 15C4\
.13401 15 1 11.8\
66 1 8Z\x22 fill=\x22#\
CED0D6\x22/>\x0a</svg>\
\x0a\
\x00\x00\x01e\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M5.5 3V5.\
5H10.5V3M4.5 13V\
9.5H11.5V13M2.5 \
13.5V2.5H11.5L13\
.5 4.5V13.5H2.5Z\
\x22 stroke=\x22#CED0D\
6\x22 stroke-linejo\
in=\x22round\x22/>\x0a</s\
vg>\x0a\
\x00\x00\x02m\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M8.93527 \
10.1424L7.63107 \
14.4897C4.33497 \
14.3053 1.69472 \
11.665 1.51029 8\
.36893L5.85762 7\
.06473L8.93527 1\
0.1424Z\x22 stroke=\
\x22#CED0D6\x22/>\x0a<pat\
h d=\x22M14.5 1.5L1\
0 6\x22 stroke=\x22#CE\
D0D6\x22 stroke-lin\
ecap=\x22round\x22/>\x0a<\
path d=\x22M6.85742\
 6.35742L6.96289\
 6.25195C7.73307\
 5.48178 8.98178\
 5.48178 9.75195\
 6.25195V6.25195\
C10.5221 7.02213\
 10.5221 8.27084\
 9.75195 9.04102\
L9.64648 9.14648\
\x22 stroke=\x22#CED0D\
6\x22/>\x0a</svg>\x0a\
\x00\x00\x02\xe2\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2228\x22 he\
ight=\x2228\x22 viewBo\
x=\x220 0 28 28\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<g\
 clip-path=\x22url(\
#clip0_3005_4035\
0)\x22>\x0a<circle cx=\
\x2214\x22 cy=\x2214\x22 r=\x22\
12\x22 fill=\x22#DB5C5\
C\x22/>\x0a<path d=\x22M1\
5 8C15 7.44772 1\
4.5523 7 14 7C13\
.4477 7 13 7.447\
71 13 8L13 14C13\
 14.5523 13.4477\
 15 14 15C14.552\
3 15 15 14.5523 \
15 14L15 8Z\x22 fil\
l=\x22white\x22/>\x0a<pat\
h d=\x22M14 21C14.8\
284 21 15.5 20.3\
284 15.5 19.5C15\
.5 18.6716 14.82\
84 18 14 18C13.1\
716 18 12.5 18.6\
716 12.5 19.5C12\
.5 20.3284 13.17\
16 21 14 21Z\x22 fi\
ll=\x22white\x22/>\x0a</g\
>\x0a<defs>\x0a<clipPa\
th id=\x22clip0_300\
5_40350\x22>\x0a<rect \
width=\x2228\x22 heigh\
t=\x2228\x22 fill=\x22whi\
te\x22/>\x0a</clipPath\
>\x0a</defs>\x0a</svg>\
\x0a\
\x00\x00\x01\xc3\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<c\
ircle cx=\x223\x22 cy=\
\x228\x22 r=\x221\x22 transf\
orm=\x22rotate(-90 \
3 8)\x22 fill=\x22#CED\
0D6\x22/>\x0a<circle c\
x=\x228\x22 cy=\x228\x22 r=\x22\
1\x22 transform=\x22ro\
tate(-90 8 8)\x22 f\
ill=\x22#CED0D6\x22/>\x0a\
<circle cx=\x2213\x22 \
cy=\x228\x22 r=\x221\x22 tra\
nsform=\x22rotate(-\
90 13 8)\x22 fill=\x22\
#CED0D6\x22/>\x0a</svg\
>\x0a\
\x00\x00\x04\xf9\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
12.157 7.20214C1\
2.4154 6.99461 1\
2.4566 6.61695 1\
2.249 6.35861C12\
.0415 6.10028 11\
.6638 6.0591 11.\
4055 6.26663L8.9\
2772 8.25717C8.6\
568 8.09391 8.33\
937 8 8.00001 8C\
7.0059 8 6.20001\
 8.80589 6.20001\
 9.8C6.20001 10.\
7941 7.0059 11.6\
 8.00001 11.6C8.\
99412 11.6 9.800\
01 10.7941 9.800\
01 9.8C9.80001 9\
.58321 9.76169 9\
.37538 9.69144 9\
.18289L12.157 7.\
20214ZM8.80001 9\
.8C8.80001 10.24\
18 8.44184 10.6 \
8.00001 10.6C7.5\
5818 10.6 7.2000\
1 10.2418 7.2000\
1 9.8C7.20001 9.\
35817 7.55818 9 \
8.00001 9C8.4418\
4 9 8.80001 9.35\
817 8.80001 9.8Z\
\x22 fill=\x22#CED0D6\x22\
/>\x0a<path fill-ru\
le=\x22evenodd\x22 cli\
p-rule=\x22evenodd\x22\
 d=\x22M8 3.5C4.410\
15 3.5 1.5 6.410\
15 1.5 10C1.5 10\
.8909 1.76974 12\
.0874 2.13917 13\
H13.8608C14.2303\
 12.0874 14.5 10\
.8909 14.5 10C14\
.5 6.41015 11.58\
99 3.5 8 3.5ZM0.\
5 10C0.5 5.85786\
 3.85786 2.5 8 2\
.5C12.1421 2.5 1\
5.5 5.85786 15.5\
 10C15.5 11.1604\
 15.1228 12.6805\
 14.6336 13.7304\
C14.5554 13.8984\
 14.3841 14 14.1\
987 14H1.80126C1\
.61594 14 1.4446\
3 13.8984 1.3663\
7 13.7304C0.8772\
41 12.6805 0.5 1\
1.1604 0.5 10Z\x22 \
fill=\x22#CED0D6\x22/>\
\x0a</svg>\x0a\
\x00\x00\x017\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M12.5 10.\
25L8 5.75L3.5 10\
.25\x22 stroke=\x22#CE\
D0D6\x22 stroke-lin\
ecap=\x22round\x22/>\x0a<\
/svg>\x0a\
\x00\x00\x010\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M9.5 11.5\
L6 8L9.5 4.5\x22 st\
roke=\x22#B4B8BF\x22 s\
troke-linecap=\x22r\
ound\x22/>\x0a</svg>\x0a\
\x00\x00\x034\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
11.4939 4.48784C\
11.3002 4.28007 \
10.9724 4.27548 \
10.7729 4.47775L\
8.00074 7.28849L\
5.22871 4.47788C\
5.02922 4.27561 \
4.70143 4.2802 4\
.50768 4.48797C4\
.32506 4.68382 4\
.32933 4.98882 4\
.51736 5.17947L7\
.29908 7.99991L4\
.51756 10.8201C4\
.32953 11.0108 4\
.32526 11.3158 4\
.50788 11.5116C4\
.70163 11.7194 5\
.02942 11.724 5.\
22892 11.5217L8.\
00074 8.71133L10\
.7727 11.5219C10\
.9722 11.7241 11\
.3 11.7196 11.49\
37 11.5118C11.67\
64 11.3159 11.67\
21 11.0109 11.48\
4 10.8203L8.7024\
 7.99991L11.4843\
 5.17934C11.6723\
 4.98869 11.6766\
 4.68368 11.4939\
 4.48784Z\x22 fill=\
\x22#6F737A\x22/>\x0a</sv\
g>\x0a\
\x00\x00\x03r\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
8.24408 6.65516C\
8.05415 6.43616 \
7.96859 6.14552 \
8.00959 5.85854L\
8.50238 2.40901L\
3.10978 8.99996H\
6.99954C7.28943 \
8.99996 7.56505 \
9.12576 7.75499 \
9.34476C7.94493 \
9.56376 8.03048 \
9.85441 7.98949 \
10.1414L7.4967 1\
3.5909L12.8893 6\
.99996H8.99954C8\
.70965 6.99996 8\
.43402 6.87416 8\
.24408 6.65516ZM\
9.74593 0.775195\
C9.81752 0.27406\
9 9.18453 -0.003\
92066 8.86398 0.\
387867L1.66768 9\
.18334C1.40057 9\
.50981 1.63285 9\
.99996 2.05466 9\
.99996H6.99954L6\
.25314 15.2247C6\
.18155 15.7259 6\
.81454 16.0038 7\
.1351 15.6121L14\
.3314 6.81658C14\
.5985 6.49012 14\
.3662 5.99996 13\
.9444 5.99996H8.\
99954L9.74593 0.\
775195Z\x22 fill=\x22#\
C77D55\x22/>\x0a</svg>\
\x0a\
\x00\x00\x01\x8f\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M2.00098 \
2H7.00195L7.0009\
8 7H2L2.00098 2Z\
M8.00293 2H13V7H\
8.00293V2ZM2 7.9\
9902L7 8V13.001L\
2 13V7.99902ZM8.\
00195 8H12.999L1\
2.998 13.001H8.0\
0195\x22 fill=\x22#CED\
0D6\x22/>\x0a</svg>\x0a\
\x00\x00\x01\xad\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M4.5 2.5L\
8 6L11.5 2.5\x22 st\
roke=\x22#CED0D6\x22 s\
troke-linecap=\x22r\
ound\x22 stroke-lin\
ejoin=\x22round\x22/>\x0a\
<path d=\x22M4.5 13\
.5L8 10L11.5 13.\
5\x22 stroke=\x22#CED0\
D6\x22 stroke-linec\
ap=\x22round\x22 strok\
e-linejoin=\x22roun\
d\x22/>\x0a</svg>\x0a\
\x00\x00\x04\xea\
<\
!-- Copyright 20\
00-2024 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
12.5 9C12.7761 9\
 13 9.22386 13 9\
.5V12H15.5C15.77\
61 12 16 12.2239\
 16 12.5C16 12.7\
761 15.7761 13 1\
5.5 13H13V15.5C1\
3 15.7761 12.776\
1 16 12.5 16C12.\
2239 16 12 15.77\
61 12 15.5V13H9.\
5C9.22386 13 9 1\
2.7761 9 12.5C9 \
12.2239 9.22386 \
12 9.5 12H12V9.5\
C12 9.22386 12.2\
239 9 12.5 9Z\x22 f\
ill=\x22#548AF7\x22/>\x0a\
<path d=\x22M3 13V5\
.82843C3 5.29799\
 3.21071 4.78929\
 3.58579 4.41421\
L6.41421 1.58579\
C6.78929 1.21071\
 7.29799 1 7.828\
43 1H11C12.1046 \
1 13 1.89543 13 \
3V8H12.5C11.6716\
 8 11 8.67157 11\
 9.5V11H9.5C8.67\
157 11 8 11.6716\
 8 12.5V15H5C3.8\
9543 15 3 14.104\
6 3 13Z\x22 fill=\x22#\
43454A\x22/>\x0a<path \
fill-rule=\x22eveno\
dd\x22 clip-rule=\x22e\
venodd\x22 d=\x22M3 13\
V5.82843C3 5.297\
99 3.21071 4.789\
29 3.58579 4.414\
21L6.41421 1.585\
79C6.78929 1.210\
71 7.29799 1 7.8\
2843 1H11C12.104\
6 1 13 1.89543 1\
3 3V8H12.5C12.32\
47 8 12.1564 8.0\
3008 12 8.08535V\
3C12 2.44772 11.\
5523 2 11 2H8V4C\
8 5.10457 7.1045\
7 6 6 6H4V13C4 1\
3.5523 4.44772 1\
4 5 14H8V15H5C3.\
89543 15 3 14.10\
46 3 13ZM4.41421\
 5L7 2.41421V4C7\
 4.55228 6.55228\
 5 6 5H4.41421Z\x22\
 fill=\x22#CED0D6\x22/\
>\x0a</svg>\x0a\
\x00\x00\x02\x00\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M11.5 10.\
5C12.485 10.5 13\
.4152 10.2623 14\
.2356 9.84137C13\
.4417 12.5343 10\
.9502 14.5 8 14.\
5C4.41015 14.5 1\
.5 11.5899 1.5 8\
C1.5 5.04985 3.4\
6572 2.55829 6.1\
5863 1.76439C5.7\
3766 2.58483 5.5\
 3.51498 5.5 4.5\
C5.5 7.81371 8.1\
8629 10.5 11.5 1\
0.5Z\x22 fill=\x22#253\
24D\x22 stroke=\x22#54\
8AF7\x22/>\x0a</svg>\x0a\
\x00\x00\x09\x03\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<g\
 clip-path=\x22url(\
#clip0_6654_5213\
2)\x22>\x0a<path d=\x22M8\
.5 1C8.5 0.72385\
8 8.27614 0.5 8 \
0.5C7.72386 0.5 \
7.5 0.723858 7.5\
 1V3.02469C7.664\
45 3.00836 7.831\
25 3 8 3C8.16875\
 3 8.33555 3.008\
36 8.5 3.02469V1\
Z\x22 fill=\x22#548AF7\
\x22/>\x0a<path d=\x22M3.\
40381 2.6967L4.8\
3563 4.12853C4.5\
7708 4.34011 4.3\
4011 4.57708 4.1\
2853 4.83563L2.6\
967 3.40381C2.50\
144 3.20854 2.50\
144 2.89196 2.69\
67 2.6967C2.8919\
6 2.50144 3.2085\
4 2.50144 3.4038\
1 2.6967Z\x22 fill=\
\x22#548AF7\x22/>\x0a<pat\
h d=\x22M3.02469 7.\
5H1C0.723858 7.5\
 0.5 7.72386 0.5\
 8C0.5 8.27614 0\
.723858 8.5 1 8.\
5H3.02469C3.0083\
6 8.33555 3 8.16\
875 3 8C3 7.8312\
5 3.00836 7.6644\
5 3.02469 7.5Z\x22 \
fill=\x22#548AF7\x22/>\
\x0a<path d=\x22M2.696\
7 12.5962L4.1285\
3 11.1644C4.3401\
1 11.4229 4.5770\
8 11.6599 4.8356\
3 11.8715L3.4038\
1 13.3033C3.2085\
4 13.4986 2.8919\
6 13.4986 2.6967\
 13.3033C2.50144\
 13.108 2.50144 \
12.7915 2.6967 1\
2.5962Z\x22 fill=\x22#\
548AF7\x22/>\x0a<path \
d=\x22M7.5 12.9753V\
15C7.5 15.2761 7\
.72386 15.5 8 15\
.5C8.27614 15.5 \
8.5 15.2761 8.5 \
15V12.9753C8.335\
55 12.9916 8.168\
75 13 8 13C7.831\
25 13 7.66445 12\
.9916 7.5 12.975\
3Z\x22 fill=\x22#548AF\
7\x22/>\x0a<path d=\x22M1\
2.5962 13.3033L1\
1.1644 11.8715C1\
1.4229 11.6599 1\
1.6599 11.4229 1\
1.8715 11.1644L1\
3.3033 12.5962C1\
3.4986 12.7915 1\
3.4986 13.108 13\
.3033 13.3033C13\
.108 13.4986 12.\
7915 13.4986 12.\
5962 13.3033Z\x22 f\
ill=\x22#548AF7\x22/>\x0a\
<path d=\x22M12.975\
3 8.5H15C15.2761\
 8.5 15.5 8.2761\
4 15.5 8C15.5 7.\
72386 15.2761 7.\
5 15 7.5H12.9753\
C12.9916 7.66445\
 13 7.83125 13 8\
C13 8.16875 12.9\
916 8.33555 12.9\
753 8.5Z\x22 fill=\x22\
#548AF7\x22/>\x0a<path\
 d=\x22M13.3033 3.4\
0381L11.8715 4.8\
3563C11.6599 4.5\
7708 11.4229 4.3\
4011 11.1644 4.1\
2853L12.5962 2.6\
967C12.7915 2.50\
144 13.108 2.501\
44 13.3033 2.696\
7C13.4986 2.8919\
6 13.4986 3.2085\
4 13.3033 3.4038\
1Z\x22 fill=\x22#548AF\
7\x22/>\x0a<path fill-\
rule=\x22evenodd\x22 c\
lip-rule=\x22evenod\
d\x22 d=\x22M12 8C12 1\
0.2091 10.2091 1\
2 8 12C5.79086 1\
2 4 10.2091 4 8C\
4 5.79086 5.7908\
6 4 8 4C10.2091 \
4 12 5.79086 12 \
8ZM11 8C11 9.656\
85 9.65685 11 8 \
11C6.34315 11 5 \
9.65685 5 8C5 6.\
34315 6.34315 5 \
8 5C9.65685 5 11\
 6.34315 11 8Z\x22 \
fill=\x22#548AF7\x22/>\
\x0a<circle cx=\x228\x22 \
cy=\x228\x22 r=\x223\x22 fil\
l=\x22#25324D\x22/>\x0a</\
g>\x0a<defs>\x0a<clipP\
ath id=\x22clip0_66\
54_52132\x22>\x0a<rect\
 width=\x2216\x22 heig\
ht=\x2216\x22 fill=\x22wh\
ite\x22/>\x0a</clipPat\
h>\x0a</defs>\x0a</svg\
>\x0a\
\x00\x00\x03\x86\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2228\x22 he\
ight=\x2228\x22 viewBo\
x=\x220 0 28 28\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<g\
 clip-path=\x22url(\
#clip0_3005_4036\
1)\x22>\x0a<path d=\x22M1\
2.72 2.74194C13.\
2889 1.75269 14.\
7111 1.75269 15.\
28 2.74194L26.79\
98 22.7742C27.36\
87 23.7634 26.65\
76 25 25.5198 25\
H2.4802C1.34244 \
25 0.631339 23.7\
634 1.20022 22.7\
742L12.72 2.7419\
4Z\x22 fill=\x22#F2C55\
C\x22/>\x0a<path d=\x22M1\
5 9C15 8.44772 1\
4.5523 8 14 8C13\
.4477 8 13 8.447\
71 13 9L13 15C13\
 15.5523 13.4477\
 16 14 16C14.552\
3 16 15 15.5523 \
15 15L15 9Z\x22 fil\
l=\x22#2B2D30\x22/>\x0a<p\
ath d=\x22M14 22C14\
.8284 22 15.5 21\
.3284 15.5 20.5C\
15.5 19.6716 14.\
8284 19 14 19C13\
.1716 19 12.5 19\
.6716 12.5 20.5C\
12.5 21.3284 13.\
1716 22 14 22Z\x22 \
fill=\x22#2B2D30\x22/>\
\x0a</g>\x0a<defs>\x0a<cl\
ipPath id=\x22clip0\
_3005_40361\x22>\x0a<r\
ect width=\x2228\x22 h\
eight=\x2228\x22 fill=\
\x22white\x22/>\x0a</clip\
Path>\x0a</defs>\x0a</\
svg>\x0a\
\x00\x00\x02\x1d\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2228\x22 he\
ight=\x2228\x22 viewBo\
x=\x220 0 28 28\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<g\
 clip-path=\x22url(\
#clip0_3005_4034\
1)\x22>\x0a<circle cx=\
\x2214\x22 cy=\x2214\x22 r=\x22\
12\x22 fill=\x22#57965\
C\x22/>\x0a<path d=\x22M2\
0 10.5L12.5 18L8\
.5 14\x22 stroke=\x22w\
hite\x22 stroke-wid\
th=\x222\x22 stroke-li\
necap=\x22round\x22 st\
roke-linejoin=\x22r\
ound\x22/>\x0a</g>\x0a<de\
fs>\x0a<clipPath id\
=\x22clip0_3005_403\
41\x22>\x0a<rect width\
=\x2228\x22 height=\x2228\
\x22 fill=\x22white\x22/>\
\x0a</clipPath>\x0a</d\
efs>\x0a</svg>\x0a\
\x00\x00\x04\xa1\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
7 4.5C7 5.42236 \
6.5005 6.22805 5\
.75725 6.66134L7\
.62202 7.45497L1\
3.3045 5.03983C1\
3.5586 4.93182 1\
3.8522 5.05029 1\
3.9602 5.30443C1\
4.0682 5.55857 1\
3.9498 5.85215 1\
3.6956 5.96017L8\
.89943 7.99862L1\
3.6956 10.0398C1\
3.9498 10.1478 1\
4.0682 10.4414 1\
3.9602 10.6956C1\
3.8522 10.9497 1\
3.5586 11.0682 1\
3.3045 10.9602L7\
.62176 8.54165L5\
.75271 9.33603C6\
.49847 9.76867 7\
 10.5758 7 11.5C\
7 12.8807 5.8807\
1 14 4.5 14C3.11\
929 14 2 12.8807\
 2 11.5C2 10.497\
5 2.59009 9.6327\
8 3.44189 9.2343\
L3.44092 9.232L6\
.34435 7.998L3.6\
5731 6.85442C2.6\
9121 6.50859 2 5\
.58501 2 4.5C2 3\
.11929 3.11929 2\
 4.5 2C5.88071 2\
 7 3.11929 7 4.5\
ZM6 4.5C6 5.3284\
3 5.32843 6 4.5 \
6C4.33031 6 4.16\
721 5.97182 4.01\
511 5.9199L3.814\
1 5.83435C3.3306\
4 5.58533 3 5.08\
128 3 4.5C3 3.67\
157 3.67157 3 4.\
5 3C5.32843 3 6 \
3.67157 6 4.5ZM6\
 11.5C6 12.3284 \
5.32843 13 4.5 1\
3C3.67157 13 3 1\
2.3284 3 11.5C3 \
10.6716 3.67157 \
10 4.5 10C5.3284\
3 10 6 10.6716 6\
 11.5Z\x22 fill=\x22#C\
ED0D6\x22/>\x0a</svg>\x0a\
\
\x00\x00\x04\xa3\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
12.5 9C12.7761 9\
 13 9.22386 13 9\
.5V12H15.5C15.77\
61 12 16 12.2239\
 16 12.5C16 12.7\
761 15.7761 13 1\
5.5 13H13V15.5C1\
3 15.7761 12.776\
1 16 12.5 16C12.\
2239 16 12 15.77\
61 12 15.5V13H9.\
5C9.22386 13 9 1\
2.7761 9 12.5C9 \
12.2239 9.22386 \
12 9.5 12H12V9.5\
C12 9.22386 12.2\
239 9 12.5 9Z\x22 f\
ill=\x22#548AF7\x22/>\x0a\
<path d=\x22M2.6333\
3 2C1.73127 2 1 \
2.83574 1 3.8666\
7V12.1333C1 13.1\
643 1.73127 14 2\
.63333 14H8V12.5\
C8 11.6716 8.671\
57 11 9.5 11H11V\
9.5C11 8.67157 1\
1.6716 8 12.5 8H\
15V6C15 4.89543 \
14.1046 4 13 4L8\
.46667 4L6.84336\
 2.30775C6.65477\
 2.11115 6.39413\
 2 6.1217 2H2.63\
333Z\x22 fill=\x22#434\
54A\x22/>\x0a<path d=\x22\
M6.1217 3L2.6333\
3 3C2.40481 3 2 \
3.25841 2 3.8666\
7V12.1333C2 12.7\
416 2.40481 13 2\
.63333 13H8V14H2\
.63333C1.73127 1\
4 1 13.1643 1 12\
.1333V3.86667C1 \
2.83574 1.73127 \
2 2.63333 2H6.12\
17C6.39413 2 6.6\
5477 2.11115 6.8\
4336 2.30775L8.4\
6667 4L13 4C14.1\
046 4 15 4.89543\
 15 6V8H14V6C14 \
5.44771 13.5523 \
5 13 5H8.04022L6\
.1217 3Z\x22 fill=\x22\
#CED0D6\x22/>\x0a</svg\
>\x0a\
\x00\x00\x09\xbe\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M1.62632 \
9.66782C1.44286 \
9.87421 1.46145 \
10.1902 1.66785 \
10.3737C1.87424 \
10.5572 2.19027 \
10.5386 2.37373 \
10.3322L1.62632 \
9.66782ZM14 10.5\
C14 10.7761 14.2\
239 11 14.5 11C1\
4.7761 11 15 10.\
7761 15 10.5H14Z\
M2 7.5C2 7.22386\
 1.77614 7 1.5 7\
C1.22386 7 1 7.2\
2386 1 7.5H2ZM1.\
5 10.5H1V11H1.5V\
10.5ZM4.5 11C4.7\
7614 11 5 10.776\
1 5 10.5C5 10.22\
39 4.77614 10 4.\
5 10V11ZM2.00003\
 10C2.37373 10.3\
322 2.37368 10.3\
322 2.37364 10.3\
323C2.37364 10.3\
323 2.37362 10.3\
323 2.37363 10.3\
323C2.37366 10.3\
323 2.37375 10.3\
322 2.37389 10.3\
32C2.37419 10.33\
17 2.37473 10.33\
11 2.3755 10.330\
2C2.37705 10.328\
5 2.37955 10.325\
7 2.38299 10.321\
9C2.38987 10.314\
2 2.40049 10.302\
5 2.41472 10.287\
C2.44318 10.2558\
 2.48606 10.2094\
 2.54224 10.15C2\
.65466 10.0309 2\
.82016 9.85969 3\
.03001 9.65366C3\
.45029 9.24102 4\
.04545 8.69176 4\
.74568 8.14375C6\
.17384 7.02606 7\
.93178 6 9.50003\
 6V5C7.56827 5 5\
.57621 6.22394 4\
.12937 7.35625C3\
.39211 7.93324 2\
.76851 8.50898 2\
.32942 8.94009C2\
.10958 9.15594 1\
.93524 9.33626 1\
.81523 9.46333C1\
.75521 9.52688 1\
.70873 9.57717 1\
.67689 9.61197C1\
.66096 9.62938 1\
.6487 9.64292 1.\
64023 9.65231C1.\
63599 9.65701 1.\
6327 9.66068 1.6\
3038 9.66327C1.6\
2922 9.66457 1.6\
283 9.6656 1.627\
62 9.66636C1.627\
28 9.66674 1.627\
 9.66705 1.62679\
 9.66729C1.62668\
 9.66742 1.62656\
 9.66755 1.62651\
 9.66761C1.62641\
 9.66772 1.62632\
 9.66782 2.00003\
 10ZM9.50003 6C1\
0.6625 6 11.5012\
 6.28919 12.1133\
 6.69727C12.7285\
 7.10745 13.1449\
 7.65792 13.4278\
 8.22361C13.7116\
 8.79125 13.856 \
9.36494 13.9287 \
9.80095C13.9648 \
10.0178 13.9827 \
10.1974 13.9915 \
10.3208C13.9959 \
10.3824 13.998 1\
0.4298 13.9991 1\
0.4605C13.9996 1\
0.4759 13.9998 1\
0.487 13.9999 10\
.4937C14 10.4971\
 14 10.4993 14 1\
0.5003C14 10.500\
9 14 10.5011 14 \
10.5011C14 10.50\
1 14 10.5009 14 \
10.5008C14 10.50\
07 14 10.5005 14\
 10.5004C14 10.5\
002 14 10.5 14.5\
 10.5C15 10.5 15\
 10.4997 15 10.4\
995C15 10.4993 1\
5 10.499 15 10.4\
988C15 10.4983 1\
5 10.4978 15 10.\
4971C15 10.4959 \
15 10.4943 15 10\
.4924C14.9999 10\
.4887 14.9999 10\
.4837 14.9998 10\
.4776C14.9996 10\
.4654 14.9992 10\
.4485 14.9985 10\
.4272C14.9971 10\
.3847 14.9943 10\
.3246 14.989 10.\
2495C14.9782 10.\
0995 14.9571 9.8\
8848 14.9151 9.6\
3655C14.8315 9.1\
3506 14.6634 8.4\
5875 14.3222 7.7\
7639C13.9801 7.0\
9208 13.459 6.39\
255 12.668 5.865\
23C11.8739 5.335\
81 10.8375 5 9.5\
0003 5V6ZM1 7.5V\
10.5H2V7.5H1ZM1.\
5 11H4.5V10H1.5V\
11Z\x22 fill=\x22#CED0\
D6\x22/>\x0a</svg>\x0a\
\x00\x00\x01\x1f\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x223\x22 y=\x228\x22 \
width=\x2210\x22 heigh\
t=\x221\x22 fill=\x22#CED\
0D6\x22/>\x0a</svg>\x0a\
\x00\x00\x02\xa3\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M2.5 9V8C\
2.5 4.96243 4.96\
243 2.5 8 2.5C9.\
10679 2.5 10.137\
2 2.82692 11 3.3\
8947\x22 stroke=\x22#C\
ED0D6\x22 stroke-li\
necap=\x22round\x22/>\x0a\
<path d=\x22M5 12.6\
105C5.86278 13.1\
731 6.89321 13.5\
 8 13.5C11.0376 \
13.5 13.5 11.037\
6 13.5 8V7\x22 stro\
ke=\x22#CED0D6\x22 str\
oke-linecap=\x22rou\
nd\x22/>\x0a<path d=\x22M\
0.49997 7.50027L\
2.5 9.5L4.49998 \
7.50023\x22 stroke=\
\x22#CED0D6\x22 stroke\
-linecap=\x22round\x22\
/>\x0a<path d=\x22M11.\
5 8.49982L13.5 6\
.5L15.5 8.49982\x22\
 stroke=\x22#CED0D6\
\x22 stroke-linecap\
=\x22round\x22/>\x0a</svg\
>\x0a\
\x00\x00\x016\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M12.5 5.7\
5L8 10.25L3.5 5.\
75\x22 stroke=\x22#CED\
0D6\x22 stroke-line\
cap=\x22round\x22/>\x0a</\
svg>\x0a\
\x00\x00\x02\xe2\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2228\x22 he\
ight=\x2228\x22 viewBo\
x=\x220 0 28 28\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<g\
 clip-path=\x22url(\
#clip0_3005_4037\
1)\x22>\x0a<circle cx=\
\x2214\x22 cy=\x2214\x22 r=\x22\
12\x22 fill=\x22#548AF\
7\x22/>\x0a<path d=\x22M1\
3 20C13 20.5523 \
13.4477 21 14 21\
C14.5523 21 15 2\
0.5523 15 20L15 \
14C15 13.4477 14\
.5523 13 14 13C1\
3.4477 13 13 13.\
4477 13 14L13 20\
Z\x22 fill=\x22white\x22/\
>\x0a<path d=\x22M14 7\
C13.1716 7 12.5 \
7.67157 12.5 8.5\
C12.5 9.32843 13\
.1716 10 14 10C1\
4.8284 10 15.5 9\
.32843 15.5 8.5C\
15.5 7.67157 14.\
8284 7 14 7Z\x22 fi\
ll=\x22white\x22/>\x0a</g\
>\x0a<defs>\x0a<clipPa\
th id=\x22clip0_300\
5_40371\x22>\x0a<rect \
width=\x2228\x22 heigh\
t=\x2228\x22 fill=\x22whi\
te\x22/>\x0a</clipPath\
>\x0a</defs>\x0a</svg>\
\x0a\
\x00\x00\x02\xb1\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2218\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 18 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M3.5 9V8C\
3.5 4.96243 5.96\
243 2.5 9 2.5C10\
.1068 2.5 11.137\
2 2.82692 12 3.3\
8947\x22 stroke=\x22#C\
ED0D6\x22 stroke-li\
necap=\x22round\x22/>\x0a\
<path d=\x22M6 12.6\
105C6.86278 13.1\
731 7.89321 13.5\
 9 13.5C12.0376 \
13.5 14.5 11.037\
6 14.5 8V7\x22 stro\
ke=\x22#CED0D6\x22 str\
oke-linecap=\x22rou\
nd\x22/>\x0a<path d=\x22M\
1.37868 7.32133L\
3.5 9.44265L5.62\
132 7.32133\x22 str\
oke=\x22#CED0D6\x22 st\
roke-linecap=\x22ro\
und\x22/>\x0a<path d=\x22\
M12.3787 8.67867\
L14.5 6.55735L16\
.6213 8.67867\x22 s\
troke=\x22#CED0D6\x22 \
stroke-linecap=\x22\
round\x22/>\x0a</svg>\x0a\
\
\x00\x00\x01\xac\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
5 3H13V11H10V10H\
12V4H6V6H5V3Z\x22 f\
ill=\x22#CED0D6\x22/>\x0a\
<path fill-rule=\
\x22evenodd\x22 clip-r\
ule=\x22evenodd\x22 d=\
\x22M11 5H3V13H11V5\
ZM10 6H4V12H10V6\
Z\x22 fill=\x22#CED0D6\
\x22/>\x0a</svg>\x0a\
\x00\x00\x01a\
<\
!-- Copyright 20\
00-2024 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M2.5 8.25\
L6 11.75L13.5 4.\
25\x22 stroke=\x22#CED\
0D6\x22 stroke-widt\
h=\x221.5\x22 stroke-l\
inecap=\x22round\x22 s\
troke-linejoin=\x22\
round\x22/>\x0a</svg>\x0a\
\
\x00\x00\x03\xe2\
<\
!-- Copyright 20\
00-2024 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M4.12642 \
5.16655C4.32168 \
4.97129 4.63827 \
4.97129 4.83353 \
5.16655L7.16698 \
7.5L4.83353 9.83\
345C4.63827 10.0\
287 4.32168 10.0\
287 4.12642 9.83\
345C3.93116 9.63\
819 3.93116 9.32\
161 4.12642 9.12\
635L5.75277 7.5L\
4.12642 5.87365C\
3.93116 5.67839 \
3.93116 5.36181 \
4.12642 5.16655Z\
\x22 fill=\x22#CED0D6\x22\
/>\x0a<path d=\x22M7.5\
 10C7.22386 10 7\
 10.2239 7 10.5C\
7 10.7761 7.2238\
6 11 7.5 11H10.5\
C10.7761 11 11 1\
0.7761 11 10.5C1\
1 10.2239 10.776\
1 10 10.5 10L7.5\
 10Z\x22 fill=\x22#CED\
0D6\x22/>\x0a<path fil\
l-rule=\x22evenodd\x22\
 clip-rule=\x22even\
odd\x22 d=\x22M3 2C1.8\
9543 2 1 2.89543\
 1 4V12C1 13.104\
6 1.89543 14 3 1\
4H13C14.1046 14 \
15 13.1046 15 12\
V4C15 2.89543 14\
.1046 2 13 2H3ZM\
13 3H3C2.44772 3\
 2 3.44772 2 4V1\
2C2 12.5523 2.44\
772 13 3 13H13C1\
3.5523 13 14 12.\
5523 14 12V4C14 \
3.44772 13.5523 \
3 13 3Z\x22 fill=\x22#\
CED0D6\x22/>\x0a</svg>\
\x0a\
\x00\x00\x01.\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M6 11.5L9\
.5 8L6 4.5\x22 stro\
ke=\x22#B4B8BF\x22 str\
oke-linecap=\x22rou\
nd\x22/>\x0a</svg>\x0a\
\x00\x00\x02\xb6\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
12.3536 6.34645C\
12.5488 6.54171 \
12.5488 6.85829 \
12.3536 7.05355C\
12.1583 7.24882 \
11.8417 7.24882 \
11.6464 7.05355L\
8.5 3.9071L8.5 1\
3.5071C8.5 13.78\
32 8.27614 14.00\
71 8 14.0071C7.7\
2386 14.0071 7.5\
 13.7832 7.5 13.\
5071L7.5 3.90711\
L4.35355 7.05355\
C4.15829 7.24882\
 3.84171 7.24882\
 3.64645 7.05355\
C3.45118 6.85829\
 3.45118 6.54171\
 3.64645 6.34645\
L7.64645 2.34644\
L8 1.99289L8.353\
55 2.34644L12.35\
36 6.34645Z\x22 fil\
l=\x22#CED0D6\x22/>\x0a</\
svg>\x0a\
\x00\x00\x015\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M4.5 9.75\
L8 6.25L11.5 9.7\
5\x22 stroke=\x22#B4B8\
BF\x22 stroke-linec\
ap=\x22round\x22/>\x0a</s\
vg>\x0a\
\x00\x00\x02\xea\
<\
!-- Copyright 20\
00-2021 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license that ca\
n be found in th\
e LICENSE file. \
-->\x0a<svg xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22 widt\
h=\x2213\x22 height=\x221\
3\x22 viewBox=\x220 0 \
13 13\x22>\x0a  <g fil\
l=\x22#AFB1B3\x22 fill\
-rule=\x22evenodd\x22>\
\x0a    <rect width\
=\x222\x22 height=\x225.6\
57\x22 x=\x228.9\x22 y=\x226\
.869\x22 transform=\
\x22rotate(-45 9.9 \
9.697)\x22/>\x0a    <p\
ath d=\x22M5.25,10 \
C2.62664744,10 0\
.5,7.87335256 0.\
5,5.25 C0.5,2.62\
664744 2.6266474\
4,0.5 5.25,0.5 C\
7.87335256,0.5 1\
0,2.62664744 10,\
5.25 C10,7.87335\
256 7.87335256,1\
0 5.25,10 Z M5.2\
5,8.1 C6.8240115\
4,8.1 8.1,6.8240\
1154 8.1,5.25 C8\
.1,3.67598846 6.\
82401154,2.4 5.2\
5,2.4 C3.6759884\
6,2.4 2.4,3.6759\
8846 2.4,5.25 C2\
.4,6.82401154 3.\
67598846,8.1 5.2\
5,8.1 Z\x22/>\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x022\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 vi\
ewBox=\x220 0 16 16\
\x22>\x0a  <g fill=\x22no\
ne\x22 fill-rule=\x22e\
venodd\x22>\x0a    <re\
ct width=\x226\x22 hei\
ght=\x2210\x22 x=\x225\x22 y\
=\x223\x22 fill=\x22#AFB1\
B3\x22/>\x0a    <rect \
width=\x222\x22 height\
=\x222\x22 x=\x2212\x22 y=\x224\
\x22 fill=\x22#AFB1B3\x22\
/>\x0a    <rect wid\
th=\x222\x22 height=\x222\
\x22 x=\x2212\x22 y=\x227\x22 f\
ill=\x22#AFB1B3\x22/>\x0a\
    <rect width=\
\x222\x22 height=\x222\x22 x\
=\x2212\x22 y=\x2210\x22 fil\
l=\x22#AFB1B3\x22/>\x0a  \
  <rect width=\x222\
\x22 height=\x222\x22 x=\x22\
2\x22 y=\x224\x22 fill=\x22#\
AFB1B3\x22/>\x0a    <r\
ect width=\x222\x22 he\
ight=\x222\x22 x=\x222\x22 y\
=\x227\x22 fill=\x22#AFB1\
B3\x22/>\x0a    <rect \
width=\x222\x22 height\
=\x222\x22 x=\x222\x22 y=\x2210\
\x22 fill=\x22#AFB1B3\x22\
/>\x0a  </g>\x0a</svg>\
\x0a\
\x00\x00\x01\xf0\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M9 7L5.5 \
10.5\x22 stroke=\x22#C\
ED0D6\x22 stroke-li\
necap=\x22round\x22 st\
roke-linejoin=\x22r\
ound\x22/>\x0a<path d=\
\x22M8.5 10.5L5.5 1\
0.5L5.5 7.5\x22 str\
oke=\x22#CED0D6\x22 st\
roke-linecap=\x22ro\
und\x22 stroke-line\
join=\x22round\x22/>\x0a<\
rect x=\x222.5\x22 y=\x22\
2.5\x22 width=\x2211\x22 \
height=\x2211\x22 rx=\x22\
1.5\x22 stroke=\x22#CE\
D0D6\x22/>\x0a</svg>\x0a\
\x00\x00\x03\xe5\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M2.9675 1\
2.35H4.6175V14H2\
.9675V12.35Z\x22 fi\
ll=\x22#CED0D6\x22/>\x0a<\
path d=\x22M11.613 \
9.0925L9.709 6.6\
87L10.389 6.126L\
12.4205 8.404L11\
.613 9.0925ZM8.3\
235 9.0925L7.516\
 8.404L9.5475 6.\
126L10.2275 6.68\
7L8.3235 9.0925Z\
M9.7345 6.5595L6\
.751 5.854L7.031\
5 4.8255L9.964 5\
.701L9.7345 6.55\
95ZM9.9725 6.610\
5C9.84783 6.6105\
 9.74017 6.568 9\
.6495 6.483C9.56\
45 6.39233 9.522\
 6.28467 9.522 6\
.16C9.522 6.0353\
3 9.5645 5.9305 \
9.6495 5.8455C9.\
74017 5.7605 9.8\
4783 5.718 9.972\
5 5.718C10.0972 \
5.718 10.202 5.7\
605 10.287 5.845\
5C10.372 5.9305 \
10.4145 6.03533 \
10.4145 6.16C10.\
4145 6.28467 10.\
372 6.39233 10.2\
87 6.483C10.202 \
6.568 10.0972 6.\
6105 9.9725 6.61\
05ZM9.522 6.16L9\
.437 3.1H10.4995\
L10.4145 6.16H9.\
522ZM10.202 6.55\
95L9.9725 5.701L\
12.905 4.8255L13\
.1855 5.854L10.2\
02 6.5595Z\x22 fill\
=\x22#CED0D6\x22/>\x0a</s\
vg>\x0a\
\x00\x00\x09\xf7\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M1 10.5C1\
 10.7761 1.22386\
 11 1.5 11C1.776\
14 11 2 10.7761 \
2 10.5H1ZM13.626\
3 10.3322C13.809\
8 10.5386 14.125\
8 10.5572 14.332\
2 10.3737C14.538\
6 10.1902 14.557\
2 9.87421 14.373\
7 9.66782L13.626\
3 10.3322ZM11.5 \
9.99999C11.2239 \
9.99999 11 10.22\
38 11 10.5C11 10\
.7761 11.2239 11\
 11.5 11V9.99999\
ZM14.5 10.5V11H1\
5V10.5H14.5ZM15 \
7.49999C15 7.223\
85 14.7761 6.999\
99 14.5 6.99999C\
14.2239 6.99999 \
14 7.22385 14 7.\
49999H15ZM1.5 10\
.5C2 10.5 2 10.5\
002 2 10.5004C2 \
10.5005 2 10.500\
7 2 10.5008C2 10\
.5009 2 10.501 2\
 10.5011C2 10.50\
11 2 10.5009 2 1\
0.5003C2.00001 1\
0.4993 2.00003 1\
0.4971 2.00009 1\
0.4937C2.0002 10\
.487 2.00043 10.\
4759 2.00094 10.\
4605C2.00197 10.\
4298 2.00409 10.\
3824 2.00849 10.\
3208C2.01731 10.\
1974 2.03519 10.\
0178 2.07132 9.8\
0095C2.14399 9.3\
6495 2.28839 8.7\
9125 2.57221 8.2\
2361C2.85506 7.6\
5792 3.27147 7.1\
0745 3.88673 6.6\
9728C4.49885 6.2\
8919 5.33749 6 6\
.5 6V5C5.16251 5\
 4.12615 5.33581\
 3.33203 5.86522\
C2.54103 6.39255\
 2.01994 7.09208\
 1.67779 7.77639\
C1.33661 8.45875\
 1.16851 9.13505\
 1.08493 9.63655\
C1.04294 9.88848\
 1.02175 10.0995\
 1.01104 10.2495\
C1.00567 10.3246\
 1.00292 10.3847\
 1.0015 10.4272C\
1.00079 10.4485 \
1.00041 10.4654 \
1.00022 10.4776C\
1.00012 10.4837 \
1.00006 10.4887 \
1.00003 10.4924C\
1.00002 10.4943 \
1.00001 10.4959 \
1.00001 10.4971C\
1 10.4978 1 10.4\
983 1 10.4988C1 \
10.499 1 10.4993\
 1 10.4995C1 10.\
4997 1 10.5 1.5 \
10.5ZM6.5 6C8.06\
824 6 9.82619 7.\
02606 11.2543 8.\
14375C11.9546 8.\
69176 12.5497 9.\
24102 12.97 9.65\
366C13.1799 9.85\
969 13.3454 10.0\
309 13.4578 10.1\
5C13.514 10.2094\
 13.5568 10.2558\
 13.5853 10.287C\
13.5995 10.3025 \
13.6102 10.3142 \
13.617 10.3219C1\
3.6205 10.3257 1\
3.623 10.3285 13\
.6245 10.3302C13\
.6253 10.3311 13\
.6258 10.3317 13\
.6261 10.332C13.\
6263 10.3322 13.\
6264 10.3323 13.\
6264 10.3323C13.\
6264 10.3323 13.\
6264 10.3323 13.\
6264 10.3323C13.\
6264 10.3322 13.\
6263 10.3322 14 \
10C14.3737 9.667\
82 14.3736 9.667\
72 14.3735 9.667\
61C14.3735 9.667\
55 14.3733 9.667\
42 14.3732 9.667\
29C14.373 9.6670\
5 14.3727 9.6667\
4 14.3724 9.6663\
6C14.3717 9.6656\
 14.3708 9.66457\
 14.3696 9.66327\
C14.3673 9.66068\
 14.364 9.65701 \
14.3598 9.65231C\
14.3513 9.64292 \
14.3391 9.62938 \
14.3231 9.61197C\
14.2913 9.57717 \
14.2448 9.52688 \
14.1848 9.46333C\
14.0648 9.33626 \
13.8904 9.15594 \
13.6706 8.94009C\
13.2315 8.50898 \
12.6079 7.93324 \
11.8707 7.35625C\
10.4238 6.22394 \
8.43176 5 6.5 5V\
6ZM11.5 11H14.5V\
9.99999H11.5V11Z\
M15 10.5V7.49999\
H14V10.5H15Z\x22 fi\
ll=\x22#CED0D6\x22/>\x0a<\
/svg>\x0a\
\x00\x00\x05b\
<\
svg width=\x2216\x22 h\
eight=\x2216\x22 viewB\
ox=\x220 0 16 16\x22 f\
ill=\x22none\x22 xmlns\
=\x22http://www.w3.\
org/2000/svg\x22>\x0a<\
path fill-rule=\x22\
evenodd\x22 clip-ru\
le=\x22evenodd\x22 d=\x22\
M14 0.500015C14 \
0.297783 13.8782\
 0.115465 13.691\
4 0.0380748C13.5\
045 -0.0393156 1\
3.2895 0.0034622\
3 13.1465 0.1464\
61L11.1465 2.146\
46C11.0527 2.240\
23 11 2.36741 11\
 2.50001V4.29291\
L9.01602 6.27693\
C8.71825 6.10097\
 8.37092 6 8 6C6\
.89543 6 6 6.895\
43 6 8C6 9.10457\
 6.89543 10 8 10\
C9.10457 10 10 9\
.10457 10 8C10 7\
.62911 9.89904 7\
.2818 9.72311 6.\
98405L11.7071 5.\
00001H13.5C13.63\
26 5.00001 13.75\
98 4.94734 13.85\
36 4.85357L15.85\
36 2.85357C15.99\
66 2.71057 16.03\
94 2.49551 15.96\
2 2.30867C15.884\
6 2.12184 15.702\
3 2.00001 15.5 2\
.00001H14V0.5000\
15ZM13.2929 4.00\
001H12V2.70712L1\
3 1.70712V2.5000\
1C13 2.77616 13.\
2239 3.00001 13.\
5 3.00001H14.292\
9L13.2929 4.0000\
1ZM9 8C9 8.55228\
 8.55228 9 8 9C7\
.44772 9 7 8.552\
28 7 8C7 7.44772\
 7.44772 7 8 7C8\
.55228 7 9 7.447\
72 9 8Z\x22 fill=\x22#\
CED0D6\x22/>\x0a<path \
d=\x22M10.0081 2.34\
43C9.38028 2.121\
36 8.70432 2 8 2\
C4.68629 2 2 4.6\
8629 2 8C2 11.31\
37 4.68629 14 8 \
14C11.3137 14 14\
 11.3137 14 8C14\
 7.29572 13.8787\
 6.61978 13.6557\
 5.99195C13.9963\
 5.95641 14.3163\
 5.80507 14.5607\
 5.5607L14.5626 \
5.55883C14.8454 \
6.31891 15 7.141\
4 15 8C15 11.866\
 11.866 15 8 15C\
4.13401 15 1 11.\
866 1 8C1 4.1340\
1 4.13401 1 8 1C\
8.85864 1 9.6811\
8 1.1546 10.4413\
 1.43748L10.4394\
 1.43938C10.195 \
1.68373 10.0437 \
2.00371 10.0081 \
2.3443Z\x22 fill=\x22#\
CED0D6\x22/>\x0a</svg>\
\x0a\
\x00\x00\x01\xad\
<\
!-- Copyright 20\
00-2024 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M4.5 5.5L\
8 2L11.5 5.5\x22 st\
roke=\x22#CED0D6\x22 s\
troke-linecap=\x22r\
ound\x22 stroke-lin\
ejoin=\x22round\x22/>\x0a\
<path d=\x22M4.5 10\
.5L8 14L11.5 10.\
5\x22 stroke=\x22#CED0\
D6\x22 stroke-linec\
ap=\x22round\x22 strok\
e-linejoin=\x22roun\
d\x22/>\x0a</svg>\x0a\
\x00\x00\x03\x02\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x222\x22 y=\x2212\x22\
 width=\x2212\x22 heig\
ht=\x221\x22 rx=\x220.5\x22 \
fill=\x22#CED0D6\x22/>\
\x0a<rect x=\x226\x22 y=\x22\
6\x22 width=\x228\x22 hei\
ght=\x221\x22 rx=\x220.5\x22\
 fill=\x22#CED0D6\x22/\
>\x0a<rect x=\x226\x22 y=\
\x229\x22 width=\x228\x22 he\
ight=\x221\x22 rx=\x220.5\
\x22 fill=\x22#CED0D6\x22\
/>\x0a<rect x=\x222\x22 y\
=\x223\x22 width=\x2212\x22 \
height=\x221\x22 rx=\x220\
.5\x22 fill=\x22#CED0D\
6\x22/>\x0a<path d=\x22M2\
.8 6.1C2.64849 5\
.98637 2.44579 5\
.96809 2.27639 6\
.05279C2.107 6.1\
3749 2 6.31062 2\
 6.5V9.5C2 9.689\
39 2.107 9.86252\
 2.27639 9.94722\
C2.44579 10.0319\
 2.64849 10.0136\
 2.8 9.9L4.8 8.4\
C4.9259 8.30558 \
5 8.15738 5 8C5 \
7.84262 4.9259 7\
.69443 4.8 7.6L2\
.8 6.1Z\x22 fill=\x22#\
548AF7\x22/>\x0a</svg>\
\x0a\
\x00\x00\x01\x1f\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x224\x22 y=\x2212\x22\
 width=\x228\x22 heigh\
t=\x221\x22 fill=\x22#CED\
0D6\x22/>\x0a</svg>\x0a\
\x00\x00\x0a\xe3\
<\
svg width=\x2216\x22 h\
eight=\x2216\x22 viewB\
ox=\x220 0 16 16\x22 f\
ill=\x22none\x22 xmlns\
=\x22http://www.w3.\
org/2000/svg\x22>\x0a<\
path fill-rule=\x22\
evenodd\x22 clip-ru\
le=\x22evenodd\x22 d=\x22\
M3.22655 4.36961\
C2.92233 4.76924\
 2.66735 5.20781\
 2.47037 5.67626\
L3.30992 7.0943C\
3.6406 7.65283 3\
.6406 8.34718 3.\
30992 8.9057L2.4\
7037 10.3237C2.6\
6736 10.7922 2.9\
2233 11.2308 3.2\
2656 11.6304L4.8\
7261 11.6124C5.5\
2165 11.6053 6.1\
2297 11.9524 6.4\
4133 12.5181L7.2\
4899 13.953C7.49\
593 13.984 7.747\
92 14 8.00408 14\
C8.2602 14 8.512\
14 13.984 8.7590\
4 13.9531L9.5667\
1 12.5181C9.8850\
7 11.9524 10.486\
4 11.6053 11.135\
4 11.6124L12.781\
6 11.6304C13.085\
8 11.2308 13.340\
8 10.7923 13.537\
7 10.3239L12.698\
1 8.9057C12.3674\
 8.34718 12.3674\
 7.65283 12.6981\
 7.0943L13.5377 \
5.67613C13.3408 \
5.20773 13.0858 \
4.76921 12.7816 \
4.36961L11.1354 \
4.38764C10.4864 \
4.39475 9.88507 \
4.04758 9.56671 \
3.48194L8.75904 \
2.04693C8.51214 \
2.01599 8.2602 2\
 8.00408 2C7.747\
92 2 7.49594 2.0\
16 7.24899 2.046\
95L6.44133 3.481\
94C6.12297 4.047\
58 5.52165 4.394\
75 4.87261 4.387\
64L3.22655 4.369\
61ZM10.655 8.000\
01C10.655 9.4641\
2 9.46811 10.651\
 8.004 10.651C6.\
5399 10.651 5.35\
3 9.46412 5.353 \
8.00001C5.353 6.\
53591 6.5399 5.3\
4902 8.004 5.349\
02C9.46811 5.349\
02 10.655 6.5359\
1 10.655 8.00001\
ZM4.88356 3.3877\
C5.16752 3.39081\
 5.4306 3.23892 \
5.56988 2.99146L\
6.43817 1.44875C\
6.54914 1.25159 \
6.7401 1.1101 6.\
96387 1.07676C7.\
30327 1.0262 7.6\
5062 1 8.00408 1\
C8.3575 1 8.7048\
 1.02619 9.04414\
 1.07674C9.26792\
 1.11007 9.45889\
 1.25157 9.56986\
 1.44873L10.4382\
 2.99146C10.5774\
 3.23892 10.8405\
 3.39081 11.1245\
 3.3877L12.8938 \
3.36832C13.1196 \
3.36585 13.3372 \
3.46012 13.4781 \
3.63661C13.9099 \
4.17766 14.2632 \
4.78416 14.5207 \
5.43884C14.6034 \
5.6491 14.5763 5\
.88489 14.4612 6\
.07931L13.5586 7\
.60376C13.4139 7\
.84811 13.4139 8\
.15189 13.5586 8\
.39625L14.4612 9\
.92069C14.5763 1\
0.1151 14.6034 1\
0.3509 14.5207 1\
0.5612C14.2632 1\
1.2158 13.9099 1\
1.8223 13.4781 1\
2.3634C13.3372 1\
2.5399 13.1196 1\
2.6342 12.8938 1\
2.6317L11.1245 1\
2.6123C10.8405 1\
2.6092 10.5774 1\
2.7611 10.4382 1\
3.0085L9.56986 1\
4.5513C9.45889 1\
4.7484 9.26792 1\
4.8899 9.04414 1\
4.9233C8.7048 14\
.9738 8.3575 15 \
8.00408 15C7.650\
62 15 7.30327 14\
.9738 6.96387 14\
.9232C6.7401 14.\
8899 6.54914 14.\
7484 6.43817 14.\
5512L5.56988 13.\
0085C5.4306 12.7\
611 5.16752 12.6\
092 4.88356 12.6\
123L3.1144 12.63\
17C2.8886 12.634\
2 2.67096 12.539\
9 2.5301 12.3634\
C2.09822 11.8223\
 1.74489 11.2158\
 1.48738 10.561C\
1.40469 10.3508 \
1.43184 10.115 1\
.54695 9.92057L2\
.44942 8.39625C2\
.5941 8.15189 2.\
5941 7.84811 2.4\
4942 7.60376L1.5\
4695 6.07944C1.4\
3184 5.88502 1.4\
0469 5.64924 1.4\
8738 5.43898C1.7\
4489 4.78425 2.0\
9822 4.1777 2.53\
009 3.63661C2.67\
096 3.46012 2.88\
86 3.36585 3.114\
4 3.36832L4.8835\
6 3.3877ZM9.655 \
8.00001C9.655 8.\
91183 8.91582 9.\
65101 8.004 9.65\
101C7.09218 9.65\
101 6.353 8.9118\
3 6.353 8.00001C\
6.353 7.08819 7.\
09218 6.34902 8.\
004 6.34902C8.91\
582 6.34902 9.65\
5 7.08819 9.655 \
8.00001Z\x22 fill=\x22\
#CED0D6\x22/>\x0a</svg\
>\x0a\
\x00\x00\x02\x9d\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
12.3536 9.65355C\
12.5488 9.45829 \
12.5488 9.14171 \
12.3536 8.94645C\
12.1583 8.75118 \
11.8417 8.75118 \
11.6464 8.94645L\
8.5 12.0929L8.5 \
2.5C8.5 2.22386 \
8.27614 2 8 2C7.\
72386 2 7.5 2.22\
386 7.5 2.5L7.5 \
12.0929L4.35355 \
8.94645C4.15829 \
8.75118 3.84171 \
8.75118 3.64645 \
8.94645C3.45118 \
9.14171 3.45118 \
9.45829 3.64645 \
9.65355L7.64645 \
13.6536L8 14.007\
1L8.35355 13.653\
6L12.3536 9.6535\
5Z\x22 fill=\x22#CED0D\
6\x22/>\x0a</svg>\x0a\
\x00\x00\x01\xc8\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x223.75781\x22 \
y=\x223.05029\x22 widt\
h=\x2213\x22 height=\x221\
\x22 transform=\x22rot\
ate(45 3.75781 3\
.05029)\x22 fill=\x22#\
CED0D6\x22/>\x0a<rect \
width=\x2213\x22 heigh\
t=\x221\x22 transform=\
\x22matrix(-0.70710\
7 0.707107 0.707\
107 0.707107 12.\
2432 3.05029)\x22 f\
ill=\x22#CED0D6\x22/>\x0a\
</svg>\x0a\
\x00\x00\x05\x00\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M5.5 6C5.\
22386 6 5 6.2238\
6 5 6.5C5 6.7761\
4 5.22386 7 5.5 \
7H10.5C10.7761 7\
 11 6.77614 11 6\
.5C11 6.22386 10\
.7761 6 10.5 6H5\
.5Z\x22 fill=\x22#CED0\
D6\x22/>\x0a<path d=\x22M\
5 8.5C5 8.22386 \
5.22386 8 5.5 8H\
10.5C10.7761 8 1\
1 8.22386 11 8.5\
C11 8.77614 10.7\
761 9 10.5 9H5.5\
C5.22386 9 5 8.7\
7614 5 8.5Z\x22 fil\
l=\x22#CED0D6\x22/>\x0a<p\
ath d=\x22M5.5 10C5\
.22386 10 5 10.2\
239 5 10.5C5 10.\
7761 5.22386 11 \
5.5 11H10.5C10.7\
761 11 11 10.776\
1 11 10.5C11 10.\
2239 10.7761 10 \
10.5 10H5.5Z\x22 fi\
ll=\x22#CED0D6\x22/>\x0a<\
path fill-rule=\x22\
evenodd\x22 clip-ru\
le=\x22evenodd\x22 d=\x22\
M12 2H10.9146C10\
.7087 1.4174 10.\
1531 1 9.5 1H6.5\
C5.84689 1 5.291\
27 1.4174 5.0853\
5 2H4C2.89543 2 \
2 2.89543 2 4V13\
C2 14.1046 2.895\
43 15 4 15H12C13\
.1046 15 14 14.1\
046 14 13V4C14 2\
.89543 13.1046 2\
 12 2ZM4 3H5.085\
35C5.29127 3.582\
6 5.84689 4 6.5 \
4H9.5C10.1531 4 \
10.7087 3.5826 1\
0.9146 3H12C12.5\
523 3 13 3.44772\
 13 4V13C13 13.5\
523 12.5523 14 1\
2 14H4C3.44772 1\
4 3 13.5523 3 13\
V4C3 3.44772 3.4\
4772 3 4 3ZM6.5 \
2C6.22386 2 6 2.\
22386 6 2.5C6 2.\
77614 6.22386 3 \
6.5 3H9.5C9.7761\
4 3 10 2.77614 1\
0 2.5C10 2.22386\
 9.77614 2 9.5 2\
H6.5Z\x22 fill=\x22#CE\
D0D6\x22/>\x0a</svg>\x0a\
\x00\x00\x02G\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
4 3H12C12.5523 3\
 13 3.44772 13 4\
V7.5L3 7.5V4C3 3\
.44772 3.44772 3\
 4 3ZM2 8.5V7.5V\
4C2 2.89543 2.89\
543 2 4 2H12C13.\
1046 2 14 2.8954\
3 14 4V7.5V8.5V1\
2C14 13.1046 13.\
1046 14 12 14H4C\
2.89543 14 2 13.\
1046 2 12V8.5ZM1\
3 8.5V12C13 12.5\
523 12.5523 13 1\
2 13H4C3.44772 1\
3 3 12.5523 3 12\
V8.5L13 8.5Z\x22 fi\
ll=\x22#CED0D6\x22/>\x0a<\
/svg>\x0a\
\x00\x00\x05Z\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x222.5\x22 y=\x222\
.5\x22 width=\x2211\x22 h\
eight=\x2211\x22 rx=\x221\
.5\x22 fill=\x22#43454\
A\x22 stroke=\x22#CED0\
D6\x22/>\x0a<path d=\x22M\
7.32546 9.03C7.3\
2546 8.80334 7.3\
638 8.605 7.4404\
6 8.435C7.52046 \
8.26167 7.61546 \
8.115 7.72546 7.\
995C7.8388 7.871\
67 7.98546 7.731\
67 8.16546 7.575\
C8.32546 7.435 8\
.45046 7.31834 8\
.54046 7.225C8.6\
338 7.12834 8.71\
046 7.01667 8.77\
046 6.89C8.8338 \
6.76334 8.86546 \
6.62167 8.86546 \
6.465C8.86546 6.\
215 8.7888 6.011\
67 8.63546 5.855\
C8.48213 5.695 8\
.2788 5.615 8.02\
546 5.615C7.7454\
6 5.615 7.52046 \
5.705 7.35046 5.\
885C7.1838 6.065\
 7.10213 6.3 7.1\
0546 6.59H5.7254\
6C5.72546 6.13 5\
.8188 5.735 6.00\
546 5.405C6.1921\
3 5.07167 6.4588\
 4.81834 6.80546\
 4.645C7.15546 4\
.46834 7.56713 4\
.38 8.04046 4.38\
C8.49713 4.38 8.\
8938 4.46167 9.2\
3046 4.625C9.567\
13 4.78834 9.825\
46 5.02 10.0055 \
5.32C10.1855 5.6\
1667 10.2738 5.9\
6667 10.2705 6.3\
7C10.2705 6.6733\
4 10.2221 6.935 \
10.1255 7.155C10\
.0288 7.375 9.91\
38 7.555 9.78046\
 7.695C9.64713 7\
.835 9.47213 7.9\
9334 9.25546 8.1\
7C9.10546 8.29 8\
.98713 8.39 8.90\
046 8.47001C8.81\
713 8.55 8.74713\
 8.64167 8.69046\
 8.74501C8.63713\
 8.84501 8.61046\
 8.95667 8.61046\
 9.08V9.255H7.32\
546V9.03ZM8.7404\
6 11.5H7.24046V1\
0H8.74046V11.5Z\x22\
 fill=\x22#CED0D6\x22/\
>\x0a</svg>\x0a\
\x00\x00\x03\x9c\
<\
!-- Copyright 20\
00-2024 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
11 1H7.91421C7.5\
1639 1 7.13486 1\
.15803 6.85355 1\
.43934L3.43934 4\
.85355C3.15804 5\
.13486 3 5.51639\
 3 5.91421V13C3 \
14.1046 3.89543 \
15 5 15H11C12.10\
46 15 13 14.1046\
 13 13V3C13 1.89\
543 12.1046 1 11\
 1ZM4 13C4 13.55\
23 4.44772 14 5 \
14H11C11.5523 14\
 12 13.5523 12 1\
3V3C12 2.44772 1\
1.5523 2 11 2H8V\
4.5C8 5.32843 7.\
32843 6 6.5 6H4V\
13ZM4.70711 5L7 \
2.70711V4.5C7 4.\
77614 6.77614 5 \
6.5 5H4.70711Z\x22 \
fill=\x22#CED0D6\x22/>\
\x0a<path d=\x22M5 14C\
4.44772 14 4 13.\
5523 4 13V6H6.5C\
7.32843 6 8 5.32\
843 8 4.5V2H11C1\
1.5523 2 12 2.44\
772 12 3V13C12 1\
3.5523 11.5523 1\
4 11 14H5Z\x22 fill\
=\x22#43454A\x22/>\x0a<pa\
th d=\x22M7 2.70711\
L4.70711 5H6.5C6\
.77614 5 7 4.776\
14 7 4.5V2.70711\
Z\x22 fill=\x22#43454A\
\x22/>\x0a</svg>\x0a\
\x00\x00\x03\xbc\
<\
!-- Copyright 20\
00-2024 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M10.164 1\
0.8717C9.30216 1\
1.5769 8.20049 1\
2 7 12C6.59443 1\
2 6.20013 11.951\
7 5.82255 11.860\
6L5.36279 10.650\
7C5.86252 10.875\
1 6.41668 11 7 1\
1C9.20914 11 11 \
9.20914 11 7C11 \
4.79086 9.20914 \
3 7 3C4.79086 3 \
3 4.79086 3 7C3 \
7.3453 3.04375 7\
.68038 3.12602 8\
H2.10002C2.03443\
 7.67689 2 7.342\
47 2 7C2 4.23858\
 4.23858 2 7 2C9\
.76142 2 12 4.23\
858 12 7C12 8.20\
078 11.5767 9.30\
27 10.8712 10.16\
47L13.8526 13.14\
24C14.0479 13.33\
75 14.0481 13.65\
41 13.853 13.849\
5C13.6578 14.044\
9 13.3413 14.045\
 13.1459 13.8499\
L10.164 10.8717Z\
\x22 fill=\x22#CED0D6\x22\
/>\x0a<path fill-ru\
le=\x22evenodd\x22 cli\
p-rule=\x22evenodd\x22\
 d=\x22M3.665 9H2.5\
7L0 16H1.075L1.6\
7 14.22H4.635L5.\
275 16H6.325L3.6\
65 9ZM3.225 10.3\
3L4.335 13.385H1\
.95L3 10.33L3.11\
 9.9L3.225 10.33\
Z\x22 fill=\x22#CED0D6\
\x22/>\x0a</svg>\x0a\
\x00\x00\x02A\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
8.5 3H12C12.5523\
 3 13 3.44772 13\
 4V12C13 12.5523\
 12.5523 13 12 1\
3H8.5V3ZM7.5 2H8\
.5H12C13.1046 2 \
14 2.89543 14 4V\
12C14 13.1046 13\
.1046 14 12 14H8\
.5H7.5H4C2.89543\
 14 2 13.1046 2 \
12V4C2 2.89543 2\
.89543 2 4 2H7.5\
ZM7.5 13H4C3.447\
72 13 3 12.5523 \
3 12V4C3 3.44772\
 3.44772 3 4 3H7\
.5V13Z\x22 fill=\x22#C\
ED0D6\x22/>\x0a</svg>\x0a\
\
\x00\x00\x08\xd1\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2228\x22 he\
ight=\x2228\x22 viewBo\
x=\x220 0 28 28\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<g\
 clip-path=\x22url(\
#clip0_4347_4808\
0)\x22>\x0a<circle cx=\
\x2214\x22 cy=\x2214\x22 r=\x22\
12\x22 fill=\x22#548AF\
7\x22/>\x0a<path d=\x22M1\
3.9366 21.004C13\
.5872 21.004 13.\
2868 20.8805 13.\
0353 20.6333C12.\
7839 20.3819 12.\
6582 20.0793 12.\
6582 19.7256C12.\
6582 19.3762 12.\
7839 19.0779 13.\
0353 18.8307C13.\
2868 18.5793 13.\
5872 18.4536 13.\
9366 18.4536C14.\
2818 18.4536 14.\
5801 18.5793 14.\
8315 18.8307C15.\
0872 19.0779 15.\
215 19.3762 15.2\
15 19.7256C15.21\
5 19.96 15.1554 \
20.1752 15.036 2\
0.3712C14.921 20\
.563 14.7676 20.\
7164 14.5758 20.\
8315C14.3841 20.\
9465 14.171 21.0\
04 13.9366 21.00\
4Z\x22 fill=\x22white\x22\
/>\x0a<path d=\x22M13.\
8358 16.5C13.358\
9 16.5 12.9724 1\
6.1134 12.9724 1\
5.6366V15.6366C1\
2.9809 14.8791 1\
3.0597 14.6127 1\
3.2089 14.1647C1\
3.3623 13.7168 1\
3.5796 13.3543 1\
3.8609 13.0774C1\
4.1421 12.8005 1\
4.4809 12.548 14\
.8772 12.3199C15\
.1329 12.1652 15\
.363 11.9921 15.\
5676 11.8007C15.\
7721 11.6093 15.\
934 11.3894 16.0\
533 11.1409C16.1\
727 10.8925 16.2\
316 10.6123 16.2\
316 10.3109C16.2\
316 9.94845 16.1\
421 9.63487 15.9\
632 9.37016C15.7\
842 9.10545 15.5\
455 8.90183 15.2\
472 8.75929C14.9\
532 8.61269 14.6\
251 8.53938 14.2\
629 8.53938C13.9\
347 8.53938 13.6\
215 8.60454 13.3\
232 8.73486C13.0\
249 8.86518 12.7\
778 9.0688 12.58\
18 9.34572C12.54\
22 9.40075 12.50\
61 9.459 12.4733\
 9.52048C12.2301\
 9.97682 11.8418\
 10.4025 11.3246\
 10.4025V10.4025\
C10.7655 10.4025\
 10.2997 9.92801\
 10.4658 9.39414\
C10.5629 9.0824 \
10.7014 8.79952 \
10.8815 8.54549C\
11.2394 8.03644 \
11.7124 7.65159 \
12.3005 7.39095C\
12.8928 7.13032 \
13.547 7 14.2629\
 7C15.047 7 15.7\
33 7.1405 16.321\
1 7.4215C16.9092\
 7.69842 17.3651\
 8.08734 17.689 \
8.58825C18.0171 \
9.08509 18.1812 \
9.66541 18.1812 \
10.3292C18.1812 \
10.7853 18.1073 \
11.202 17.9582 1\
1.5685C17.809 11\
.931 17.596 12.2\
548 17.319 12.53\
98C17.0462 12.82\
49 16.7181 13.07\
74 16.3346 13.29\
73C15.9724 13.51\
31 15.6783 13.73\
71 15.4525 13.96\
92C15.2309 14.20\
14 15.068 14.406\
2 14.9658 14.723\
9C14.8635 15.041\
5 14.809 15.1683\
 14.8005 15.6366\
V15.6366C14.8005\
 16.1134 14.4139\
 16.5 13.9371 16\
.5H13.8358Z\x22 fil\
l=\x22white\x22/>\x0a</g>\
\x0a<defs>\x0a<clipPat\
h id=\x22clip0_4347\
_48080\x22>\x0a<rect w\
idth=\x2228\x22 height\
=\x2228\x22 fill=\x22whit\
e\x22/>\x0a</clipPath>\
\x0a</defs>\x0a</svg>\x0a\
\
\x00\x00\x0aD\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M4.51619 \
13.0001C3.68538 \
13.0001 2.93338 \
12.7967 2.26021 \
12.3899C1.58704 \
11.9787 1.05873 \
11.4161 0.675276\
 10.702C0.291824\
 9.98794 0.10009\
8 9.1873 0.10009\
8 8.3001C0.10009\
8 7.4129 0.29182\
4 6.61225 0.6752\
76 5.89816C1.058\
73 5.18408 1.587\
04 4.62362 2.260\
21 4.21681C2.933\
38 3.80567 3.685\
38 3.6001 4.5161\
9 3.6001C5.20214\
 3.6001 5.84336 \
3.73642 6.43984 \
4.00908C7.03632 \
4.2774 7.52629 4\
.64743 7.90974 5\
.11916C8.29319 5\
.59089 8.52114 6\
.11455 8.59356 6\
.69015H7.31539C7\
.22592 6.3396 7.\
04271 6.01934 6.\
76578 5.72938C6.\
4931 5.43942 6.1\
5864 5.21221 5.7\
6241 5.04775C5.3\
6618 4.88329 4.9\
5077 4.80106 4.5\
1619 4.80106C3.9\
2823 4.80106 3.3\
9992 4.95037 2.9\
3125 5.24899C2.4\
6259 5.54761 2.0\
9405 5.96308 1.8\
2563 6.4954C1.56\
148 7.02772 1.42\
94 7.62929 1.429\
4 8.3001C1.4294 \
8.97091 1.56148 \
9.57247 1.82563 \
10.1048C2.09405 \
10.6371 2.46259 \
11.0526 2.93125 \
11.3512C3.39992 \
11.6498 3.92823 \
11.7991 4.51619 \
11.7991C4.95077 \
11.7991 5.36618 \
11.7169 5.76241 \
11.5524C6.15864 \
11.388 6.4931 11\
.1629 6.76578 10\
.8773C7.04271 10\
.5873 7.22592 10\
.2671 7.31539 9.\
91653H8.59356C8.\
52114 10.4921 8.\
29319 11.0158 7.\
90974 11.4875C7.\
52629 11.9549 7.\
03632 12.325 6.4\
3984 12.5976C5.8\
4336 12.8659 5.2\
0214 13.0001 4.5\
1619 13.0001Z\x22 f\
ill=\x22#CED0D6\x22/>\x0a\
<path d=\x22M12.800\
5 13.0001C12.17 \
13.0001 11.6012 \
12.8486 11.0942 \
12.5457C10.5872 \
12.2427 10.1888 \
11.8273 9.89907 \
11.2993C9.60935 \
10.7669 9.46449 \
10.174 9.46449 9\
.52054C9.46449 8\
.86704 9.60935 8\
.27629 9.89907 7\
.7483C10.1888 7.\
21598 10.5872 6.\
79835 11.0942 6.\
4954C11.6012 6.1\
9245 12.17 6.040\
98 12.8005 6.040\
98C13.3331 6.040\
98 13.8167 6.134\
03 14.2513 6.320\
13C14.6901 6.506\
22 15.0501 6.776\
71 15.3313 7.131\
59C15.6168 7.486\
47 15.8064 7.908\
43 15.9001 8.397\
47H14.6475C14.56\
23 8.1378 14.425\
9 7.91709 14.238\
5 7.73532C14.055\
3 7.55355 13.838\
 7.41722 13.5866\
 7.32634C13.3395\
 7.23113 13.0775\
 7.18352 12.8005\
 7.18352C12.4128\
 7.18352 12.0634\
 7.28306 11.7524\
 7.48214C11.4414\
 7.68122 11.1985\
 7.9582 11.0239 \
8.31308C10.8534 \
8.66796 10.7682 \
9.07045 10.7682 \
9.52054C10.7682 \
9.9663 10.8534 1\
0.3666 11.0239 1\
0.7215C11.1985 1\
1.0764 11.4414 1\
1.3555 11.7524 1\
1.5589C12.0634 1\
1.758 12.4128 11\
.8576 12.8005 11\
.8576C13.0775 11\
.8576 13.3395 11\
.8121 13.5866 11\
.7212C13.838 11.\
626 14.0553 11.4\
875 14.2385 11.3\
058C14.4259 11.1\
24 14.5623 10.90\
33 14.6475 10.64\
36H15.9001C15.81\
06 11.1197 15.61\
89 11.5351 15.32\
49 11.89C15.0352\
 12.2449 14.6709\
 12.5197 14.2321\
 12.7145C13.7975\
 12.9049 13.3203\
 13.0001 12.8005\
 13.0001Z\x22 fill=\
\x22#CED0D6\x22/>\x0a</sv\
g>\x0a\
\x00\x00\x02%\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M8.10584 \
4.34613L8.25344 \
4.5H8.46667H13C1\
3.8284 4.5 14.5 \
5.17157 14.5 6V1\
2.1333C14.5 12.9\
529 13.932 13.5 \
13.3667 13.5H2.6\
3333C2.06804 13.\
5 1.5 12.9529 1.\
5 12.1333V3.8666\
7C1.5 3.04707 2.\
06804 2.5 2.6333\
3 2.5H6.1217C6.2\
5792 2.5 6.38824\
 2.55557 6.48253\
 2.65387L8.10584\
 4.34613Z\x22 fill=\
\x22#43454A\x22 stroke\
=\x22#CED0D6\x22/>\x0a</s\
vg>\x0a\
\x00\x00\x01$\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x223.5\x22 y=\x223\
.5\x22 width=\x229\x22 he\
ight=\x229\x22 stroke=\
\x22#CED0D6\x22/>\x0a</sv\
g>\x0a\
\x00\x00\x01\xed\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x222\x22 y=\x2212\x22\
 width=\x228\x22 heigh\
t=\x221\x22 rx=\x220.5\x22 f\
ill=\x22#CED0D6\x22/>\x0a\
<rect x=\x222\x22 y=\x226\
\x22 width=\x228\x22 heig\
ht=\x221\x22 rx=\x220.5\x22 \
fill=\x22#CED0D6\x22/>\
\x0a<rect x=\x222\x22 y=\x22\
9\x22 width=\x2212\x22 he\
ight=\x221\x22 rx=\x220.5\
\x22 fill=\x22#CED0D6\x22\
/>\x0a<rect x=\x222\x22 y\
=\x223\x22 width=\x2212\x22 \
height=\x221\x22 rx=\x220\
.5\x22 fill=\x22#CED0D\
6\x22/>\x0a</svg>\x0a\
\x00\x00\x03p\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<c\
ircle opacity=\x220\
.13\x22 cx=\x228\x22 cy=\x22\
8\x22 r=\x228\x22 fill=\x22#\
F0F1F2\x22/>\x0a<path \
fill-rule=\x22eveno\
dd\x22 clip-rule=\x22e\
venodd\x22 d=\x22M11.4\
939 4.48784C11.3\
002 4.28007 10.9\
724 4.27548 10.7\
729 4.47775L8.00\
074 7.28849L5.22\
871 4.47788C5.02\
922 4.27561 4.70\
143 4.2802 4.507\
68 4.48797C4.325\
06 4.68382 4.329\
33 4.98882 4.517\
36 5.17947L7.299\
08 7.99991L4.517\
56 10.8201C4.329\
53 11.0108 4.325\
26 11.3158 4.507\
88 11.5116C4.701\
63 11.7194 5.029\
42 11.724 5.2289\
2 11.5217L8.0007\
4 8.71133L10.772\
7 11.5219C10.972\
2 11.7241 11.3 1\
1.7196 11.4937 1\
1.5118C11.6764 1\
1.3159 11.6721 1\
1.0109 11.484 10\
.8203L8.7024 7.9\
9991L11.4843 5.1\
7934C11.6723 4.9\
8869 11.6766 4.6\
8368 11.4939 4.4\
8784Z\x22 fill=\x22#86\
8A91\x22/>\x0a</svg>\x0a\
\x00\x00\x01\x91\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath d=\x22M1.299 3.\
9H2.703L5.043 11\
.2125L7.2725 3.9\
H8.6115L10.8735 \
11.2125L13.155 3\
.9H14.5135L11.54\
3 13H10.1585L7.9\
225 5.7785L5.647\
5 13H4.2695L1.29\
9 3.9Z\x22 fill=\x22#C\
ED0D6\x22/>\x0a</svg>\x0a\
\
\x00\x00\x036\
<\
!-- Copyright 20\
00-2023 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<r\
ect x=\x222.5\x22 y=\x223\
.5\x22 width=\x229\x22 he\
ight=\x2210\x22 rx=\x221.\
5\x22 stroke=\x22#CED0\
D6\x22/>\x0a<rect x=\x225\
\x22 y=\x226\x22 width=\x224\
\x22 height=\x221\x22 rx=\
\x220.5\x22 fill=\x22#CED\
0D6\x22/>\x0a<rect x=\x22\
5\x22 y=\x228\x22 width=\x22\
4\x22 height=\x221\x22 rx\
=\x220.5\x22 fill=\x22#CE\
D0D6\x22/>\x0a<rect x=\
\x225\x22 y=\x2210\x22 width\
=\x224\x22 height=\x221\x22 \
rx=\x220.5\x22 fill=\x22#\
CED0D6\x22/>\x0a<path \
fill-rule=\x22eveno\
dd\x22 clip-rule=\x22e\
venodd\x22 d=\x22M11.0\
017 2H11.5998C12\
.373 2 12.9998 2\
.6268 12.9998 3.\
4V3.91081C13.001\
1 3.94038 13.001\
7 3.97011 13.001\
7 4V11.5482C13.6\
063 11.1124 13.9\
998 10.4021 13.9\
998 9.6V3.4C13.9\
998 2.07452 12.9\
253 1 11.5998 1H\
6.39978C5.59677 \
1 4.88587 1.3943\
7 4.4502 2H6.399\
78H11.0017Z\x22 fil\
l=\x22#CED0D6\x22/>\x0a</\
svg>\x0a\
\x00\x00\x03\x1f\
<\
svg width=\x2216\x22 h\
eight=\x2216\x22 viewB\
ox=\x220 0 16 16\x22 f\
ill=\x22none\x22 xmlns\
=\x22http://www.w3.\
org/2000/svg\x22>\x0a<\
path fill-rule=\x22\
evenodd\x22 clip-ru\
le=\x22evenodd\x22 d=\x22\
M4 14C2.89543 14\
 2 13.1046 2 12L\
2 4C2 2.89543 2.\
89543 2 4 2L6.5 \
2C6.77614 2 7 2.\
22386 7 2.5C7 2.\
77614 6.77614 3 \
6.5 3L4 3C3.4477\
2 3 3 3.44772 3 \
4L3 12C3 12.5523\
 3.44772 13 4 13\
H12C12.5523 13 1\
3 12.5523 13 12V\
9.5C13 9.22386 1\
3.2239 9 13.5 9C\
13.7761 9 14 9.2\
2386 14 9.5V12C1\
4 13.1046 13.104\
6 14 12 14H4Z\x22 f\
ill=\x22#CED0D6\x22/>\x0a\
<path fill-rule=\
\x22evenodd\x22 clip-r\
ule=\x22evenodd\x22 d=\
\x22M14 2V6.5C14 6.\
77614 13.7761 7 \
13.5 7C13.2239 7\
 13 6.77614 13 6\
.5V3.70711L8.853\
55 7.85355C8.658\
29 8.04882 8.341\
71 8.04882 8.146\
45 7.85355C7.951\
18 7.65829 7.951\
18 7.34171 8.146\
45 7.14645L12.29\
29 3L9.5 3C9.223\
86 3 9 2.77614 9\
 2.5C9 2.22386 9\
.22386 2 9.5 2L1\
4 2Z\x22 fill=\x22#CED\
0D6\x22/>\x0a</svg>\x0a\
\x00\x00\x04\xd3\
<\
!-- Copyright 20\
00-2022 JetBrain\
s s.r.o. and con\
tributors. Use o\
f this source co\
de is governed b\
y the Apache 2.0\
 license. -->\x0a<s\
vg width=\x2216\x22 he\
ight=\x2216\x22 viewBo\
x=\x220 0 16 16\x22 fi\
ll=\x22none\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a<p\
ath fill-rule=\x22e\
venodd\x22 clip-rul\
e=\x22evenodd\x22 d=\x22M\
6.48057 5.70711L\
6.26727 7.20016C\
6.19763 7.68767 \
5.90122 8.07205 \
5.53634 8.29289C\
4.78518 8.74751 \
4.39847 9.41436 \
4.19857 10H11.80\
15C11.6016 9.414\
34 11.2149 8.747\
46 10.4637 8.292\
84C10.0988 8.072\
01 9.80236 7.687\
62 9.73272 7.200\
09L9.51943 5.707\
11C9.39072 4.806\
11 10.0899 4 11 \
4V3L5 3V4C5.9101\
4 4 6.60928 4.80\
611 6.48057 5.70\
711ZM5.27732 7.0\
5873C5.25463 7.2\
176 5.15585 7.35\
428 5.01856 7.43\
737C3.84968 8.14\
481 3.35768 9.22\
759 3.15058 10.0\
138C3.0099 10.54\
78 3.44776 11 4.\
00005 11H12C12.5\
523 11 12.9902 1\
0.5478 12.8495 1\
0.0138C12.6424 9\
.22757 12.1504 8\
.14475 10.9814 7\
.43732C10.8442 7\
.35423 10.7454 7\
.21754 10.7227 7\
.05867L10.5094 5\
.56569C10.4667 5\
.26712 10.6984 5\
 11 5C11.5523 5 \
12 4.55228 12 4V\
3C12 2.44772 11.\
5523 2 11 2H5C4.\
44772 2 4 2.4477\
2 4 3V4C4 4.5522\
8 4.44772 5 5 5C\
5.3016 5 5.53327\
 5.26712 5.49062\
 5.56569L5.27732\
 7.05873Z\x22 fill=\
\x22#CED0D6\x22/>\x0a<pat\
h d=\x22M7.5 11H8.5\
V14.5C8.5 14.776\
1 8.27614 15 8 1\
5V15C7.72386 15 \
7.5 14.7761 7.5 \
14.5V11Z\x22 fill=\x22\
#CED0D6\x22/>\x0a</svg\
>\x0a\
"

qt_resource_name = b"\
\x00\x04\
\x00\x06\xa8\x8b\
\x00d\
\x00a\x00r\x00k\
\x00\x05\
\x00r\xfd\xf4\
\x00l\
\x00i\x00g\x00h\x00t\
\x00\x0b\
\x09\xb1o~\
\x00c\
\x00h\x00e\x00v\x00r\x00o\x00n\x00D\x00o\x00w\x00n\
\x00\x06\
\x07\x80\xaf^\
\x00p\
\x00y\x00t\x00h\x00o\x00n\
\x00\x04\
\x00\x07f\xbe\
\x00o\
\x00p\x00e\x00n\
\x00\x07\
\x07\x96\x0bD\
\x00p\
\x00r\x00o\x00j\x00e\x00c\x00t\
\x00\x13\
\x02)l\xf4\
\x00s\
\x00y\x00s\x00t\x00e\x00m\x00T\x00h\x00e\x00m\x00e\x00S\x00e\x00l\x00e\x00c\x00t\
\x00e\x00d\
\x00\x06\
\x075\x98\xa5\
\x00l\
\x00o\x00c\x00a\x00t\x00e\
\x00\x0a\
\x08\xb6+E\
\x00t\
\x00a\x00b\x00b\x00e\x00d\x00P\x00a\x00n\x00e\
\x00\x04\
\x00\x07\x98\xc5\
\x00s\
\x00a\x00v\x00e\
\x00\x09\
\x0b\x86L\xd8\
\x00c\
\x00l\x00e\x00a\x00r\x00C\x00a\x00s\x00h\
\x00\x0b\
\x06vq\x97\
\x00e\
\x00r\x00r\x00o\x00r\x00D\x00i\x00a\x00l\x00o\x00g\
\x00\x0e\
\x0c\x09\xaa\x5c\
\x00m\
\x00o\x00r\x00e\x00H\x00o\x00r\x00i\x00z\x00o\x00n\x00t\x00a\x00l\
\x00\x08\
\x0c\xc8\xe5\xb4\
\x00o\
\x00v\x00e\x00r\x00h\x00e\x00a\x00d\
\x00\x0e\
\x01\xc9\xbe\xd5\
\x00c\
\x00h\x00e\x00v\x00r\x00o\x00n\x00U\x00p\x00L\x00a\x00r\x00g\x00e\
\x00\x0b\
\x09\xb0\xf2t\
\x00c\
\x00h\x00e\x00v\x00r\x00o\x00n\x00L\x00e\x00f\x00t\
\x00\x0a\
\x09\xa7r\xec\
\x00c\
\x00l\x00o\x00s\x00e\x00S\x00m\x00a\x00l\x00l\
\x00\x09\
\x0d\xfb\xad\xa7\
\x00l\
\x00i\x00g\x00h\x00t\x00n\x00i\x00n\x00g\
\x00\x10\
\x0fT\xf3c\
\x00m\
\x00i\x00c\x00r\x00o\x00s\x00o\x00f\x00t\x00W\x00i\x00n\x00d\x00o\x00w\x00s\
\x00\x0b\
\x08\xadRl\
\x00c\
\x00o\x00l\x00l\x00a\x00p\x00s\x00e\x00A\x00l\x00l\
\x00\x06\
\x06z\x88Y\
\x00a\
\x00d\x00d\x00A\x00n\x00y\
\x00\x11\
\x00\xa9\xfb\x94\
\x00d\
\x00a\x00r\x00k\x00T\x00h\x00e\x00m\x00e\x00S\x00e\x00l\x00e\x00c\x00t\x00e\x00d\
\
\x00\x12\
\x05D\xa1\xd4\
\x00l\
\x00i\x00g\x00h\x00t\x00T\x00h\x00e\x00m\x00e\x00S\x00e\x00l\x00e\x00c\x00t\x00e\
\x00d\
\x00\x0d\
\x00\xbd\xe27\
\x00w\
\x00a\x00r\x00n\x00i\x00n\x00g\x00D\x00i\x00a\x00l\x00o\x00g\
\x00\x0d\
\x02\xdc{\xf7\
\x00s\
\x00u\x00c\x00c\x00e\x00s\x00s\x00D\x00i\x00a\x00l\x00o\x00g\
\x00\x03\
\x00\x00j\xc4\
\x00c\
\x00u\x00t\
\x00\x09\
\x0b\xd6\xc3B\
\x00n\
\x00e\x00w\x00F\x00o\x00l\x00d\x00e\x00r\
\x00\x04\
\x00\x07\xc4\xaf\
\x00u\
\x00n\x00d\x00o\
\x00\x08\
\x00PO\x85\
\x00m\
\x00i\x00n\x00i\x00m\x00i\x00z\x00e\
\x00\x07\
\x08\xbd\x8cx\
\x00r\
\x00e\x00f\x00r\x00e\x00s\x00h\
\x00\x10\
\x09\x04\xa55\
\x00c\
\x00h\x00e\x00v\x00r\x00o\x00n\x00D\x00o\x00w\x00n\x00L\x00a\x00r\x00g\x00e\
\x00\x11\
\x01\x1f.7\
\x00i\
\x00n\x00f\x00o\x00r\x00m\x00a\x00t\x00i\x00o\x00n\x00D\x00i\x00a\x00l\x00o\x00g\
\
\x00\x0b\
\x00\xbf;#\
\x00s\
\x00e\x00t\x00t\x00i\x00n\x00g\x00S\x00y\x00n\x00c\
\x00\x07\
\x08\xca\xb6e\
\x00r\
\x00e\x00s\x00t\x00o\x00r\x00e\
\x00\x07\
\x09\xeb\xa1t\
\x00c\
\x00h\x00e\x00c\x00k\x00e\x00d\
\x00\x07\
\x0ae\xa6\xe5\
\x00c\
\x00o\x00n\x00s\x00o\x00l\x00e\
\x00\x0c\
\x0b\x05f\xd4\
\x00c\
\x00h\x00e\x00v\x00r\x00o\x00n\x00R\x00i\x00g\x00h\x00t\
\x00\x02\
\x00\x00\x07\xc0\
\x00u\
\x00p\
\x00\x09\
\x0c\xd9\xb0\x00\
\x00c\
\x00h\x00e\x00v\x00r\x00o\x00n\x00U\x00p\
\x00\x0e\
\x07\xa8j\x04\
\x00t\
\x00o\x00o\x00l\x00W\x00i\x00n\x00d\x00o\x00w\x00F\x00i\x00n\x00d\
\x00\x0a\
\x06\x90\xb7G\
\x00m\
\x00e\x00m\x00o\x00r\x00y\x00V\x00i\x00e\x00w\
\x00\x10\
\x07\xc6\xbc\xa7\
\x00o\
\x00p\x00e\x00n\x00I\x00n\x00T\x00o\x00o\x00l\x00W\x00i\x00n\x00d\x00o\x00w\
\x00\x05\
\x00x\xbd\xc8\
\x00r\
\x00e\x00g\x00e\x00x\
\x00\x04\
\x00\x07\x8b\xaf\
\x00r\
\x00e\x00d\x00o\
\x00\x06\
\x07\xa8\x8d\xc4\
\x00t\
\x00a\x00r\x00g\x00e\x00t\
\x00\x09\
\x06\x84a\xcc\
\x00e\
\x00x\x00p\x00a\x00n\x00d\x00A\x00l\x00l\
\x00\x0c\
\x0c\x9fH\x85\
\x00r\
\x00e\x00f\x00o\x00r\x00m\x00a\x00t\x00C\x00o\x00d\x00e\
\x00\x0d\
\x08\xa4A\xcc\
\x00m\
\x00i\x00n\x00i\x00m\x00i\x00z\x00e\x00S\x00m\x00a\x00l\x00l\
\x00\x08\
\x0c\xbb\x0b\xc3\
\x00s\
\x00e\x00t\x00t\x00i\x00n\x00g\x00s\
\x00\x04\
\x00\x06\xb6\xde\
\x00d\
\x00o\x00w\x00n\
\x00\x05\
\x00j6\x95\
\x00c\
\x00l\x00o\x00s\x00e\
\x00\x05\
\x00v\x8a\xa5\
\x00p\
\x00a\x00s\x00t\x00e\
\x00\x11\
\x06^\xad9\
\x00s\
\x00p\x00l\x00i\x00t\x00H\x00o\x00r\x00i\x00z\x00o\x00n\x00t\x00a\x00l\x00l\x00y\
\
\x00\x07\
\x0cRV>\
\x00u\
\x00n\x00k\x00n\x00o\x00w\x00n\
\x00\x07\
\x08^\xc0\xa5\
\x00a\
\x00n\x00y\x00T\x00y\x00p\x00e\
\x00\x07\
\x08\xc7'u\
\x00r\
\x00e\x00p\x00l\x00a\x00c\x00e\
\x00\x0f\
\x0c\xeb3\xd9\
\x00s\
\x00p\x00l\x00i\x00t\x00V\x00e\x00r\x00t\x00i\x00c\x00a\x00l\x00l\x00y\
\x00\x0e\
\x05:E\xb7\
\x00q\
\x00u\x00e\x00s\x00t\x00i\x00o\x00n\x00D\x00i\x00a\x00l\x00o\x00g\
\x00\x09\
\x0a\x9c\x7f\x95\
\x00m\
\x00a\x00t\x00c\x00h\x00C\x00a\x00s\x00e\
\x00\x06\
\x06\xd6*\xc2\
\x00f\
\x00o\x00l\x00d\x00e\x00r\
\x00\x08\
\x08\xf0Oe\
\x00m\
\x00a\x00x\x00i\x00m\x00i\x00z\x00e\
\x00\x04\
\x00\x07\xac\xf4\
\x00t\
\x00e\x00x\x00t\
\x00\x11\
\x0b\x82\x94\xd4\
\x00c\
\x00l\x00o\x00s\x00e\x00S\x00m\x00a\x00l\x00l\x00H\x00o\x00v\x00e\x00r\x00e\x00d\
\
\x00\x0a\
\x0a\x93\xf4S\
\x00e\
\x00x\x00a\x00c\x00t\x00W\x00o\x00r\x00d\x00s\
\x00\x04\
\x00\x06\xa6y\
\x00c\
\x00o\x00p\x00y\
\x00\x0f\
\x04\xc1\xfbG\
\x00o\
\x00p\x00e\x00n\x00I\x00n\x00N\x00e\x00w\x00W\x00i\x00n\x00d\x00o\x00w\
\x00\x03\
\x00\x00v\xfe\
\x00p\
\x00i\x00n\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00A\x00\x00\x00D\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x0e\x00\x02\x00\x00\x00A\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x03\xb6\x00\x00\x00\x00\x00\x01\x00\x00`\xc1\
\x00\x00\x01\x99\xa3D+\xb9\
\x00\x00\x02\x96\x00\x00\x00\x00\x00\x01\x00\x00;{\
\x00\x00\x01\x99\xa3D+\xb2\
\x00\x00\x06p\x00\x00\x00\x00\x00\x01\x00\x00\xcc\x0a\
\x00\x00\x01\x99\xa3D+\xb6\
\x00\x00\x06>\x00\x00\x00\x00\x00\x01\x00\x00\xc5\xad\
\x00\x00\x01\x99\xa3D+\xb2\
\x00\x00\x04\xd6\x00\x00\x00\x00\x00\x01\x00\x00\x8e\x1b\
\x00\x00\x01\x99\xa3D+\xb3\
\x00\x00\x00L\x00\x00\x00\x00\x00\x01\x00\x00\x05\x83\
\x00\x00\x01\x99\xa3D+\xb5\
\x00\x00\x04J\x00\x00\x00\x00\x00\x01\x00\x00mz\
\x00\x00\x01\x99\xa3D+\xb6\
\x00\x00\x00\xc6\x00\x00\x00\x00\x00\x01\x00\x00\x0d\x8c\
\x00\x00\x01\x99\xa3D+\xb7\
\x00\x00\x05\xee\x00\x00\x00\x00\x00\x01\x00\x00\xbe\xb4\
\x00\x00\x01\x99\xa3D+\xb8\
\x00\x00\x02\xba\x00\x00\x00\x00\x00\x01\x00\x00D\xc7\
\x00\x00\x01\x99\xa3D+\xb9\
\x00\x00\x02\xc8\x00\x00\x00\x00\x00\x01\x00\x00N\x89\
\x00\x00\x01\x99\xa5\xc8\xdf\xe7\
\x00\x00\x04\xe4\x00\x00\x00\x00\x00\x01\x00\x00\x90\xbc\
\x00\x00\x01\x99\xa5\xc8\xdf\xe6\
\x00\x00\x04\xf4\x00\x00\x00\x00\x00\x01\x00\x00\x92\x88\
\x00\x00\x01\x99\xa3D+\xb6\
\x00\x00\x04:\x00\x00\x00\x00\x00\x01\x00\x00kg\
\x00\x00\x01\x99\xa3D+\xb7\
\x00\x00\x02\x04\x00\x00\x00\x00\x00\x01\x00\x00+\xf1\
\x00\x00\x01\x99\xa3D+\xb3\
\x00\x00\x02V\x00\x00\x00\x00\x00\x01\x00\x006\xfc\
\x00\x00\x01\x99\xa3D+\xb9\
\x00\x00\x03@\x00\x00\x00\x00\x00\x01\x00\x00U\xdf\
\x00\x00\x01\x99\xa3D+\xb7\
\x00\x00\x03\x18\x00\x00\x00\x00\x00\x01\x00\x00S\x8d\
\x00\x00\x01\x99\xa3D+\xb4\
\x00\x00\x01@\x00\x00\x00\x00\x00\x01\x00\x00\x1a|\
\x00\x00\x01\x99\xa3D+\xb1\
\x00\x00\x00n\x00\x00\x00\x00\x00\x01\x00\x00\x07\x91\
\x00\x00\x01\x99\xa3D+\xb8\
\x00\x00\x02v\x00\x00\x00\x00\x00\x01\x00\x009\xee\
\x00\x00\x01\x99\xa3D+\xb8\
\x00\x00\x06L\x00\x00\x00\x00\x00\x01\x00\x00\xc8\xe7\
\x00\x00\x01\x99\xa3D+\xb5\
\x00\x00\x05\x8c\x00\x00\x00\x00\x00\x01\x00\x00\xa8\xda\
\x00\x00\x01\x99\xa3D+\xb6\
\x00\x00\x02,\x00\x00\x00\x00\x00\x01\x00\x00-\xf5\
\x00\x00\x01\x99\xa3D+\xb4\
\x00\x00\x05\x04\x00\x00\x00\x00\x00\x01\x00\x00\x97\x8c\
\x00\x00\x01\x99\xa3D+\xb7\
\x00\x00\x00\xec\x00\x00\x00\x00\x00\x01\x00\x00\x11f\
\x00\x00\x01\x99\xa3D+\xb3\
\x00\x00\x01\xf2\x00\x00\x00\x00\x00\x01\x00\x00'\x03\
\x00\x00\x01\x99\xa3D+\xb0\
\x00\x00\x04j\x00\x00\x00\x00\x00\x01\x00\x00|\xdb\
\x00\x00\x01\x99\xa3D+\xb3\
\x00\x00\x03\xfa\x00\x00\x00\x00\x00\x01\x00\x00g\xa2\
\x00\x00\x01\x99\xa3D+\xb5\
\x00\x00\x05\xc6\x00\x00\x00\x00\x00\x01\x00\x00\xbbc\
\x00\x00\x01\x99\xa3D+\xb4\
\x00\x00\x00\x9a\x00\x00\x00\x00\x00\x01\x00\x00\x096\
\x00\x00\x01\x99\xa3D+\xb4\
\x00\x00\x00:\x00\x00\x00\x00\x00\x01\x00\x00\x019\
\x00\x00\x01\x99\xa3D+\xb6\
\x00\x00\x00Z\x00\x00\x00\x00\x00\x01\x00\x00\x05\x83\
\x00\x00\x01\x99\xa3D+\xb6\
\x00\x00\x03\xd8\x00\x00\x00\x00\x00\x01\x00\x00d\xb4\
\x00\x00\x01\x99\xa3D+\xb8\
\x00\x00\x04X\x00\x00\x00\x00\x00\x01\x00\x00wu\
\x00\x00\x01\x99\xb1T\xf8\xc0\
\x00\x00\x04\x14\x00\x00\x00\x00\x00\x01\x00\x00is\
\x00\x00\x01\x99\xa3D+\xb6\
\x00\x00\x05@\x00\x00\x00\x00\x00\x01\x00\x00\x9f5\
\x00\x00\x01\x99\xa3D+\xb0\
\x00\x00\x04\xa0\x00\x00\x00\x00\x00\x01\x00\x00\x81\x92\
\x00\x00\x01\x99\xa3D+\xb5\
\x00\x00\x01\xd6\x00\x00\x00\x00\x00\x01\x00\x00%R\
\x00\x00\x01\x99\xa3D+\xb2\
\x00\x00\x00\xac\x00\x00\x00\x00\x00\x01\x00\x00\x0c\x9c\
\x00\x00\x01\x99\xa3D+\xb8\
\x00\x00\x02\xde\x00\x00\x00\x00\x00\x01\x00\x00O\xac\
\x00\x00\x01\x99\xa9.&0\
\x00\x00\x05T\x00\x00\x00\x00\x00\x01\x00\x00\xa2\xd5\
\x00\x00\x01\x99\xa3D+\xb7\
\x00\x00\x03\x5c\x00\x00\x00\x00\x00\x01\x00\x00X\x94\
\x00\x00\x01\x99\xa5\xc8\xdf\xe7\
\x00\x00\x05\xd8\x00\x00\x00\x00\x00\x01\x00\x00\xbd\x8c\
\x00\x00\x01\x99\xa5\xc8\xdf\xe7\
\x00\x00\x02\xf2\x00\x00\x00\x00\x00\x01\x00\x00RS\
\x00\x00\x01\x99\xa3D+\xb1\
\x00\x00\x01~\x00\x00\x00\x00\x00\x01\x00\x00\x1d\x11\
\x00\x00\x01\x99\xa3D+\xb2\
\x00\x00\x01b\x00\x00\x00\x00\x00\x01\x00\x00\x1b\xb7\
\x00\x00\x01\x99\xa3D+\xb1\
\x00\x00\x00\x1e\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x99\xa3D+\xb1\
\x00\x00\x03p\x00\x00\x00\x00\x00\x01\x00\x00ZD\
\x00\x00\x01\x99\xa3D+\xb0\
\x00\x00\x03\x84\x00\x00\x00\x00\x00\x01\x00\x00[\xa9\
\x00\x00\x01\x99\xb1#B0\
\x00\x00\x06$\x00\x00\x00\x00\x00\x01\x00\x00\xc4\x18\
\x00\x00\x01\x99\xa3D+\xb3\
\x00\x00\x05\xae\x00\x00\x00\x00\x00\x01\x00\x00\xb1\x1b\
\x00\x00\x01\x99\xa3D+\xb4\
\x00\x00\x03\x98\x00\x00\x00\x00\x00\x01\x00\x00_\x8f\
\x00\x00\x01\x99\xa3D+\xb1\
\x00\x00\x05\xfc\x00\x00\x00\x00\x00\x01\x00\x00\xc0\xa5\
\x00\x00\x01\x99\xa3D+\xb2\
\x00\x00\x00\xd4\x00\x00\x00\x00\x00\x01\x00\x00\x0e\xf5\
\x00\x00\x01\x99\xa3D+\xb1\
\x00\x00\x02\xa2\x00\x00\x00\x00\x00\x01\x00\x00@ \
\x00\x00\x01\x99\xa3D+\xb5\
\x00\x00\x01\x08\x00\x00\x00\x00\x00\x01\x00\x00\x13\xb8\
\x00\x00\x01\x99\xa3D+\xb5\
\x00\x00\x05,\x00\x00\x00\x00\x00\x01\x00\x00\x99\xd7\
\x00\x00\x01\x99\xa3D+\xb9\
\x00\x00\x04\x82\x00\x00\x00\x00\x00\x01\x00\x00~\x8c\
\x00\x00\x01\x99\xc22CP\
\x00\x00\x04\xc0\x00\x00\x00\x00\x00\x01\x00\x00\x82\xb5\
\x00\x00\x01\x99\xa3D+\xb7\
\x00\x00\x01*\x00\x00\x00\x00\x00\x01\x00\x00\x15\x7f\
\x00\x00\x01\x99\xb4\xec!p\
\x00\x00\x03\xc0\x00\x00\x00\x00\x00\x01\x00\x00c{\
\x00\x00\x01\x99\xa3D+\xb1\
\x00\x00\x05h\x00\x00\x00\x00\x00\x01\x00\x00\xa6\x95\
\x00\x00\x01\x99\xa3D+\xb8\
\x00\x00\x01\x98\x00\x00\x00\x00\x00\x01\x00\x00 I\
\x00\x00\x01\x99\xb2p\xa9\xc0\
\x00\x00\x01\xb0\x00\x00\x00\x00\x00\x01\x00\x00#\xbf\
\x00\x00\x01\x99\xb4\xec\xd5 \
\x00\x00\x03\xb6\x00\x00\x00\x00\x00\x01\x00\x012\xe0\
\x00\x00\x01\x99\xa3D+\xb9\
\x00\x00\x02\x96\x00\x00\x00\x00\x00\x01\x00\x01\x0d\x06\
\x00\x00\x01\x99\xa3D+\xb2\
\x00\x00\x06p\x00\x00\x00\x00\x00\x01\x00\x01\xa0z\
\x00\x00\x01\x99\xa3D+\xb6\
\x00\x00\x06>\x00\x00\x00\x00\x00\x01\x00\x01\x9a\x1d\
\x00\x00\x01\x99\xa3D+\xb2\
\x00\x00\x04\xd6\x00\x00\x00\x00\x00\x01\x00\x01a\xf6\
\x00\x00\x01\x99\xa3D+\xb3\
\x00\x00\x00L\x00\x00\x00\x00\x00\x01\x00\x00\xd6d\
\x00\x00\x01\x99\xa3D+\xb6\
\x00\x00\x04J\x00\x00\x00\x00\x00\x01\x00\x01A\xd4\
\x00\x00\x01\x99\xa3D+\xb7\
\x00\x00\x00\xc6\x00\x00\x00\x00\x00\x01\x00\x00\xdd}\
\x00\x00\x01\x99\xa3D+\xb7\
\x00\x00\x05\xee\x00\x00\x00\x00\x00\x01\x00\x01\x93#\
\x00\x00\x01\x99\xa3D+\xb8\
\x00\x00\x02\xba\x00\x00\x00\x00\x00\x01\x00\x01\x16R\
\x00\x00\x01\x99\xa3D+\xb9\
\x00\x00\x02\xc8\x00\x00\x00\x00\x00\x01\x00\x01 \x14\
\x00\x00\x01\x99\xa5\xc8\xdf\xe7\
\x00\x00\x04\xe4\x00\x00\x00\x00\x00\x01\x00\x01d\x97\
\x00\x00\x01\x99\xa5\xc8\xdf\xe6\
\x00\x00\x04\xf4\x00\x00\x00\x00\x00\x01\x00\x01fc\
\x00\x00\x01\x99\xa3D+\xb6\
\x00\x00\x04:\x00\x00\x00\x00\x00\x01\x00\x01=\xeb\
\x00\x00\x01\x99\xa3D+\xb7\
\x00\x00\x02\x04\x00\x00\x00\x00\x00\x01\x00\x00\xfcP\
\x00\x00\x01\x99\xa3D+\xb3\
\x00\x00\x02V\x00\x00\x00\x00\x00\x01\x00\x01\x07[\
\x00\x00\x01\x99\xa3D+\xb9\
\x00\x00\x03@\x00\x00\x00\x00\x00\x01\x00\x01'\xfe\
\x00\x00\x01\x99\xa3D+\xb7\
\x00\x00\x03\x18\x00\x00\x00\x00\x00\x01\x00\x01%\x18\
\x00\x00\x01\x99\xa3D+\xb4\
\x00\x00\x01@\x00\x00\x00\x00\x00\x01\x00\x00\xeb\x01\
\x00\x00\x01\x99\xa3D+\xb1\
\x00\x00\x00n\x00\x00\x00\x00\x00\x01\x00\x00\xd8r\
\x00\x00\x01\x99\xa3D+\xb8\
\x00\x00\x02v\x00\x00\x00\x00\x00\x01\x00\x01\x0a\xe5\
\x00\x00\x01\x99\xa3D+\xb8\
\x00\x00\x06L\x00\x00\x00\x00\x00\x01\x00\x01\x9dW\
\x00\x00\x01\x99\xa3D+\xb5\
\x00\x00\x05\x8c\x00\x00\x00\x00\x00\x01\x00\x01|\xb5\
\x00\x00\x01\x99\xa3D+\xb6\
\x00\x00\x02,\x00\x00\x00\x00\x00\x01\x00\x00\xfeT\
\x00\x00\x01\x99\xa3D+\xb4\
\x00\x00\x05\x04\x00\x00\x00\x00\x00\x01\x00\x01kg\
\x00\x00\x01\x99\xa3D+\xb8\
\x00\x00\x00\xec\x00\x00\x00\x00\x00\x01\x00\x00\xe1W\
\x00\x00\x01\x99\xa3D+\xb3\
\x00\x00\x01\xf2\x00\x00\x00\x00\x00\x01\x00\x00\xf7b\
\x00\x00\x01\x99\xa3D+\xb0\
\x00\x00\x04j\x00\x00\x00\x00\x00\x01\x00\x01Q5\
\x00\x00\x01\x99\xa3D+\xb3\
\x00\x00\x03\xfa\x00\x00\x00\x00\x00\x01\x00\x019\xc1\
\x00\x00\x01\x99\xa3D+\xb5\
\x00\x00\x05\xc6\x00\x00\x00\x00\x00\x01\x00\x01\x8f\xd2\
\x00\x00\x01\x99\xa3D+\xb4\
\x00\x00\x00\x9a\x00\x00\x00\x00\x00\x01\x00\x00\xda\x17\
\x00\x00\x01\x99\xa3D+\xb4\
\x00\x00\x00:\x00\x00\x00\x00\x00\x01\x00\x00\xd2\x1a\
\x00\x00\x01\x99\xa3D+\xb6\
\x00\x00\x00Z\x00\x00\x00\x00\x00\x01\x00\x00\xd6d\
\x00\x00\x01\x99\xa3D+\xb6\
\x00\x00\x03\xd8\x00\x00\x00\x00\x00\x01\x00\x016\xd3\
\x00\x00\x01\x99\xa3D+\xb9\
\x00\x00\x04X\x00\x00\x00\x00\x00\x01\x00\x01K\xcf\
\x00\x00\x01\x99\xb1T\xf8\xc0\
\x00\x00\x04\x14\x00\x00\x00\x00\x00\x01\x00\x01;\xf7\
\x00\x00\x01\x99\xa3D+\xb6\
\x00\x00\x05@\x00\x00\x00\x00\x00\x01\x00\x01s\x10\
\x00\x00\x01\x99\xa3D+\xb0\
\x00\x00\x04\xa0\x00\x00\x00\x00\x00\x01\x00\x01U\xec\
\x00\x00\x01\x99\xa3D+\xb5\
\x00\x00\x01\xd6\x00\x00\x00\x00\x00\x01\x00\x00\xf5\xb1\
\x00\x00\x01\x99\xa3D+\xb2\
\x00\x00\x00\xac\x00\x00\x00\x00\x00\x01\x00\x00\x0c\x9c\
\x00\x00\x01\x99\xa3D+\xb8\
\x00\x00\x02\xde\x00\x00\x00\x00\x00\x01\x00\x01!7\
\x00\x00\x01\x99\xa9.&0\
\x00\x00\x05T\x00\x00\x00\x00\x00\x01\x00\x01v\xb0\
\x00\x00\x01\x99\xa3D+\xb7\
\x00\x00\x03\x5c\x00\x00\x00\x00\x00\x01\x00\x01*\xb3\
\x00\x00\x01\x99\xa5\xc8\xdf\xe7\
\x00\x00\x05\xd8\x00\x00\x00\x00\x00\x01\x00\x01\x91\xfb\
\x00\x00\x01\x99\xa5\xc8\xdf\xe7\
\x00\x00\x02\xf2\x00\x00\x00\x00\x00\x01\x00\x01#\xde\
\x00\x00\x01\x99\xa3D+\xb1\
\x00\x00\x01~\x00\x00\x00\x00\x00\x01\x00\x00\xedp\
\x00\x00\x01\x99\xa3D+\xb2\
\x00\x00\x01b\x00\x00\x00\x00\x00\x01\x00\x00\xec<\
\x00\x00\x01\x99\xa3D+\xb1\
\x00\x00\x00\x1e\x00\x00\x00\x00\x00\x01\x00\x00\xd0\xe1\
\x00\x00\x01\x99\xa3D+\xb1\
\x00\x00\x03p\x00\x00\x00\x00\x00\x01\x00\x01,c\
\x00\x00\x01\x99\xa3D+\xb0\
\x00\x00\x03\x84\x00\x00\x00\x00\x00\x01\x00\x01-\xc8\
\x00\x00\x01\x99\xb1#B0\
\x00\x00\x06$\x00\x00\x00\x00\x00\x01\x00\x01\x98\x88\
\x00\x00\x01\x99\xa3D+\xb3\
\x00\x00\x05\xae\x00\x00\x00\x00\x00\x01\x00\x01\x85\x8a\
\x00\x00\x01\x99\xa3D+\xb4\
\x00\x00\x03\x98\x00\x00\x00\x00\x00\x01\x00\x011\xae\
\x00\x00\x01\x99\xa3D+\xb1\
\x00\x00\x05\xfc\x00\x00\x00\x00\x00\x01\x00\x01\x95\x14\
\x00\x00\x01\x99\xa3D+\xb2\
\x00\x00\x00\xd4\x00\x00\x00\x00\x00\x01\x00\x00\xde\xe6\
\x00\x00\x01\x99\xa3D+\xb1\
\x00\x00\x02\xa2\x00\x00\x00\x00\x00\x01\x00\x01\x11\xab\
\x00\x00\x01\x99\xa3D+\xb5\
\x00\x00\x01\x08\x00\x00\x00\x00\x00\x01\x00\x00\xe4=\
\x00\x00\x01\x99\xa3D+\xb5\
\x00\x00\x05,\x00\x00\x00\x00\x00\x01\x00\x01m\xb2\
\x00\x00\x01\x99\xa3D+\xb9\
\x00\x00\x04\x82\x00\x00\x00\x00\x00\x01\x00\x01R\xe6\
\x00\x00\x01\x99\xc22CP\
\x00\x00\x04\xc0\x00\x00\x00\x00\x00\x01\x00\x01W\x0f\
\x00\x00\x01\x99\xa3D+\xb7\
\x00\x00\x01*\x00\x00\x00\x00\x00\x01\x00\x00\xe6\x04\
\x00\x00\x01\x99\xb4\xec!p\
\x00\x00\x03\xc0\x00\x00\x00\x00\x00\x01\x00\x015\x9a\
\x00\x00\x01\x99\xa3D+\xb1\
\x00\x00\x05h\x00\x00\x00\x00\x00\x01\x00\x01zp\
\x00\x00\x01\x99\xa3D+\xb8\
\x00\x00\x01\x98\x00\x00\x00\x00\x00\x01\x00\x00\xf0\xa8\
\x00\x00\x01\x99\xb2p\xa9\xc0\
\x00\x00\x01\xb0\x00\x00\x00\x00\x00\x01\x00\x00\xf4\x1e\
\x00\x00\x01\x99\xb4\xec\xd5 \
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
