#!/usr/bin/env python3


"stub"


import setuptools


if __name__ == "__main__":
    setuptools.setup(
        scripts=["bin/genocide",]
    )
