Circular doubly linked list data structure.
Emulates Python list behavior and has additional features.
