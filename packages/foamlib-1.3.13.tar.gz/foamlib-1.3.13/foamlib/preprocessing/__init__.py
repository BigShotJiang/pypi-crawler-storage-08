"""The preprocessing module provides tools and utilities for generating and modifying OpenFOAM cases."""
