uv run mcp dev src/prompt_writing_assistant/mcp.py

