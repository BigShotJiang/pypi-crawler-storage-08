from tacotoolbox.sample.validators.tacotiff import TacotiffValidator as TacoTIFF
