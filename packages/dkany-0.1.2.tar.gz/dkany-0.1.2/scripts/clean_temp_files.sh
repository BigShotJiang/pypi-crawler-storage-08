rm -rf ./test-reports/assets
rm -rf ./test-reports/cov

rm -f ./test-reports/*.xml
rm -f ./test-reports/*.html
rm -f ./test-reports/*.txt
