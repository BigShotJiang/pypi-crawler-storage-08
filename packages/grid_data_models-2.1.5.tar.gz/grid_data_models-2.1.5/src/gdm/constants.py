from pydantic import WithJsonSchema

PINT_SCHEMA = WithJsonSchema({"type": "string"})
