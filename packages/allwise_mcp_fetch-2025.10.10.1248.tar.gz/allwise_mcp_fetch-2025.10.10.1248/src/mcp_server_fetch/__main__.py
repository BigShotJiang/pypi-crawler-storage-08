# __main__.py

from mcp_server_fetch import main

main()
