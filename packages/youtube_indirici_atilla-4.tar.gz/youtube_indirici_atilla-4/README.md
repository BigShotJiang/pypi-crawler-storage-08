
# YouTube İndirici Atilla

Bununla YouTube'daki videoları son kalitede kolayca indirebilirsiniz (MP4 (Sesli) ve MP3 (Tek Seçenek)).


## Özellikler

- GUI
- Kolay Kullanım
- MP4 ve MP3
- Versiyon Kontrolü (Kaldırıldı)

  
## Nasıl Kullanılır?

İndirildikten Sonra Konsola Şunu Yazarak Başlatabilirsiniz.
```bash
ytvi
```
### veya
```bash
py -3.13 -m ytvi
```
## Lisans

[MIT](https://choosealicense.com/licenses/mit/)

  