from .getResults import get_results

__version__ = '0.0.8'
