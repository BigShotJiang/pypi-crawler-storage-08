# Plain Dev AGENTS.md

- `plain dev logs`: Show the log output for the running `plain dev` processes
