"""The zebra on i03 and i04 (phase1 beamlines) are configured in a specific way which are compatible to the plans in this module"""
