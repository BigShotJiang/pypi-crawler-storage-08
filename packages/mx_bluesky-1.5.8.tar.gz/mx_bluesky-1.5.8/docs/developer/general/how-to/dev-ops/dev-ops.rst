Dev-Ops guides
==============================

.. toctree::
    :maxdepth: 1
    :glob:

    ./*
