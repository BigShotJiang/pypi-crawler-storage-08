import sys

from .uis.tui.main import main

main(sys.argv[1:])
