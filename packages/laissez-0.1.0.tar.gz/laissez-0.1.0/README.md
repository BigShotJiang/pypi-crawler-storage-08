# Laissez

Agent spending you trust