"""
Minimal setup.py for backward compatibility.
The actual configuration is in pyproject.toml
"""

from setuptools import setup

# For backward compatibility, keep a minimal setup.py
# All configuration is now in pyproject.toml
setup()
