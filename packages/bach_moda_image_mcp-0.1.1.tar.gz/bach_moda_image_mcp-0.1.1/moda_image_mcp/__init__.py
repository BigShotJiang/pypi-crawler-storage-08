"""魔搭图像生成MCP服务器"""

__version__ = "0.1.1"
__author__ = "bachStudio"
__description__ = "MCP服务器用于魔搭图像生成"

from moda_image_mcp.server import main, async_main

__all__ = ["main", "async_main", "__version__"]