# 🏏 BD Sports-10 Dataset (Resized Version)

The **BD Sports-10 Dataset** is a comprehensive collection of **3,000 high-resolution videos** (originally 1920×1080 pixels at 30 frames per second), showcasing **ten culturally and traditionally significant Bangladeshi sports**.  
🔗 **Original Dataset DOI:** [10.57760/sciencedb.24216](https://doi.org/10.57760/sciencedb.24216)

For public research purposes, the dataset has been **resized to 224×224 pixels at 30 FPS**, making it more suitable for **machine learning** and **deep learning** applications.

---

## 🎯 Research Applications

This dataset is designed to support:

- Human action recognition
- Cultural heritage preservation
- Bangladeshi Sports video classification
- Supervised learning tasks
- Deep learning model benchmarking

---

## 📁 Dataset Structure

The `BD_Sports_10` folder contains a `Dataset` directory with **10 subfolders**, each representing a distinct sports class.  
Each class includes **300 videos**, ensuring a **balanced distribution** for supervised learning.

---

## 🏅 Sports Categories

1. Hari Vanga
2. Joldanga
3. Kanamachi
4. Lathim
5. Morog Lorai
6. Toilakto Kolagach Arohon (Kolagach)
7. Nouka Baich
8. Kabaddi
9. Kho Kho
10. Lathi Khela

---

## 📊 Dataset Access

The **BD Sports-10 Dataset** is available in two versions for research use:

- **Resized Version (224×224 pixels)** — optimized for ML/DL tasks  
  [![BD Sports-10 Dataset (224×224 Pixels, Resized Version)](https://img.shields.io/badge/BD_Sports_10_Resized_Version-224x224-blue)](https://data.mendeley.com/datasets/rnh3x48nfb/1)  
  🔗 **Access:** [Mendeley Data](https://data.mendeley.com/datasets/rnh3x48nfb/1)

> 📜 The dataset is licensed under the **Creative Commons Attribution 4.0 International (CC BY 4.0)** license.  
> Proper citation is required when using or redistributing this dataset.

---

## 📜 Citation — BD Sports-10 Dataset (Resized Version)

If you use the **resized version (224×224 pixels)**, please cite:

**APA Citation:**

> Tanzim, W. U., Minhaz Hossain, S. M., Supta, N. B., & Shifatun Nur, S. (2025). _BD Sports-10 Dataset (224×224 Pixels, Resized Version)_ [Data set]. Mendeley Data. [https://doi.org/10.17632/rnh3x48nfb.1](https://doi.org/10.17632/rnh3x48nfb.1)

**BibTeX Citation:**

```bibtex
@misc{Tanzim_BD_Sports_10_Resized_2025,
  author = {Tanzim, Wazih Ullah and Hossain, Syed Md. Minhaz and Supta, Niloy Barua and Shifatun Nur, Shifa},
  title = {{BD Sports-10 Dataset (224×224 Pixels, Resized Version)}},
  year = {2025},
  doi = {10.17632/rnh3x48nfb.1},
  url = {https://doi.org/10.17632/rnh3x48nfb.1},
  publisher = {Mendeley Data},
  version = {V1}
}
```
