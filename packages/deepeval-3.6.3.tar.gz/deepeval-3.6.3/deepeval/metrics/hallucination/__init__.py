from .template import HallucinationTemplate
