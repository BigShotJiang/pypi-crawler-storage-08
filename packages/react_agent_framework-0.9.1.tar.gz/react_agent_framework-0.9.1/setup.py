"""
Setup para instalação do ReAct Agent Framework
"""
from setuptools import setup, find_packages

setup(
    packages=find_packages(include=["react_agent_framework", "react_agent_framework.*"]),
)
