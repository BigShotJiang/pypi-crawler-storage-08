"""Top-level package for rhizonet."""
from . import _version
import sys


__version__ = _version.get_versions()['version']
