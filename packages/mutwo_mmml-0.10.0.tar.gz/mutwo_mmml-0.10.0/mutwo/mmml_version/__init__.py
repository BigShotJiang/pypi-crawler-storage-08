MAJOR, MINOR, PATCH = 0, 10, 0

VERSION = f"{MAJOR}.{MINOR}.{PATCH}"
"""The version of the package ``mutwo.mmml``."""

del MAJOR, MINOR, PATCH
