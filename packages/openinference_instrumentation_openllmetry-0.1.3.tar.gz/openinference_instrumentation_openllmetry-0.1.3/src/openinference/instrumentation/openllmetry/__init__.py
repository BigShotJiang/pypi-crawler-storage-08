from openinference.instrumentation.openllmetry._span_processor import OpenInferenceSpanProcessor

__all__ = ["OpenInferenceSpanProcessor"]
