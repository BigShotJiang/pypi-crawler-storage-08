::: albert.collections.custom_templates.CustomTemplatesCollection
