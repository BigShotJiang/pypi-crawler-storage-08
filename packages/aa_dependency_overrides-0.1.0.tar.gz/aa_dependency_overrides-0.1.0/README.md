# AA Dependency Overrides

[![Version](https://img.shields.io/pypi/v/aa-dependency-overrides?label=release)](https://pypi.org/project/aa-dependency-overrides/)
[![License](https://img.shields.io/github/license/ppfeufer/aa-dependency-overrides)](https://github.com/ppfeufer/aa-dependency-overrides/blob/master/LICENSE)
[![Python](https://img.shields.io/pypi/pyversions/aa-dependency-overrides)](https://pypi.org/project/aa-dependency-overrides/)
![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)
[![pre-commit.ci status](https://results.pre-commit.ci/badge/github/ppfeufer/aa-dependency-overrides/master.svg)](https://results.pre-commit.ci/latest/github/ppfeufer/aa-dependency-overrides/master)
[![Contributor Covenant](https://img.shields.io/badge/Contributor%20Covenant-2.1-4baaaa.svg)](https://github.com/ppfeufer/aa-dependency-overrides/blob/master/CODE_OF_CONDUCT.md)

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/N4N8CL1BY)

Dependency overrides for Alliance Auth, if they are needed.

______________________________________________________________________

<!-- mdformat-toc start --slug=gitlab --maxlevel=6 --minlevel=2 -->

- [Installation](#installation)

<!-- mdformat-toc end -->

______________________________________________________________________

## Installation<a name="installation"></a>

```shell
pip install aa-dependency-overrides==0.1.0
```

Restart supervisor.
