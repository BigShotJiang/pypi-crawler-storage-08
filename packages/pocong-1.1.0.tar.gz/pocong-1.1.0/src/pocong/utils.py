"""Utilities script for pocong."""
