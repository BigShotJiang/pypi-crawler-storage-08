# ape.exceptions

```{eval-rst}
.. automodule:: ape.exceptions
    :members:
    :show-inheritance:
```
