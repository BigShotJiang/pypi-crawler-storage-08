.. click:: ape_test._cli:cli
  :prog: test
  :nested: full
