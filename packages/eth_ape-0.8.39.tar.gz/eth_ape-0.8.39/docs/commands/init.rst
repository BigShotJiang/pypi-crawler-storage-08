.. click:: ape_init._cli:cli
  :prog: init
  :nested: full
