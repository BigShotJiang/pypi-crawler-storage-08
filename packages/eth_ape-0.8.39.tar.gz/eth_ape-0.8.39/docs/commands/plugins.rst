.. click:: ape_plugins._cli:cli
  :prog: plugins
  :nested: full
