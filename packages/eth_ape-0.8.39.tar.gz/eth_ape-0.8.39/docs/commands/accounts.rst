.. click:: ape_accounts._cli:cli
  :prog: accounts
  :nested: full
