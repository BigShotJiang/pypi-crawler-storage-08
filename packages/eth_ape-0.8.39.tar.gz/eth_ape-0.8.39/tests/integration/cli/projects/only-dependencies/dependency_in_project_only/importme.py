def import_me():
    print("I was imported and then called")
