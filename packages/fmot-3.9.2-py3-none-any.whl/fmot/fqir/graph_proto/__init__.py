from .graph_proto import GraphProto
