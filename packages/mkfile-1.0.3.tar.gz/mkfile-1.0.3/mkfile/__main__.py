from .mkfile import main

def usage():
	main()

if __name__ == '__main__':
	usage()