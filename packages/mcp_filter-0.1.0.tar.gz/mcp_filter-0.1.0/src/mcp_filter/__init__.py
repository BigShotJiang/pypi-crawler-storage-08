"""Top-level package for mcp-filter."""

from .version import __version__

__all__ = ["__version__"]
