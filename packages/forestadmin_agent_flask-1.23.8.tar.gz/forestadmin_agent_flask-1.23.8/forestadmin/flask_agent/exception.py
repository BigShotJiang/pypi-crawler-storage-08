from forestadmin.datasource_toolkit.exceptions import ForestException


class FlaskAgentException(ForestException):
    pass
