"""Syslog server and handler"""
