"""Syslog server"""
