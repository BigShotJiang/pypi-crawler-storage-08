"""Allow running Neo as a module: python -m neo"""

from neo.cli import main

if __name__ == "__main__":
    main()
