---
description: Ask Neo for semantic reasoning and code suggestions
argument-hint: [your question]
---

Use the Neo agent to analyze this request using semantic memory and multi-agent reasoning:

$ARGUMENTS

Please gather relevant context from the codebase first, then query Neo with specific details.
