# Anisette.py

## Jump To

[//]: # (This is hidden to prevent it from showing on the home page)
```{toctree}
:hidden:
Home <self>
```

[//]: # (Show these with a maxdepth of 1)
```{toctree}
:maxdepth: 1
API Reference <autoapi/anisette/index>
genindex
```
