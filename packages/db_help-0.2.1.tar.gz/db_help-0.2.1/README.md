qdrant

index 

构建关键词搜索和 id搜索


## 做到prompt_writing_herper 中 目标是, 无论什么, 随便扔进去, 然后取的时候直接取即可

## 然后做code自动化编写的coder 写完之后写豆包语音智能体的链接, mcp协议 然后重构一些, obsidian 的SDK
