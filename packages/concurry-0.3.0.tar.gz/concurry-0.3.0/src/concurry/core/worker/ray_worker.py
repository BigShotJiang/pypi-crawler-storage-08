"""Ray-based worker implementation for concurry."""

import asyncio
import inspect
import threading
from typing import Any, Dict, Optional, Union

from morphic.structs import map_collection
from pydantic import PrivateAttr

from ..config import ExecutionMode
from ..future import RayFuture
from .base_worker import WorkerProxy, _create_worker_wrapper

# Note: Ray has native support for async methods in actors.
# When you define an async method in a Ray actor and call it with .remote(),
# Ray automatically handles the async execution.
#
# TODO: For optimal async performance with Ray, we could:
# 1. Detect async methods and use Ray's async actor APIs
# 2. Leverage Ray's asyncio integration for concurrent task execution
# 3. Use Ray's async/await support for better concurrency within actors
#
# For now, Ray's default behavior correctly executes async functions,
# though it may not provide the same level of concurrent execution as
# a dedicated event loop (like AsyncioWorkerProxy).


def _unwrap_future_for_ray(obj: Any) -> Any:
    """Unwrap futures for Ray, preserving ObjectRefs for zero-copy.

    RayFuture → ObjectRef (zero-copy for top-level args, resolved for nested)
    Other BaseFuture → .result() (materialize)
    Non-future → unchanged

    Note: Ray automatically unwraps top-level ObjectRef arguments but NOT
    ObjectRefs nested in collections. This function handles both cases.

    Args:
        obj: Object that might be a BaseFuture

    Returns:
        ObjectRef if obj is RayFuture (zero-copy),
        materialized value if obj is other BaseFuture,
        otherwise obj unchanged
    """
    from ..future import BaseFuture

    if isinstance(obj, RayFuture):
        # Zero-copy: pass ObjectRef directly
        return obj._object_ref
    elif isinstance(obj, BaseFuture):
        # Cross-worker: materialize value
        return obj.result()
    return obj


def _resolve_nested_objectrefs(obj: Any) -> Any:
    """Resolve ObjectRefs that are nested in collections.

    Ray automatically unwraps top-level ObjectRef arguments, but ObjectRefs
    nested in collections (lists, dicts, etc.) must be explicitly resolved.

    Args:
        obj: Object that might be an ObjectRef

    Returns:
        Resolved value if obj is an ObjectRef, otherwise obj unchanged
    """
    import ray

    if isinstance(obj, ray.ObjectRef):
        return ray.get(obj)
    return obj


def _unwrap_futures_for_ray(
    args: tuple,
    kwargs: dict,
    unwrap_futures: bool,
) -> tuple:
    """Ray-specific unwrapping with zero-copy optimization.

    Recursively traverses nested collections and:
    - Extracts ObjectRef from RayFuture (zero-copy)
    - Materializes other BaseFuture types via .result()
    - Resolves nested ObjectRefs (Ray limitation workaround)
    - Leaves non-future values unchanged

    Args:
        args: Positional arguments
        kwargs: Keyword arguments
        unwrap_futures: Whether to perform unwrapping

    Returns:
        Tuple of (unwrapped_args, unwrapped_kwargs)
    """
    if not unwrap_futures:
        return args, kwargs

    # Step 1: Unwrap BaseFuture instances to ObjectRefs or values
    unwrapped_args = tuple(map_collection(arg, _unwrap_future_for_ray, recurse=True) for arg in args)

    unwrapped_kwargs = {
        key: map_collection(value, _unwrap_future_for_ray, recurse=True) for key, value in kwargs.items()
    }

    # Step 2: Resolve any ObjectRefs that are nested in collections
    # Ray only auto-unwraps top-level ObjectRef args, not nested ones
    resolved_args = tuple(
        map_collection(arg, _resolve_nested_objectrefs, recurse=True) for arg in unwrapped_args
    )

    resolved_kwargs = {
        key: map_collection(value, _resolve_nested_objectrefs, recurse=True)
        for key, value in unwrapped_kwargs.items()
    }

    return resolved_args, resolved_kwargs


class RayWorkerProxy(WorkerProxy):
    """Worker proxy for Ray-based execution.

    This proxy uses Ray actors to execute methods in a distributed manner.

    **Default Resource Allocation:**

    - `num_cpus = 1`: Each Ray actor is allocated 1 CPU by default
    - `num_gpus = 0`: No GPU allocation by default
    - `resources = None`: No custom resources by default

    These defaults ensure Ray actors are created without requiring explicit
    resource specifications, while still allowing users to override as needed.

    **Exception Handling:**

    - Setup errors (e.g., `AttributeError` for non-existent methods) fail immediately
    - Execution errors are wrapped by Ray in `RayTaskError` (Ray's standard behavior)
    - Original exception information is preserved in the Ray error message

    **Async Function Support:**

    Ray has native support for async methods in actors - they work automatically.
    For TaskWorker with async functions, they are wrapped to execute correctly
    but won't provide the same concurrency benefits as `AsyncioWorkerProxy`.

    **Future Unwrapping with Zero-Copy Optimization:**

    When passing RayFuture instances from one Ray worker to another, the underlying
    ObjectRef is passed directly (zero-copy), avoiding data serialization. For futures
    from other worker types, values are materialized before passing. This optimization
    is automatic when `unwrap_futures=True` (default).

    **Example:**

        ```python
        import asyncio

        class MyWorker(Worker):
            async def async_method(self, x: int) -> int:
                await asyncio.sleep(0.01)
                return x * 2

        # Use defaults (1 CPU, 0 GPUs)
        w = MyWorker.options(mode="ray").init()
        result = w.async_method(5).result()  # Works with Ray's native async support

        # Override resources
        w = MyWorker.options(mode="ray", num_cpus=2, num_gpus=1).init()

        # Specify custom resources
        w = MyWorker.options(
            mode="ray",
            resources={"special_hardware": 1}
        ).init()

        w.stop()
        ```
    """

    num_cpus: float = 1  # Default to 1 CPU
    num_gpus: float = 0  # Default to 0 GPUs
    resources: Optional[Dict[str, Union[int, float]]] = None

    # Private attributes
    _ray_actor: Any = PrivateAttr()
    _futures: Dict[str, Any] = PrivateAttr()  # Maps future.uuid -> RayFuture
    _futures_lock: Any = PrivateAttr()

    def post_initialize(self) -> None:
        """Initialize private attributes after Typed validation."""
        super().post_initialize()

        # Initialize futures tracking
        self._futures = {}  # future.uuid -> RayFuture
        self._futures_lock = threading.Lock()

        # Create Ray actor (uses public fields directly)
        self._ray_actor = self._create_ray_actor()

    def _create_ray_actor(self):
        """Create a Ray actor from the worker class.

        Returns:
            Ray actor handle
        """
        try:
            import ray
        except ImportError:
            raise ImportError("Ray is required for RayWorker. Install with: pip install ray")

        # Check if Ray is initialized
        if not ray.is_initialized():
            raise RuntimeError("Ray is not initialized. Call ray.init() before creating Ray workers.")

        # Create Ray actor options using public fields
        actor_options = {}
        if self.num_cpus is not None:
            actor_options["num_cpus"] = self.num_cpus
        if self.num_gpus is not None:
            actor_options["num_gpus"] = self.num_gpus
        if self.resources is not None:
            actor_options["resources"] = self.resources

        # Add any additional options from kwargs
        for key, value in self._options.items():
            actor_options[key] = value

        # Process limits for worker
        processed_limits = self._process_limits_for_worker(worker_mode=ExecutionMode.Ray)

        # If limits are provided, create a wrapper class
        if processed_limits is not None:
            # Create a wrapper class that injects limits
            worker_cls_to_use = _create_worker_wrapper(self.worker_cls, processed_limits)
        else:
            worker_cls_to_use = self.worker_cls

        # Create the Ray actor
        # Note: Ray 2.50+ doesn't accept ray.remote(**{}) with an empty dict
        # so we only pass options if the dict is not empty
        if actor_options:
            ray_actor_cls = ray.remote(**actor_options)(worker_cls_to_use)
        else:
            ray_actor_cls = ray.remote(worker_cls_to_use)

        return ray_actor_cls.remote(*self.init_args, **self.init_kwargs)

    def _execute_method(self, method_name: str, *args: Any, **kwargs: Any):
        """Execute a method on the Ray actor.

        Args:
            method_name: Name of the method to invoke
            *args: Positional arguments
            **kwargs: Keyword arguments

        Returns:
            RayFuture for the method execution

        Raises:
            AttributeError: If the method doesn't exist on the actor
            Exception: Any immediate errors during method invocation setup
        """
        # Unwrap futures with Ray zero-copy optimization
        args, kwargs = _unwrap_futures_for_ray(args, kwargs, self.unwrap_futures)

        # Don't catch exceptions - let them propagate immediately for fast failure
        # This ensures errors like AttributeError (method not found) fail immediately
        # rather than being wrapped in a future
        ray_method = getattr(self._ray_actor, method_name)
        object_ref = ray_method.remote(*args, **kwargs)
        future = RayFuture(object_ref=object_ref)

        # Store future for cancellation on stop()
        with self._futures_lock:
            self._futures[future.uuid] = future

        return future

    def _execute_task(self, fn, *args: Any, **kwargs: Any):
        """Execute an arbitrary function on the Ray actor.

        Args:
            fn: Callable function to execute
            *args: Positional arguments
            **kwargs: Keyword arguments

        Returns:
            RayFuture for the task execution

        Raises:
            ImportError: If Ray is not available
            Exception: Any immediate errors during task submission setup
        """
        # Unwrap futures with Ray zero-copy optimization
        args, kwargs = _unwrap_futures_for_ray(args, kwargs, self.unwrap_futures)

        # Don't catch exceptions - let them propagate immediately for fast failure
        import ray

        # Ray doesn't support async functions directly in ray.remote() for tasks
        # We need to wrap them to use asyncio.run()
        if inspect.iscoroutinefunction(fn):
            # Capture the async function in a closure
            async_fn = fn

            # Wrap the async function in a sync wrapper
            def sync_wrapper(*args, **kwargs):
                return asyncio.run(async_fn(*args, **kwargs))

            # Use the wrapper instead
            fn = sync_wrapper

        # Create a remote function and execute it on the actor's resources
        # We'll use ray.remote to make the function remote, then call it
        remote_fn = ray.remote(fn)

        # Execute with the same resources as the actor (use public fields)
        options = {}
        if self.num_cpus is not None:
            options["num_cpus"] = self.num_cpus
        if self.num_gpus is not None:
            options["num_gpus"] = self.num_gpus
        if self.resources is not None:
            options["resources"] = self.resources

        if options:
            remote_fn = remote_fn.options(**options)

        object_ref = remote_fn.remote(*args, **kwargs)
        future = RayFuture(object_ref=object_ref)

        # Store future for cancellation on stop()
        with self._futures_lock:
            self._futures[future.uuid] = future

        return future

    def stop(self, timeout: float = 30) -> None:
        """Stop the Ray actor.

        Args:
            timeout: Maximum time to wait for actor to stop (currently ignored for Ray)
        """
        super().stop(timeout)

        # Cancel all pending futures
        with self._futures_lock:
            for future in self._futures.values():
                future.cancel()
            self._futures.clear()

        try:
            import ray

            ray.kill(self._ray_actor)
        except Exception:
            pass
