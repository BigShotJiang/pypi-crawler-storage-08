"""Tests for future module."""
