from accli.cli import app as cli_app

if __name__ == "__main__":
    cli_app()