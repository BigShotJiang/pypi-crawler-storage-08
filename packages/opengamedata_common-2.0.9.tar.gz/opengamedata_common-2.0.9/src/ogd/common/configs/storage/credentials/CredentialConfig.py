from typing import TypeAlias
from ogd.common.configs.Config import Config

CredentialConfig : TypeAlias = Config
