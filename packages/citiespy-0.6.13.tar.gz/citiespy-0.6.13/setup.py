from setuptools import setup

setup(
    name="citiespy",
    url="https://github.com/ringsaturn/go-cities.json/blob/main/citiespy"
)
