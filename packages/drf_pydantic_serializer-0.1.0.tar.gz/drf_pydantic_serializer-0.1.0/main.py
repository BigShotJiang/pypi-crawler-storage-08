def main():
    print("Hello from drf-pydantic-basemodel!")


if __name__ == "__main__":
    main()
