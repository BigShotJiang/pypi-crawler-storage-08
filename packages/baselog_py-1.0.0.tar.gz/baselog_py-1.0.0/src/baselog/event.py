


class Event:
    pass 