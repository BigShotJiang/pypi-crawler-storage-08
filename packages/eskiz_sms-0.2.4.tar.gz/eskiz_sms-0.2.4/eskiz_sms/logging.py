import logging

logger = logging.getLogger("eskiz_sms")
