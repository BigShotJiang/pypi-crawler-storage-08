"""Package information."""

__version__ = "8.3.0"
__build__ = "2025091510"
