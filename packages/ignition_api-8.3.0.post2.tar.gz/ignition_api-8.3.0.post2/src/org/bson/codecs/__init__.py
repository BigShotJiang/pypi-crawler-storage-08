class Codec(object):
    pass
