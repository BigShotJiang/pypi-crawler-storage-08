__all__ = ["FragileRunnable"]


class FragileRunnable(object):
    def run(self):
        # type: () -> None
        raise NotImplementedError
