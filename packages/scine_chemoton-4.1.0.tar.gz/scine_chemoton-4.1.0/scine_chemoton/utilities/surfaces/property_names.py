#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__copyright__ = """ This code is licensed under the 3-clause BSD license.
Copyright ETH Zurich, Department of Chemistry and Applied Biosciences, Reiher Group.
See LICENSE.txt for details.
"""
slab_formula_str = 'slab_formula'
surface_atom_indices_str = 'surface_atom_indices'
primitive_lattice_str = 'primitive_lattice'
