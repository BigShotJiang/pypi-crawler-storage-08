.. scine_chemoton master file

Chemoton
========

.. image:: res/chemoton_header.png
   :width: 100 %
   :alt: Chemoton

.. toctree::
   :maxdepth: 3

   readme
   api/api
   changelog
