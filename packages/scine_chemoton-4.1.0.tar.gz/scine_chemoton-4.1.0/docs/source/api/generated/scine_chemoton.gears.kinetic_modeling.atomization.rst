scine\_chemoton.gears.kinetic\_modeling.atomization
===================================================

.. automodule:: scine_chemoton.gears.kinetic_modeling.atomization

   
   .. rubric:: Classes

   .. autosummary::
   
      AtomEnergyReference
      MultiModelEnergyReferences
      PlaceHolderMultiModelEnergyReferences
      ZeroEnergyReference
   