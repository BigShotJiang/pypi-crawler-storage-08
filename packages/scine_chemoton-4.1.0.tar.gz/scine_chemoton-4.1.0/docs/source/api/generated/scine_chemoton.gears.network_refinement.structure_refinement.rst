scine\_chemoton.gears.network\_refinement.structure\_refinement
===============================================================

.. automodule:: scine_chemoton.gears.network_refinement.structure_refinement

   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   minimum_structure_reoptimization
   ts_refinement
