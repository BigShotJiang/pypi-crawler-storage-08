scine\_chemoton.gears.kinetic\_modeling
=======================================

.. automodule:: scine_chemoton.gears.kinetic_modeling

   
   .. rubric:: Classes

   .. autosummary::
   
      KineticModeling
   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   atomization
   kinetx_kinetic_modeling
   prepare_kinetic_modeling_job
   rms_kinetic_modeling
   rms_microcanonical_kinetic_modeling
   rms_network_extractor
