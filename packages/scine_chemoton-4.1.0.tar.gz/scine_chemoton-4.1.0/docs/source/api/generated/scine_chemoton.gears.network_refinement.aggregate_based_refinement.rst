scine\_chemoton.gears.network\_refinement.aggregate\_based\_refinement
======================================================================

.. automodule:: scine_chemoton.gears.network_refinement.aggregate_based_refinement

   
   .. rubric:: Classes

   .. autosummary::
   
      AggregateBasedRefinement
   