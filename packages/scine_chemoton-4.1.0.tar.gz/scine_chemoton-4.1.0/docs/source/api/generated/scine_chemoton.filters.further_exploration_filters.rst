scine\_chemoton.filters.further\_exploration\_filters
=====================================================

.. automodule:: scine_chemoton.filters.further_exploration_filters

   
   .. rubric:: Functions

   .. autosummary::
   
      single_structure_assertion
   
   .. rubric:: Classes

   .. autosummary::
   
      AllBarrierLessDissociationsFilter
      FurtherExplorationFilter
      FurtherExplorationFilterAndArray
      FurtherExplorationFilterOrArray
      ReactionCoordinateMaxDissociationEnergyFilter
   