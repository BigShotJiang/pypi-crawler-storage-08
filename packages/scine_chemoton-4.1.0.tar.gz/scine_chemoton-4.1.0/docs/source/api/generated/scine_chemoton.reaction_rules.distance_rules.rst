scine\_chemoton.reaction\_rules.distance\_rules
===============================================

.. automodule:: scine_chemoton.reaction_rules.distance_rules

   
   .. rubric:: Classes

   .. autosummary::
   
      AlwaysFalse
      AlwaysTrue
      DistanceBaseRule
      DistanceRuleAndArray
      DistanceRuleOrArray
      DistanceRuleSet
      FunctionalGroupRule
      SimpleDistanceRule
   