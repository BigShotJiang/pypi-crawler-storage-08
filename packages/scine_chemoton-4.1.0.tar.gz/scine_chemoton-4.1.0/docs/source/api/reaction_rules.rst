Optional Reaction Rules
=======================

Some reactive site filters allow specifying a set of reaction rules.
The different types of reaction rules are defined here.

.. autosummary::
   :toctree: generated
   :recursive:

   scine_chemoton.reaction_rules

