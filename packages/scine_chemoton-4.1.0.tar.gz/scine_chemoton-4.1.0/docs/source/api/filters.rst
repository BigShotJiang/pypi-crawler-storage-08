Filters
=======

Chemoton per default considers every aggregate, reactive site, elementary step etc.
as valid/active for reaction trials. However, they can be limited with so-called filters.
All Filters have a default implementation that does not filter anything.

.. autosummary::
   :toctree: generated
   :recursive:

   scine_chemoton.filters
