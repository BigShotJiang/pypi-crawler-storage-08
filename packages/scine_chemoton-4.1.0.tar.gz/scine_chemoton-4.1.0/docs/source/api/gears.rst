Gears
=====

Interface
---------
.. autoclass:: scine_chemoton.gears.Gear
    :special-members: __call__
    :noindex:

Implementations
---------------

.. autosummary::
   :toctree: generated
   :recursive:

   scine_chemoton.gears

