.. _README:

######
README
######

.. include:: README.txt
    :start-after: inclusion-marker-do-not-remove
