from setuptools import setup

# This file exists for backward compatibility with tools that don't support pyproject.toml
# All configuration is in pyproject.toml

setup()
