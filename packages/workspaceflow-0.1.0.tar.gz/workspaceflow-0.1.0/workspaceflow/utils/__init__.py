"""Utility functions for workspaceflow"""

from workspaceflow.utils.slug import generate_slug, is_valid_slug

__all__ = ["generate_slug", "is_valid_slug"]
