This module allows you to register non deductible VAT from Invoices or
Stock Operations.
