"""Adapters for various frameworks."""

__all__ = []
