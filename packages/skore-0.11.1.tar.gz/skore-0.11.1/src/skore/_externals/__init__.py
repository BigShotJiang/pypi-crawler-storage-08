"""Module for vendoring external dependencies."""
