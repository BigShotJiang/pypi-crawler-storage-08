"""Alias top level function and class of the project submodule."""

from skore.project.project import Project

__all__ = ["Project"]
