from skore._sklearn._plot.data.table_report import TableReportDisplay

__all__ = ["TableReportDisplay"]
