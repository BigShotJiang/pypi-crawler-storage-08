"""
Tests for stemming module
"""
