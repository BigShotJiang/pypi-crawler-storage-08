"""
Tests for preprocessing module
"""
