"""
Lemmatization module for Persian text
"""

from .persian_lemmatizer import PersianLemmatizer

__all__ = ['PersianLemmatizer']
