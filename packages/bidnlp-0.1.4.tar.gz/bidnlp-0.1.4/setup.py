"""
BidNLP - A Comprehensive Persian (Farsi) Natural Language Processing Library

This file provides backward compatibility for older pip versions.
The actual package configuration is in pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
