At the time of writing this, latest version of wrapt hasn't been uploaded to pypi.
This is the latest version plus some modifications to ObjectProxy and AutoObjectProxy.