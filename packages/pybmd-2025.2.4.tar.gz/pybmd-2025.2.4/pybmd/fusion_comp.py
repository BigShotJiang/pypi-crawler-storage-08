class FusionComp():
    """Fusion Composite Object"""
    def __init__(self, fusion_comp):
        self._fusion_comp = fusion_comp
        
    

    