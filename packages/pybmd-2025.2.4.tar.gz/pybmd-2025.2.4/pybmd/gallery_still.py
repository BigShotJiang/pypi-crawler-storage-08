class GalleryStill():
    """GalleryStill Object"""
    def __init__(self, gallery_still):
        self._gallery_still = gallery_still

    