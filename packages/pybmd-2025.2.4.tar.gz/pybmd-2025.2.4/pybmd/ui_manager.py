class UI_Manager(object):
    """docstring for UI_Manager."""
    def __init__(self, ui_manager):
        self._ui_manager = ui_manager

    