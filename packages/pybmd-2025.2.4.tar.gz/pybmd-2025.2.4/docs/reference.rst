API Reference
================

.. autosummary::
   :toctree: _autosummary
   :template: module.rst
   :recursive:

   pybmd


Indices and search
------------------

* :ref:`genindex`
* :ref:`search`