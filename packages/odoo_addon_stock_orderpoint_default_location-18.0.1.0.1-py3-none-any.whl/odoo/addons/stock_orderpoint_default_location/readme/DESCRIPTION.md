This module allows to define a different default location than the 'Stock Location'.
