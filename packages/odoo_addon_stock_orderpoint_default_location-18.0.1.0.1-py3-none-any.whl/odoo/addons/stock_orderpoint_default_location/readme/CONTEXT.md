In some advanced configurations, stock orderpoints could have a different replenishment
location than the warehouse 'Stock Location'.

In order to get that different replenishment location by default, a new field should be
necessary on warehouses to define that new default value.
