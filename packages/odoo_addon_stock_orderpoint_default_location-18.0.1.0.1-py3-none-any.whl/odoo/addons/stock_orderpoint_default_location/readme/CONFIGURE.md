To set a different default location for new orderpoints:

#. Go to Inventory > Settings > Warehouse #. Enable 'Storage Locations' and 'Multi-Step
Routes'

#. Go to Inventory > Warehouse Management > Warehouses #. Pick the one you want to
modify #. In the 'Warehouse Configuration' tab > Default Orderpoint Location, select the
one you want as default for new orderpoints.
