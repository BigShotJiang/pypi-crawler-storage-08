"""Equity Data."""
