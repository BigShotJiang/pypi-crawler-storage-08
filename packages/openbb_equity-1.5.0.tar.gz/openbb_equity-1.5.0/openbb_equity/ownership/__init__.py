"""Equity Ownership."""
