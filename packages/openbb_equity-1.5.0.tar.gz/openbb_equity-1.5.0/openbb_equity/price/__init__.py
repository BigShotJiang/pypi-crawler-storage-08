"""Equity Price."""
