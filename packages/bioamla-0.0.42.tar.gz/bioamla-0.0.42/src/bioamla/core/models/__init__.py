"""Data Models

This package contains data model definitions and schemas used throughout
the bioamla package for audio processing and API interfaces.
"""