"""SmartCocoon API REST Client."""
