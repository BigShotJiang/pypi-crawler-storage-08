"""Function meant to be run by github action to set a new version tag"""
import os
import re
import subprocess




def main():







if __name__ == "__main__":
    main()
