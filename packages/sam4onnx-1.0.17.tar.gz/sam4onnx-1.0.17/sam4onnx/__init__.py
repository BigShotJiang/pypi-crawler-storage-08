from sam4onnx.onnx_attr_const_modify import modify, main

__version__ = '1.0.17'
