Создай дополнительный модуль queues, который будет содержать подмодули и методы

queues.create()
https://yandex.ru/support/tracker/ru/concepts/queues/create-queue

queues.get()
https://yandex.ru/support/tracker/ru/concepts/queues/get-queue
https://yandex.ru/support/tracker/ru/concepts/queues/get-queues

queues.delete()
https://yandex.ru/support/tracker/ru/concepts/queues/delete-queue

queues.restore()
https://yandex.ru/support/tracker/ru/concepts/queues/restore-queue

queues.versions.create()/get()
https://yandex.ru/support/tracker/ru/concepts/queues/create-version
https://yandex.ru/support/tracker/ru/concepts/queues/get-versions

queues.fields.get()
https://yandex.ru/support/tracker/ru/concepts/queues/get-fields

queues.tags.get()/delete()
https://yandex.ru/support/tracker/ru/concepts/queues/get-tags
https://yandex.ru/support/tracker/ru/concepts/queues/delete-tag

queues.bulk.create()
https://yandex.ru/support/tracker/ru/concepts/queues/manage-access

queues.user.get()
https://yandex.ru/support/tracker/ru/concepts/queues/get-user-access

queues.group.get()
https://yandex.ru/support/tracker/ru/concepts/queues/get-group-access