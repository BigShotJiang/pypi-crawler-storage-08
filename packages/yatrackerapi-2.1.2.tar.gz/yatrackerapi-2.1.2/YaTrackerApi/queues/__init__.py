"""
API модуль для работы с очередями (Queues) в Yandex Tracker
"""

from .api import QueuesAPI

__all__ = ['QueuesAPI']
