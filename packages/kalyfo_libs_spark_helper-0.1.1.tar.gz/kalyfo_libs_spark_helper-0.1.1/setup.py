"""Setup configuration for spark-helper package."""
from setuptools import setup

# This file is kept for backward compatibility
# All configuration is now in pyproject.toml
setup()
