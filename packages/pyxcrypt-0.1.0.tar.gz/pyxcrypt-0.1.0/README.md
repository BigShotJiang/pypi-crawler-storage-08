# pyxcrypt
Simple python3 bindings to libxrcypt[1].



# Links
[1] - https://github.com/besser82/libxcrypt
