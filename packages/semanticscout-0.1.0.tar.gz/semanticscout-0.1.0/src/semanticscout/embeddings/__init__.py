"""Embedding generation providers for converting code to vectors."""


