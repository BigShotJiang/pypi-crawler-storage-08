.. Nero Workgroup Creator documentation master file, created by
   sphinx-quickstart on Wed Jun  9 11:35:48 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../README.rst

.. toctree::
   :hidden:

   client
   account
   workgroup
   changes

   genindex
