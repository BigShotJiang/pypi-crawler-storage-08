"""Widgets for displaying data (sinogram, browsing scans, display reconstructed volumes...)"""
