.. _internals:

=====================
Внутреннее устройство
=====================

.. toctree::
   :maxdepth: 2

   dict
   prediction
   char-substitutes
