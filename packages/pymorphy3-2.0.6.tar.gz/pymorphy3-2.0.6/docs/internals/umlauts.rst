:orphan:

См. :ref:`char-substitutes`.
