
.. include:: ../../AUTHORS.rst
