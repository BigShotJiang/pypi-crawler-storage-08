* new file formats
  * DJVU
  * INDD
  * WOFF2
* expand file formats
  * Jpeg XL
  * DICOM
* more consistent naming convention
* backends (process the json blob)
  * exiftool-like output
  * filtering/labeling files (e.g. "files that have a gps coordinate in the northern hemisphere")
  * plugins (?)
