"""
Protocol compliance testing infrastructure.

This module provides utilities for testing that services properly implement
their protocol interfaces.
"""
