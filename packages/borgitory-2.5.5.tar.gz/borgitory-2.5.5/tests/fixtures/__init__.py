"""
Test fixtures for Borgitory application.

This module provides shared fixtures and utilities for testing across the application.
"""
