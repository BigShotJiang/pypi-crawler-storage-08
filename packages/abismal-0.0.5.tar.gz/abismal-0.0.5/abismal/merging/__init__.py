from .merging import VariationalMergingModel
