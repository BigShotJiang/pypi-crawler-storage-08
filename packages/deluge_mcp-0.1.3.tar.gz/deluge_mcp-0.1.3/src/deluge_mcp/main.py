#!/usr/bin/env python3
import asyncio
import logging
import sys
from typing import Any

from mcp.server import Server
from mcp.types import Tool, TextContent
import mcp.server.stdio

# Configure logging with more detail for debugging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stderr)],
)
logger = logging.getLogger("deluge-mcp")

# Create the MCP server
server = Server("deluge-mcp")


async def run_deluge_command(command: str) -> dict[str, Any]:
    """
    Run a deluge-console command asynchronously.

    Args:
        command: The deluge-console command to run

    Returns:
        dict with 'success', 'output', and optionally 'error'
    """
    logger.debug(f"Running deluge command: {command}")
    try:
        process = await asyncio.create_subprocess_exec(
            "deluge-console",
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        stdout, stderr = await process.communicate()

        if process.returncode == 0:
            output = stdout.decode("utf-8").strip()
            logger.debug(f"Command succeeded. Output length: {len(output)}")
            return {
                "success": True,
                "output": output,
            }
        else:
            error = stderr.decode("utf-8").strip()
            output = stdout.decode("utf-8").strip()
            logger.error(
                f"Command failed with code {process.returncode}: {error}"
            )
            return {
                "success": False,
                "error": error,
                "output": output,
            }

    except Exception as e:
        logger.error(f"Error running deluge command: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available MCP tools."""
    return [
        Tool(
            name="get_running_torrents",
            description="Get information about all running torrents in Deluge. Returns details like name, state, progress, speeds, etc.",  # fmt: skip
            inputSchema={
                "type": "object",
                "properties": {},
                "required": [],
            },
        ),
        Tool(
            name="add_torrent_magnet",
            description="Add a new torrent to Deluge using a magnet URL. The magnet URL must start with 'magnet:'.",  # fmt: skip
            inputSchema={
                "type": "object",
                "properties": {
                    "magnet_url": {
                        "type": "string",
                        "description": "The magnet URL of the torrent to add (must start with 'magnet:')",  # fmt: skip
                    }
                },
                "required": ["magnet_url"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: Any) -> list[TextContent]:
    """Handle tool execution requests."""
    logger.info(f"Tool called: {name} with arguments: {arguments}")

    if name == "get_running_torrents":
        result = await run_deluge_command("info")

        if result["success"]:
            return [
                TextContent(
                    type="text",
                    text=f"Running Torrents:\n\n{result['output']}",
                )
            ]
        else:
            error_msg = result.get("error", "Unknown error")
            return [
                TextContent(
                    type="text",
                    text=f"Error getting torrents: {error_msg}",
                )
            ]

    elif name == "add_torrent_magnet":
        magnet_url = arguments.get("magnet_url", "")

        # Validate magnet URL
        if not magnet_url.startswith("magnet:"):
            return [
                TextContent(
                    type="text",
                    text="Error: Invalid magnet URL. Must start with 'magnet:'",  # fmt: skip
                )
            ]

        # Add the torrent
        result = await run_deluge_command(f"add {magnet_url}")

        if result["success"]:
            return [
                TextContent(
                    type="text",
                    text=f"Torrent added successfully!\n\nOutput: {result['output']}",  # fmt: skip
                )
            ]
        else:
            error_msg = result.get("error", "Unknown error")
            return [
                TextContent(
                    type="text",
                    text=f"Error adding torrent: {error_msg}",
                )
            ]

    else:
        return [
            TextContent(
                type="text",
                text=f"Unknown tool: {name}",
            )
        ]


async def main(
    transport: str = "stdio",
    port: int = 58880,
):
    """
    Main entry point for the MCP server.

    Args:
        transport: Transport type ('stdio' or 'sse')
        port: Port to bind to for SSE transport
    """
    logger.info(
        f"Starting Deluge MCP Server (transport={transport}, port={port})..."
    )

    if transport == "stdio":
        async with mcp.server.stdio.stdio_server() as (
            read_stream,
            write_stream,
        ):
            logger.info("Running with stdio transport")
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )
    elif transport == "sse":
        from mcp.server.sse import SseServerTransport
        from starlette.applications import Starlette
        from starlette.routing import Route

        logger.info(f"Running with SSE transport on port {port}")

        sse = SseServerTransport("/messages")

        async def handle_sse(request):
            async with sse.connect_sse(
                request.scope, request.receive, request._send
            ) as streams:
                await server.run(
                    streams[0],
                    streams[1],
                    server.create_initialization_options(),
                )

        async def handle_messages(request):
            await sse.handle_post_message(
                request.scope, request.receive, request._send
            )

        app = Starlette(
            routes=[
                Route("/sse", endpoint=handle_sse),
                Route("/messages", endpoint=handle_messages, methods=["POST"]),
            ]
        )

        import uvicorn

        logger.info(f"Server listening on http://0.0.0.0:{port}")
        await uvicorn.Server(
            uvicorn.Config(app, host="0.0.0.0", port=port, log_level="info")
        ).serve()
    else:
        raise ValueError(f"Unknown transport: {transport}")


def cli_main():
    """CLI wrapper for main function."""
    import sys

    # Parse command line arguments
    transport = "stdio"
    port = 58880

    i = 1
    while i < len(sys.argv):
        if sys.argv[i] == "--transport" and i + 1 < len(sys.argv):
            transport = sys.argv[i + 1]
            i += 2
        elif sys.argv[i] == "--port" and i + 1 < len(sys.argv):
            port = int(sys.argv[i + 1])
            i += 2
        else:
            i += 1

    asyncio.run(main(transport=transport, port=port))


if __name__ == "__main__":
    cli_main()
    