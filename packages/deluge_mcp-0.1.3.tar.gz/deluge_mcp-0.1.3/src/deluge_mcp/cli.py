#!/usr/bin/env python3
import os
import platform
import subprocess
import sys
import logging
from pathlib import Path

import typer
from typing_extensions import Annotated

app = typer.Typer(
    name="deluge-mcp",
    help="Deluge MCP Server - Manage Deluge torrent client via MCP",
    add_completion=False,
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger("deluge-mcp")

# Configuration
SERVICE_PORT = 58880
SERVICE_VENV_PATH = Path("/opt/deluge-mcp/venv")
SERVICE_LOG_PATH = Path("/var/log/deluge-mcp")


def is_ubuntu() -> bool:
    """Check if the system is running Ubuntu or Debian-based."""
    try:
        if platform.system() != "Linux":
            return False

        # Check /etc/os-release for Ubuntu
        if Path("/etc/os-release").exists():
            with open("/etc/os-release") as f:
                content = f.read().lower()
                return "ubuntu" in content or "debian" in content

        return False
    except Exception:
        return False


def is_root() -> bool:
    """Check if running as root."""
    return os.geteuid() == 0


def check_deluge_console() -> bool:
    """Check if deluge-console is available."""
    try:
        result = subprocess.run(
            ["which", "deluge-console"],
            capture_output=True,
            text=True,
            check=False,
        )
        return result.returncode == 0
    except Exception:
        return False


@app.command()
def install():
    """
    Install Deluge MCP server as a systemd service.
    MUST be run with sudo/root privileges on Ubuntu systems.
    Creates a dedicated venv, installs dependencies, and sets up service.
    """
    typer.echo("🔍 Checking system requirements...")

    # Check if root
    if not is_root():
        typer.echo(
            "❌ Error: This command must be run as root (use sudo).",
            err=True,
        )
        typer.echo("   Run: sudo deluge-mcp install", err=True)
        raise typer.Exit(code=1)

    # Check if Ubuntu
    if not is_ubuntu():
        typer.echo(
            "❌ Error: Only supported on Ubuntu/Debian systems.",  # fmt: skip
            err=True,
        )
        raise typer.Exit(code=1)

    # Check if deluge-console is installed
    if not check_deluge_console():
        typer.echo(
            "❌ Error: deluge-console not found. Install deluge first:",
            err=True,
        )
        typer.echo("   sudo apt-get install deluge-console", err=True)
        raise typer.Exit(code=1)

    typer.echo("✅ System check passed: Ubuntu/Debian detected")
    typer.echo("✅ Running as root")
    typer.echo("✅ deluge-console is available")

    # Get the current package location
    package_path = Path(__file__).parent.parent.parent
    typer.echo(f"📂 Package location: {package_path}")

    # Step 1: Create dedicated venv
    typer.echo(f"\n🔨 Creating dedicated venv at {SERVICE_VENV_PATH}...")
    SERVICE_VENV_PATH.parent.mkdir(parents=True, exist_ok=True)

    try:
        subprocess.run(
            ["python3", "-m", "venv", str(SERVICE_VENV_PATH)],
            check=True,
            capture_output=True,
        )
        typer.echo("✅ Virtual environment created")
    except subprocess.CalledProcessError as e:
        typer.echo(f"❌ Failed to create venv: {e}", err=True)
        raise typer.Exit(code=1)

    # Step 2: Install the package in the venv
    typer.echo("\n📦 Installing deluge-mcp in the service venv...")
    pip_path = SERVICE_VENV_PATH / "bin" / "pip"
    python_venv_path = SERVICE_VENV_PATH / "bin" / "python"

    try:
        # Upgrade pip
        subprocess.run(
            [str(pip_path), "install", "--upgrade", "pip"],
            check=True,
            capture_output=True,
        )

        # Install the package
        subprocess.run(
            [str(pip_path), "install", str(package_path)],
            check=True,
            capture_output=True,
        )
        typer.echo("✅ Package installed in service venv")
    except subprocess.CalledProcessError as e:
        typer.echo(f"❌ Failed to install package: {e}", err=True)
        raise typer.Exit(code=1)

    # Step 3: Create log directory
    typer.echo(f"\n📁 Creating log directory at {SERVICE_LOG_PATH}...")
    SERVICE_LOG_PATH.mkdir(parents=True, exist_ok=True)
    typer.echo("✅ Log directory created")

    # Step 4: Create systemd service file
    service_content = f"""[Unit]
Description=Deluge MCP Server
After=network.target deluged.service
Wants=deluged.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/deluge-mcp
Environment="PATH={SERVICE_VENV_PATH}/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"  # fmt: skip
ExecStart={python_venv_path} -m deluge_mcp.main --transport sse --port {SERVICE_PORT}  # fmt: skip
Restart=always
RestartSec=10
StandardOutput=append:{SERVICE_LOG_PATH}/deluge-mcp.log
StandardError=append:{SERVICE_LOG_PATH}/deluge-mcp-error.log

# Logging
SyslogIdentifier=deluge-mcp

# Security
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
"""

    service_path = Path("/etc/systemd/system/deluge-mcp.service")
    typer.echo(f"\n📝 Creating systemd service file: {service_path}")

    try:
        with open(service_path, "w") as f:
            f.write(service_content)
        typer.echo("✅ Service file created")
    except Exception as e:
        typer.echo(f"❌ Failed to create service file: {e}", err=True)
        raise typer.Exit(code=1)

    # Step 5: Reload systemd and enable service
    typer.echo("\n🔄 Reloading systemd daemon...")
    try:
        subprocess.run(["systemctl", "daemon-reload"], check=True)
        typer.echo("✅ Systemd reloaded")
    except subprocess.CalledProcessError as e:
        typer.echo(f"❌ Failed to reload systemd: {e}", err=True)
        raise typer.Exit(code=1)

    typer.echo("\n🚀 Enabling deluge-mcp service...")
    try:
        subprocess.run(["systemctl", "enable", "deluge-mcp"], check=True)
        typer.echo("✅ Service enabled")
    except subprocess.CalledProcessError as e:
        typer.echo(f"❌ Failed to enable service: {e}", err=True)
        raise typer.Exit(code=1)

    typer.echo("\n▶️  Starting deluge-mcp service...")
    try:
        subprocess.run(["systemctl", "start", "deluge-mcp"], check=True)
        typer.echo("✅ Service started")
    except subprocess.CalledProcessError as e:
        typer.echo(f"❌ Failed to start service: {e}", err=True)
        typer.echo("   Check logs: sudo journalctl -u deluge-mcp -n 50")
        raise typer.Exit(code=1)

    typer.echo("\n✅ Installation complete!")
    typer.echo("\n📋 Configuration:")
    typer.echo(f"   Service venv: {SERVICE_VENV_PATH}")
    typer.echo(f"   Log directory: {SERVICE_LOG_PATH}")
    typer.echo(f"   Server port: {SERVICE_PORT}")
    typer.echo(f"   Transport: SSE (Server-Sent Events)")
    typer.echo("\n📋 Service Management:")
    typer.echo("   Start:   sudo systemctl start deluge-mcp")
    typer.echo("   Stop:    sudo systemctl stop deluge-mcp")
    typer.echo("   Status:  sudo systemctl status deluge-mcp")
    typer.echo("   Restart: sudo systemctl restart deluge-mcp")
    typer.echo("\n📋 View Logs:")
    typer.echo(f"   Main:  sudo tail -f {SERVICE_LOG_PATH}/deluge-mcp.log")
    typer.echo(f"   Error: sudo tail -f {SERVICE_LOG_PATH}/deluge-mcp-error.log")  # fmt: skip
    typer.echo("   Journal: sudo journalctl -u deluge-mcp -f")


@app.command()
def uninstall():
    """
    Uninstall the deluge-mcp systemd service.
    Requires root privileges.
    """
    if not is_root():
        typer.echo("❌ Error: Must be run as root (use sudo)", err=True)
        raise typer.Exit(code=1)

    typer.echo("🗑️  Uninstalling deluge-mcp service...")

    try:
        # Stop service
        typer.echo("⏹️  Stopping service...")
        subprocess.run(["systemctl", "stop", "deluge-mcp"], check=False)

        # Disable service
        typer.echo("🔌 Disabling service...")
        subprocess.run(["systemctl", "disable", "deluge-mcp"], check=False)

        # Remove service file
        typer.echo("📝 Removing service file...")
        service_path = Path("/etc/systemd/system/deluge-mcp.service")
        if service_path.exists():
            service_path.unlink()

        # Reload systemd daemon
        typer.echo("🔄 Reloading systemd daemon...")
        subprocess.run(["systemctl", "daemon-reload"], check=True)

        typer.echo("\n✅ Service uninstalled!")
        typer.echo(
            f"\nNote: Venv and logs remain:\n  {SERVICE_VENV_PATH}\n  {SERVICE_LOG_PATH}"  # fmt: skip
        )
        typer.echo("Remove manually if desired.")

    except Exception as e:
        typer.echo(f"❌ Uninstallation failed: {e}", err=True)
        raise typer.Exit(code=1)


@app.command()
def status():
    """
    Check the status of the deluge-mcp daemon service.
    """
    try:
        result = subprocess.run(
            ["systemctl", "is-active", "deluge-mcp.service"],
            capture_output=True,
            text=True,
            check=False,
        )

        if result.stdout.strip() == "active":
            typer.echo("✅ deluge-mcp service is running")
        else:
            typer.echo("❌ deluge-mcp service is not running")

        # Show detailed status
        subprocess.run(["systemctl", "status", "deluge-mcp.service"])

    except Exception as e:
        typer.echo(f"❌ Failed to check status: {e}", err=True)
        raise typer.Exit(code=1)


@app.command()
def run(
    transport: Annotated[
        str,
        typer.Option(
            "--transport",
            "-t",
            help="Transport mode: stdio or sse",
        ),
    ] = "stdio",
    port: Annotated[
        int,
        typer.Option("--port", "-p", help="Port for SSE transport"),
    ] = 58880,
):
    """
    Run the deluge-mcp server directly (not as daemon).
    """
    typer.echo(
        f"🚀 Starting deluge-mcp server (transport={transport}, port={port})..."  # fmt: skip
    )

    # Import and run the main function
    import asyncio
    from deluge_mcp.main import main

    asyncio.run(main(transport=transport, port=port))


def cli():
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    cli()
