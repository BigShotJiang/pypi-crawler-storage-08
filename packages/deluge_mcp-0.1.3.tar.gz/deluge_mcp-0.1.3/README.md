# Deluge MCP Server

A Model Context Protocol (MCP) server that provides AI assistants with tools to 
interact with and control the Deluge BitTorrent client. This server enables AI 
agents to manage torrents through a standardized interface.

## Features

- **Get Running Torrents**: Query information about all active torrents
- **Add Torrents**: Add new torrents using magnet URLs
- **Async Operations**: All operations run asynchronously using asyncio
- **HTTP Streamable Transport**: Run as an HTTP server for easy integration
- **CLI Management**: Command-line interface for daemon installation and control
- **Systemd Service**: Install as a persistent system service (Ubuntu)

## Prerequisites

## Prerequisites

- Python 3.10 or higher
- Deluge BitTorrent client with `deluge-console` installed
- For service installation: 
  - Ubuntu/Debian system with systemd
  - Root/sudo access
  - Running deluged service (recommended)

### Install Deluge

```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install deluged deluge-console

# Start deluged service
sudo systemctl enable deluged
sudo systemctl start deluged
```

## Installation

1. Clone the repository:
```bash
git clone https://github.com/abi-jey/deluge-mcp.git
cd deluge-mcp
```

2. Install dependencies using Poetry:
```bash
poetry install
```

3. Activate the virtual environment:
```bash
poetry shell
```

## Usage

### Running the MCP Server

Run the server directly in HTTP streamable mode:

```bash
deluge-mcp run
```

Or with a custom port:

```bash
deluge-mcp run --port 8080
```

The server will start and listen for MCP connections over HTTP.

### Available MCP Tools

Once the server is running, AI assistants can use the following tools:

#### 1. `get_running_torrents`

Get information about all torrents currently in Deluge.

**Returns**: Detailed information including torrent names, states, progress, 
download/upload speeds, seeds, peers, and ETA.

**Example output**:
```
Name: Ubuntu 22.04 LTS
ID: abc123...
State: Downloading
Down Speed: 5.2 MB/s
Up Speed: 1.1 MB/s
Progress: 45.3%
Seeds: 124 (200)
Peers: 45 (100)
ETA: 00:15:23
```

#### 2. `add_torrent_magnet`

Add a new torrent to Deluge using a magnet URL.

**Parameters**:
- `magnet_url` (string): The magnet URL starting with "magnet:"

**Returns**: Confirmation message with the result of the operation.

**Example**:
```python
add_torrent_magnet("magnet:?xt=urn:btih:...")
# Returns: "Torrent added successfully. Output: ..."
```

### CLI Commands

The `deluge-mcp` command provides several subcommands for managing the server:

#### Install as Daemon Service

Install deluge-mcp as a systemd service that starts automatically on boot:

```bash
deluge-mcp install
```

Options:
- `--port`, `-p`: Specify the HTTP server port (default: 8080)
- `--force`, `-f`: Force installation on non-Ubuntu systems

**System Requirements Check**:
- Verifies the system is running Ubuntu
- Checks that `deluge-console` is installed and accessible
- Creates a systemd service file
- Enables and starts the service

**Example**:
```bash
# Install with default settings
deluge-mcp install

# Install on custom port
deluge-mcp install --port 9090

# Force install on non-Ubuntu system (not recommended)
deluge-mcp install --force
```

#### Check Service Status

Check if the daemon service is running:

```bash
deluge-mcp status
```

This shows whether the service is active and displays detailed status information.

#### Uninstall Daemon Service

Remove the systemd service:

```bash
deluge-mcp uninstall
```

This will:
- Stop the running service
- Disable automatic startup
- Remove the service file
- Reload systemd configuration

#### Managing the Service

After installation, you can manage the service using standard systemd commands:

```bash
# Check status
sudo systemctl status deluge-mcp

# Stop the service
sudo systemctl stop deluge-mcp

# Start the service
sudo systemctl start deluge-mcp

# Restart the service
sudo systemctl restart deluge-mcp

# View logs
sudo journalctl -u deluge-mcp -f
```

## Architecture

### Async Subprocess Execution

All Deluge operations run asynchronously using Python's `asyncio` module:

```python
async def run_deluge_command(command: str) -> str:
    process = await asyncio.create_subprocess_shell(
        f'deluge-console "{command}"',
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await process.communicate()
    # ...
```

This ensures the MCP server remains responsive even during long-running operations.

### Transport Mode

The server uses FastMCP's HTTP streamable transport:

```python
app.run(transport="streamable-http")
```

This allows AI assistants to connect to the server over HTTP and stream responses 
efficiently.

### Command Execution

The server executes commands by invoking `deluge-console` as a subprocess:

- **Get torrents**: `deluge-console "info"`
- **Add magnet**: `deluge-console "add <magnet_url>"`

This approach ensures compatibility with existing Deluge installations and 
doesn't require direct API integration.

## Development

### Project Structure

```
deluge-mcp/
├── src/
│   └── deluge_mcp/
│       ├── main.py          # MCP server and tools
│       └── cli.py           # CLI interface
├── pyproject.toml           # Dependencies and config
├── README.md               # This file
└── LICENSE                 # License information
```

### Adding New Tools

To add a new MCP tool, define an async function in `main.py` and decorate it 
with `@app.tool()`:

```python
@app.tool()
async def my_new_tool(param: str) -> str:
    """
    Description of what the tool does.
    
    Args:
        param: Description of the parameter
    
    Returns:
        Description of the return value
    """
    output = await run_deluge_command(f"some-command {param}")
    return output
```

### Running Tests

```bash
poetry run pytest
```

## Security Considerations

- The daemon service runs with user-level permissions (not root)
- `deluge-console` commands are executed through subprocess with proper escaping
- Magnet URLs are validated before processing
- Service installation requires sudo privileges only for systemd operations

## Troubleshooting

### deluge-console not found

Ensure Deluge is installed:
```bash
sudo apt-get install deluge-console
which deluge-console  # Should return a path
```

### Permission errors during daemon installation

The installation requires sudo access to create systemd service files. Make sure 
your user has sudo privileges.

### Service fails to start

Check the service logs:
```bash
sudo journalctl -u deluge-mcp -n 50
```

Common issues:
- Deluge daemon not running
- Python environment not properly configured
- Port conflicts

### Ubuntu check fails

The daemon installation is designed for Ubuntu systems with systemd. If you're 
on a different Linux distribution, you can use `--force` flag, but you may need 
to manually adapt the service configuration.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

See the [LICENSE](LICENSE) file for details.

## Authors

- abi_jey (git@public.abja.dev)

## Links

- [Model Context Protocol](https://modelcontextprotocol.io/)
- [FastMCP](https://github.com/jlowin/fastmcp)
- [Deluge BitTorrent Client](https://deluge-torrent.org/)
- [Typer CLI Framework](https://typer.tiangolo.com/)
MCP server to automate deluge
