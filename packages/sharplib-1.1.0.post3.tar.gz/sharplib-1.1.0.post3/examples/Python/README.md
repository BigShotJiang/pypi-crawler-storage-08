## Install Prerequisites

```bash
conda create -n SHARPlib python=3.13
pip install -r requirements.txt
```
