API Reference
=============

The SHARPlib C++ and Python APIs are logically grouped into individual headers or submodules that group like operations. 

.. toctree::
   :maxdepth: 2

   python_api/index.rst
   cpp_api/index.rst
