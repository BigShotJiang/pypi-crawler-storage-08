interp
======
.. automodule:: nwsspc.sharp.calc.interp 

    .. autofunction:: nwsspc.sharp.calc.interp.interp_height
    .. autofunction:: nwsspc.sharp.calc.interp.interp_pressure
    .. autofunction:: nwsspc.sharp.calc.interp.find_first_height
    .. autofunction:: nwsspc.sharp.calc.interp.find_first_pressure
