__all__ = ['Cellular', 'BLE', 'Wifi', 'Ethernet', 'Network']

from .Network import Network, NetworkScope
