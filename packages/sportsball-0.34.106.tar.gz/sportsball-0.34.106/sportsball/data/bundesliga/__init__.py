"""The bundesliga data sportsball module."""

from .combined.bundesliga_combined_league_model import \
    BundesligaCombinedLeagueModel as BundesligaLeagueModel

__all__ = ("BundesligaLeagueModel",)
