"""Workflows MCP Server - DAG-based workflow execution for Claude Code."""

__version__ = "0.3.1"

__all__ = ["__version__"]
