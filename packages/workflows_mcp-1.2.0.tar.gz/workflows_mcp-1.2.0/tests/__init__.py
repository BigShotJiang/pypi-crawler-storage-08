# Test suite for workflows-mcp MCP server
#
# This directory contains validation tests for Phase 0 and future phases.
