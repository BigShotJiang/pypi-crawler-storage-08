"""Security test-specific fixtures.

Fixtures for security-focused testing including output sanitization and validation.
"""


# Security tests primarily use fixtures from root conftest.py
# Additional security-specific fixtures can be added here as needed
