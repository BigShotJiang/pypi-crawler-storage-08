.. currentmodule:: bitformat
.. _use_cases:

Common Use Cases
================


.. toctree::
    :maxdepth: 1

    use_case_construction
    use_case_manipulation
    use_case_formats
