.. currentmodule:: bitformat
.. _use_case_formats:

Binary formats
--------------

TODO
