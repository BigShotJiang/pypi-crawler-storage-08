"""Utilities for random DataFrame testing."""
