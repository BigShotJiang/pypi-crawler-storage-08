"""Real finlab integration tests for finlab-guard.

This package contains integration tests that require actual finlab package
and API connectivity to test real-world integration scenarios.
"""
