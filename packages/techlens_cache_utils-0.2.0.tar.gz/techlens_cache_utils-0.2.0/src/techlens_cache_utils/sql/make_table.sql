create table if not exists <table_name> (
    key TEXT,
    hash TEXT,
    val TEXT
)
