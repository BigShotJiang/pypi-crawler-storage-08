# cachehash
A python library for storing data about files in sqlite
