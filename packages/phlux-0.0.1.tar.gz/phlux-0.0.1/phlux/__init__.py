__version__ = "0.0.1"

def say_hello():
    return "Hello from my library!"
