__all__ = ("InvalidFrontMatter",)


class InvalidFrontMatter(Exception):
    pass
