"""Model selection test module."""
