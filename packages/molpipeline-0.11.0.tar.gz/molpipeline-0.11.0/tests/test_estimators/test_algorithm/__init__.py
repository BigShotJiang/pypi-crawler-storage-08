"""Test sklearn estimator algorithms."""
