from typing_arguments.generic_arguments import (
    GenericArgumentsMixin as GenericArgumentsMixin,
)
from typing_arguments.generic_arguments import (
    typing_arg as typing_arg,
)
