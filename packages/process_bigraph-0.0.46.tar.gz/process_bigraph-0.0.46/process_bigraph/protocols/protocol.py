class Protocol():
    def __init__(self):
        pass
