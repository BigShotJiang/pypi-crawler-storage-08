# load_distribution

A Python package for projecting abritrary, piecewise-linear polygons into a line.

Useful for converting arbitrary polygons within a tributary area onto a beam or other linear element (in structural engineering).