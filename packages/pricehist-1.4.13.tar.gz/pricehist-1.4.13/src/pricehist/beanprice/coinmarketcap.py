from pricehist import beanprice
from pricehist.sources.coinmarketcap import CoinMarketCap

Source = beanprice.source(CoinMarketCap())
