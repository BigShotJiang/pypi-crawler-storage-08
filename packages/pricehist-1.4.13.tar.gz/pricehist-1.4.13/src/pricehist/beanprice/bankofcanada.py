from pricehist import beanprice
from pricehist.sources.bankofcanada import BankOfCanada

Source = beanprice.source(BankOfCanada())
