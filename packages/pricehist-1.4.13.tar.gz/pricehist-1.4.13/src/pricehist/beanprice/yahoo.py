from pricehist import beanprice
from pricehist.sources.yahoo import Yahoo

Source = beanprice.source(Yahoo())
