def seconds_to_ms(seconds):
    return round(seconds * 1000, 2)


def ms_to_seconds(ms):
    return ms / 1000
