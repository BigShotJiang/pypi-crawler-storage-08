"""Tests for Toolscore package."""
