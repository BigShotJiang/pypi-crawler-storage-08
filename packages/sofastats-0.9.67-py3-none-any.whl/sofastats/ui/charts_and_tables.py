import panel as pn

def get_charts_and_tables_main():
    content = """\
    ## Charts and Tables
    Under construction
    """
    text = pn.pane.Markdown(content)
    return pn.Column(text)
