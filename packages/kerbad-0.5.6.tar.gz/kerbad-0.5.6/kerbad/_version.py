
__version__ = "0.5.6"
__banner__ = \
"""
# kerbad %s 
# Author: Tamas Jos @skelsec (skelsecprojects@gmail.com)
# Current Maintainer: Baptiste Crépin (baptiste@cravaterouge.com)
""" % __version__
