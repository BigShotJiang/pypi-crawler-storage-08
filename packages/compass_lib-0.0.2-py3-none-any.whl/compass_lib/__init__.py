# -*- coding: utf-8 -*-

"""
"A library to read Compass Survey files"
"""

__version__ = "0.0.2"
