class UnitConversionError(ValueError):
    """
    Raised by the units module when unit conversion fails.
    """

    pass
