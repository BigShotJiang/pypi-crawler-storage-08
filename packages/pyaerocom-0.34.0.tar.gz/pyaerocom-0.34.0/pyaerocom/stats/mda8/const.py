# Variable names for which mda8 values are to be calculated.
MDA8_INPUT_VARS = ("conco3", "vmro3")
MDA8_OUTPUT_VARS = (
    "conco3mda8",
    "vmro3mda8",
)
