# the files in this directory are not configurations needed by pyaerocom/aeroval
# but ready made configurations for users of pyaerocom/aeroval
