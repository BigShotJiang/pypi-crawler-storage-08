class ConfigError(ValueError):
    pass


class TrendsError(ValueError):
    pass
