CFG = {
    "proj_id": "cams2-83",
    "exp_id": "mos-colocated-data",
    "use_cams2_83": True,
    "species_list": ["concno2"],
}
