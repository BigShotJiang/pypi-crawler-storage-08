from .cams84 import CAMS84_CONFIG
from .common import add_dummy_model_data, make_dummy_cube_3D_daily
