"""Version information for structured-logger package."""

__version__ = "1.5.1"
