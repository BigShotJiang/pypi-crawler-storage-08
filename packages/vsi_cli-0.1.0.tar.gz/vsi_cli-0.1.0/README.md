# VSI-CLI 1.0

A VSI CLI wrapper on top of AWS CLI.

## Installation

```bash
pip install -e .
```

## Usage
TODO