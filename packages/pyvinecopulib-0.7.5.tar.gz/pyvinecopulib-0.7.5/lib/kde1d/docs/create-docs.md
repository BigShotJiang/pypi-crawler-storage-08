To generate the docs in usual doxygen format, run
```
mkdir build && cd build && cmake .. && make doc
```

To generate the docs for the website, run
```
path/to/doxygen.py docs/Doxyfile-mcss
```
where `doxygen.py` is from https://github.com/mosra/m.css.
