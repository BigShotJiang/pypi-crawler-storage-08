"""zytome"""

__version__ = "0.0.45"
__author__ = "Marko Zolo Gozano Untalan"
