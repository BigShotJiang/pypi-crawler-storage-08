from copy import deepcopy
from operator import attrgetter
from typing import Tuple

from ..analysis import (
    get_pinch_temperatures,
    get_process_heat_cascade,
    get_utility_targets,
    get_balanced_cc,
)
from ..classes import *
from ..lib import *

__all__ = ["get_process_targets"]

#######################################################################################################
# Public API
#######################################################################################################


def get_process_targets(zone: Zone):
    """Populate a ``Zone`` with detailed process-level pinch targets.

    The function aggregates problem-table calculations, multi-utility targeting,
    pinch temperature detection, and graph preparation.  Results are cached on
    the provided ``zone`` via :meth:`Zone.add_target_from_results` and used later
    by site and regional aggregation routines.
    """
    (
        config,
        hot_streams,
        cold_streams,
        all_streams,
        hot_utilities,
        cold_utilities,
        zone_identifier,
        subzones,
    ) = attrgetter(
        "config",
        "hot_streams",
        "cold_streams",
        "all_streams",
        "hot_utilities",
        "cold_utilities",
        "identifier",
        "subzones",
    )(zone)

    pt, pt_real, target_values = get_process_heat_cascade(
        hot_streams, cold_streams, all_streams, config
    )
    pt, pt_real, hot_utilities, cold_utilities = get_utility_targets(
        pt, pt_real, hot_utilities, cold_utilities
    )
    net_hot_streams, net_cold_streams = _get_net_hot_and_cold_segments(
        zone_identifier, pt, hot_utilities, cold_utilities
    )
    pt = get_balanced_cc(
        pt
    )
    pt_real = get_balanced_cc(
        pt_real
    )
    hot_pinch, cold_pinch = get_pinch_temperatures(pt)

    # Target heat transfer area and number of exchanger units based on Balanced CC
    if config.AREA_BUTTON and 0:
        # area = get_area_targets(pt_real, config)
        # num_units = get_min_number_hx(pt)
        # capital_cost = compute_capital_cost(area, num_units, config)
        # annual_capital_cost = compute_annual_capital_cost(area, num_units, config)
        # zone.add_target_from_results(TargetType.DI.value, {
        #     "capital_cost": capital_cost,
        #     "annual_capital_cost": annual_capital_cost,
        #     "num_units": num_units,
        #     "area": area,
        # })
        pass

    graph_data = _save_graph_data(pt, pt_real)
    zone.add_target_from_results(
        TargetType.DI.value,
        {
            "pt": pt,
            "pt_real": pt_real,
            "target_values": target_values,
            "graphs": graph_data,
            "hot_utilities": hot_utilities,
            "cold_utilities": cold_utilities,
            "net_hot_streams": net_hot_streams,
            "net_cold_streams": net_cold_streams,
            "hot_pinch": hot_pinch,
            "cold_pinch": cold_pinch,
        },
    )

    if len(subzones) > 0:
        for z in subzones.values():
            z = get_process_targets(z)

    return zone


#######################################################################################################
# Helper functions
#######################################################################################################


def _get_net_hot_and_cold_segments(
    zone_identifier: str,
    pt: ProblemTable,
    hot_utilities: StreamCollection,
    cold_utilities: StreamCollection,
) -> Tuple[StreamCollection, StreamCollection]:
    """Derive net process streams that represent overall utility demand for site aggregation."""
    total_utility_demand = sum([u.heat_flow for u in hot_utilities]) + sum(
        [u.heat_flow for u in cold_utilities]
    )
    if zone_identifier == ZoneType.P.value and total_utility_demand > tol:
        net_hot_streams, net_cold_streams = _save_data_for_site_analysis(
            pt, PT.T.value, PT.H_NET_A.value, hot_utilities, cold_utilities
        )
    else:
        net_hot_streams, net_cold_streams = StreamCollection(), StreamCollection()
    return net_hot_streams, net_cold_streams


def _save_data_for_site_analysis(
    pt: ProblemTable,
    col_T: str,
    col_H: str,
    hot_utilities: StreamCollection,
    cold_utilities: StreamCollection,
) -> Tuple[StreamCollection, StreamCollection]:
    """Constructs net stream segments that require utility input across temperature intervals."""
    net_hot_streams = StreamCollection()
    net_cold_streams = StreamCollection()

    if pt.delta_col(col_T)[1:].min() < tol:
        raise ValueError("Infeasible temperature interval detected in _store_TSP_data")

    T_vals = pt.col[col_T]
    dh_vals = pt.delta_col(col_H)[1:]

    hot_utilities = deepcopy(hot_utilities)
    cold_utilities = deepcopy(cold_utilities)

    hu: Stream = _initialise_utility_selected(hot_utilities)
    cu: Stream = _initialise_utility_selected(cold_utilities)

    k = 1
    for i, dh in enumerate(dh_vals):
        if dh > tol:
            hu, hot_utilities, net_cold_streams, k = _add_net_segment(
                T_vals[i], T_vals[i + 1], hu, dh, hot_utilities, net_cold_streams, k
            )
        elif -dh > tol:
            cu, cold_utilities, net_hot_streams, k = _add_net_segment(
                T_vals[i], T_vals[i + 1], cu, dh, cold_utilities, net_hot_streams, k
            )

    return net_hot_streams, net_cold_streams


def _add_net_segment(
    T_ub: float,
    T_lb: float,
    curr_u: Stream,
    dh_req: float,
    utilities: StreamCollection,
    net_streams: StreamCollection,
    k: int,
    j: int = 0,
):
    """Adds a net utility segment and recursively handles segmentation if needed."""
    next_u = _advance_utility_if_needed(dh_req, curr_u, utilities)

    dh_next = max(-curr_u.heat_flow, 0.0)
    curr_u.heat_flow = max(curr_u.heat_flow, 0.0)
    dh_curr = abs(dh_req) - dh_next
    T_i = T_ub - (dh_curr / abs(dh_req)) * (T_ub - T_lb)

    net_streams.add(
        Stream(
            name=f"Segment {k}" if j == 0 else f"Segment {k}-{j}",
            t_supply=T_i if curr_u.type == StreamType.Hot.value else T_ub,
            t_target=T_ub if curr_u.type == StreamType.Hot.value else T_i,
            heat_flow=dh_curr,
            dt_cont=curr_u.dt_cont,
            htc=1.0,  # Might be a way to calculate this.
            is_process_stream=True,
        )
    )
    if dh_next > tol:  # /1000
        return _add_net_segment(
            T_i, T_lb, next_u, dh_next, utilities, net_streams, k, j + 1
        )
    else:
        return next_u, utilities, net_streams, k + 1


def _initialise_utility_selected(utilities: StreamCollection = None):
    """Returns the first available utility with remaining capacity."""
    for j in range(len(utilities)):
        if utilities[j].heat_flow > tol:
            return utilities[j]
    return utilities[-1]


def _advance_utility_if_needed(
    dh_used: float, current_u: Stream = None, utilities: StreamCollection = None
) -> Stream:
    """Advances to the next utility if the current one is exhausted."""
    current_u.heat_flow -= abs(dh_used)
    if current_u.heat_flow > tol:
        return current_u

    k = utilities.get_index(current_u) + 1
    for j in range(k, len(utilities)):
        if utilities[j].heat_flow > tol:
            return utilities[j]

    return utilities[-1]


def _save_graph_data(pt: ProblemTable, pt_real: ProblemTable) -> Zone:
    """Assemble the problem-table slices required for composite/comparison plots."""
    pt.round(decimals=4)
    pt_real.round(decimals=4)
    return {
        GT.CC.value: pt_real[[PT.T.value, PT.H_HOT.value, PT.H_COLD.value]],
        GT.SCC.value: pt[[PT.T.value, PT.H_HOT.value, PT.H_COLD.value]],
        GT.BCC.value: pt_real[[PT.T.value, PT.H_HOT_BAL.value, PT.H_COLD_BAL.value]],
        GT.GCC.value: pt[[PT.T.value, PT.H_NET.value, PT.H_NET_NP.value, PT.H_NET_V.value, PT.H_NET_A.value, PT.H_UT_NET.value]],
        GT.GCC_R.value: pt_real[[PT.T.value, PT.H_NET.value, PT.H_UT_NET.value]],
        GT.NLC.value: pt[[PT.T.value, PT.H_HOT_NET.value, PT.H_COLD_NET.value, PT.H_HOT_UT.value, PT.H_COLD_UT.value]],
    }
