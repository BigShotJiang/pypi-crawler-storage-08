pathsim.blocks.multiplier module
================================

.. automodule:: pathsim.blocks.multiplier
   :members:
   :show-inheritance:
   :undoc-members:
