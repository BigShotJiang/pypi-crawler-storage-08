pathsim.solvers.rkdp87 module
=============================

.. automodule:: pathsim.solvers.rkdp87
   :members:
   :show-inheritance:
   :undoc-members:
