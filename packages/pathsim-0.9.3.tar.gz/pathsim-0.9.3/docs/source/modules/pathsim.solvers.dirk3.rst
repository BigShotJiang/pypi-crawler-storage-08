pathsim.solvers.dirk3 module
============================

.. automodule:: pathsim.solvers.dirk3
   :members:
   :show-inheritance:
   :undoc-members:
