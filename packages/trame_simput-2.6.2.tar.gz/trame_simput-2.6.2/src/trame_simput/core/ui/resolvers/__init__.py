from .vuetify import VuetifyResolver

__all__ = [
    "VuetifyResolver",
]
