from .factory import get_simput_manager

__all__ = [
    "get_simput_manager",
]
