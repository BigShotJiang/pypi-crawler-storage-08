Alligater
===

A small config-based feature gating library for Python.
