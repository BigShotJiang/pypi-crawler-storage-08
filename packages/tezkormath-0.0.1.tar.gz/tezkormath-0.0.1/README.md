# TezkorMath kutubxonasi v0.0.1

# Kutubxonani o'rnatish
```
pip install tezkormath
```

# Ishlatilinishi
```
from tezkormath import matematika
x = matematika(2, "+", 3) #5
```