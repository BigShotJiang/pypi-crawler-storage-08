from .main import matematika
__version__ = "0.0.1"