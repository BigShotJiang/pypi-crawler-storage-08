# litmus-libs
![PyPI](https://img.shields.io/pypi/v/litmus-libs)


# How to release
 
Go to https://github.com/canonical/litmus-operators/releases and click on 'Draft a new release'.

Select a tag from the dropdown, or create a new one from the `main` target branch. The tag needs to start with `libs-` to get picked up by pypi automation.

Enter a meaningful release title and in the description, put an itemized changelog listing new features and bugfixes, and whatever is good to mention.

Click on 'Publish release'.