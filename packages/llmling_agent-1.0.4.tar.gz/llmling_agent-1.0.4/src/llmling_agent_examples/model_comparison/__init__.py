"""Example of comparing different models using parallel teams."""

TITLE = "Model Comparison"
ICON = "octicon:graph-16"
