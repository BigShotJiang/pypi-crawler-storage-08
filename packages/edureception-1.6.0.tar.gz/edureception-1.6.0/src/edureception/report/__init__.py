# coding: utf-8
from __future__ import unicode_literals
"""Действия и интерфейсы для печати расписания приёма специалиста."""
