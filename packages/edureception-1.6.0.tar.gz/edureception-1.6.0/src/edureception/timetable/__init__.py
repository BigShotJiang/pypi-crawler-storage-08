# coding: utf-8
from __future__ import unicode_literals
"""Действия и интерфейсы для просмотра списания приема и назначения приема."""
