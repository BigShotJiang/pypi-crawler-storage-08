# Core shell logic for gptsh
