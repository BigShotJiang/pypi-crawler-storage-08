"""ECB utils module."""
