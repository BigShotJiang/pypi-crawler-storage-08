"""ECB Provider Models."""
