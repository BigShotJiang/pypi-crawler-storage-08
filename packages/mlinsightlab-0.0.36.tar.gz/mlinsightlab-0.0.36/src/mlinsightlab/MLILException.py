class MLILException(Exception):
    '''
    Exception specific to ML Insight Lab
    '''
    pass
