"""Privy.io MCP Server - User statistics, wallet management, and authentication."""

__version__ = "0.1.0"
