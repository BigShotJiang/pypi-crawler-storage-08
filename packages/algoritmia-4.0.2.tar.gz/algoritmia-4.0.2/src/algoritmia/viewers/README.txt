Programs in this folder need the easypaint package:

pip install easypaint