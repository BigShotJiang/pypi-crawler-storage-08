# Open Banking, Opened | Dependency

Dependency Injection Package for Open Banking, Opened API.
