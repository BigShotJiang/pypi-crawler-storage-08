# ruff: noqa: F401

from ._svgrenderer import SvgRenderer, registry, register_svg_render_function
from . import linerender
