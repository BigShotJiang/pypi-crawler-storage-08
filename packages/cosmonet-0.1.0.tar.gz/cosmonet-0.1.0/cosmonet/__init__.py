"""
CosmoNet: Astronomical Light Curve Classification using Physics-Informed Neural Networks

Copyright 2023 CosmoNet Team

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from .cosmonet_classifier import CosmoNetClassifier
from .cosmonet_pinn import CosmoNetPINN

__version__ = "0.1.0"
__author__ = "CosmoNet Team"
__email__ = "cosmonet-team@example.com"
__license__ = "Apache 2.0"

__all__ = ['CosmoNetClassifier', 'CosmoNetPINN']