This dataset is primarily based off the AI2D Dataset (see [here](
  https://prior.allenai.org/projects/diagram-understanding)).

See [Section 4.1](https://arxiv.org/pdf/2310.12128) of our paper for
 the AI2D-Caption dataset annotation process.
