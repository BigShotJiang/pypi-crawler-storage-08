.. toctree::
   /src/usage/cli.rst
