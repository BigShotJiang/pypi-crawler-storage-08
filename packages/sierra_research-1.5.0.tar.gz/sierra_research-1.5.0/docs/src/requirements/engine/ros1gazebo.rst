.. SPDX-License-Identifier:  MIT

#. :envvar:`ROS_PACKAGE_PATH` is set up properly prior to invoking SIERRA.
