# Copyright 2022 John Harwell, All rights reserved.
#
#  SPDX-License-Identifier: MIT
"""
Common variables module for the :term:`ROS1` engine.
"""

# Core packages

# 3rd party packages

# Project packages
