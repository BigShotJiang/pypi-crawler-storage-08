# Copyright 2021 John Harwell, All rights reserved.
#
#  SPDX-License-Identifier: MIT
"""Container module for things stage 1 of the pipeline."""

# Core packages

# 3rd party packages

# Project packages
