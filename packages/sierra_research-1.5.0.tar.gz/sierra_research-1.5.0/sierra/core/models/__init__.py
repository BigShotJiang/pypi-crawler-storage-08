# Copyright 2021 John Harwell, All rights reserved.
#
#  SPDX-License-Identifier: MIT
"""Container module for things related to models."""

# Core packages

# 3rd party packages

# Project packages
from .info import ModelInfo as ModelInfo
