# Copyright 2021 John Harwell, All rights reserved.
#
#  SPDX-License-Identifier: MIT
"""
Container module for core aspects of SIERRA invariate across plugins.
"""
# Core packages

# 3rd party packages

# Project packages
