# Copyright 2021 John Harwell, All rights reserved.
#
#  SPDX-License-Identifier: MIT
"""Container module for plugins related to real robot execution environments."""

# Core packages

# 3rd party packages

# Project packages
