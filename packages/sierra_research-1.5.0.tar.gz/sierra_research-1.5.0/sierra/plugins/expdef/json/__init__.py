# Copyright 2024 John Harwell, All rights reserved.
#
#  SPDX-License-Identifier: MIT
"""Container module for the JSON expdef plugin."""

# Core packages

# 3rd party packages

# Project packages


def sierra_plugin_type() -> str:
    return "pipeline"
