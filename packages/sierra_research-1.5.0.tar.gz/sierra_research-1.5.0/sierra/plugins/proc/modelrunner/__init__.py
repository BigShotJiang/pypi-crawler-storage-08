#
# Copyright 2025 John Harwell, All rights reserved.
#
# SPDX-License Identifier: MIT
#
"Plugin for running models during stage 3."

# Core packages

# 3rd party packages

# Project packages


def sierra_plugin_type() -> str:
    return "pipeline"
