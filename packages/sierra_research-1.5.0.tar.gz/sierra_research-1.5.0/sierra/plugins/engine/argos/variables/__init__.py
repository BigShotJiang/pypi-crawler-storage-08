# Copyright 2022 John Harwell, All rights reserved.
#
#  SPDX-License-Identifier: MIT
"""
Variables module for the :term:`ARGoS` engine.

See :ref:`plugins/engine/argos`.
"""

# Core packages

# 3rd party packages

# Project packages
