# Copyright 2019 John Harwell, All rights reserved.
#
# SPDX-License-Identifier: MIT

"""Classes for comparing deliverables across a set of scenarios.

Univariate batch criteria only. The same controller must be used for all
scenarios.

"""

# Core packages
import typing as tp
import argparse
import logging
import pathlib

# 3rd party packages

# Project packages
from sierra.core.variables import batch_criteria as bc
import sierra.core.plugin as pm
from sierra.core import types, utils, config, storage, batchroot, graphs
from sierra.plugins.compare.graphs import outputroot, preprocess, namecalc, comparator


class UnivarInterScenarioComparator(comparator.BaseComparator):
    """Compares a single controller across a set of scenarios.

    Graph generation is controlled via a config file parsed in
    :class:`~sierra.core.pipeline.stage5.pipeline_stage5.PipelineStage5`.

    Univariate batch criteria only.

    Attributes:
        controller: Controller to use.

        scenarios: List of scenario names to compare ``controller`` across.

        sc_csv_root: Absolute directory path to the location scenario CSV
                     files should be output to.

        sc_graph_root: Absolute directory path to the location the generated
                       graphs should be output to.

        cmdopts: Dictionary of parsed cmdline parameters.

        cli_args: :class:`argparse` object containing the cmdline
                  parameters. Needed for
                  :class:`~sierra.core.variables.batch_criteria.XVarBatchCriteria`
                  generation for each scenario controllers are compared within,
                  as batch criteria is dependent on controller+scenario
                  definition, and needs to be re-generated for each scenario in
                  order to get graph labels/axis ticks to come out right in all
                  cases.

    """

    def __init__(
        self,
        controller: str,
        scenarios: tp.List[str],
        stage5_roots: outputroot.PathSet,
        cmdopts: types.Cmdopts,
        cli_args: argparse.Namespace,
        main_config: types.YAMLDict,
    ) -> None:
        super().__init__(scenarios, stage5_roots, cmdopts, cli_args, main_config)
        self.logger = logging.getLogger(__name__)
        self.controller = controller

    def exp_select(self) -> tp.List[batchroot.ExpRoot]:
        """
        Determine if a scenario can be include in the comparison for a controller.

        """
        selected = []
        for scenario in self.things:
            for candidate in (self.project_root / self.controller / scenario).iterdir():
                root = batchroot.ExpRoot(
                    sierra_root=self.cmdopts["sierra_root"],
                    project=self.cmdopts["project"],
                    controller=self.controller,
                    leaf=batchroot.ExpRootLeaf.from_name(candidate.name),
                    scenario=scenario,
                )
                if root.to_path().exists():
                    selected.append(root)
        return selected

    def compare(
        self,
        cmdopts: types.Cmdopts,
        graph: types.YAMLDict,
        roots: tp.List[batchroot.ExpRoot],
        legend: tp.List[str],
    ) -> None:
        for scenario in self.things:
            valid_configurations = sum(r.scenario == scenario for r in roots)
            if valid_configurations > 1:
                self.logger.warning(
                    "Skipping ambiguous comparison for scenario %s: was run on multiple selected batch roots %s",
                    scenario,
                    [r.to_str() for r in roots],
                )
                continue

            if valid_configurations == 0:
                self.logger.warning(
                    "Skipping comparison for scenario %s: not run on any selected batch roots %s",
                    scenario,
                    [r.to_str() for r in roots],
                )
                continue

        # Each controller should have been run on exactly ONE batch experiment
        # that we selected for controller comparison, by definition.
        root = next(r for r in roots if r.scenario == scenario)

        # We need to generate the root directory paths for each batch experiment
        # (which lives inside of the scenario dir), because they are all
        # different. We need generate these paths for EACH controller, because
        # the controller is part of the batch root path.
        pathset = batchroot.from_exp(
            sierra_root=self.cli_args.sierra_root,
            project=self.cli_args.project,
            batch_leaf=root.leaf,
            controller=self.controller,
            scenario=root.scenario,
        )

        # For each scenario, we have to create the batch criteria for it,
        # because they are all different.
        criteria = bc.factory(
            self.main_config,
            cmdopts,
            pathset.input_root,
            self.cli_args,
            root.scenario,
        )

        self._gen_csvs(
            criteria=criteria,
            pathset=pathset,
            project=self.cli_args.project,
            root=root,
            src_stem=graph["src_stem"],
            dest_stem=graph["dest_stem"],
            index=graph.get("index", -1),
        )

        self._gen_graph(
            batch_leaf=root.leaf,
            criteria=criteria,
            cmdopts=cmdopts,
            batch_output_root=pathset.output_root,
            dest_stem=graph["dest_stem"],
            title=graph.get("title", None),
            label=graph["label"],
            legend=legend,
            backend=graph.get("backend", cmdopts["graphs_backend"]),
        )

    def _gen_graph(
        self,
        batch_leaf: batchroot.ExpRootLeaf,
        criteria: bc.XVarBatchCriteria,
        cmdopts: types.Cmdopts,
        batch_output_root: pathlib.Path,
        dest_stem: str,
        title: str,
        label: str,
        legend: tp.List[str],
        backend: str,
        inc_exps: tp.Optional[str] = None,
    ) -> None:
        """Generate graph comparing the specified controller across scenarios."""
        opath_leaf = namecalc.for_sc(batch_leaf, self.things, dest_stem, None)
        info = criteria.graph_info(cmdopts, batch_output_root=batch_output_root)

        xticklabels = info.xticklabels
        xticks = info.xticks
        if inc_exps is not None:
            xticklabels = utils.exp_include_filter(
                inc_exps, info.xticklabels, criteria.n_exp()
            )
            xticks = utils.exp_include_filter(inc_exps, info.xticks, criteria.n_exp())

        paths = graphs.PathSet(
            input_root=self.stage5_roots.csv_root,
            output_root=self.stage5_roots.graph_root,
            batchroot=pathlib.Path(
                self.cmdopts["sierra_root"], self.cmdopts["project"]
            ),
            model_root=None,
        )

        graphs.summary_line(
            paths=paths,
            input_stem=opath_leaf,
            stats=cmdopts["dist_stats"],
            medium=cmdopts["storage"],
            output_stem=opath_leaf,
            title=title,
            xlabel=info.xlabel,
            ylabel=label,
            backend=backend,
            xticks=xticks,
            xticklabels=xticklabels,
            logyscale=cmdopts["plot_log_yscale"],
            large_text=cmdopts["plot_large_text"],
            legend=legend,
        )

    def _gen_csvs(
        self,
        criteria: bc.XVarBatchCriteria,
        pathset: batchroot.PathSet,
        project: str,
        root: batchroot.ExpRoot,
        index: int,
        src_stem: str,
        dest_stem: str,
    ) -> None:
        """Generate a set of CSV files for use in inter-scenario graph generation.

        Generates:

        - ``.mean`` CSV file containing results for each scenario the controller
           is being compared across, 1 per line.

        - Stastics CSV files containing various statistics for the ``.mean`` CSV
          file, 1 per line.

        - ``.model`` file containing model predictions for controller behavior
          during each scenario, 1 per line (not generated if models were not run
          the performance measures we are generating graphs for).

        - ``.legend`` file containing legend values for models to plot (not
          generated if models were not run for the performance measures we are
          generating graphs for).

        """

        csv_ipath_stem = pathset.stat_interexp_root / src_stem

        # Some experiments might not generate the necessary performance measure
        # CSVs for graph generation, which is OK.
        csv_ipath_mean = csv_ipath_stem.with_suffix(config.kStats["mean"].exts["mean"])
        if not utils.path_exists(csv_ipath_mean):
            self.logger.warning(
                "%s missing for controller %s", csv_ipath_mean, self.controller
            )
            return

        preparer = preprocess.IntraExpPreparer(
            ipath_stem=pathset.stat_interexp_root,
            ipath_leaf=src_stem,
            opath_stem=self.stage5_roots.csv_root,
            criteria=criteria,
        )
        opath_leaf = namecalc.for_sc(root.leaf, self.things, dest_stem, None)

        preparer.for_sc(
            scenario=root.scenario,
            opath_leaf=opath_leaf,
            index=index,
            inc_exps=None,
        )

        # Collect performance results models and legends. Append to existing
        # dataframes if they exist, otherwise start new ones.
        # Can't use with_suffix() for opath, because that path contains the
        # controller, which already has a '.' in it.
        # model_istem = pathlib.Path(pathset.model_root, src_stem)
        model_ostem = self.stage5_roots.model_root / (dest_stem + "-" + self.controller)

        # model_ipath = model_istem.with_suffix(config.kModelsExt["model"])
        model_opath = model_ostem.with_name(
            model_ostem.name + config.kModelsExt["model"]
        )
        # model_df = self._accum_df(criteria, model_ipath, model_opath, src_stem)
        model_df = None
        legend_opath = model_ostem.with_name(
            model_ostem.name + config.kModelsExt["legend"]
        )

        if model_df is not None:
            storage.df_write(model_df, model_opath, "storage.csv", index=False)

            with utils.utf8open(legend_opath, "a") as f:
                sgp = pm.module_load_tiered(project=project, path="generators.scenario")
                kw = sgp.to_dict(root.scenario)
                f.write("{0} Model Prediction\n".format(kw["scenario_tag"]))


__all__ = ["UnivarInterScenarioComparator"]
