# About Me

Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.

Below is an example of a function written in Python. Syntax highlighting is supported in the rendered HTML content.

```python
def sayhello():
    """
    Example function that prints a string.
    """
    s = 'Hello there'
    print(s)
```

<p>HTML can be mixed in with the Markdown content. This paragraph is written in Markdown using an HTML paragraph tag.</p>
