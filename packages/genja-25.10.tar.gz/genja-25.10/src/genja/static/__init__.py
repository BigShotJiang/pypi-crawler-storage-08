"""Static files subpackage.

Files in this subpackage are for creating a new Genja project with the
`genja new` command.
"""
