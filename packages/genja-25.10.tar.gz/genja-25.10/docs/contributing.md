# Contributing

See the [CONTRIBUTING.md](https://github.com/wigging/genja/blob/main/CONTRIBUTING.md) document on GitHub for guidelines on contributing to the Genja package. Thank you for taking the time to contribute.
