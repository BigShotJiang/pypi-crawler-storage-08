# Welcome to Genja

Welcome to Genja's documentation. Genja is a simple static website generator. It is a command line tool built in Python that generates HTML files and a JSON feed from Markdown content. The source code for Genja is available on [GitHub](https://github.com/wigging/genja).

```{toctree}
:maxdepth: 2
:caption: Contents:

getstarted
markdown
templates
examples
contributing
```
