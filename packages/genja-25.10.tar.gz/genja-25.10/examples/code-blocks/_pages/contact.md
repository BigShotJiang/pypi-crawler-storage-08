# Contact

Got a question, idea, or just want to say hi? I’d love to hear from you. Whether it’s about coding projects, hiking adventures, or anything in between, feel free to reach out by email. I’ll get back to you as soon as I can—preferably before my next hike.

