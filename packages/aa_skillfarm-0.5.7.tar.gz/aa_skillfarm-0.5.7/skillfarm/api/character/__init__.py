from .skillfarm import SkillFarmApiEndpoints


def setup(api):
    SkillFarmApiEndpoints(api)
