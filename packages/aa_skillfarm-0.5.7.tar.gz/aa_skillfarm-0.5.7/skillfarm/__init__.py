"""Initialize the app"""

__version__ = "0.5.7"
__title__ = "Skillfarm"

__package_name__ = "aa-skillfarm"

__app_name_useragent__ = "AA-Skillfarm"
__github_url__ = f"https://github.com/Geuthur/{__package_name__}"
