# ModelName

Custom enum for the model name

## Enum

* `BINNET_MINUS_0_DOT_5_MINUS_X86_MINUS_WINDOWS` (value: `'binnet-0.5-x86-windows'`)

* `BINNET_MINUS_0_DOT_5_MINUS_X86_MINUS_LINUX` (value: `'binnet-0.5-x86-linux'`)

* `BINNET_MINUS_0_DOT_5_MINUS_X86_MINUS_MACOS` (value: `'binnet-0.5-x86-macos'`)

* `BINNET_MINUS_0_DOT_5_MINUS_X86_MINUS_ANDROID` (value: `'binnet-0.5-x86-android'`)

* `BINNET_MINUS_0_DOT_5_MINUS_X86_MINUS_32_MINUS_WINDOWS` (value: `'binnet-0.5-x86-32-windows'`)

* `BINNET_MINUS_0_DOT_5_MINUS_X86_MINUS_32_MINUS_LINUX` (value: `'binnet-0.5-x86-32-linux'`)

* `BINNET_MINUS_0_DOT_5_MINUS_ARM_MINUS_64_MINUS_WINDOWS` (value: `'binnet-0.5-arm-64-windows'`)

* `BINNET_MINUS_0_DOT_5_MINUS_ARM_MINUS_64_MINUS_LINUX` (value: `'binnet-0.5-arm-64-linux'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


