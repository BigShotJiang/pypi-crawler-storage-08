# ConfidenceType


## Enum

* `FALSE_POSITIVE` (value: `'FALSE_POSITIVE'`)

* `SIGNATURE` (value: `'SIGNATURE'`)

* `HEURISTIC` (value: `'HEURISTIC'`)

* `LIKELY_VULNERABLE` (value: `'LIKELY_VULNERABLE'`)

* `VULNERABLE` (value: `'VULNERABLE'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


