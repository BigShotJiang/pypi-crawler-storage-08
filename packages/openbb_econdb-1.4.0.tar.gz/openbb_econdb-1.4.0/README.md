# OpenBB EconDB Provider

This extension integrates the [EconDB](https://econdb.com/) data provider into the OpenBB Platform.

## Installation

To install the extension:

```bash
pip install openbb-econdb
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
