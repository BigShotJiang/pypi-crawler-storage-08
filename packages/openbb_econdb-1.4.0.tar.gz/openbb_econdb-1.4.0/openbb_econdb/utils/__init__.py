"""EconDB Utilities."""
