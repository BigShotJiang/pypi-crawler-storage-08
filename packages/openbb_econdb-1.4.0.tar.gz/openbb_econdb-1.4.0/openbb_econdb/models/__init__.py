"""EconDB Models."""
