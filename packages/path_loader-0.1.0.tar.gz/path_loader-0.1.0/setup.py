from setuptools import setup, find_packages
from setuptools.command.install import install
import os


class PostInstallCommand(install):
    """安裝後建立 .pth 檔案"""

    def run(self):
        install.run(self)
        # 安裝後在 site-packages 中建立 .pth 檔案
        pth_content = "import path_loader.sitecustomize"

        # 取得 site-packages 目錄
        from distutils.sysconfig import get_python_lib

        site_packages = get_python_lib()
        pth_file = os.path.join(site_packages, "path_loader_auto.pth")

        try:
            with open(pth_file, "w") as f:
                f.write(pth_content)
            print("\n" + "=" * 60)
            print("✓ Path Loader 已安裝並啟用自動載入功能")
            print("=" * 60)
            print("\n使用方式:")
            print("  1. 在專案根目錄建立 .pypath 檔案")
            print("  2. 在 .pypath 中加入路徑(每行一個)")
            print("  3. 直接執行 Python,路徑會自動載入!")
            print("\n範例 .pypath 內容:")
            print("  ./lib")
            print("  ./src")
            print("\n" + "=" * 60 + "\n")
        except Exception as e:
            print(f"\n警告: 無法建立 .pth 檔案: {e}")
            print("可能需要管理員權限,請嘗試: pip install --user path-loader\n")


with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

PACKAGE_NAME = "path-loader"
AUTHOR = "Pyan-X"
AUTHOR_EMAIL = "a0025071@gmail.com"
URL = "https://github.com/Pyan-X/path-loader"
DOWNLOAD_URL = "https://pypi.org/project/path-loader/"

LICENSE = "MIT"
VERSION = "0.1.0"
DESCRIPTION = "自動從配置檔載入 Python 路徑到 sys.path"
LONG_DESCRIPTION = long_description
LONG_DESC_TYPE = "text/markdown"

CLASSIFIERS = [f"Programming Language :: Python :: 3.{str(v)}" for v in range(7, 12)]
PYTHON_REQUIRES = ">=3.7"

setup(
    name=PACKAGE_NAME,
    version=VERSION,
    author=AUTHOR,
    author_email=AUTHOR_EMAIL,
    description=DESCRIPTION,
    long_description=LONG_DESCRIPTION,
    long_description_content_type=LONG_DESC_TYPE,
    license=LICENSE,
    url=URL,
    download_url=DOWNLOAD_URL,
    python_requires=PYTHON_REQUIRES,
    packages=find_packages(),
    cmdclass={
        "install": PostInstallCommand,
    },
    classifiers=CLASSIFIERS,
)
