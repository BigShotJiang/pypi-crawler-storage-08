"""
自動載入 .pypath 配置的路徑到 sys.path
這個檔案會在 Python 啟動時自動執行
"""

import sys
import os
from pathlib import Path


def find_pypath_file(start_dir=None):
    """
    從指定目錄開始向上搜尋 .pypath 配置檔

    Args:
        start_dir: 起始目錄,若為 None 則從當前工作目錄開始

    Returns:
        找到的配置檔路徑,若找不到則回傳 None
    """
    config_names = [".pypath", "pythonpath.txt", "sys_paths.conf"]

    if start_dir is None:
        start_dir = Path.cwd()
    else:
        start_dir = Path(start_dir)

    current = start_dir.resolve()

    # 向上搜尋直到根目錄
    while True:
        for config_name in config_names:
            config_path = current / config_name
            if config_path.exists():
                return config_path

        # 已到達根目錄
        if current.parent == current:
            break
        current = current.parent

    return None


def parse_pypath_file(config_path):
    """
    解析 .pypath 配置檔

    Args:
        config_path: 配置檔路徑

    Returns:
        解析出的路徑列表
    """
    paths = []
    config_dir = config_path.parent

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            for line in f:
                # 移除註解和空白
                line = line.split("#")[0].strip()
                if not line:
                    continue

                # 處理相對路徑和絕對路徑
                path = line
                if not os.path.isabs(path):
                    # 相對於配置檔所在目錄
                    path = str((config_dir / path).resolve())

                # 檢查路徑是否存在
                if os.path.exists(path):
                    paths.append(path)
    except Exception:
        # 如果讀取失敗,靜默忽略
        pass

    return paths


def auto_load_paths():
    """自動載入 .pypath 中的路徑到 sys.path"""
    config_path = find_pypath_file()

    if config_path:
        paths = parse_pypath_file(config_path)
        for path in paths:
            if path not in sys.path:
                # 插入到開頭以獲得較高優先級
                sys.path.insert(0, path)


# 執行自動載入
auto_load_paths()
