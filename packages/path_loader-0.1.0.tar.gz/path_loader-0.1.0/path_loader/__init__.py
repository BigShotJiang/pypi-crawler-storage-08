"""
Path Loader - 自動從配置檔載入 Python 路徑到 sys.path

安裝後會自動生效,無需手動呼叫。
"""

__version__ = "0.1.0"

# 匯出除錯工具函式
from .sitecustomize import find_pypath_file, parse_pypath_file, auto_load_paths

__all__ = ["find_pypath_file", "parse_pypath_file", "auto_load_paths"]
