# Path Loader

**自動從配置檔載入 Python 路徑 - 安裝即用,零程式碼** 🚀

## 為什麼需要 Path Loader?

不想在每個 Python 檔案中寫這些?

```python
import sys
sys.path.append('../lib')
sys.path.append('../src')
sys.path.append('/home/user/shared_modules')
```

Path Loader 讓你只需要一個配置檔,**安裝後自動生效**!

## 快速開始

### 1️⃣ 安裝

```bash
pip install path-loader
```

### 2️⃣ 建立配置檔

在專案根目錄建立 `.pypath` 檔案:

```bash
cd /your/project
cat > .pypath << EOF
# 相對路徑(相對於這個檔案)
./lib
./src
./utils

# 絕對路徑
/home/user/shared_libraries
EOF
```

### 3️⃣ 完成!

```python
# 不需要任何 import path_loader 或其他程式碼!
# 路徑已經自動載入了!

import my_module      # 從 ./lib 載入
import another_module # 從 ./src 載入
```

## 工作原理

```
pip install path-loader
    ↓
在 site-packages 建立 .pth 檔案
    ↓
Python 啟動時自動執行 sitecustomize.py
    ↓
搜尋並載入 .pypath 中的路徑
    ↓
✅ 你的程式可以直接 import 任何模組!
```

## 配置檔格式

```
# 這是註解

# 相對路徑(相對於 .pypath 檔案所在目錄)
./lib
./src
../shared_modules

# 絕對路徑
/home/user/my_libraries
/opt/custom_python_modules

# 空行會被忽略

# 不存在的路徑會被自動跳過(不會報錯)
./non_existent_path
```

## 配置檔搜尋順序

Path Loader 會從 **Python 執行時的當前目錄** 開始向上搜尋,依序尋找:

1. `.pypath` (推薦)
2. `pythonpath.txt`
3. `sys_paths.conf`

找到第一個就會使用,不會繼續搜尋。

## 使用情境

### 情境 1: 多人協作

```
專案/
├── .pypath         # 使用相對路徑,提交到 git
│   ./lib
│   ./src
├── lib/
└── src/
```

### 情境 2: 共用函式庫

```
.pypath 內容:
./project_modules
/home/user/company_shared_libs
../team_common_utils
```

### 情境 3: 測試環境

```
專案/
├── .pypath
│   ./src
│   ./tests
├── src/
│   └── myapp/
└── tests/
    └── test_myapp.py  # 可以直接 import myapp
```

## 除錯工具

如果需要檢查配置:

```python
from path_loader import find_pypath_file, parse_pypath_file

# 查看找到的配置檔位置
config = find_pypath_file()
print(f"配置檔: {config}")

# 查看載入了哪些路徑
if config:
    paths = parse_pypath_file(config)
    print(f"載入的路徑: {paths}")

# 查看當前 sys.path
import sys
print("sys.path:", sys.path[:5])  # 顯示前 5 個
```

## 常見問題

### Q: 路徑沒有被載入?

**檢查步驟**:

```bash
# 1. 確認已安裝
pip list | grep path-loader

# 2. 確認 .pth 檔案存在
python -c "import site; print(site.getsitepackages())"
# 到這個目錄檢查是否有 path_loader_auto.pth

# 3. 測試配置檔是否被找到
python -c "from path_loader import find_pypath_file; print(find_pypath_file())"

# 4. 查看當前工作目錄
python -c "import os; print(os.getcwd())"
```

### Q: 使用虛擬環境怎麼辦?

每個虛擬環境都要單獨安裝:

```bash
source venv/bin/activate
pip install path-loader
```

### Q: 如何禁用自動載入?

**方法 1**: 暫時禁用

```bash
# 重新命名 .pth 檔案
mv /path/to/site-packages/path_loader_auto.pth \
   /path/to/site-packages/path_loader_auto.pth.disabled
```

**方法 2**: 刪除配置檔

```bash
rm .pypath  # 沒有配置檔就不會載入任何路徑
```

**方法 3**: 解除安裝

```bash
pip uninstall path-loader
```

### Q: 可以在程式中手動載入嗎?

可以!雖然通常不需要:

```python
from path_loader import auto_load_paths

# 強制重新載入
auto_load_paths()
```

## 與其他方案比較

| 方案                | 優點              | 缺點             |
| ------------------- | ----------------- | ---------------- |
| **path-loader**     | 自動載入,零程式碼 | 需要安裝套件     |
| sys.path.append()   | 不需要額外套件    | 每個檔案都要寫   |
| PYTHONPATH 環境變數 | Python 原生支援   | 每個環境都要設定 |
| setup.py develop    | 標準做法          | 設定複雜         |

## 最佳實踐

✅ **DO**:

- 使用相對路徑讓專案更容易移植
- 在配置檔中加入註解說明用途
- 將 `.pypath` 提交到版本控制(如果路徑是相對的)
- 定期清理不再使用的路徑

❌ **DON'T**:

- 不要在 `.pypath` 中加入過多路徑(保持簡潔)
- 不要使用絕對路徑(除非確實需要)
- 不要忘記將 `.pypath` 放在正確的位置(專案根目錄)

## 解除安裝

```bash
pip uninstall path-loader
```

解除安裝後,`.pth` 檔案會自動刪除,自動載入功能立即停止。

## 檔案大小

- 核心程式碼: ~2.5 KB
- 總安裝大小: ~5 KB

極度輕量! 🪶

## 授權

MIT License

## 貢獻

歡迎提交 Issue 和 Pull Request!

GitHub: https://github.com/yourusername/path-loader
