"""Compatibility API for gRPC extensions.

The public gRPC extensions API has moved to the :mod:`ni_grpc_extensions`
package.

The :mod:`ni_measurement_plugin_sdk_service.grpc` subpackage provides
compatibility with existing applications and will be deprecated in a future
release.
"""
