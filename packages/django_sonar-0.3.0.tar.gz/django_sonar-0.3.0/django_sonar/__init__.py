__all__ = ["default_app_config", "APP_NAME", "VERSION"]

default_app_config = 'django_sonar.apps.DjangoSonarConfig'
APP_NAME = "django_sonar"
VERSION = "0.3.0"
