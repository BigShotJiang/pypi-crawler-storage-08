# OpenInference Semantic Conventions

[![pypi](https://badge.fury.io/py/openinference-semantic-conventions.svg)](https://pypi.org/project/openinference-semantic-conventions/)

This library contains code for the OpenInference Semantic Conventions defined by the OpenInference specification.
