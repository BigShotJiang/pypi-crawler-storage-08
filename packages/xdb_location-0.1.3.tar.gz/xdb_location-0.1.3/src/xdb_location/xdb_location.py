"""Main module."""

def main():
    """Main function."""
    print("Hello, Xdb Location!")