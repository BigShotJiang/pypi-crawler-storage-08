# Usage

To use Xdb_Location in a project:

```python
import xdb_location
```
