# Xdb_Location

![PyPI version](https://img.shields.io/pypi/v/xdb_location.svg)
[![Documentation Status](https://readthedocs.org/projects/xdb_location/badge/?version=latest)](https://xdb_location.readthedocs.io/en/latest/?version=latest)

a geographic information database

* PyPI package: https://pypi.org/project/xdb_location/
* Free software: MIT License
* Documentation: https://xdb_location.readthedocs.io.

## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
# xdb_location
