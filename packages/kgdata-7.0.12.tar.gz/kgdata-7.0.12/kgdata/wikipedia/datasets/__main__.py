from kgdata.dataset import make_dataset_cli

if __name__ == "__main__":
    make_dataset_cli("wikipedia")()
