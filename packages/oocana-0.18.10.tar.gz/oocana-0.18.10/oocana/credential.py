class CredentialInput:
    def __init__(self, type: str, id: str):
        self.type = type
        self.id = id