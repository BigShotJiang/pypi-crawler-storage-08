<p align="center"><img src="https://dydx.exchange/icon.svg?" width="256" /></p>

<h1 align="center">v4-proto-py</h1>

<div align="center">
  <a href='https://pypi.org/project/v4-proto'>
    <img src='https://img.shields.io/pypi/v/v4-proto.svg' alt='PyPI'/>
  </a>
  <a href='https://github.com/dydxprotocol/v4-chain/blob/main/v4-proto-py/LICENSE'>
    <img src='https://img.shields.io/badge/License-AGPL_v3-blue.svg' alt='License' />
  </a>
</div>

Generated Python package for dYdX Chain protobufs.
