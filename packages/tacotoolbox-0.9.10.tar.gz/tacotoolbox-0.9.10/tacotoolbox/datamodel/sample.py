from tacotoolbox.sample.extensions.istac import ISTAC
from tacotoolbox.sample.extensions.scaling import Scaling
from tacotoolbox.sample.extensions.stac import STAC
from tacotoolbox.sample.extensions.stats import GeotiffStats
