COLOR_PALETTE = {
    "success": "rgb(113,176,109)",
    "warning": "rgb(176,169,109)",
    "error": "rgb(176,109,109)"
}

DOMINO_HELM_PATH = 'domino/domino'
DOMINO_HELM_VERSION = '0.1.6'
DOMINO_HELM_REPOSITORY = 'https://iisas.github.io/domino/'