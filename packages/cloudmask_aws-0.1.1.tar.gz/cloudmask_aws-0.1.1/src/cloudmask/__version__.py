"""Version information for cloudmask."""

__version__ = "0.1.1"
