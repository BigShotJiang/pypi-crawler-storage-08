"""
PyPrestaScan - CLI per analisi SEO specializzata di e-commerce PrestaShop
"""

__version__ = "1.0.0"
__author__ = "PyPrestaScan Team"
__email__ = "pyprestascan@example.com"