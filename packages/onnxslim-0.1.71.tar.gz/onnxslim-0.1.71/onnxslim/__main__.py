from onnxslim.cli._main import main

if __name__ == "__main__":
    main()
