from onnxslim.third_party.onnx_graphsurgeon.logger.logger import G_LOGGER, LogMode
