# External

```{autofile} ../../src/*/external/**/*.py
---
module:
---
```
