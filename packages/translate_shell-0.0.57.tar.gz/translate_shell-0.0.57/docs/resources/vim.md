# Vim Help

```{eval-sh}
cd ..
scripts/generate-vim.md.pl doc/*.txt
```
