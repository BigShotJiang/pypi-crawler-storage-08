"""Test
=======

Provide assets path.
"""

from pathlib import Path

ASSETS_PATH = Path(__file__).absolute().parent
