- Antonio Esposito \<<a.esposito@onestein.nl>\>
- Andrea Stirpe \<<a.stirpe@onestein.nl>\>
- Luisa Miguéns \<<luisa.miguens@solvos.es>\>
- [Heliconia Solutions Pvt. Ltd.](https://www.heliconia.io)
  - Bhavesh Heliconia

