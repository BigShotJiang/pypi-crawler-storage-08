This module provides a security group category 'Maintenance' with two
new user groups:

- 'User'
- 'Full Access'.

The user group 'Equipment Manager', already provided by the standard
Odoo, will also be listed in the group category 'Maintenance'.
