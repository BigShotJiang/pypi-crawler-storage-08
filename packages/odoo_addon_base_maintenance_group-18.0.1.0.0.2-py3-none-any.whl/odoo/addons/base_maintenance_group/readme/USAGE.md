Assign any of the Maintenance groups ('User' or 'Equipment Manager' or
'Full Access') to the users, in order to enable the maintenance menus.

To do so, you need to:

1.  Go on 'Settings' -\> 'Users & Companies' -\> 'Users'.
2.  Create a new user or select an already existing one.
3.  In the tab 'Access Rights', at the 'Application Accesses' paragraph,
    set a group in the 'Maintenance' category.
