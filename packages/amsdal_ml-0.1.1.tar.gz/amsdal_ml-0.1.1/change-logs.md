## [v0.1.0](https://pypi.org/project/amsdal_ml/0.1.0/) - 2025-09-22

### Core * OpenAI-based implementations

- Interfaces and default OpenAI-based implementations