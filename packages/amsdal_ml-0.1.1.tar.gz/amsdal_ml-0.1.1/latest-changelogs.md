## [v0.1.1](https://pypi.org/project/amsdal_ml/0.1.0/) - 2025-10-08

### Interface of BaseFileLoader & OpenAI-based PDF file loader

- BaseFileLoader interface and OpenAI Files API implementation