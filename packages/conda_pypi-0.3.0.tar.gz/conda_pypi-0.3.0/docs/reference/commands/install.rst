``conda pypi install``
**********************

.. argparse::
   :module: conda_pypi.cli.main
   :func: generate_parser
   :prog: conda pypi
   :path: install
   :nodefault:
   :nodefaultconst:
