``conda pypi convert``
**********************

.. argparse::
   :module: conda_pypi.cli.main
   :func: generate_parser
   :prog: conda pypi
   :path: convert
   :nodefault:
   :nodefaultconst:
