from conda_pypi.cli import main

__all__ = ["main"]
