```
-------------------------------------------------------------------------
Copyright (C) 2024-2025 Brigitte Bigi, CNRS,
Laboratoire Parole et Langage, Aix-en-Provence, France
See the accompanying LICENSE file for details.
-------------------------------------------------------------------------
```

# Authors 

A contributing author is a person or company who contributed code that
is now part of this tool.

For the purpose of copyright and licensing, this is the official list
of contributing authors.


## Main author, contributor, maintainer, developer:

* 2024-: Brigitte Bigi - <https://sppas.org/bigi/> - ORCID: 0000-0003-1834-6918
