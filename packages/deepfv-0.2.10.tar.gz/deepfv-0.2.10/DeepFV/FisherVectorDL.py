import numpy as np
import tensorflow as tf
from sklearn.cluster import MiniBatchKMeans
import pickle
import os

N_Kernel_Choices = [5, 20, 60, 100, 200, 500]


class FisherVectorDL(tf.keras.Model):
    """
    TensorFlow/Keras implementation of Fisher Vector with Gaussian Mixture Model.
    Uses mini-batch training for improved speed on large datasets.
    """

    def __init__(self, n_kernels=1, feature_dim=None, covariance_type='diag'):
        """
        Initialize Fisher Vector GMM model.

        Args:
            n_kernels: Number of Gaussian components
            feature_dim: Dimensionality of input features
            covariance_type: Type of covariance ('diag' or 'full')
        """
        super(FisherVectorDL, self).__init__()

        assert covariance_type in ['diag', 'full'], "covariance_type must be 'diag' or 'full'"
        assert n_kernels > 0

        self.n_kernels = n_kernels
        self.feature_dim = feature_dim
        self.covariance_type = covariance_type
        self.fitted = False

        # These will be initialized in build() or initialize()
        self.pi_layer = None
        self.mu_layer = None
        self.sd_layer = None  # For diagonal covariance
        self.cov_layer = None  # For full covariance (lower triangular Cholesky factors)

    def build(self, input_shape):
        """Build the model layers."""
        if self.feature_dim is None:
            self.feature_dim = input_shape[-1]

        # Initialize trainable parameters
        # pi: mixture weights (n_kernels,)
        self.pi_layer = self.add_weight(
            name='pi',
            shape=(self.n_kernels,),
            initializer=tf.keras.initializers.Constant(1.0 / self.n_kernels),
            trainable=True,
            constraint=tf.keras.constraints.NonNeg()
        )

        # mu: means (feature_dim, n_kernels)
        self.mu_layer = self.add_weight(
            name='mu',
            shape=(self.feature_dim, self.n_kernels),
            initializer=tf.keras.initializers.RandomNormal(mean=0.0, stddev=1.0),
            trainable=True
        )

        if self.covariance_type == 'diag':
            # sd: standard deviations (feature_dim, n_kernels)
            self.sd_layer = self.add_weight(
                name='sd',
                shape=(self.feature_dim, self.n_kernels),
                initializer=tf.keras.initializers.Constant(1.0),
                trainable=True,
                constraint=tf.keras.constraints.NonNeg()
            )
        else:  # full covariance
            # Store Cholesky decomposition of covariance matrices (lower triangular)
            # Shape: (n_kernels, feature_dim, feature_dim)
            # Initialize as identity matrices
            init_cov = np.tile(np.eye(self.feature_dim)[None, :, :], (self.n_kernels, 1, 1))
            self.cov_layer = self.add_weight(
                name='cov_cholesky',
                shape=(self.n_kernels, self.feature_dim, self.feature_dim),
                initializer=tf.keras.initializers.Constant(init_cov),
                trainable=True
            )

        super(FisherVectorDL, self).build(input_shape)

    def initialize(self, X, init='MiniBatchKmeans'):
        """
        Initialize GMM parameters using KMeans clustering.

        Args:
            X: Training data (n_samples, feature_dim)
            init: Initialization method ('MiniBatchKmeans' supported)
        """
        # Build the model first
        self(tf.keras.layers.Input(shape=(X.shape[1],), dtype=tf.float32))

        if init == 'MiniBatchKmeans':
            # MiniBatchKMeans for initialization
            mb_kmeans = MiniBatchKMeans(
                n_clusters=self.n_kernels,
                init='k-means++',
                max_iter=500,
                batch_size=1024 * 6,
                random_state=42
            )
            mb_kmeans.fit(X)

            # Calculate initial GMM parameters from kmeans solution
            mu = mb_kmeans.cluster_centers_.T  # (feature_dim, n_kernels)

            # Assign samples to clusters
            labels = mb_kmeans.predict(X)
            one_hot = np.eye(self.n_kernels)[labels]  # One-hot encoding
            pi = one_hot.sum(axis=0, keepdims=True)  # Count per cluster

            if self.covariance_type == 'diag':
                # Calculate standard deviation for each cluster
                sd_values = np.zeros((self.feature_dim, self.n_kernels))
                for k in range(self.n_kernels):
                    cluster_mask = labels == k
                    if cluster_mask.sum() > 1:
                        cluster_data = X[cluster_mask]
                        sd_values[:, k] = np.sqrt(
                            np.sum((cluster_data - mu[:, k])**2, axis=0) / (pi[0, k] - 1)
                        )
                    else:
                        sd_values[:, k] = 1.0  # Default value for empty clusters

                # Normalize pi
                pi = pi / pi.sum()

                # Set model weights
                self.set_params(pi, mu, sd_values)

            else:  # full covariance
                # Calculate full covariance matrix for each cluster
                cov_matrices = np.zeros((self.n_kernels, self.feature_dim, self.feature_dim))
                for k in range(self.n_kernels):
                    cluster_mask = labels == k
                    if cluster_mask.sum() > 1:
                        cluster_data = X[cluster_mask]
                        centered = cluster_data - mu[:, k]
                        cov_matrices[k] = (centered.T @ centered) / (pi[0, k] - 1)
                        # Add small regularization to diagonal for numerical stability
                        cov_matrices[k] += np.eye(self.feature_dim) * 1e-6
                    else:
                        cov_matrices[k] = np.eye(self.feature_dim)

                # Normalize pi
                pi = pi / pi.sum()

                # Set model weights
                self.set_params(pi, mu, cov_matrices)

        self.fitted = True
        return self

    def set_params(self, pi, mu, sd_or_cov):
        """
        Set GMM parameters.

        Args:
            pi: Mixture weights (1, n_kernels) or (n_kernels,)
            mu: Means (feature_dim, n_kernels)
            sd_or_cov: For 'diag': Standard deviations (feature_dim, n_kernels)
                      For 'full': Covariance matrices (n_kernels, feature_dim, feature_dim)
        """
        if pi.ndim == 2:
            pi = pi.flatten()

        self.pi_layer.assign(pi)
        self.mu_layer.assign(mu)

        if self.covariance_type == 'diag':
            self.sd_layer.assign(sd_or_cov)
        else:  # full covariance
            # Compute Cholesky decomposition of covariance matrices
            cov_cholesky = np.zeros_like(sd_or_cov)
            for k in range(self.n_kernels):
                try:
                    cov_cholesky[k] = np.linalg.cholesky(sd_or_cov[k])
                except np.linalg.LinAlgError:
                    # If Cholesky fails, add more regularization
                    cov_reg = sd_or_cov[k] + np.eye(self.feature_dim) * 1e-4
                    cov_cholesky[k] = np.linalg.cholesky(cov_reg)
            self.cov_layer.assign(cov_cholesky)

    def call(self, inputs):
        """
        Forward pass - compute negative log likelihood for training.

        Args:
            inputs: Input features (batch_size, feature_dim)

        Returns:
            Negative log likelihood
        """
        # Normalize pi to ensure it sums to 1
        pi = tf.nn.softmax(self.pi_layer)

        if self.covariance_type == 'diag':
            # Diagonal covariance implementation
            sd = self.sd_layer + 1e-6

            # Compute Gaussian likelihood for each component
            x_expanded = tf.expand_dims(inputs, axis=-1)  # (batch_size, feature_dim, 1)
            mu_expanded = tf.expand_dims(self.mu_layer, axis=0)  # (1, feature_dim, n_kernels)
            sd_expanded = tf.expand_dims(sd, axis=0)  # (1, feature_dim, n_kernels)

            # Compute normalized squared distance
            diff = (x_expanded - mu_expanded) / sd_expanded  # (batch_size, feature_dim, n_kernels)

            # Log probability for diagonal Gaussian
            log_prob = -0.5 * tf.reduce_sum(diff**2, axis=1)  # (batch_size, n_kernels)
            log_prob = log_prob - tf.reduce_sum(tf.math.log(sd_expanded), axis=1)
            log_prob = log_prob - 0.5 * self.feature_dim * tf.math.log(2 * np.pi)

        else:  # full covariance
            # Get Cholesky decomposition L where Cov = L @ L^T
            L = self.cov_layer  # (n_kernels, feature_dim, feature_dim)

            # Compute log determinant: log|Cov| = 2 * sum(log(diag(L)))
            log_det = 2.0 * tf.reduce_sum(tf.math.log(tf.abs(tf.linalg.diag_part(L)) + 1e-10), axis=1)  # (n_kernels,)

            # Compute Mahalanobis distance for each component
            # inputs: (batch_size, feature_dim)
            # mu: (feature_dim, n_kernels)
            x_expanded = tf.expand_dims(inputs, axis=1)  # (batch_size, 1, feature_dim)
            mu_expanded = tf.transpose(self.mu_layer)[tf.newaxis, :, :]  # (1, n_kernels, feature_dim)

            # Centered data
            centered = x_expanded - mu_expanded  # (batch_size, n_kernels, feature_dim)

            # Solve L @ v = centered^T for v, then compute ||v||^2
            # centered: (batch_size, n_kernels, feature_dim)
            # L: (n_kernels, feature_dim, feature_dim)
            # We need to solve for each kernel separately
            log_prob_list = []
            for k in range(self.n_kernels):
                # centered_k: (batch_size, feature_dim)
                centered_k = centered[:, k, :]  # (batch_size, feature_dim)
                L_k = L[k]  # (feature_dim, feature_dim)

                # Solve L @ v = centered_k^T
                v = tf.linalg.triangular_solve(L_k, tf.transpose(centered_k), lower=True)  # (feature_dim, batch_size)
                mahalanobis_sq = tf.reduce_sum(v**2, axis=0)  # (batch_size,)

                # Log probability
                log_prob_k = -0.5 * (mahalanobis_sq + log_det[k] + self.feature_dim * tf.math.log(2 * np.pi))
                log_prob_list.append(log_prob_k)

            log_prob = tf.stack(log_prob_list, axis=1)  # (batch_size, n_kernels)

        # Add mixture weights
        log_prob = log_prob + tf.math.log(pi + 1e-10)

        # Log-sum-exp for numerical stability
        log_likelihood = tf.reduce_logsumexp(log_prob, axis=1)

        return -tf.reduce_mean(log_likelihood)

    def fit_minibatch(self, X, epochs=100, batch_size=1024*6, learning_rate=0.001,
                      verbose=True, model_dump_path=None, steps_per_epoch=None, print_every=1,
                      validation_split=0.0, patience=None, min_delta=0.001, epochs_min=0):
        """
        Fit GMM using mini-batch gradient descent.

        Args:
            X: Training data (n_samples, feature_dim) or with higher dimensions
            epochs: Number of training epochs
            batch_size: Mini-batch size
            learning_rate: Learning rate for optimizer
            verbose: Print training progress
            model_dump_path: Path to save fitted model
            steps_per_epoch: Number of batches to process per epoch (default: None = full dataset).
                           Useful for massive datasets to avoid cycling through entire dataset per epoch.
            print_every: Print loss every N epochs (default: 1). Always prints first and last epoch.
            validation_split: Fraction of data to use for validation (default: 0.0 = no validation).
                            E.g., 0.2 means 20% validation, 80% training.
            patience: Number of epochs to wait for improvement before early stopping (default: None = no early stopping).
                     If validation_split > 0: monitors validation loss.
                     If validation_split = 0: monitors training loss.
            min_delta: Minimum change in loss to qualify as improvement (default: 0.001).
            epochs_min: Minimum number of epochs before early stopping can trigger (default: 0).
                       Useful to let model train for a while before checking patience.

        Returns:
            self
        """
        # Handle different input dimensions
        if X.ndim == 4:
            self.ndim = 4
            original_shape = X.shape
            X = X.reshape(-1, X.shape[-1])
        elif X.ndim == 3:
            self.ndim = 3
            original_shape = X.shape
            X = np.reshape(X, [1] + list(X.shape))
            X = X.reshape(-1, X.shape[-1])
        else:
            self.ndim = 2
            original_shape = X.shape

        self.feature_dim = X.shape[-1]

        # Split data into train/val if validation_split is specified
        if validation_split > 0:
            n_samples = len(X)
            n_val = int(n_samples * validation_split)
            n_train = n_samples - n_val

            # Shuffle indices
            indices = np.random.permutation(n_samples)
            train_indices = indices[:n_train]
            val_indices = indices[n_train:]

            X_train = X[train_indices]
            X_val = X[val_indices]

            if verbose:
                print(f'Split data: {n_train} training, {n_val} validation samples')
        else:
            X_train = X
            X_val = None

        # Initialize if not already done (use all training data for initialization)
        if not self.fitted:
            if verbose:
                print(f'Initializing GMM with MiniBatchKMeans ({self.n_kernels} kernels)...')
            self.initialize(X_train, init='MiniBatchKmeans')

        # Create TensorFlow datasets
        train_dataset = tf.data.Dataset.from_tensor_slices(X_train.astype(np.float32))
        train_dataset = train_dataset.shuffle(buffer_size=min(10000, len(X_train)))
        train_dataset = train_dataset.batch(batch_size)
        train_dataset = train_dataset.prefetch(tf.data.AUTOTUNE)

        if X_val is not None:
            val_dataset = tf.data.Dataset.from_tensor_slices(X_val.astype(np.float32))
            val_dataset = val_dataset.batch(batch_size)
            val_dataset = val_dataset.prefetch(tf.data.AUTOTUNE)

        # Optimizer
        optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)

        # Early stopping tracking
        best_loss = float('inf')
        epochs_no_improve = 0

        # Training loop
        if verbose:
            steps_info = f' ({steps_per_epoch} steps/epoch)' if steps_per_epoch else ''
            val_info = f' with validation' if validation_split > 0 else ''
            early_stop_info = f' (early stopping enabled)' if patience is not None else ''
            print(f'Training GMM with {self.n_kernels} kernels for {epochs} epochs{steps_info}{val_info}{early_stop_info}...')

        for epoch in range(epochs):
            # Training phase
            epoch_train_loss = []
            step_count = 0

            for batch in train_dataset:
                with tf.GradientTape() as tape:
                    loss = self(batch, training=True)

                gradients = tape.gradient(loss, self.trainable_variables)
                optimizer.apply_gradients(zip(gradients, self.trainable_variables))

                epoch_train_loss.append(loss.numpy())
                step_count += 1

                # Stop after steps_per_epoch batches if specified
                if steps_per_epoch is not None and step_count >= steps_per_epoch:
                    break

            avg_train_loss = np.mean(epoch_train_loss)

            # Validation phase
            if X_val is not None:
                epoch_val_loss = []
                for batch in val_dataset:
                    val_loss = self(batch, training=False)
                    epoch_val_loss.append(val_loss.numpy())
                avg_val_loss = np.mean(epoch_val_loss)

                # Monitor validation loss for early stopping
                monitored_loss = avg_val_loss

                # Print progress
                if verbose and (epoch % print_every == 0 or epoch == epochs - 1):
                    print(f'Epoch {epoch+1}/{epochs}, Train Loss: {avg_train_loss:.4f}, Val Loss: {avg_val_loss:.4f}')
            else:
                # No validation - monitor training loss for early stopping
                monitored_loss = avg_train_loss

                # Print progress
                if verbose and (epoch % print_every == 0 or epoch == epochs - 1):
                    print(f'Epoch {epoch+1}/{epochs}, Train Loss: {avg_train_loss:.4f}')

            # Early stopping check (works for both validation and training loss)
            if patience is not None and epoch >= epochs_min:
                if monitored_loss < best_loss - min_delta:
                    best_loss = monitored_loss
                    epochs_no_improve = 0
                else:
                    epochs_no_improve += 1

                # Trigger early stopping
                if epochs_no_improve >= patience:
                    if verbose:
                        loss_type = 'Val Loss' if X_val is not None else 'Train Loss'
                        print(f'Early stopping triggered after {epoch+1} epochs (patience={patience}, {loss_type} plateaued)')
                    break
            elif patience is not None and epoch < epochs_min:
                # Before epochs_min, still track best loss but don't count patience
                if monitored_loss < best_loss - min_delta:
                    best_loss = monitored_loss
                    epochs_no_improve = 0

        self.fitted = True

        if model_dump_path:
            self.save_model(model_dump_path)
            if verbose:
                print(f'Saved model to {model_dump_path}')

        return self

    def compute_bic(self, X):
        """
        Compute Bayesian Information Criterion (BIC) for the model.

        Args:
            X: Input data (n_samples, feature_dim) or higher dimensions

        Returns:
            BIC score (lower is better)
        """
        # Handle different input dimensions
        if X.ndim == 4:
            X = X.reshape(-1, X.shape[-1])
        elif X.ndim == 3:
            X = np.reshape(X, [1] + list(X.shape))
            X = X.reshape(-1, X.shape[-1])

        n_samples = X.shape[0]

        # Compute log likelihood
        X_tf = tf.constant(X.astype(np.float32), dtype=tf.float32)
        neg_log_likelihood = self(X_tf, training=False).numpy()
        log_likelihood = -neg_log_likelihood * n_samples

        # Number of parameters:
        # - pi: n_kernels - 1 (constraint: sum to 1)
        # - mu: feature_dim * n_kernels
        # - sd: feature_dim * n_kernels (diagonal covariance)
        n_params = (self.n_kernels - 1) + (self.feature_dim * self.n_kernels * 2)

        # BIC = -2 * log_likelihood + n_params * log(n_samples)
        bic = -2 * log_likelihood + n_params * np.log(n_samples)

        return bic

    def fit_by_bic(self, X, choices_n_kernels=N_Kernel_Choices, epochs=100,
                   batch_size=1024*6, learning_rate=0.001,
                   model_dump_path=None, verbose=True):
        """
        Fit GMM with various n_kernels and select model with lowest BIC.

        Args:
            X: Training data with 3 or 4 dimensions
            choices_n_kernels: List of kernel numbers to try
            epochs: Number of training epochs per model
            batch_size: Mini-batch size
            learning_rate: Learning rate for optimizer
            model_dump_path: Path to save the best model
            verbose: Print training progress

        Returns:
            self (fitted with best n_kernels)
        """
        # Store original n_kernels
        original_n_kernels = self.n_kernels

        # Handle input dimensions
        if X.ndim == 4:
            ndim = 4
        elif X.ndim == 3:
            ndim = 3
            X = np.reshape(X, [1] + list(X.shape))
        else:
            raise AssertionError("X must be an ndarray with 3 or 4 dimensions")

        bic_scores = []
        best_params = None
        best_bic = float('inf')
        best_n_kernels = choices_n_kernels[0]

        for n_kernels in choices_n_kernels:
            # Create new model with different n_kernels
            temp_model = FisherVectorDL(
                n_kernels=n_kernels,
                feature_dim=self.feature_dim,
                covariance_type=self.covariance_type
            )

            # Fit the model
            temp_model.fit_minibatch(
                X,
                epochs=epochs,
                batch_size=batch_size,
                learning_rate=learning_rate,
                verbose=False
            )

            # Compute BIC
            bic_score = temp_model.compute_bic(X)
            bic_scores.append(bic_score)

            if verbose:
                print(f'Fitted GMM with {n_kernels} kernels - BIC = {bic_score:.4f}')

            # Keep track of best model
            if bic_score < best_bic:
                best_bic = bic_score
                best_n_kernels = n_kernels
                best_params = {
                    'pi': temp_model.pi_layer.numpy(),
                    'mu': temp_model.mu_layer.numpy()
                }

                if self.covariance_type == 'diag':
                    best_params['sd'] = temp_model.sd_layer.numpy()
                else:
                    # Save covariance matrices (not Cholesky)
                    L = temp_model.cov_layer.numpy()
                    best_params['cov'] = np.array([L[k] @ L[k].T for k in range(n_kernels)])

        # Update current model with best parameters
        self.n_kernels = best_n_kernels
        self.ndim = ndim

        if verbose:
            print(f'Selected GMM with {best_n_kernels} kernels')

        # Rebuild model with best n_kernels
        self.__init__(
            n_kernels=best_n_kernels,
            feature_dim=self.feature_dim,
            covariance_type=self.covariance_type
        )

        # Build and set best parameters
        dummy_input = tf.keras.layers.Input(shape=(self.feature_dim,), dtype=tf.float32)
        self(dummy_input)

        if self.covariance_type == 'diag':
            self.set_params(best_params['pi'], best_params['mu'], best_params['sd'])
        else:
            self.set_params(best_params['pi'], best_params['mu'], best_params['cov'])

        self.fitted = True

        if model_dump_path:
            self.save_model(model_dump_path)
            if verbose:
                print(f'Saved model to {model_dump_path}')

        return self

    def predict_fisher_vector(self, X, normalized=True, batch_size=None, verbose=False):
        """
        Compute Fisher Vectors for input data.

        Args:
            X: Input features with 2, 3, or 4 dimensions
               - 2D: (n_samples, feature_dim) - each sample treated as single descriptor
               - 3D: (n_samples, n_descriptors, feature_dim)
               - 4D: (n_samples, n_features_per_sample, n_descriptors, feature_dim)
            normalized: Apply improved Fisher Vector normalization
            batch_size: Process data in batches to avoid memory issues (default: None = process all at once).
                       For large datasets (millions of samples), set to e.g. 1000-10000.
            verbose: Print progress when processing in batches

        Returns:
            Fisher vectors with shape:
            - (n_samples, 2*n_kernels, feature_dim) for 2D or 3D input
            - (n_samples, n_features_per_sample, 2*n_kernels, feature_dim) for 4D input
        """
        # If batch_size specified, process in batches
        if batch_size is not None:
            return self._predict_batched(X, normalized=normalized, batch_size=batch_size, verbose=verbose)

        # Otherwise use original single-pass method
        if X.ndim == 4:
            return self._predict(X, normalized=normalized)
        elif X.ndim == 3:
            orig_shape = X.shape
            X = np.reshape(X, [1] + list(X.shape))
            result = self._predict(X, normalized=normalized)
            return np.reshape(result, (orig_shape[0], 2 * self.n_kernels, orig_shape[-1]))
        elif X.ndim == 2:
            # Treat each sample as having a single descriptor
            orig_shape = X.shape
            X = X.reshape(orig_shape[0], 1, orig_shape[1])  # (n_samples, 1, feature_dim)
            X = np.reshape(X, [1] + list(X.shape))  # (1, n_samples, 1, feature_dim)
            result = self._predict(X, normalized=normalized)
            return np.reshape(result, (orig_shape[0], 2 * self.n_kernels, orig_shape[-1]))
        else:
            raise AssertionError("X must be an ndarray with 2, 3, or 4 dimensions")

    def _predict_batched(self, X, normalized=True, batch_size=1000, verbose=False):
        """
        Compute Fisher Vectors in batches to avoid memory issues.

        Args:
            X: Input features with 2, 3, or 4 dimensions
            normalized: Apply improved Fisher Vector normalization
            batch_size: Number of samples to process per batch
            verbose: Print progress

        Returns:
            Fisher vectors
        """
        orig_ndim = X.ndim
        orig_shape = X.shape

        # Determine output shape based on input dimensions
        if orig_ndim == 2:
            n_samples = orig_shape[0]
            output_shape = (n_samples, 2 * self.n_kernels, orig_shape[-1])
        elif orig_ndim == 3:
            n_samples = orig_shape[0]
            output_shape = (n_samples, 2 * self.n_kernels, orig_shape[-1])
        elif orig_ndim == 4:
            n_samples = orig_shape[0]
            output_shape = (n_samples, orig_shape[1], 2 * self.n_kernels, orig_shape[-1])
        else:
            raise AssertionError("X must be an ndarray with 2, 3, or 4 dimensions")

        # Pre-allocate output array
        fisher_vectors_all = np.zeros(output_shape, dtype=np.float32)

        # Process in batches
        n_batches = int(np.ceil(n_samples / batch_size))

        if verbose:
            print(f"Processing {n_samples} samples in {n_batches} batches of size {batch_size}...")

        for i in range(n_batches):
            start_idx = i * batch_size
            end_idx = min((i + 1) * batch_size, n_samples)

            # Extract batch
            if orig_ndim == 2:
                X_batch = X[start_idx:end_idx]
            elif orig_ndim == 3:
                X_batch = X[start_idx:end_idx]
            else:  # 4D
                X_batch = X[start_idx:end_idx]

            # Process batch (recursively call predict_fisher_vector without batch_size)
            fv_batch = self.predict_fisher_vector(X_batch, normalized=normalized, batch_size=None)

            # Store results
            fisher_vectors_all[start_idx:end_idx] = fv_batch

            if verbose and (i + 1) % max(1, n_batches // 10) == 0:
                print(f"  Processed {end_idx}/{n_samples} samples ({(end_idx/n_samples)*100:.1f}%)")

        if verbose:
            print(f"✓ Completed processing {n_samples} samples")

        return fisher_vectors_all

    def predict_fisher_vector_bags(self, X, bag_ids, normalized=True, return_instance_level=False,
                                   instance_batch_size=None, verbose=False):
        """
        Compute Fisher Vectors for variable-length bags (OPTIMIZED with vectorization).

        This method uses a vectorized approach: computes statistics for all instances at once,
        then aggregates by bag. This is 10-100x faster than the old bag-by-bag approach.

        Args:
            X: Instance-level features with shape (n_instances, feature_dim)
               Each row is a single instance/descriptor
            bag_ids: Array of bag IDs (n_instances,)
                    Maps each instance to its bag. Can be any hashable type (int, str, etc.)
            normalized: Apply improved Fisher Vector normalization
            return_instance_level: If True, also return instance-level Fisher statistics (default: False)
            instance_batch_size: Process instances in batches to avoid OOM (default: None = all at once).
                                For millions of instances, set to e.g., 100000-500000.
            verbose: Print progress

        Returns:
            fisher_vectors: Array of shape (n_bags, 2*n_kernels, feature_dim)
            unique_bag_ids: Array of unique bag IDs corresponding to fisher_vectors rows
            [Optional] instance_fisher_vectors: If return_instance_level=True, returns instance-level FVs

        Examples:
            >>> # Simple SIFT descriptors
            >>> X = np.random.randn(245, 128)  # 245 descriptors, 128-dim
            >>> bag_ids = np.array([0]*50 + [1]*120 + [2]*75)
            >>> fisher_vectors, unique_ids = fv_dl.predict_fisher_vector_bags(X, bag_ids)
            >>> fisher_vectors.shape  # (3, 20, 128) if n_kernels=10

            >>> # For millions of instances - use batching
            >>> fisher_vectors, unique_ids = fv_dl.predict_fisher_vector_bags(
            ...     X_millions, bag_ids_millions, instance_batch_size=100000, verbose=True
            ... )
        """
        assert self.fitted, "Model must be fitted first"
        assert X.ndim == 2, "X must be 2D: (n_instances, feature_dim)"
        assert len(bag_ids) == len(X), "bag_ids must have same length as X"

        # Convert bag_ids to numpy array if not already
        bag_ids = np.asarray(bag_ids)
        n_instances = len(X)

        # Get unique bag IDs in order of first appearance
        _, unique_indices = np.unique(bag_ids, return_index=True)
        unique_bag_ids = bag_ids[np.sort(unique_indices)]
        n_bags = len(unique_bag_ids)

        # Pre-allocate output for bag aggregation
        bag_mean_dev = np.zeros((n_bags, self.n_kernels, self.feature_dim), dtype=np.float32)
        bag_cov_dev = np.zeros((n_bags, self.n_kernels, self.feature_dim), dtype=np.float32)
        bag_counts = np.zeros(n_bags, dtype=np.int32)  # Track number of instances per bag

        # Create a mapping from bag_id to bag_index
        bag_id_to_idx = {bag_id: idx for idx, bag_id in enumerate(unique_bag_ids)}

        # Prepare for instance-level storage if needed
        if return_instance_level:
            instance_mean_dev_list = []
            instance_cov_dev_list = []

        # STEP 1: Compute instance-level Fisher statistics (in batches if needed)
        if instance_batch_size is None or n_instances <= instance_batch_size:
            # Process all at once
            if verbose:
                print(f"Computing instance-level Fisher statistics for {n_instances} instances...")

            mean_dev, cov_dev = self._compute_instance_fisher_statistics(X)

            if verbose:
                print(f"Aggregating by {n_bags} bags...")

            # Aggregate by bag
            for i, bag_id in enumerate(unique_bag_ids):
                mask = bag_ids == bag_id
                bag_mean_dev[i] = mean_dev[mask].mean(axis=0)
                bag_cov_dev[i] = cov_dev[mask].mean(axis=0)

                if verbose and (i + 1) % max(1, n_bags // 10) == 0:
                    print(f"  Aggregated {i+1}/{n_bags} bags ({((i+1)/n_bags)*100:.1f}%)")

            if return_instance_level:
                instance_mean_dev_list = [mean_dev]
                instance_cov_dev_list = [cov_dev]

        else:
            # Process in batches to avoid OOM
            n_batches = int(np.ceil(n_instances / instance_batch_size))

            if verbose:
                print(f"Processing {n_instances} instances in {n_batches} batches of {instance_batch_size}...")

            for batch_idx in range(n_batches):
                start_idx = batch_idx * instance_batch_size
                end_idx = min((batch_idx + 1) * instance_batch_size, n_instances)

                # Get batch
                X_batch = X[start_idx:end_idx]
                bag_ids_batch = bag_ids[start_idx:end_idx]

                # Compute Fisher statistics for this batch
                mean_dev_batch, cov_dev_batch = self._compute_instance_fisher_statistics(X_batch)

                # Accumulate into bag aggregates
                for i, bag_id in enumerate(unique_bag_ids):
                    mask = bag_ids_batch == bag_id
                    if mask.any():
                        # Accumulate sum and count for later averaging
                        bag_mean_dev[i] += mean_dev_batch[mask].sum(axis=0)
                        bag_cov_dev[i] += cov_dev_batch[mask].sum(axis=0)
                        bag_counts[i] += mask.sum()

                if return_instance_level:
                    instance_mean_dev_list.append(mean_dev_batch)
                    instance_cov_dev_list.append(cov_dev_batch)

                if verbose:
                    print(f"  Processed batch {batch_idx+1}/{n_batches} ({end_idx}/{n_instances} instances)")

            # Convert sums to means
            for i in range(n_bags):
                if bag_counts[i] > 0:
                    bag_mean_dev[i] /= bag_counts[i]
                    bag_cov_dev[i] /= bag_counts[i]

            if verbose:
                print(f"✓ Completed aggregation for {n_bags} bags")

        # STEP 2: Concatenate mean and covariance deviations
        fisher_vectors = np.concatenate([bag_mean_dev, bag_cov_dev], axis=1)  # (n_bags, 2*n_kernels, feature_dim)

        # STEP 3: Apply normalization if requested
        if normalized:
            # Power normalization
            fisher_vectors = np.sqrt(np.abs(fisher_vectors)) * np.sign(fisher_vectors)
            # L2 normalization
            norms = np.linalg.norm(fisher_vectors, axis=(1, 2))[:, None, None]
            fisher_vectors = fisher_vectors / (norms + 1e-10)
            # Threshold small values
            fisher_vectors[fisher_vectors < 1e-4] = 0

        if verbose:
            print(f"✓ Completed processing {n_bags} bags from {n_instances} instances")

        if return_instance_level:
            # Concatenate all instance-level results
            if verbose:
                print(f"Assembling instance-level Fisher Vectors...")

            instance_mean_dev = np.concatenate(instance_mean_dev_list, axis=0)
            instance_cov_dev = np.concatenate(instance_cov_dev_list, axis=0)
            instance_fisher_vectors = np.concatenate([instance_mean_dev, instance_cov_dev], axis=1)

            if normalized:
                instance_fisher_vectors = np.sqrt(np.abs(instance_fisher_vectors)) * np.sign(instance_fisher_vectors)
                norms = np.linalg.norm(instance_fisher_vectors, axis=(1, 2))[:, None, None]
                instance_fisher_vectors = instance_fisher_vectors / (norms + 1e-10)
                instance_fisher_vectors[instance_fisher_vectors < 1e-4] = 0

            return fisher_vectors, unique_bag_ids, instance_fisher_vectors
        else:
            return fisher_vectors, unique_bag_ids

    def _compute_instance_fisher_statistics(self, X):
        """
        Compute Fisher Vector statistics for individual instances (vectorized).

        This is the core computation that can be aggregated by bag later.

        Args:
            X: Instance-level features (n_instances, feature_dim)

        Returns:
            mean_dev: Mean deviations (n_instances, n_kernels, feature_dim)
            cov_dev: Covariance deviations (n_instances, n_kernels, feature_dim)
        """
        assert self.fitted, "Model must be fitted first"
        assert X.ndim == 2, "X must be 2D: (n_instances, feature_dim)"
        assert X.shape[1] == self.feature_dim, f"Feature dim mismatch: {X.shape[1]} vs {self.feature_dim}"

        n_instances = X.shape[0]

        # Get GMM parameters
        pi = tf.nn.softmax(self.pi_layer).numpy()
        mu = self.mu_layer.numpy()  # (feature_dim, n_kernels)

        # Compute posterior probabilities (responsibilities) using uniform weights
        equal_weights = np.ones(self.n_kernels) / self.n_kernels

        X_tf = tf.constant(X, dtype=tf.float32)

        if self.covariance_type == 'diag':
            sd = (self.sd_layer + 1e-6).numpy()  # (feature_dim, n_kernels)

            # Compute log probabilities for all instances at once
            x_expanded = tf.expand_dims(X_tf, axis=-1)  # (n_instances, feature_dim, 1)
            mu_expanded = tf.expand_dims(mu, axis=0)  # (1, feature_dim, n_kernels)
            sd_expanded = tf.expand_dims(sd, axis=0)  # (1, feature_dim, n_kernels)

            diff = (x_expanded - mu_expanded) / sd_expanded
            log_prob = -0.5 * tf.reduce_sum(diff**2, axis=1)
            log_prob = log_prob - tf.reduce_sum(tf.math.log(sd_expanded), axis=1)
            log_prob = log_prob - 0.5 * self.feature_dim * tf.math.log(2 * np.pi)
            log_prob = log_prob + tf.math.log(equal_weights + 1e-10)

            # Convert to probabilities (responsibilities)
            log_prob_normalized = log_prob - tf.reduce_logsumexp(log_prob, axis=1, keepdims=True)
            likelihood_ratio = tf.exp(log_prob_normalized).numpy()  # (n_instances, n_kernels)

            # Compute normalized deviations from modes
            var = sd ** 2
            # Broadcast: (n_instances, 1, feature_dim) - (1, n_kernels, feature_dim)
            norm_dev = (X[:, None, :] - mu.T[None, :, :]) / var.T[None, :, :]  # (n_instances, n_kernels, feature_dim)

            # Weight by likelihood ratio
            mean_dev = likelihood_ratio[:, :, None] * norm_dev  # (n_instances, n_kernels, feature_dim)
            mean_dev = mean_dev / np.sqrt(pi[None, :, None])

            # Covariance deviation
            cov_dev = likelihood_ratio[:, :, None] * (norm_dev**2 - 1)
            cov_dev = cov_dev / np.sqrt(2 * pi[None, :, None])

        else:  # full covariance
            # Get Cholesky decomposition and compute covariance matrices
            L = self.cov_layer.numpy()  # (n_kernels, feature_dim, feature_dim)
            cov_matrices = np.array([L[k] @ L[k].T for k in range(self.n_kernels)])
            cov_inv = np.array([np.linalg.inv(cov_matrices[k]) for k in range(self.n_kernels)])

            # Compute log determinants
            log_det = np.array([np.linalg.slogdet(cov_matrices[k])[1] for k in range(self.n_kernels)])

            # Compute log probabilities for each component
            log_prob_list = []
            for k in range(self.n_kernels):
                centered = X - mu[:, k]  # (n_instances, feature_dim)
                mahalanobis_sq = np.sum(centered @ cov_inv[k] * centered, axis=1)  # (n_instances,)
                log_prob_k = -0.5 * (mahalanobis_sq + log_det[k] + self.feature_dim * np.log(2 * np.pi))
                log_prob_list.append(log_prob_k)

            log_prob = np.stack(log_prob_list, axis=1) + np.log(equal_weights + 1e-10)  # (n_instances, n_kernels)

            # Convert to probabilities
            log_prob_normalized = log_prob - np.max(log_prob, axis=1, keepdims=True)
            prob = np.exp(log_prob_normalized)
            likelihood_ratio = prob / (prob.sum(axis=1, keepdims=True) + 1e-10)  # (n_instances, n_kernels)

            # Compute Fisher vector gradients for full covariance
            mean_dev = np.zeros((n_instances, self.n_kernels, self.feature_dim))
            cov_dev = np.zeros((n_instances, self.n_kernels, self.feature_dim))

            for k in range(self.n_kernels):
                # Mean gradient
                centered = X - mu[:, k]  # (n_instances, feature_dim)
                weighted_centered = likelihood_ratio[:, k:k+1] * (centered @ cov_inv[k])  # (n_instances, feature_dim)
                mean_dev[:, k, :] = weighted_centered / np.sqrt(pi[k])

                # Covariance gradient (use diagonal approximation for compatibility)
                quad_form = np.sum(centered @ cov_inv[k] * centered, axis=1)  # (n_instances,)
                cov_grad = likelihood_ratio[:, k] * (quad_form - self.feature_dim)  # (n_instances,)

                diag_var = np.diag(cov_matrices[k])
                cov_dev[:, k, :] = (cov_grad[:, None] / diag_var[None, :]) / np.sqrt(2 * pi[k])

        return mean_dev, cov_dev

    def _predict(self, X, normalized=True):
        """
        Internal method to compute Fisher Vectors.

        Args:
            X: Input features (n_samples, n_features_per_sample, n_descriptors, feature_dim)
            normalized: Apply improved Fisher Vector normalization

        Returns:
            Fisher vectors (n_samples, n_features_per_sample, 2*n_kernels, feature_dim)
        """
        assert self.fitted, "Model must be fitted first"
        assert X.ndim == 4
        assert X.shape[-1] == self.feature_dim

        n_samples, n_features_per_sample = X.shape[0], X.shape[1]

        # Reshape for processing
        X = X.reshape((-1, X.shape[-2], X.shape[-1]))  # (n_samples * n_features_per_sample, n_descriptors, feature_dim)
        X_matrix = X.reshape(-1, X.shape[-1])  # (total_descriptors, feature_dim)

        # Get GMM parameters
        pi = tf.nn.softmax(self.pi_layer).numpy()
        mu = self.mu_layer.numpy()  # (feature_dim, n_kernels)

        # Compute posterior probabilities (responsibilities)
        # Use uniform weights for likelihood ratio as in original implementation
        equal_weights = np.ones(self.n_kernels) / self.n_kernels

        X_tf = tf.constant(X_matrix, dtype=tf.float32)

        if self.covariance_type == 'diag':
            sd = (self.sd_layer + 1e-6).numpy()  # (feature_dim, n_kernels)

            # Compute log probabilities
            x_expanded = tf.expand_dims(X_tf, axis=-1)  # (n_samples, feature_dim, 1)
            mu_expanded = tf.expand_dims(mu, axis=0)  # (1, feature_dim, n_kernels)
            sd_expanded = tf.expand_dims(sd, axis=0)  # (1, feature_dim, n_kernels)

            diff = (x_expanded - mu_expanded) / sd_expanded
            log_prob = -0.5 * tf.reduce_sum(diff**2, axis=1)
            log_prob = log_prob - tf.reduce_sum(tf.math.log(sd_expanded), axis=1)
            log_prob = log_prob - 0.5 * self.feature_dim * tf.math.log(2 * np.pi)
            log_prob = log_prob + tf.math.log(equal_weights + 1e-10)

            # Convert to probabilities
            log_prob_normalized = log_prob - tf.reduce_logsumexp(log_prob, axis=1, keepdims=True)
            likelihood_ratio = tf.exp(log_prob_normalized).numpy()
            likelihood_ratio = likelihood_ratio.reshape(X.shape[0], X.shape[1], self.n_kernels)

            # Compute normalized deviation from modes (for diagonal covariance)
            var = sd ** 2
            norm_dev_from_modes = np.tile(X[:, :, None, :], (1, 1, self.n_kernels, 1))
            np.subtract(norm_dev_from_modes, mu.T[None, None, :, :], out=norm_dev_from_modes)
            np.divide(norm_dev_from_modes, var.T[None, None, :, :], out=norm_dev_from_modes)

            # Mean deviation
            mean_dev = np.multiply(
                likelihood_ratio[:, :, :, None],
                norm_dev_from_modes
            ).mean(axis=1)  # (n_groups, n_kernels, feature_dim)
            mean_dev = np.multiply(1 / np.sqrt(pi[None, :, None]), mean_dev)

            # Covariance deviation
            cov_dev = np.multiply(
                likelihood_ratio[:, :, :, None],
                norm_dev_from_modes**2 - 1
            ).mean(axis=1)
            cov_dev = np.multiply(1 / np.sqrt(2 * pi[None, :, None]), cov_dev)

        else:  # full covariance
            # Get Cholesky decomposition and compute covariance matrices
            L = self.cov_layer.numpy()  # (n_kernels, feature_dim, feature_dim)
            cov_matrices = np.array([L[k] @ L[k].T for k in range(self.n_kernels)])  # (n_kernels, feature_dim, feature_dim)
            cov_inv = np.array([np.linalg.inv(cov_matrices[k]) for k in range(self.n_kernels)])  # (n_kernels, feature_dim, feature_dim)

            # Compute log determinants
            log_det = np.array([np.linalg.slogdet(cov_matrices[k])[1] for k in range(self.n_kernels)])

            # Compute log probabilities for each component
            log_prob_list = []
            for k in range(self.n_kernels):
                centered = X_matrix - mu[:, k]  # (n_samples, feature_dim)
                mahalanobis_sq = np.sum(centered @ cov_inv[k] * centered, axis=1)  # (n_samples,)
                log_prob_k = -0.5 * (mahalanobis_sq + log_det[k] + self.feature_dim * np.log(2 * np.pi))
                log_prob_list.append(log_prob_k)

            log_prob = np.stack(log_prob_list, axis=1) + np.log(equal_weights + 1e-10)  # (n_samples, n_kernels)

            # Convert to probabilities
            log_prob_normalized = log_prob - np.max(log_prob, axis=1, keepdims=True)
            prob = np.exp(log_prob_normalized)
            likelihood_ratio = prob / (prob.sum(axis=1, keepdims=True) + 1e-10)
            likelihood_ratio = likelihood_ratio.reshape(X.shape[0], X.shape[1], self.n_kernels)

            # Compute Fisher vector gradients for full covariance
            mean_dev = np.zeros((X.shape[0], self.n_kernels, self.feature_dim))
            cov_dev = np.zeros((X.shape[0], self.n_kernels, self.feature_dim))

            for k in range(self.n_kernels):
                # Mean gradient
                centered = X - mu[:, k]  # (n_groups, n_descriptors, feature_dim)
                weighted_centered = likelihood_ratio[:, :, k:k+1] * (centered @ cov_inv[k])  # (n_groups, n_descriptors, feature_dim)
                mean_dev[:, k, :] = weighted_centered.mean(axis=1)  # (n_groups, feature_dim)
                mean_dev[:, k, :] *= 1 / np.sqrt(pi[k])

                # Covariance gradient (diagonal elements only for compatibility)
                # For full covariance, we compute the gradient w.r.t. diagonal of precision matrix
                quad_form = np.einsum('...i,ij,...j->...', centered, cov_inv[k], centered)  # (n_groups, n_descriptors)
                cov_grad = likelihood_ratio[:, :, k] * (quad_form - self.feature_dim)  # (n_groups, n_descriptors)

                # Average over features and use diagonal variance as approximation
                diag_var = np.diag(cov_matrices[k])
                cov_dev[:, k, :] = cov_grad.mean(axis=1, keepdims=True) * np.ones((1, self.feature_dim)) / diag_var
                cov_dev[:, k, :] *= 1 / np.sqrt(2 * pi[k])

        # Concatenate mean and covariance deviations
        fisher_vectors = np.concatenate([mean_dev, cov_dev], axis=1)

        # Reshape to separate samples and features
        fisher_vectors = fisher_vectors.reshape(
            (n_samples, n_features_per_sample, fisher_vectors.shape[1], fisher_vectors.shape[2])
        )

        # Apply normalization if requested
        if normalized:
            # Power normalization
            fisher_vectors = np.sqrt(np.abs(fisher_vectors)) * np.sign(fisher_vectors)
            # L2 normalization
            norms = np.linalg.norm(fisher_vectors, axis=(2, 3))[:, :, None, None]
            fisher_vectors = fisher_vectors / (norms + 1e-10)

        # Threshold small values
        fisher_vectors[fisher_vectors < 1e-4] = 0

        return fisher_vectors

    def save_model(self, path):
        """Save model parameters to file."""
        params = {
            'n_kernels': self.n_kernels,
            'feature_dim': self.feature_dim,
            'covariance_type': self.covariance_type,
            'pi': self.pi_layer.numpy(),
            'mu': self.mu_layer.numpy(),
            'fitted': self.fitted
        }

        if self.covariance_type == 'diag':
            params['sd'] = self.sd_layer.numpy()
        else:
            # For full covariance, save the Cholesky factors
            params['cov_cholesky'] = self.cov_layer.numpy()

        with open(path, 'wb') as f:
            pickle.dump(params, f, protocol=4)

    @staticmethod
    def load_model(path):
        """Load model parameters from file."""
        assert os.path.isfile(path), 'Path must be an existing file'

        with open(path, 'rb') as f:
            params = pickle.load(f)

        model = FisherVectorDL(
            n_kernels=params['n_kernels'],
            feature_dim=params['feature_dim'],
            covariance_type=params['covariance_type']
        )

        # Build model
        dummy_input = tf.keras.layers.Input(shape=(params['feature_dim'],), dtype=tf.float32)
        model(dummy_input)

        # Set parameters
        if params['covariance_type'] == 'diag':
            # Reconstruct covariance from standard deviations
            model.set_params(params['pi'], params['mu'], params['sd'])
        else:
            # Reconstruct full covariance from Cholesky factors
            L = params['cov_cholesky']
            cov_matrices = np.array([L[k] @ L[k].T for k in range(params['n_kernels'])])
            model.set_params(params['pi'], params['mu'], cov_matrices)

        model.fitted = params['fitted']

        return model
