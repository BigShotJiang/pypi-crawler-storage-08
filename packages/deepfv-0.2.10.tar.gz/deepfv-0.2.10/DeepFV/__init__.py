from DeepFV.FisherVectorDL import FisherVectorDL

__all__ = ['FisherVectorDL']
__version__ = '0.2.0'