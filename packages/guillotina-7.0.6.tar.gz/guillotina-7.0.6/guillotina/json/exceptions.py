# -*- coding: utf-8 -*-
# b/w compat imports
from guillotina.exceptions import DeserializationError  # noqa
from guillotina.exceptions import QueryParsingError  # noqa
from guillotina.exceptions import ValueDeserializationError  # noqa
