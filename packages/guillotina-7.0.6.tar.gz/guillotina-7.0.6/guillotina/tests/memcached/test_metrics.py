try:
    from guillotina.contrib.memcached.driver import MemcachedDriver
except ModuleNotFoundError:
    MemcachedDriver = None  # type: ignore

from asyncmock import AsyncMock

import pytest


pytestmark = pytest.mark.asyncio


@pytest.mark.skipif(MemcachedDriver is None, reason="emcache not installed")
class TestMemcachedMetrics:
    async def test_connect_metric(self, metrics_registry, event_loop):
        driver = MemcachedDriver()
        driver._client = AsyncMock()
        await driver.initialize(event_loop)
        assert (
            metrics_registry.get_sample_value(
                "guillotina_cache_memcached_ops_total", {"type": "connect", "error": "none"}
            )
            == 1.0
        )
        assert (
            metrics_registry.get_sample_value(
                "guillotina_cache_memcached_ops_processing_time_seconds_sum", {"type": "connect"}
            )
            > 0
        )

    async def test_set_memcached_metric(self, metrics_registry):
        driver = MemcachedDriver()
        driver._client = AsyncMock()
        await driver.set("foo", "bar")

        assert (
            metrics_registry.get_sample_value(
                "guillotina_cache_memcached_ops_total", {"type": "set", "error": "none"}
            )
            == 1.0
        )
        assert (
            metrics_registry.get_sample_value(
                "guillotina_cache_memcached_ops_processing_time_seconds_sum", {"type": "set"}
            )
            > 0
        )

    async def test_get_memcached_metric(self, metrics_registry):
        driver = MemcachedDriver()
        driver._client = AsyncMock()
        await driver.get("foo")
        assert (
            metrics_registry.get_sample_value(
                "guillotina_cache_memcached_ops_total", {"type": "get", "error": "none"}
            )
            == 1.0
        )
        assert (
            metrics_registry.get_sample_value(
                "guillotina_cache_memcached_ops_processing_time_seconds_sum", {"type": "get"}
            )
            > 0
        )

    async def test_get_miss_memcached_metric(self, metrics_registry):
        driver = MemcachedDriver()
        driver._client = AsyncMock()
        driver._client.get.return_value = None
        await driver.get("foo")
        assert (
            metrics_registry.get_sample_value(
                "guillotina_cache_memcached_ops_total", {"type": "get_miss", "error": "none"}
            )
            == 1.0
        )
        assert (
            metrics_registry.get_sample_value(
                "guillotina_cache_memcached_ops_processing_time_seconds_sum", {"type": "get_miss"}
            )
            > 0
        )

    async def test_delete_memcached_metric(self, metrics_registry):
        driver = MemcachedDriver()
        driver._client = AsyncMock()
        await driver.delete("foo")
        assert (
            metrics_registry.get_sample_value(
                "guillotina_cache_memcached_ops_total", {"type": "delete", "error": "none"}
            )
            == 1.0
        )
        assert (
            metrics_registry.get_sample_value(
                "guillotina_cache_memcached_ops_processing_time_seconds_sum", {"type": "delete"}
            )
            > 0
        )

    async def test_delete_many_memcached_metric(self, metrics_registry):
        driver = MemcachedDriver()
        driver._client = AsyncMock()
        await driver.delete_all(["foo", "bar"])
        assert (
            metrics_registry.get_sample_value(
                "guillotina_cache_memcached_ops_total", {"type": "delete_many", "error": "none"}
            )
            == 1.0
        )
        assert (
            metrics_registry.get_sample_value(
                "guillotina_cache_memcached_ops_processing_time_seconds_sum", {"type": "delete_many"}
            )
            > 0
        )
        assert (
            metrics_registry.get_sample_value(
                "guillotina_cache_memcached_ops_total", {"type": "delete", "error": "none"}
            )
            == 2.0
        )
        assert (
            metrics_registry.get_sample_value(
                "guillotina_cache_memcached_ops_processing_time_seconds_sum", {"type": "delete"}
            )
            > 0
        )
        assert metrics_registry.get_sample_value("guillotina_cache_memcached_delete_all_num_keys_sum") > 0
