import os


TEST_DIR = os.path.dirname(os.path.realpath(__file__))
TEST_RESOURCES_DIR = os.path.join(TEST_DIR, "resources")
