import os.path


TEST_DATA_LOCATION = os.path.join(os.path.dirname(__file__), "data")
