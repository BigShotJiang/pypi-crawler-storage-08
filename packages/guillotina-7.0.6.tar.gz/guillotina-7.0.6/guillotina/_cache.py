SCHEMA_CACHE: dict = {}
PERMISSIONS_CACHE: dict = {}
FACTORY_CACHE: dict = {}
BEHAVIOR_CACHE: dict = {}
