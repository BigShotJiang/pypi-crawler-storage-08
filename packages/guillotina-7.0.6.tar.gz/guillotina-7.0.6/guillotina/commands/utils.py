def change_transaction_strategy(*args):
    """
    now a noop, leave around
    """
