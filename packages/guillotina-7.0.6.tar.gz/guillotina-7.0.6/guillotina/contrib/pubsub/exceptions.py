class NoPubSubDriver(Exception):
    pass
