class NoMemcachedConfigured(Exception):
    pass
