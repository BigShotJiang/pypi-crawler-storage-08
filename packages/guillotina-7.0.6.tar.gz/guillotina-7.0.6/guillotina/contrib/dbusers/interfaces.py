from zope.interface import Interface


class IDBUsersLayer(Interface):
    """Marker interface layer for db users"""
