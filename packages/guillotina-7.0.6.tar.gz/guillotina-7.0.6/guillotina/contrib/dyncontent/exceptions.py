class VocabularySettingNotFound(Exception):
    pass
