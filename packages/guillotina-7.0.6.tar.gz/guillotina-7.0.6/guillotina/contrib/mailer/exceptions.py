class NoEndpointDefinedException(Exception):
    pass
