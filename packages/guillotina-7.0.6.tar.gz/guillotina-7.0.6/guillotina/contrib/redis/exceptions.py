class NoRedisConfigured(Exception):
    pass
