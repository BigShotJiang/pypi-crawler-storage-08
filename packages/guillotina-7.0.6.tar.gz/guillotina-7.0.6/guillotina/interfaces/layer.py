from zope.interface import Interface


class IDefaultLayer(Interface):
    pass
