from zope.interface import Interface


class IMigration(Interface):
    pass
