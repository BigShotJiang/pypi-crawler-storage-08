# base root object
ROOT_ID = "0" * 32

# object to reassign parent id to when you are deleting
TRASHED_ID = "D" * 32
