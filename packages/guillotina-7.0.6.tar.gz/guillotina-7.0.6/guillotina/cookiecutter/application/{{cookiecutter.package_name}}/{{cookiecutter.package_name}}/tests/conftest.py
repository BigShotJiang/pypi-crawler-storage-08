pytest_plugins = [
    'guillotina.tests.fixtures',
    '{{cookiecutter.package_name}}.tests.fixtures'
]
