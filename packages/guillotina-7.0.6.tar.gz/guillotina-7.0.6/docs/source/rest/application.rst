Application
===========


.. http:gapi::
   :path: /
   :basic_auth: root:root

.. http:gapi::
   :path: /@apidefinition
   :basic_auth: root:root

.. http:gapi::
   :path: /@component-subscribers
   :basic_auth: root:root
