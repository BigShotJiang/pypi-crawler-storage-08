:mod:`guillotina.factory`
-------------------------

.. automodule:: guillotina.factory.app

  .. autofunction:: make_app
