:mod:`guillotina.component`
---------------------------

.. automodule:: guillotina.component

  .. autofunction:: get_adapter
  .. autofunction:: get_adapters
  .. autofunction:: get_multi_adapter
  .. autofunction:: query_adapter
  .. autofunction:: query_multi_adapter
  .. autofunction:: get_utility
  .. autofunction:: query_utility
  .. autofunction:: get_all_utilities_registered_for
  .. autofunction:: get_utilities_for
