:mod:`guillotina.request`
--------------------------

.. automodule:: guillotina.request

    .. autoclass:: Request
        :members:
        :show-inheritance: