:mod:`guillotina.transactions`
------------------------------

.. automodule:: guillotina.transactions

  .. autofunction:: commit
  .. autofunction:: abort
  .. autofunction:: get_tm
  .. autofunction:: get_transaction

  .. autoclass:: transaction

