:mod:`guillotina.contentapi`
----------------------------

.. automodule:: guillotina.contentapi

  .. autoclass:: ContentAPI
     :members: db, tm, request, use_container, get_transaction, create, get, delete, abort, commit
