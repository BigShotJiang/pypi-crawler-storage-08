# Vocabularies

`guillotina` provides out of the box basic vocabularies.

## Defined

- countries: List of countries
- languages: List of languages
