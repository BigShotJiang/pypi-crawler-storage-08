"""Google

This subpackage includes functionality for working with various Google 
APIs
"""