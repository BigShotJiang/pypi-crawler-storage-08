#!/usr/bin/env python
"""
UniversalPython.

Python, but in different human languages.
"""

__author__ = 'Saad Bazaz'
__credits__ = 'Grayhat'
__url__ = 'https://github.com/UniversalPython/UniversalPython'

from .universalpython import *
