"""
Claude Sync - Sync local Claude Code environment to remote machines

A utility to sync .claude folder, claude.json, MCP servers, and agents
to remote servers (Vast.ai, RunPod, SSH) with environment compatibility checks.
"""

__version__ = "0.1.0"
