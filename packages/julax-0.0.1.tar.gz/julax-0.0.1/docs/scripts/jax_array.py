import jax


def get_name():
    return __name__
