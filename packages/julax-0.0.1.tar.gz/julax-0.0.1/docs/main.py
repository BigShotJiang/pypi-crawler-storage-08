def main():
    print("Hello from julax!")


if __name__ == "__main__":
    main()
