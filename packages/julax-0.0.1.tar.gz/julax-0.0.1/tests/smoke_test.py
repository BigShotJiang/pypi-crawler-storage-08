from julax import main

main()
