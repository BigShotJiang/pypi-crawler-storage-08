import fasta
import sequence