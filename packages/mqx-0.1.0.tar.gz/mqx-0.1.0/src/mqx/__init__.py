def main() -> None:
    print("Hello from mq!")
