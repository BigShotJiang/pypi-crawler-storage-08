raise Exception(
    'EditTable/EditColumn has moved out of iommi.experimental. Update imports and remove the .experimental part.'
)
