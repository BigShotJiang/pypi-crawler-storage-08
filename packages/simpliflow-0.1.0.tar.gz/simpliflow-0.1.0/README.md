# simpliflow

This repository https://github.com/DevenPanchal/simpliflow, contains the code for the simpliflow package itself.

To start using simpliflow, refer to: https://github.com/DevenPanchal/simpliflow-usage and install simpliflow using  
```pip install simpliflow``` 

simpliflow package on PyPI: https://pypi.org/project/simpliflow/ 

Read about simpliflow : https://devenpanchal.github.io/simpliflow-website/
