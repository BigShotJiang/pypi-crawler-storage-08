import asyncio
import logging

import httpx
from google.protobuf.message import Message, DecodeError

from PasarGuardNodeBridge.controller import NodeAPIError, Health
from PasarGuardNodeBridge.common import service_pb2 as service
from PasarGuardNodeBridge.abstract_node import PasarGuardNode


class Node(PasarGuardNode):
    def __init__(
        self,
        address: str,
        port: int,
        server_ca: str,
        api_key: str,
        name: str = "default",
        extra: dict | None = None,
        max_logs: int = 1000,
        logger: logging.Logger | None = None,
    ):
        super().__init__(server_ca, api_key, name, extra, max_logs, logger)

        url = f"https://{address.strip('/')}:{port}/"

        self._client = httpx.AsyncClient(
            http2=True,
            verify=self.ctx,
            headers={"Content-Type": "application/x-protobuf", "x-api-key": api_key},
            base_url=url,
            timeout=httpx.Timeout(None),
        )

        self._node_lock = asyncio.Lock()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.stop()
        await self._client.aclose()

    def _serialize_protobuf(self, proto_message: Message) -> bytes:
        """Serialize a protobuf message to bytes."""
        return proto_message.SerializeToString()

    def _deserialize_protobuf(self, proto_class: type[Message], data: bytes) -> Message:
        """Deserialize bytes into a protobuf message."""
        proto_instance = proto_class()
        try:
            proto_instance.ParseFromString(data)
        except DecodeError as e:
            raise NodeAPIError(code=-2, detail=f"Error deserialising protobuf: {e}")
        return proto_instance

    def _handle_error(self, error: Exception):
        if isinstance(error, httpx.RemoteProtocolError):
            raise NodeAPIError(code=-1, detail=f"Server closed connection: {error}")
        elif isinstance(error, httpx.HTTPStatusError):
            raise NodeAPIError(code=error.response.status_code, detail=f"HTTP error: {error.response.text}")
        elif isinstance(error, httpx.ConnectError) or isinstance(error, httpx.ReadTimeout):
            raise NodeAPIError(code=-1, detail=f"Connection error: {error}")
        else:
            raise NodeAPIError(0, str(error))

    async def _make_request(
        self,
        method: str,
        endpoint: str,
        timeout: int,
        proto_message: Message = None,
        proto_response_class: type[Message] = None,
    ) -> Message:
        """Handle common REST API call logic with protobuf support (async)."""
        request_data = None

        if proto_message:
            request_data = self._serialize_protobuf(proto_message)

        try:
            response = await self._client.request(
                method=method,
                url=endpoint,
                content=request_data,
                timeout=timeout,
            )
            response.raise_for_status()

            if proto_response_class:
                return self._deserialize_protobuf(proto_response_class, response.content)
            return response.content

        except Exception as e:
            self._handle_error(e)

    async def start(
        self,
        config: str,
        backend_type: service.BackendType,
        users: list[service.User],
        keep_alive: int = 0,
        ghather_logs: bool = True,
        exclude_inbounds: list[str] = [],
        timeout: int = 10,
    ):
        """Start the node with proper task management"""
        health = await self.get_health()
        if health in (Health.BROKEN, Health.HEALTHY):
            await self.stop()
        elif health is Health.INVALID:
            raise NodeAPIError(code=-4, detail="Invalid node")

        async with self._node_lock:
            response: service.BaseInfoResponse = await self._make_request(
                method="POST",
                endpoint="start",
                timeout=timeout,
                proto_message=service.Backend(
                    type=backend_type,
                    config=config,
                    users=users,
                    keep_alive=keep_alive,
                    exclude_inbounds=exclude_inbounds,
                ),
                proto_response_class=service.BaseInfoResponse,
            )

            if not response.started:
                raise NodeAPIError(500, "Failed to start the node")

            try:
                tasks = [self._sync_user]

                if ghather_logs:
                    tasks.append(self._fetch_logs)

                await self.connect(response.node_version, response.core_version, tasks)
            except Exception as e:
                await self.disconnect()
                raise e

        return response

    async def stop(self, timeout: int = 10) -> None:
        """Stop the node with proper cleanup"""
        if await self.get_health() is Health.NOT_CONNECTED:
            return

        async with self._node_lock:
            await self.disconnect()

            try:
                await self._make_request(method="PUT", endpoint="stop", timeout=timeout)
            except Exception:
                pass

    async def info(self, timeout: int = 10) -> service.BaseInfoResponse | None:
        return await self._make_request(
            method="GET", endpoint="info", timeout=timeout, proto_response_class=service.BaseInfoResponse
        )

    async def get_system_stats(self, timeout: int = 10) -> service.SystemStatsResponse | None:
        return await self._make_request(
            method="GET", endpoint="stats/system", timeout=timeout, proto_response_class=service.SystemStatsResponse
        )

    async def get_backend_stats(self, timeout: int = 10) -> service.BackendStatsResponse | None:
        return await self._make_request(
            method="GET", endpoint="stats/backend", timeout=timeout, proto_response_class=service.BackendStatsResponse
        )

    async def get_stats(
        self, stat_type: service.StatType, reset: bool = True, name: str = "", timeout: int = 10
    ) -> service.StatResponse | None:
        return await self._make_request(
            method="GET",
            endpoint="stats",
            timeout=timeout,
            proto_message=service.StatRequest(reset=reset, name=name, type=stat_type),
            proto_response_class=service.StatResponse,
        )

    async def get_user_online_stats(self, email: str, timeout: int = 10) -> service.OnlineStatResponse | None:
        return await self._make_request(
            method="GET",
            endpoint="stats/user/online",
            timeout=timeout,
            proto_message=service.StatRequest(name=email),
            proto_response_class=service.OnlineStatResponse,
        )

    async def get_user_online_ip_list(self, email: str, timeout: int = 10) -> service.StatsOnlineIpListResponse | None:
        return await self._make_request(
            method="GET",
            endpoint="stats/user/online_ip",
            timeout=timeout,
            proto_message=service.StatRequest(name=email),
            proto_response_class=service.StatsOnlineIpListResponse,
        )

    async def sync_users(
        self, users: list[service.User], flush_queue: bool = False, timeout: int = 10
    ) -> service.Empty | None:
        if flush_queue:
            await self.flush_user_queue()

        async with self._node_lock:
            return await self._make_request(
                method="PUT",
                endpoint="users/sync",
                timeout=timeout,
                proto_message=service.Users(users=users),
                proto_response_class=service.Empty,
            )

    async def _sync_user_with_retry(self, user: service.User, max_retries: int = 3, timeout: int = 10) -> bool:
        """
        Attempt to sync a user with retry logic for timeout errors.
        Returns True if successful, False if all retries failed.
        """
        for attempt in range(max_retries):
            try:
                await self._make_request(
                    method="PUT",
                    endpoint="user/sync",
                    timeout=timeout,
                    proto_message=user,
                    proto_response_class=service.Empty,
                )
                return True
            except NodeAPIError as e:
                # Retry only on timeout (code -1)
                if e.code == -1 and attempt < max_retries - 1:
                    self.logger.debug(
                        f"[{self.name}] Timeout syncing user {user.email}, retry {attempt + 1}/{max_retries} | "
                        f"Error: NodeAPIError(code={e.code}) - {e.detail}"
                    )
                    await asyncio.sleep(0.5)
                    continue
                # For other errors or last attempt, log and return failure
                self.logger.warning(
                    f"[{self.name}] Failed to sync user {user.email} after {attempt + 1} attempts | "
                    f"Error: NodeAPIError(code={e.code}) - {e.detail}"
                )
                return False
            except Exception as e:
                # Unexpected error, don't retry
                error_type = type(e).__name__
                self.logger.error(
                    f"[{self.name}] Unexpected error syncing user {user.email} | " f"Error: {error_type} - {str(e)}",
                    exc_info=True,
                )
                return False
        return False

    async def _check_node_health(self):
        """Health check task with proper cancellation handling"""
        health_check_interval = 10
        max_retries = 3
        retry_delay = 2
        retries = 0
        self.logger.info(f"[{self.name}] Health check task started")

        try:
            while not self.is_shutting_down():
                last_health = await self.get_health()

                if last_health in (Health.NOT_CONNECTED, Health.INVALID):
                    self.logger.info(f"[{self.name}] Health check task stopped due to node state")
                    break

                try:
                    await asyncio.wait_for(self.get_backend_stats(), timeout=10)
                    if last_health != Health.HEALTHY:
                        self.logger.info(f"[{self.name}] Node health is HEALTHY")
                        await self.set_health(Health.HEALTHY)
                    retries = 0
                except Exception as e:
                    retries += 1
                    error_type = type(e).__name__
                    if retries >= max_retries:
                        if last_health != Health.BROKEN:
                            self.logger.error(
                                f"[{self.name}] Health check failed after {max_retries} retries, setting health to BROKEN | "
                                f"Error: {error_type} - {str(e)}"
                            )
                            await self.set_health(Health.BROKEN)
                    else:
                        self.logger.warning(
                            f"[{self.name}] Health check failed, retry {retries}/{max_retries} in {retry_delay}s | "
                            f"Error: {error_type} - {str(e)}"
                        )
                        await asyncio.sleep(retry_delay)
                        continue

                try:
                    await asyncio.wait_for(asyncio.sleep(health_check_interval), timeout=health_check_interval + 1)
                except asyncio.TimeoutError:
                    continue

        except asyncio.CancelledError:
            self.logger.info(f"[{self.name}] Health check task cancelled")
        except Exception as e:
            error_type = type(e).__name__
            self.logger.error(
                f"[{self.name}] Unexpected error in health check task | Error: {error_type} - {str(e)}", exc_info=True
            )
            try:
                await self.set_health(Health.BROKEN)
            except Exception as e_set_health:
                error_type_set = type(e_set_health).__name__
                self.logger.error(
                    f"[{self.name}] Failed to set health to BROKEN | Error: {error_type_set} - {str(e_set_health)}",
                    exc_info=True,
                )
        finally:
            self.logger.info(f"[{self.name}] Health check task finished")

    async def _should_continue_task(self, task_name: str) -> bool:
        """Check if task should continue based on health status.

        Returns:
            True if task should continue, False if task should stop
        """
        health = await self.get_health()

        if health in (Health.NOT_CONNECTED, Health.INVALID):
            self.logger.info(f"[{self.name}] {task_name} stopped due to node state")
            return False
        return True

    async def _wait_for_healthy_state(self, retry_delay: float, max_retry_delay: float) -> float:
        """Wait if node is broken, returns updated retry_delay."""
        health = await self.get_health()

        if health == Health.BROKEN:
            self.logger.warning(f"[{self.name}] Node is broken, waiting for {retry_delay} seconds")
            try:
                await asyncio.wait_for(asyncio.sleep(retry_delay), timeout=retry_delay + 1)
            except asyncio.TimeoutError:
                pass
            return min(retry_delay * 1.5, max_retry_delay)
        return retry_delay

    async def _process_log_stream(self, response) -> bool:
        """Process incoming log stream chunks.

        Returns:
            True if stream completed successfully, False if stream failed
        """
        buffer = b""

        async for chunk in response.aiter_bytes():
            if self.is_shutting_down():
                return True

            buffer += chunk

            while b"\n" in buffer:
                line, buffer = buffer.split(b"\n", 1)
                line = line.decode().strip()

                if line:
                    logs_queue = await self.get_logs()
                    if logs_queue:
                        await logs_queue.put(line)

        return True

    async def _open_and_process_log_stream(self) -> bool:
        """Open log stream and process it.

        Returns:
            True if successful, False if failed
        """
        try:
            self.logger.info(f"[{self.name}] Opening log stream")
            async with self._client.stream("GET", "/logs", timeout=60) as response:
                self.logger.info(f"[{self.name}] Log stream opened successfully")
                return await self._process_log_stream(response)
        except asyncio.CancelledError:
            self.logger.info(f"[{self.name}] Log stream cancelled")
            raise
        except Exception as e:
            error_type = type(e).__name__
            self.logger.error(f"[{self.name}] Log stream failed | Error: {error_type} - {str(e)}", exc_info=True)
            return False

    async def _fetch_logs(self):
        """Log fetching task with proper cancellation handling"""
        retry_delay = 10.0
        max_retry_delay = 60.0
        log_retry_delay = 1.0
        self.logger.info(f"[{self.name}] Log fetching task started")

        try:
            while not self.is_shutting_down():
                if not await self._should_continue_task("Log fetching task"):
                    break

                retry_delay = await self._wait_for_healthy_state(retry_delay, max_retry_delay)
                health = await self.get_health()
                if health == Health.BROKEN:
                    continue

                # Reset retry delay when healthy
                retry_delay = 10.0

                # Try to open and process log stream
                stream_success = await self._open_and_process_log_stream()

                if not stream_success:
                    self.logger.warning(f"[{self.name}] Log stream failed, retrying in {log_retry_delay} seconds")
                    try:
                        await asyncio.wait_for(asyncio.sleep(log_retry_delay), timeout=log_retry_delay + 1)
                    except asyncio.TimeoutError:
                        pass
                    log_retry_delay = min(log_retry_delay * 2, max_retry_delay)
                else:
                    log_retry_delay = 1.0

        except asyncio.CancelledError:
            self.logger.info(f"[{self.name}] Log fetching task cancelled")
        finally:
            self.logger.info(f"[{self.name}] Log fetching task finished")

    async def _get_user_queues(self):
        """Get user and notify queue references with minimal lock scope.

        Returns:
            Tuple of (user_queue, notify_queue) or (None, None) if unavailable
        """
        async with self._queue_lock:
            return self._user_queue, self._notify_queue

    async def _wait_for_user_or_notification(self, user_queue, notify_queue):
        """Wait for either a user or notification from queues.

        Returns:
            Tuple of (done_tasks, pending_tasks)
        """
        user_task = asyncio.create_task(user_queue.get())
        notify_task = asyncio.create_task(notify_queue.get())

        done, pending = await asyncio.wait([user_task, notify_task], return_when=asyncio.FIRST_COMPLETED, timeout=30)

        # Cancel pending tasks
        for task in pending:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        return done, user_task, notify_task

    async def _handle_user_sync(self, user, sync_retry_delay: float, max_retry_delay: float) -> float:
        """Sync a single user and handle retry logic.

        Returns:
            Updated sync_retry_delay
        """
        self.logger.info(f"[{self.name}] Syncing user {user.email}")
        success = await self._sync_user_with_retry(user, max_retries=3, timeout=10)

        if success:
            self.logger.info(f"[{self.name}] Successfully synced user {user.email}")
            return 1.0
        else:
            self.logger.warning(f"[{self.name}] Failed to sync user {user.email}, requeueing")
            await self.requeue_user_with_deduplication(user)
            try:
                await asyncio.wait_for(asyncio.sleep(sync_retry_delay), timeout=sync_retry_delay + 1)
            except asyncio.TimeoutError:
                pass
            return min(sync_retry_delay * 2, max_retry_delay)

    async def _process_sync_iteration(self, retry_delay: float, sync_retry_delay: float, max_retry_delay: float):
        """Process one iteration of user sync.

        Returns:
            Tuple of (updated_retry_delay, updated_sync_retry_delay, should_continue)
        """
        # Get queue references
        user_queue, notify_queue = await self._get_user_queues()

        if user_queue is None or notify_queue is None:
            self.logger.warning(f"[{self.name}] User queues are None, waiting before retry...")
            await asyncio.sleep(retry_delay)
            return min(retry_delay * 1.5, max_retry_delay), sync_retry_delay, True

        # Wait for user or notification
        done, user_task, notify_task = await self._wait_for_user_or_notification(user_queue, notify_queue)

        if not done:
            return retry_delay, sync_retry_delay, True

        # Handle notification
        if notify_task in done:
            notify_result = notify_task.result()
            if notify_result is None:
                self.logger.info(f"[{self.name}] Received notification to renew queues, continuing...")
            return retry_delay, sync_retry_delay, True

        # Handle user sync
        if user_task in done:
            user = user_task.result()
            if user is None:
                self.logger.info(f"[{self.name}] Received None user, continuing...")
                return retry_delay, sync_retry_delay, True

            updated_sync_retry_delay = await self._handle_user_sync(user, sync_retry_delay, max_retry_delay)
            return 10.0, updated_sync_retry_delay, True

        return retry_delay, sync_retry_delay, True

    async def _sync_user(self) -> None:
        """User sync task with proper cancellation handling"""
        retry_delay = 10.0
        max_retry_delay = 60.0
        sync_retry_delay = 1.0
        self.logger.info(f"[{self.name}] User sync task started")

        try:
            while not self.is_shutting_down():
                if not await self._should_continue_task("User sync task"):
                    break

                retry_delay = await self._wait_for_healthy_state(retry_delay, max_retry_delay)
                health = await self.get_health()
                if health == Health.BROKEN:
                    continue

                try:
                    retry_delay, sync_retry_delay, _ = await self._process_sync_iteration(
                        retry_delay, sync_retry_delay, max_retry_delay
                    )
                except asyncio.CancelledError:
                    self.logger.info(f"[{self.name}] User sync task cancelled")
                    break
                except Exception as e:
                    error_type = type(e).__name__
                    self.logger.error(
                        f"[{self.name}] Error in user sync task | Error: {error_type} - {str(e)}", exc_info=True
                    )
                    try:
                        await asyncio.wait_for(asyncio.sleep(sync_retry_delay), timeout=sync_retry_delay + 1)
                    except asyncio.TimeoutError:
                        pass
                    sync_retry_delay = min(sync_retry_delay * 2, max_retry_delay)

        except asyncio.CancelledError:
            self.logger.info(f"[{self.name}] User sync task cancelled")
        finally:
            self.logger.info(f"[{self.name}] User sync task finished")
