<!-- THIS FILE IS EXCLUSIVELY MAINTAINED by the project ae.ae v0.3.100 -->
<!-- THIS FILE IS EXCLUSIVELY MAINTAINED by the project aedev.namespace_root_tpls v0.3.21 -->
# pythonanywhere 0.3.2

[![GitLab develop](https://img.shields.io/gitlab/pipeline/ae-group/ae_pythonanywhere/develop?logo=python)](
    https://gitlab.com/ae-group/ae_pythonanywhere)
[![LatestPyPIrelease](
    https://img.shields.io/gitlab/pipeline/ae-group/ae_pythonanywhere/release0.3.2?logo=python)](
    https://gitlab.com/ae-group/ae_pythonanywhere/-/tree/release0.3.2)
[![PyPIVersions](https://img.shields.io/pypi/v/ae_pythonanywhere)](
    https://pypi.org/project/ae-pythonanywhere/#history)

>ae namespace module portion pythonanywhere: PythonAnywhere Web API Client.

[![Coverage](https://ae-group.gitlab.io/ae_pythonanywhere/coverage.svg)](
    https://ae-group.gitlab.io/ae_pythonanywhere/coverage/index.html)
[![MyPyPrecision](https://ae-group.gitlab.io/ae_pythonanywhere/mypy.svg)](
    https://ae-group.gitlab.io/ae_pythonanywhere/lineprecision.txt)
[![PyLintScore](https://ae-group.gitlab.io/ae_pythonanywhere/pylint.svg)](
    https://ae-group.gitlab.io/ae_pythonanywhere/pylint.log)

[![PyPIImplementation](https://img.shields.io/pypi/implementation/ae_pythonanywhere)](
    https://gitlab.com/ae-group/ae_pythonanywhere/)
[![PyPIPyVersions](https://img.shields.io/pypi/pyversions/ae_pythonanywhere)](
    https://gitlab.com/ae-group/ae_pythonanywhere/)
[![PyPIWheel](https://img.shields.io/pypi/wheel/ae_pythonanywhere)](
    https://gitlab.com/ae-group/ae_pythonanywhere/)
[![PyPIFormat](https://img.shields.io/pypi/format/ae_pythonanywhere)](
    https://pypi.org/project/ae-pythonanywhere/)
[![PyPILicense](https://img.shields.io/pypi/l/ae_pythonanywhere)](
    https://gitlab.com/ae-group/ae_pythonanywhere/-/blob/develop/LICENSE.md)
[![PyPIStatus](https://img.shields.io/pypi/status/ae_pythonanywhere)](
    https://libraries.io/pypi/ae-pythonanywhere)
[![PyPIDownloads](https://img.shields.io/pypi/dm/ae_pythonanywhere)](
    https://pypi.org/project/ae-pythonanywhere/#files)


## installation


execute the following command to install the
ae.pythonanywhere module
in the currently active virtual environment:
 
```shell script
pip install ae-pythonanywhere
```

if you want to contribute to this portion then first fork
[the ae_pythonanywhere repository at GitLab](
https://gitlab.com/ae-group/ae_pythonanywhere "ae.pythonanywhere code repository").
after that pull it to your machine and finally execute the
following command in the root folder of this repository
(ae_pythonanywhere):

```shell script
pip install -e .[dev]
```

the last command will install this module portion, along with the tools you need
to develop and run tests or to extend the portion documentation. to contribute only to the unit tests or to the
documentation of this portion, replace the setup extras key `dev` in the above command with `tests` or `docs`
respectively.

more detailed explanations on how to contribute to this project
[are available here](
https://gitlab.com/ae-group/ae_pythonanywhere/-/blob/develop/CONTRIBUTING.rst)


## namespace portion documentation

information on the features and usage of this portion are available at
[ReadTheDocs](
https://ae.readthedocs.io/en/latest/_autosummary/ae.pythonanywhere.html
"ae_pythonanywhere documentation").
