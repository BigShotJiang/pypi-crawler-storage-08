"""Slurm logics."""
