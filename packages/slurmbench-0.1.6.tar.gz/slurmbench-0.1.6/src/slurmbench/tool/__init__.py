"""Tools abstract module."""
