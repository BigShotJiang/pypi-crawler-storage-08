"""Prelude topics description."""

# Due to typer usage:
# ruff: noqa: PLC0414

from slurmbench.topic.description import Description as Description
