"""Prelude module for tool."""
