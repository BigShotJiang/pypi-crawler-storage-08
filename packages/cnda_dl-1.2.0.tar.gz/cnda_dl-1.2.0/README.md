# Installation

We recommend installing cnda-dl with [pipx](https://github.com/pypa/pipx), which ensures that the cnda-dl binary is installed in an isolated environment. Installation instructions can be found [here](https://github.com/pypa/pipx?tab=readme-ov-file#install-pipx).

With `pipx` installed:

```
pipx install cnda_dl
```
