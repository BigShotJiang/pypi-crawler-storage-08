"""OpenBB News extension."""
