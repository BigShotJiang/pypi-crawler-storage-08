# OpenBB News Extension

This extension provides news for the OpenBB Platform.

## Installation

To install the extension, run the following command in this folder:

```bash
pip install openbb-news
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
