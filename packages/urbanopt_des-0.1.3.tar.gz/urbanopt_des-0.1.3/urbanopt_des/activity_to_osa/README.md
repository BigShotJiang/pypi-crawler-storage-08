# Notes

The measures in this directory are copied from the openstudio calibration gem. Only certain measures are copied to
save space.
