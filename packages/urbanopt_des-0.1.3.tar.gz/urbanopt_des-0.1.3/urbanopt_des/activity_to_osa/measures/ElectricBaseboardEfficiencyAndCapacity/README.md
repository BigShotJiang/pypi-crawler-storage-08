###### (Automatically generated documentation)

# Electric Baseboard Efficiency And Capacity

## Description

Electric Baseboard Efficiency And Capacity

## Modeler Description

Electric Baseboard Efficiency And Capacity

## Measure Type

ModelMeasure

## Taxonomy

## Arguments

### efficiency

**Name:** base_eff,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Nominal Capacity (W)

**Name:** nom_cap,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false
