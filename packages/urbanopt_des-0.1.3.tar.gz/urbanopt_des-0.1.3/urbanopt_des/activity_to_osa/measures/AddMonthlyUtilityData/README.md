###### (Automatically generated documentation)

# AddMonthlyUtilityData

## Description

## Modeler Description

## Measure Type

ModelMeasure

## Taxonomy

## Arguments

### Path to electric JSON

**Name:** electric_json,
**Type:** String,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Path to gas JSON

**Name:** gas_json,
**Type:** String,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Path to water JSON

**Name:** water_json,
**Type:** String,
**Units:** ,
**Required:** false,
**Model Dependent:** false

### Start date

YYYY-MM-DD format
**Name:** start_date,
**Type:** String,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### End date

YYYY-MM-DD format
**Name:** end_date,
**Type:** String,
**Units:** ,
**Required:** true,
**Model Dependent:** false
