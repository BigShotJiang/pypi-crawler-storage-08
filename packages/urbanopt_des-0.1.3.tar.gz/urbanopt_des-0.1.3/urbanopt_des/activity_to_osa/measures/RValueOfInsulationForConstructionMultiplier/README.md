###### (Automatically generated documentation)

# Change R-value of Insulation Layer for Construction By a Multiplier

## Description

Change R-value of Insulation Layer for Construction By a Multiplier

## Modeler Description

Change R-value of Insulation Layer for Construction By a Multiplier

## Measure Type

ModelMeasure

## Taxonomy

## Arguments

### Choose a Construction to Alter.

**Name:** construction,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Multiplier for R-value for Insulation Layer of Construction.

**Name:** r_value_multplier,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false
