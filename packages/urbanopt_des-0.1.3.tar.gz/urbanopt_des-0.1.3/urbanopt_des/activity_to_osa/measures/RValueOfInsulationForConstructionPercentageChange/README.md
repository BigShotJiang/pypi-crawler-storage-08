###### (Automatically generated documentation)

# Change R-value of Insulation Layer for Construction By a Specified Percentage

## Description

Change R-value of Insulation Layer for Construction By a Specified Percentage

## Modeler Description

Change R-value of Insulation Layer for Construction By a Specified Percentage

## Measure Type

ModelMeasure

## Taxonomy

## Arguments

### Choose a Construction to Alter.

**Name:** construction,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Percentage Change of R-value for Insulation Layer of Construction.

**Name:** r_value_prct_inc,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false
