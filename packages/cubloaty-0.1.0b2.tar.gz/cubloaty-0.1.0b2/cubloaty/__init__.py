"""cubloaty - Analyze CUDA binary sizes in .so files"""

__version__ = "0.1.0b2"
