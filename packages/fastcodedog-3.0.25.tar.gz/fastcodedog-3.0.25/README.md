Based on the pdm file(sap powerdesigner), automatically generate a FastAPI project.    
Including SQLAlchemy models and CRUD operations.   
FastAPI schemas and APIs.   
The database engine should be installed manually based on actual requirements.   
Version 3 and above temporarily reverts to multithreading and does not support coroutines.
