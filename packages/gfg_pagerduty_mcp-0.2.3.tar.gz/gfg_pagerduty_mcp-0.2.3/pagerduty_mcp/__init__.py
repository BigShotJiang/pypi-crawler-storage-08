DIST_NAME = "gfg-pagerduty-mcp"
