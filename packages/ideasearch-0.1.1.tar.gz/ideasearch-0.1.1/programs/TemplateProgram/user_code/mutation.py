__all__ = [
    "mutate",
]


def mutate(
    idea: str,
)-> str:
    
    mutated_idea = idea
    
    return mutated_idea
