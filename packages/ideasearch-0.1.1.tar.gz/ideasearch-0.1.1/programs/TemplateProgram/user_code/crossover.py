__all__ = [
    "crossover",
]


def crossover(
    parent1: str,
    parent2: str,
)-> str:
    
    crossover_idea = parent1
    
    return crossover_idea
