from .schema import NetBoxBGPQuery

schema = [NetBoxBGPQuery]
