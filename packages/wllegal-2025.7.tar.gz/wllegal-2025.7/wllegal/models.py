# Copyright © Michal Čihař <michal@weblate.org>
#
# SPDX-License-Identifier: GPL-3.0-or-later

from datetime import date

LEGAL_TOS_DATE = date(2024, 11, 1)
