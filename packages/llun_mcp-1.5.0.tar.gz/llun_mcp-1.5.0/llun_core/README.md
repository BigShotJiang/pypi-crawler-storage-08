# Llun Core

the core library defines the modules that will be used by each product., along with their dependencies. this architecture allows us to start having multiple products consume the core logic, and ensures all tooling stays up to date.