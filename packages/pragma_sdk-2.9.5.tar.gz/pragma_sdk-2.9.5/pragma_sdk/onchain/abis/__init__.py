from pragma_sdk.onchain.abis.abi import ABIS, CONTRACTS_NAMES

__all__ = ["ABIS", "CONTRACTS_NAMES"]
