.. include:: ../README.rst


API documentation
-----------------

.. toctree::
   :maxdepth: 2

   samplerate/index


Change Log
----------
.. toctree::
   :maxdepth: 2

   changelog


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


.. _libsamplerate: http://www.mega-nerd.com/libsamplerate/
