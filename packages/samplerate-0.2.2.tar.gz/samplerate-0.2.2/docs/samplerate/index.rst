`samplerate` module documentation
=================================

.. toctree::
   :maxdepth: 2

   samplerate
   converters
   exceptions
