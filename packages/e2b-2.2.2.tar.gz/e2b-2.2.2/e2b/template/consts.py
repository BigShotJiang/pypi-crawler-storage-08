FINALIZE_STEP_NAME = "finalize"
BASE_STEP_NAME = "base"

"""
Depths explained:
1. TemplateClass
2. Caller method (eg. copy(), fromImage(), etc.)
"""
STACK_TRACE_DEPTH = 2

RESOLVE_SYMLINKS = False
