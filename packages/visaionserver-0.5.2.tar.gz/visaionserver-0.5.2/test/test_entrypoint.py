from visaionserver.script import entrypoint

if __name__ == "__main__":
    # Example: entrypoint(debug='visaionserver help')
    entrypoint(debug="")