class JobCancelled(Exception):
    """Raised when a job is cancelled before or during execution."""
