export const adminPaths = {
    customerAdd: "/admin/testapp/customer/add/",
    logout: "/admin/logout/",
    root: "/admin",
};
