"""Add simple dynamic interaction to the otherwise static django admin."""

__version__ = "3.2.10"
