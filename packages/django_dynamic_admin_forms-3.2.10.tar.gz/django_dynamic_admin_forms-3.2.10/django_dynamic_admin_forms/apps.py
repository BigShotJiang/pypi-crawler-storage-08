from django.apps import AppConfig


class DynamicSelectConfig(AppConfig):
    name = "django_dynamic_admin_forms"
