from mipcandy.common.numpy.regressions import quotient_regression, quotient_derivative, quotient_bounds
