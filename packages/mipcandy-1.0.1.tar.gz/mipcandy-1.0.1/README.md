# MIP Candy: A Candy for Medical Image Processing

![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/ProjectNeura/MIPCandy)
![PyPI](https://img.shields.io/pypi/v/mipcandy)
![GitHub Release](https://img.shields.io/github/v/release/ProjectNeura/MIPCandy)
![GitHub Release Date - Published_At](https://img.shields.io/github/release-date/ProjectNeura/MIPCandy)

MIP Candy is Project Neura's next-generation infrastructure framework for medical image processing. It integrates a
handful number of common network architectures with their corresponding training, inference, and evaluation pipelines
that are out-of-the-box ready to use. Additionally, it also provides adapters to popular frontend dashboards such as
Notion, WandB, and TensorBoard.

:link: [Home](https://mipcandy.projectneura.org)

:link: [Docs](https://mipcandy-docs.projectneura.org)

## Installation

Note that MIP Candy requires **Python >= 3.12**.

```shell
pip install "mipcandy[standard]"
```