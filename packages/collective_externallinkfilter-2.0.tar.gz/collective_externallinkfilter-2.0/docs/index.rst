=============================
collective.externallinkfilter
=============================

User documentation
