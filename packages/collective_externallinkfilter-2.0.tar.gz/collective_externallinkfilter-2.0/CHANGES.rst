Changelog
=========


2.0 (2025-10-08)
----------------

- Drop python2 and Plone 5 support. Mark as Plone 6 only
  [erral]


1.1 (2025-10-08)
----------------

- Set image loading to be lazy
  [libargutxi]

- Set image width and height if the value is empty
  [libargutxi]



1.0 (2023-02-23)
----------------

- Initial release.
  [erral]
