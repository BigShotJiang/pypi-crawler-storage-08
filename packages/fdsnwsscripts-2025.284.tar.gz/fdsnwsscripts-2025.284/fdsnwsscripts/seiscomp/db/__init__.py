from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

class DBError(Exception):
    pass

