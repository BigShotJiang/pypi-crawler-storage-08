# Copyright (c) 2023-2024 Geosiris.
# SPDX-License-Identifier: Apache-2.0

# This is a namespace package
__path__ = __import__("pkgutil").extend_path(__path__, __name__)
