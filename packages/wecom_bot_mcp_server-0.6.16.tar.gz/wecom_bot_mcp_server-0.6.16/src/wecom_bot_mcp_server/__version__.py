"""Version information for WeCom Bot MCP Server.

This module contains the version number of the package.
"""

__version__ = "0.6.16"
