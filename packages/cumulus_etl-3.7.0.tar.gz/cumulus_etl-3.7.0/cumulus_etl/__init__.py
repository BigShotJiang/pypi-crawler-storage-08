"""Turns FHIR data into de-identified & aggregated records"""

__version__ = "3.7.0"
