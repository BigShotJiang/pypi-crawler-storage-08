"""upload-notes"""

from .cli import run_upload_notes
