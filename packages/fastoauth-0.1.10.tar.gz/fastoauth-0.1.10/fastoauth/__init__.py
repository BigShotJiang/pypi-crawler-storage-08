# -*- coding: utf-8 -*-
"""
@author: hubo
@project: fastframe
@file: __init__.py
@time: 2024/5/21 16:19
@desc:
"""
from fastoauth.oauth import OAuth2, AuthMiddleware, get_current_user
from fastoauth.schemas import Token
