# -*- coding: utf-8 -*-
"""
@author: hubo
@project: fastframe
@file: __init__.py
@time: 2024/5/23 16:55
@desc:
"""
