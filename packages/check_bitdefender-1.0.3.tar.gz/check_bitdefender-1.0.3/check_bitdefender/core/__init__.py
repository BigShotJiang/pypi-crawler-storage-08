"""Core functionality for check_bitdefender."""
