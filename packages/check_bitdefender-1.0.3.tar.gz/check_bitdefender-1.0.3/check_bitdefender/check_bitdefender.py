"""Main entry point for check_bitdefender Nagios plugin."""

from check_bitdefender.cli import main

if __name__ == "__main__":
    main()
