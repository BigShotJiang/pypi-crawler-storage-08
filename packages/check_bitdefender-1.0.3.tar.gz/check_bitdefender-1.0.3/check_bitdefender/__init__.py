"""Check BitDefender GravityZone API endpoints and check values - Nagios plugin."""
__version__ = "1.0.3"
__author__ = "ldvchosal"
__email__ = "ldvchosa@github.com"
