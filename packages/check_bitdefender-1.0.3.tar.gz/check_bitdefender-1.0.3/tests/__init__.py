"""Tests package for check_bitdefender."""
