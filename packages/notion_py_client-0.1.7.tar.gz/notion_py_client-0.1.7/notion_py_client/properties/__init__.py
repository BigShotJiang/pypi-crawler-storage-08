from .relation_property import RelationProperty
from .rollup_property import RollupProperty

__all__ = ["RelationProperty", "RollupProperty"]
