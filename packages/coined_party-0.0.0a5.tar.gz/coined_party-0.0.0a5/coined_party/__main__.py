from coined_party import main  # assuming your main game function is called `main`

if __name__ == "__main__":
    main()
