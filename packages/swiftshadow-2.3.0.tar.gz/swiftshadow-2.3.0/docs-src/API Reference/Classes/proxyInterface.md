# ProxyInterface Class
::: swiftshadow.classes.ProxyInterface
