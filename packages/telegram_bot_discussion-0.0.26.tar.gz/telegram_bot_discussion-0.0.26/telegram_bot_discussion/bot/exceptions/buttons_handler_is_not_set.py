class ButtonsHandlerIsNotSet(Exception):
    def __str__(self):
        return "Buttons-handler is not set"
