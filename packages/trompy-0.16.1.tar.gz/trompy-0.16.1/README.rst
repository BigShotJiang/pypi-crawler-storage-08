trompy
======

Collection of tools for plotting and data analysis from McCutcheon Lab in Tromsø
