# The authors of `pipefunc`

- [Bas Nijholt](http://nijho.lt) ([@basnijholt](https://github.com/basnijholt))
