## `pipefunc.cache` module

```{eval-rst}
.. automodule:: pipefunc.cache
    :members:
    :undoc-members:
    :show-inheritance:
```
