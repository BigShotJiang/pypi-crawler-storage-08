## `pipefunc.mcp` module

```{eval-rst}
.. automodule:: pipefunc.mcp
    :members:
    :undoc-members:
    :show-inheritance:
```
