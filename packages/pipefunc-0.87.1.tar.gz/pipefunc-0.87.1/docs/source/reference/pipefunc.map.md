## `pipefunc.map` module

```{eval-rst}
.. automodule:: pipefunc.map
    :members:
    :undoc-members:
    :show-inheritance:
```
