## `pipefunc.lazy` module

```{eval-rst}
.. automodule:: pipefunc.lazy
    :members:
    :undoc-members:
    :show-inheritance:
```
