# pypi `davidkhala.data.frame`

extras
- [Pandas](https://github.com/davidkhala/py-data/wiki/Pandas)
- [polars](https://github.com/davidkhala/data/blob/main/frame/polars.md)
