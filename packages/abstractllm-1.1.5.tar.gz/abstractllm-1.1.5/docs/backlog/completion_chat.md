# AbstractLLM
- only chat at the moment
- enable completion
- are tool calls notification catchable by other codes ?