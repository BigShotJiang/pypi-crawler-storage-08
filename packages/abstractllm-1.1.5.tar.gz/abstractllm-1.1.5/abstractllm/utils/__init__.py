"""
Utility modules for AbstractLLM.
""" 