"""
This file makes the tests directory a proper Python package.
""" 