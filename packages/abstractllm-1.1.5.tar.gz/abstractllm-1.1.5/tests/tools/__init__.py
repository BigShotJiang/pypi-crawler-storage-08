"""
Tool tests package for AbstractLLM.
""" 