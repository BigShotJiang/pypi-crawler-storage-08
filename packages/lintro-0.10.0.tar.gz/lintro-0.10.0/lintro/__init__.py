"""Lintro - A unified CLI core for code formatting, linting, and quality assurance."""

__version__ = "0.10.0"
