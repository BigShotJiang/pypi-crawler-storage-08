"""Enumeration types used throughout the Lintro codebase."""
