"""Error handling module for SAP OData Connector"""
