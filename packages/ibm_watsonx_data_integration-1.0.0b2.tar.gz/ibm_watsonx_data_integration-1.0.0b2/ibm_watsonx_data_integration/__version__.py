#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2025

"1.0.0b2"

__version__ = "1.0.0b2"
