from pydantic import BaseModel


class ExtendedProperties(BaseModel):
    pass
