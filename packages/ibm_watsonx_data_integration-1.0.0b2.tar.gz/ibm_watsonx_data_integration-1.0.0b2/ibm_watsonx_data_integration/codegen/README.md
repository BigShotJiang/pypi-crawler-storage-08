# Python Generator

The idea behind the Python Generator is to provide a built-in tool within the wx.DI SDK that can  take the JSON of an
existing pipeline and convert it into executable python commands that would recreate the exact same pipeline via python.
