"""
PEAPOD: Protein Embedding Aligner Plus Output Display
"""

__version__ = "0.1.6"
