.. _license:

License
=======

.. literalinclude:: ../../LICENSE
   :language: text
