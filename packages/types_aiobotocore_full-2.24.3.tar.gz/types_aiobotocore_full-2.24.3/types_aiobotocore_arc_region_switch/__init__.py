"""
Main interface for arc-region-switch service.

[Documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_arc_region_switch/)

Copyright 2025 Vlad Emelianov

Usage::

    ```python
    from aiobotocore.session import get_session
    from types_aiobotocore_arc_region_switch import (
        ARCRegionswitchClient,
        Client,
        GetPlanEvaluationStatusPaginator,
        GetPlanExecutionPaginator,
        ListPlanExecutionEventsPaginator,
        ListPlanExecutionsPaginator,
        ListPlansInRegionPaginator,
        ListPlansPaginator,
        ListRoute53HealthChecksPaginator,
        PlanEvaluationStatusPassedWaiter,
        PlanExecutionCompletedWaiter,
    )

    session = get_session()
    async with session.create_client("arc-region-switch") as client:
        client: ARCRegionswitchClient
        ...


    plan_evaluation_status_passed_waiter: PlanEvaluationStatusPassedWaiter = client.get_waiter("plan_evaluation_status_passed")
    plan_execution_completed_waiter: PlanExecutionCompletedWaiter = client.get_waiter("plan_execution_completed")

    get_plan_evaluation_status_paginator: GetPlanEvaluationStatusPaginator = client.get_paginator("get_plan_evaluation_status")
    get_plan_execution_paginator: GetPlanExecutionPaginator = client.get_paginator("get_plan_execution")
    list_plan_execution_events_paginator: ListPlanExecutionEventsPaginator = client.get_paginator("list_plan_execution_events")
    list_plan_executions_paginator: ListPlanExecutionsPaginator = client.get_paginator("list_plan_executions")
    list_plans_in_region_paginator: ListPlansInRegionPaginator = client.get_paginator("list_plans_in_region")
    list_plans_paginator: ListPlansPaginator = client.get_paginator("list_plans")
    list_route53_health_checks_paginator: ListRoute53HealthChecksPaginator = client.get_paginator("list_route53_health_checks")
    ```
"""

from .client import ARCRegionswitchClient
from .paginator import (
    GetPlanEvaluationStatusPaginator,
    GetPlanExecutionPaginator,
    ListPlanExecutionEventsPaginator,
    ListPlanExecutionsPaginator,
    ListPlansInRegionPaginator,
    ListPlansPaginator,
    ListRoute53HealthChecksPaginator,
)
from .waiter import PlanEvaluationStatusPassedWaiter, PlanExecutionCompletedWaiter

Client = ARCRegionswitchClient


__all__ = (
    "ARCRegionswitchClient",
    "Client",
    "GetPlanEvaluationStatusPaginator",
    "GetPlanExecutionPaginator",
    "ListPlanExecutionEventsPaginator",
    "ListPlanExecutionsPaginator",
    "ListPlansInRegionPaginator",
    "ListPlansPaginator",
    "ListRoute53HealthChecksPaginator",
    "PlanEvaluationStatusPassedWaiter",
    "PlanExecutionCompletedWaiter",
)
