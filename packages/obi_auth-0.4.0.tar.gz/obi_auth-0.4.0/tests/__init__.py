"""obi_auth tests."""
