/*********************************************************************
GH/27.09.00

include file for
 - current version of LEED program

Changes:
GH/27.09.00 - create
*********************************************************************/

#ifndef LEED_VER_H
#define LEED_VER_H

/* current version */

#define LEED_VERSION "1.1 (symmetrised version WB+GH/27.09.00)"
#define LEED_NAME "CLEED_SYM"

#endif /* LEED_VER_H */
