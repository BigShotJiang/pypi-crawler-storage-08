cleedpy-leed -i Ni111_2x2O.inp -b Ni111_2x2O.inp -o cleedpy.res
