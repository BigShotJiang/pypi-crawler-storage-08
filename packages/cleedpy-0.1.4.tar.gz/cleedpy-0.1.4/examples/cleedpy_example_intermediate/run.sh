cleedpy-leed -i leed.inp -o leed.res
