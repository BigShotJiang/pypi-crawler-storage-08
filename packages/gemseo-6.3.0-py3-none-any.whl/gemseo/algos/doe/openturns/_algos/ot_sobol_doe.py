# Copyright 2021 IRT Saint Exupéry, https://www.irt-saintexupery.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License version 3 as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
"""The DOE algorithm to compute the Sobol' indices."""

from __future__ import annotations

from typing import TYPE_CHECKING

from numpy import array
from openturns import SobolIndicesExperiment

from gemseo.algos.doe.openturns._algos.base_ot_doe import BaseOTDOE

if TYPE_CHECKING:
    from gemseo.algos.doe.openturns.settings.ot_sobol_indices import (
        OT_SOBOL_INDICES_Settings,
    )
    from gemseo.typing import RealArray


class OTSobolDOE(BaseOTDOE):
    """The DOE algorithm to compute the Sobol' indices.

    .. note:: This class is a singleton.
    """

    def generate_samples(  # noqa: D102
        self,
        n_samples: int,
        dimension: int,
        eval_second_order: bool = True,
        settings: OT_SOBOL_INDICES_Settings | None = None,
    ) -> RealArray:
        """
        Args:
            eval_second_order: Whether to build a DOE
                to evaluate also the second-order indices.
                If ``False``,
                the DOE is designed for first and total-order indices only.
                Ignored if ``settings`` is not `None`.

        """  # noqa: D205, D212
        # If eval_second_order is set to False, the input design is of size N(2+n_X).
        # If eval_second_order is set to False,
        #   if n_X = 2, the input design is of size N(2+n_X).
        #   if n_X != 2, the input design is of size N(2+2n_X).
        # Ref: https://openturns.github.io/openturns/latest/user_manual/_generated/
        # openturns.SobolIndicesExperiment.html#openturns.SobolIndicesExperiment
        if settings is not None:
            n_samples = settings.n_samples
            eval_second_order = settings.eval_second_order

        if eval_second_order and dimension > 2:
            sub_sample_size = int(n_samples / (2 * dimension + 2))
        else:
            sub_sample_size = int(n_samples / (dimension + 2))

        return array(
            SobolIndicesExperiment(
                self._get_uniform_distribution(dimension),
                sub_sample_size,
                eval_second_order,
            ).generate()
        )
