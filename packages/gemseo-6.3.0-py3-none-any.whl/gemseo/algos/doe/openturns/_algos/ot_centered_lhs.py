# Copyright 2021 IRT Saint Exupéry, https://www.irt-saintexupery.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License version 3 as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
"""The centered LHS algorithm."""

from __future__ import annotations

from typing import TYPE_CHECKING

from gemseo.algos.doe.openturns._algos.ot_standard_lhs import OTStandardLHS

if TYPE_CHECKING:
    from gemseo.algos.doe.base_n_samples_based_doe_settings import (
        BaseNSamplesBasedDOESettings,
    )
    from gemseo.typing import RealArray


class OTCenteredLHS(OTStandardLHS):
    """The centered LHS algorithm.

    .. note:: This class is a singleton.
    """

    def generate_samples(  # noqa: D102
        self,
        n_samples: int,
        dimension: int,
        settings: BaseNSamplesBasedDOESettings | None = None,
    ) -> RealArray:
        if settings is not None:
            n_samples = settings.n_samples
        samples = super().generate_samples(n_samples, dimension, settings)
        return (samples // (1.0 / n_samples) + 0.5) / n_samples
