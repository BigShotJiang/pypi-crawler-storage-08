"""Model-specific end-to-end tests for VCP CLI."""
