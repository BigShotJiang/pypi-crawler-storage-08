"""End-to-end tests for VCP CLI."""
