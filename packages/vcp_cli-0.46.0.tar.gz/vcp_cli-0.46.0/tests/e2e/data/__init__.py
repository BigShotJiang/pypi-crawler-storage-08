"""E2E tests for data commands."""
