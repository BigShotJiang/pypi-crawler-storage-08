.. _cli-reference:

Command Line Interface
======================

.. click:: vcp.cli:cli
   :prog: vcp
   :nested: full
