VCP CLI documentation
=====================

The VCP CLI is a command-line interface that provides commands for
working with the `Virtual Cell Platform <https://virtualcellmodels.cziscience.com/>`_.

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   install
   usage/index
   commands
