# Work in Progress Imaging Metadata Schema

```{include} ../../_schemas/imaging_metadata_schema.md
:start-line: 2
```

---

Sourced from https://github.com/chanzuckerberg/data-guidance/blob/main/standards/imaging/1.0.0/schema.md
