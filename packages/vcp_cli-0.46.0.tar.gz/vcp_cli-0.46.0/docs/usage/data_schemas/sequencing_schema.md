# Work in Progress Sequencing Schema

```{include} ../../_schemas/cz_seq_schema.md
:start-line: 2
```

---

Sourced from https://github.com/chanzuckerberg/data-guidance/blob/main/standards/sequencing/1.0/cz_seq_schema.md
