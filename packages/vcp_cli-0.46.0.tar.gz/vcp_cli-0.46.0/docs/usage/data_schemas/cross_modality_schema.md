# Cross Modality Schema

```{include} ../../_schemas/cross_modality_schema.md
:start-line: 2
```

---

Sourced from https://github.com/chanzuckerberg/data-guidance/blob/main/standards/cross-modality/1.1.0/schema.md
