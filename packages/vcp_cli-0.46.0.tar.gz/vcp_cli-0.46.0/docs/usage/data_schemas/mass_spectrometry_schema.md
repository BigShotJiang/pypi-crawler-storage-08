# Work in Progress Mass Spectrometry Schema

```{include} ../../_schemas/cz_ms_schema.md
:start-line: 2
```

---

Sourced from https://github.com/chanzuckerberg/data-guidance/blob/main/standards/mass-spectrometry/1.0.0/cz_ms_schema.md
