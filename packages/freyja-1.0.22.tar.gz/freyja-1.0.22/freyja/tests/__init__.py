"""Tests for freyja."""
