iBridges API Reference
======================

Welcome to the API reference for the iBridges library. The reference is split into two parts:
the user reference that will suffice for most users and a full reference that describes all public
classes and functions.

.. toctree::
    :maxdepth: 2

    user_reference
    full_reference
