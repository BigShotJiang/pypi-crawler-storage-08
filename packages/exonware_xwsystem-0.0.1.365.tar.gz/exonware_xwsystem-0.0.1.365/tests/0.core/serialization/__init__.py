"""
Core Serialization Tests

Tests all 24+ serialization formats with comprehensive roundtrip testing.
Focuses on the main public API and real-world usage scenarios.
"""
