# Pyarmor 8.4.7 (basic), 004363, 2025-10-09T08:21:18.467922
from .pyarmor_runtime import __pyarmor__
