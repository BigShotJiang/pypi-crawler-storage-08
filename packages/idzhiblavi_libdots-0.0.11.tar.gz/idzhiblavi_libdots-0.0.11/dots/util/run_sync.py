import asyncio


def run_sync(future):
    asyncio.run(future)
