# Sphinx SVG.IO Package

This is a simple extension for embedding draw.io diagramms into sphinx docs.

