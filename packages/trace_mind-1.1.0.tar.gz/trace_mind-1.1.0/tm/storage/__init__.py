"""Storage package initialization."""
