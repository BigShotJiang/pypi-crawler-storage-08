"""Pipeline package initialization."""
