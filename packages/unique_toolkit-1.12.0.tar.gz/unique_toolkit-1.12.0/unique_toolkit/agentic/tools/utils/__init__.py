"""Utilities for tools."""
