from .HM_Sec_SC_2 import HM_Sec_SC_2
from .HM_Sen_MDIR_WM55 import HM_Sen_MDIR_WM55

DEVICE_MAP = {
    "HM-Sec-SC-2": HM_Sec_SC_2,
    "HM-Sen-MDIR-WM55": HM_Sen_MDIR_WM55,
}
