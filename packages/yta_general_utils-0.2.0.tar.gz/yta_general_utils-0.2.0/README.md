# Youtube Autónomo General Utils

The generals we need to interact with the *Youtube Autónomo* project.

This project needs:
- Variable _WIP_FOLDER_ set, pointing to path in which we want temporary files. If this variable doesn't exist, default value will be 'yta_wip'.
- Variable _GIPHY_API_KEY_ set, to allow downloading gifs from Giphy platform.