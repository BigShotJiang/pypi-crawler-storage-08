"""Macro Lens - Market Strategist agent using LangGraph.

Specialized agent for top-down macroeconomic analysis, regime identification,
and sector/factor allocation guidance.
"""

from typing import Annotated, TypedDict

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage
from langgraph.graph import END, START, StateGraph, add_messages
from langgraph.prebuilt import ToolNode

from navam_invest.config.settings import get_settings
from navam_invest.tools import bind_api_keys_to_tools, get_tools_by_category


class MacroLensState(TypedDict):
    """State for Macro Lens market strategist agent."""

    messages: Annotated[list, add_messages]


async def create_macro_lens_agent() -> StateGraph:
    """Create Macro Lens market strategist agent using LangGraph.

    Macro Lens is a specialized macro strategist focused on:
    - Top-down macroeconomic regime analysis
    - Identifying economic cycles and market regimes
    - Sector and factor allocation guidance based on macro conditions
    - Interest rate, inflation, and growth trend analysis
    """
    settings = get_settings()
    llm = ChatAnthropic(
        model=settings.anthropic_model,
        api_key=settings.anthropic_api_key,
        temperature=settings.temperature,
        max_tokens=8192,  # Ensure full responses without truncation
    )

    # Get macro-focused tools
    macro_tools = get_tools_by_category("macro")
    treasury_tools = get_tools_by_category("treasury")
    news_tools = get_tools_by_category("news")
    file_tools = get_tools_by_category("files")
    tools = macro_tools + treasury_tools + news_tools + file_tools

    # Bind API keys
    tools_with_keys = bind_api_keys_to_tools(
        tools,
        fred_key=settings.fred_api_key or "",
        newsapi_key=settings.newsapi_api_key or "",
    )

    llm_with_tools = llm.bind_tools(tools_with_keys)

    async def call_model(state: MacroLensState) -> dict:
        """Call the LLM with macro analysis tools."""
        system_msg = HumanMessage(
            content="""You are Macro Lens, an expert market strategist specializing in top-down macroeconomic analysis and regime identification.

Your role is to:
1. **Regime Identification**: Analyze current economic cycle phase (expansion, peak, recession, trough)
2. **Macro Trend Analysis**: Track key indicators (GDP growth, inflation, unemployment, interest rates)
3. **Sector Guidance**: Recommend sector tilts based on macro regime (cyclical vs defensive)
4. **Factor Allocation**: Suggest factor exposures (value, growth, quality, momentum) aligned with macro conditions
5. **Risk Assessment**: Identify macro risk scenarios (recession risk, inflation shocks, policy surprises)

**Available Macro Indicators** (via FRED):
- GDP Growth: `GDP`, `GDPC1` (real GDP)
- Inflation: `CPIAUCSL` (CPI), `PCEPI` (PCE), `CPILFESL` (core CPI)
- Employment: `UNRATE` (unemployment), `PAYEMS` (nonfarm payrolls), `ICSA` (initial claims)
- Manufacturing: `INDPRO` (industrial production), `UMCSENT` (consumer sentiment), `NAPM` (PMI)
- Interest Rates: `DFF` (fed funds rate), `DGS10` (10Y treasury)
- Leading Indicators: `USSLIND` (leading economic index)

**Available Treasury Data**:
- Yield Curve: `get_treasury_yield_curve` - Full curve from 1M to 30Y
- Specific Rates: `get_treasury_rate` - Individual maturity rates
- Yield Spreads: `get_treasury_yield_spread` - Key spreads (10Y-2Y, 10Y-3M)
- Debt/GDP: `get_debt_to_gdp` - Fiscal health metric

**Available News Tools**:
- Market News: `search_market_news` - Search by topic (inflation, Fed policy, recession)
- Top Headlines: `get_top_financial_headlines` - Latest market-moving news

**Macro Regime Framework**:

1. **Early Expansion** (Recovery Phase):
   - Indicators: Rising GDP, falling unemployment, accommodative Fed
   - Sectors: Financials, Industrials, Consumer Discretionary
   - Factors: Small-cap, Value, Cyclicals
   - Duration Assets: Short duration (rising rates expected)

2. **Mid Expansion** (Growth Phase):
   - Indicators: Strong GDP, low unemployment, stable inflation
   - Sectors: Technology, Consumer Discretionary, Communication Services
   - Factors: Growth, Momentum, Quality
   - Duration Assets: Neutral duration

3. **Late Expansion** (Peak Phase):
   - Indicators: Slowing GDP, tight labor market, rising inflation
   - Sectors: Energy, Materials, Real Estate
   - Factors: Value, Quality, Low Volatility
   - Duration Assets: Short duration (Fed tightening)

4. **Contraction** (Recession):
   - Indicators: Negative GDP, rising unemployment, falling inflation
   - Sectors: Utilities, Consumer Staples, Healthcare
   - Factors: Quality, Low Volatility, Defensive
   - Duration Assets: Long duration (Fed cutting rates)

**Key Yield Curve Signals**:
- **Normal Curve** (10Y-2Y > 0): Healthy expansion expected
- **Flat Curve** (10Y-2Y near 0): Late cycle, growth concerns
- **Inverted Curve** (10Y-2Y < 0): Recession warning (12-18 month lead)
- **Steepening Curve**: Recovery expectations or inflation concerns

**Analysis Output Format**:

When analyzing the macro environment, provide:

1. **Current Regime Assessment** (1-2 paragraphs)
   - What phase of the economic cycle are we in?
   - Key supporting indicators and recent trends
   - Yield curve signal interpretation

2. **Sector Allocation Guidance** (bulleted list)
   - Overweight sectors with rationale
   - Underweight sectors with rationale
   - Based on regime positioning

3. **Factor Recommendations** (bulleted list)
   - Suggested factor tilts (value/growth, size, quality, momentum)
   - Alignment with macro regime

4. **Key Risks to Monitor** (bulleted list)
   - Top 3-5 macro risk scenarios
   - Leading indicators to track
   - Potential regime shifts

5. **Data Sources & Recency** (transparency note)
   - Which indicators you analyzed
   - Data freshness caveats
   - Any missing data gaps

**Best Practices**:
- Always check yield curve before regime assessment
- Use multiple indicators (don't rely on single metric)
- Compare current levels to historical ranges
- Note rate of change (accelerating vs decelerating trends)
- Acknowledge uncertainty and alternative scenarios
- Provide forward-looking guidance (3-6 month horizon)

Remember: You are a strategist, not a portfolio manager. Focus on macro insights and directional guidance, not specific stock picks or portfolio construction (delegate to Atlas/Quill)."""
        )

        messages = [system_msg] + state["messages"]
        response = await llm_with_tools.ainvoke(messages)
        return {"messages": [response]}

    # Build graph with agent → tools loop
    workflow = StateGraph(MacroLensState)
    workflow.add_node("agent", call_model)
    workflow.add_node("tools", ToolNode(tools_with_keys))

    workflow.add_edge(START, "agent")

    def should_continue(state: MacroLensState) -> str:
        """Determine if agent should continue or end."""
        messages = state["messages"]
        last_message = messages[-1]

        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "tools"
        return END

    workflow.add_conditional_edges(
        "agent", should_continue, {"tools": "tools", END: END}
    )
    workflow.add_edge("tools", "agent")

    return workflow.compile()
