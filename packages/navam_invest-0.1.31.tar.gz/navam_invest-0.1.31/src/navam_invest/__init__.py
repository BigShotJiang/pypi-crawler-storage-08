"""Navam Invest - AI agents and tools for the retail investor."""

__version__ = "0.1.0"
__author__ = "navam-io"
__email__ = "contact@navam.io"

__all__ = ["__version__", "__author__", "__email__"]
