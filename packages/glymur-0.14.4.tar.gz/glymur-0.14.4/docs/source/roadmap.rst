############
Known Issues
############

    * Creating a Jp2 file with the irreversible option does not work
      on windows.
    * Eval-ing a :py:meth:`repr` string does not work on windows.

#######
Roadmap
#######

    * Glymur version 0.9.0 drops support for Python 2.7 and OpenJPEG 1.5.
    * Glymur version 0.8.12 marks the transition of 0.8.x into an LTS series, i.e. bug fixes only.
    * Version 0.8.12 will drop support for Python 3.3, but keep support for Python 2.7.
