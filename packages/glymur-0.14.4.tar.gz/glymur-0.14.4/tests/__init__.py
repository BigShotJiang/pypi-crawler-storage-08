"""
Test suite for glymur high-level functionality.
"""
