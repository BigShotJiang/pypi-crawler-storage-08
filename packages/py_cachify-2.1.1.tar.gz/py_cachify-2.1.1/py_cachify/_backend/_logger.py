import logging


logger = logging.getLogger('py-cachify')
