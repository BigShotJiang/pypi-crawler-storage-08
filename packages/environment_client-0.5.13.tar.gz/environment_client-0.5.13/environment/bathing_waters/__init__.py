from .client import BathingWatersClient
from .models import BathingWater

__all__ = ["BathingWatersClient", "BathingWater"]
