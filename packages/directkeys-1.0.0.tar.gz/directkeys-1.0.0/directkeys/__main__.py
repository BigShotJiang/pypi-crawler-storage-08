# -*- coding: utf-8 -*-
import directkeys
import fileinput
import json
import sys

def print_event_json(event):
    print(event.to_json(ensure_ascii=sys.stdout.encoding != 'utf-8'))
    sys.stdout.flush()
directkeys.hook(print_event_json)

parse_event_json = lambda line: directkeys.KeyboardEvent(**json.loads(line))
directkeys.play(parse_event_json(line) for line in fileinput.input())