"""front module tests"""

# import os
# import pkg_resources
# import tekigo.front as tfront
# import tekigo.tools as tools
# import numpy as np
# import pytest
# import h5py
# from h5cross import hdfdict as h5d


def test_calibrate_metric():
    pass
    # tfront.calibrate_metric()


def test_adaptation_pyhip():
    # tfront.adaptation_pyhip
    pass
