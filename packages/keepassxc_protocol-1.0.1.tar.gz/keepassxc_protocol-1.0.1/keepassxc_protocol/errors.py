class ResponseUnsuccesfulException(Exception):
    pass