x <- 10
y <- 20
sum_result <- x + y
