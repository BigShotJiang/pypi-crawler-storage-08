class SIError(Exception):
    """Base class for exceptions in the smoothintegration package."""

    pass
