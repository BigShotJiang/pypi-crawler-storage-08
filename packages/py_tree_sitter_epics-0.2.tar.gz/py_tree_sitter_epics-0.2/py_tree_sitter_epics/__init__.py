"""Init function for the package."""
