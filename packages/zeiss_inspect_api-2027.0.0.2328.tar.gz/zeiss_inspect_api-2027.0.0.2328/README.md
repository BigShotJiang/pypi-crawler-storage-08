# ZEISS INSPECT API

This package provides an API to write and execute scripts in a running ZEISS INSPECT instance.
Please read the [ZEISS INSPECT API documentation](https://zeiss.github.io/IQS/) for details.

The [ZEISS INSPECT API wheel](https://pypi.org/project/zeiss-inspect-api/) is hosted on PyPI.