# -*- coding: utf-8 -*-
"""Test suite for giscemultitools."""
