// This template file is filled in upon start up of the application
// dara_core is a global included in UMD

window.onload = function () {
    $$extraJs$$;

    dara.core['default']($$importers$$);
};
