from ordeq_common.hooks.spy import SpyHook

__all__ = ("SpyHook",)
