"""ETCCDI Climate Extreme Indices dataset."""
