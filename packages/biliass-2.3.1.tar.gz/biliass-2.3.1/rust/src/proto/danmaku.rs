#![allow(clippy::all)]
include!(concat!(env!("OUT_DIR"), "/danmaku.rs"));
