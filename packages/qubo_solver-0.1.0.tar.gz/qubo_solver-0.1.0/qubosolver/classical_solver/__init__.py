# qubosolver/classical_solver/__init__.py

from __future__ import annotations

from .classical_solver import get_classical_solver

__all__ = [
    "get_classical_solver",
]
