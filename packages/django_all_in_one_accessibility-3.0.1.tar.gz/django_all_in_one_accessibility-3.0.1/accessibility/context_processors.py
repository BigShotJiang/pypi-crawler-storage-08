def admin_AIOA(request):
    aioa_BaseScript = ''

    aioa_BaseScript = 'https://www.skynettechnologies.com/accessibility/js/all-in-one-accessibility-js-widget-minify.js?colorcode='
    
    return {'AIOA_URL': aioa_BaseScript}

