# sim_sci_test_monorepo.core

Core functionality for the sim_sci_test_monorepo namespace package.

## Installation

```bash
pip install sim-sci-test-monorepo-core
```

## Usage

```python
from sim_sci_test_monorepo.core import ...
```