"""CLI root."""
