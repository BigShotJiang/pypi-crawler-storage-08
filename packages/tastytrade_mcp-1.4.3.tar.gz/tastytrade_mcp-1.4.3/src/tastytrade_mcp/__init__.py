"""TastyTrade MCP Server package."""

__version__ = "1.4.3"
__author__ = "TastyTrade MCP Team"
__license__ = "MIT"