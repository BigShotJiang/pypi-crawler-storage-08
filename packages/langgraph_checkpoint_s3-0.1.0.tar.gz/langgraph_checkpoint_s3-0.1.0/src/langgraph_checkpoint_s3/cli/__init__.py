"""CLI package for S3 checkpoint reader."""
