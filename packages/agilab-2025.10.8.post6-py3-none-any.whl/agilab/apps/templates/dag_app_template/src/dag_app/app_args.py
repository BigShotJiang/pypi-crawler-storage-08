"""Compatibility shim re-exporting :mod:`dag_app.dag_app_args`."""

from .dag_app_args import *  # noqa: F401,F403
