from .configuration import AbstractConfig

__version__ = "0.1.0"
