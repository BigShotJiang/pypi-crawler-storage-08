"""
MoreCompute: An interactive, real-time Python notebook
"""

__version__ = "0.1.0"

