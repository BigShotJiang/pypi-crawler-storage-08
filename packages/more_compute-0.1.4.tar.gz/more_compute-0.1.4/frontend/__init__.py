# This file makes the frontend directory a Python package so it can be included in the distribution
