data_info
===========

.. automodule:: graph_datasets.data_info
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: DEFAULT_DATA_DIR
