"""Graph Datasets
"""

__version__ = "1.1.0"

from .load_data import load_data
from .utils import *
