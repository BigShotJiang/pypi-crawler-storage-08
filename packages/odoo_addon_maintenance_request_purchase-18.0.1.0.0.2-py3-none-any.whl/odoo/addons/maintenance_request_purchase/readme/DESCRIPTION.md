This module allows to related a Maintenance Request with Purchase Orders
