Boring Math - Pythagorean Triples
=================================

PyPI project
`boring-math-pythagorean-triples
<https://pypi.org/project/boring-math-pythagorean-triples>`_.

Package containing a class to generate Pythagorean triples along
with a CLI executable.

This pypi project is part of the
`boring math
<https://grscheller.github.io/boring-math>`_ projects.

Documentation
-------------

Documentation for this project is hosted on
`GitHub Pages
<https://grscheller.github.io/boring-math/pythagorean-triples/development/build/html>`_.

Copyright and License
---------------------

Copyright (c) 2023-2025 Geoffrey R. Scheller. Licensed under the Apache
License, Version 2.0. See the LICENSE file for details.
