This document is a list of links to resources that can influence the development roadmap
for the cobwood python package.

# Solvers

- https://www.cvxpy.org/index.html


# Other models

## Other forest sector models

See paper.md

