# ta-sites
[![pip version](https://img.shields.io/pypi/v/ta-sites.svg)](https://pypi.python.org/pypi/ta-sites)

Thoughtful Automation sites package. This package contains the function required for Thoughtful Automation bots. Documentation may be closed and certain functions may not work outside the Thoughtful Automation environment.

Example Usage
-------------
