"""Allow scripts.agent_cli to be run as a module: python -m scripts.agent_cli"""
from scripts.agent_cli import main

if __name__ == "__main__":
    main()
