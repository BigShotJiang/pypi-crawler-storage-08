---
description: Query stac-geoparquet with DuckDB
---

# DuckDB

::: rustac.DuckdbClient
