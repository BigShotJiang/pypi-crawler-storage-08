# STAC

Typed dictionaries for STAC entities.

::: rustac.Catalog
::: rustac.Collection
::: rustac.Item
::: rustac.ItemCollection
