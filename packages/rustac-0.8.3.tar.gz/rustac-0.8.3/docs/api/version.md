---
description: Return this package's version or the version of an upstream
---

# Version

::: rustac.sha
::: rustac.version
