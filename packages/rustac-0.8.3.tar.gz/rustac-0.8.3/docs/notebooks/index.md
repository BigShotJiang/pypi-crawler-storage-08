# Notebooks

Examples of using **rustac** in [Jupyter](https://jupyter.org/) notebooks.
