"""
The `lms.procedure` package contains code for more complex operations (referred to as "procedures").
These procedures are often processes that require several different components,
and this package provides a place put them.
"""
