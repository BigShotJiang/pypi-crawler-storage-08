"""
Yandex Tracker API Client

Модульная архитектура для работы с различными сущностями Yandex Tracker API.
"""

from .base import YandexTrackerClient

__all__ = ['YandexTrackerClient']
