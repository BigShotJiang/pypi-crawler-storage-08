#This is a barebones setup.py file, because we use setup.cfg instead!
#setup.cfg is declarative, and therefore better for security reasons,
from setuptools import setup

if __name__ == "__main__":
    setup()