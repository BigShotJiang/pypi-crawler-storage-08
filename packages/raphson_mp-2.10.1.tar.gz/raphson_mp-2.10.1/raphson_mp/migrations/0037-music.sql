ALTER TABLE now_playing ADD COLUMN lastfm_update_timestamp INTEGER NOT NULL DEFAULT 0;
