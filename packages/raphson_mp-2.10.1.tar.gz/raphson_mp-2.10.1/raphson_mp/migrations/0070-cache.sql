DELETE FROM cache WHERE external = true;
