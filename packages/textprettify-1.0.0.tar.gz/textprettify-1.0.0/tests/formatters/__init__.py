"""Tests for formatter classes."""
