"""
Unit tests for TextPrettify library.
"""
