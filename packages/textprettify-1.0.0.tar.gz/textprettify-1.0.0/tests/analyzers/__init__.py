"""Tests for analyzer classes."""
