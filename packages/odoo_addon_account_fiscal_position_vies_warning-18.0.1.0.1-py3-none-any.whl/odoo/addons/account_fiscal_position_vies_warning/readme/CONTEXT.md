This module was developed to prevent errors when setting the some Fiscal 
Position (for ex. in Spain location it's Intra-community) 
if the partner’s VAT number is not registered in VIES