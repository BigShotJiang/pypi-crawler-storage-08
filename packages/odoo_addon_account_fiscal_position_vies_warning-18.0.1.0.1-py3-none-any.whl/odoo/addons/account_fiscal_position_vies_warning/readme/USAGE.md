Partner

1. Create or edit a partner.
2. Enter the VAT number.
3. Set the Fiscal Position that have Show Vies Warning active.
    - If the VAT is registered in VIES, the partner form can be saved.
    - Otherwise, Odoo will display a warning message.

Invoicing

1. Create a new invoice.
2. Select a partner who is not registered in VIES.
3. Set the Fiscal Position that have Show Vies Warning active and confirm the invoice.
    - If the VAT is registered in VIES, the invoice can be confirmed.
    - Otherwise, Odoo will display a warning message.