from .non_query_base import NonQueryBase as NonQueryBase
