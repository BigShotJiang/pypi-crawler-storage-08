"""RAG client configuration management using ContextVars for thread-safe provider switching."""
