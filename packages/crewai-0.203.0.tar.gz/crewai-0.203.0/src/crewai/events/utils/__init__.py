"""Event utilities for crewAI."""
