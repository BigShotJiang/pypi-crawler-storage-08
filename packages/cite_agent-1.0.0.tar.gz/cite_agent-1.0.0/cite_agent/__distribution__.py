"""
This is a DISTRIBUTION build.
Local LLM calling code has been removed.
All queries must go through the centralized backend.
"""
DISTRIBUTION_BUILD = True
BACKEND_ONLY = True
