---
<!-- 该部分为参数配置部分 -->

---
<!-- 公共内容部分  -->

用法请参考文档（[一键部署](https://github.com/alibaba-damo-academy/FunASR/blob/main/funasr/runtime/readme_cn.md)）

---
<!-- 在线使用独有内容部分 -->

---
<!-- 本地使用独有内容部分 -->
