This directory is no longer used by FreeDV. Please see the documentation.
