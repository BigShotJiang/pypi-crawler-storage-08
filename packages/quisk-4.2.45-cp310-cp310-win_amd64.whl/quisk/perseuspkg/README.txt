Microtelecom Perseus HF receiver

Prerequisite are:

libusb-1.0-0-dev (found in all major Linux distro)

libperseus-sdr as found in https://github.com/Microtelecom/libperseus-sdr/archive/master.zip



