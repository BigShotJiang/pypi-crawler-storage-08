from n2adr import conf3

settings_file_path = "../quisk_settings.json"

microphone_name = ""
