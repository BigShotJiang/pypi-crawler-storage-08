# SPDX-FileCopyrightText: 2024-present Atri Bhattacharya <atrib@duck.com>
#
# SPDX-License-Identifier: MIT
__appname__ = "tartex"
__version__ = "0.11.0"
