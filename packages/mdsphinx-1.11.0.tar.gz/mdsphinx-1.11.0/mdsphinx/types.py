from pathlib import Path
from typing import Optional

OptionalPath = Optional[Path]
MultipleStrings = Optional[list[str]]
