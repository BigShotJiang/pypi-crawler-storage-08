"""Integration tests for Fleet MCP.

Integration tests require a running Fleet server and test real functionality
end-to-end. These tests are slower but verify actual behavior against a
live Fleet instance.
"""

