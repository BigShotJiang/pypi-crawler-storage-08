"""Shared test fixtures for Fleet MCP tests."""

