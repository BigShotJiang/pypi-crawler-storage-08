# Asynchronous Client

::: bookwyrm.AsyncBookWyrmClient
options:
members:
\- __init__
\- stream_citations
\- stream_summarize
\- stream_process_text
\- classify
\- extract_pdf
\- stream_extract_pdf
\- close
\- __aenter__
\- __aexit__
show_root_heading: true
show_source: true
