# Synchronous Client

::: bookwyrm.BookWyrmClient
options:
members:
\- __init__
\- stream_citations
\- stream_summarize
\- stream_process_text
\- classify
\- extract_pdf
\- stream_extract_pdf
\- close
\- __enter__
\- __exit__
show_root_heading: true
show_source: true
