# RFL: authorizations package

Manage authorizations with RBAC policy.
