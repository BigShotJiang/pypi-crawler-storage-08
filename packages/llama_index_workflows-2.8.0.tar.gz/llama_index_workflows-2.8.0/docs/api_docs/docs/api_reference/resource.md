::: workflows.resource.Resource
