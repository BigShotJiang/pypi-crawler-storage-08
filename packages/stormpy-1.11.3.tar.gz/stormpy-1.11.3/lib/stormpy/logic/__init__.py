from . import _logic
from ._logic import *
