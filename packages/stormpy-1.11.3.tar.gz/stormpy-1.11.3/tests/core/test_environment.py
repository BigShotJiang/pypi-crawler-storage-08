import stormpy
from helpers.helper import get_example_path


class TestEnvironment:
    def test_environment(self):
        env = stormpy.Environment()
