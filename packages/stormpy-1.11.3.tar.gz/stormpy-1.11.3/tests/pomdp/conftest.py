from configurations import has_pomdp

if has_pomdp:
    import stormpy.pomdp
