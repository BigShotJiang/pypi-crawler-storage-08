**************
Contributors
**************

Stormpy is an extension to `Storm <https://www.stormchecker.org/>`_.
As a consequence, developers of Storm contributed significantly to the functionality offered by these Python bindings.

The bindings themselves have been developed by (lexicographically ordered):

* Sebastian Junges
* Matthias Volk

and received significant contributions by (lexicographically ordered):

* Tom Janson
* Hannah Mertens

We would like to thank Harold Bruintjes for the initial development of the pycarl bindings.

Furthermore, the following list of people helped us to develop stormpy (in chronological order):

* Nils Jansen (early adoption, feedback)
* Murat Cubuktepe (early adoption, feedback)

