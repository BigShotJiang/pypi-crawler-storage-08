#pragma once

#include "common.h"


template<typename ValueType>
void define_scheduler(py::module& m, std::string vt_suffix);
