#pragma once

#include "common.h"


void define_origins(py::module& m);