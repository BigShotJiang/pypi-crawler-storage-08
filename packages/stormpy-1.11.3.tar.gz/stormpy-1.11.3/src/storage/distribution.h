#pragma once

#include "common.h"

template<typename ValueType>
void define_distribution(py::module& m, std::string vt_suffix);