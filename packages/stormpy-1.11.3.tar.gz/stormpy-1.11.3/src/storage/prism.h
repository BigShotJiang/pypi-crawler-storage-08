#pragma  once

#include "common.h"

void define_prism(py::module& m);
