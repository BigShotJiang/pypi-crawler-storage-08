#ifndef PYTHON_STORAGE_EXPRESSIONS_H_
#define PYTHON_STORAGE_EXPRESSIONS_H_

#include "common.h"

void define_expressions(py::module& m);

#endif /* PYTHON_STORAGE_EXPRESSIONS_H_ */
