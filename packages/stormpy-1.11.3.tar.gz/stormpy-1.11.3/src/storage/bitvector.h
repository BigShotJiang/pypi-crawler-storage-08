#ifndef PYTHON_STORAGE_BITVECTOR_H_
#define PYTHON_STORAGE_BITVECTOR_H_

#include "common.h"

void define_bitvector(py::module& m);

#endif /* PYTHON_STORAGE_BITVECTOR_H_ */
