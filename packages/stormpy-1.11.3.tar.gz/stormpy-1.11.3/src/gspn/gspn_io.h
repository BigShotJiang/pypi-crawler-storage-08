#pragma once

#include "common.h"

void define_gspn_io(py::module& m);

