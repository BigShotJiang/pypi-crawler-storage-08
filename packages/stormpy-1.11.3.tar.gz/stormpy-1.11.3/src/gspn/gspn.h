#pragma once

#include "common.h"

void define_gspn(py::module& m);


