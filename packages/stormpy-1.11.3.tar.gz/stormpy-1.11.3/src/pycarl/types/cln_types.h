#pragma once

#include "pycarl/definitions.h"
#include <carl/numbers/numbers.h>


typedef cln::cl_RA Rational;
typedef cln::cl_I Integer;

