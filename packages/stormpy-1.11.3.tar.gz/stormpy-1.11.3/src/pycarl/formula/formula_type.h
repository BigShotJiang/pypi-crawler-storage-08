#pragma once

#include "src/pycarl/common.h"

void define_formula_type(py::module& m);