#pragma once

#include "src/pycarl/common.h"

void define_relation(py::module& m);
