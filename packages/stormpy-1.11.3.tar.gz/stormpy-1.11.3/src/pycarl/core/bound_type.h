#pragma once

#include "src/pycarl/common.h"

void define_boundtype(py::module& m);
