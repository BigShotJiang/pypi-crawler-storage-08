#ifndef PYTHON_PYCARL_CORE_FACTORIZEDPOLYNOMIAL_H_
#define PYTHON_PYCARL_CORE_FACTORIZEDPOLYNOMIAL_H_

#include "src/pycarl/common.h"

void define_factorizedpolynomial(py::module& m);

#endif /* PYTHON_PYCARL_CORE_FACTORIZEDPOLYNOMIAL_H_ */
