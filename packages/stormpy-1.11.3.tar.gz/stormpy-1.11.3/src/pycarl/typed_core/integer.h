#pragma once

#include "src/pycarl/common.h"

void define_cln_integer(py::module& m);
void define_gmp_integer(py::module& m);