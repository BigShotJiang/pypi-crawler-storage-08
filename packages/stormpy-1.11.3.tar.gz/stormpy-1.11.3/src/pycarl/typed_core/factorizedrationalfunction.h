/*
 * factorizedraitonalfunction.h
 *
 *  Created on: 16 Apr 2016
 *      Author: harold
 */

#ifndef PYTHON_PYCARL_CORE_FACTORIZEDRATIONALFUNCTION_H_
#define PYTHON_PYCARL_CORE_FACTORIZEDRATIONALFUNCTION_H_

#include "src/pycarl/common.h"

void define_factorizedrationalfunction(py::module& m);

#endif /* PYTHON_PYCARL_CORE_FACTORIZEDRATIONALFUNCTION_H_ */
