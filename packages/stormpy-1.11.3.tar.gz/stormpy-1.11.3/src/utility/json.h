#pragma once

#include "src/common.h"

template<typename RationalValueType>
void define_json(py::module& m, std::string const& vtSuffix);