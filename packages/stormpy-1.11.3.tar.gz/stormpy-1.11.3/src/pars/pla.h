#ifndef PYTHON_PARS_PLA_H_
#define PYTHON_PARS_PLA_H_

#include "common.h"

void define_pla(py::module& m);

#endif /* PYTHON_PARS_PLA_H_ */
