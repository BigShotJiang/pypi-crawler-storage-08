#ifndef PYTHON_CORE_ENVIRONMENT_H_
#define PYTHON_CORE_ENVIRONMENT_H_

#include "common.h"

void define_environment(py::module& m);

#endif /* PYTHON_CORE_ENVIRONMENT_H_ */
