#pragma once
#include "common.h"

void define_graph_constraints(py::module& m);
