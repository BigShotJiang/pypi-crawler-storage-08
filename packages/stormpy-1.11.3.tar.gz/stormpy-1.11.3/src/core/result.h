#ifndef PYTHON_CORE_RESULT_H_
#define PYTHON_CORE_RESULT_H_

#include "common.h"

void define_result(py::module& m);

#endif /* PYTHON_CORE_RESULT_H_ */
