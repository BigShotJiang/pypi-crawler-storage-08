#ifndef PYTHON_CORE_INPUT_H_
#define PYTHON_CORE_INPUT_H_

#include "common.h"

void define_property(py::module& m);
void define_input(py::module& m);


#endif /* PYTHON_CORE_INPUT_H_ */
