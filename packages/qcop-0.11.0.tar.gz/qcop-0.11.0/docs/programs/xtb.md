::: qcop.adapters.xtb.XTBAdapter

## Example

```python
{!examples/xtb.py!}
```
