## geomeTRIC

```python
{!examples/geometric.py!}
```

## TeraChem

```python
{!examples/terachem_opt.py!}
```
