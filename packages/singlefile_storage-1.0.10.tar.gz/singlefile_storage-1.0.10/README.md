# singlefile-storage

singlefile-storage --users admin:123456 --port 5001 --data-path /data/singlefile --api-key Jyfi3ndu87

ui:(admin/123456)
http://127.0.0.1:5001/

upload to a REST Form API
URL: http://124.221.149.22:5001/upload
authorization token: Jyfi3ndu87
archive data field name: singlehtmlfile
archive URL field name: url


