"""Miscellaneous utilities for schemist."""
