class NotEnoughSamplesForLabelError(Exception):
    pass
