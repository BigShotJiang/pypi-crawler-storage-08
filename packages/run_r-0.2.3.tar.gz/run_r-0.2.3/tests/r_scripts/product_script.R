a <- 5
b <- 3
product_result <- a * b
