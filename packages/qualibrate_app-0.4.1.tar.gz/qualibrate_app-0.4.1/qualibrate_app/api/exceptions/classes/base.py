class QualibrateException(Exception):
    pass
