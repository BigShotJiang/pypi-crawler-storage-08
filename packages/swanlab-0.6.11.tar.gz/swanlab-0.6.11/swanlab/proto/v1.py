"""
@author: cunyue
@file: v1.py
@time: 2025/6/20 15:16
@description: swanlab data transfer protocol version 1
"""
