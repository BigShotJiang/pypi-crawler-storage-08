from setuptools import setup, find_packages

setup(
    name="authflow",
    packages=find_packages(),
    include_package_data=True,
)
