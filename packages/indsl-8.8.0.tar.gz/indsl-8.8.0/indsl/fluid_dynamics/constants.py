acceleration_gravity = 9.81  # acceleration due to gravity [m/s2]
