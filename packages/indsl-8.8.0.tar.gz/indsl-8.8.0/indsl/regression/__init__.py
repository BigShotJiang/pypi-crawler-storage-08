# Copyright 2023 Cognite AS
from .polynomial import poly_regression


TOOLBOX_NAME = "Regression"

__all__ = ["poly_regression"]

__cognite__ = ["poly_regression"]
