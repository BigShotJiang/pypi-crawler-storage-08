"""Tests for bayan library."""
