class InvalidTargetFile(Exception):
    pass
