"""
Model management functionality
"""
from dataidea.sklearn.models import regression_report, classification_report

__all__ = ['regression_report', 'classification_report'] 