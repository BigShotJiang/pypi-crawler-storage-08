"""
Custom types.
"""

from .number import Number as Number
from .provider import FxProviderStr as FxProviderStr
