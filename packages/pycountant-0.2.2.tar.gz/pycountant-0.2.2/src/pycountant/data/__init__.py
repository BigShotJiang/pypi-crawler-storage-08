"""
Data module
"""

from .currency import ABBREVIATIONS as ABBREVIATIONS
from .currency import CURRENCY_SYMBOL_TO_CODE_MAP as CURRENCY_SYMBOL_TO_CODE_MAP
