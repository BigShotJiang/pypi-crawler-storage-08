"""Apple platform implementation (iCloud Mail)"""

from .client import AppleClient

__all__ = ['AppleClient']