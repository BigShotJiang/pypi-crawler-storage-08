"""Module for data shipped with the package."""

from __future__ import annotations

from .copy_test_data import copy_test_data  # noqa: F401
