"""Unit tests for MyProject."""

from __future__ import annotations

from logging import getLogger

# Disable flake8 logger as it can be rather verbose
getLogger("flake8").propagate = False
