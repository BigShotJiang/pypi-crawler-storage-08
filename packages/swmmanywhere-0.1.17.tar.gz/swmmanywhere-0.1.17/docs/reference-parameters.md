# Reference for SWMManywhere/parameters.py

::: swmmanywhere.parameters
