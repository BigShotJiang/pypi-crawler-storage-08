# Reference for SWMManywhere/filepaths.py

::: swmmanywhere.filepaths
