# Reference

Different API sections are documented separately.

- [SWMManywhere](reference.md)
- [Graph utilities](reference-graph-utilities.md)
- [Geospatial utilities](reference-geospatial-utilities.md)
- [Metric utilities](reference-metric-utilities.md)
- [Logging](reference-logging.md)
- [Parameters](reference-parameters.md)
- [Post processing](reference-post-processing.md)
- [Preprocessing](reference-preprocessing.md)
