# Reference for SWMManywhere/defs

## Demo configuration file

```yml
{%
    include-markdown "../src/swmmanywhere/defs/demo_config.yml"
    comments=false
%}
```

## Schema for configuration file

```yml
{%
    include-markdown "../src/swmmanywhere/defs/schema.yml"
    comments=false
%}
```
