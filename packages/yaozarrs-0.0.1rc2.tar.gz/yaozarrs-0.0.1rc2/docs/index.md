# Home

<span class="yaozarrs-animated">yaozarrs!!</span>

<center><em><strong>Yet Another Ome-ZARR Schema!</strong></em></center>

Pydantic models for the OME-Zarr specification.

!!!warning

    This is an experimental project.  Playing with a bottom-up design,
    starting with the OME-Zarr specification for JSON documents
    expressed as models.  

    **See first:** 

    [ome-zarr-models-py](https://github.com/ome-zarr-models/ome-zarr-models-py), 
    which is more of a top-down design, starting from a `zarr.Group`, and 
    validating the metadata within.  It has the community buy in and you should
    probably start there.
