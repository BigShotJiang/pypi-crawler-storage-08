from bluer_objects.README.consts import assets_url

eagle_assets2 = assets_url(
    suffix="eagle",
    volume=2,
)
