docs = [
    {
        "path": "../docs/arzhang/algo",
    },
    {
        "path": "../docs/arzhang/algo/target-detection",
    },
]
