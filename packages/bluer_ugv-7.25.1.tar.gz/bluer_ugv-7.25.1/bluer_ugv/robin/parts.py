dict_of_parts = {
    "4-ch-transceiver": "",
    "2xAA-battery-holder": "",
    "4xAA-battery-holder": "",
    "yellow-gearbox-dc-motor": "2 x 270 RPM + 1 x 80 RPM",
    "yellow-wheels": "x 2",
    "L-1x2": "x 4",
    "shaft-10cm": "",
    "M3": "",
    "front-connector": "",
    "front-wheels": "x 2",
}
