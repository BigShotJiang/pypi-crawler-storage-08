from .table1 import *
from .table2 import *