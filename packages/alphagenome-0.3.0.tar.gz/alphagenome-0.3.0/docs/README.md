AlphaGenome API is a service that provides comprehensive and accurate AI
predictions for genome interpretation.

AlphaGenome is a deep learning genomics model that takes a genomic (DNA)
sequence as input and predicts various molecular properties of DNA & RNA, many
at single base pair resolution.
