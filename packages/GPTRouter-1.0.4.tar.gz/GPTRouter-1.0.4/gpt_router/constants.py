DEFAULT_API_BASE_URL = 'https://gpt-router-preview.writesonic.com'
DEFAULT_REQUEST_TIMEOUT = 60