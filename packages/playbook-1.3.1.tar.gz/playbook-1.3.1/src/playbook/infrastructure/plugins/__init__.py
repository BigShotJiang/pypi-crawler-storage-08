# src/playbook/infrastructure/plugins/__init__.py
"""Built-in plugins for Playbook."""

from .python_plugin import PythonPlugin

__all__ = ["PythonPlugin"]
