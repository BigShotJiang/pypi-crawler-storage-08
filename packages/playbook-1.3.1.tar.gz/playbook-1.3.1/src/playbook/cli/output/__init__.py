# src/playbook/cli/output/__init__.py
"""CLI output handling."""
