# src/playbook/cli/__init__.py
"""CLI module for Playbook workflow engine."""

from .main import app

__all__ = ["app"]
