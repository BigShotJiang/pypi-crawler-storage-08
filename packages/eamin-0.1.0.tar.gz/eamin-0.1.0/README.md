# eamin

一个有趣的 Python 包！🎉

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.6+](https://img.shields.io/badge/python-3.6+-blue.svg)](https://www.python.org/downloads/)

## 🌟 功能特点

`eamin` 是一个神奇的 Python 包，它可以让你调用**任何属性**，并且会自动输出该属性的名称！

✨ **动态性** - 不需要预定义任何属性  
🎯 **通用性** - 对所有属性名都有效  
🌍 **国际化** - 支持任何 Unicode 字符  
🎮 **趣味性** - 展示 Python 元编程的强大

## 📦 安装

```bash
pip install eamin
```

## 🚀 快速开始

```python
import eamin

# 输出 "hello_world"
eamin.hello_world(print)

# 输出 "printout"  
eamin.printout(print)

# 对于任意属性都有相同的行为！
eamin.any_attribute_you_want(print)  # 输出 "any_attribute_you_want"
eamin.你好世界(print)                 # 输出 "你好世界"
```

## 💡 使用示例

### 基础用法

```python
import eamin

# 最简单的用法
eamin.test(print)  # 输出: test
```

### 自定义输出函数

```python
def shout(text):
    print(f"🔊 {text.upper()}!!!")

eamin.exciting(shout)  # 输出: 🔊 EXCITING!!!
```

### 获取属性名作为字符串

```python
# 获取属性名
name = eamin.variable_name(lambda x: x)
print(name)  # "variable_name"

# 转换为大写
upper = eamin.hello(lambda x: x.upper())  
print(upper)  # "HELLO"

# 获取长度
length = eamin.long_name(lambda x: len(x))
print(length)  # 9
```

### 批量操作

```python
# 动态生成配置键
config_keys = ['host', 'port', 'username', 'password']
config = {k: getattr(eamin, k)(str) for k in config_keys}
# {'host': 'host', 'port': 'port', 'username': 'username', 'password': 'password'}
```

### 支持多语言

```python
eamin.hello(print)      # hello
eamin.你好(print)       # 你好
eamin.مرحبا(print)      # مرحبا
eamin.Привет(print)     # Привет
```

## 🔧 工作原理

`eamin` 使用 Python 的 `__getattr__` 魔法方法和模块替换技术：

```python
import sys

class EaminModule:
    def __getattr__(self, name):
        def magic_func(func=print):
            return func(name)
        return magic_func

sys.modules[__name__] = EaminModule()
```

当你访问任何属性时：
1. `__getattr__` 拦截属性访问
2. 返回一个接受函数参数的闭包
3. 调用该函数并传入属性名

## 🎪 为什么有趣？

- 展示 Python 元编程的强大能力
- 学习 `__getattr__` 和模块系统
- 创造性地使用 Python 特性
- 简洁优雅的代码实现复杂功能

## 📚 更多示例

```python
import eamin

# 链式处理
results = []
for name in ['apple', 'banana', 'cherry']:
    result = getattr(eamin, name)(lambda x: x.upper())
    results.append(result)
print(results)  # ['APPLE', 'BANANA', 'CHERRY']

# 反转字符串
reversed_text = eamin.test(lambda x: x[::-1])
print(reversed_text)  # "tset"

# 自定义格式化
def fancy_print(text):
    print(f"✨ {text} ✨")

eamin.magic(fancy_print)  # ✨ magic ✨
```

## ⚠️ 注意事项

这个包主要用于：
- 学习 Python 元编程
- 娱乐和实验  
- 展示 Python 的灵活性

不建议用于生产环境的关键代码。

## 📖 许可证

MIT License - 自由使用！

## 🤝 贡献

欢迎提交 Issues 和 Pull Requests！

## 🔗 链接

- GitHub: https://github.com/yourusername/eamin
- PyPI: https://pypi.org/project/eamin/
- 问题反馈: https://github.com/yourusername/eamin/issues

---

用 Python 玩得开心！🐍✨
