- Add checks to avoid errors in the report, e.g. no VAT code, tax-code
  not matching fiscal position, etc..
- Calculate separated lines for product and service sales. Currently the
  values are in two columns per intra-community partner.
