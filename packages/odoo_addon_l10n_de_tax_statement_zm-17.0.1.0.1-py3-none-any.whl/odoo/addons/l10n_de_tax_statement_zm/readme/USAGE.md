To use this module, you need to:

1.  Create a VAT Statement.
2.  Post the VAT Statement: a new tab VAT Statement Extended will be
    displayed; the tab contains the lines of the German VAT Statement
    report extended by a separated statement for the Intra-Community
    transactions declaration (Zusammenfassende Meldung).
3.  In tab Zusammenfassende Meldung press the Update button in order to
    recompute the statement lines for this report.
4.  The values for product deliveries and services are separated in two
    columns.
5.  If you want to transmit the values to the official report form, f.e.
    by "www.elster.de" you would have to enter two lines if both columns
    product + services contains values.

Printing a PDF report:

1.  If you need to print the report in PDF, open a statement form and
    click: Print -\> Zusammenfassende Meldung
