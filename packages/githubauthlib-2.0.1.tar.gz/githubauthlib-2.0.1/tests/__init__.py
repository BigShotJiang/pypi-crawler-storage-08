# tests/__init__.py
"""
Test suite for githubauthlib.

This package contains all tests for the githubauthlib package.
"""
