import sys
from os import path
sys.path.append(path.dirname(__file__))
from src.Dont_touch import Dont_touch

GAME_SETUP = {
    "game": Dont_touch
}
