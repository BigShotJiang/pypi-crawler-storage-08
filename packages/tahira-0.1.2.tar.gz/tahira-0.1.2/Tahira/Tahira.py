import webbrowser


def debdoubi():
    print("The best nickname ever")

def ahmedsaid():
    print("Tahira is my fav person ever")

def time():
    print("9alt mau dar khaaayba")

def oursong():
    webbrowser.open("https://www.youtube.com/watch?v=P1gnCQhoEYQ&list=RDP1gnCQhoEYQ&start_radio=1")