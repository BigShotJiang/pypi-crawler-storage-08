from setuptools import setup, find_packages

setup(
    name='Tahira',
    version='0.1.2',
    packages=find_packages(),
    description='A simple library for YOU',
    author='Ahmed',
    license='Free-to-use (proprietary)',
)
