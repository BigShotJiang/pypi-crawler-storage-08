# Reading atomic structures
