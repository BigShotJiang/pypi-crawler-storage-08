# Reparameterizing pytrees
