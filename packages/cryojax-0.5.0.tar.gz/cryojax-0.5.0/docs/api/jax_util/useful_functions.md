# Useful JAX functions

`cryojax` provides a collection of useful functions not found in JAX that tend to be important for tasks in cryo-EM. Depending on developments with core JAX/Equinox and other factors, these functions could be removed in future releases of `cryojax`. Use with caution!

::: cryojax.jax_util.filter_bmap

::: cryojax.jax_util.filter_bscan
