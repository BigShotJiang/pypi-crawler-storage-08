# Converting between common conventions

Here, helper functions for converting between common conventions are described.

::: cryojax.constants.b_factor_to_variance

::: cryojax.constants.variance_to_b_factor
