# Rendering an image
