# Scattering approximations
