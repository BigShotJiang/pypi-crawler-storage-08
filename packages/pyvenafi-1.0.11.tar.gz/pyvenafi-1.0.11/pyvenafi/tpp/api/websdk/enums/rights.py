from __future__ import annotations

class SubSystemTypes:
    aperture = 'Aperture'
    client = 'Client'
    config = 'Config'
    rights = 'Rights'
    secret_store_config = 'SecretStoreconfig'
    websdk = 'WebSDK'
