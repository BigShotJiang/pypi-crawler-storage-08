class _Attributes:
    pass

Attributes = _Attributes()
