from pyvenafi.cloud.attributes._helper import IterableMeta

class Classes(metaclass=IterableMeta):
    pass
