"""MCP resources for procedure access"""
