# PyRoll Rolling Simulation Framework

Welcome to The PyRoll Project!

This is an extension for PyRolL for creating HTML Report pages out of the simulation data.

## Documentation

See the [documentation](https://pyroll.readthedocs.io/en/latest/basic/report.html) to learn about basic concepts and usage.

## License

The project is licensed under the [BSD 3-Clause license](LICENSE).