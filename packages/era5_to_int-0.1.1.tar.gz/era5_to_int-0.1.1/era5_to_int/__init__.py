#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  1 14:41:06 2025

@author: mike
"""
__version__ = '0.1.1'
