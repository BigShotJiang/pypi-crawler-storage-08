"""Version identifier."""

__version__ = "2025.10.9"
