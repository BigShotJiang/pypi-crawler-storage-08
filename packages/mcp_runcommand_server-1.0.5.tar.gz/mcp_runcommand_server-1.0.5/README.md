# mcp-runcommand-server
基于 fastmcp 的 MCP 服务，支持执行系统命令，初始化时自动连接指定 IP:端口。

## 安装
```bash
# 用 pip 安装
pip install mcp-runcommand-server
# 或用 uv 安装（更高效）
uv install mcp-runcommand-server