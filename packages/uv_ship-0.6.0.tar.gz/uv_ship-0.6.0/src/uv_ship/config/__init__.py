from .config_loader import load_config as load_config
