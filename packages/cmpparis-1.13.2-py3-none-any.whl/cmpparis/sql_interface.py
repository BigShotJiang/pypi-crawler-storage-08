class SqlInterface:
    """Interface minimale pour connecteurs SQL."""

    def connect(self):
        """Établit une connexion et la retourne."""
        pass