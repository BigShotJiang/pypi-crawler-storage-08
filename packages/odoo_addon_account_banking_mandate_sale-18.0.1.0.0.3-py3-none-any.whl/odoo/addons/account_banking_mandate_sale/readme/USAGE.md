When you select a payment mode that requires mandate on a sale order,
Odoo will select by default the first valid mandate of this customer.

The mandate will be copied from the sale order to the invoice.
