This modules adds the field *Direct Debit Mandate* on sale orders.
