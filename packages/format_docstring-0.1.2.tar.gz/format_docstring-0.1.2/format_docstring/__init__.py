"""A Python formatter to wrap/adjust docstring lines."""

import importlib.metadata

__version__ = importlib.metadata.version('format-docstring')
