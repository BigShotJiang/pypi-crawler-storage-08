def test_hello():
    print("Hello, World!")
