# ruff: noqa: E501
"""
Holistic implementation of "migration zero" pattern for Django covering local changes and in-production database adjustments.
"""

__version__ = "2.3.11"
