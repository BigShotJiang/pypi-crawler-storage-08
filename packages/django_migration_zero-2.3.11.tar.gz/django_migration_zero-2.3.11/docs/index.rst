django-migration-zero
===================

.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   features/01_introduction.md
   features/02_configuration.md
   features/03_workflow.md
   features/04_common_issues_and_solutions.md
   features/05_architecture.md
   features/06_management_commands.md
   features/07_changelog.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
