```{include} ../README.md
:relative-docs: docs/
:relative-images:
```
