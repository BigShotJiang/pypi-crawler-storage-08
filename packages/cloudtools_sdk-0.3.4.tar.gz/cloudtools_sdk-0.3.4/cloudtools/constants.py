"""Shared SDK constants."""
from __future__ import annotations

WORKFLOW_ID_PREFIX = "ct"

__all__ = ["WORKFLOW_ID_PREFIX"]
