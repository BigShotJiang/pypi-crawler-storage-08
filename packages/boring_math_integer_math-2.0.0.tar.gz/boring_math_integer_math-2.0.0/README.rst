Boring Math - Integer Math
==========================

DEPRICATED!!!
-------------

**Effort has been divided between the boring-math-combinatorics
and boring-math-number-theory PyPI projects.**

PyPI project
`boring-math-integer-math
<https://pypi.org/project/boring-math-integer-math>`_.

Python module implementing two integer oriented math libraries.

- number theory module: boring_math.integer_math.number_theory
- combinatorics module: boring_math.integer_math.combinatorics

This PyPI project is part of the
`Boring Math
<https://github.com/grscheller/boring-math/blob/main/README.md>`_ projects.

Documentation
-------------

Documentation for this project is hosted on
`GitHub Pages
<https://grscheller.github.io/boring-math/integer-math/development/build/html>`_.

Copyright and License
---------------------

Copyright (c) 2023-2025 Geoffrey R. Scheller. Licensed under the Apache
License, Version 2.0. See the LICENSE file for details.
