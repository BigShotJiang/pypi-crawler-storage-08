def main() -> None:
    print("CASTpFoldpy!")
