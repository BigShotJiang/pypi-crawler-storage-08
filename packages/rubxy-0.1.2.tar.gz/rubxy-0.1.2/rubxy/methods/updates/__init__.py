from .get_updates import getUpdates

class Updates(
    getUpdates,
):
    pass