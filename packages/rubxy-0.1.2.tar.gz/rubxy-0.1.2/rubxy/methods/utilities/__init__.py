from .add_handler import AddHandler

class Utilities(
    AddHandler
):
    pass