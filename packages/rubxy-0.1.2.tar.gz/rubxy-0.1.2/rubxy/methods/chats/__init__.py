from .get_chat import GetChat

class Chats(
    GetChat
):
    pass