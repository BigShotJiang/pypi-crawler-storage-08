Bitfield operations
^^^^^^^^^^^^^^^^^^^

.. autoclass:: coredis.commands.BitFieldOperation
   :no-inherited-members:
   :class-doc-from: both

