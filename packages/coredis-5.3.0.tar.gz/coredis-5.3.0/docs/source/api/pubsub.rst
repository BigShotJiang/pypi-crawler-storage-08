PubSub
------
.. autosummary::

   ~coredis.commands.PubSub
   ~coredis.commands.ClusterPubSub
   ~coredis.commands.ShardedPubSub
   ~coredis.commands.pubsub.SubscriptionCallback

.. autoclass:: coredis.commands.PubSub
   :class-doc-from: both

.. autoclass:: coredis.commands.ClusterPubSub
   :class-doc-from: both

.. autoclass:: coredis.commands.ShardedPubSub
   :class-doc-from: both

.. autodata:: coredis.commands.pubsub.SubscriptionCallback


