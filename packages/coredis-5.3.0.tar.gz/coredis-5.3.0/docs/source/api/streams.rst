Stream Consumers
----------------
:mod:`coredis.streams`

.. autoclass:: coredis.stream.Consumer
   :class-doc-from: both
   :show-inheritance:
   :special-members: __aiter__, __anext__

.. autoclass:: coredis.stream.GroupConsumer
   :class-doc-from: both
   :show-inheritance:
   :special-members: __aiter__, __anext__

.. autoclass:: coredis.stream.StreamParameters
   :show-inheritance:
   :no-inherited-members:

