Scripting
---------

LUA Scripts
^^^^^^^^^^^

.. autoclass:: coredis.commands.Script
   :no-inherited-members:
   :class-doc-from: both
   :special-members: __call__


Redis Functions
^^^^^^^^^^^^^^^
.. autoclass:: coredis.commands.Library
   :class-doc-from: both

.. autoclass:: coredis.commands.Function
   :class-doc-from: both
   :special-members: __call__

