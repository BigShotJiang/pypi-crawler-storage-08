## cdf 

### Improved

- Warning on YAML syntax errors when running cdf build for resources
types (alpha features) agents and infield configurations.

## templates

No changes.