"""Zen namespace package placeholder.

This lightweight module exists so repository scripts can import
`zen.telemetry` directly without requiring the full orchestrator package.
"""

__all__: list[str] = []
