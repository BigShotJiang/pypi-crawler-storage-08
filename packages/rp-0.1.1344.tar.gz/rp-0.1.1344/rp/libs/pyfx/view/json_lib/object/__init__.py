"""Node implementation for JSON `object` type."""
from .object_node import ObjectNode
