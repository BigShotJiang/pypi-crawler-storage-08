declare function bhattacharyya(a: number[], b: number[]): number;
declare const exports: {
    bhattacharyya: typeof bhattacharyya;
};
export default exports;
