import { Vec2 } from '../types';
export declare function largestTriangleThreeBuckets(data: Vec2[], numberOfPoints: number): Vec2[];
