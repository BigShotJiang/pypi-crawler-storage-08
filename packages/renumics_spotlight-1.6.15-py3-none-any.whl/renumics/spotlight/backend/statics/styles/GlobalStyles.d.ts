declare const GlobalStyles: () => JSX.Element;
export default GlobalStyles;
