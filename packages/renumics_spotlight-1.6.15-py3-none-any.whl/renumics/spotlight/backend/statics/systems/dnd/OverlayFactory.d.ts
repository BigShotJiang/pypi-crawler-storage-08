/// <reference types="react" />
import { DragData } from './types';
interface Props {
    data: DragData;
}
export default function OverlayFactory({ data }: Props): JSX.Element;
export {};
