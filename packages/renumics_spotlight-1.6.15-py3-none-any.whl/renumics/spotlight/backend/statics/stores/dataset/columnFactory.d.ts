import { Column } from '../../client';
import { DataColumn } from '../../types';
export declare function makeColumn(column: Column, index: number): DataColumn;
