import { Problem } from '../types';
export declare function parseError(error: any): Promise<Problem>;
