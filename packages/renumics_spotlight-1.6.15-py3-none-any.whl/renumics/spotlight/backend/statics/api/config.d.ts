import { Configuration } from '../client/runtime';
export declare const config: Configuration;
