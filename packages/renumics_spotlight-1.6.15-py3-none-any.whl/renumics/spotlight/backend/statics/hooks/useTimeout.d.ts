declare function useTimeout(callback: () => void, delay?: number): void;
export default useTimeout;
