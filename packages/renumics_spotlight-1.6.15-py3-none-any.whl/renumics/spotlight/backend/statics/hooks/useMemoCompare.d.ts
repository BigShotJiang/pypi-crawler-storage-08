declare function useMemoCompare<T>(value: T, isEqual?: (a: T, b: T) => boolean): T;
export default useMemoCompare;
