declare const useKeyPressed: (key: string) => boolean;
export default useKeyPressed;
