declare function useWhyDidYouUpdate<T>(name: string, props: Record<string, T>): void;
export default useWhyDidYouUpdate;
