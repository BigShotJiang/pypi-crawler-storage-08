import type { IconType } from 'react-icons';
declare const File: IconType;
export default File;
