import type { IconType } from 'react-icons';
declare const BoundingBox: IconType;
export default BoundingBox;
