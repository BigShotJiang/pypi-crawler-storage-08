import { FunctionComponent } from 'react';
declare const BanIcon: FunctionComponent;
export default BanIcon;
