import { FunctionComponent } from 'react';
declare const XIcon: FunctionComponent;
export default XIcon;
