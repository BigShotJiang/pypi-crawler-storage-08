import type { IconType } from 'react-icons';
declare const Mesh: IconType;
export default Mesh;
