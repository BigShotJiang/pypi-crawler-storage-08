import type { IconType } from 'react-icons';
declare const TriangleRight: IconType;
export default TriangleRight;
