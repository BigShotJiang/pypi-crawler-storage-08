import type { IconType } from 'react-icons';
declare const Histogram: IconType;
export default Histogram;
