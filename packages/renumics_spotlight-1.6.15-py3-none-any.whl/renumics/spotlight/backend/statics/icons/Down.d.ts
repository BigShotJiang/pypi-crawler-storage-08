import { FunctionComponent } from 'react';
declare const DownIcon: FunctionComponent;
export default DownIcon;
