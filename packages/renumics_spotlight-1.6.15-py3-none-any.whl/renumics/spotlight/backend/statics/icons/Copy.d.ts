import type { IconType } from 'react-icons';
declare const Docs: IconType;
export default Docs;
