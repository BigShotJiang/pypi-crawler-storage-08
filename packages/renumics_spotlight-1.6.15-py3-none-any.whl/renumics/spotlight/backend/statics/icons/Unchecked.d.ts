import type { IconType } from 'react-icons';
declare const UncheckedIcon: IconType;
export default UncheckedIcon;
