import type { IconType } from 'react-icons';
declare const Text: IconType;
export default Text;
