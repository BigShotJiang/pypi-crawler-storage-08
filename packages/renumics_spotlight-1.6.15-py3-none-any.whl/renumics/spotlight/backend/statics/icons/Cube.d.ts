declare const StyledCube: import("styled-components").StyledComponent<import("react-icons/lib").IconType, any, {}, never>;
export default StyledCube;
