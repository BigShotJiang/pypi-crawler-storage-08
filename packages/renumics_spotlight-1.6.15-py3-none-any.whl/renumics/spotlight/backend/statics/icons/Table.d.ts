import type { IconType } from 'react-icons';
declare const StyledTable: IconType;
export default StyledTable;
