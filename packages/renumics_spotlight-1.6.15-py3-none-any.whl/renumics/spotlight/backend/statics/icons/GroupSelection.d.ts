import { FunctionComponent } from 'react';
declare const FilterFromSelectionIcon: FunctionComponent;
export default FilterFromSelectionIcon;
