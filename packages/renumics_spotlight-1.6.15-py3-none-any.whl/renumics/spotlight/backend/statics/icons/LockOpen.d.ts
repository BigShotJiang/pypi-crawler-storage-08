import { FunctionComponent } from 'react';
declare const LockOpenIcon: FunctionComponent;
export default LockOpenIcon;
