import { FunctionComponent } from 'react';
declare const ResetIcon: FunctionComponent;
export default ResetIcon;
