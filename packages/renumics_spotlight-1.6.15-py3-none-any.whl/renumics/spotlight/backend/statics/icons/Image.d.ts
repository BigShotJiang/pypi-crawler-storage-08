import type { IconType } from 'react-icons';
declare const Image: IconType;
export default Image;
