import type { IconType } from 'react-icons';
declare const AddBox: IconType;
export default AddBox;
