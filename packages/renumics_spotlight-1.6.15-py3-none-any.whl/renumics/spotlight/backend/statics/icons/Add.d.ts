import type { IconType } from 'react-icons';
declare const Add: IconType;
export default Add;
