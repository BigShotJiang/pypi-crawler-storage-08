import { FunctionComponent } from 'react';
declare const HideIcon: FunctionComponent;
export default HideIcon;
