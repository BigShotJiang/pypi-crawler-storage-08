import type { IconType } from 'react-icons';
declare const Categorical: IconType;
export default Categorical;
