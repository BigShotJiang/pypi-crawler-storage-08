import type { IconType } from 'react-icons';
declare const Github: IconType;
export default Github;
