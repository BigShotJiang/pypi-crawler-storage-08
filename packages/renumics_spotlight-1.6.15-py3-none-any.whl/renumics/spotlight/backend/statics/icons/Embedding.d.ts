import type { IconType } from 'react-icons';
declare const Embedding: IconType;
export default Embedding;
