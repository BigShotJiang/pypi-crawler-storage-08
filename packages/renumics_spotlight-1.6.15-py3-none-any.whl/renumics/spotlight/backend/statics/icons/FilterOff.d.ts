import type { IconType } from 'react-icons';
declare const FilterOff: IconType;
export default FilterOff;
