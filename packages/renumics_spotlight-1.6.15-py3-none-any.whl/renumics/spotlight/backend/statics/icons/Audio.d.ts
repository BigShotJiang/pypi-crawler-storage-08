import type { IconType } from 'react-icons';
declare const Audio: IconType;
export default Audio;
