import type { IconType } from 'react-icons';
declare const Sequence: IconType;
export default Sequence;
