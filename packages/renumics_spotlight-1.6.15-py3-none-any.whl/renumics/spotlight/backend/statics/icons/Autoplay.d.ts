import type { IconType } from 'react-icons';
declare const Autoplay: IconType;
export default Autoplay;
