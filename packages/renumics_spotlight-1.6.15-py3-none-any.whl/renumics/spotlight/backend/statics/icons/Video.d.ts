import type { IconType } from 'react-icons';
declare const Movie: IconType;
export default Movie;
