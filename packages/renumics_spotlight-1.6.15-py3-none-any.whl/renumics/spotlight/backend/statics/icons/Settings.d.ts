import { FunctionComponent } from 'react';
declare const SettingsIcon: FunctionComponent;
export default SettingsIcon;
