import type { IconType } from 'react-icons';
declare const Folder: IconType;
export default Folder;
