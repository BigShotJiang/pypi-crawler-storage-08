import type { IconType } from 'react-icons';
declare const Minimize: IconType;
export default Minimize;
