import { FunctionComponent } from 'react';
declare const UpIcon: FunctionComponent;
export default UpIcon;
