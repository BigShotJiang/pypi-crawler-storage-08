import type { IconType } from 'react-icons';
declare const ResetLayout: IconType;
export default ResetLayout;
