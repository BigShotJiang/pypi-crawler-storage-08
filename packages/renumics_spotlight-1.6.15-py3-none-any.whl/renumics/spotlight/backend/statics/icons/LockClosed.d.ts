import { FunctionComponent } from 'react';
declare const LockClosedIcon: FunctionComponent;
export default LockClosedIcon;
