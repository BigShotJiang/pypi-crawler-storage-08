import type { IconType } from 'react-icons';
declare const Filter: IconType;
export default Filter;
