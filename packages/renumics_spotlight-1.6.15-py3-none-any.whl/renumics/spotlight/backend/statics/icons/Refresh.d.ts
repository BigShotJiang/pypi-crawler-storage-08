import { FunctionComponent } from 'react';
declare const RefreshIcon: FunctionComponent;
export default RefreshIcon;
