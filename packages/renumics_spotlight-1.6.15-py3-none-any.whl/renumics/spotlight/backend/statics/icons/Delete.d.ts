import type { IconType } from 'react-icons';
declare const StyledDelete: IconType;
export default StyledDelete;
