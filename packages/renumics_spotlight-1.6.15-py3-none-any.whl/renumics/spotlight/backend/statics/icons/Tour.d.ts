import type { IconType } from 'react-icons';
declare const Tour: IconType;
export default Tour;
