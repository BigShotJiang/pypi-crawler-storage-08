import type { IconType } from 'react-icons';
declare const Sequence1D: IconType;
export default Sequence1D;
