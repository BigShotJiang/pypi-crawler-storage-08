import { FunctionComponent } from 'react';
declare const Union: FunctionComponent;
export default Union;
