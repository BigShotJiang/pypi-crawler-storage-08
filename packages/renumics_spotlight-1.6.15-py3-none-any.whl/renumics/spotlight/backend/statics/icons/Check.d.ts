import { FunctionComponent } from 'react';
declare const CheckIcon: FunctionComponent;
export default CheckIcon;
