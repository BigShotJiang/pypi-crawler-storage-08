import type { IconType } from 'react-icons';
declare const StyledLocation: IconType;
export default StyledLocation;
