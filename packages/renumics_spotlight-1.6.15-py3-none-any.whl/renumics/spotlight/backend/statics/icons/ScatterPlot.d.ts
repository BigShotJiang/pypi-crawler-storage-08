import type { IconType } from 'react-icons';
declare const ScatterPlot: IconType;
export default ScatterPlot;
