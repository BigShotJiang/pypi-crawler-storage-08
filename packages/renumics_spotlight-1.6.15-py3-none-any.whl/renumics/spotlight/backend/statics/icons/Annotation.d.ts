import { FunctionComponent } from 'react';
declare const AnnotationIcon: FunctionComponent;
export default AnnotationIcon;
