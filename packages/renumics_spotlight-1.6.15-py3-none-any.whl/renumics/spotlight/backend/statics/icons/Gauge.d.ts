import type { IconType } from 'react-icons';
declare const Gauge: IconType;
export default Gauge;
