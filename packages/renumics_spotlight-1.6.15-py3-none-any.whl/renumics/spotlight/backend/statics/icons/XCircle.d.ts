import { FunctionComponent } from 'react';
declare const XCircleIcon: FunctionComponent;
export default XCircleIcon;
