import type { IconType } from 'react-icons';
declare const Bubbles: IconType;
export default Bubbles;
