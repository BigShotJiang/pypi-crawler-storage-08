import type { IconType } from 'react-icons';
declare const TriangleDown: IconType;
export default TriangleDown;
