import type { IconType } from 'react-icons';
declare const Edit: IconType;
export default Edit;
