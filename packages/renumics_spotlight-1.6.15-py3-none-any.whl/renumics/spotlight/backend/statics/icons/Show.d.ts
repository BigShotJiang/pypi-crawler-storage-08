import { FunctionComponent } from 'react';
declare const ShowIcon: FunctionComponent;
export default ShowIcon;
