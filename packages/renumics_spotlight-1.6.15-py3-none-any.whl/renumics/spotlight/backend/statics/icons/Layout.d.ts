import type { IconType } from 'react-icons';
declare const Layout: IconType;
export default Layout;
