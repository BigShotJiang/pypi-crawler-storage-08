import type { IconType } from 'react-icons';
declare const Help: IconType;
export default Help;
