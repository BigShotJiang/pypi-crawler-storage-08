import type { IconType } from 'react-icons';
declare const StyledLightbulb: IconType;
export default StyledLightbulb;
