import { FunctionComponent } from 'react';
declare const RightIcon: FunctionComponent;
export default RightIcon;
