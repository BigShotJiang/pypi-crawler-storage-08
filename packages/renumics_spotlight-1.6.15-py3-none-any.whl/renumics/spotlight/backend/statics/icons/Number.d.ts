import type { IconType } from 'react-icons';
declare const Number: IconType;
export default Number;
