import type { IconType } from 'react-icons';
declare const StyledResize: IconType;
export default StyledResize;
