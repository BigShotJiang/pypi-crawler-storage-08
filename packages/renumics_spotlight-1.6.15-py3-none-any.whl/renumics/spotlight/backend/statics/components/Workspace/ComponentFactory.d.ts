import { TabNode } from 'flexlayout-react';
declare const ComponentFactory: (node: TabNode) => JSX.Element;
export default ComponentFactory;
