declare const Styles: import("styled-components").StyledComponent<"div", any, {}, never>;
export default Styles;
