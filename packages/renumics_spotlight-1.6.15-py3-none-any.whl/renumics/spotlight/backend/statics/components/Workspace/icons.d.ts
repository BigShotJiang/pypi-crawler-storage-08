declare const icons: {
    maximize: JSX.Element;
    restore: JSX.Element;
};
export default icons;
