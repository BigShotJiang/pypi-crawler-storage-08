import FileBrowser from './FileBrowser';
export default FileBrowser;
