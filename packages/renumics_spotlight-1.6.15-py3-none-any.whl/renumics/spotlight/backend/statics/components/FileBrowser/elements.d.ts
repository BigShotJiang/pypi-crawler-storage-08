export declare const Container: import("twin.macro").TwComponent<"div">;
export declare const Header: import("twin.macro").TwComponent<"div">;
export declare const Content: import("twin.macro").TwComponent<"div">;
export declare const Footer: import("twin.macro").TwComponent<"div">;
