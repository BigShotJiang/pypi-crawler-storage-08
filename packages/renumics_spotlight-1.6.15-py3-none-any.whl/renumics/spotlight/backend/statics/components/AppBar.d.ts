/// <reference types="react" />
type AppBarItem = JSX.Element;
export declare const appBarItems: AppBarItem[];
declare const AppBar: () => JSX.Element;
export default AppBar;
