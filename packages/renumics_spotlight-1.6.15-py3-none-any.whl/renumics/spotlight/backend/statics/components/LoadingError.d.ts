import { Problem } from '../types';
interface Props {
    problem: Problem;
}
declare const LoadingError: ({ problem }: Props) => JSX.Element;
export default LoadingError;
