declare const StatusBar: () => JSX.Element;
export default StatusBar;
