declare const WebGLDetector: () => null;
export default WebGLDetector;
