import { DataType } from '../datatypes';
interface Props {
    type: DataType;
}
declare const DataTypeIcon: ({ type }: Props) => JSX.Element;
export default DataTypeIcon;
