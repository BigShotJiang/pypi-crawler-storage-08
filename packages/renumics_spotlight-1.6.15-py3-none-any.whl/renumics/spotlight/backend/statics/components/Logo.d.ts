import { FunctionComponent } from 'react';
declare const Logo: FunctionComponent;
export default Logo;
