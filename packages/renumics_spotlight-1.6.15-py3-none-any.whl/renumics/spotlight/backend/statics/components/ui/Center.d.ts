declare const Center: import("twin.macro").TwComponent<"div">;
export default Center;
