/// <reference types="react" />
declare const _default: {
    Button: import("react").ForwardRefExoticComponent<Pick<import("./Button").Props, string | number | symbol> & import("react").RefAttributes<HTMLButtonElement>>;
};
export default _default;
