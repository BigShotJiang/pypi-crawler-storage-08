interface Props {
    content: string;
}
declare const Markdown: ({ content }: Props) => JSX.Element;
export default Markdown;
