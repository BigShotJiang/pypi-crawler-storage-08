declare const Input: import("twin.macro").TwComponent<"input">;
export default Input;
