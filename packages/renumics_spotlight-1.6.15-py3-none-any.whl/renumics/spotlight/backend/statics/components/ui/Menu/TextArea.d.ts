declare const TextArea: import("twin.macro").TwComponent<"textarea">;
export default TextArea;
