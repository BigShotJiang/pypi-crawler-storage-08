interface Props {
    html: string;
}
declare const Html: ({ html }: Props) => JSX.Element;
export default Html;
