import * as React from 'react';
import Slider from './Slider';
declare const LabeledSlider: React.FunctionComponent<React.ComponentProps<typeof Slider> & {
    className?: string;
}>;
export default LabeledSlider;
