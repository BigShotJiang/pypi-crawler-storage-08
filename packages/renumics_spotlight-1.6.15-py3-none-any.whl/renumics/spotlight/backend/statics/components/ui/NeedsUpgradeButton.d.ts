/// <reference types="react" />
import { Props } from './Button';
declare const _default: import("react").ForwardRefExoticComponent<Pick<Omit<Props, "onClick">, string | number | symbol> & import("react").RefAttributes<HTMLButtonElement>>;
export default _default;
