declare const Title: import("twin.macro").TwComponent<"div">;
export default Title;
