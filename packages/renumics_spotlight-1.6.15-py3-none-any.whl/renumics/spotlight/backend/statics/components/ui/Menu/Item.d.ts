declare const Item: import("twin.macro").TwComponent<"div">;
export default Item;
