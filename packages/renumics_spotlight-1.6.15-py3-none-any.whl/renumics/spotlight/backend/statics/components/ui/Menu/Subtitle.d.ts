declare const Subtitle: import("twin.macro").TwComponent<"div">;
export default Subtitle;
