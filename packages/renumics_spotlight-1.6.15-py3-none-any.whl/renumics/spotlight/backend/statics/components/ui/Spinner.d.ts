interface Props {
    className?: string;
}
declare const Spinner: ({ className }: Props) => JSX.Element;
export default Spinner;
