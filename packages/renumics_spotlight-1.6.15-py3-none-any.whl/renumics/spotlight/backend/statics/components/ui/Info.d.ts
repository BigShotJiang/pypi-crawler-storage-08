declare const Info: import("twin.macro").TwComponent<"div">;
export default Info;
