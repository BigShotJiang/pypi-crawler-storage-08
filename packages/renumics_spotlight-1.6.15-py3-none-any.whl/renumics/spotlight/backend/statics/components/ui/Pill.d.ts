declare const Pill: import("twin.macro").TwComponent<"span">;
export default Pill;
