import { FunctionComponent } from 'react';
declare const HorizontalDivider: FunctionComponent;
export default HorizontalDivider;
