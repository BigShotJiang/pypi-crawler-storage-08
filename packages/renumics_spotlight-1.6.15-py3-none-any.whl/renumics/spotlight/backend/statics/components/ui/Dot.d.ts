declare const _default: import("styled-components").StyledComponent<"div", any, {
    style: {
        backgroundColor: string | undefined;
    };
}, "style">;
export default _default;
