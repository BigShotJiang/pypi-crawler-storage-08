declare const _default: import("twin.macro").TwComponent<"div">;
export default _default;
