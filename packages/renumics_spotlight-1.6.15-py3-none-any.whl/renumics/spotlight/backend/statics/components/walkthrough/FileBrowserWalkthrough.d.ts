import React from 'react';
export type Handle = {
    restartTour: () => void;
};
declare const _default: React.ForwardRefExoticComponent<React.RefAttributes<Handle>>;
export default _default;
