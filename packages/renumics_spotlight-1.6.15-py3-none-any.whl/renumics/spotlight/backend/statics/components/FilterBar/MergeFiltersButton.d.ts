import { FunctionComponent } from 'react';
declare const MergeFiltersButton: FunctionComponent;
export default MergeFiltersButton;
