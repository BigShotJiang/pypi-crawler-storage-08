import { FunctionComponent } from 'react';
declare const FilterSelectedButton: FunctionComponent;
export default FilterSelectedButton;
