import { FunctionComponent } from 'react';
import { Filter } from '../../types';
export interface Props {
    filter: Filter;
}
declare const FilterItem: FunctionComponent<Props>;
export default FilterItem;
