/// <reference types="react" />
declare const Button: import("react").ForwardRefExoticComponent<Pick<import("../ui/Button").Props, string | number | symbol> & import("react").RefAttributes<HTMLButtonElement>>;
export default Button;
