import { FunctionComponent } from 'react';
declare const FilterCreator: FunctionComponent;
export default FilterCreator;
