interface Props {
    delay?: number;
}
declare const LoadingIndicator: ({ delay }: Props) => JSX.Element;
export default LoadingIndicator;
