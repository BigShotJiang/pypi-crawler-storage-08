declare const ColumnListSeparator: import("twin.macro").TwComponent<"div">;
export default ColumnListSeparator;
