declare const ColumnList: import("twin.macro").TwComponent<"div">;
export default ColumnList;
