/// <reference types="react" />
import { DataColumn } from '../types';
interface Props {
    value?: any;
    className?: string;
    column: DataColumn;
    filtered?: boolean;
}
declare const _default: import("react").NamedExoticComponent<Props>;
export default _default;
