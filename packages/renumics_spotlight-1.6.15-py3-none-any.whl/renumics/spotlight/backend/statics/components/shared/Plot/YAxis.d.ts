import { FunctionComponent } from 'react';
interface Props {
    caption?: string;
}
declare const YAxis: FunctionComponent<Props>;
export default YAxis;
