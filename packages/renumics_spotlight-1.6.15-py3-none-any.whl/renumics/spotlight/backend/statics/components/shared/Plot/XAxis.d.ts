import { FunctionComponent } from 'react';
interface Props {
    caption?: string;
}
declare const XAxis: FunctionComponent<Props>;
export default XAxis;
