import * as THREE from 'three';
export declare const postprocessMesh: (mesh: THREE.Mesh) => void;
