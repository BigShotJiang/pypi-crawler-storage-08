import type { Widget } from '../types';
declare const ConfusionMatrix: Widget;
export default ConfusionMatrix;
