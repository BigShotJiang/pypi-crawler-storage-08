export declare const ALL_WIDGETS: import("./types").Widget[];
