import Inspector from './Inspector';
export default Inspector;
