import { Widget } from '../types';
declare const Inspector: Widget;
export default Inspector;
