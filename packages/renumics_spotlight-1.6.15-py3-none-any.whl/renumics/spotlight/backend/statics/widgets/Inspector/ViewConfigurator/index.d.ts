import ViewConfigurator from './ViewConfigurator';
export default ViewConfigurator;
