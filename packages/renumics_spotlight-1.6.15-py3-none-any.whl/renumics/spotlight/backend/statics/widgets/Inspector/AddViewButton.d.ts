declare const AddViewButton: () => JSX.Element;
export default AddViewButton;
