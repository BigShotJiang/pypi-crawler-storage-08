declare const ViewConfigurator: () => JSX.Element;
export default ViewConfigurator;
