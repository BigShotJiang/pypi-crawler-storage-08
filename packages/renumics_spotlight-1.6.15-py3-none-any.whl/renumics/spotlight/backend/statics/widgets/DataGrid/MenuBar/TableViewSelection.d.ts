import { FunctionComponent } from 'react';
declare const TableViewSelection: FunctionComponent;
export default TableViewSelection;
