declare function useCellValue(columnKey: string, rowIndex: number): any;
export default useCellValue;
