import { ReactNode } from 'react';
interface Props {
    children?: ReactNode;
}
declare const MouseControls: ({ children }: Props) => JSX.Element;
export default MouseControls;
