import { FunctionComponent } from 'react';
import { DataColumn } from '../../../types';
interface Props {
    column: DataColumn;
    value: any;
}
declare const DefaultCell: FunctionComponent<Props>;
export default DefaultCell;
