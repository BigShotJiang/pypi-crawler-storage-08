import { FunctionComponent } from 'react';
declare const AddColumnButton: FunctionComponent;
export default AddColumnButton;
