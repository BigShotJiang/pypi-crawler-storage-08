/// <reference types="react" />
interface Props {
    columnIndex: number;
    rowIndex: number;
}
declare const _default: import("react").NamedExoticComponent<Props>;
export default _default;
