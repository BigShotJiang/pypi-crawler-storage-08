declare function useRowCount(): number;
export default useRowCount;
