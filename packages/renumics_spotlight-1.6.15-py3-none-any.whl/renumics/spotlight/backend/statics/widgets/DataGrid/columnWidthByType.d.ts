import { DataType } from '../../datatypes';
declare const columnWidthByType: Record<DataType['kind'], number>;
export default columnWidthByType;
