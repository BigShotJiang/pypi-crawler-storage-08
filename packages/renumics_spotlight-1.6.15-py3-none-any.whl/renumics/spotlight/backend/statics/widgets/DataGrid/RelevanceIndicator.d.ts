import { FunctionComponent } from 'react';
import { DataColumn } from '../../types';
interface Props {
    column: DataColumn;
}
declare const RelevanceIndicator: FunctionComponent<Props>;
export default RelevanceIndicator;
