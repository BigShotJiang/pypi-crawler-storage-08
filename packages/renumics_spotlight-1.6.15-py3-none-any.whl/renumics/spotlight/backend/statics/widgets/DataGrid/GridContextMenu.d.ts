import { FunctionComponent, ReactNode } from 'react';
type Props = {
    className?: string;
    children?: ReactNode;
};
declare const GridContextMenu: FunctionComponent<Props>;
export default GridContextMenu;
