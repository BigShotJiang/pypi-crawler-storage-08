import { FunctionComponent } from 'react';
declare const MenuBar: FunctionComponent;
export default MenuBar;
