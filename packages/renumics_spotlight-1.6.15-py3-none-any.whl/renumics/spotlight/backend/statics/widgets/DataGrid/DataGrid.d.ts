import { Widget } from '../types';
declare const DataGrid: Widget;
export default DataGrid;
