import { FunctionComponent } from 'react';
export interface Props {
    columnIndex: number;
}
declare const CellContextMenu: FunctionComponent<Props>;
export default CellContextMenu;
