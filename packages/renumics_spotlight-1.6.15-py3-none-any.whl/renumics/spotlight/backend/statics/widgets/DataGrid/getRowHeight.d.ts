declare const getRowHeight: () => number;
export default getRowHeight;
