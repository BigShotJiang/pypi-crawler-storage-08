import { FunctionComponent } from 'react';
declare const SettingsButton: FunctionComponent;
export default SettingsButton;
