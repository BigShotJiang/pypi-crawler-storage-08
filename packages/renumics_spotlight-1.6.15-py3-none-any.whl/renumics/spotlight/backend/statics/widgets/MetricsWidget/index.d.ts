import { Widget } from '../types';
declare const MetricsWidget: Widget;
export default MetricsWidget;
