import { Metric } from './types';
export declare const METRICS: Record<string, Metric>;
