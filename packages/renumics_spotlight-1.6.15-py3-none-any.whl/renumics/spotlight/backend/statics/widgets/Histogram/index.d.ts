import Histogram from './Histogram';
export default Histogram;
