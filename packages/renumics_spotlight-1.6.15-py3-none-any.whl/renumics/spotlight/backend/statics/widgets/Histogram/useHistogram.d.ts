import { HistogramData } from './types';
declare function useHistogram(xColumnKey?: string, yColumnKey?: string): HistogramData;
export default useHistogram;
