import { Widget } from '../types';
declare const Histogram: Widget;
export default Histogram;
