import ScatterplotView from './ScatterplotView';
export default ScatterplotView;
