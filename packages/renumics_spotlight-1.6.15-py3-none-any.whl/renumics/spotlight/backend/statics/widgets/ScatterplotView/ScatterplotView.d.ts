import { Widget } from '../types';
declare const ScatterplotView: Widget;
export default ScatterplotView;
