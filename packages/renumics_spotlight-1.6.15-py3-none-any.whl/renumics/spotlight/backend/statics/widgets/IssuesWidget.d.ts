import { Widget } from './types';
declare const IssuesWidget: Widget;
export default IssuesWidget;
