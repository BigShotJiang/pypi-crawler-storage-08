import { Widget } from '../types';
declare const SimilarityMap: Widget;
export default SimilarityMap;
