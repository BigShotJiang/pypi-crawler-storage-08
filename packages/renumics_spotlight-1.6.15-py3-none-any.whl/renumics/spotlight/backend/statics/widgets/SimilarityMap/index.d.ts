import SimilarityMap from './SimilarityMap';
export default SimilarityMap;
