export declare const reductionMethods: readonly ["umap", "pca"];
export type ReductionMethod = (typeof reductionMethods)[number];
