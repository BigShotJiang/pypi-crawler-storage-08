import WorldCloudView from './WordCloudView';
export default WorldCloudView;
