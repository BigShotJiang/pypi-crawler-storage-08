import { Widget } from '../types';
declare const WordCloudView: Widget;
export default WordCloudView;
