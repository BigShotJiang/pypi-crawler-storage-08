import { Vec2 } from './types';
declare const getScrollbarSize: () => Vec2;
export default getScrollbarSize;
