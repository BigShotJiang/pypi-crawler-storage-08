export declare const ALL_LENSES: (import("../types").Lens | import("../types").Lens<string> | import("../types").Lens<number[] | import("../types").Vec2[]>)[];
