declare const None: () => JSX.Element;
export default None;
