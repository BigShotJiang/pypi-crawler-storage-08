import { Lens } from '../../types';
declare const BoundingBoxLens: Lens;
export default BoundingBoxLens;
