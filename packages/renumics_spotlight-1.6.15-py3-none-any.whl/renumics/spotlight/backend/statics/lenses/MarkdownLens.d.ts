import { Lens } from '../types';
declare const MarkdownLens: Lens;
export default MarkdownLens;
