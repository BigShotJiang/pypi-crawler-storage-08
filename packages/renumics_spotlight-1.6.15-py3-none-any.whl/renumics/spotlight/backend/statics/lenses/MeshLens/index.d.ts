import { Lens } from '../../types';
declare const MeshLens: Lens;
export default MeshLens;
