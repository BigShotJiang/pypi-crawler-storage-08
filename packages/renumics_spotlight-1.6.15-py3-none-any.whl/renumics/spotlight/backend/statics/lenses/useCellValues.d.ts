import { Problem } from '../types';
declare function useCellValues(rowIndex: number, columnKeys: string[], deferLoading?: boolean): [unknown[] | undefined, Problem | undefined];
export default useCellValues;
