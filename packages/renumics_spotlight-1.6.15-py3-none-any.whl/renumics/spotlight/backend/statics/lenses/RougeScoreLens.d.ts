import { Lens } from '../types';
declare const RougeScoreLens: Lens<string>;
export default RougeScoreLens;
