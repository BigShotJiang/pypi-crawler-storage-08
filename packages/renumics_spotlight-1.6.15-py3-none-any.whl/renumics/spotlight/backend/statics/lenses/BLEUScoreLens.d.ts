import { Lens } from '../types';
declare const BLEUScoreLens: Lens;
export default BLEUScoreLens;
