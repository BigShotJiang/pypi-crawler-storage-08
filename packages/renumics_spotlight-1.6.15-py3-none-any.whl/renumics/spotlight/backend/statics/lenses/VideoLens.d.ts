import { Lens } from '../types';
declare const VideoView: Lens;
export default VideoView;
