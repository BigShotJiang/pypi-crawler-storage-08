import { Lens } from '../types';
declare const SafeHtmlLens: Lens<string>;
export default SafeHtmlLens;
