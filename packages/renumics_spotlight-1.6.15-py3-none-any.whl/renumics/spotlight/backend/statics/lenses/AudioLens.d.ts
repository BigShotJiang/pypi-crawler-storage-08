import { Lens } from '../types';
declare const AudioLens: Lens;
export default AudioLens;
