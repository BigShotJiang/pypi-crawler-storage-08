import { Lens } from '../types';
declare const TextLens: Lens<string>;
export default TextLens;
