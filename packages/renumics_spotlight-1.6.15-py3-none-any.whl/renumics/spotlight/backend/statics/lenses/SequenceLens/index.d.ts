import type { Lens, Vec2 } from '../../types';
declare const SequenceView: Lens<Vec2[] | number[]>;
export default SequenceView;
