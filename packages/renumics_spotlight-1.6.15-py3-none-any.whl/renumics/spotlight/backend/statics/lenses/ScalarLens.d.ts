import { Lens } from '../types';
declare const ScalarView: Lens;
export default ScalarView;
