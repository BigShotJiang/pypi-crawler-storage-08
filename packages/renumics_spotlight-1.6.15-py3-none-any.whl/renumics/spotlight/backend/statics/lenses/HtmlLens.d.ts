import { Lens } from '../types';
declare const HtmlLens: Lens;
export default HtmlLens;
