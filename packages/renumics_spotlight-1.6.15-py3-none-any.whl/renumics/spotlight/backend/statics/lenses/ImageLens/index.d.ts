import { Lens } from '../../types';
declare const ImageLens: Lens;
export default ImageLens;
