import { Lens } from '../types';
declare const ArrayLens: Lens;
export default ArrayLens;
