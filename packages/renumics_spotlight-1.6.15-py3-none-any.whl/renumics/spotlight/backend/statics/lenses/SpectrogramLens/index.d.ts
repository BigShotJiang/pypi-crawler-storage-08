import { Lens } from '../../types';
declare const SpectrogramLens: Lens;
export default SpectrogramLens;
