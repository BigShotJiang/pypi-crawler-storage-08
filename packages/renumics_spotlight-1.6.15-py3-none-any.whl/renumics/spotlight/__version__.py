"""
Package version.

Replaced at build time.
"""

__version__ = "1.6.15"
