rm -rf test-reports/*

python -m pytest -c ./tests/pytest.ini ./