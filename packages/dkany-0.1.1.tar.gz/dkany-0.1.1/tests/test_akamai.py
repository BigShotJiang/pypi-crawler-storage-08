# import os
# from dkany.data_hosts.sftp import SftpClient

def test_akamai_sftp_client():
    pass
    # akamai_sftp_client = SftpClient(
    #     host = "cmsstorage.upload.akamai.com",
    #     username = "sshacs",
    #     private_key_file = os.environ['DKAN_AKAMAI_PRIVATE_KEY'],
    #     private_key_pass = os.environ['DKAN_AKAMAI_PRIVATE_KEY_PASSWORD'],
    #     default_remote_path='/399963/questions.medicaid.gov/production/wwwroot/data/scorecard/'
    # )

    # cwd = akamai_sftp_client.connection.getcwd()

    # print(cwd)

    # output = akamai_sftp_client.connection.listdir()

    # print(output)
    # raise(ValueError("hi"))
    