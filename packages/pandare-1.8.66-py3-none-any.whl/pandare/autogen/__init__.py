"""
Automatically generated python code. Contains panda_datatypes, which is the glue of this project.
"""