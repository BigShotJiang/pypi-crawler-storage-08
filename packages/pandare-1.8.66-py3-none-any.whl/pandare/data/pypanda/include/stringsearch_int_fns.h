
bool    add_string(const char* arg);
bool remove_string(const char* arg);
void reset_strings();

