
// Public interface
void add_target_string(char* target);
bool remove_target_string(char* target);
void add_target_num(target_ulong target);
bool remove_target_num(target_ulong target);
