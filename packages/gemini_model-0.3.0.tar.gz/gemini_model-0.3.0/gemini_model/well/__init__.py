"""Well hydraulics models.

Includes models for pressure and temperature changes along wells and
auxiliary correlations for single- and two-phase flow.
"""
