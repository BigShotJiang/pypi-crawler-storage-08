__version__ = "1.6.0"


def version():
    """Print the module's version number."""
    return __version__
