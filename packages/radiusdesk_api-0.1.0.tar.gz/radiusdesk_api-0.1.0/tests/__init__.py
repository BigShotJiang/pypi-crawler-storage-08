"""Tests for the RadiusDesk API client."""
