from .core import connect_arduino, start_camera, detect_fingers
from . import led
from . import otto
from . import wonders
from . import pose
from . import sign   # ✅ new project
