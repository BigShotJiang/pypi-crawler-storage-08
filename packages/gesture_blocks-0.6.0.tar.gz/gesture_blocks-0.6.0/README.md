# gesture-blocks
Block-style gesture control for Arduino + Python robots & AI demos.

## Install
```bash
pip install gesture-blocks
