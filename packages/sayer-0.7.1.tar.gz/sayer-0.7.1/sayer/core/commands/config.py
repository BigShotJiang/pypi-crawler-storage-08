from dataclasses import dataclass


@dataclass
class CustomCommandConfig:
    title: str
