## CNaaS YAML CLI

A CLI interface for doing auto-completion of YAML items in a CNaaS settings repository

## LICENSE: BSD-2-Clause
