"""
Contains the commands for the CLI.
"""

import fundamend.commands.xml2json
from fundamend.commands.app import app

__all__ = ["app"]
