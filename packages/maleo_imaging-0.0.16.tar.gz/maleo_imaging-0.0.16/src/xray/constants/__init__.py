from maleo.schemas.resource import Resource, ResourceIdentifier


RESOURCE = Resource(
    identifiers=[ResourceIdentifier(key="xray", name="X-Ray", slug="xray")],
    details=None,
)
