# SPDX-License-Identifier: MIT

"""
The resources sub-module for the Avro Dictionary.

Licensed under the terms of the MIT License.
"""

# Import local modules.
from .dictionary import *
