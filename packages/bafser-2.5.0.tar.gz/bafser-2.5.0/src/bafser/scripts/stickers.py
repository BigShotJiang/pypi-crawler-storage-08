from bafser_tgapi.tools.stickers import stickers  # type: ignore


def run(args: list[str]):
    stickers()
