from bafser import TablesBase


class Tables(TablesBase):
    Apple = "Apple"
