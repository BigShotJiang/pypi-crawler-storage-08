Celery-viestikanava
===================

Asynkroninen toteutus Celeryn käyttämiseksi viestinvälitykseen
