"""A module for dummy classes used for testing."""
