"""MCP Zephyr Scale Cloud server package."""

__version__ = "0.1.0"
__author__ = "Yevhen Burlaka"
__email__ = "yevhen.burlaka@example.com"
