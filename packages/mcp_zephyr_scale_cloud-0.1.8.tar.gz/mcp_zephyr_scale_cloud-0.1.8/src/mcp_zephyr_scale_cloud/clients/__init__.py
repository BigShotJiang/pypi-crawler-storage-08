"""HTTP clients for external APIs."""
