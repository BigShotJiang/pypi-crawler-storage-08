==================================================
filesystem
==================================================

Description
=================================
ファイル操作関係（Web APIにアクセスしない）のコマンドです。



Available Commands
=================================


.. toctree::
   :maxdepth: 1
   :titlesonly:

   draw_annotation
   filter_annotation
   mask_user_info
   merge_annotation

Usage Details
=================================

.. argparse::
   :ref: annofabcli.filesystem.subcommand_filesystem.add_parser
   :prog: annofabcli filesystem
   :nosubcommands:
