"""Ports (interfaces) for external dependencies."""

from .http_client import HttpClient

__all__ = ['HttpClient']
