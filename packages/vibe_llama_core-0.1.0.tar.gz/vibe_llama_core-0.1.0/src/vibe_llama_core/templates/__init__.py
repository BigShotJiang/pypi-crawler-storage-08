from .scaffold import ProjectName, PROJECTS, TEMPLATES, download_template

__all__ = ["ProjectName", "PROJECTS", "TEMPLATES", "download_template"]
