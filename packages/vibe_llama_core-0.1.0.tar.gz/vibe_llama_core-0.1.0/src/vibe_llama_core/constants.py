CHUNKS_SEPARATOR = "<!-- sep---sep -->"
BASE_URL = "https://raw.githubusercontent.com/run-llama/vibe-llama/main"
