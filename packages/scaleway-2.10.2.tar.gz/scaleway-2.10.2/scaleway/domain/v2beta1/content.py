# This file was automatically generated. DO NOT EDIT.
# If you have any remark or suggestion do not hesitate to open an issue.

from .types import (
    DNSZoneStatus,
    DomainFeatureStatus,
    DomainRegistrationStatusTransferStatus,
    DomainStatus,
    HostStatus,
    SSLCertificateStatus,
    TaskStatus,
)

DNS_ZONE_TRANSIENT_STATUSES: list[DNSZoneStatus] = [
    DNSZoneStatus.PENDING,
]
"""
Lists transient statutes of the enum :class:`DNSZoneStatus <DNSZoneStatus>`.
"""
DOMAIN_FEATURE_TRANSIENT_STATUSES: list[DomainFeatureStatus] = [
    DomainFeatureStatus.ENABLING,
    DomainFeatureStatus.DISABLING,
]
"""
Lists transient statutes of the enum :class:`DomainFeatureStatus <DomainFeatureStatus>`.
"""
DOMAIN_REGISTRATION_STATUS_TRANSFER_TRANSIENT_STATUSES: list[
    DomainRegistrationStatusTransferStatus
] = [
    DomainRegistrationStatusTransferStatus.PENDING,
    DomainRegistrationStatusTransferStatus.PROCESSING,
]
"""
Lists transient statutes of the enum :class:`DomainRegistrationStatusTransferStatus <DomainRegistrationStatusTransferStatus>`.
"""
DOMAIN_TRANSIENT_STATUSES: list[DomainStatus] = [
    DomainStatus.CREATING,
    DomainStatus.RENEWING,
    DomainStatus.XFERING,
    DomainStatus.EXPIRING,
    DomainStatus.UPDATING,
    DomainStatus.CHECKING,
    DomainStatus.DELETING,
]
"""
Lists transient statutes of the enum :class:`DomainStatus <DomainStatus>`.
"""
HOST_TRANSIENT_STATUSES: list[HostStatus] = [
    HostStatus.UPDATING,
    HostStatus.DELETING,
]
"""
Lists transient statutes of the enum :class:`HostStatus <HostStatus>`.
"""
SSL_CERTIFICATE_TRANSIENT_STATUSES: list[SSLCertificateStatus] = [
    SSLCertificateStatus.PENDING,
]
"""
Lists transient statutes of the enum :class:`SSLCertificateStatus <SSLCertificateStatus>`.
"""
TASK_TRANSIENT_STATUSES: list[TaskStatus] = [
    TaskStatus.PENDING,
]
"""
Lists transient statutes of the enum :class:`TaskStatus <TaskStatus>`.
"""
