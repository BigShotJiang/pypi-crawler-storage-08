from random import randint


def random_port() -> int:
    return randint(30000, 35000)
