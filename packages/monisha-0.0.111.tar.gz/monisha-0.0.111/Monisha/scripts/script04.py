#============================================================================

class Apis(object):

    DATA02 = "https://api.ipify.org?format=json"
    DATA01 = "https://www.x-rates.com/calculator/?from={}&to={}&amount=1"

#============================================================================

class Links(object):

    DATA01 = "https://www.x-rates.com/calculator/?from={}&to={}&amount=1"

#============================================================================
