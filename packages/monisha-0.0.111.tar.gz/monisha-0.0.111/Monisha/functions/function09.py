class Storage(object):

    DATA01 = {}
    DATA02 = []
    QUEUES = []

    USER_BID = {}
    USER_TID = []
    USER_CID = []
    USER_UID = []
