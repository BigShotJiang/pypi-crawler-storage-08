
class Okeys(object): #USRKEYS

    DATA01 = str("1477582805")
    DATA02 = str("1590281357")
    DATA03 = str("1294618460")
    DATA04 = str("1534220004")
    DATA05 = str("603092102")

class Ukeys(object):

    DATA01 = int("1477582805")
    DATA02 = int("1590281357")
    DATA03 = int("1294618460")
    DATA04 = int("1534220004")
    DATA05 = int("603092102")

class Bkeys(object): #BOTKEYS

    DATA01 = str("5207123401")
    DATA02 = str("5248850931")
    DATA03 = str("5120463922")
    DATA04 = str("5010468668")
    DATA05 = str("5485493815")
    DATA06 = str("2083789928")

class Mkeys(object):

    DATA01 = int("5207123401")
    DATA02 = int("5248850931")
    DATA03 = int("5120463922")
    DATA04 = int("5010468668")
    DATA05 = int("5485493815")
    DATA06 = int("2083789928")

#================================================================================

class Uname(object):

    DATA04 = "ＤＣ４ ＷＡＲＲＩＯＲ"
    DATA05 = "ＤＣ５ ＷＡＲＲＩＯＲ"

#================================================================================

class Skeys(object):

    DATA01 = "0123456789"
    DATA02 = "abcdefghijklmnopqrstuvwxyz"
    DATA03 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    DATA04 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"

#================================================================================
