"""Allow running CLI as a module: python -m fastapi_pulse.cli"""

from . import main

if __name__ == "__main__":
    main()
