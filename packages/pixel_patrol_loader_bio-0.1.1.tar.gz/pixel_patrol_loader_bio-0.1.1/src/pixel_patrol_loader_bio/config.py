# TODO: Isnt this a problem - same config file for both loaders?
STANDARD_DIM_ORDER = "TCZYXS"