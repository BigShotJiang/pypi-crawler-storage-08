"""Text Formater - A CLI tool for polishing text with Chinese typography rules."""

__version__ = "0.2.2"
