from multidict import CIMultiDict


class Headers(CIMultiDict):
    pass

class QueryParams(CIMultiDict):
    pass
