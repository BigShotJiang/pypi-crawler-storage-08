# Installation

## Via pip

Install the package from PyPI:

```bash
pip install wpt-tools
```

## Development

```bash
git clone https://github.com/t-sasatani/wpt-tools.git
cd wpt-tools
uv sync
```

**Requirements**: Python 3.11+
