Para utilizar este módulo, necesita la biblioteca
[pycryptodome](https://pypi.python.org/pypi/pycryptodome) instalada en
su sistema:

    pip3 install pycryptodome
