Este módulo añade la opción de pago a través de la pasarela de Redsys,
pudiendo seleccionar entre los métodos de pago: pago con tarjeta, pago
por transferencia, domiciliación y Bizum.
