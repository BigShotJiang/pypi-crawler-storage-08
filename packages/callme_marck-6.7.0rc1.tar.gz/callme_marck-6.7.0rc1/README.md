# callme

Using it to test something.

## Usage
```python
from callme import callme
print(callme())