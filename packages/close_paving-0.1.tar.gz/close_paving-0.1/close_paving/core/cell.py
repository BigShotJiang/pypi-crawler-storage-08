
from abc import ABCMeta


class Cell(metaclass=ABCMeta):
    def __init__(self, *args, **kwargs):
        pass
