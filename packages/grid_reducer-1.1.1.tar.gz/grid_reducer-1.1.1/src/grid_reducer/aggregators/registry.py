from grid_reducer.create_registry import make_registry

AGGREGATION_FUNC_REGISTRY, register_aggregator = make_registry()
