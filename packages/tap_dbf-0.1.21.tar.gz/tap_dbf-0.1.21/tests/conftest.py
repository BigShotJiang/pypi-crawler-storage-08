"""Pytest configuration for the tap-dbf tests.

Copyright 2024 Edgar Ramírez-Mondragón.
"""

from __future__ import annotations
