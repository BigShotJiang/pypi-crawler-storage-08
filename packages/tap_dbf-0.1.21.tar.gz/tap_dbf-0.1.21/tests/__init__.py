"""Tests for tap-dbf.

Copyright 2024 Edgar Ramírez-Mondragón.
"""
