"""Singer tap for .DBF files.

Copyright 2024 Edgar Ramírez-Mondragón.
"""
