"""zytome"""

__version__ = "0.0.42"
__author__ = "Marko Zolo Gozano Untalan"
