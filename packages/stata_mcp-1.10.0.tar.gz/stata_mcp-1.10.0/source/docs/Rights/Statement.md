# Statement

Multi-language: [中文](#中文版本)、[English](#english-version)、[Française](#version-française)

## 中文版本

### 版本说明
各个语言版本可能存在冲突，一切以中文版本为准。

### 项目说明
Stata-MCP 是一个旨在帮助用户通过大语言模型(LLM)完成Stata回归分析的开源工具。本项目采用Apache License 2.0，仅用于研究和教育目的。

### 免责声明
1. **使用风险**：使用本软件的风险由用户自行承担。开发者不对因使用本软件而可能导致的任何直接或间接损失负责，包括但不限于数据丢失、系统故障或其他形式的损害。

2. **Stata许可**：本工具仅作为Stata的辅助工具，用户必须拥有合法有效的Stata许可证才能使用本软件。本项目与Stata官方无关，不提供任何Stata软件授权。

3. **API密钥**：使用本软件可能需要第三方LLM服务的API密钥，用户应当遵守相关服务提供商的使用条款和隐私政策。开发者不对用户使用第三方服务可能产生的费用或问题负责。

4. **数据安全**：本软件可能会处理用户提供的数据。用户应当确保拥有处理这些数据的合法权利，并了解将数据传输给第三方LLM服务可能带来的风险。开发者不对数据的安全性或隐私泄露负责。

5. **功能限制**：本软件目前仅支持macOS系统，其他操作系统的支持正在开发中。软件可能存在未知的错误或限制，开发者不保证软件的完整性、可靠性或适用性。

### 版权和许可
1. 本项目采用Apache License 2.0，允许用户在遵守许可条款的前提下自由使用、修改和分发。

2. 本项目中使用的第三方库和组件受其各自许可证的约束，用户在使用时应当遵守这些许可要求。

3. Stata是StataCorp LLC的注册商标，本项目与StataCorp没有任何从属或赞助关系。

### 贡献和修改
1. 欢迎用户通过GitHub提交问题报告、功能请求或合并请求来参与项目开发。

2. 所有贡献者必须遵守项目的行为准则和贡献指南。

3. 开发者保留接受或拒绝任何贡献的权利。

### 更新和维护
1. 开发者不承诺为本软件提供任何形式的技术支持、维护或更新。

2. 软件的更新将基于开发者的自愿和时间安排，不保证任何特定功能或问题的修复时间表。

## English Version

### Version Note
There may be conflicts between different language versions. The Chinese version shall prevail.

### Project Description
Stata-MCP is an open-source tool designed to help users complete Stata regression analysis through Large Language Models (LLMs). This project is licensed under the Apache License 2.0 and is intended for research and educational purposes only.

### Disclaimer
1. **Usage Risk**: Use of this software is at your own risk. The developer is not responsible for any direct or indirect losses that may result from using this software, including but not limited to data loss, system failures, or other forms of damage.

2. **Stata License**: This tool is only intended as an auxiliary tool for Stata. Users must have a valid and legal Stata license to use this software. This project is not affiliated with Stata and does not provide any Stata software licensing.

3. **API Keys**: Using this software may require API keys from third-party LLM services. Users should comply with the terms of use and privacy policies of these service providers. The developer is not responsible for any fees or issues that may arise from using third-party services.

4. **Data Security**: This software may process data provided by users. Users should ensure they have legal rights to process such data and understand the risks of transmitting data to third-party LLM services. The developer is not responsible for data security or privacy breaches.

5. **Functional Limitations**: This software currently only supports macOS systems, with support for other operating systems under development. The software may contain unknown errors or limitations, and the developer does not guarantee its completeness, reliability, or suitability.

### Copyright and License
1. This project is licensed under the Apache License 2.0, allowing users to freely use, modify, and distribute it in compliance with the license terms.

2. Third-party libraries and components used in this project are subject to their respective licenses, which users should respect when using the software.

3. Stata is a registered trademark of StataCorp LLC. This project has no affiliation or sponsorship relationship with StataCorp.

### Contributions and Modifications
1. Users are welcome to participate in project development by submitting issue reports, feature requests, or pull requests through GitHub.

2. All contributors must adhere to the project's code of conduct and contribution guidelines.

3. The developer reserves the right to accept or reject any contributions.

### Updates and Maintenance
1. The developer does not promise to provide any form of technical support, maintenance, or updates for this software.

2. Software updates will be based on the developer's voluntary efforts and schedule, with no guarantee of any specific timeline for feature implementations or bug fixes.

## Version Française

### Note sur les Versions
Il peut y avoir des conflits entre différentes versions linguistiques. La version chinoise prévaudra.

### Description du Projet
Stata-MCP est un outil open-source conçu pour aider les utilisateurs à réaliser des analyses de régression avec Stata grâce aux Grands Modèles de Langage (LLM). Ce projet est sous licence Apache 2.0 et est destiné uniquement à des fins de recherche et d'éducation.

### Avertissement
1. **Risque d'Utilisation** : L'utilisation de ce logiciel se fait à vos propres risques. Le développeur n'est pas responsable des pertes directes ou indirectes qui pourraient résulter de l'utilisation de ce logiciel, y compris, mais sans s'y limiter, la perte de données, les défaillances du système ou d'autres formes de dommages.

2. **Licence Stata** : Cet outil est uniquement destiné à servir d'outil auxiliaire pour Stata. Les utilisateurs doivent posséder une licence Stata valide et légale pour utiliser ce logiciel. Ce projet n'est pas affilié à Stata et ne fournit aucune licence pour le logiciel Stata.

3. **Clés API** : L'utilisation de ce logiciel peut nécessiter des clés API de services LLM tiers. Les utilisateurs doivent se conformer aux conditions d'utilisation et aux politiques de confidentialité de ces fournisseurs de services. Le développeur n'est pas responsable des frais ou problèmes qui pourraient survenir lors de l'utilisation de services tiers.

4. **Sécurité des Données** : Ce logiciel peut traiter des données fournies par les utilisateurs. Les utilisateurs doivent s'assurer qu'ils disposent des droits légaux pour traiter ces données et comprendre les risques liés à la transmission de données à des services LLM tiers. Le développeur n'est pas responsable de la sécurité des données ou des violations de confidentialité.

5. **Limitations Fonctionnelles** : Ce logiciel ne prend actuellement en charge que les systèmes macOS, le support pour d'autres systèmes d'exploitation étant en cours de développement. Le logiciel peut contenir des erreurs ou des limitations inconnues, et le développeur ne garantit pas son exhaustivité, sa fiabilité ou son adéquation.

### Droits d'Auteur et Licence
1. Ce projet est sous licence Apache 2.0, permettant aux utilisateurs de l'utiliser, de le modifier et de le distribuer librement conformément aux conditions de la licence.

2. Les bibliothèques et composants tiers utilisés dans ce projet sont soumis à leurs licences respectives, que les utilisateurs doivent respecter lors de l'utilisation du logiciel.

3. Stata est une marque déposée de StataCorp LLC. Ce projet n'a aucune affiliation ou relation de parrainage avec StataCorp.

### Contributions et Modifications
1. Les utilisateurs sont invités à participer au développement du projet en soumettant des rapports de problèmes, des demandes de fonctionnalités ou des pull requests via GitHub.

2. Tous les contributeurs doivent adhérer au code de conduite et aux directives de contribution du projet.

3. Le développeur se réserve le droit d'accepter ou de rejeter toute contribution.

### Mises à Jour et Maintenance
1. Le développeur ne promet pas de fournir une forme quelconque de support technique, de maintenance ou de mises à jour pour ce logiciel.

2. Les mises à jour du logiciel seront basées sur les efforts volontaires et le planning du développeur, sans garantie d'un calendrier spécifique pour l'implémentation de fonctionnalités ou la correction de bugs.