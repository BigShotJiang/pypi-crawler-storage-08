# AutoFuzzTS

Automated fuzzy time series forecasting library in Python.  
Build and evaluate time series models automatically using fuzzy logic and AutoML techniques.

## Installation

```bash
pip install autofuzzts