r"""
 ___           _
| _ \__ _ _  _| |___  ___ _ __
|  _/ _` | || | / _ \/ _ \ '_ \
|_| \__,_|\_, |_\___/\___/ .__/
          |__/           |_|AI             07312025 / optimus codex
"""

ATHROPIC_CLIENT_TITLE = "anthropic"
GOOGLE_CLIENT_TITLE = "google"
LANGCHAIN_CLIENT_PROVIDER = "langchain"
LANGCHAIN_OPENAI_CLIENT_TITLE = "chatopenai"
LANGCHAIN_CHATBEDROCK_CLIENT_TITLE = "chatbedrock"
OPENAI_CLIENT_TITLE = "openai"
PYDANTIC_AI_CLIENT_PROVIDER = "pydantic_ai"
