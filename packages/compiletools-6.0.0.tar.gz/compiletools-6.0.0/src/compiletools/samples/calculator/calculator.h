#pragma once

#include "add.H"

// Simple calculator function declaration
int calculate(int a, int b);