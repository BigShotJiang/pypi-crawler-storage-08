#include "add.H"

// Basic addition function implementation
int add_numbers(int a, int b)
{
    return a + b;
}