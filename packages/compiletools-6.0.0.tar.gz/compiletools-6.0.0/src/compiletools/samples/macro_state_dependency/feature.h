#ifndef FEATURE_H
#define FEATURE_H

#ifdef DEBUG
#include "debug.h"
#else
#include "release.h"
#endif

#endif