#ifndef TEMP_DEFINED_HPP
#define TEMP_DEFINED_HPP
// Should be included when TEMP_MACRO is defined
#endif