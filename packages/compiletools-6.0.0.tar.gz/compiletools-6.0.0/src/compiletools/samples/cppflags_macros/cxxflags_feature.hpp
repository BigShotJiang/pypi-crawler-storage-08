#ifndef CXXFLAGS_FEATURE_HPP
#define CXXFLAGS_FEATURE_HPP
// Feature enabled via CXXFLAGS macro
#endif