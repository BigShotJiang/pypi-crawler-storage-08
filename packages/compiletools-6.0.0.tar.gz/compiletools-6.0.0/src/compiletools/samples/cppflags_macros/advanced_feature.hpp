#ifndef ADVANCED_FEATURE_HPP
#define ADVANCED_FEATURE_HPP

// Advanced feature implementation that should only be included
// when ENABLE_ADVANCED_FEATURES is defined in CPPFLAGS
class AdvancedFeature {
public:
    void execute();
};

#endif