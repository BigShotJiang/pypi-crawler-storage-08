#ifndef DEFAULT_FEATURE_HPP
#define DEFAULT_FEATURE_HPP
// Default fallback feature
#endif