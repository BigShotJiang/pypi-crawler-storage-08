#ifndef MSVC_FEATURE_HPP
#define MSVC_FEATURE_HPP
// Microsoft Visual C++ specific feature
#endif