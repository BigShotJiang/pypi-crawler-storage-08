#ifndef EMSCRIPTEN_FEATURE_HPP
#define EMSCRIPTEN_FEATURE_HPP
// Emscripten/WebAssembly specific feature
#endif