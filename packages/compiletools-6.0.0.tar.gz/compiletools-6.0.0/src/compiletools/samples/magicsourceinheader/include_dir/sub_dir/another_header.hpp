//#LDFLAGS=-lm
#ifdef __linux__
//#SOURCE=the_code_lin.cpp
#else
//#SOURCE=the_code_win.cpp
#endif

