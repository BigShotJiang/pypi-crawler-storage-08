#include "include_dir/some_header.hpp"

int main(int argc, char* argv[])
{

}
