#ifndef SYSTEM_VERSION_H
#define SYSTEM_VERSION_H

// Version 2.15 - should trigger modern branch when processed correctly
#define SYSTEM_VERSION_MAJOR 2
#define SYSTEM_VERSION_MINOR 15
#define SYSTEM_VERSION_PATCH 0

#endif