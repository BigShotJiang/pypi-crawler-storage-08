dict_of_parts = {
    "BTS7960": "2 x",
}
