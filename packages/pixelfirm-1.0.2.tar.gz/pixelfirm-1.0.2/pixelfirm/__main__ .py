def main():
    print("Pixelfirm CLI works!")

if __name__ == "__main__":
    main()
