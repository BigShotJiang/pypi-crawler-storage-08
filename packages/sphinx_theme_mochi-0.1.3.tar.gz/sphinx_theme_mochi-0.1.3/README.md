# sphinx-theme-mochi

sphinx-theme-mochi is a plain sphinx theme.

Documentation: https://cobapen.github.io/sphinx-theme-mochi

