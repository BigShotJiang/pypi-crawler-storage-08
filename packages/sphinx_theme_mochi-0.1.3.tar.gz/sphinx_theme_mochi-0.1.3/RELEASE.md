
# Release Log

## 0.1.3 (2025.10)

- Fix design: remove improper margin from the last table cell

## 0.1.2 (2025.02)

- Design fixes

## 0.1.1 (2024.07)

- Bug fixes
- Design fixes

## 0.1.0 (2024.01)

- Initial release