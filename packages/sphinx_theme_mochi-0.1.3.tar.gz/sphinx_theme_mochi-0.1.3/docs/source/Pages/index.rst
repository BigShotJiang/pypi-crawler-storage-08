User's Manual
==============

**sphinx-theme-mochi** is a simple theme for sphinx-documentation. 

The theme provides an improved navigation in the left pane. It allows writers to organize the documents in a structured manner.

..  toctree::
    :maxdepth: 2
    :titlesonly:
    
    setup.md
    customize.md
    usage.md