Developer's Manual
==================

This is a developer's documentation. 

..  toctree::
    :maxdepth: 1

    setup.md
    release.md
    publish.md
    maintenance.md

