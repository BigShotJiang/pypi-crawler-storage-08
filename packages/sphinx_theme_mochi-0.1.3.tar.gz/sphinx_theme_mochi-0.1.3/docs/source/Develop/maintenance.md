
# Maintenance

## Update Dependencies

python

```sh
# check outdated packages, then manually update the dependencies
pip list --outdated
```

node.js

```sh
npx npm-check-updates
npx npm-check-updates -u  # upgrade
```