# Release

1. Finish development
1. Increment version  `__init__.py`
1. Write changelog `RELEASE.md`
1. [Build and Publish](./publish.md)