"""DataSage MCP Server - Secure local file system access for AI assistants."""

__version__ = "1.0.0"
__author__ = "P6P Lab"
__description__ = "MCP server for secure local file system access"
