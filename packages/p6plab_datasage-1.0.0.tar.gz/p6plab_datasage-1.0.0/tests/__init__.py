"""Tests for DataSage MCP server."""
