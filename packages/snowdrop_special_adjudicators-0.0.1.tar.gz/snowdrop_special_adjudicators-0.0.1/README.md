# snowdrop-special-adjudicators
Geordie's top secret Tangled adjudicators

## Notes
Haven't been able to run quantum annealing tests because of hardware unavailability