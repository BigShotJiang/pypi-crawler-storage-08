"""Prefect MCP Server - MCP interface for Prefect."""

from prefect_mcp_server.server import mcp

__all__ = ["mcp"]
