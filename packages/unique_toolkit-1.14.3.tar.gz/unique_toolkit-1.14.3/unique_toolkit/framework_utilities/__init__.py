"""Framework utilities for integrating with external frameworks."""
