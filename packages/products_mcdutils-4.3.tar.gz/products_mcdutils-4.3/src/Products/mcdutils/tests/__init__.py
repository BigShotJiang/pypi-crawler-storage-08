""" Unit tests for Products.mcdutils """
