""" Product functional tests for mcdutils, run with "zopectl run"
"""
