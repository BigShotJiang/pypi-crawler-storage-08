def fart(colicshestvo):
    print(f'напреееедеелел {str(colicshestvo)}ййййййцуууущщщщщщщщщщщщщ раз')

def mega_farting(colicshestvo):
    print(f'супер ьупф напреееедеелел {str(colicshestvo)}йщщ раз')