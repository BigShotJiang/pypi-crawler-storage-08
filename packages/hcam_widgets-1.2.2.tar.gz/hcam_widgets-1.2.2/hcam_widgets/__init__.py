# -*- coding: utf-8 -*-
from __future__ import print_function, unicode_literals, absolute_import, division

__author__ = """Stuart Littlefair"""
__email__ = 's.littlefair@shef.ac.uk'
__version__ = '1.2.2'


class DriverError(Exception):
    pass
