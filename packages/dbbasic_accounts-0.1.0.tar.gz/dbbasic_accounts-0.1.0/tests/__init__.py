# Tests for dbbasic-passwd
