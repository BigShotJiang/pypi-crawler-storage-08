"""Template library for Strands Tools Community."""

from . import teams_templates

__all__ = ["teams_templates"]

