dataframely.columns.bool module
===============================

.. automodule:: dataframely.columns.bool
   :members:
   :show-inheritance:
   :undoc-members:
