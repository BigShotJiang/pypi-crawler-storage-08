dataframely.schema module
=========================

.. automodule:: dataframely.schema
   :members:
   :show-inheritance:
   :undoc-members:
