dataframely.columns.float module
================================

.. automodule:: dataframely.columns.float
   :members:
   :show-inheritance:
   :undoc-members:
