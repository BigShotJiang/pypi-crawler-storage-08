# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


from .aoai_grader import AzureOpenAIGrader

__all__ = [
    "AzureOpenAIGrader",
]
