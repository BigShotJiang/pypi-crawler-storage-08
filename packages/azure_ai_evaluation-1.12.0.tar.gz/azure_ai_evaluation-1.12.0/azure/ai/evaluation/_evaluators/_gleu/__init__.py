# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._gleu import GleuScoreEvaluator

__all__ = [
    "GleuScoreEvaluator",
]
