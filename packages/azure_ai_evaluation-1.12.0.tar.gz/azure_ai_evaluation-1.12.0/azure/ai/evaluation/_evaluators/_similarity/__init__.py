# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._similarity import SimilarityEvaluator

__all__ = [
    "SimilarityEvaluator",
]
