# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._task_success import TaskSuccessEvaluator

__all__ = ["TaskSuccessEvaluator"]
