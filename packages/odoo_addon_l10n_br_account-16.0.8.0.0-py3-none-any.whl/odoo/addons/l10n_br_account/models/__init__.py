# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html

from . import account_chart_template
from . import account_tax_group
from . import fiscal_tax_group
from . import account_tax_template
from . import account_tax
from . import fiscal_tax
from . import fiscal_operation
from . import fiscal_operation_line
from . import fiscal_decorator_mixin
from . import account_move
from . import account_move_line
from . import document
from . import document_line
from . import account_incoterms
from . import ir_model_data
from . import account_journal
