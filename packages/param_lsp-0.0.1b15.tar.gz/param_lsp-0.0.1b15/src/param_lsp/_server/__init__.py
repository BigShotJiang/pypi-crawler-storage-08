"""Mixins for the Param Language Server."""

from __future__ import annotations
