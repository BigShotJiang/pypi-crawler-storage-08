# Release History

## 1.0.1 (2025-10-09)

### Bugs Fixed

- Exclude `generated_samples` and `generated_tests` from wheel

## 1.0.0 (2025-09-29)

### Features Added

  - First GA

## 1.0.0b2 (2025-09-03)

### Features Added

  - Client `StorageDiscoveryMgmtClient` added parameter `cloud_setting` in method `__init__`

## 1.0.0b1 (2025-07-17)

### Other Changes

  - Initial version
