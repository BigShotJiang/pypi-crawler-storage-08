from importlib.metadata import version as _importlib_metadata_version
#from .components import *

__version__ = _importlib_metadata_version("flask-composed-views")

