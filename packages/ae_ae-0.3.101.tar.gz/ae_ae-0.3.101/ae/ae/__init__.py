""" bundling and maintaining templates and documentation of the portions of this namespace. """

__version__ = '0.3.101'
