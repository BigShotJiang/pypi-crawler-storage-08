"""
Entry point for the Vector Memory MCP server.
This can be used as an alternative to running vector_memory.py directly.
"""

from vector_memory import main

if __name__ == "__main__":
    main()
