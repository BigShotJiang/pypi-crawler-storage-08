# -*- coding:utf-8 -*-
"""
ddns Package
"""

__description__ = "automatically update DNS records to my IP [域名自动指向本机IP]"

# 编译时，版本会被替换
__version__ = "4.1.0"

# 时间也会被替换掉
build_date = "2025-10-09T09:06:52Z"
