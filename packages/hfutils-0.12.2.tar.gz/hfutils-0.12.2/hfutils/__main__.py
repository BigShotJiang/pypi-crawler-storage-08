from .entry import hfutilscli

if __name__ == '__main__':
    hfutilscli()
