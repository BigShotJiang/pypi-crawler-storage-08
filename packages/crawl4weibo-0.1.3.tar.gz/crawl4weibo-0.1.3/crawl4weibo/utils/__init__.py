#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Utility functions for crawl4weibo
"""