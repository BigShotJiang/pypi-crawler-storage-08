#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Exceptions for crawl4weibo
"""