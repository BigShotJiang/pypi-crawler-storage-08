#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Data models for crawl4weibo
"""