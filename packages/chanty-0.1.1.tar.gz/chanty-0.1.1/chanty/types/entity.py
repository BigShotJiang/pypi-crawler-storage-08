class Entity:
    # BLOCKS
    TNT = "minecraft:tnt"
    # HOSTILE
    ZOMBIE = "minecraft:zombie"
    # PEACE
    COW = "minecraft:cow"
    SHEEP = "minecraft:sheep"
    PIG = "minecraft:pig"
    # NPCs
    VILLAGER = "minecraft:villager"
    PLAYER = "player"
