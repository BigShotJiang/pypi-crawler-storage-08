# pyconfiglite
A lightweight config manager that loads configs (YAML, JSON, TOML, INI), validates them against a schema, supports environment variable overrides, and gives type safety.
