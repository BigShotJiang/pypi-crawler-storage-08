class ConfigError(Exception):
    """Custom exception for configuration errors."""
    pass
