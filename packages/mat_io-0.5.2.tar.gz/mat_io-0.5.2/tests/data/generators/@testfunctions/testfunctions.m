classdef testfunctions
    methods
        function y = square(~,x)
            y = x.^2;
        end
    end
end
