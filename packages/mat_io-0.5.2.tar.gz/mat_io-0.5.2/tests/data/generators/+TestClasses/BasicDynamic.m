classdef BasicDynamic < dynamicprops
    properties
        Name
    end
    methods
        function obj = BasicDynamic(name)
            obj.Name = name;
        end
    end
end
