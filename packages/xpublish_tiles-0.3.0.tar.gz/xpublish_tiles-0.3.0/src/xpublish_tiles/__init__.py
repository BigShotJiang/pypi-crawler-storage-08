"""xpublish-tiles"""

from xpublish_tiles.config import config as config
