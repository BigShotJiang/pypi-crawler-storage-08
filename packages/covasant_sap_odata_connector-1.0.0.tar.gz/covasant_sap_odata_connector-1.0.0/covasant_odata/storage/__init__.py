"""Storage module for SAP OData Connector"""
