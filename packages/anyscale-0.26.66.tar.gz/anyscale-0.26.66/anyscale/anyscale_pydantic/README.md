
Current vendored pydantic version is `1.10.12` and source files were downloaded from https://files.pythonhosted.org/packages/3b/9b/a7631bf35e55326fd74654fe6bd896478f47d65e97ca69e60ddb1b3823ee/pydantic-1.10.12.tar.gz.

## Steps to upgrade pydantic version:
- Select pydantic version from https://pypi.org/project/pydantic/#history
- A link to the source distribution tar file can be found in the "Download files" section. Download this tar file.
- Copy files from `pydantic` folder (eg: `pydantic-1.10.12/pydantic` to `frontend/cli/anyscale/anyscale_pydantic`). Also copy over license information.