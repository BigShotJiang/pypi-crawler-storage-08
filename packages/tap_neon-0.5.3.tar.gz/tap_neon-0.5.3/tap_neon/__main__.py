"""Tap executable."""

from __future__ import annotations

from tap_neon.tap import TapNeon

TapNeon.cli()
