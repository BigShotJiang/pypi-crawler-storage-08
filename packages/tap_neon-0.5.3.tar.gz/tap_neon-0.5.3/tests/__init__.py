"""Tests for tap-neon."""

from __future__ import annotations
