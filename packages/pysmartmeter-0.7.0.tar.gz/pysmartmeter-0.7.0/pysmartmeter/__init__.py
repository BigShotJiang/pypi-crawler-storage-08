"""
    pysmartmeter
    Collect data from Hichi Smartmeter and expose it via MQTT
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__author__ = 'Jens Diemer <pysmartmeter@jensdiemer.de>'
__version__ = '0.7.0'
