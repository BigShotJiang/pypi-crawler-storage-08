"""
    Allow pysmartmeter to be executable
    through `python -m pysmartmeter`.
"""

from pysmartmeter.cli_app import main


if __name__ == '__main__':
    main()
