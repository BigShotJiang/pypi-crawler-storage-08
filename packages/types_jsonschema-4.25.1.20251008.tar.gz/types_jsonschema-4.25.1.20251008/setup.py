
from setuptools import setup

setup(package_data={'jsonschema-stubs': ['__init__.pyi', '_format.pyi', '_keywords.pyi', '_legacy_keywords.pyi', '_types.pyi', '_typing.pyi', '_utils.pyi', 'cli.pyi', 'exceptions.pyi', 'protocols.pyi', 'validators.pyi', 'METADATA.toml', 'py.typed']})
