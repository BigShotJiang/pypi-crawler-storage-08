# -*- coding: utf-8 -*-
"""
    @Author : PKing
    @E-mail : 
    @Date   : 2023-09-20 08:50:12
    @Brief  :
"""


def sum(a, b):
    print(a, b)
    return a + b
