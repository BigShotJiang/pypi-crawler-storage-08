__version__ = "1.2.19"  # pragma: no cover
