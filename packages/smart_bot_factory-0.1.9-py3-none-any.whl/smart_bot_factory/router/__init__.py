"""
Router модули smart_bot_factory
"""

from ..core.router import Router

__all__ = [
    'Router'
]