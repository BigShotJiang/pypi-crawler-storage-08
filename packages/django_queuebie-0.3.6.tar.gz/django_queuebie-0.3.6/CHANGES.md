# Changelog

**0.3.6** (2025-10-10)
  * Maintenance updates via ambient-package-update

**0.3.5** (2025-10-09)
  * Maintenance updates via ambient-package-update

**0.3.4** (2025-05-29)
  * Maintenance updates via ambient-package-update

**0.3.3** (2025-04-03)
  * Clarified package tagline

**0.3.2** (2025-04-03)
  * Maintenance updates via ambient-package-update

* *0.3.1* (2025-03-19)
  * Added a paranoid-ish test to check that the import logic isn't breaking any testing functionality

* *0.3.0* (2025-03-19)
  * The whole queue iteration now is wrapped in a transaction atomic

* *0.2.0* (2025-03-17)
  * Extend strict mode to prohibit event (!) handlers to talk to the database

* *0.1.0* (2025-01-29)
  * Project init
