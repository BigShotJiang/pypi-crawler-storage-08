django-queuebie
===============

.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   features/introduction.md
   features/motivation.md
   features/setup.md
   features/getting-started.md
   features/settings.md
   features/changelog.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
