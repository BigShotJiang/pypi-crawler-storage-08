pytorch\_lightning\_spells.optimizers module
============================================

.. automodule:: pytorch_lightning_spells.optimizers
   :autosummary:
   :autosummary-no-nesting:
   :members:
   :undoc-members:
   :show-inheritance:
