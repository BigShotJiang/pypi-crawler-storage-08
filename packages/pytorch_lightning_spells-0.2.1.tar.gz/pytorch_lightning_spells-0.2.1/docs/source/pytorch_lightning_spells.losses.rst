pytorch\_lightning\_spells.losses module
========================================

.. automodule:: pytorch_lightning_spells.losses
   :autosummary:
   :autosummary-no-nesting:
   :members:
   :undoc-members:
   :show-inheritance:
