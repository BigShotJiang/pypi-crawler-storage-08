pytorch\_lightning\_spells.callbacks module
===========================================

.. automodule:: pytorch_lightning_spells.callbacks
   :autosummary:
   :autosummary-no-nesting:
   :members:
   :undoc-members:
   :show-inheritance:
