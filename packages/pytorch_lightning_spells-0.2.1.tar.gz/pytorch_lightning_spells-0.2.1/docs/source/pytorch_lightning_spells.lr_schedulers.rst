pytorch\_lightning\_spells.lr\_schedulers module
================================================

.. automodule:: pytorch_lightning_spells.lr_schedulers
   :autosummary:
   :autosummary-no-nesting:
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
