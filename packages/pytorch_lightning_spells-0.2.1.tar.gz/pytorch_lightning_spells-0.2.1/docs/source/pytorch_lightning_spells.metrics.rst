pytorch\_lightning\_spells.metrics module
=========================================

.. automodule:: pytorch_lightning_spells.metrics
   :autosummary:
   :autosummary-no-nesting:
   :members:
   :undoc-members:
   :show-inheritance:
