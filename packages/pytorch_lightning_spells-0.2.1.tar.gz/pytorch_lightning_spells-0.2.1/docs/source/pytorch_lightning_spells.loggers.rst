pytorch\_lightning\_spells.loggers module
=========================================

.. automodule:: pytorch_lightning_spells.loggers
   :autosummary:
   :autosummary-no-nesting:
   :members:
   :undoc-members:
   :show-inheritance:
