====================
page 1
====================

this is page 1

..  toctree::
    :maxdepth: 1

    page1-1
    page1-2