# Release

🔽 Finish development

🔽 Build assets

```sh
npm run build:sass
```

🔽 Increment version  `__init__.py`

🔽 Write changelog `RELEASE.md`

🔽 [Build and Publish](./publish.md)