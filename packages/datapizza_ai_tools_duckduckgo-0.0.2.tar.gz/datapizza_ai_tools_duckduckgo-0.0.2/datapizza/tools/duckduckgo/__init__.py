from .base import DuckDuckGoSearchTool

__all__ = ["DuckDuckGoSearchTool"]
