This module adds images to the maintenance equipments.
