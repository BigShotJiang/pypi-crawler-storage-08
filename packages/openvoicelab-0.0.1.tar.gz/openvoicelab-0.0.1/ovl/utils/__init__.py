from ovl.utils.logging import setup_logging

__all__ = ["setup_logging"]
