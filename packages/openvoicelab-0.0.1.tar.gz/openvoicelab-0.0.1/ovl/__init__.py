__version__ = "0.0.1"
__author__ = "OpenVoiceLab Contributors"
__license__ = "BSD-3-Clause"

from ovl.app import app

__all__ = ["app", "__version__"]
