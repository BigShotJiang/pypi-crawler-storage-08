"""Training module for VibeVoice fine-tuning"""

from ovl.training.trainer import TrainingManager

__all__ = ["TrainingManager"]
