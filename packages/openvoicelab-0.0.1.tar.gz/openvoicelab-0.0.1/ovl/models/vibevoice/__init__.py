from .model import VibeVoiceModel

__all__ = ["VibeVoiceModel"]
