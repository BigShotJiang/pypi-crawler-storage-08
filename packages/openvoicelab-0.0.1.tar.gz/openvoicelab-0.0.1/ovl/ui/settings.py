import gradio as gr

with gr.Blocks() as settings_tab:
    gr.Markdown("Settings")
