# Copyright 2025 BrainX Ecosystem Limited. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
import brainpy.math as bm


def test_format():
    print(bm.ones((5)))
    print(bm.Variable(bm.ones((5))))
    print(bm.VariableView(bm.Variable(bm.ones((5))), bm.asarray([1, 2, 3])))

    print(bm.ones((3, 4)))
    print(bm.Variable(bm.ones((3, 4))))
    print(bm.VariableView(bm.Variable(bm.ones((3, 4))), bm.asarray([1, 2])))
