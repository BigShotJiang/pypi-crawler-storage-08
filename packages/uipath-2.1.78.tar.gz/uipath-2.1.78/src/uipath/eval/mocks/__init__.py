"""Mock interface."""

from uipath._cli._evals._models._mocks import ExampleCall

from .mockable import mockable

__all__ = ["ExampleCall", "mockable"]
