def generate_name(base: str, index: int) -> str:
    return f"{base}_{index}"
