from .core import generate_name

__all__ = ["generate_name"]
