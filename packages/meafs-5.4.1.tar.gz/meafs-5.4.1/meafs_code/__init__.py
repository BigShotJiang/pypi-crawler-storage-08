__version__ = "5.4.1"
__author__ = "Matheus J. Castro"

from meafs_code import gui
