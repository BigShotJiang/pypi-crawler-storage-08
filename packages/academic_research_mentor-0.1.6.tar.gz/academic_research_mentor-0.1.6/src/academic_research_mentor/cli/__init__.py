# CLI package for Academic Research Mentor

from .main import main as main
