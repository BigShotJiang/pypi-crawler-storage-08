from xl_docx.compiler.processors.base import BaseProcessor
from xl_docx.compiler.processors.style import StyleProcessor
from xl_docx.compiler.processors.directive import DirectiveProcessor
from xl_docx.compiler.processors.table import TableProcessor
from xl_docx.compiler.processors.paragraph import ParagraphProcessor
from xl_docx.compiler.processors.pager import PagerProcessor
from xl_docx.compiler.processors.component import ComponentProcessor
