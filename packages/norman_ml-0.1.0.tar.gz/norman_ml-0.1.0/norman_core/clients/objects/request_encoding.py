from enum import Enum

class RequestEncoding(Enum):
    Bytes = "bytes"
    Json = "json"
    Text = "text"
