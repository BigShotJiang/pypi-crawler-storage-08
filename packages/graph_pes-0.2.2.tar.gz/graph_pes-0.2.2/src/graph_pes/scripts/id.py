from graph_pes.utils.misc import random_id


def main():
    print(random_id())


if __name__ == "__main__":
    main()
