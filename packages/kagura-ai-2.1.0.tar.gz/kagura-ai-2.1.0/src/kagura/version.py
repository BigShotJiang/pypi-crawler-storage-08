"""Version information for Kagura AI"""
__version__ = "2.1.0"
