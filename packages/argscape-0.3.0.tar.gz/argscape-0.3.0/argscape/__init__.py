"""
Argscape package initialization.
""" 

__version__ = "0.3.0"
