# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Session Service."""

__version__ = "3.26.2"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .admin_get_member_active_3765c4 import AdminGetMemberActiveSession
from .admin_reconcile_max_act_4f7653 import AdminReconcileMaxActiveSession
