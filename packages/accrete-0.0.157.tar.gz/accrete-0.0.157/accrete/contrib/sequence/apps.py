from django.apps import AppConfig


class SequenceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'accrete.contrib.sequence'
