from dify_oapi.core.model.base_response import BaseResponse

from .annotation_info import AnnotationInfo


class GetAnnotationsResponse(BaseResponse):
    """Response for getting annotation list."""

    data: list[AnnotationInfo] | None = None
    has_more: bool | None = None
    limit: int | None = None
    total: int | None = None
    page: int | None = None
