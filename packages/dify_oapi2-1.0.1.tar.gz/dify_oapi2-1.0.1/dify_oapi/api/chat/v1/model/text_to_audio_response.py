from dify_oapi.core.model.base_response import BaseResponse


class TextToAudioResponse(BaseResponse):
    """Response for text-to-audio API that returns binary audio data."""

    pass
