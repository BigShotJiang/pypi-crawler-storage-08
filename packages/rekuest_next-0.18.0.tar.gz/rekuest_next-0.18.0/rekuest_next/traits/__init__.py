"""General traits for Rekuest Next"""
