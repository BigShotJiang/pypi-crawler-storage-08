"""Package metadata for Arbitrium Framework."""

__version__ = "0.0.1"
__description__ = "A framework for collaborative-competitive LLM evaluation"
__author__ = "Nikolay Eremeev"
__author_email__ = "nikolay.eremeev@outlook.com"
__license__ = "MIT"
