"""Integration tests for Arbitrium Framework."""
