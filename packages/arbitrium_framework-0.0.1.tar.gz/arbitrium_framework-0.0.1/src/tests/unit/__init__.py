"""Unit tests for Arbitrium Framework."""
