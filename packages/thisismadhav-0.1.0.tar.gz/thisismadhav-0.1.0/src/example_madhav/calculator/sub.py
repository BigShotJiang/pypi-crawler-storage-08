def sub(a,b):
    print("this is,",a)
    c=a-b
    return c