# Tax capital gains income as ordinary income
