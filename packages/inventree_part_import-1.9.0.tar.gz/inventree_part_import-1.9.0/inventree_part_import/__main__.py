from .cli import inventree_part_import

if __name__ == "__main__":
    inventree_part_import(max_content_width=120)
