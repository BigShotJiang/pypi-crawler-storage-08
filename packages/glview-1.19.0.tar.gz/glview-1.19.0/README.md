# glview

[![Build Status](https://travis-ci.com/toaarnio/glview.svg?branch=master)](https://travis-ci.com/github/toaarnio/glview)

Lightning-fast image viewer with synchronized split-screen zooming &amp; panning + HDR &amp; WCG support

**Installing:**
```
pip install glview
```

**Usage:**
```
glview --help
```

**Building &amp; installing from source:**
```
make install
```
