# Contributors

* Jake Varey [jacob.varey@ll.mit.edu](mailto:jacob.varey@ll.mit.edu)
* Ryan Sullenberger [ryan.sullenberger@ll.mit.edu](mailto:ryan.sullenberger@ll.mit.edu)
* Michael Tierney [michael.kotson@ll.mit.edu](mailto:michael.kotson@ll.mit.edu)
* Hunter Quebedeaux [hunter.quebedeaux@ucf.edu](mailto:hunter.quebedeaux@ucf.edu)