release = "fixes for mac release builds"
version = "3.2.0.a0.dev6"
