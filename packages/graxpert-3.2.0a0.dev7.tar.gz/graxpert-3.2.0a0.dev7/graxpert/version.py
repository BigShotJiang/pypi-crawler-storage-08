release = "the github CI DMG builds are not yet reliable, don't require them before pypi publish"
version = "3.2.0.a0.dev7"
