# -*- coding: utf-8 -*-
from httpbinx.routers.inspection import request as request_inspection
from httpbinx.routers.inspection import response as response_inspection
