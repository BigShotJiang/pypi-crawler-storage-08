from .main import app

__version__ = '1.9.0'

app.version = __version__
