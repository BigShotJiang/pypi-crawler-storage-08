REDIRECT_LOCATION = '/redirect/1'

ACCEPTED_MEDIA_TYPES = [
    'image/webp',
    'image/svg+xml',
    'image/jpeg',
    'image/png',
    'image/*'
]

ENV_COOKIES = (
    '_gauges_unique',
    '_gauges_unique_year',
    '_gauges_unique_month',
    '_gauges_unique_day',
    '_gauges_unique_hour',
    '__utmz',
    '__utma',
    '__utmb',
)

ASCII_ART = """
    -=[ teapot ]=-

       _...._
     .'  _ _ `.
    | ."` ^ `". _,
    \\_;`"---"`|//
      |       ;/
      \\_     _/
        `\"\"\"`
"""

ANGRY_ASCII = """
          .-''''''-.
        .' _      _ '.
       /   O      O   \\
      :                :
      |                |
      :       __       :
       \\  .-"`  `"-.  /
        '.          .'
          '-......-'
     YOU SHOULDN'T BE HERE
"""

ROBOT_TXT = """User-agent: *
Disallow: /deny
"""

AWESOME_BASE64ENCODED = 'SFRUUEJJTlggaXMgYXdlc29tZQ=='
