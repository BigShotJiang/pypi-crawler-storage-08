# -*- coding: utf-8 -*-
"""
Tag: Redirects
"""
from fastapi.testclient import TestClient

from httpbinx import app

client = TestClient(app)


def test_absolute_redirect(): pass


def test_redirect_to(): pass


def test_redirect(): pass


def test_relative_redirect(): pass
