from abc import ABC


class Router(ABC):
	pass
