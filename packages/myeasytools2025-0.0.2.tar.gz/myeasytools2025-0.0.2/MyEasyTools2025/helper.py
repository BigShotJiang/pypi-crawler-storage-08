pi = 3.14

def greet():
    return "Hey"
