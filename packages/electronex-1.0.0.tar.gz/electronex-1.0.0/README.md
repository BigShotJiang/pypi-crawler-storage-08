# EngiX — Engineering Intelligence Toolkit

EngiX is a Python package for **ECE and CSE engineers**.

## Installation
```bash
pip install engix
