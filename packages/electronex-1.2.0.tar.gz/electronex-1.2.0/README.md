# Electronex — Engineering Intelligence Toolkit

Electronex is a Python package for **ECE and CSE engineers**.

## Installation
```bash
pip install electronex
