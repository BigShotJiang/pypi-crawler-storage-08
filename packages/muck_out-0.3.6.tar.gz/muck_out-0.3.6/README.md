# bovine - muck_out

The goal of this package is to provide normalization
routines for ActivityPub data. This means you input
some dictionary and get a pydantic object back.

__Warning__: This package is a work in progress, and might
change a lot.

## Development

### Generate json schemas

```bash
python -mmuck_out schemas
```