# actor-header-component

## Development

### Setting up to run tests

```bash
npm install
./node_modules/.bin/playwright install
```

then one can run tests via

```bash
npm test
```

### Testing looks

```bash
npm run dev
```