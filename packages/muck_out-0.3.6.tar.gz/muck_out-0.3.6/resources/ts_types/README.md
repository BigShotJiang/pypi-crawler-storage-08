# @cattle-grid/muck-out-types

Automatically generated type objects.

* [muck_out](https://bovine.codeberg.page/muck_out/)

## Publishing

```bash
npm run generate
npm publish --access public
```

## docs

```bash
npm run docs
```