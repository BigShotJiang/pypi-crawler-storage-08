"""Generated protocol buffer code."""

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

_sym_db = _symbol_database.Default()


from ..._protobuf import Error_pb2 as Error__pb2

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(
    b'\n\x18SetUserBlackResIdl.proto\x1a\x0b\x45rror.proto"+\n\x12SetUserBlackResIdl\x12\x15\n\x05\x65rror\x18\x01 \x01(\x0b\x32\x06.Errorb\x06proto3'
)

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, "SetUserBlackResIdl_pb2", _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals["_SETUSERBLACKRESIDL"]._serialized_start = 41
    _globals["_SETUSERBLACKRESIDL"]._serialized_end = 84
