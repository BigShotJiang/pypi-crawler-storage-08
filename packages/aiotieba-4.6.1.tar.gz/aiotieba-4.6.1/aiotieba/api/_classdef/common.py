from typing import TypeVar

from google.protobuf.message import Message

TypeMessage = TypeVar("TypeMessage", bound=Message)
