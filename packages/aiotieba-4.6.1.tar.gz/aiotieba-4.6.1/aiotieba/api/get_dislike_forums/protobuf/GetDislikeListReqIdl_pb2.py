"""Generated protocol buffer code."""

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

_sym_db = _symbol_database.Default()


from ..._protobuf import CommonReq_pb2 as CommonReq__pb2

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(
    b'\n\x1aGetDislikeListReqIdl.proto\x1a\x0f\x43ommonReq.proto"\x82\x01\n\x14GetDislikeListReqIdl\x12+\n\x04\x64\x61ta\x18\x01 \x01(\x0b\x32\x1d.GetDislikeListReqIdl.DataReq\x1a=\n\x07\x44\x61taReq\x12\x1a\n\x06\x63ommon\x18\x01 \x01(\x0b\x32\n.CommonReq\x12\n\n\x02pn\x18\x03 \x01(\x05\x12\n\n\x02rn\x18\x04 \x01(\x05\x62\x06proto3'
)

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, "GetDislikeListReqIdl_pb2", _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals["_GETDISLIKELISTREQIDL"]._serialized_start = 48
    _globals["_GETDISLIKELISTREQIDL"]._serialized_end = 178
    _globals["_GETDISLIKELISTREQIDL_DATAREQ"]._serialized_start = 117
    _globals["_GETDISLIKELISTREQIDL_DATAREQ"]._serialized_end = 178
