"""Generated protocol buffer code."""

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

_sym_db = _symbol_database.Default()


DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(
    b'\n\x17GetUserInfoReqIdl.proto"Y\n\x11GetUserInfoReqIdl\x12(\n\x04\x64\x61ta\x18\x01 \x01(\x0b\x32\x1a.GetUserInfoReqIdl.DataReq\x1a\x1a\n\x07\x44\x61taReq\x12\x0f\n\x07user_id\x18\x02 \x01(\x03\x62\x06proto3'
)

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, "GetUserInfoReqIdl_pb2", _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals["_GETUSERINFOREQIDL"]._serialized_start = 27
    _globals["_GETUSERINFOREQIDL"]._serialized_end = 116
    _globals["_GETUSERINFOREQIDL_DATAREQ"]._serialized_start = 90
    _globals["_GETUSERINFOREQIDL_DATAREQ"]._serialized_end = 116
