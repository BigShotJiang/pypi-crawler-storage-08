"""Generated protocol buffer code."""

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

_sym_db = _symbol_database.Default()


from ..._protobuf import CommonReq_pb2 as CommonReq__pb2

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(
    b'\n\x1bSearchPostForumReqIdl.proto\x1a\x0f\x43ommonReq.proto"{\n\x15SearchPostForumReqIdl\x12,\n\x04\x64\x61ta\x18\x01 \x01(\x0b\x32\x1e.SearchPostForumReqIdl.DataReq\x1a\x34\n\x07\x44\x61taReq\x12\x1a\n\x06\x63ommon\x18\x01 \x01(\x0b\x32\n.CommonReq\x12\r\n\x05\x66name\x18\x02 \x01(\tb\x06proto3'
)

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, "SearchPostForumReqIdl_pb2", _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals["_SEARCHPOSTFORUMREQIDL"]._serialized_start = 48
    _globals["_SEARCHPOSTFORUMREQIDL"]._serialized_end = 171
    _globals["_SEARCHPOSTFORUMREQIDL_DATAREQ"]._serialized_start = 119
    _globals["_SEARCHPOSTFORUMREQIDL_DATAREQ"]._serialized_end = 171
