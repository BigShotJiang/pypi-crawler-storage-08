from .api._classdef import UserInfo, contents
from .api.get_comments import Comment, Comments
from .api.get_posts import Post, Posts
from .api.get_threads import Thread, Threads

TypeUserInfo = UserInfo
