#pragma once

#define TBC_OK 0x0000

#define TBC_MEMORY_ERROR 0x0001
