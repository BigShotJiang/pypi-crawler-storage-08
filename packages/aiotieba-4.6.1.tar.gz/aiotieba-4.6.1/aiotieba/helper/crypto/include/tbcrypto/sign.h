#pragma once

#include "tbcrypto/pywrap.h"

PyObject* sign(PyObject* Py_UNUSED(self), PyObject* args);
