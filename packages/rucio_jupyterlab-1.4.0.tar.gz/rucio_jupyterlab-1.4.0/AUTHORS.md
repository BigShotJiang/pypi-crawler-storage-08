Individual contributors to the source code
------------------------------------------
- Muhammad Aditya Hilmy <mhilmy@hey.com>, 2020
- Alba Vendrell (CERN), 2022
- Elena Gazzarrini (CERN), 2022-2023
- Domenic Gosein (CERN), 2023
- Francesc Torradeflot (PIC), 2023-2024
- Enrique Garcia (CERN), 2023-2024
- Giovanni Guerrieri (CERN) 2024-
  
Organisations associated with contributors
------------------------------------------
- Institut Teknologi Bandung (Indonesia)
- CERN (Switzerland)
- Mannheim University of Applied Sciences (Germany)
  