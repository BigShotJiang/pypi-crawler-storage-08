from __future__ import annotations

from setuptools import setup

setup(name="demo-pkg", package_dir={"": "src"})
