from __future__ import annotations


def hello() -> str:
    return "Hello from demo-foo!"
