# This file is generated. Do not modify by hand.
from enum import Enum


class ProcessControllerSourceSensor(Enum):
    """
    Servo Tuning Parameter Set to target.
    """

    THERMISTOR = 10
    ANALOG_INPUT = 20
