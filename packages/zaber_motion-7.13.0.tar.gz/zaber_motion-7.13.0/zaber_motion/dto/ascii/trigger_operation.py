# This file is generated. Do not modify by hand.
from enum import Enum


class TriggerOperation(Enum):
    """
    Operation for trigger action.
    """

    SET_TO = 0
    INCREMENT_BY = 1
    DECREMENT_BY = 2
