# This file is generated. Do not modify by hand.
from enum import Enum


class DigitalOutputAction(Enum):
    """
    Action type for digital output.
    """

    OFF = 0
    ON = 1
    TOGGLE = 2
    KEEP = 3
