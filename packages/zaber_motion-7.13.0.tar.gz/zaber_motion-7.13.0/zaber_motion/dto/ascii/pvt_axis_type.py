# This file is generated. Do not modify by hand.
from enum import Enum


class PvtAxisType(Enum):
    """
    Denotes type of the PVT sequence axis.
    """

    PHYSICAL = 0
    LOCKSTEP = 1
