﻿# ===== THIS FILE IS GENERATED FROM A TEMPLATE ===== #
# ============== DO NOT EDIT DIRECTLY ============== #

from .motion_lib_exception import MotionLibException


class OsFailedException(MotionLibException):
    """
    Thrown when an operation fails due to underlying operating system error.
    """
