class regs:
    # ***********************************************************************
    #
    # regs.h                                          (c) Spectrum GmbH, 2006
    #
    # ***********************************************************************
    #
    # software register and constants definition for all Spectrum drivers.
    # Please stick to the card manual to see which of the inhere defined
    # registers are used on your hardware.
    #
    # ***********************************************************************

    # ***********************************************************************
    # macros for kilo, Mega or Giga as standard version or binary (_B) (2^x)
    # ***********************************************************************

    # KILO = (k)     ((uint64) 1000 * k)
    # MEGA = (m)     ((uint64) 1000 * 1000 * m)
    # GIGA = (g)     ((uint64) 1000 * 1000 * 1000 * g)
    # KILO_B = (k)   ((uint64) 1024 * k)
    # MEGA_B = (m)   ((uint64) 1024 * 1024 * m)
    # GIGA_B = (g)   ((uint64) 1024 * 1024 * 1024 * g)

    # #Self created!!!
    SPCM_BUF_DATA = 1000
    SPCM_DIR_PCTOCARD = 0
    SPCM_DIR_CARDTOPC = 1

    # ***********************************************************************
    # card types
    # ***********************************************************************

    TYP_PCIDEVICEID = 0x00000000

    # ***** Board Types ***************
    TYP_EVAL = 0x00000010
    TYP_RSDLGA = 0x00000014
    TYP_GMG = 0x00000018
    TYP_VAN8 = 0x00000020
    TYP_VAC = 0x00000028

    TYP_PCIAUTOINSTALL = 0x000000FF

    TYP_DAP116 = 0x00000100
    TYP_PAD82 = 0x00000200
    TYP_PAD82a = 0x00000210
    TYP_PAD82b = 0x00000220
    TYP_PCI212 = 0x00000300
    TYP_PAD1232a = 0x00000400
    TYP_PAD1232b = 0x00000410
    TYP_PAD1232c = 0x00000420
    TYP_PAD1616a = 0x00000500
    TYP_PAD1616b = 0x00000510
    TYP_PAD1616c = 0x00000520
    TYP_PAD1616d = 0x00000530
    TYP_PAD52 = 0x00000600
    TYP_PAD242 = 0x00000700
    TYP_PCK400 = 0x00000800
    TYP_PAD164_2M = 0x00000900
    TYP_PAD164_5M = 0x00000910
    TYP_PCI208 = 0x00001000
    TYP_CPCI208 = 0x00001001
    TYP_PCI412 = 0x00001100
    TYP_PCIDIO32 = 0x00001200
    TYP_PCI248 = 0x00001300
    TYP_PADCO = 0x00001400
    TYP_TRS582 = 0x00001500
    TYP_PCI258 = 0x00001600

    # ------ series and familiy identifiers -----
    TYP_SERIESMASK = 0x00FF0000  # the series (= type of base card), e.g. MI.xxxx
    TYP_VERSIONMASK = 0x0000FFFF  # the version, e.g. XX.3012
    TYP_FAMILYMASK = 0x0000FF00  # the family, e.g. XX.30xx
    TYP_TYPEMASK = 0x000000FF  # the type, e.g. XX.xx12
    TYP_SPEEDMASK = 0x000000F0  # the speed grade, e.g. XX.xx1x
    TYP_CHMASK = 0x0000000F  # the channel/modules, e.g. XX.xxx2

    TYP_MISERIES = 0x00000000
    TYP_MCSERIES = 0x00010000
    TYP_MXSERIES = 0x00020000
    TYP_M2ISERIES = 0x00030000
    TYP_M2IEXPSERIES = 0x00040000
    TYP_M3ISERIES = 0x00050000
    TYP_M3IEXPSERIES = 0x00060000

    # ----- MI.20xx, MC.20xx, MX.20xx -----
    TYP_MI2020 = 0x00002020
    TYP_MI2021 = 0x00002021
    TYP_MI2025 = 0x00002025
    TYP_MI2030 = 0x00002030
    TYP_MI2031 = 0x00002031

    TYP_M2I2020 = 0x00032020
    TYP_M2I2021 = 0x00032021
    TYP_M2I2025 = 0x00032025
    TYP_M2I2030 = 0x00032030
    TYP_M2I2031 = 0x00032031

    TYP_M2I2020EXP = 0x00042020
    TYP_M2I2021EXP = 0x00042021
    TYP_M2I2025EXP = 0x00042025
    TYP_M2I2030EXP = 0x00042030
    TYP_M2I2031EXP = 0x00042031

    TYP_MC2020 = 0x00012020
    TYP_MC2021 = 0x00012021
    TYP_MC2025 = 0x00012025
    TYP_MC2030 = 0x00012030
    TYP_MC2031 = 0x00012031

    TYP_MX2020 = 0x00022020
    TYP_MX2025 = 0x00022025
    TYP_MX2030 = 0x00022030

    # ----- M3i.21xx, M3i.21xx-Exp (8 bit A/D) -----
    TYP_M3I2120 = 0x00052120  # 1x500M
    TYP_M3I2122 = 0x00052122  # 1x500M & 2x250M
    TYP_M3I2130 = 0x00052130  # 1x1G
    TYP_M3I2132 = 0x00052132  # 1x1G & 2x500M

    TYP_M3I2120EXP = 0x00062120  # 1x500M
    TYP_M3I2122EXP = 0x00062122  # 1x500M & 2x250M
    TYP_M3I2130EXP = 0x00062130  # 1x1G
    TYP_M3I2132EXP = 0x00062132  # 1x1G & 2x500M

    # ----- MI.30xx, MC.30xx, MX.30xx -----
    TYP_MI3010 = 0x00003010
    TYP_MI3011 = 0x00003011
    TYP_MI3012 = 0x00003012
    TYP_MI3013 = 0x00003013
    TYP_MI3014 = 0x00003014
    TYP_MI3015 = 0x00003015
    TYP_MI3016 = 0x00003016
    TYP_MI3020 = 0x00003020
    TYP_MI3021 = 0x00003021
    TYP_MI3022 = 0x00003022
    TYP_MI3023 = 0x00003023
    TYP_MI3024 = 0x00003024
    TYP_MI3025 = 0x00003025
    TYP_MI3026 = 0x00003026
    TYP_MI3027 = 0x00003027
    TYP_MI3031 = 0x00003031
    TYP_MI3033 = 0x00003033

    TYP_M2I3010 = 0x00033010
    TYP_M2I3011 = 0x00033011
    TYP_M2I3012 = 0x00033012
    TYP_M2I3013 = 0x00033013
    TYP_M2I3014 = 0x00033014
    TYP_M2I3015 = 0x00033015
    TYP_M2I3016 = 0x00033016
    TYP_M2I3020 = 0x00033020
    TYP_M2I3021 = 0x00033021
    TYP_M2I3022 = 0x00033022
    TYP_M2I3023 = 0x00033023
    TYP_M2I3024 = 0x00033024
    TYP_M2I3025 = 0x00033025
    TYP_M2I3026 = 0x00033026
    TYP_M2I3027 = 0x00033027
    TYP_M2I3031 = 0x00033031
    TYP_M2I3033 = 0x00033033

    TYP_M2I3010EXP = 0x00043010
    TYP_M2I3011EXP = 0x00043011
    TYP_M2I3012EXP = 0x00043012
    TYP_M2I3013EXP = 0x00043013
    TYP_M2I3014EXP = 0x00043014
    TYP_M2I3015EXP = 0x00043015
    TYP_M2I3016EXP = 0x00043016
    TYP_M2I3020EXP = 0x00043020
    TYP_M2I3021EXP = 0x00043021
    TYP_M2I3022EXP = 0x00043022
    TYP_M2I3023EXP = 0x00043023
    TYP_M2I3024EXP = 0x00043024
    TYP_M2I3025EXP = 0x00043025
    TYP_M2I3026EXP = 0x00043026
    TYP_M2I3027EXP = 0x00043027
    TYP_M2I3031EXP = 0x00043031
    TYP_M2I3033EXP = 0x00043033

    TYP_MC3010 = 0x00013010
    TYP_MC3011 = 0x00013011
    TYP_MC3012 = 0x00013012
    TYP_MC3013 = 0x00013013
    TYP_MC3014 = 0x00013014
    TYP_MC3015 = 0x00013015
    TYP_MC3016 = 0x00013016
    TYP_MC3020 = 0x00013020
    TYP_MC3021 = 0x00013021
    TYP_MC3022 = 0x00013022
    TYP_MC3023 = 0x00013023
    TYP_MC3024 = 0x00013024
    TYP_MC3025 = 0x00013025
    TYP_MC3026 = 0x00013026
    TYP_MC3027 = 0x00013027
    TYP_MC3031 = 0x00013031
    TYP_MC3033 = 0x00013033

    TYP_MX3010 = 0x00023010
    TYP_MX3011 = 0x00023011
    TYP_MX3012 = 0x00023012
    TYP_MX3020 = 0x00023020
    TYP_MX3021 = 0x00023021
    TYP_MX3022 = 0x00023022
    TYP_MX3031 = 0x00023031

    # ----- MI.31xx, MC.31xx, MX.31xx -----
    TYP_MI3110 = 0x00003110
    TYP_MI3111 = 0x00003111
    TYP_MI3112 = 0x00003112
    TYP_MI3120 = 0x00003120
    TYP_MI3121 = 0x00003121
    TYP_MI3122 = 0x00003122
    TYP_MI3130 = 0x00003130
    TYP_MI3131 = 0x00003131
    TYP_MI3132 = 0x00003132
    TYP_MI3140 = 0x00003140

    TYP_M2I3110 = 0x00033110
    TYP_M2I3111 = 0x00033111
    TYP_M2I3112 = 0x00033112
    TYP_M2I3120 = 0x00033120
    TYP_M2I3121 = 0x00033121
    TYP_M2I3122 = 0x00033122
    TYP_M2I3130 = 0x00033130
    TYP_M2I3131 = 0x00033131
    TYP_M2I3132 = 0x00033132

    TYP_M2I3110EXP = 0x00043110
    TYP_M2I3111EXP = 0x00043111
    TYP_M2I3112EXP = 0x00043112
    TYP_M2I3120EXP = 0x00043120
    TYP_M2I3121EXP = 0x00043121
    TYP_M2I3122EXP = 0x00043122
    TYP_M2I3130EXP = 0x00043130
    TYP_M2I3131EXP = 0x00043131
    TYP_M2I3132EXP = 0x00043132

    TYP_MC3110 = 0x00013110
    TYP_MC3111 = 0x00013111
    TYP_MC3112 = 0x00013112
    TYP_MC3120 = 0x00013120
    TYP_MC3121 = 0x00013121
    TYP_MC3122 = 0x00013122
    TYP_MC3130 = 0x00013130
    TYP_MC3131 = 0x00013131
    TYP_MC3132 = 0x00013132

    TYP_MX3110 = 0x00023110
    TYP_MX3111 = 0x00023111
    TYP_MX3120 = 0x00023120
    TYP_MX3121 = 0x00023121
    TYP_MX3130 = 0x00023130
    TYP_MX3131 = 0x00023131

    # ----- M3i.32xx, M3i.32xx-Exp (12 bit A/D) -----
    TYP_M3I3220 = 0x00053220  # 1x250M
    TYP_M3I3221 = 0x00053221  # 2x250M
    TYP_M3I3240 = 0x00053240  # 1x500M
    TYP_M3I3242 = 0x00053242  # 1x500M & 2x250M

    TYP_M3I3220EXP = 0x00063220  # 1x250M
    TYP_M3I3221EXP = 0x00063221  # 2x250M
    TYP_M3I3240EXP = 0x00063240  # 1x500M
    TYP_M3I3242EXP = 0x00063242  # 1x500M & 2x250M

    # ----- MI.40xx, MC.40xx, MX.40xx -----
    TYP_MI4020 = 0x00004020
    TYP_MI4021 = 0x00004021
    TYP_MI4022 = 0x00004022
    TYP_MI4030 = 0x00004030
    TYP_MI4031 = 0x00004031
    TYP_MI4032 = 0x00004032

    TYP_M2I4020 = 0x00034020
    TYP_M2I4021 = 0x00034021
    TYP_M2I4022 = 0x00034022
    TYP_M2I4028 = 0x00034028
    TYP_M2I4030 = 0x00034030
    TYP_M2I4031 = 0x00034031
    TYP_M2I4032 = 0x00034032
    TYP_M2I4038 = 0x00034038

    TYP_M2I4020EXP = 0x00044020
    TYP_M2I4021EXP = 0x00044021
    TYP_M2I4022EXP = 0x00044022
    TYP_M2I4028EXP = 0x00044028
    TYP_M2I4030EXP = 0x00044030
    TYP_M2I4031EXP = 0x00044031
    TYP_M2I4032EXP = 0x00044032
    TYP_M2I4038EXP = 0x00044038

    TYP_MC4020 = 0x00014020
    TYP_MC4021 = 0x00014021
    TYP_MC4022 = 0x00014022
    TYP_MC4030 = 0x00014030
    TYP_MC4031 = 0x00014031
    TYP_MC4032 = 0x00014032

    TYP_MX4020 = 0x00024020
    TYP_MX4021 = 0x00024021
    TYP_MX4030 = 0x00024030
    TYP_MX4031 = 0x00024031

    # ----- M3i.41xx, M3i.41xx-Exp (14 bit A/D) -----
    TYP_M3I4110 = 0x00054110  # 1x100M
    TYP_M3I4111 = 0x00054111  # 2x100M
    TYP_M3I4120 = 0x00054120  # 1x250M
    TYP_M3I4121 = 0x00054121  # 2x250M
    TYP_M3I4140 = 0x00054140  # 1x400M
    TYP_M3I4142 = 0x00054142  # 1x400M & 2x250M

    TYP_M3I4110EXP = 0x00064110  # 1x100M
    TYP_M3I4111EXP = 0x00064111  # 2x100M
    TYP_M3I4120EXP = 0x00064120  # 1x250M
    TYP_M3I4121EXP = 0x00064121  # 2x250M
    TYP_M3I4140EXP = 0x00064140  # 1x400M
    TYP_M3I4142EXP = 0x00064142  # 1x400M & 2x250M

    # ----- MI.45xx, MC.45xx, MX.45xx -----
    TYP_MI4520 = 0x00004520
    TYP_MI4521 = 0x00004521
    TYP_MI4530 = 0x00004530
    TYP_MI4531 = 0x00004531
    TYP_MI4540 = 0x00004540
    TYP_MI4541 = 0x00004541

    TYP_M2I4520 = 0x00034520
    TYP_M2I4521 = 0x00034521
    TYP_M2I4530 = 0x00034530
    TYP_M2I4531 = 0x00034531
    TYP_M2I4540 = 0x00034540
    TYP_M2I4541 = 0x00034541

    TYP_MC4520 = 0x00014520
    TYP_MC4521 = 0x00014521
    TYP_MC4530 = 0x00014530
    TYP_MC4531 = 0x00014531
    TYP_MC4540 = 0x00014540
    TYP_MC4541 = 0x00014541

    TYP_MX4520 = 0x00024520
    TYP_MX4530 = 0x00024530
    TYP_MX4540 = 0x00024540

    # ----- MI.46xx, MC.46xx, MX.46xx -----
    TYP_MI4620 = 0x00004620
    TYP_MI4621 = 0x00004621
    TYP_MI4622 = 0x00004622
    TYP_MI4630 = 0x00004630
    TYP_MI4631 = 0x00004631
    TYP_MI4632 = 0x00004632
    TYP_MI4640 = 0x00004640
    TYP_MI4641 = 0x00004641
    TYP_MI4642 = 0x00004642
    TYP_MI4650 = 0x00004650
    TYP_MI4651 = 0x00004651
    TYP_MI4652 = 0x00004652

    TYP_M2I4620 = 0x00034620
    TYP_M2I4621 = 0x00034621
    TYP_M2I4622 = 0x00034622
    TYP_M2I4630 = 0x00034630
    TYP_M2I4631 = 0x00034631
    TYP_M2I4632 = 0x00034632
    TYP_M2I4640 = 0x00034640
    TYP_M2I4641 = 0x00034641
    TYP_M2I4642 = 0x00034642
    TYP_M2I4650 = 0x00034650
    TYP_M2I4651 = 0x00034651
    TYP_M2I4652 = 0x00034652

    TYP_M2I4620EXP = 0x00044620
    TYP_M2I4621EXP = 0x00044621
    TYP_M2I4622EXP = 0x00044622
    TYP_M2I4630EXP = 0x00044630
    TYP_M2I4631EXP = 0x00044631
    TYP_M2I4632EXP = 0x00044632
    TYP_M2I4640EXP = 0x00044640
    TYP_M2I4641EXP = 0x00044641
    TYP_M2I4642EXP = 0x00044642
    TYP_M2I4650EXP = 0x00044650
    TYP_M2I4651EXP = 0x00044651
    TYP_M2I4652EXP = 0x00044652

    TYP_MC4620 = 0x00014620
    TYP_MC4621 = 0x00014621
    TYP_MC4622 = 0x00014622
    TYP_MC4630 = 0x00014630
    TYP_MC4631 = 0x00014631
    TYP_MC4632 = 0x00014632
    TYP_MC4640 = 0x00014640
    TYP_MC4641 = 0x00014641
    TYP_MC4642 = 0x00014642
    TYP_MC4650 = 0x00014650
    TYP_MC4651 = 0x00014651
    TYP_MC4652 = 0x00014652

    TYP_MX4620 = 0x00024620
    TYP_MX4621 = 0x00024621
    TYP_MX4630 = 0x00024630
    TYP_MX4631 = 0x00024631
    TYP_MX4640 = 0x00024640
    TYP_MX4641 = 0x00024641
    TYP_MX4650 = 0x00024650
    TYP_MX4651 = 0x00024651

    # ----- MI.47xx, MC.47xx, MX.47xx -----
    TYP_MI4710 = 0x00004710
    TYP_MI4711 = 0x00004711
    TYP_MI4720 = 0x00004720
    TYP_MI4721 = 0x00004721
    TYP_MI4730 = 0x00004730
    TYP_MI4731 = 0x00004731
    TYP_MI4740 = 0x00004740
    TYP_MI4741 = 0x00004741

    TYP_M2I4710 = 0x00034710
    TYP_M2I4711 = 0x00034711
    TYP_M2I4720 = 0x00034720
    TYP_M2I4721 = 0x00034721
    TYP_M2I4730 = 0x00034730
    TYP_M2I4731 = 0x00034731
    TYP_M2I4740 = 0x00034740
    TYP_M2I4741 = 0x00034741

    TYP_M2I4710EXP = 0x00044710
    TYP_M2I4711EXP = 0x00044711
    TYP_M2I4720EXP = 0x00044720
    TYP_M2I4721EXP = 0x00044721
    TYP_M2I4730EXP = 0x00044730
    TYP_M2I4731EXP = 0x00044731
    TYP_M2I4740EXP = 0x00044740
    TYP_M2I4741EXP = 0x00044741

    TYP_MC4710 = 0x00014710
    TYP_MC4711 = 0x00014711
    TYP_MC4720 = 0x00014720
    TYP_MC4721 = 0x00014721
    TYP_MC4730 = 0x00014730
    TYP_MC4731 = 0x00014731

    TYP_MX4710 = 0x00024710
    TYP_MX4720 = 0x00024720
    TYP_MX4730 = 0x00024730

    # ----- M3i.48xx, M3i.48xx-Exp (16 bit A/D) -----
    TYP_M3I4830 = 0x00054830
    TYP_M3I4831 = 0x00054831
    TYP_M3I4840 = 0x00054840
    TYP_M3I4841 = 0x00054841
    TYP_M3I4860 = 0x00054860
    TYP_M3I4861 = 0x00054861

    TYP_M3I4830EXP = 0x00064830
    TYP_M3I4831EXP = 0x00064831
    TYP_M3I4840EXP = 0x00064840
    TYP_M3I4841EXP = 0x00064841
    TYP_M3I4860EXP = 0x00064860
    TYP_M3I4861EXP = 0x00064861

    # ----- MI.60xx, MC.60xx, MX.60xx -----
    TYP_MI6010 = 0x00006010
    TYP_MI6011 = 0x00006011
    TYP_MI6012 = 0x00006012
    TYP_MI6021 = 0x00006021
    TYP_MI6022 = 0x00006022
    TYP_MI6030 = 0x00006030
    TYP_MI6031 = 0x00006031
    TYP_MI6033 = 0x00006033
    TYP_MI6034 = 0x00006034

    TYP_M2I6010 = 0x00036010
    TYP_M2I6011 = 0x00036011
    TYP_M2I6012 = 0x00036012
    TYP_M2I6021 = 0x00036021
    TYP_M2I6022 = 0x00036022
    TYP_M2I6030 = 0x00036030
    TYP_M2I6031 = 0x00036031
    TYP_M2I6033 = 0x00036033
    TYP_M2I6034 = 0x00036034

    TYP_M2I6010EXP = 0x00046010
    TYP_M2I6011EXP = 0x00046011
    TYP_M2I6012EXP = 0x00046012
    TYP_M2I6021EXP = 0x00046021
    TYP_M2I6022EXP = 0x00046022
    TYP_M2I6030EXP = 0x00046030
    TYP_M2I6031EXP = 0x00046031
    TYP_M2I6033EXP = 0x00046033
    TYP_M2I6034EXP = 0x00046034

    TYP_MC6010 = 0x00016010
    TYP_MC6011 = 0x00016011
    TYP_MC6012 = 0x00016012
    TYP_MC6021 = 0x00016021
    TYP_MC6022 = 0x00016022
    TYP_MC6030 = 0x00016030
    TYP_MC6031 = 0x00016031
    TYP_MC6033 = 0x00016033
    TYP_MC6034 = 0x00016034

    TYP_MX6010 = 0x00026010
    TYP_MX6011 = 0x00026011
    TYP_MX6021 = 0x00026021
    TYP_MX6030 = 0x00026030
    TYP_MX6033 = 0x00026033

    # ----- MI.61xx, MC.61xx, MX.61xx -----
    TYP_MI6105 = 0x00006105
    TYP_MI6110 = 0x00006110
    TYP_MI6111 = 0x00006111

    TYP_M2I6105 = 0x00036105
    TYP_M2I6110 = 0x00036110
    TYP_M2I6111 = 0x00036111

    TYP_M2I6105EXP = 0x00046105
    TYP_M2I6110EXP = 0x00046110
    TYP_M2I6111EXP = 0x00046111

    TYP_MC6110 = 0x00016110
    TYP_MC6111 = 0x00016111

    TYP_MX6110 = 0x00026110

    # ----- MI.70xx, MC.70xx, MX.70xx -----
    TYP_MI7005 = 0x00007005
    TYP_MI7010 = 0x00007010
    TYP_MI7011 = 0x00007011
    TYP_MI7020 = 0x00007020
    TYP_MI7021 = 0x00007021

    TYP_M2I7005 = 0x00037005
    TYP_M2I7010 = 0x00037010
    TYP_M2I7011 = 0x00037011
    TYP_M2I7020 = 0x00037020
    TYP_M2I7021 = 0x00037021

    TYP_M2I7005EXP = 0x00047005
    TYP_M2I7010EXP = 0x00047010
    TYP_M2I7011EXP = 0x00047011
    TYP_M2I7020EXP = 0x00047020
    TYP_M2I7021EXP = 0x00047021

    TYP_MC7005 = 0x00017005
    TYP_MC7010 = 0x00017010
    TYP_MC7011 = 0x00017011
    TYP_MC7020 = 0x00017020
    TYP_MC7021 = 0x00017021

    TYP_MX7005 = 0x00027005
    TYP_MX7010 = 0x00027010
    TYP_MX7011 = 0x00027011

    # ----- MI.72xx, MC.72xx, MX.72xx -----
    TYP_MI7210 = 0x00007210
    TYP_MI7211 = 0x00007211
    TYP_MI7220 = 0x00007220
    TYP_MI7221 = 0x00007221

    TYP_M2I7210 = 0x00037210
    TYP_M2I7211 = 0x00037211
    TYP_M2I7220 = 0x00037220
    TYP_M2I7221 = 0x00037221

    TYP_M2I7210EXP = 0x00047210
    TYP_M2I7211EXP = 0x00047211
    TYP_M2I7220EXP = 0x00047220
    TYP_M2I7221EXP = 0x00047221

    TYP_MC7210 = 0x00017210
    TYP_MC7211 = 0x00017211
    TYP_MC7220 = 0x00017220
    TYP_MC7221 = 0x00017221

    TYP_MX7210 = 0x00027210
    TYP_MX7220 = 0x00027220

    # ***********************************************************************
    # software registers
    # ***********************************************************************

    # ***** PCI Features Bits (MI/MC/MX and prior cards) *********
    PCIBIT_MULTI = 0x00000001
    PCIBIT_DIGITAL = 0x00000002
    PCIBIT_CH0DIGI = 0x00000004
    PCIBIT_EXTSAM = 0x00000008
    PCIBIT_3CHANNEL = 0x00000010
    PCIBIT_GATE = 0x00000020
    PCIBIT_SLAVE = 0x00000040
    PCIBIT_MASTER = 0x00000080
    PCIBIT_DOUBLEMEM = 0x00000100
    PCIBIT_SYNC = 0x00000200
    PCIBIT_TIMESTAMP = 0x00000400
    PCIBIT_STARHUB = 0x00000800
    PCIBIT_CA = 0x00001000
    PCIBIT_XIO = 0x00002000
    PCIBIT_AMPLIFIER = 0x00004000
    PCIBIT_DIFFMODE = 0x00008000

    PCIBIT_ELISA = 0x10000000

    # ***** PCI features starting with M2i card series *****
    SPCM_FEAT_MULTI = 0x00000001  # multiple recording
    SPCM_FEAT_GATE = 0x00000002  # gated sampling
    SPCM_FEAT_DIGITAL = 0x00000004  # additional synchronous digital inputs or outputs
    SPCM_FEAT_TIMESTAMP = 0x00000008  # timestamp
    SPCM_FEAT_STARHUB5 = 0x00000020  # starhub for 5 cards installed (M2i + M2i-Exp)
    SPCM_FEAT_STARHUB4 = 0x00000020  # starhub for 4 cards installed (M3i + M3i-Exp)
    SPCM_FEAT_STARHUB16 = 0x00000040  # starhub for 16 cards installed
    SPCM_FEAT_STARHUB8 = 0x00000040  # starhub for 8 cards installed (M3i + M3i-Exp)
    SPCM_FEAT_ABA = 0x00000080  # ABA mode installed
    SPCM_FEAT_BASEXIO = 0x00000100  # extra I/O on base card installed
    SPCM_FEAT_AMPLIFIER_10V = 0x00000200  # external amplifier for 60/61
    SPCM_FEAT_STARHUBSYSMASTER = 0x00000400  # system starhub master installed
    SPCM_FEAT_DIFFMODE = 0x00000800  # Differential mode installed
    SPCM_FEAT_EXTFW_AVERAGE = (
        0x00010000  # extended firmware : hardware averaging installed
    )
    SPCM_FEAT_CUSTOMMOD_MASK = 0xF0000000  # mask for custom modification code, meaning of code depends on type and customer

    # ***** Error Request *************
    ERRORTEXTLEN = 200
    SPC_LASTERRORTEXT = 999996
    SPC_LASTERRORVALUE = 999997
    SPC_LASTERRORREG = 999998
    SPC_LASTERRORCODE = 999999  # Reading this reset the internal error-memory.

    # ***** Register and Command Structure
    SPC_COMMAND = 0
    SPC_RESET = 0
    SPC_SOFTRESET = 1
    SPC_WRITESETUP = 2
    SPC_START = 10
    SPC_STARTANDWAIT = 11
    SPC_FIFOSTART = 12
    SPC_FIFOWAIT = 13
    SPC_FIFOSTARTNOWAIT = 14
    SPC_FORCETRIGGER = 16
    SPC_STOP = 20
    SPC_FLUSHFIFOBUFFER = 21
    SPC_POWERDOWN = 30
    SPC_SYNCMASTER = 100
    SPC_SYNCTRIGGERMASTER = 101
    SPC_SYNCMASTERFIFO = 102
    SPC_SYNCSLAVE = 110
    SPC_SYNCTRIGGERSLAVE = 111
    SPC_SYNCSLAVEFIFO = 112
    SPC_NOSYNC = 120
    SPC_SYNCSTART = 130
    SPC_SYNCCALCMASTER = 140
    SPC_SYNCCALCMASTERFIFO = 141
    SPC_RELAISON = 200
    SPC_RELAISOFF = 210
    SPC_ADJUSTSTART = 300
    SPC_FIFO_BUFREADY0 = 400
    SPC_FIFO_BUFREADY1 = 401
    SPC_FIFO_BUFREADY2 = 402
    SPC_FIFO_BUFREADY3 = 403
    SPC_FIFO_BUFREADY4 = 404
    SPC_FIFO_BUFREADY5 = 405
    SPC_FIFO_BUFREADY6 = 406
    SPC_FIFO_BUFREADY7 = 407
    SPC_FIFO_BUFREADY8 = 408
    SPC_FIFO_BUFREADY9 = 409
    SPC_FIFO_BUFREADY10 = 410
    SPC_FIFO_BUFREADY11 = 411
    SPC_FIFO_BUFREADY12 = 412
    SPC_FIFO_BUFREADY13 = 413
    SPC_FIFO_BUFREADY14 = 414
    SPC_FIFO_BUFREADY15 = 415
    SPC_FIFO_AUTOBUFSTART = 500
    SPC_FIFO_AUTOBUFEND = 510

    SPC_STATUS = 10
    SPC_RUN = 0
    SPC_TRIGGER = 10
    SPC_READY = 20

    # commands for M2 cards
    SPC_M2CMD = 100  # write a command
    M2CMD_CARD_RESET = 0x00000001  # hardware reset
    M2CMD_CARD_WRITESETUP = 0x00000002  # write setup only
    M2CMD_CARD_START = 0x00000004  # start of card (including writesetup)
    M2CMD_CARD_ENABLETRIGGER = 0x00000008  # enable trigger engine
    M2CMD_CARD_FORCETRIGGER = 0x00000010  # force trigger
    M2CMD_CARD_DISABLETRIGGER = (
        0x00000020  # disable trigger engine again (multi or gate)
    )
    M2CMD_CARD_STOP = 0x00000040  # stop run
    M2CMD_CARD_FLUSHFIFO = 0x00000080  # flush fifos to memory
    M2CMD_CARD_INVALIDATEDATA = 0x00000100  # current data in memory is invalidated, next data transfer start will wait until new data is available

    M2CMD_ALL_STOP = 0x00440060  # stops card and all running transfers

    M2CMD_CARD_WAITPREFULL = 0x00001000  # wait until pretrigger is fu
    M2CMD_CARD_WAITTRIGGER = 0x00002000  # wait for trigger recognition
    M2CMD_CARD_WAITREADY = 0x00004000  # wait for card ready

    M2CMD_DATA_STARTDMA = 0x00010000  # start of DMA transfer for data
    M2CMD_DATA_WAITDMA = 0x00020000  # wait for end of data transfer / next block ready
    M2CMD_DATA_STOPDMA = 0x00040000  # abort the data transfer
    M2CMD_DATA_POLL = 0x00080000  # transfer data using single access and polling

    M2CMD_EXTRA_STARTDMA = (
        0x00100000  # start of DMA transfer for extra (ABA + timestamp) data
    )
    M2CMD_EXTRA_WAITDMA = 0x00200000  # wait for end of extra (ABA + timestamp) data transfer / next block ready
    M2CMD_EXTRA_STOPDMA = 0x00400000  # abort the extra (ABA + timestamp) data transfer
    M2CMD_EXTRA_POLL = 0x00800000  # transfer data using single access and polling

    # status for M2 cards (bitmask)
    SPC_M2STATUS = 110  # read the current status
    M2STAT_NONE = 0x00000000  # status empty
    M2STAT_CARD_PRETRIGGER = 0x00000001  # pretrigger area is fu
    M2STAT_CARD_TRIGGER = 0x00000002  # trigger recognized
    M2STAT_CARD_READY = 0x00000004  # card is ready, run finished

    M2STAT_DATA_BLOCKREADY = 0x00000100  # next data block is available
    M2STAT_DATA_END = 0x00000200  # data transfer has ended
    M2STAT_DATA_OVERRUN = 0x00000400  # FIFO overrun (record) or underrun (replay)
    M2STAT_DATA_ERROR = 0x00000800  # internal error

    M2STAT_EXTRA_BLOCKREADY = (
        0x00001000  # next extra data (ABA and timestamp) block is available
    )
    M2STAT_EXTRA_END = 0x00002000  # extra data (ABA and timestamp) transfer has ended
    M2STAT_EXTRA_OVERRUN = 0x00004000  # FIFO overrun
    M2STAT_EXTRA_ERROR = 0x00008000  # internal error

    M2STAT_INTERNALMASK = 0xFF000000  # mask for internal status signals
    M2STAT_INTERNAL_SYSLOCK = 0x02000000

    # buffer control registers for samples data
    SPC_DATA_AVAIL_USER_LEN = 200  # number of bytes available for user (valid data if READ, free buffer if WRITE)
    SPC_DATA_AVAIL_USER_POS = (
        201  # the current byte position where the available user data starts
    )
    SPC_DATA_AVAIL_CARD_LEN = 202  # number of bytes available for card (free buffer if READ, filled data if WRITE)
    SPC_DATA_OUTBUFSIZE = 209  # output buffer size in samples

    # buffer control registers for extra data (ABA slow data, timestamps)
    SPC_ABA_AVAIL_USER_LEN = 210  # number of bytes available for user (valid data if READ, free buffer if WRITE)
    SPC_ABA_AVAIL_USER_POS = (
        211  # the current byte position where the available user data starts
    )
    SPC_ABA_AVAIL_CARD_LEN = 212  # number of bytes available for card (free buffer if READ, filled data if WRITE)

    SPC_TS_AVAIL_USER_LEN = 220  # number of bytes available for user (valid data if READ, free buffer if WRITE)
    SPC_TS_AVAIL_USER_POS = (
        221  # the current byte position where the available user data starts
    )
    SPC_TS_AVAIL_CARD_LEN = 222  # number of bytes available for card (free buffer if READ, filled data if WRITE)

    # Installation
    SPC_VERSION = 1000
    SPC_ISAADR = 1010
    SPC_INSTMEM = 1020
    SPC_INSTSAMPLERATE = 1030
    SPC_BRDTYP = 1040

    # MI/MC/MX type information (internal use)
    SPC_MIINST_MODULES = 1100
    SPC_MIINST_CHPERMODULE = 1110
    SPC_MIINST_BYTESPERSAMPLE = 1120
    SPC_MIINST_BITSPERSAMPLE = 1125
    SPC_MIINST_MAXADCVALUE = 1126
    SPC_MIINST_MINADCLOCK = 1130
    SPC_MIINST_MAXADCLOCK = 1140
    SPC_MIINST_MINEXTCLOCK = 1145
    SPC_MIINST_MAXEXTCLOCK = 1146
    SPC_MIINST_MINSYNCCLOCK = 1147
    SPC_MIINST_MINEXTREFCLOCK = 1148
    SPC_MIINST_MAXEXTREFCLOCK = 1149
    SPC_MIINST_QUARZ = 1150
    SPC_MIINST_QUARZ2 = 1151
    SPC_MIINST_FLAGS = 1160
    SPC_MIINST_FIFOSUPPORT = 1170
    SPC_MIINST_ISDEMOCARD = 1175

    # Driver information
    SPC_GETDRVVERSION = 1200
    SPC_GETKERNELVERSION = 1210
    SPC_GETDRVTYPE = 1220
    DRVTYP_DOS = 0
    DRVTYP_LINUX32 = 1
    DRVTYP_VXD = 2
    DRVTYP_NTLEGACY = 3
    DRVTYP_WDM32 = 4
    DRVTYP_WDM64 = 5
    DRVTYP_WOW64 = 6
    DRVTYP_LINUX64 = 7
    SPC_GETCOMPATIBILITYVERSION = 1230

    # PCI, CompactPCI and PXI Installation Information
    SPC_PCITYP = 2000

    # ***** available card function types *****
    SPC_FNCTYPE = 2001
    SPCM_TYPE_AI = 0x01
    SPCM_TYPE_AO = 0x02
    SPCM_TYPE_DI = 0x04
    SPCM_TYPE_DO = 0x08
    SPCM_TYPE_DIO = 0x10

    SPC_PCIVERSION = 2010
    SPC_PCIEXTVERSION = 2011
    SPC_PCIMODULEVERSION = 2012
    SPC_PCIMODULEBVERSION = 2013
    SPC_PCIDATE = 2020
    SPC_CALIBDATE = 2025
    SPC_PCISERIALNR = 2030
    SPC_PCISERIALNO = 2030
    SPC_PCIHWBUSNO = 2040
    SPC_PCIHWDEVNO = 2041
    SPC_PCIHWFNCNO = 2042
    SPC_PCIHWSLOTNO = 2043
    SPC_PCISAMPLERATE = 2100
    SPC_PCIMEMSIZE = 2110
    SPC_PCIFEATURES = 2120
    SPC_PCIINFOADR = 2200
    SPC_PCIINTERRUPT = 2300
    SPC_PCIBASEADR0 = 2400
    SPC_PCIBASEADR1 = 2401
    SPC_PCIREGION0 = 2410
    SPC_PCIREGION1 = 2411
    SPC_READTRGLVLCOUNT = 2500
    SPC_READIRCOUNT = 3000
    SPC_READUNIPOLAR0 = 3010
    SPC_READUNIPOLAR1 = 3020
    SPC_READUNIPOLAR2 = 3030
    SPC_READUNIPOLAR3 = 3040
    SPC_READMAXOFFSET = 3100

    SPC_READAIFEATURES = 3101
    SPCM_AI_TERM = 0x00000001  # input termination available
    SPCM_AI_SE = 0x00000002  # single-ended mode available
    SPCM_AI_DIFF = 0x00000004  # differential mode available
    SPCM_AI_OFFSPERCENT = (
        0x00000008  # offset programming is done in percent of input range
    )
    SPCM_AI_OFFSMV = 0x00000010  # offset programming is done in mV absolut
    SPCM_AI_OVERRANGEDETECT = 0x00000020  # overrange detection is programmable
    SPCM_AI_DCCOUPLING = 0x00000040  # DC coupling available
    SPCM_AI_ACCOUPLING = 0x00000080  # AC coupling available
    SPCM_AI_LOWPASS = 0x00000100  # selecteable low pass
    SPCM_AI_AUTOCALOFFS = 0x00001000  # automatic offset calibration in hardware
    SPCM_AI_AUTOCALGAIN = 0x00002000  # automatic gain calibration in hardware
    SPCM_AI_AUTOCALOFFSNOIN = (
        0x00004000  # automatic offset calibration with open inputs
    )
    SPCM_AI_INDIVPULSEWIDTH = 0x00100000  # individual pulsewidth per channel available

    SPC_READAOFEATURES = 3102
    SPCM_AO_SE = 0x00000002  # single-ended mode available
    SPCM_AO_DIFF = 0x00000004  # differential mode available
    SPCM_AO_PROGFILTER = 0x00000008  # programmable filters available
    SPCM_AO_PROGOFFSET = 0x00000010  # programmable offset available
    SPCM_AO_PROGGAIN = 0x00000020  # programmable gain available
    SPCM_AO_PROGSTOPLEVEL = 0x00000040  # programmable stop level available
    SPCM_AO_DOUBLEOUT = 0x00000080  # double out mode available

    SPC_READDIFEATURES = 3103
    SPCM_DI_TERM = 0x00000001  # input termination available
    SPCM_DI_SE = 0x00000002  # single-ended mode available
    SPCM_DI_DIFF = 0x00000004  # differential mode available
    SPCM_DI_INDIVPULSEWIDTH = 0x00100000  # individual pulsewidth per channel available
    SPCM_DI_IOCHANNEL = 0x00200000  # connected with DO channe

    SPC_READDOFEATURES = 3104
    SPCM_DO_SE = 0x00000002  # single-ended mode available
    SPCM_DO_DIFF = 0x00000004  # differential mode available
    SPCM_DO_PROGSTOPLEVEL = 0x00000008  # programmable stop level available
    SPCM_DO_PROGOUTLEVELS = (
        0x00000010  # programmable output levels (low + high) available
    )
    SPCM_DO_ENABLEMASK = 0x00000020  # individual enable mask for each output channe
    SPCM_DO_IOCHANNEL = 0x00200000  # connected with DI channe

    SPC_READCHGROUPING = 3110
    SPC_READAIPATHCOUNT = 3120  # number of available analog input paths
    SPC_READAIPATH = 3121  # the current path for which all the settings are read

    SPC_READRANGECH0_0 = 3200
    SPC_READRANGECH0_1 = 3201
    SPC_READRANGECH0_2 = 3202
    SPC_READRANGECH0_3 = 3203
    SPC_READRANGECH0_4 = 3204
    SPC_READRANGECH0_5 = 3205
    SPC_READRANGECH0_6 = 3206
    SPC_READRANGECH0_7 = 3207
    SPC_READRANGECH0_8 = 3208
    SPC_READRANGECH0_9 = 3209
    SPC_READRANGECH1_0 = 3300
    SPC_READRANGECH1_1 = 3301
    SPC_READRANGECH1_2 = 3302
    SPC_READRANGECH1_3 = 3303
    SPC_READRANGECH1_4 = 3304
    SPC_READRANGECH1_5 = 3305
    SPC_READRANGECH1_6 = 3306
    SPC_READRANGECH1_7 = 3307
    SPC_READRANGECH1_8 = 3308
    SPC_READRANGECH1_9 = 3309
    SPC_READRANGECH2_0 = 3400
    SPC_READRANGECH2_1 = 3401
    SPC_READRANGECH2_2 = 3402
    SPC_READRANGECH2_3 = 3403
    SPC_READRANGECH3_0 = 3500
    SPC_READRANGECH3_1 = 3501
    SPC_READRANGECH3_2 = 3502
    SPC_READRANGECH3_3 = 3503

    SPC_READRANGEMIN0 = 4000
    SPC_READRANGEMIN99 = 4099
    SPC_READRANGEMAX0 = 4100
    SPC_READRANGEMAX99 = 4199
    SPC_READOFFSMIN0 = 4200
    SPC_READOFFSMIN99 = 4299
    SPC_READOFFSMAX0 = 4300
    SPC_READOFFSMAX99 = 4399
    SPC_PCICOUNTER = 9000
    SPC_BUFFERPOS = 9010

    SPC_CARDMODE = 9500  # card modes as listed below
    SPC_AVAILCARDMODES = 9501  # list with available card modes

    # card modes
    SPC_REC_STD_SINGLE = 0x00000001  # singleshot recording to memory
    SPC_REC_STD_MULTI = 0x00000002  # multiple records to memory on each trigger event
    SPC_REC_STD_GATE = 0x00000004  # gated recording to memory on gate signa
    SPC_REC_STD_ABA = (
        0x00000008  # ABA: A slowly to extra FIFO, B to memory on each trigger event
    )
    SPC_REC_STD_AVERAGE = 0x00010000  # multiple records summed to average memory on each trigger event -> stored in on-board memory

    SPC_REC_FIFO_SINGLE = 0x00000010  # singleshot to FIFO on trigger event
    SPC_REC_FIFO_MULTI = 0x00000020  # multiple records to FIFO on each trigger event
    SPC_REC_FIFO_GATE = 0x00000040  # gated sampling to FIFO on gate signa
    SPC_REC_FIFO_ABA = (
        0x00000080  # ABA: A slowly to extra FIFO, B to FIFO on each trigger event
    )
    SPC_REC_FIFO_AVERAGE = 0x00020000  # multiple records summed to average memory on each trigger event -> streamed to host

    SPC_REP_STD_SINGLE = 0x00000100  # single replay from memory on trigger event
    SPC_REP_STD_MULTI = 0x00000200  # multiple replay from memory on each trigger event
    SPC_REP_STD_GATE = 0x00000400  # gated replay from memory on gate signa

    SPC_REP_FIFO_SINGLE = 0x00000800  # single replay from FIFO on trigger event
    SPC_REP_FIFO_MULTI = 0x00001000  # multiple replay from FIFO on each trigger event
    SPC_REP_FIFO_GATE = 0x00002000  # gated replay from FIFO on gate signa

    SPC_REP_STD_CONTINUOUS = (
        0x00004000  # continuous replay started by one trigger event
    )
    SPC_REP_STD_SINGLERESTART = (
        0x00008000  # single replays on every detected trigger event
    )

    # Memory
    SPC_MEMSIZE = 10000
    SPC_SEGMENTSIZE = 10010
    SPC_LOOPS = 10020
    SPC_PRETRIGGER = 10030
    SPC_ABADIVIDER = 10040
    SPC_AVERAGES = 10050
    SPC_POSTTRIGGER = 10100
    SPC_STARTOFFSET = 10200

    # Memory info (depends on mode and channelenable)
    SPC_AVAILMEMSIZE_MIN = 10201
    SPC_AVAILMEMSIZE_MAX = 10202
    SPC_AVAILMEMSIZE_STEP = 10203
    SPC_AVAILPOSTTRIGGER_MIN = 10204
    SPC_AVAILPOSTTRIGGER_MAX = 10205
    SPC_AVAILPOSTTRIGGER_STEP = 10206

    SPC_AVAILABADIVIDER_MIN = 10207
    SPC_AVAILABADIVIDER_MAX = 10208
    SPC_AVAILABADIVIDER_STEP = 10209

    SPC_AVAILLOOPS_MIN = 10210
    SPC_AVAILLOOPS_MAX = 10211
    SPC_AVAILLOOPS_STEP = 10212

    # Channels
    SPC_CHENABLE = 11000
    SPC_CHCOUNT = 11001
    SPC_CHMODACOUNT = 11100
    SPC_CHMODBCOUNT = 11101

    # ----- channel enable flags for A/D and D/A boards (MI/MC/MX series) -----
    #       and all cards on M2i series
    CHANNEL0 = 0x00000001
    CHANNEL1 = 0x00000002
    CHANNEL2 = 0x00000004
    CHANNEL3 = 0x00000008
    CHANNEL4 = 0x00000010
    CHANNEL5 = 0x00000020
    CHANNEL6 = 0x00000040
    CHANNEL7 = 0x00000080
    CHANNEL8 = 0x00000100
    CHANNEL9 = 0x00000200
    CHANNEL10 = 0x00000400
    CHANNEL11 = 0x00000800
    CHANNEL12 = 0x00001000
    CHANNEL13 = 0x00002000
    CHANNEL14 = 0x00004000
    CHANNEL15 = 0x00008000
    CHANNEL16 = 0x00010000
    CHANNEL17 = 0x00020000
    CHANNEL18 = 0x00040000
    CHANNEL19 = 0x00080000
    CHANNEL20 = 0x00100000
    CHANNEL21 = 0x00200000
    CHANNEL22 = 0x00400000
    CHANNEL23 = 0x00800000
    CHANNEL24 = 0x01000000
    CHANNEL25 = 0x02000000
    CHANNEL26 = 0x04000000
    CHANNEL27 = 0x08000000
    CHANNEL28 = 0x10000000
    CHANNEL29 = 0x20000000
    CHANNEL30 = 0x40000000
    CHANNEL31 = 0x80000000
    # CHANNEL32 up to CHANNEL63 are placed in the upper 32 bit of a 64 bit word (M2i only)

    # ----- old digital i/o settings for 16 bit implementation (MI/MC/MX series)  -----
    CH0_8BITMODE = 65536  # for MI.70xx only
    CH0_16BIT = 1
    CH0_32BIT = 3
    CH1_16BIT = 4
    CH1_32BIT = 12

    # ----- new digital i/o settings for 8 bit implementation (MI/MC/MX series) -----
    MOD0_8BIT = 1
    MOD0_16BIT = 3
    MOD0_32BIT = 15
    MOD1_8BIT = 16
    MOD1_16BIT = 48
    MOD1_32BIT = 240

    SPC_CHROUTE0 = 11010
    SPC_CHROUTE1 = 11020

    SPC_BITENABLE = 11030

    # ----- Clock Settings -----
    SPC_SAMPLERATE = 20000
    SPC_SYNCCLOCK = 20005
    SPC_SAMPLERATE2 = 20010
    SPC_SR2 = 20020
    SPC_PLL_ENABLE = 20030
    SPC_CLOCKDIV = 20040
    SPC_INTCLOCKDIV = 20041
    SPC_PLL_R = 20060
    SPC_PLL_F = 20061
    SPC_PLL_S = 20062
    SPC_PLL_DIV = 20063
    SPC_EXTERNALCLOCK = 20100
    SPC_EXTERNOUT = 20110
    SPC_CLOCKOUT = 20110
    SPC_CLOCK50OHM = 20120
    SPC_CLOCK110OHM = 20120
    SPC_EXTERNRANGE = 20130
    SPC_EXTRANGESHDIRECT = 20131
    EXRANGE_NONE = 0
    EXRANGE_NOPLL = 1
    EXRANGE_SINGLE = 2
    EXRANGE_BURST_S = 4
    EXRANGE_BURST_M = 8
    EXRANGE_BURST_L = 16
    EXRANGE_BURST_XL = 32
    EXRANGE_LOW = 64
    EXRANGE_HIGH = 128
    EXRANGE_LOW_DPS = 256  # digital phase synchronization
    SPC_REFERENCECLOCK = 20140
    REFCLOCK_PXI = -1

    # ----- new clock registers starting with M2i cards -----
    SPC_CLOCKMODE = 20200  # clock mode as listed below
    SPC_AVAILCLOCKMODES = 20201  # returns all available clock modes
    SPC_CM_INTPLL = 0x00000001  # use internal PLL
    SPC_CM_QUARTZ1 = 0x00000002  # use plain quartz1 (with divider)
    SPC_CM_QUARTZ2 = 0x00000004  # use plain quartz2 (with divider)
    SPC_CM_EXTERNAL = 0x00000008  # use external clock directly
    SPC_CM_EXTDIVIDER = 0x00000010  # use external clock with programmed divider
    SPC_CM_EXTREFCLOCK = (
        0x00000020  # external reference clock fed in (defined with SPC_REFERENCECLOCK)
    )
    SPC_CM_PXIREFCLOCK = 0x00000040  # PXI reference clock
    SPC_CM_SHDIRECT = 0x00000080  # Star-hub direct clock (not synchronised)
    SPC_CM_QUARTZ2_DIRSYNC = 0x00000100  # use plain quartz2 (with divider) and put the Q2 clock on the star-hub module

    SPC_CLOCK_READFEATURES = 20205
    SPCM_CKFEAT_TERM = 0x00000001
    SPCM_CKFEAT_HIGHIMP = 0x00000002
    SPCM_CKFEAT_DCCOUPLING = 0x00000004
    SPCM_CKFEAT_ACCOUPLING = 0x00000008
    SPCM_CKFEAT_SE = 0x00000010
    SPCM_CKFEAT_DIFF = 0x00000020
    SPCM_CKFEAT_LEVELPROG = 0x00000100

    # ----- internal use only! -----
    SPC_CM_SYNCINT = 0x01000000
    SPC_CM_SYNCEXT = 0x02000000
    SPC_BURSTSYSCLOCKMODE = 20210
    SPC_SYNCMASTERSYSCLOCKMODE = 20211

    # mux definitions for channel routing
    SPC_CHANNELMUXINFO = 20300
    SPCM_MUX_NONE = 0x00000000  # nothing is interlaced
    SPCM_MUX_MUXONMOD = 0x00000001  # data on module is multiplexed, only one channel can have full speed
    SPCM_MUX_INVERTCLKONMOD = (
        0x00000002  # two channels on one module run with inverted clock
    )
    SPCM_MUX_DLY = 0x00000003  # delay cable between modules, one channel can have full interlace speed
    SPCM_MUX_DLYANDMUXONMOD = (
        0x00000004  # delay cable between modules and multplexing on module
    )
    SPCM_MUX_MUXBETWEENMODS = 0x00000005  # multiplexed between modules (fastest sampling rate only with one module)

    # ----- In/Out Range -----
    SPC_OFFS0 = 30000
    SPC_AMP0 = 30010
    SPC_ACDC0 = 30020
    SPC_50OHM0 = 30030
    SPC_DIFF0 = 30040
    SPC_DOUBLEOUT0 = 30041
    SPC_DIGITAL0 = 30050
    SPC_110OHM0 = 30060
    SPC_110OHM0L = 30060
    SPC_INOUT0 = 30070
    SPC_FILTER0 = 30080
    SPC_BANKSWITCH0 = 30081
    SPC_PATH0 = 30090

    SPC_OFFS1 = 30100
    SPC_AMP1 = 30110
    SPC_ACDC1 = 30120
    SPC_50OHM1 = 30130
    SPC_DIFF1 = 30140
    SPC_DOUBLEOUT1 = 30141
    SPC_DIGITAL1 = 30150
    SPC_110OHM1 = 30160
    SPC_110OHM0H = 30160
    SPC_INOUT1 = 30170
    SPC_FILTER1 = 30180
    SPC_BANKSWITCH1 = 30181
    SPC_PATH1 = 30190

    SPC_OFFS2 = 30200
    SPC_AMP2 = 30210
    SPC_ACDC2 = 30220
    SPC_50OHM2 = 30230
    SPC_DIFF2 = 30240
    SPC_DOUBLEOUT2 = 30241
    SPC_110OHM2 = 30260
    SPC_110OHM1L = 30260
    SPC_INOUT2 = 30270
    SPC_FILTER2 = 30280
    SPC_BANKSWITCH2 = 30281
    SPC_PATH2 = 30290

    SPC_OFFS3 = 30300
    SPC_AMP3 = 30310
    SPC_ACDC3 = 30320
    SPC_50OHM3 = 30330
    SPC_DIFF3 = 30340
    SPC_DOUBLEOUT3 = 30341
    SPC_110OHM3 = 30360
    SPC_110OHM1H = 30360
    SPC_INOUT3 = 30370
    SPC_FILTER3 = 30380
    SPC_BANKSWITCH3 = 30381
    SPC_PATH3 = 30390

    SPC_OFFS4 = 30400
    SPC_AMP4 = 30410
    SPC_ACDC4 = 30420
    SPC_50OHM4 = 30430
    SPC_DIFF4 = 30440
    SPC_PATH4 = 30490

    SPC_OFFS5 = 30500
    SPC_AMP5 = 30510
    SPC_ACDC5 = 30520
    SPC_50OHM5 = 30530
    SPC_DIFF5 = 30540
    SPC_PATH5 = 30590

    SPC_OFFS6 = 30600
    SPC_AMP6 = 30610
    SPC_ACDC6 = 30620
    SPC_50OHM6 = 30630
    SPC_DIFF6 = 30640
    SPC_PATH6 = 30690

    SPC_OFFS7 = 30700
    SPC_AMP7 = 30710
    SPC_ACDC7 = 30720
    SPC_50OHM7 = 30730
    SPC_DIFF7 = 30740
    SPC_PATH7 = 30790

    SPC_OFFS8 = 30800
    SPC_AMP8 = 30810
    SPC_ACDC8 = 30820
    SPC_50OHM8 = 30830
    SPC_DIFF8 = 30840
    SPC_PATH8 = 30890

    SPC_OFFS9 = 30900
    SPC_AMP9 = 30910
    SPC_ACDC9 = 30920
    SPC_50OHM9 = 30930
    SPC_DIFF9 = 30940
    SPC_PATH9 = 30990

    SPC_OFFS10 = 31000
    SPC_AMP10 = 31010
    SPC_ACDC10 = 31020
    SPC_50OHM10 = 31030
    SPC_DIFF10 = 31040
    SPC_PATH10 = 31090

    SPC_OFFS11 = 31100
    SPC_AMP11 = 31110
    SPC_ACDC11 = 31120
    SPC_50OHM11 = 31130
    SPC_DIFF11 = 31140
    SPC_PATH11 = 31190

    SPC_OFFS12 = 31200
    SPC_AMP12 = 31210
    SPC_ACDC12 = 31220
    SPC_50OHM12 = 31230
    SPC_DIFF12 = 31240
    SPC_PATH12 = 31290

    SPC_OFFS13 = 31300
    SPC_AMP13 = 31310
    SPC_ACDC13 = 31320
    SPC_50OHM13 = 31330
    SPC_DIFF13 = 31340
    SPC_PATH13 = 31390

    SPC_OFFS14 = 31400
    SPC_AMP14 = 31410
    SPC_ACDC14 = 31420
    SPC_50OHM14 = 31430
    SPC_DIFF14 = 31440
    SPC_PATH14 = 31490

    SPC_OFFS15 = 31500
    SPC_AMP15 = 31510
    SPC_ACDC15 = 31520
    SPC_50OHM15 = 31530
    SPC_DIFF15 = 31540
    SPC_PATH15 = 31590

    SPC_110OHMTRIGGER = 30400
    SPC_110OHMCLOCK = 30410

    AMP_BI200 = 200
    AMP_BI500 = 500
    AMP_BI1000 = 1000
    AMP_BI2000 = 2000
    AMP_BI2500 = 2500
    AMP_BI4000 = 4000
    AMP_BI5000 = 5000
    AMP_BI10000 = 10000
    AMP_UNI400 = 100400
    AMP_UNI1000 = 101000
    AMP_UNI2000 = 102000

    # ----- Trigger Settings -----
    SPC_TRIGGERMODE = 40000
    SPC_TRIG_OUTPUT = 40100
    SPC_TRIGGEROUT = 40100
    SPC_TRIG_TERM = 40110
    SPC_TRIG_TERM0 = 40110
    SPC_TRIGGER50OHM = 40110
    SPC_TRIGGER110OHM0 = 40110
    SPC_TRIG_TERM1 = 40111
    SPC_TRIGGER110OHM1 = 40111
    SPC_TRIG_EXT0_ACDC = 40120
    SPC_TRIG_EXT1_ACDC = 40121
    SPC_TRIG_EXT2_ACDC = 40122

    SPC_TRIGGERMODE0 = 40200
    SPC_TRIGGERMODE1 = 40201
    SPC_TRIGGERMODE2 = 40202
    SPC_TRIGGERMODE3 = 40203
    SPC_TRIGGERMODE4 = 40204
    SPC_TRIGGERMODE5 = 40205
    SPC_TRIGGERMODE6 = 40206
    SPC_TRIGGERMODE7 = 40207
    SPC_TRIGGERMODE8 = 40208
    SPC_TRIGGERMODE9 = 40209
    SPC_TRIGGERMODE10 = 40210
    SPC_TRIGGERMODE11 = 40211
    SPC_TRIGGERMODE12 = 40212
    SPC_TRIGGERMODE13 = 40213
    SPC_TRIGGERMODE14 = 40214
    SPC_TRIGGERMODE15 = 40215

    TM_SOFTWARE = 0
    TM_NOTRIGGER = 10
    TM_CHXPOS = 10000
    TM_CHXPOS_LP = 10001
    TM_CHXPOS_SP = 10002
    TM_CHXPOS_GS = 10003
    TM_CHXPOS_SS = 10004
    TM_CHXNEG = 10010
    TM_CHXNEG_LP = 10011
    TM_CHXNEG_SP = 10012
    TM_CHXNEG_GS = 10013
    TM_CHXNEG_SS = 10014
    TM_CHXOFF = 10020
    TM_CHXBOTH = 10030
    TM_CHXWINENTER = 10040
    TM_CHXWINENTER_LP = 10041
    TM_CHXWINENTER_SP = 10042
    TM_CHXWINLEAVE = 10050
    TM_CHXWINLEAVE_LP = 10051
    TM_CHXWINLEAVE_SP = 10052

    TM_CH0POS = 10000
    TM_CH0NEG = 10010
    TM_CH0OFF = 10020
    TM_CH0BOTH = 10030
    TM_CH1POS = 10100
    TM_CH1NEG = 10110
    TM_CH1OFF = 10120
    TM_CH1BOTH = 10130
    TM_CH2POS = 10200
    TM_CH2NEG = 10210
    TM_CH2OFF = 10220
    TM_CH2BOTH = 10230
    TM_CH3POS = 10300
    TM_CH3NEG = 10310
    TM_CH3OFF = 10320
    TM_CH3BOTH = 10330

    TM_TTLPOS = 20000
    TM_TTLHIGH_LP = 20001
    TM_TTLHIGH_SP = 20002
    TM_TTLNEG = 20010
    TM_TTLLOW_LP = 20011
    TM_TTLLOW_SP = 20012
    TM_TTL = 20020
    TM_TTLBOTH = 20030
    TM_TTLBOTH_LP = 20031
    TM_TTLBOTH_SP = 20032
    TM_CHANNEL = 20040
    TM_PATTERN = 21000
    TM_PATTERN_LP = 21001
    TM_PATTERN_SP = 21002
    TM_PATTERNANDEDGE = 22000
    TM_PATTERNANDEDGE_LP = 22001
    TM_PATTERNANDEDGE_SP = 22002
    TM_GATELOW = 30000
    TM_GATEHIGH = 30010
    TM_GATEPATTERN = 30020
    TM_CHOR = 35000
    TM_CHAND = 35010

    SPC_PXITRGOUT = 40300
    PTO_OFF = 0
    PTO_LINE0 = 1
    PTO_LINE1 = 2
    PTO_LINE2 = 3
    PTO_LINE3 = 4
    PTO_LINE4 = 5
    PTO_LINE5 = 6
    PTO_LINE6 = 7
    PTO_LINE7 = 8
    PTO_LINESTAR = 9
    SPC_PXITRGOUT_AVAILABLE = 40301  # bitmap register

    SPC_PXITRGIN = 40310  # bitmap register
    PTI_OFF = 0
    PTI_LINE0 = 1
    PTI_LINE1 = 2
    PTI_LINE2 = 4
    PTI_LINE3 = 8
    PTI_LINE4 = 16
    PTI_LINE5 = 32
    PTI_LINE6 = 64
    PTI_LINE7 = 128
    PTI_LINESTAR = 256
    SPC_PXITRGIN_AVAILABLE = 40311  # bitmap register

    # new registers of M2i driver
    SPC_TRIG_AVAILORMASK = 40400
    SPC_TRIG_ORMASK = 40410
    SPC_TRIG_AVAILANDMASK = 40420
    SPC_TRIG_ANDMASK = 40430
    SPC_TMASK_NONE = 0x00000000
    SPC_TMASK_SOFTWARE = 0x00000001
    SPC_TMASK_EXT0 = 0x00000002
    SPC_TMASK_EXT1 = 0x00000004
    SPC_TMASK_EXT2 = 0x00000008
    SPC_TMASK_XIO0 = 0x00000100
    SPC_TMASK_XIO1 = 0x00000200
    SPC_TMASK_XIO2 = 0x00000400
    SPC_TMASK_XIO3 = 0x00000800
    SPC_TMASK_XIO4 = 0x00001000
    SPC_TMASK_XIO5 = 0x00002000
    SPC_TMASK_XIO6 = 0x00004000
    SPC_TMASK_XIO7 = 0x00008000
    SPC_TMASK_PXI0 = 0x00100000
    SPC_TMASK_PXI1 = 0x00200000
    SPC_TMASK_PXI2 = 0x00400000
    SPC_TMASK_PXI3 = 0x00800000
    SPC_TMASK_PXI4 = 0x01000000
    SPC_TMASK_PXI5 = 0x02000000
    SPC_TMASK_PXI6 = 0x04000000
    SPC_TMASK_PXI7 = 0x08000000
    SPC_TMASK_PXISTAR = 0x80000000

    SPC_TRIG_CH_AVAILORMASK0 = 40450
    SPC_TRIG_CH_AVAILORMASK1 = 40451
    SPC_TRIG_CH_ORMASK0 = 40460
    SPC_TRIG_CH_ORMASK1 = 40461
    SPC_TRIG_CH_AVAILANDMASK0 = 40470
    SPC_TRIG_CH_AVAILANDMASK1 = 40471
    SPC_TRIG_CH_ANDMASK0 = 40480
    SPC_TRIG_CH_ANDMASK1 = 40481
    SPC_TMASK0_NONE = 0x00000000
    SPC_TMASK0_CH0 = 0x00000001
    SPC_TMASK0_CH1 = 0x00000002
    SPC_TMASK0_CH2 = 0x00000004
    SPC_TMASK0_CH3 = 0x00000008
    SPC_TMASK0_CH4 = 0x00000010
    SPC_TMASK0_CH5 = 0x00000020
    SPC_TMASK0_CH6 = 0x00000040
    SPC_TMASK0_CH7 = 0x00000080
    SPC_TMASK0_CH8 = 0x00000100
    SPC_TMASK0_CH9 = 0x00000200
    SPC_TMASK0_CH10 = 0x00000400
    SPC_TMASK0_CH11 = 0x00000800
    SPC_TMASK0_CH12 = 0x00001000
    SPC_TMASK0_CH13 = 0x00002000
    SPC_TMASK0_CH14 = 0x00004000
    SPC_TMASK0_CH15 = 0x00008000
    SPC_TMASK0_CH16 = 0x00010000
    SPC_TMASK0_CH17 = 0x00020000
    SPC_TMASK0_CH18 = 0x00040000
    SPC_TMASK0_CH19 = 0x00080000
    SPC_TMASK0_CH20 = 0x00100000
    SPC_TMASK0_CH21 = 0x00200000
    SPC_TMASK0_CH22 = 0x00400000
    SPC_TMASK0_CH23 = 0x00800000
    SPC_TMASK0_CH24 = 0x01000000
    SPC_TMASK0_CH25 = 0x02000000
    SPC_TMASK0_CH26 = 0x04000000
    SPC_TMASK0_CH27 = 0x08000000
    SPC_TMASK0_CH28 = 0x10000000
    SPC_TMASK0_CH29 = 0x20000000
    SPC_TMASK0_CH30 = 0x40000000
    SPC_TMASK0_CH31 = 0x80000000

    SPC_TMASK1_NONE = 0x00000000
    SPC_TMASK1_CH32 = 0x00000001
    SPC_TMASK1_CH33 = 0x00000002
    SPC_TMASK1_CH34 = 0x00000004
    SPC_TMASK1_CH35 = 0x00000008
    SPC_TMASK1_CH36 = 0x00000010
    SPC_TMASK1_CH37 = 0x00000020
    SPC_TMASK1_CH38 = 0x00000040
    SPC_TMASK1_CH39 = 0x00000080
    SPC_TMASK1_CH40 = 0x00000100
    SPC_TMASK1_CH41 = 0x00000200
    SPC_TMASK1_CH42 = 0x00000400
    SPC_TMASK1_CH43 = 0x00000800
    SPC_TMASK1_CH44 = 0x00001000
    SPC_TMASK1_CH45 = 0x00002000
    SPC_TMASK1_CH46 = 0x00004000
    SPC_TMASK1_CH47 = 0x00008000
    SPC_TMASK1_CH48 = 0x00010000
    SPC_TMASK1_CH49 = 0x00020000
    SPC_TMASK1_CH50 = 0x00040000
    SPC_TMASK1_CH51 = 0x00080000
    SPC_TMASK1_CH52 = 0x00100000
    SPC_TMASK1_CH53 = 0x00200000
    SPC_TMASK1_CH54 = 0x00400000
    SPC_TMASK1_CH55 = 0x00800000
    SPC_TMASK1_CH56 = 0x01000000
    SPC_TMASK1_CH57 = 0x02000000
    SPC_TMASK1_CH58 = 0x04000000
    SPC_TMASK1_CH59 = 0x08000000
    SPC_TMASK1_CH60 = 0x10000000
    SPC_TMASK1_CH61 = 0x20000000
    SPC_TMASK1_CH62 = 0x40000000
    SPC_TMASK1_CH63 = 0x80000000

    SPC_TRIG_EXT_AVAILMODES = 40500
    SPC_TRIG_EXT0_AVAILMODES = 40500
    SPC_TRIG_EXT1_AVAILMODES = 40501
    SPC_TRIG_EXT2_AVAILMODES = 40502
    SPC_TRIG_EXT0_AVAILMODESOR = 40503
    SPC_TRIG_EXT1_AVAILMODESOR = 40504
    SPC_TRIG_EXT2_AVAILMODESOR = 40505
    SPC_TRIG_EXT0_AVAILMODESAND = 40506
    SPC_TRIG_EXT1_AVAILMODESAND = 40507
    SPC_TRIG_EXT2_AVAILMODESAND = 40508
    SPC_TRIG_EXT0_MODE = 40510
    SPC_TRIG_EXT1_MODE = 40511
    SPC_TRIG_EXT2_MODE = 40512

    SPC_TRIG_EXT0_READFEATURES = 40520
    SPC_TRIG_EXT1_READFEATURES = 40521
    SPC_TRIG_EXT2_READFEATURES = 40522
    SPCM_TRFEAT_TERM = 0x00000001
    SPCM_TRFEAT_HIGHIMP = 0x00000002
    SPCM_TRFEAT_DCCOUPLING = 0x00000004
    SPCM_TRFEAT_ACCOUPLING = 0x00000008
    SPCM_TRFEAT_SE = 0x00000010
    SPCM_TRFEAT_DIFF = 0x00000020
    SPCM_TRFEAT_LEVELPROG = 0x00000100

    SPC_TRIG_XIO_AVAILMODES = 40550
    SPC_TRIG_XIO_AVAILMODESOR = 40551
    SPC_TRIG_XIO_AVAILMODESAND = 40552
    SPC_TRIG_XIO0_MODE = 40560
    SPC_TRIG_XIO1_MODE = 40561
    SPC_TM_MODEMASK = 0x00FFFFFF
    SPC_TM_NONE = 0x00000000
    SPC_TM_POS = 0x00000001
    SPC_TM_NEG = 0x00000002
    SPC_TM_BOTH = 0x00000004
    SPC_TM_HIGH = 0x00000008
    SPC_TM_LOW = 0x00000010
    SPC_TM_WINENTER = 0x00000020
    SPC_TM_WINLEAVE = 0x00000040
    SPC_TM_INWIN = 0x00000080
    SPC_TM_OUTSIDEWIN = 0x00000100
    SPC_TM_SPIKE = 0x00000200
    SPC_TM_PATTERN = 0x00000400
    SPC_TM_STEEPPOS = 0x00000800
    SPC_TM_STEEPNEG = 0x00001000
    SPC_TM_EXTRAMASK = 0xFF000000
    SPC_TM_REARM = 0x01000000
    SPC_TM_PW_SMALLER = 0x02000000
    SPC_TM_PW_GREATER = 0x04000000
    SPC_TM_DOUBLEEDGE = 0x08000000

    SPC_TRIG_PATTERN_AVAILMODES = 40580
    SPC_TRIG_PATTERN_MODE = 40590

    SPC_TRIG_CH_AVAILMODES = 40600
    SPC_TRIG_CH_AVAILMODESOR = 40601
    SPC_TRIG_CH_AVAILMODESAND = 40602
    SPC_TRIG_CH0_MODE = 40610
    SPC_TRIG_CH1_MODE = 40611
    SPC_TRIG_CH2_MODE = 40612
    SPC_TRIG_CH3_MODE = 40613
    SPC_TRIG_CH4_MODE = 40614
    SPC_TRIG_CH5_MODE = 40615
    SPC_TRIG_CH6_MODE = 40616
    SPC_TRIG_CH7_MODE = 40617
    SPC_TRIG_CH8_MODE = 40618
    SPC_TRIG_CH9_MODE = 40619
    SPC_TRIG_CH10_MODE = 40620
    SPC_TRIG_CH11_MODE = 40621
    SPC_TRIG_CH12_MODE = 40622
    SPC_TRIG_CH13_MODE = 40623
    SPC_TRIG_CH14_MODE = 40624
    SPC_TRIG_CH15_MODE = 40625
    SPC_TRIG_CH16_MODE = 40626
    SPC_TRIG_CH17_MODE = 40627
    SPC_TRIG_CH18_MODE = 40628
    SPC_TRIG_CH19_MODE = 40629
    SPC_TRIG_CH20_MODE = 40630
    SPC_TRIG_CH21_MODE = 40631
    SPC_TRIG_CH22_MODE = 40632
    SPC_TRIG_CH23_MODE = 40633
    SPC_TRIG_CH24_MODE = 40634
    SPC_TRIG_CH25_MODE = 40635
    SPC_TRIG_CH26_MODE = 40636
    SPC_TRIG_CH27_MODE = 40637
    SPC_TRIG_CH28_MODE = 40638
    SPC_TRIG_CH29_MODE = 40639
    SPC_TRIG_CH30_MODE = 40640
    SPC_TRIG_CH31_MODE = 40641

    SPC_TRIG_CH32_MODE = 40642
    SPC_TRIG_CH33_MODE = 40643
    SPC_TRIG_CH34_MODE = 40644
    SPC_TRIG_CH35_MODE = 40645
    SPC_TRIG_CH36_MODE = 40646
    SPC_TRIG_CH37_MODE = 40647
    SPC_TRIG_CH38_MODE = 40648
    SPC_TRIG_CH39_MODE = 40649
    SPC_TRIG_CH40_MODE = 40650
    SPC_TRIG_CH41_MODE = 40651
    SPC_TRIG_CH42_MODE = 40652
    SPC_TRIG_CH43_MODE = 40653
    SPC_TRIG_CH44_MODE = 40654
    SPC_TRIG_CH45_MODE = 40655
    SPC_TRIG_CH46_MODE = 40656
    SPC_TRIG_CH47_MODE = 40657
    SPC_TRIG_CH48_MODE = 40658
    SPC_TRIG_CH49_MODE = 40659
    SPC_TRIG_CH50_MODE = 40660
    SPC_TRIG_CH51_MODE = 40661
    SPC_TRIG_CH52_MODE = 40662
    SPC_TRIG_CH53_MODE = 40663
    SPC_TRIG_CH54_MODE = 40664
    SPC_TRIG_CH55_MODE = 40665
    SPC_TRIG_CH56_MODE = 40666
    SPC_TRIG_CH57_MODE = 40667
    SPC_TRIG_CH58_MODE = 40668
    SPC_TRIG_CH59_MODE = 40669
    SPC_TRIG_CH60_MODE = 40670
    SPC_TRIG_CH61_MODE = 40671
    SPC_TRIG_CH62_MODE = 40672
    SPC_TRIG_CH63_MODE = 40673

    SPC_TRIG_AVAILDELAY = 40800
    SPC_TRIG_AVAILDELAY_STEP = 40801
    SPC_TRIG_DELAY = 40810

    SPC_SINGLESHOT = 41000
    SPC_OUTONTRIGGER = 41100
    SPC_RESTARTCONT = 41200
    SPC_SINGLERESTART = 41300

    SPC_TRIGGERLEVEL = 42000
    SPC_TRIGGERLEVEL0 = 42000
    SPC_TRIGGERLEVEL1 = 42001
    SPC_TRIGGERLEVEL2 = 42002
    SPC_TRIGGERLEVEL3 = 42003
    SPC_TRIGGERLEVEL4 = 42004
    SPC_TRIGGERLEVEL5 = 42005
    SPC_TRIGGERLEVEL6 = 42006
    SPC_TRIGGERLEVEL7 = 42007
    SPC_TRIGGERLEVEL8 = 42008
    SPC_TRIGGERLEVEL9 = 42009
    SPC_TRIGGERLEVEL10 = 42010
    SPC_TRIGGERLEVEL11 = 42011
    SPC_TRIGGERLEVEL12 = 42012
    SPC_TRIGGERLEVEL13 = 42013
    SPC_TRIGGERLEVEL14 = 42014
    SPC_TRIGGERLEVEL15 = 42015

    SPC_AVAILHIGHLEVEL_MIN = 41997
    SPC_AVAILHIGHLEVEL_MAX = 41998
    SPC_AVAILHIGHLEVEL_STEP = 41999

    SPC_HIGHLEVEL0 = 42000
    SPC_HIGHLEVEL1 = 42001
    SPC_HIGHLEVEL2 = 42002
    SPC_HIGHLEVEL3 = 42003
    SPC_HIGHLEVEL4 = 42004
    SPC_HIGHLEVEL5 = 42005
    SPC_HIGHLEVEL6 = 42006
    SPC_HIGHLEVEL7 = 42007
    SPC_HIGHLEVEL8 = 42008
    SPC_HIGHLEVEL9 = 42009
    SPC_HIGHLEVEL10 = 42010
    SPC_HIGHLEVEL11 = 42011
    SPC_HIGHLEVEL12 = 42012
    SPC_HIGHLEVEL13 = 42013
    SPC_HIGHLEVEL14 = 42014
    SPC_HIGHLEVEL15 = 42015

    SPC_AVAILLOWLEVEL_MIN = 42097
    SPC_AVAILLOWLEVEL_MAX = 42098
    SPC_AVAILLOWLEVEL_STEP = 42099

    SPC_LOWLEVEL0 = 42100
    SPC_LOWLEVEL1 = 42101
    SPC_LOWLEVEL2 = 42102
    SPC_LOWLEVEL3 = 42103
    SPC_LOWLEVEL4 = 42104
    SPC_LOWLEVEL5 = 42105
    SPC_LOWLEVEL6 = 42106
    SPC_LOWLEVEL7 = 42107
    SPC_LOWLEVEL8 = 42108
    SPC_LOWLEVEL9 = 42109
    SPC_LOWLEVEL10 = 42110
    SPC_LOWLEVEL11 = 42111
    SPC_LOWLEVEL12 = 42112
    SPC_LOWLEVEL13 = 42113
    SPC_LOWLEVEL14 = 42114
    SPC_LOWLEVEL15 = 42115

    SPC_TRIG_CH0_LEVEL0 = 42200
    SPC_TRIG_CH1_LEVEL0 = 42201
    SPC_TRIG_CH2_LEVEL0 = 42202
    SPC_TRIG_CH3_LEVEL0 = 42203
    SPC_TRIG_CH4_LEVEL0 = 42204
    SPC_TRIG_CH5_LEVEL0 = 42205
    SPC_TRIG_CH6_LEVEL0 = 42206
    SPC_TRIG_CH7_LEVEL0 = 42207
    SPC_TRIG_CH8_LEVEL0 = 42208
    SPC_TRIG_CH9_LEVEL0 = 42209
    SPC_TRIG_CH10_LEVEL0 = 42210
    SPC_TRIG_CH11_LEVEL0 = 42211
    SPC_TRIG_CH12_LEVEL0 = 42212
    SPC_TRIG_CH13_LEVEL0 = 42213
    SPC_TRIG_CH14_LEVEL0 = 42214
    SPC_TRIG_CH15_LEVEL0 = 42215

    SPC_TRIG_CH0_LEVEL1 = 42300
    SPC_TRIG_CH1_LEVEL1 = 42301
    SPC_TRIG_CH2_LEVEL1 = 42302
    SPC_TRIG_CH3_LEVEL1 = 42303
    SPC_TRIG_CH4_LEVEL1 = 42304
    SPC_TRIG_CH5_LEVEL1 = 42305
    SPC_TRIG_CH6_LEVEL1 = 42306
    SPC_TRIG_CH7_LEVEL1 = 42307
    SPC_TRIG_CH8_LEVEL1 = 42308
    SPC_TRIG_CH9_LEVEL1 = 42309
    SPC_TRIG_CH10_LEVEL1 = 42310
    SPC_TRIG_CH11_LEVEL1 = 42311
    SPC_TRIG_CH12_LEVEL1 = 42312
    SPC_TRIG_CH13_LEVEL1 = 42313
    SPC_TRIG_CH14_LEVEL1 = 42314
    SPC_TRIG_CH15_LEVEL1 = 42315

    SPC_TRIG_EXT0_LEVEL0 = 42320
    SPC_TRIG_EXT1_LEVEL0 = 42321
    SPC_TRIG_EXT2_LEVEL0 = 42322

    SPC_TRIG_EXT0_LEVEL1 = 42330
    SPC_TRIG_EXT1_LEVEL1 = 42331
    SPC_TRIG_EXT2_LEVEL1 = 42332

    SPC_TRIG_EXT_AVAIL0_MIN = 42340
    SPC_TRIG_EXT_AVAIL0_MAX = 42341
    SPC_TRIG_EXT_AVAIL0_STEP = 42342

    SPC_TRIG_EXT_AVAIL1_MIN = 42345
    SPC_TRIG_EXT_AVAIL1_MAX = 42346
    SPC_TRIG_EXT_AVAIL1_STEP = 42347

    SPC_TRIGGERPATTERN = 43000
    SPC_TRIGGERPATTERN0 = 43000
    SPC_TRIGGERPATTERN1 = 43001
    SPC_TRIGGERMASK = 43100
    SPC_TRIGGERMASK0 = 43100
    SPC_TRIGGERMASK1 = 43101

    SPC_PULSEWIDTH = 44000
    SPC_PULSEWIDTH0 = 44000
    SPC_PULSEWIDTH1 = 44001

    SPC_TRIG_CH_AVAILPULSEWIDTH = 44100
    SPC_TRIG_CH_PULSEWIDTH = 44101
    SPC_TRIG_CH0_PULSEWIDTH = 44101
    SPC_TRIG_CH1_PULSEWIDTH = 44102
    SPC_TRIG_CH2_PULSEWIDTH = 44103
    SPC_TRIG_CH3_PULSEWIDTH = 44104
    SPC_TRIG_CH4_PULSEWIDTH = 44105
    SPC_TRIG_CH5_PULSEWIDTH = 44106
    SPC_TRIG_CH6_PULSEWIDTH = 44107
    SPC_TRIG_CH7_PULSEWIDTH = 44108
    SPC_TRIG_CH8_PULSEWIDTH = 44109
    SPC_TRIG_CH9_PULSEWIDTH = 44110
    SPC_TRIG_CH10_PULSEWIDTH = 44111
    SPC_TRIG_CH11_PULSEWIDTH = 44112
    SPC_TRIG_CH12_PULSEWIDTH = 44113
    SPC_TRIG_CH13_PULSEWIDTH = 44114
    SPC_TRIG_CH14_PULSEWIDTH = 44115
    SPC_TRIG_CH15_PULSEWIDTH = 44116

    SPC_TRIG_EXT_AVAILPULSEWIDTH = 44200
    SPC_TRIG_EXT0_PULSEWIDTH = 44210

    # available dividers for MICX
    SPC_READCLOCKDIVCOUNT = 44300
    SPC_CLOCKDIV0 = 44301
    SPC_CLOCKDIV1 = 44302
    SPC_CLOCKDIV2 = 44303
    SPC_CLOCKDIV3 = 44304
    SPC_CLOCKDIV4 = 44305
    SPC_CLOCKDIV5 = 44306
    SPC_CLOCKDIV6 = 44307
    SPC_CLOCKDIV7 = 44308
    SPC_CLOCKDIV8 = 44309
    SPC_CLOCKDIV9 = 44310
    SPC_CLOCKDIV10 = 44311
    SPC_CLOCKDIV11 = 44312
    SPC_CLOCKDIV12 = 44313
    SPC_CLOCKDIV13 = 44314
    SPC_CLOCKDIV14 = 44315
    SPC_CLOCKDIV15 = 44316
    SPC_CLOCKDIV16 = 44317

    SPC_READTROFFSET = 45000
    SPC_TRIGGEREDGE = 46000
    SPC_TRIGGEREDGE0 = 46000
    SPC_TRIGGEREDGE1 = 46001
    TE_POS = 10000
    TE_NEG = 10010
    TE_BOTH = 10020
    TE_NONE = 10030

    # ----- Timestamp -----
    CH_TIMESTAMP = 9999

    SPC_TIMESTAMP_CMD = 47000
    TS_RESET = 0
    TS_MODE_DISABLE = 10
    TS_MODE_STARTRESET = 11
    TS_MODE_STANDARD = 12
    TS_MODE_REFCLOCK = 13
    TS_MODE_TEST5555 = 90
    TS_MODE_TESTAAAA = 91
    TS_MODE_ZHTEST = 92

    # ----- modes for M2i hardware (bitmap) -----
    SPC_TIMESTAMP_AVAILMODES = 47001
    SPC_TSMODE_DISABLE = 0x00000000
    SPC_TS_RESET = 0x00000001
    SPC_TSMODE_STANDARD = 0x00000002
    SPC_TSMODE_STARTRESET = 0x00000004
    SPC_TSCNT_INTERNAL = 0x00000100
    SPC_TSCNT_REFCLOCKPOS = 0x00000200
    SPC_TSCNT_REFCLOCKNEG = 0x00000400
    SPC_TSFEAT_NONE = 0x00000000
    SPC_TSFEAT_STORE1STABA = 0x00010000

    SPC_TSXIOACQ_DISABLE = 0x00000000
    SPC_TSXIOACQ_ENABLE = 0x00001000

    SPC_TSMODE_MASK = 0x000000FF
    SPC_TSCNT_MASK = 0x00000F00
    SPC_TSFEAT_MASK = 0x000F0000

    SPC_TIMESTAMP_STATUS = 47010
    TS_FIFO_EMPTY = 0
    TS_FIFO_LESSHALF = 1
    TS_FIFO_MOREHALF = 2
    TS_FIFO_OVERFLOW = 3

    SPC_TIMESTAMP_COUNT = 47020
    SPC_TIMESTAMP_STARTTIME = 47030
    SPC_TIMESTAMP_STARTDATE = 47031
    SPC_TIMESTAMP_FIFO = 47040
    SPC_TIMESTAMP_TIMEOUT = 47045

    SPC_TIMESTAMP_RESETMODE = 47050
    TS_RESET_POS = 10
    TS_RESET_NEG = 20

    # ----- Extra I/O module -----
    SPC_XIO_DIRECTION = 47100
    XD_CH0_INPUT = 0
    XD_CH0_OUTPUT = 1
    XD_CH1_INPUT = 0
    XD_CH1_OUTPUT = 2
    XD_CH2_INPUT = 0
    XD_CH2_OUTPUT = 4
    SPC_XIO_DIGITALIO = 47110
    SPC_XIO_ANALOGOUT0 = 47120
    SPC_XIO_ANALOGOUT1 = 47121
    SPC_XIO_ANALOGOUT2 = 47122
    SPC_XIO_ANALOGOUT3 = 47123
    SPC_XIO_WRITEDACS = 47130

    # ----- M3i multi purpose lines (X0 and X1) -----
    SPCM_X0_MODE = 47200
    SPCM_X1_MODE = 47201
    SPCM_X0_AVAILMODES = 47210
    SPCM_X1_AVAILMODES = 47211
    SPCM_XX_ASYNCIO = 47220  # asynchronous in/out register
    SPCM_XMODE_DISABLE = 0x00000000
    SPCM_XMODE_ASYNCIN = 0x00000001  # used as asynchronous input
    SPCM_XMODE_ASYNCOUT = 0x00000002  # used as asynchronous output
    SPCM_XMODE_DIGIN = 0x00000004  # used as synchronous digital input
    SPCM_XMODE_DIGOUT = 0x00000008  # used as synchronous digital output
    SPCM_XMODE_TRIGIN = 0x00000010  # used as trigger input
    SPCM_XMODE_TRIGOUT = 0x00000020  # used as trigger output
    SPCM_XMODE_OVROUT = 0x00000040  # used as ADC overrange output
    SPCM_XMODE_RUNSTATE = 0x00000100  # shows the run state of the card (high = run)
    SPCM_XMODE_ARMSTATE = 0x00000200  # shows the arm state (high = armed for trigger)
    SPCM_XMODE_DIRECTTRIGOUT = 0x00000400  # used as direct trigger output (safe mode)
    SPCM_XMODE_DIRECTTRIGOUT_LR = (
        0x00000800  # used as direct trigger output (low re-arm)
    )
    SPCM_XMODE_RUNPULSE = 0x00001000  # starts a pulse with RUNSTATE

    # ----- Star-Hub -----
    SPC_STARHUB_CMD = 48000
    SH_INIT = 0  # Internal use: Initialisation of Starhub
    SH_AUTOROUTE = 1  # Internal use: Routing of Starhub
    SH_INITDONE = 2  # Internal use: End of Init
    SH_SYNCSTART = 3  # Internal use: Synchronisation

    SPC_STARHUB_STATUS = 48010

    SPC_STARHUB_ROUTE0 = 48100  # Routing Information for Test
    SPC_STARHUB_ROUTE99 = 48199  # ...

    # Spcm driver (M2i) sync setup registers
    SPC_SYNC_READ_SYNCCOUNT = 48990  # number of sync'd cards

    SPC_SYNC_READ_CARDIDX0 = 49000  # read index of card at location 0 of sync
    SPC_SYNC_READ_CARDIDX1 = 49001  # ...
    SPC_SYNC_READ_CARDIDX2 = 49002  # ...
    SPC_SYNC_READ_CARDIDX3 = 49003  # ...
    SPC_SYNC_READ_CARDIDX4 = 49004  # ...
    SPC_SYNC_READ_CARDIDX5 = 49005  # ...
    SPC_SYNC_READ_CARDIDX6 = 49006  # ...
    SPC_SYNC_READ_CARDIDX7 = 49007  # ...
    SPC_SYNC_READ_CARDIDX8 = 49008  # ...
    SPC_SYNC_READ_CARDIDX9 = 49009  # ...
    SPC_SYNC_READ_CARDIDX10 = 49010  # ...
    SPC_SYNC_READ_CARDIDX11 = 49011  # ...
    SPC_SYNC_READ_CARDIDX12 = 49012  # ...
    SPC_SYNC_READ_CARDIDX13 = 49013  # ...
    SPC_SYNC_READ_CARDIDX14 = 49014  # ...
    SPC_SYNC_READ_CARDIDX15 = 49015  # ...

    SPC_SYNC_READ_CABLECON0 = (
        49100  # read cable connection of card at location 0 of sync
    )
    SPC_SYNC_READ_CABLECON1 = 49101  # ...
    SPC_SYNC_READ_CABLECON2 = 49102  # ...
    SPC_SYNC_READ_CABLECON3 = 49103  # ...
    SPC_SYNC_READ_CABLECON4 = 49104  # ...
    SPC_SYNC_READ_CABLECON5 = 49105  # ...
    SPC_SYNC_READ_CABLECON6 = 49106  # ...
    SPC_SYNC_READ_CABLECON7 = 49107  # ...
    SPC_SYNC_READ_CABLECON8 = 49108  # ...
    SPC_SYNC_READ_CABLECON9 = 49109  # ...
    SPC_SYNC_READ_CABLECON10 = 49110  # ...
    SPC_SYNC_READ_CABLECON11 = 49111  # ...
    SPC_SYNC_READ_CABLECON12 = 49112  # ...
    SPC_SYNC_READ_CABLECON13 = 49113  # ...
    SPC_SYNC_READ_CABLECON14 = 49114  # ...
    SPC_SYNC_READ_CABLECON15 = 49115  # ...

    SPC_SYNC_ENABLEMASK = 49200  # synchronisation enable (mask)
    SPC_SYNC_NOTRIGSYNCMASK = 49210  # trigger disabled for sync (mask)
    SPC_SYNC_CLKMASK = 49220  # clock master (mask)

    # ----- Gain and Offset Adjust DAC's -----
    SPC_ADJ_START = 50000

    SPC_ADJ_LOAD = 50000
    SPC_ADJ_SAVE = 50010
    ADJ_DEFAULT = 0
    ADJ_USER0 = 1
    ADJ_USER1 = 2
    ADJ_USER2 = 3
    ADJ_USER3 = 4
    ADJ_USER4 = 5
    ADJ_USER5 = 6
    ADJ_USER6 = 7
    ADJ_USER7 = 8

    SPC_ADJ_AUTOADJ = 50020
    ADJ_ALL = 0
    ADJ_CURRENT = 1
    ADJ_EXTERNAL = 2
    ADJ_1MOHM = 3

    ADJ_CURRENT_CLOCK = 4
    ADJ_CURRENT_IR = 8
    ADJ_OFFSET_ONLY = 16

    SPC_ADJ_SOURCE_CALLBACK = 50021
    SPC_ADJ_PROGRESS_CALLBACK = 50022

    SPC_ADJ_SET = 50030
    SPC_ADJ_FAILMASK = 50040

    SPC_ADJ_CALIBSOURCE = 50050
    ADJ_CALSRC_OFF = 0
    ADJ_CALSRC_GND = -1
    ADJ_CALSRC_GNDOFFS = -2

    SPC_ADJ_CALIBVALUE0 = 50060
    SPC_ADJ_CALIBVALUE1 = 50061
    SPC_ADJ_CALIBVALUE2 = 50062
    SPC_ADJ_CALIBVALUE3 = 50063
    SPC_ADJ_CALIBVALUE4 = 50064
    SPC_ADJ_CALIBVALUE5 = 50065
    SPC_ADJ_CALIBVALUE6 = 50066
    SPC_ADJ_CALIBVALUE7 = 50067

    SPC_ADJ_OFFSET0 = 51000
    SPC_ADJ_OFFSET999 = 51999

    SPC_ADJ_GAIN0 = 52000
    SPC_ADJ_GAIN999 = 52999

    SPC_ADJ_CORRECT0 = 53000
    SPC_ADJ_OFFS_CORRECT0 = 53000
    SPC_ADJ_CORRECT999 = 53999
    SPC_ADJ_OFFS_CORRECT999 = 53999

    SPC_ADJ_XIOOFFS0 = 54000
    SPC_ADJ_XIOOFFS1 = 54001
    SPC_ADJ_XIOOFFS2 = 54002
    SPC_ADJ_XIOOFFS3 = 54003

    SPC_ADJ_XIOGAIN0 = 54010
    SPC_ADJ_XIOGAIN1 = 54011
    SPC_ADJ_XIOGAIN2 = 54012
    SPC_ADJ_XIOGAIN3 = 54013

    SPC_ADJ_GAIN_CORRECT0 = 55000
    SPC_ADJ_GAIN_CORRECT999 = 55999

    SPC_ADJ_OFFSCALIBCORRECT0 = 56000
    SPC_ADJ_OFFSCALIBCORRECT999 = 56999

    SPC_ADJ_GAINCALIBCORRECT0 = 57000
    SPC_ADJ_GAINCALIBCORRECT999 = 57999

    SPC_ADJ_ANALOGTRIGGER0 = 58000
    SPC_ADJ_ANALOGTRIGGER99 = 58099

    SPC_ADJ_CALIBSAMPLERATE0 = 58100
    SPC_ADJ_CALIBSAMPLERATE99 = 58199

    SPC_ADJ_CALIBSAMPLERATE_GAIN0 = 58200
    SPC_ADJ_CALIBSAMPLERATE_GAIN99 = 58299

    SPC_ADJ_END = 59999

    # ----- FIFO Control -----
    SPC_FIFO_BUFFERS = 60000  # number of FIFO buffers
    SPC_FIFO_BUFLEN = 60010  # len of each FIFO buffer
    SPC_FIFO_BUFCOUNT = 60020  # number of FIFO buffers tranfered until now
    SPC_FIFO_BUFMAXCNT = 60030  # number of FIFO buffers to be transfered (0=continuous)
    SPC_FIFO_BUFADRCNT = 60040  # number of FIFO buffers allowed
    SPC_FIFO_BUFREADY = 60050  # fifo buffer ready register (same as SPC_COMMAND + SPC_FIFO_BUFREADY0...)
    SPC_FIFO_BUFFILLCNT = 60060  # number of currently filled buffers
    SPC_FIFO_BUFADR0 = 60100  # adress of FIFO buffer no. 0
    SPC_FIFO_BUFADR1 = 60101  # ...
    SPC_FIFO_BUFADR2 = 60102  # ...
    SPC_FIFO_BUFADR3 = 60103  # ...
    SPC_FIFO_BUFADR4 = 60104  # ...
    SPC_FIFO_BUFADR5 = 60105  # ...
    SPC_FIFO_BUFADR6 = 60106  # ...
    SPC_FIFO_BUFADR7 = 60107  # ...
    SPC_FIFO_BUFADR8 = 60108  # ...
    SPC_FIFO_BUFADR9 = 60109  # ...
    SPC_FIFO_BUFADR10 = 60110  # ...
    SPC_FIFO_BUFADR11 = 60111  # ...
    SPC_FIFO_BUFADR12 = 60112  # ...
    SPC_FIFO_BUFADR13 = 60113  # ...
    SPC_FIFO_BUFADR14 = 60114  # ...
    SPC_FIFO_BUFADR15 = 60115  # ...
    SPC_FIFO_BUFADR255 = 60355  # last

    # ----- Filter -----
    SPC_FILTER = 100000
    SPC_READNUMFILTERS = 100001  # number of programable filters
    SPC_FILTERFREQUENCY0 = 100002  # frequency of filter 0 (bypass)
    SPC_FILTERFREQUENCY1 = 100003  # frequency of filter 1
    SPC_FILTERFREQUENCY2 = 100004  # frequency of filter 2
    SPC_FILTERFREQUENCY3 = 100005  # frequency of filter 3

    # ----- Pattern -----
    SPC_PATTERNENABLE = 110000
    SPC_READDIGITAL = 110100

    # ----- Miscellanous -----
    SPC_MISCDAC0 = 200000
    SPC_MISCDAC1 = 200010
    SPC_FACTORYMODE = 200020
    SPC_DIRECTDAC = 200030
    SPC_NOTRIGSYNC = 200040
    SPC_DSPDIRECT = 200100
    SPC_DMAPHYSICALADR = 200110
    SPC_MICXCOMPATIBILITYMODE = 200120
    SPC_TEST_FIFOSPEED = 200121
    SPC_RELOADDEMO = 200122
    SPC_OVERSAMPLINGFACTOR = 200123
    SPC_GETTHREADHANDLE = 200130
    SPC_GETKERNELHANDLE = 200131
    SPC_XYZMODE = 200200
    SPC_INVERTDATA = 200300
    SPC_GATEMARKENABLE = 200400
    SPC_CONTOUTMARK = 200450
    SPC_EXPANDINT32 = 200500
    SPC_NOPRETRIGGER = 200600
    SPC_RELAISWAITTIME = 200700
    SPC_DACWAITTIME = 200710
    SPC_ILAMODE = 200800
    SPC_NMDGMODE = 200810
    SPC_CKADHALF_OUTPUT = 200820
    SPC_LONGTRIG_OUTPUT = 200830
    SPC_STOREMODAENDOFSEGMENT = 200840
    SPC_COUNTERMODE = 200850
    SPC_CNTMOD_MASK = 0x0000000F
    SPC_CNTMOD_PARALLELDATA = 0x00000000
    SPC_CNTMOD_8BITCNT = 0x00000001
    SPC_CNTMOD_2x8BITCNT = 0x00000002
    SPC_CNTMOD_16BITCNT = 0x00000003
    SPC_CNT0_MASK = 0x000000F0
    SPC_CNT0_CNTONPOSEDGE = 0x00000000
    SPC_CNT0_CNTONNEGEDGE = 0x00000010
    SPC_CNT0_RESETHIGHLVL = 0x00000000
    SPC_CNT0_RESETLOWLVL = 0x00000020
    SPC_CNT0_STOPATMAX = 0x00000000
    SPC_CNT0_ROLLOVER = 0x00000040
    SPC_CNT1_MASK = 0x00000F00
    SPC_CNT1_CNTONPOSEDGE = 0x00000000
    SPC_CNT1_CNTONNEGEDGE = 0x00000100
    SPC_CNT1_RESETHIGHLVL = 0x00000000
    SPC_CNT1_RESETLOWLVL = 0x00000200
    SPC_CNT1_STOPATMAX = 0x00000000
    SPC_CNT1_ROLLOVER = 0x00000400
    SPC_CNTCMD_MASK = 0x0000F000
    SPC_CNTCMD_RESETCNT0 = 0x00001000
    SPC_CNTCMD_RESETCNT1 = 0x00002000
    SPC_ENHANCEDSTATUS = 200900
    SPC_ENHSTAT_OVERRANGE0 = 0x00000001
    SPC_ENHSTAT_OVERRANGE1 = 0x00000002
    SPC_ENHSTAT_COMPARATOR0 = 0x40000000
    SPC_ENHSTAT_COMPARATOR1 = 0x80000000
    SPC_FILLSIZEPROMILLE = 200910
    SPC_OVERRANGEBIT = 201000
    SPC_2CH8BITMODE = 201100
    SPC_12BITMODE = 201200
    SPC_HOLDLASTSAMPLE = 201300
    SPC_CKSYNC0 = 202000
    SPC_CKSYNC1 = 202001
    SPC_DISABLEMOD0 = 203000
    SPC_DISABLEMOD1 = 203010
    SPC_ENABLEOVERRANGECHECK = 204000
    SPC_OVERRANGESTATUS = 204010
    SPC_BITMODE = 205000

    SPC_READBACK = 206000
    SPC_AVAILSTOPLEVEL = 206009
    SPC_STOPLEVEL1 = 206010
    SPC_STOPLEVEL0 = 206020
    SPC_CH0_STOPLEVEL = 206020
    SPC_CH1_STOPLEVEL = 206021
    SPC_CH2_STOPLEVEL = 206022
    SPC_CH3_STOPLEVEL = 206023
    SPCM_STOPLVL_TRISTATE = 0x00000001
    SPCM_STOPLVL_LOW = 0x00000002
    SPCM_STOPLVL_HIGH = 0x00000004
    SPCM_STOPLVL_HOLDLAST = 0x00000008
    SPCM_STOPLVL_ZERO = 0x00000010

    SPC_DIFFMODE = 206030
    SPC_DACADJUST = 206040

    SPC_AMP_MODE = 207000

    SPCM_FW_CTRL = 210000
    SPCM_FW_CLOCK = 210010
    SPCM_FW_CONFIG = 210020
    SPCM_FW_MODULEA = 210030
    SPCM_FW_MODULEB = 210031
    SPCM_FW_MODEXTRA = 210050

    SPC_MULTI = 220000
    SPC_DOUBLEMEM = 220100
    SPC_MULTIMEMVALID = 220200
    SPC_BANK = 220300
    SPC_GATE = 220400
    SPC_RELOAD = 230000
    SPC_USEROUT = 230010
    SPC_WRITEUSER0 = 230100
    SPC_WRITEUSER1 = 230110
    SPC_READUSER0 = 230200
    SPC_READUSER1 = 230210
    SPC_MUX = 240000
    SPC_ADJADC = 241000
    SPC_ADJOFFS0 = 242000
    SPC_ADJOFFS1 = 243000
    SPC_ADJGAIN0 = 244000
    SPC_ADJGAIN1 = 245000
    SPC_READEPROM = 250000
    SPC_WRITEEPROM = 250010
    SPC_DIRECTIO = 260000
    SPC_DIRECT_MODA = 260010
    SPC_DIRECT_MODB = 260020
    SPC_DIRECT_EXT0 = 260030
    SPC_DIRECT_EXT1 = 260031
    SPC_DIRECT_EXT2 = 260032
    SPC_DIRECT_EXT3 = 260033
    SPC_DIRECT_EXT4 = 260034
    SPC_DIRECT_EXT5 = 260035
    SPC_DIRECT_EXT6 = 260036
    SPC_DIRECT_EXT7 = 260037
    SPC_MEMTEST = 270000
    SPC_NODMA = 275000
    SPC_NOCOUNTER = 275010
    SPC_NOSCATTERGATHER = 275020
    SPC_RUNINTENABLE = 290000
    SPC_XFERBUFSIZE = 295000
    SPC_CHLX = 295010
    SPC_SPECIALCLOCK = 295100
    SPC_STARTDELAY = 295110
    SPC_BASISTTLTRIG = 295120
    SPC_TIMEOUT = 295130
    SPC_SWL_INFO = 295140
    SPC_SWD_INFO = 295141
    SPC_SWD_DOWN = 295142
    SPC_SWL_EXTRAINFO = 295143
    SPC_LOGDLLCALLS = 299999

    # ----- PCK400 -----
    SPC_FREQUENCE = 300000
    SPC_DELTAFREQUENCE = 300010
    SPC_PINHIGH = 300100
    SPC_PINLOW = 300110
    SPC_PINDELTA = 300120
    SPC_STOPLEVEL = 300200
    SPC_PINRELAIS = 300210
    SPC_EXTERNLEVEL = 300300

    # ----- PADCO -----
    SPC_COUNTER0 = 310000
    SPC_COUNTER1 = 310001
    SPC_COUNTER2 = 310002
    SPC_COUNTER3 = 310003
    SPC_COUNTER4 = 310004
    SPC_COUNTER5 = 310005
    SPC_MODE0 = 310100
    SPC_MODE1 = 310101
    SPC_MODE2 = 310102
    SPC_MODE3 = 310103
    SPC_MODE4 = 310104
    SPC_MODE5 = 310105
    CM_SINGLE = 1
    CM_MULTI = 2
    CM_POSEDGE = 4
    CM_NEGEDGE = 8
    CM_HIGHPULSE = 16
    CM_LOWPULSE = 32

    # ----- PAD1616 -----
    SPC_SEQUENCERESET = 320000
    SPC_SEQUENCEADD = 320010
    SEQ_IR_10000MV = 0
    SEQ_IR_5000MV = 1
    SEQ_IR_2000MV = 2
    SEQ_IR_1000MV = 3
    SEQ_IR_500MV = 4
    SEQ_CH0 = 0
    SEQ_CH1 = 8
    SEQ_CH2 = 16
    SEQ_CH3 = 24
    SEQ_CH4 = 32
    SEQ_CH5 = 40
    SEQ_CH6 = 48
    SEQ_CH7 = 56
    SEQ_CH8 = 64
    SEQ_CH9 = 72
    SEQ_CH10 = 80
    SEQ_CH11 = 88
    SEQ_CH12 = 96
    SEQ_CH13 = 104
    SEQ_CH14 = 112
    SEQ_CH15 = 120
    SEQ_TRIGGER = 128
    SEQ_START = 256

    # ----- Option CA -----
    SPC_CA_MODE = 330000
    CAMODE_OFF = 0
    CAMODE_CDM = 1
    CAMODE_KW = 2
    CAMODE_OT = 3
    CAMODE_CDMMUL = 4
    SPC_CA_TRIGDELAY = 330010
    SPC_CA_CKDIV = 330020
    SPC_CA_PULS = 330030
    SPC_CA_CKMUL = 330040
    SPC_CA_DREHZAHLFORMAT = 330050
    CADREH_4X4 = 0
    CADREH_1X16 = 1
    SPC_CA_KWINVERT = 330060
    SPC_CA_OUTA = 330100
    SPC_CA_OUTB = 330110
    CAOUT_TRISTATE = 0
    CAOUT_LOW = 1
    CAOUT_HIGH = 2
    CAOUT_CDM = 3
    CAOUT_OT = 4
    CAOUT_KW = 5
    CAOUT_TRIG = 6
    CAOUT_CLK = 7
    CAOUT_KW60 = 8
    CAOUT_KWGAP = 9
    CAOUT_TRDLY = 10
    CAOUT_INVERT = 16

    # ----- Hardware registers (debug use only) -----
    SPC_REG0x00 = 900000
    SPC_REG0x02 = 900010
    SPC_REG0x04 = 900020
    SPC_REG0x06 = 900030
    SPC_REG0x08 = 900040
    SPC_REG0x0A = 900050
    SPC_REG0x0C = 900060
    SPC_REG0x0E = 900070

    SPC_DEBUGREG0 = 900100
    SPC_DEBUGREG15 = 900115
    SPC_DEBUGVALUE0 = 900200
    SPC_DEBUGVALUE15 = 900215

    SPC_MI_ISP = 901000
    ISP_TMS_0 = 0
    ISP_TMS_1 = 1
    ISP_TDO_0 = 0
    ISP_TDO_1 = 2

    SPC_EE_RWAUTH = 901100
    SPC_EE_REG = 901110
    SPC_EE_RESETCOUNTER = 901120

    # ----- Test Registers -----
    SPC_TEST_BASE = 902000
    SPC_TEST_LOCAL_START = 902100
    SPC_TEST_LOCAL_END = 902356
    SPC_TEST_PLX_START = 902400
    SPC_TEST_PLX_END = 902656
    SPCM_DEBUG_MASK = 903000
    SPCM_DEBUG_NONE = 0
    SPCM_DEBUG_MD = 1
    SPCM_DEBUG_CCEN = 2
