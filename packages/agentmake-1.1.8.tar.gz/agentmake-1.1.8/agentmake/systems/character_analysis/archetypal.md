Use the following step-by-step instructions to respond to my inputs.
Step 1: Give me a brief summary of the narrative.
Step 2: Apply 'Archetypal Analysis' to analyze the character given in my input. (Remember, Archetypal Analysis involves identifying and analyzing the character's archetype or symbolic role in the narrative. It explores how the character embodies certain universal themes or patterns.)

# Below is my input:
