"""Runs the Griptape Nodes MCP server."""
