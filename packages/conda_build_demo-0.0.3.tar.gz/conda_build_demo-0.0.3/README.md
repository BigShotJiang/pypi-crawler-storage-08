## Intro

This is Python project skeleton used to demonstrate building Conda packages using [conda-build](https://github.com/conda/conda-build) and [rattler-build](https://github.com/prefix-dev/rattler-build).

## Development

```shell
python -m venv .venv
source .venv/bin/activate
pip install -e .
# Modify version, for example
python -m unittest discover -s tests
```

## Building

Setup to build by installing [build](https://github.com/pypa/build) and [twine](https://github.com/pypa/twine):
```shell
pip install --upgrade pip build twine
```

Clean out the dist path and create the source tarball and wheel:
```shell
rm dist/conda_build_demo-*.tar.gz dist/conda_build_demo-*.whl
python -m build
twine check dist/conda_build_demo-*.tar.gz dist/conda_build_demo-*.whl
```

## Distributing

```shell
export TWINE_USERNAME="__token__"
export TWINE_PASSWORD="pypi-..."
export TWINE_REPOSITORY_URL="https://test.pypi.org/"

twine upload --repository testpypi dist/conda_build_demo-*.tar.gz dist/conda_build_demo-*.whl
```

## Validate Package

```shell
docker run --rm -v ./ca:/etc/ca docker.io/library/python:3.12-slim sh -c "PIP_CERT=/etc/ca pip install --index-url https://test.pypi.org/simple --no-deps conda-build-demo && python -c 'import conda_build_demo; d = Demo(); print(d.version())'"
```
