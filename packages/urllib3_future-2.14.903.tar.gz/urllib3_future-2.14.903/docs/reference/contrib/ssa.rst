Simplified Async Socket
=======================

.. automodule:: urllib3.contrib.ssa
    :members:
    :undoc-members:
    :show-inheritance:
