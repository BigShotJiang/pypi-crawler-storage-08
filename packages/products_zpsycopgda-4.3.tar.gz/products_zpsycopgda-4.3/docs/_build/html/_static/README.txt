Place static files, e.g. images or CSS, in this folder.
