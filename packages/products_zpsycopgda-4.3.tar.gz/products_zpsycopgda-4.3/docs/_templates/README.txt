Place Sphinx layout templates in this folder.
