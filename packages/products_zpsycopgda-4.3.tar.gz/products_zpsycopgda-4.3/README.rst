.. image:: https://github.com/dataflake/Products.ZPsycopgDA/actions/workflows/tests.yml/badge.svg
   :target: https://github.com/dataflake/Products.ZPsycopgDA/actions/workflows/tests.yml

.. image:: https://coveralls.io/repos/github/dataflake/Products.ZPsycopgDA/badge.svg?branch=master
   :target: https://coveralls.io/github/dataflake/Products.ZPsycopgDA?branch=master

.. image:: https://readthedocs.org/projects/zpsycopgda/badge/?version=latest
   :target: https://zpsycopgda.readthedocs.io
   :alt: Documentation Status

.. image:: https://img.shields.io/pypi/v/Products.ZPsycopgDA.svg
   :target: https://pypi.org/project/Products.ZPsycopgDA/
   :alt: Latest stable release on PyPI

.. image:: https://img.shields.io/pypi/pyversions/Products.ZPsycopgDA.svg
   :target: https://pypi.org/project/Products.ZPsycopgDA/
   :alt: Stable release supported Python versions


=====================
 Products.ZPsycopgDA
=====================

This is a Zope database adapter for PostGreSQL based on psycopg2__ for Zope 4
and up on all Python versions supported by Zope 4 and 5.

The code was forked from the original project at
https://github.com/psycopg/ZPsycopgDA because it appears to be dead. The old
code is not compatible with Zope 4/5 and Python 3.

.. __: https://pypi.org/project/psycopg2/
