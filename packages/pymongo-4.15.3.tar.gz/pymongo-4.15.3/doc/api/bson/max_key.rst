:mod:`max_key` -- Representation for the MongoDB internal MaxKey type
=====================================================================
.. automodule:: bson.max_key
   :synopsis: Representation for the MongoDB internal MaxKey type
   :members:
