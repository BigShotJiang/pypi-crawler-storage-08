:mod:`int64` -- Tools for representing BSON int64
=================================================
.. versionadded:: 3.0

.. automodule:: bson.int64
   :synopsis: Tools for representing BSON int64
   :members:
