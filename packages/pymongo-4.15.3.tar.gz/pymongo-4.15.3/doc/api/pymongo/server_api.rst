:mod:`server_api` -- Support for MongoDB Stable API
======================================================

.. automodule:: pymongo.server_api
   :synopsis: Support for MongoDB Stable API

   .. autoclass:: pymongo.server_api.ServerApi
      :members:

   .. autoclass:: pymongo.server_api.ServerApiVersion
      :members:
