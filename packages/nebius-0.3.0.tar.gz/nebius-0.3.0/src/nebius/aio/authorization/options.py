OPTION_TYPE = "type"


class Types:
    DISABLE = "disable"
