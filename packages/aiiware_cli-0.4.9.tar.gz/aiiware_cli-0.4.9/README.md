# AII — AI-Powered Terminal Assistant

**AII** (pronounced *"eye"*) is your **intelligent command-line companion** that brings Claude, GPT, and Gemini directly into your terminal through natural language commands.

**🎉 Version 0.4.9** — MCP Made Easy | **v0.4.8** — Multi-Step Automation & GitHub Integration | **v0.4.7** — Templates & Analytics

## Why AII?

**One CLI. 25 AI Functions. Natural Language. Zero Configuration Headaches.**

Stop context-switching between your terminal and ChatGPT. Get instant AI assistance for git commits, code generation, translation, content writing, shell automation, and analysis—all without leaving your terminal.

**Perfect for:**
- **Developers**: AI-powered git commits, code generation, and shell automation
- **Creators**: Content writing, translation, and social media posts
- **Professionals**: Email templates, document analysis, and research assistance

Built with the Pydantic AI framework for reliable, multi-provider LLM integration (Anthropic Claude, OpenAI GPT, Google Gemini).

### 📊 AII vs. Traditional Workflows

| Task | Without AII | With AII |
|------|-------------|----------|
| **Git Workflows** | Manual commits, PRs, branches | `aii commit/pr/branch` → AI-powered git automation |
| **GitHub Operations** | Switch to browser → Manual queries | `aii "list my repositories"` → Instant GitHub API access |
| **Translation** | Copy to browser → ChatGPT → Copy back | `aii translate "text" to spanish` → Instant result |
| **Code Generation** | Search Stack Overflow → Adapt code | `aii create python email validator` → Complete function |
| **Shell Commands** | Google syntax → Test carefully | `aii find large files` → Safe command with explanation |
| **Content Writing** | Open docs/emails separately | `aii write email declining meeting` → Professional draft |

**Result:** Stay in your terminal, maintain flow state, get instant AI assistance.

---

## ✨ Key Features

### 🎯 Natural Language Interface
Just describe what you want—no commands to memorize:
- **25 AI Functions**: Content generation, code operations, git workflows, shell automation, analysis, translation
- **Multi-Provider**: Anthropic Claude, OpenAI GPT, Google Gemini with automatic fallbacks
- **Smart Confirmations**: Context-aware safety checks that don't interrupt safe operations
- **Session Memory**: Persistent conversations across commands

###  🛡️ Advanced Features

**New in v0.4.9:**
- **📦 Easy MCP Server Management**: No more manual config file editing!
  - **Catalog of 10+ Popular Servers**: Pre-configured servers ready to install
  - `aii mcp catalog` — Browse available servers (github, chrome-devtools, postgres, etc.)
  - `aii mcp install <server>` — One-command installation from catalog
  - `aii mcp add <name> <command>` — Add custom servers
  - `aii mcp list` — View installed servers with status
  - `aii mcp remove/disable/enable` — Manage server lifecycle
  - `aii mcp list-tools <server>` — Discover available tools per server
  - Setup time reduced: 5 minutes → 30 seconds
- **🔧 Bug Fixes**:
  - Token tracking now works (previously showed 0 for MCP operations)
  - Natural language queries display results correctly
  - Clean output formatting without duplicate status lines

**New in v0.4.8:**
- **🔗 Multi-Step Tool Chaining**: Automatically execute complex workflows requiring sequential operations
  - LLM-guided chain planning with intelligent parameter mapping
  - Real-time progress display for each step
  - Seamless output-to-input data flow between steps
  - Example: Complex file operations, multi-step data transformations
- **🐙 GitHub Integration** (Fixed Oct 9): Full GitHub API access through Model Context Protocol
  - **Search repositories**: `"search github for popular python ML repos"` → Returns 138+ actual repos
  - **List your repos**: `"list my github repositories"` → All public and private repos
  - **Create issues**: `"create an issue in ttware/aii about adding tests"` → AI-generated issue
  - **Search code**: `"search github code for authentication examples"` → Cross-repo code search
  - **Authenticated queries**: Use `@me` for "my repos", "my issues" (automatic auth)
  - **26 GitHub tools**: create_issue, fork_repository, search_code, create_pull_request, and more
  - **Verified working**: All queries correctly route to GitHub API (not web search)
- **⚡ Direct MCP Control**: Power-user interface for precise tool invocation
  - `aii mcp invoke <tool_name>` — Direct tool calls bypassing LLM
  - `aii mcp list-tools` — Discover available MCP server tools
  - Perfect for scripting and automation workflows

**New in v0.4.7:**
- **📝 Template Library**: 8 pre-built content templates for rapid generation
  - Marketing: Product announcements, social media posts, launch tweets
  - Development: PR descriptions, release notes
  - Business: Professional emails, meeting notes, blog intros
  - Variable substitution with Handlebars-style syntax
  - User override system: `~/.config/aii/templates/`
  - CLI: `aii template list/show/use` or natural language
- **📊 Usage Analytics**: Track your AI function usage with detailed statistics
  - Command history analysis (7d, 30d, 90d, all time)
  - Function usage breakdown with percentages
  - Token and cost estimation per execution
  - `aii stats` command for instant insights
  - Privacy-first: Local SQLite storage, no external tracking

**New in v0.4.5:**
- **🔀 Git PR Generator**: AI-powered pull request creation with automatic title and description
  - Analyzes commit history across branches
  - Generates comprehensive PR descriptions with summary, changes, and test plan
  - Creates PR directly on GitHub via `gh` CLI
- **🌿 Smart Branch Naming**: Conventional branch names from natural language
  - Auto-detects type: feature/, bugfix/, docs/, refactor/, etc.
  - Generates clean slugs from descriptions
  - Validates branch doesn't exist before creation

**New in v0.4.4:**
- **🌊 Real-Time Response Streaming**: See LLM responses as they're generated — 60-80% faster perceived speed
  - Token-by-token display with <100ms latency
  - Works with Claude, GPT, and Gemini
  - Markdown rendering during streaming
  - Configurable with `--no-streaming` flag
- **🎨 OutputMode System**: Function-specific output formatting — Get exactly the detail you need
  - **CLEAN mode** (16 functions, 67% default): Just the result (perfect for quick queries and pipeable output)
  - **STANDARD mode** (5 functions, 21%): Result + metrics + simple summary (no expensive LLM analysis)
  - **THINKING mode** (3 functions, 12%): Full reasoning display with LLM semantic analysis
  - Smart defaults: Most functions → CLEAN (shell, translate, content), Analysis → THINKING (research, code_review)
  - CLI overrides: `--clean`, `--standard`, `--thinking` or per-function config in config.yaml
  - Session header only in THINKING mode (STANDARD/CLEAN are cleaner and faster)

**New in v0.4.3:**
- **⚡ Shell Autocomplete**: Tab completion for bash/zsh/fish — Type 40-60% faster
- **📜 Command History**: Arrow key navigation in interactive mode with 1000-command persistence

**New in v0.4.2:**
- **🚀 Interactive Setup Wizard**: 2-minute guided setup with arrow key navigation
- **💰 Real-Time Cost Tracking**: Transparent pricing for 27 AI models across 3 providers
- **⚙️ Quick Config**: Fast provider/model switching with `aii config provider/model`

**Core Features:**
- **LLM-First Architecture**: Advanced natural language understanding
- **Thinking Mode Display**: See AI reasoning, confidence scores, and token usage
- **Web Search Integration**: Research with real-time web results (DuckDuckGo, Brave, Google)
- **Health Diagnostics**: `aii doctor` command for troubleshooting setup issues
- **Debug Mode**: Complete diagnostics with 56 security patterns

---

## 🚀 Quick Start

### Installation

```bash
# With uv (recommended)
uv tool install aiiware-cli

# Or with pip
pip install aiiware-cli

# Verify
aii --version  # → aiiware-cli 0.4.9
```

### Setup *(Interactive Wizard in v0.4.2)*

```bash
# Interactive setup wizard (2 minutes)
aii config init

# Verify setup
aii doctor  # → Runs health checks for configuration, LLM provider, storage, etc.
```

**Features:**
- **Arrow key navigation** — Visual menu with provider descriptions
- **Automatic validation** — Tests API key before saving
- **Browser integration** — Opens API key signup pages
- **Guided experience** — Provider selection → API key → Model choice

**Troubleshooting:** If you encounter issues, run `aii doctor` to diagnose configuration problems.

**Get API Keys:**
- **Claude**: [console.anthropic.com](https://console.anthropic.com/)
- **GPT**: [platform.openai.com](https://platform.openai.com/)
- **Gemini**: [aistudio.google.com/apikey](https://aistudio.google.com/apikey)

### Shell Autocomplete *(New in v0.4.3)*

Enable tab completion for commands, flags, and parameters in bash, zsh, and fish:

```bash
# Install (auto-detects your shell)
aii install-completion

# Or specify shell explicitly
aii install-completion --shell bash
aii install-completion --shell zsh
aii install-completion --shell fish
```

**For zsh users:** Add to `~/.zshrc` if not already present:
```bash
fpath=(~/.zsh/completion $fpath)
autoload -Uz compinit && compinit
```

**Activate:**
```bash
source ~/.bashrc          # bash
exec zsh                  # zsh (or restart terminal)
# fish auto-loads automatically
```

**Usage:**
```bash
aii tr<TAB>                      → aii translate
aii translate --<TAB>            → --to --from --format --help
aii translate --to <TAB>         → spanish french german chinese  # zsh/fish
```

**Uninstall:**
```bash
aii uninstall-completion
```

### Interactive Mode with Command History *(New in v0.4.3)*

Interactive mode now includes persistent command history with arrow key navigation:

```bash
# Start interactive mode
aii

# Your commands are saved and can be recalled
> translate hello to French
Bonjour

> explain how LLMs work
[explanation...]

> ↑  # UP arrow — recalls previous commands
> ↓  # DOWN arrow — navigate forward
```

**Features:**
- **Arrow keys**: UP/DOWN for history, LEFT/RIGHT for editing
- **Keyboard shortcuts**: Home/End, Ctrl+A/E/K/U
- **Persistent**: 1000 commands saved at `~/.config/aii/.aii_history`
- **Zero config**: Works automatically

---

## 💡 What You Can Do

### 🔧 Core Use Cases

#### 🔀 **AI Git Workflows** — Complete git automation
```bash
# Smart commit messages
git add . && aii commit
# → Analyzes changes → Generates conventional commit → Shows confidence score

# Pull request creation (New in v0.4.5)
aii pr
# → Analyzes commits → Generates PR title/description → Creates on GitHub

# Smart branch naming (New in v0.4.5)
aii branch "add user authentication"
# → feature/add-user-authentication
```

#### 💻 **Code Generation** — Language-agnostic with best practices
```bash
aii create a python function to validate emails
# Complete with typing, docstrings, error handling, and examples
```

#### 🌍 **Translation** — Context-aware with cultural notes
```bash
# Quick answer (CLEAN mode default)
aii translate "running late for meeting" to spanish
# → "Voy a llegar tarde a la reunión"

# With full reasoning (override with --thinking)
aii translate "running late for meeting" to spanish --thinking
# → Shows translation logic, cultural context, confidence score
```

#### 📝 **Content Creation** — Professional writing assistance
```bash
aii write a tweet about AI breakthroughs in 2025
# → Engaging tweet with hashtags, character count validation
```

#### 📚 **Template Library** — Rapid content generation **(New in v0.4.7)**
```bash
# List available templates
aii template list
# → 8 templates: product-announcement, tweet-launch, email-professional...

# View template details
aii template show product-announcement
# → Shows variables: product, version, key_features, etc.

# Generate from template
aii template use product-announcement \
  --product "AII CLI" \
  --version "v0.4.7" \
  --key-features "Template library, usage analytics"
# → Professional announcement with variable substitution

# Or use natural language
aii "generate a product announcement for AII v0.4.7"
# → Detects intent and uses appropriate template
```

#### 📦 **MCP Server Management** — Easy setup for extended capabilities **(New in v0.4.9)**
```bash
# Browse available servers
aii mcp catalog
# → Shows 10+ pre-configured servers: github, chrome-devtools, postgres, redis...

# Install from catalog
aii mcp install github
# → One-command setup with automatic configuration

# Add custom server
aii mcp add my-server npx my-mcp-server --port 3000
# → Adds custom MCP server to configuration

# List installed servers
aii mcp list
# → Shows all servers with status (enabled/disabled)

# Discover tools
aii mcp list-tools github
# → Lists all available tools for github server

# Manage servers
aii mcp disable github     # Temporarily disable
aii mcp enable github      # Re-enable
aii mcp remove github      # Remove completely
```

#### 🐙 **GitHub Integration** — Full GitHub API access **(New in v0.4.8)**
```bash
# First, install GitHub MCP server (v0.4.9 made this easy!)
aii mcp install github
# → Set GITHUB_PERSONAL_ACCESS_TOKEN environment variable
# → Get token at github.com/settings/tokens (scopes: repo, read:org, read:user)

# List your repositories
aii "list my github repositories"
# → Returns all your repos with details (public and private)

# Search for repositories
aii "search for popular python machine learning repositories"
# → Searches GitHub with intelligent query construction

# Create an issue
aii "create an issue in my repo about adding dark mode"
# → Creates issue with AI-generated title and description

# Search code across GitHub
aii "search for TODO comments in my repositories"
# → Finds code patterns across your projects

# Direct MCP control (power users)
aii mcp invoke search_repositories --args '{"query": "user:@me language:python"}'
# → Precise control over GitHub API calls
```

#### 📊 **Usage Analytics** — Track your AI function usage **(New in v0.4.7)**
```bash
# View usage statistics
aii stats
# → Last 30 days: Total executions, top functions, usage percentages

# Weekly breakdown
aii stats --period 7d
# → Last 7 days statistics

# Function-specific analysis
aii stats --breakdown functions
# → Detailed function usage with tokens and cost estimates

# Exclude stats function from results (avoid observer effect)
aii stats --exclude-stats
# → Shows only "real work" functions, not stats checks
```

#### 🐚 **Shell Automation** — Safe command generation with explanations
```bash
aii find all python files modified this week
# → Generates command, explains safety, requests confirmation
```

#### 🧠 **Explanations** — Clear technical concepts
```bash
aii explain how transformers work in LLMs
# → Structured explanation with examples and analogies
```

#### 🔍 **Web Research** — Real-time information with sources
```bash
aii research latest developments in quantum computing
# → Searches web (DuckDuckGo/Brave/Google)
# → Synthesizes findings with [Source N] citations
```

#### 🎨 **Output Modes** — Control detail level **(New in v0.4.4)**
```bash
# CLEAN mode: Just the answer (default for most functions)
aii translate hello to french
# → "bonjour"

aii find largest file in Downloads --clean
# Generated command: `find ~/Downloads -type f -exec du -h {} + | sort -rh | head -n 1`
# Execute? [y/N]: y
# → 1.2G    bigfile.zip

# STANDARD mode: Answer + metrics (no expensive LLM analysis)
aii translate hello to french --standard
# → "bonjour"
# → ✓ translate: (1.8s) • 145↗ 28↘ (173 tokens)
# → 📊 Session Summary: ⚡ Total: 3.2s • 💰 $0.000043

# THINKING mode: Full reasoning (for when you need to understand why)
aii commit --thinking
# → 🔍 aii • Claude • Functions: 23 loaded
# → [Diff analysis + reasoning + commit message + confidence + LLM insights]
```

---

## 📖 Usage Guide

### 🎯 Natural Language Commands

No need to memorize syntax—just describe what you want:

| Command Type | Example | What Happens |
|-------------|---------|--------------|
| **Translation** | `aii translate hello to spanish` | Context-aware translation with cultural notes |
| **Git** | `aii commit` / `aii pr` / `aii branch "feature"` | AI-powered commits, PRs, and branch naming |
| **Code** | `aii write a python email validator` | Complete function with types, docs, examples |
| **Content** | `aii write a tweet about AI` | Character-limited, engaging, with hashtags |
| **Shell** | `aii find large files` | Generates safe command with explanation |
| **Analysis** | `aii explain machine learning` | Structured explanation with examples |

### 🔧 All 25 AI Functions

<details>
<summary><b>📝 Content Generation</b> (5 functions) — Click to expand</summary>

- **Universal Content**: Flexible generation with tone/style customization
- **Twitter/Social**: Platform-specific posts with character limits
- **Email Templates**: Professional business communication
- **Blog/Article**: Long-form content creation
</details>

<details>
<summary><b>💻 Code Operations</b> (2 functions)</summary>

- **Code Generation**: Multi-language with best practices, typing, documentation
- **Code Review**: Security analysis, style suggestions, optimization tips
</details>

<details>
<summary><b>🔀 Git Integration</b> (5 functions) — Enhanced in v0.4.5</summary>

- **AI Commit**: Diff analysis → Conventional commit messages with thinking mode
- **PR Generator** *(New)*: Analyze commits → Create GitHub pull requests with AI descriptions
- **Smart Branch** *(New)*: Natural language → Conventional branch names (feature/, bugfix/, etc.)
- **Git Status**: Repository insights with actionable suggestions
- **Git Diff**: Intelligent change analysis and explanations
</details>

<details>
<summary><b>🐚 Shell Operations</b> (4 functions)</summary>

- **Command Generation**: Safe shell command creation with confirmation
- **Enhanced Shell**: AI-powered execution with tool calling
- **Streaming Shell**: Real-time command output
- **Contextual Shell**: Environment-aware operations
</details>

<details>
<summary><b>🧠 Analysis & Research</b> (3 functions)</summary>

- **Explain**: Technical concepts with examples and analogies
- **Summarize**: Intelligent content condensation
- **Research**: Web-based research with source validation
</details>

<details>
<summary><b>🌍 Translation & Language</b> (2 functions)</summary>

- **Translation**: Multi-language with cultural context
- **Language Detection**: Automatic language identification
</details>

<details>
<summary><b>📊 Context Management</b> (3 functions)</summary>

- **Git Context**: Repository history and structure analysis
- **File Context**: Project structure and file system insights
- **System Context**: Environment information gathering
</details>

<details>
<summary><b>⚙️ System</b> (2 functions)</summary>

- **Help**: Dynamic assistance based on your context
- **Clarification**: Handles ambiguous requests intelligently
</details>

### 🎛️ Advanced Features

#### **OutputMode System** *(New in v0.4.4)*
Control output detail with function-specific defaults and CLI overrides:

- **CLEAN mode** (default for translate, explain, summarize): Just the result
- **STANDARD mode**: Result + metrics + session summary
- **THINKING mode** (default for git commit, code review): Full AI reasoning

```bash
# Defaults work intelligently
aii translate hello to spanish     # → "hola" (CLEAN default)
aii commit                          # → Full reasoning (THINKING default)

# Override any function
aii translate hello to spanish --thinking  # → See reasoning
aii commit --clean                         # → Quick commit

# CLI flags: --clean, --standard, --thinking, --verbose
```

#### **Smart Risk-Based Confirmations**
- **Safe operations** (translate, explain): Execute immediately, no interruption
- **Risky operations** (shell, git): Show command preview + safety notes + confirmation

#### **Token Tracking & Cost Transparency** *(Enhanced in v0.4.2)*
Monitor LLM usage and costs in real-time across all operations:
```bash
# 📊 Session: 3.2s • Tokens: 142↗ 28↘ (170 total) • 💰 $0.000049
# Shows: execution time, input/output tokens, exact cost
```

#### **Session Persistence**
```bash
aii explain quantum computing  # Auto-saves as session_abc123
aii --continue give me more examples  # Resumes conversation
```

#### **Debug Mode**
```bash
AII_DEBUG=1 aii commit  # Shows: security patterns, LLM recognition, token breakdown
```

---

## 🎨 Real-World Examples

### **AI Git Commit**

```bash
git add . && aii commit

# 🧠 Thinking: Analyzing changes... console.log added for debugging
# 💻 Commit: feat(app): add console logging for debugging
# 🎯 Confidence: 89% • Tokens: 245↗ 67↘
# Proceed? (y/n): y
# ✅ Committed: a1b2c3d
```

### **Context-Aware Translation**

```bash
aii translate "running late for meeting" to spanish

# 🧠 Converting informal business expression, maintaining urgency...
# 🌐 "Voy a llegar tarde a la reunión"
# 📝 Informal but professional. Alternative: "Me voy a retrasar" (more formal)
# 🎯 Confidence: 94%
```

### **Code Generation with Best Practices**

```bash
aii create a python email validator with error handling

# 💻 Returns complete function with:
# - RFC 5322 regex pattern
# - Type hints (typing.bool)
# - Comprehensive docstring
# - Error handling (TypeError, re.error)
# - Example usage with test cases
# 🎯 Confidence: 92% • 445 tokens generated
```

### **GitHub Integration** *(New in v0.4.8 - Fixed Oct 9)*

```bash
# List your repositories (automatic @me authentication)
aii "list my github repositories"

# 📊 Returns:
# {
#   "total_count": 6,
#   "items": [
#     {"name": "aii", "full_name": "ttware/aii", "private": false, "stars": 245},
#     {"name": "sites", "full_name": "ttware/sites", "private": true, ...}
#   ]
# }
# ✓ mcp_tool: (12.3s)

# Search for popular repositories (VERIFIED WORKING!)
aii "search github for popular python ML repos"

# 🔍 Returns 138 repositories:
# - transformers (huggingface/transformers)
# - funNLP (fighting41love/funNLP)
# - awesome-machine-learning (josephmisiti/awesome-machine-learning)
# - scikit-learn (scikit-learn/scikit-learn)
# ...
# ✓ Uses: language:python machine learning stars:>1000 sort:stars

# Create an issue with AI-generated content
aii "create an issue in ttware/aii about adding tests"

# 💡 AI generates:
# Title: "Add comprehensive test suite and CI"
# Body: Detailed description with acceptance criteria, implementation notes
# Labels: ["tests", "ci", "enhancement"]
# ✓ Issue created: https://github.com/ttware/aii/issues/184
```

---

## ⚙️ Configuration

```bash
# Interactive setup
aii config init        # Guided provider + API key setup (v0.4.2: arrow key menu)
aii config show        # View current config
aii config validate    # Check configuration

# Quick config commands (New in v0.4.2)
aii config provider    # Switch LLM provider (Claude/GPT/Gemini)
aii config model       # Change model within provider
aii config web-search  # Configure web search integration

# MCP (Model Context Protocol) management (Enhanced in v0.4.9)
aii mcp catalog            # Browse available servers
aii mcp install <server>   # Install from catalog
aii mcp add <name> <cmd>   # Add custom server
aii mcp list               # List installed servers
aii mcp list-tools <srv>   # Discover available tools
aii mcp invoke <tool>      # Direct tool invocation
aii mcp remove/disable/enable <server>  # Manage lifecycle

# Command-line options
aii --help             # Show help
aii --version          # Version info
aii --continue "msg"   # Resume last session
```

### MCP Server Management *(Enhanced in v0.4.9)*

**Easy Setup (New in v0.4.9):**
```bash
# Browse available servers
aii mcp catalog
# → Development: github, filesystem
# → Automation: chrome-devtools, puppeteer
# → Databases: mongodb, postgres, redis
# → DevOps: docker
# → Communication: slack

# Install from catalog (one command!)
aii mcp install github

# Set environment variables
export GITHUB_PERSONAL_ACCESS_TOKEN="ghp_your_token_here"

# Start using immediately
aii "list my github repositories"
```

**Manual Configuration (Advanced):**

If you prefer manual setup, configure MCP servers in `~/.aii/mcp_servers.json`:

```json
{
  "mcpServers": {
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "ghp_your_token_here"
      }
    },
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/path/to/allowed/dir"]
    }
  }
}
```

**Available MCP Servers (10+ in Catalog):**
- **Development**: github, filesystem
- **Automation**: chrome-devtools, puppeteer
- **Databases**: mongodb, postgres, redis
- **DevOps**: docker
- **Communication**: slack

More servers at [MCP Server Registry](https://github.com/modelcontextprotocol/servers)

**Server Management Commands:**
```bash
aii mcp list                    # View installed servers
aii mcp list-tools github       # Discover available tools
aii mcp disable github          # Temporarily disable
aii mcp enable github           # Re-enable
aii mcp remove github           # Remove completely
```

---

## 🐛 Troubleshooting

**Quick Diagnosis:** Run `aii doctor` to check your setup automatically.

| Issue | Solution |
|-------|----------|
| ❌ `ANTHROPIC_API_KEY not found` | Run `aii config init` or `export ANTHROPIC_API_KEY="key"` |
| ❌ `aii command not found` | Restart terminal or check PATH: `uv tool install aiiware-cli` |
| ⚠️ Slow responses | Check network or try different provider: `aii config init` |
| 🔍 Need diagnostics | Run `aii doctor` or enable debug: `AII_DEBUG=1 aii your-command` |
| 🔄 LLM timeout errors | Retry logic automatic in v0.4.1, check `aii doctor` for connectivity |
| ⚠️ Web search not working | Configure Brave Search API key (optional, free DuckDuckGo fallback available) |
| 🐙 GitHub operations failing | **v0.4.9**: Use `aii mcp install github` then set `GITHUB_PERSONAL_ACCESS_TOKEN` env var |
| 🔍 GitHub search returns 0 results | **FIXED in v0.4.8 (Oct 9)** - Now returns actual repositories! |
| 🔗 MCP tools not found | **v0.4.9**: Run `aii mcp catalog` to browse available servers, `aii mcp list` to see installed |
| ⚠️ MCP token usage shows 0 | **FIXED in v0.4.9** - Token tracking now accurate for all MCP operations |
| 🐛 Natural language MCP queries show no output | **FIXED in v0.4.9** - Results now display correctly |
| 📊 Duplicate status lines in output | **FIXED in v0.4.9** - Clean single-line status display |

---

## 🔧 Architecture

AII uses LLM-first design with:
- **Intent Recognition**: Natural language → function mapping via LLMs
- **Function Plugins**: 25 extensible functions across 8 categories
- **Multi-Step Orchestration** *(v0.4.8)*: Automatic workflow chaining with intelligent parameter mapping
- **MCP Integration** *(v0.4.8)*: Model Context Protocol for GitHub, filesystem, and extensible tool access
- **Smart Risk Assessment**: Context-aware confirmations
- **Multi-Provider**: Anthropic Claude, OpenAI GPT, Google Gemini
- **Session Persistence**: Conversation memory and metrics

---

## 📚 Links & Resources

- **📦 [PyPI Package](https://pypi.org/project/aiiware-cli)** — Official distribution
- **📖 Documentation** — Comprehensive examples in this README
- **🔄 Releases** — Version history on PyPI

---

## 📄 License & Credits

**License:** Apache 2.0 • Copyright 2025-present aiiware.com

**Built with:**
- [Pydantic AI](https://ai.pydantic.dev/) — Reliable LLM integration framework
- [Anthropic Claude](https://www.anthropic.com/claude) • [OpenAI GPT](https://openai.com/) • [Google Gemini](https://ai.google.dev/)

---

<div align="center">

**Made with ❤️ for developers who want AI-powered assistance without leaving the terminal**

[⬆ Back to top](#aii--ai-powered-terminal-assistant-for-developers)

</div>
