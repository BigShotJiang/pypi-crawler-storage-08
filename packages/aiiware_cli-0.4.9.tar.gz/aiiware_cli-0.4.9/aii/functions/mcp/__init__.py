"""MCP (Model Context Protocol) Functions - Tool invocation from MCP servers"""

from .mcp_functions import MCPToolFunction

__all__ = ["MCPToolFunction"]
