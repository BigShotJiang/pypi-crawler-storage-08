from .mean_average_precision_3d import MeanAveragePrecisionMetric

__all__ = ["MeanAveragePrecisionMetric"]