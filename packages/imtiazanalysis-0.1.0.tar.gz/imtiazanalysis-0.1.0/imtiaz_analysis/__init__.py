# imtiaz_analysis/__init__.py

from .analyze import imtiaz_analyze

__version__ = '0.1.0'