# A display extension for [Calzone][CALZONE]
(**CAL**orimeter **ZONE**)


## License
The source of Calzone's display extension is distributed under the **GNU
LGPLv3** license. See the provided [LICENSE](LICENSE) and
[COPYING.LESSER](COPYING.LESSER) files.


[CALZONE]: https://github.com/niess/calzone
