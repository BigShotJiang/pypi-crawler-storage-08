# coding=utf-8
# Copyright (c) 2025 Jifeng Wu
# Licensed under the MIT License. See LICENSE file in the project root for full license information.
import mimetypes
import sys

from posix_or_nt import posix_or_nt
if posix_or_nt() == 'nt':
    import ntpath as os_path
else:
    import posixpath as os_path

if sys.version_info >= (3, 13):
    def guess_file_mime_type(file_path):
        # type: (str) -> str
        mime_type, _ = mimetypes.guess_file_type(os_path.basename(file_path))
        return mime_type or 'application/octet-stream'
else:
    def guess_file_mime_type(file_path):
        # type: (str) -> str
        mime_type, _ = mimetypes.guess_type(os_path.basename(file_path))
        return mime_type or 'application/octet-stream'