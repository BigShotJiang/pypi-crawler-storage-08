from .core import *

__version__ = "0.1.8.1"
__author__ = "RinLit"
