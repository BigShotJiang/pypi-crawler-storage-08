""" The entry point for the dashboard UI. Uses PyScript. See index.html """

from microlog.dashboard import ui

ui.load()