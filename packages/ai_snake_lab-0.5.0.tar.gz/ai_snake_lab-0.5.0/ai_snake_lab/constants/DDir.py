"""
constants/DDir.py

    AI Snake Game Simulator
    Author: Nadim-Daniel Ghaznavi
    Copyright: (c) 2024-2025 Nadim-Daniel Ghaznavi
    GitHub: https://github.com/NadimGhaznavi/ai
    License: GPL 3.0
"""

from ai_snake_lab.utils.ConstGroup import ConstGroup


class DDir(ConstGroup):
    """Directories"""

    AI_SNAKE_LAB: str = "ai_snake_lab"
    UTILS: str = "utils"
