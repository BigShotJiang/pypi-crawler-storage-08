def _defaultfunc(arg = None):
    pass

onupdate = _defaultfunc
oneventupdate = _defaultfunc

onkeypress = _defaultfunc
onkeydown = _defaultfunc
onkeyup = _defaultfunc

onmouseclicked = _defaultfunc
onmousedown = _defaultfunc
onmousemove = _defaultfunc
onmousescroll = _defaultfunc

onquit = _defaultfunc