# sputility

sputility is a Python tool to interface with System Platform packages (*.aapkg).<br>
It's all preliminary guesswork and likely to change.  Use at your own risk.<br>