from AutoFeedback_grader.test_exercises import studentTest

fname = "221990/u103369_Assignment2.ipynb"

studentTest(fname)