# -*- coding: utf-8 -*-
"""DB集合"""

__all__ = [
    "db",
]