__PKG__ = 'yitool'
__VERSION__ = '0.1.0'
__ENV__ = '/etc/yitech/.env'
