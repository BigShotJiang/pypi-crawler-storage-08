"""
Example usage scripts for LLM-BENCH library.
"""
