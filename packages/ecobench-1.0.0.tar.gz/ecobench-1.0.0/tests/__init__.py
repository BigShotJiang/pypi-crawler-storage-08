"""
Test package for ECO-BENCH library.
"""
