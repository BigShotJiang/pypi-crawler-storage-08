"""Translation Functions - Language translation with auto-detection"""

from .translation_functions import TranslationFunction

__all__ = ["TranslationFunction"]
