Logger Module
---------------------------

.. automodule:: wpt_tools.logger
   :members:
   :undoc-members:
   :show-inheritance: