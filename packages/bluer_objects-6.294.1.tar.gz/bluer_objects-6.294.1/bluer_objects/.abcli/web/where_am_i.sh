#! /usr/bin/env bash

function bluer_objects_web_where_am_i() {
    curl ifconfig.co/json
}
