from bluer_objects import path

# TODO: complete.


def test_path():
    assert True
