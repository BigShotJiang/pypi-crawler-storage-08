# Support

We welcome issues, pull request and feature requests via [Github](https://github.com/mrijken/check-config).
