Modules
*******

.. click:: ape_safe._cli.modules:modules
  :prog: ape safe modules
  :nested: full
