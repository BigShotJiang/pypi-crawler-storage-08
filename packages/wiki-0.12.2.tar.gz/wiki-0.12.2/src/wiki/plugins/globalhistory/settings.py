SLUG = "globalhistory"
