"""
OpenSMILE Pipeline Module
"""

from .engine import OpenSMILEEngine

__all__ = ['OpenSMILEEngine']
