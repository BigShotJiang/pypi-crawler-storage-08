# sage_setup: distribution = sagemath-lcalc
# delvewheel: patch
