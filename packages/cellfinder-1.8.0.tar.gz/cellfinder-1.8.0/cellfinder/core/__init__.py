import logging

logger = logging.getLogger("cellfinder.core")
