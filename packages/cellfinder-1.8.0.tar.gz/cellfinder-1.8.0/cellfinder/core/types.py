from typing import Union

import dask.array as da
import numpy as np

array = Union[da.Array, np.ndarray]
