from .train import training_widget
