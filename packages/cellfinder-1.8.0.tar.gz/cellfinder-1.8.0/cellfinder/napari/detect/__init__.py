from .detect import detect_widget
