from typing import TypeVar

from dandy.processor.agent.plan.task.task import AgentTaskIntel

AgentTaskIntelType = TypeVar('AgentTaskIntelType', bound=AgentTaskIntel)