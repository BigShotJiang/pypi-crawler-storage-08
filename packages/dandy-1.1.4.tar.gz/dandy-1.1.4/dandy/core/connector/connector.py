from abc import ABC


class BaseConnector(ABC):
    pass