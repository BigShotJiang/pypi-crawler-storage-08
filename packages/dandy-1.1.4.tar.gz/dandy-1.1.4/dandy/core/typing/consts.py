TYPE_STRING_TO_ANNOTATION_MAP = {
    'str': str,
    'string': str,
    'int': int,
    'integer': int,
    'float': float,
    'bool': bool,
}
