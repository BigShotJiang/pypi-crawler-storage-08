from typing import TypeVar

from dandy.intel.intel import BaseIntel

IntelType = TypeVar('IntelType', bound=BaseIntel)