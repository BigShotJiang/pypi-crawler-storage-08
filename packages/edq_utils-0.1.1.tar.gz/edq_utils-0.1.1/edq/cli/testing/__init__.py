"""
The edq.cli.testing package provides testing-related utilities.
"""
