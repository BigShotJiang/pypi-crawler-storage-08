# Contributing

We welcome contributions of any type. Totally!

By any means feel free to open an issue or, even better, fork the repo and
submit a pull request.