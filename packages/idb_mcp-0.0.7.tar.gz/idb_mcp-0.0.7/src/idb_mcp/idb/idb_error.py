class IDBError(Exception):
    """Custom exception for IDB related errors."""
