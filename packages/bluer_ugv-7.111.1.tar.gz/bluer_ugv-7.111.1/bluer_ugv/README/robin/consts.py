from bluer_objects.README.consts import assets_url, designs_url


robin_assets2 = assets_url(
    suffix="robin",
    volume=2,
)

robin_design = designs_url("robin")
