"""UI components for the injection server."""
