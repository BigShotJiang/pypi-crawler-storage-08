from django.apps import AppConfig


class DjangoFeaturesAppConfig(AppConfig):
    name = "django_features"
