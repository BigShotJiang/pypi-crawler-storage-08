from django.apps import AppConfig


class SystemMessageAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_features.system_message"
