License to be determined soon. Please contact author before using.
