Cuando se valida una factura, automáticamente genera el registro de
envío para verifactu. Cada minuto se enviarán todos aquellos registros
pendientes de enviar mediante un cron.
