"""
This module imports task modules to qc_lab.tasks.
"""

from qc_lab.tasks.update_tasks import *
from qc_lab.tasks.collect_tasks import *
from qc_lab.tasks.initialization_tasks import *
