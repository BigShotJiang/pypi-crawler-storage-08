"""
PyInstaller 专用模块：配置构建等工具。
"""

from .config_builder import PyInstallerConfigBuilder

__all__ = ["PyInstallerConfigBuilder"]
