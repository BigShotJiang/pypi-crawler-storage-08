"""
UnifyPy - 跨平台Python应用打包工具
"""

__version__ = "2.0.0"
__author__ = "Junsen"
__description__ = "Universal Python Application Packaging Tool"
