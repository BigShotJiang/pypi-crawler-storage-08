from collections import namedtuple

HDF5PluginBuildConfig = namedtuple('HDF5PluginBuildConfig', ('openmp', 'native', 'bmi2', 'sse2', 'ssse3', 'avx2', 'avx512', 'cpp11', 'cpp14', 'cpp20', 'ipp', 'filter_file_extension', 'embedded_filters'))
build_config = HDF5PluginBuildConfig(**{'openmp': False, 'native': False, 'bmi2': False, 'sse2': True, 'ssse3': False, 'avx2': False, 'avx512': False, 'cpp11': True, 'cpp14': True, 'cpp20': True, 'ipp': False, 'filter_file_extension': '.dll', 'embedded_filters': ('blosc', 'blosc2', 'bshuf', 'bzip2', 'fcidecomp', 'lz4', 'sperr', 'sz', 'sz3', 'zfp', 'zstd')})
