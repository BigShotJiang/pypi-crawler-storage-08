"""Setup script for backwards compatibility."""

from setuptools import setup

# This file is kept for backwards compatibility only.
# The actual package configuration is in pyproject.toml
setup()
