# This filename has "double" quotes

This filename is expected to be illegal on Microsoft Windows, unfortunately.