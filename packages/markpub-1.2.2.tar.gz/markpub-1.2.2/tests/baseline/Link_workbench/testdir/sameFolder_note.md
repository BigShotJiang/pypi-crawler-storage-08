# sameFolder note
This note is in the "Link workbench/testdir" folder.
