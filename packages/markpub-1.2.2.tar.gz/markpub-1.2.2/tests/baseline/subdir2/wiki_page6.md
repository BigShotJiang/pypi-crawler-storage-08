# wiki page6
- this is just a test page

(but what if it were an actual wiki page? wait! it is!)
