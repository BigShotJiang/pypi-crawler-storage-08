# Proto files for OpenCue

The `proto` is a module containing the [protobuf](https://protobuf.dev/) (Protocol Buffers) modules for communication to and from Cuebot.