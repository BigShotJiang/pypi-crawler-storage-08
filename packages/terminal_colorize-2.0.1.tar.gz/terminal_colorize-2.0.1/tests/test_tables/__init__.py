"""Test cases for tables module."""
