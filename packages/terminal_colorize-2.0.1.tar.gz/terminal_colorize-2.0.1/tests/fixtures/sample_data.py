"""Sample data for testing."""

SAMPLE_TABLE_DATA = [
    ["Name", "Age", "City"],
    ["Alice", "30", "New York"],
    ["Bob", "25", "San Francisco"],
    ["Charlie", "35", "Los Angeles"],
]

SAMPLE_COLORS = ["red", "green", "blue", "yellow", "magenta", "cyan"]

SAMPLE_TEXT = "The quick brown fox jumps over the lazy dog"
