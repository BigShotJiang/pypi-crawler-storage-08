# noinspection PyUnusedImports
from ._tmf import has_gdal, get_driver_name_from_extension
