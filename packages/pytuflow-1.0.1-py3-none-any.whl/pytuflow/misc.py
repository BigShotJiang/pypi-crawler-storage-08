# noinspection PyUnusedImports
from ._tmf import AppendDict
