# Changelog

## 1.2.0

- No user-facing changes.

## 1.1.0

- Extends support to Python versions `3.10` and `3.11`.

## 1.0.0

- Adds pytester tests for the `pytest`-plugin.

## 0.2.0

- Fixes `crosszip_parametrize` marker for `pytest` plugin. There was a bug in the implementation that caused the marker to not be recognized by `pytest`.

## 0.1.0

- Initial release of `crosszip` package.
