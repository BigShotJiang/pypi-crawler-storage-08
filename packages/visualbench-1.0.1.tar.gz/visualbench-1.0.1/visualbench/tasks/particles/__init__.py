from .colors import ColoredParticles
from .closest_furthest import ClosestFurthestParticles
from .ratio import ParticleDistanceRatio
from .heilbronn import HeilbronnTrianglesProblem
from .maximize_angle import MaximizeSmallestAngle