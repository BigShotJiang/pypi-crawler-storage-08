from .projected_descent import (
    Ackley,
    BumpyBowl,
    ChebushevRosenbrock,
    NeuralNet,
    ProjectedFunctionDescent,
    Rastrigin,
    Rosenbrock,
    RotatedQuadratic,
)
