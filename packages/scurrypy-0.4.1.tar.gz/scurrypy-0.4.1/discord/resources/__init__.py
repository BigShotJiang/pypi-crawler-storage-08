# discord/resources
