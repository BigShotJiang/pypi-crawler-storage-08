from mindee.product.fr.bank_account_details.bank_account_details_v1 import (
    BankAccountDetailsV1,
)
from mindee.product.fr.bank_account_details.bank_account_details_v1_document import (
    BankAccountDetailsV1Document,
)
from mindee.product.fr.bank_account_details.bank_account_details_v2 import (
    BankAccountDetailsV2,
)
from mindee.product.fr.bank_account_details.bank_account_details_v2_bban import (
    BankAccountDetailsV2Bban,
)
from mindee.product.fr.bank_account_details.bank_account_details_v2_document import (
    BankAccountDetailsV2Document,
)
