from mindee.product.ind.indian_passport.indian_passport_v1 import IndianPassportV1
from mindee.product.ind.indian_passport.indian_passport_v1_document import (
    IndianPassportV1Document,
)
