from mindee.product.passport.passport_v1 import PassportV1
from mindee.product.passport.passport_v1_document import (
    PassportV1Document,
)
