from mindee.product.generated.generated_v1 import (
    GeneratedV1,
    GeneratedV1Document,
    GeneratedV1Page,
)
