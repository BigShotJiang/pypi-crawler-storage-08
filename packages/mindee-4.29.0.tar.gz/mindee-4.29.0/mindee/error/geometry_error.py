class GeometryError(RuntimeError):
    """An error related to geometry operations."""
