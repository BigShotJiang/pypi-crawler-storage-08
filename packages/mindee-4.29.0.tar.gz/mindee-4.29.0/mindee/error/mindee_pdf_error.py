class MindeePDFError(RuntimeError):
    """An exception relating to errors during PDF operations."""
