class MindeeImageError(RuntimeError):
    """An exception relating to errors during image operations."""
