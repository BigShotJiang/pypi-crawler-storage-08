"""
Contains key exceptions for pipeline execution control.
"""

from ._exceptions import SkipItem as SkipItem
from ._exceptions import StopPipeline as StopPipeline