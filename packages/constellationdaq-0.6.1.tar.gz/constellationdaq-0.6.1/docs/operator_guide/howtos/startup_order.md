# Configuring a Startup Order

This how-to guide walks through steps required to configure a startup order of satellites in a Constellation.

```{seealso}
The concept of autonomous transitions is described in the [concepts section](../concepts/autonomy.md#conditional-transitions)
```

TODO
