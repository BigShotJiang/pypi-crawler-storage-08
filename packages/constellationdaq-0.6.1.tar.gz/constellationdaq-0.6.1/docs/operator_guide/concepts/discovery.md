# Network Discovery

* brief CHIRP description
* mention of firewalls, link to FAQ
*

```{seealso}
A detailed technical description, including protocol sequence diagrams, can be found in the
[protocol description chapter](../../framework_reference/protocols.md#network-discovery) in the framework development guide.
```
