CHIRP Module
=================

.. automodule:: core.chirp
   :members:
   :undoc-members:
   :show-inheritance:
