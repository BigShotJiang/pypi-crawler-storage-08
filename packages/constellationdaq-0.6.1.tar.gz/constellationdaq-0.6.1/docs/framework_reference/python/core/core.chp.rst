CHP Module
===============

.. automodule:: core.chp
   :members:
   :undoc-members:
   :show-inheritance:
