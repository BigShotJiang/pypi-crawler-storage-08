CHIRPManager module
========================

.. automodule:: core.chirpmanager
   :members:
   :undoc-members:
   :show-inheritance:
