TransmitterSatellite module
===========================

.. automodule:: core.transmitter_satellite
   :members:
   :show-inheritance:
   :undoc-members:
