FSM Module
===============

.. automodule:: core.fsm
   :members:
   :undoc-members:
   :show-inheritance:
