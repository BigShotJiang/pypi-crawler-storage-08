Exceptions module
=================

.. automodule:: core.message.exceptions
   :members:
   :show-inheritance:
   :undoc-members:
