Message module
==============

Module contents
---------------

.. automodule:: core.message
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

.. toctree::
   :maxdepth: 1

   core.message.cdtp2
   core.message.cscp1
   core.message.exceptions
   core.message.msgpack_helpers
   core.message.multipart
