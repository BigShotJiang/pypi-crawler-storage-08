CSCP1 module
============

.. automodule:: core.message.cscp1
   :members:
   :show-inheritance:
   :undoc-members:
