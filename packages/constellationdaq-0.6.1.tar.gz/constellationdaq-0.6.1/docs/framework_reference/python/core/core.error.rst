Error Module
=================

.. automodule:: core.error
   :members:
   :undoc-members:
   :show-inheritance:
