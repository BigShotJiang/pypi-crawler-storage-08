CDTP2 module
============

.. automodule:: core.message.cdtp2
   :members:
   :show-inheritance:
   :undoc-members:
