Base Module
================

.. automodule:: core.base
   :members:
   :undoc-members:
   :show-inheritance:
