# Controller

## `constellation::controller` Namespace

```{doxygennamespace} constellation::controller
:content-only:
:members:
:protected-members:
:undoc-members:
```
