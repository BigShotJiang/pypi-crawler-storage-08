# Heartbeat Protocol Implementation

## `constellation::heartbeat` Namespace

```{doxygennamespace} constellation::heartbeat
:content-only:
:members:
:protected-members:
:undoc-members:
```
