# Configuration

## `constellation::config` Namespace

```{doxygennamespace} constellation::config
:content-only:
:members:
:protected-members:
:undoc-members:
```
