# Pools

## `constellation::pools` Namespace

```{doxygennamespace} constellation::pools
:content-only:
:members:
:protected-members:
:undoc-members:
```
