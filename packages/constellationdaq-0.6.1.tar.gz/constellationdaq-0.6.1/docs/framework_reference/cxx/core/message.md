# Messages

## `constellation::message` Namespace

```{doxygennamespace} constellation::message
:content-only:
:members:
:protected-members:
:undoc-members:
```
