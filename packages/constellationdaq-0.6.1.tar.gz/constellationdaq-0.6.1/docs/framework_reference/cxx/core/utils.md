# Utilities

## `constellation::utils` Namespace

```{doxygennamespace} constellation::utils
:content-only:
:members:
:protected-members:
:undoc-members:
```
