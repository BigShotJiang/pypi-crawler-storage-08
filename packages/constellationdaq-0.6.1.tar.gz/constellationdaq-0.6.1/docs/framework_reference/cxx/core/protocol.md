# Protocols

## `constellation::protocol` Namespace

```{doxygennamespace} constellation::protocol
:content-only:
:members:
:protected-members:
:undoc-members:
```

## `constellation::protocol::CSCP` Namespace

```{doxygennamespace} constellation::protocol::CSCP
:content-only:
:members:
:protected-members:
:undoc-members:
```

## `constellation::protocol::CHP` Namespace

```{doxygennamespace} constellation::protocol::CHP
:content-only:
:members:
:protected-members:
:undoc-members:
```
