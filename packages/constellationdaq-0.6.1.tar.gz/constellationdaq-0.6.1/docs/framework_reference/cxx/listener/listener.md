# Listener

## `constellation::listener` Namespace

```{doxygennamespace} constellation::listener
:content-only:
:members:
:protected-members:
:undoc-members:
```
