<!-- markdownlint-disable MD041 -->
### Metrics inherited from `Satellite`

None
