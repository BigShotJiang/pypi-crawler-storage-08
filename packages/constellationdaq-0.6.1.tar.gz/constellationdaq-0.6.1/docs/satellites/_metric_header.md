<!-- markdownlint-disable MD041 -->
## Framework Metrics

This satellite inherits the following framework metrics from its base classes:
