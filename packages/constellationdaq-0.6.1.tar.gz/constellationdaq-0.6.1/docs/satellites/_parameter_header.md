<!-- markdownlint-disable MD041 -->
## Framework Parameters

This satellite inherits the following framework parameters from its base classes:
