<!-- markdownlint-disable MD041 -->
### Metrics inherited from `ReceiverSatellite`

| Metric | Description | Value Type | Metric Type | Interval |
|--------|-------------|------------|-------------|----------|
| `RX_BYTES` | Amount of bytes received from all transmitters during current run | Integer | `LAST_VALUE` | 10s |
