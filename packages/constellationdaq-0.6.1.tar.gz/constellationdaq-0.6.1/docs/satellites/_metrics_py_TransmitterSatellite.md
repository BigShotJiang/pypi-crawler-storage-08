<!-- markdownlint-disable MD041 -->
### Metrics inherited from `DataSender`

| Metric | Description | Value Type | Metric Type | Interval |
|--------|-------------|------------|-------------|----------|
| `TX_BYTES` | Amount of bytes transmitted during current run | Integer | `LAST_VALUE` | 10s |
| `TX_RECORDS` | Number of data records transmitted during current run | Integer | `LAST_VALUE` | 10s |
