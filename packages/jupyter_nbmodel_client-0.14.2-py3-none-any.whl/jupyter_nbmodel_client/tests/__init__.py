# Copyright (c) 2023-2024 Datalayer, Inc.
#
# BSD 3-Clause License

"""Python unit tests for jupyter_nbmodel_client."""
