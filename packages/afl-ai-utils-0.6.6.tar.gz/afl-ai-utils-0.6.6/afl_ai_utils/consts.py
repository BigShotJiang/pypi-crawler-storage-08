min_wait_time =  1
max_wait_time = 3