class FootprintData(object):
    def __init__(self, unique_id, hits):
        self.uniqueId = unique_id
        self.hits = hits
