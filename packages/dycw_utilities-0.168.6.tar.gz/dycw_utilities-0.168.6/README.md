[![PyPI version](https://badge.fury.io/py/dycw-utilities.svg)](https://badge.fury.io/py/dycw-utilities)

# `dycw-utilities`

[All the Python functions I don't want to write twice.](https://github.com/nvim-lua/plenary.nvim)

## Installation

- `pip install dycw-utilities`

or with [extras](https://github.com/dycw/python-utilities/blob/master/pyproject.toml).
