from faststream._internal.cli.main import cli

__all__ = ("cli",)
