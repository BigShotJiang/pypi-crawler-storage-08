from faststream.confluent.opentelemetry.middleware import KafkaTelemetryMiddleware

__all__ = ("KafkaTelemetryMiddleware",)
