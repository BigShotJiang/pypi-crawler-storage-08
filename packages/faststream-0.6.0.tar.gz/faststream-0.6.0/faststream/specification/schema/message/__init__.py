from .model import Message

__all__ = ("Message",)
