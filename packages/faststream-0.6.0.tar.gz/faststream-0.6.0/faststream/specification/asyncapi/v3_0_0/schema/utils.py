from faststream.specification.asyncapi.v2_6_0.schema import Parameter, Reference

__all__ = (
    "Parameter",
    "Reference",
)
