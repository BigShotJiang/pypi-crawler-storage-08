from faststream.specification.asyncapi.v2_6_0.schema import ExternalDocs

__all__ = ("ExternalDocs",)
