from faststream.nats.opentelemetry.middleware import NatsTelemetryMiddleware

__all__ = ("NatsTelemetryMiddleware",)
