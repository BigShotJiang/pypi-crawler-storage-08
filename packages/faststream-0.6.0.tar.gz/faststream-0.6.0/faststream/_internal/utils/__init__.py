from fast_depends import inject as apply_types

from .functions import to_async

__all__ = (
    "apply_types",
    "to_async",
)
