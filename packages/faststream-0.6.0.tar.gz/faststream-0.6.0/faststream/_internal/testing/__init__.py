from faststream._internal.testing.app import TestApp

__all__ = ("TestApp",)
