from faststream.rabbit.prometheus.middleware import RabbitPrometheusMiddleware

__all__ = ("RabbitPrometheusMiddleware",)
