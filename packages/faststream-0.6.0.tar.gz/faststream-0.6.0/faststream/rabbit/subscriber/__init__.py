from .usecase import RabbitSubscriber

__all__ = ("RabbitSubscriber",)
