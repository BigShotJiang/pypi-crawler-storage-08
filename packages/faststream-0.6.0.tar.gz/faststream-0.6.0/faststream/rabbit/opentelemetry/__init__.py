from faststream.rabbit.opentelemetry.middleware import RabbitTelemetryMiddleware

__all__ = ("RabbitTelemetryMiddleware",)
