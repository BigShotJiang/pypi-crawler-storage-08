from faststream.redis.opentelemetry.middleware import RedisTelemetryMiddleware

__all__ = ("RedisTelemetryMiddleware",)
