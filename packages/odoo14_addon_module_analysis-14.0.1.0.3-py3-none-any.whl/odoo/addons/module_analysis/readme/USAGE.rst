* Go to 'Apps' / 'Module Analysis' / 'Installed module by Types'

Open the stats to analyse the detail of the code installed

    .. image:: ../static/description/analysis_pivot.png

    .. image:: ../static/description/analysis_pie.png
