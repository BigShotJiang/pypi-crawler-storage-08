To use this module, you have to install the ``pygount`` python librairy.

``pip install pygount``
