```
fetch-datasets --input input.txt/input.yml --where Eurasia
```
