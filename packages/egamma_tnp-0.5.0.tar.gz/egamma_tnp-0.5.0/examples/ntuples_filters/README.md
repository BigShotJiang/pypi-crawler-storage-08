```
run-analysis \
    --config config_nd.json/config_1d.json \
    --settings settings.json \
    --fileset fileset.json \
    --executor distributed \
    --preprocess
```
