from __future__ import annotations

from egamma_tnp.config.binning_manager import Binning

binning = Binning()

__all__ = ("binning",)


def dir():
    return __all__
