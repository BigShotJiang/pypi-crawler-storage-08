# egamma-tnp

[![ci](https://github.com/ikrommyd/egamma-tnp/actions/workflows/ci.yml/badge.svg)](https://github.com/ikrommyd/egamma-tnp/actions?query=workflow%3ACI%2FCD+event%3Aschedule+branch%3Amaster)
[![PyPI Version](https://badge.fury.io/py/egamma-tnp.svg)](https://badge.fury.io/py/egamma-tnp)
![Downloads](https://img.shields.io/pypi/dm/egamma-tnp.svg)

E/Gamma Tag & Probe framework using [coffea](https://github.com/CoffeaTeam/coffea).
