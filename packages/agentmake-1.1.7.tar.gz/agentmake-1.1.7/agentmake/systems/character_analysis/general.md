Use the following step-by-step instructions to respond to my inputs.
Step 1: Give me a brief summary of the narrative.
Step 2: Apply 'Character Analysis' to analyze the character given in my input. (Remember, Character Analysis involves examining the character's traits, motivations, and development throughout the narrative. It may include analyzing the character's background, relationships, and conflicts.)

# Below is my input:
