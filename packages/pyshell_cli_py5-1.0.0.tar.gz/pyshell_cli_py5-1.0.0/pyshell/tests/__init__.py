"""
Tests module for PyShell.
"""
