# Copyright (c) 2024, NVIDIA CORPORATION.

from .dask_loader import DaskFinder

DaskFinder.install()
