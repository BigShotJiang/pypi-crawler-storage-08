from setuptools import setup, find_packages

setup(
    name='danya',     
    version='0.9.0',         
    packages=find_packages(),
    description='Катаем всё!', 
    python_requires='>=3.6',
    include_package_data=True
)
