"""Adaptive Oscillator."""

__version__ = "0.1.0"
__author__ = "Tony Smoragiewicz"
__email__ = "tony.smoragiewicz@tum.de"
