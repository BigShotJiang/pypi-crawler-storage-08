"""Classification formats for PlasBin-flow."""
