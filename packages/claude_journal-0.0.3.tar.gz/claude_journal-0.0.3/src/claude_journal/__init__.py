# ABOUTME: Main package for claude-journal MCP server
# ABOUTME: Provides journaling capabilities for Claude Code
