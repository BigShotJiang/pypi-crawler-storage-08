import os
from mcp.server.fastmcp import FastMCP

# 创建MCP服务器实例
# 关键修复1：服务器名称必须与服务配置中的键名 "bmi-calculator-mcp" 完全匹配
mcp = FastMCP("bmi-calculator-mcp")

@mcp.tool()
def calculate_bmi(height: float, weight: float) -> str:
    """计算BMI值并返回健康状况评估
    
    参数:
        height: 身高（米）
        weight: 体重（千克）
    
    返回:
        BMI计算结果和健康状况评估
    """
    try:
        # 验证输入
        if height <= 0 or weight <= 0:
            return "错误：身高和体重必须为正数"
            
        # 计算BMI
        bmi = weight / (height * height)
        
        # 评估健康状况
        if bmi < 18.5:
            status = "体重过轻"
        elif bmi < 24:
            status = "体重正常"
        elif bmi < 28:
            status = "超重"
        else:
            status = "肥胖"
            
        return f"BMI值：{bmi:.1f}\n健康状况：{status}"
        
    except Exception as e:
        return f"计算出错：{str(e)}"

def main():
    """MCP 服务器入口点"""
    # 关键修复2：为云端托管配置网络监听模式
    # 云平台通常通过 PORT 环境变量指定监听端口
    port = int(os.environ.get("PORT", 8000))
    print(f"BMI Calculator MCP Server starting on port {port}...")
    # 使用 host="0.0.0.0" 监听所有网络接口
    mcp.run(host="0.0.0.0", port=port)

if __name__ == "__main__":
    # 本地测试时，可以手动运行此脚本，它会默认监听 8000 端口
    main()
