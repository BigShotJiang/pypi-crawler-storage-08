Go to any model that contains a chatter (e.g. Contacts, ...). Search for
content in field 'Message Content'.
