This module creates the GIN (trigram) indexes for these fields of mail.message: subject, body, record_name, email_from, reply_to.
