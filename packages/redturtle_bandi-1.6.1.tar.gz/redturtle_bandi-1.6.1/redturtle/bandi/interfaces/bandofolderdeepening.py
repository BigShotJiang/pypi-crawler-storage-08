from zope.interface import Interface


# -*- Additional Imports Here -*-


class IBandoFolderDeepening(Interface):
    """A folder that is handled in a special way by Bando."""

    # -*- schema definition goes here -*-
