from plone.supermodel import model


class IBandoFolderDeepeningSchema(model.Schema):
    pass
