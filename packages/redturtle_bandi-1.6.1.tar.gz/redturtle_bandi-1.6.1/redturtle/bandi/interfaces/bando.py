# -*- coding: utf-8 -*-
from zope.interface import Interface


class IBando(Interface):
    """Bando"""
