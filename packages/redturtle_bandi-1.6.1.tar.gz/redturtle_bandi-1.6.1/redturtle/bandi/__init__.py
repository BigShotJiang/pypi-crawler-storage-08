"""Main product initializer"""

from zope.i18nmessageid import MessageFactory

import logging


logger = logging.getLogger("redturtle.bandi")
bandiMessageFactory = MessageFactory("redturtle.bandi")
_ = bandiMessageFactory
