"""UiPath mocking framework."""
