from meomaya.cli.meomaya_cmd import main

if __name__ == "__main__":
    main()
