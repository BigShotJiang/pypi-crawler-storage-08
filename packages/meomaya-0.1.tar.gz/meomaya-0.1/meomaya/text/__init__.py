from .pipeline import TextPipeline

__all__ = ["TextPipeline"]
