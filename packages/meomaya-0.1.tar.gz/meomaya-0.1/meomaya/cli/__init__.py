from .meomaya_cmd import main

__all__ = ["main"]
