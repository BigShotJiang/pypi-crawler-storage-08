__version__ = "2.16.0"


def get_version() -> str:
    """
    Returns the current version of this lib
    """
    return __version__
