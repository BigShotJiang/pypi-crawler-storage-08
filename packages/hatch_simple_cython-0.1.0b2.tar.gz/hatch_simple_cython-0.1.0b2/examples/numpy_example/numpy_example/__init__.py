"""NumPy example package."""

from numpy_example.array_ops import sum_array, multiply_arrays

__all__ = ["sum_array", "multiply_arrays"]
