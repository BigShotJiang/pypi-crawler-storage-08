"""Creates a measurement client through use of __init__.py."""

from ni_measurement_plugin_sdk_generator.client import create_client

create_client()
