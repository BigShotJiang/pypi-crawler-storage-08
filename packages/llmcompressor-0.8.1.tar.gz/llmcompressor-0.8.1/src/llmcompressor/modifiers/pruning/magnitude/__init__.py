# ruff: noqa

from .base import MagnitudePruningModifier
