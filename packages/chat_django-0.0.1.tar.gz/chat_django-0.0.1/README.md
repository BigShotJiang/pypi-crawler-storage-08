# chat-django

A placeholder package to reserve the name `chat-django`.

## Installation

```bash
pip install chat-django
```

## License

MIT
