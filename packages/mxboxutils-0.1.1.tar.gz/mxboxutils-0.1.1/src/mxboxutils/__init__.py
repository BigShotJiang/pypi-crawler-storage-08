from .. import mx

name = __name__
version = mx.__version__
