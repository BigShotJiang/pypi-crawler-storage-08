function(doc) {
   emit([doc.request, doc.identifier, doc.thr, doc.type], null); 
}
