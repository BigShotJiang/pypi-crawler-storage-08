# -*- coding: utf-8 -*-

extensions = [
    'jupyterlite_sphinx'
]

master_doc = 'index'
source_suffix = '.rst'

project = 'jupyterlab-filesystem-access'
copyright = 'JupyterLab Contrib Team'
author = 'JupyterLab Contrib Team'

jupyterlite_silence = False

exclude_patterns = []

html_theme = "pydata_sphinx_theme"
