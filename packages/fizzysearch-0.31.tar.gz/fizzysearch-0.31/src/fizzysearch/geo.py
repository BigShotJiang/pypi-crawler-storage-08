# See: https://github.com/asg017/sqlite-tg/blob/main/docs.md
