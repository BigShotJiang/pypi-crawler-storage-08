"""
This module imports task modules to qclab.tasks.
"""

from qclab.tasks.update_tasks import *
from qclab.tasks.collect_tasks import *
from qclab.tasks.initialization_tasks import *
