from modelconverter.packages.rvc2.inferer import RVC2Inferer as RVC3Inferer

__all__ = ["RVC3Inferer"]
