Index
=====

.. toctree::
   :maxdepth: 2

   cli
   py_api
   changelog
   self
