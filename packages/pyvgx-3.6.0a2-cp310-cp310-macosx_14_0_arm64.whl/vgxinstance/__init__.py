import sys
from . import vgxinstance as _vgxinstance
sys.modules[__name__] = _vgxinstance