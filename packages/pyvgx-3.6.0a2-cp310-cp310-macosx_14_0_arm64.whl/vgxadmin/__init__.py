import sys
from . import vgxadmin as _vgxadmin
sys.modules[__name__] = _vgxadmin