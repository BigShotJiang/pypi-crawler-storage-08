/*
 * libhello.c - The hello library
 */
#include <stdio.h>

void hello(const char *person)
{
  printf("Good morning %s\n", person);
}
