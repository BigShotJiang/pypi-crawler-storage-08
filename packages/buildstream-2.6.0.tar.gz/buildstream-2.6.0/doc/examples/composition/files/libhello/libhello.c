/*
 * libhello.c - The hello library
 */
#include <stdio.h>

void hello(const char *person)
{
  printf("Hello %s\n", person);
}
