/*
 * libhello.h - The hello library
 */

/*
 * A function to say hello to @person
 */
void hello(const char *person);
