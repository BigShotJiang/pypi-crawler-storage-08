#!/bin/sh
echo "Calling hello:"
hello
