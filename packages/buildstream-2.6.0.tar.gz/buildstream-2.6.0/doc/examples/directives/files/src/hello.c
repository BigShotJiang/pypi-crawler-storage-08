/*
 * hello.c - Simple hello world program
 */
#include <stdio.h>

int main(int argc, char *argv[])
{
  printf(GREETING_MESSAGE);
  return 0;
}
