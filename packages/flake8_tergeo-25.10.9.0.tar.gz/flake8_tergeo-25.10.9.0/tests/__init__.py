"""Tests for flake8-tergeo."""

from __future__ import annotations
