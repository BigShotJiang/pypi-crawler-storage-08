"""Tests for _flake8_tergeo.checks."""

from __future__ import annotations
