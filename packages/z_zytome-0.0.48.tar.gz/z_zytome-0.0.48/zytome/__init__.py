"""zytome"""

__version__ = "0.0.48"
__author__ = "Marko Zolo Gozano Untalan"
