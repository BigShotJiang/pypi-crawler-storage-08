import os

GAME_ASSETS_BASE = os.path.dirname(__file__)
