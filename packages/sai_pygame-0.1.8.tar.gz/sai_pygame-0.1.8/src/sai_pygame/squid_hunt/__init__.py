from .squid_hunt import SquidHuntEnv

__all__ = ["SquidHuntEnv"]
