# API utilities for EO4EU

This package provides a client class that enables access to the EO4EU API. Furthermore, use case specific functions are provided for ease of testing.  

The current package is unstable. New documentation will be provided once the package stabilizes.
