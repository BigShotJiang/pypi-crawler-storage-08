"""TastyTrade MCP Server package."""

__version__ = "1.4.1"
__author__ = "TastyTrade MCP Team"
__license__ = "MIT"