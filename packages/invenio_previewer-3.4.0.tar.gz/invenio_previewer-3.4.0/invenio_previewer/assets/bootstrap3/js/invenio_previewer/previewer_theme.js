/*
 * This file is part of Invenio.
 * Copyright (C) 2020 CERN.
 *
 * Invenio is free software; you can redistribute it and/or modify it
 * under the terms of the MIT License; see LICENSE file for more details.
 */

import "jquery/dist/jquery.js";
import "bootstrap/dist/js/bootstrap.js";

import "@scss/invenio_previewer/style.scss";
