=======
Credits
=======

Development Lead
----------------

* Alexandre Refregier

Contributors
------------

* Joel Akeret, Adam Amara, Janis Fluri, Lukas Gamper, Lavinia Heisenberg, Jörg Herbel,
  Tomasz Kacprzak, Christiane S. Lorenz, Beatrice Moser, Andrina Nicola, Uwe
  Schmitt, Raphael Sgier, Federica Tarsitano

Contact information
-------------------

If you have any suggestions or questions about PyCosmo feel free to email us
at pycosmo@lists.phys.ethz.ch.
