void sici(double, double*, double*);
void sicif(float, float*, float*);
