dict_of_parts = {
    "dc-motor-12-VDC-45W": "type 2, 2 x right + 2 x left",
    "SLA-Battery": "",
    "wheel": "4 x ",
    "on-off-switch": "",
    "charging-port": "",
    "connector": "4 pairs",
}
