#!/bin/bash
chatterlang_serve --form-config story_by_example_ui.yml --display-property example --script Step_2_SearchByExample.script