#!/bin/bash
chatterlang_script --script Step_1_CreateVectorDatabase.script 
