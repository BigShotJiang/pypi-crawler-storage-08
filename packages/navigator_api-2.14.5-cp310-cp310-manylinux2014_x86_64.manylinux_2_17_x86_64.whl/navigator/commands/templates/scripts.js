/*!
 * javascript configuration for Navigator Template
 *
 * Copyright 2015–2020, Jesus Lara
 * Dual licensed under the APACHE or BSD licenses.
 *
 * Depends:
 *  Coffe and coding
 */
