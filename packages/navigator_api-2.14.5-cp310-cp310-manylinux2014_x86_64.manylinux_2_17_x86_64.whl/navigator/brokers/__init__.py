"""Navigator Broker.

Producer/Consumer broker Functionality, using RabbitMQ or AWS SQS as the message broker.
"""
