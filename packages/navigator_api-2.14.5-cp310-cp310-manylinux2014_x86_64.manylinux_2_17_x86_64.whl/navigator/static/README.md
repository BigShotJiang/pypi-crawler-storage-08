Add some static resources here.
