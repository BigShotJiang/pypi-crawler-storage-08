"""
Extensions Folder.

All integrated extensions come here.
"""
