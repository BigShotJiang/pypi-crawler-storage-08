from .client import Maniac

__all__ = ["Maniac"]
