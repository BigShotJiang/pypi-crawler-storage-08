from snowfakery import cli

cli.generate_cli.main(prog_name="snowfakery")
