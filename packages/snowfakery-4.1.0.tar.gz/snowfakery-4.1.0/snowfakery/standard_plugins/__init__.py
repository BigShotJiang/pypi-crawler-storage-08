from ._math import Math  # noqa
