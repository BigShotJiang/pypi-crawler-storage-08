from __future__ import annotations

"""SearchTheArXiv tool package for semantic literature search (stub)."""

__all__ = []