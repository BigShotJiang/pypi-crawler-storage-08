"""
© Ocado Group
Created on 24/01/2024 at 13:52:02(+00:00).
"""

from .klass import ClassViewSet
from .school import SchoolViewSet
from .user import UserViewSet
