"""
© Ocado Group
Created on 05/11/2024 at 14:40:32(+00:00).
"""

from .drf import BaseRequest, Request
from .http import BaseHttpRequest, HttpRequest
from .wsgi import BaseWSGIRequest, WSGIRequest
