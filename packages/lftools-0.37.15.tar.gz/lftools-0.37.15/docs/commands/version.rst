*******
Version
*******

.. program-output:: lftools version --help

Commands
========

.. contents:: Version Commands
    :local:

bump
----

.. program-output:: lftools version bump --help

patch
-----

.. program-output:: lftools version patch --help

release
-------

.. program-output:: lftools version release --help
