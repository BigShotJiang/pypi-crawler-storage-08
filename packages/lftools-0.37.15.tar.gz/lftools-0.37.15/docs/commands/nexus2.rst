.. _nexus2:

******
Nexus3
******

.. program-output:: lftools nexus2 --help

.. _nexus2_commands:

Commands
========

.. contents:: Nexus2 Commands
    :local:

.. _nexus2_privileges:

privilege
---------

.. program-output:: lftools nexus2 privilege --help

.. _nexus2_repository:

repository
----------

.. program-output:: lftools nexus2 repository --help

.. _nexus2_role:

role
----

.. program-output:: lftools nexus2 role --help

.. _nexus2_user:

user
----

.. program-output:: lftools nexus2 user --help
