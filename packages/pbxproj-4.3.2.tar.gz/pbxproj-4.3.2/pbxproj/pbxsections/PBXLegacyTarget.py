from pbxproj.pbxsections.PBXGenericTarget import PBXGenericTarget


class PBXLegacyTarget(PBXGenericTarget):
    pass
