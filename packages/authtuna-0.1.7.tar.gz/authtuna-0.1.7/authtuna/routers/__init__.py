from authtuna.routers.auth import router as auth_router
from authtuna.routers.social import router as social_router
from authtuna.routers.mfa import router as mfa_router
from authtuna.routers.admin import router as admin_router
from authtuna.routers.ui import router as ui_router
