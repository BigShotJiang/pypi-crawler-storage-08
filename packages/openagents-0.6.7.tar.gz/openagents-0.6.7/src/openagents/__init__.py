"""OpenAgents - A flexible framework for building multi-agent systems with customizable protocols."""

__version__ = "0.6.7"
