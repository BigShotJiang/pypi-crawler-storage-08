"""Project mods for OpenAgents framework."""

from . import default

__all__ = ["default"]
