package main

import (
	"testing"
)

func TestMain(test *testing.T) {
	test.Parallel()

	main()
}
