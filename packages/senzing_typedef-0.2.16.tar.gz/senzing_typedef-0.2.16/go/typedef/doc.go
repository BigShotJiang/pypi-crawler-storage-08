/*
Package typedef defines message fields and is generated from senzingsdk-RFC8927.json.
*/
package typedef
