# sz-sdk-json-type-definition examples

## Run main

1. Go

    ```console
    cd ${GIT_REPOSITORY_DIR}
    go run main.go

    ```

1. Python

    ```console
    cd ${GIT_REPOSITORY_DIR}
    ./main.py

    ```
