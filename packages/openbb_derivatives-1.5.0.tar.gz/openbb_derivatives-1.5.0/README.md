# OpenBB Derivatives Extension

This extension provides derivatives data for the OpenBB Platform.

## Installation

To install the extension, run the following command in this folder:

```bash
pip install openbb-derivatives
```

Documentation available [here](https://docs.openbb.co/sdk).
