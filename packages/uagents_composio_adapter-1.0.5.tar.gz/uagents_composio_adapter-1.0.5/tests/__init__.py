"""Tests for uagents-composio-adapter package."""
