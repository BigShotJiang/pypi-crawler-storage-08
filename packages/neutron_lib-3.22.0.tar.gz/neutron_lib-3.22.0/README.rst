===========
neutron-lib
===========

.. image:: https://governance.openstack.org/tc/badges/neutron-lib.svg

.. Change things from this point on

Neutron shared routines and utilities.

* Free software: Apache license
* Documentation: https://docs.openstack.org/neutron-lib/latest/
* Source: https://opendev.org/openstack/neutron-lib
* Bugs: https://bugs.launchpad.net/neutron
* Release notes: https://docs.openstack.org/releasenotes/neutron-lib/
