"""TastyTrade MCP Server package."""

__version__ = "0.1.0"
__author__ = "TastyTrade MCP Team"
__license__ = "MIT"