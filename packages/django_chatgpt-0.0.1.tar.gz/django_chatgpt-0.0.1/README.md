# django-chatgpt

A placeholder package to reserve the name `django-chatgpt`.

## Installation

```bash
pip install django-chatgpt
```

## License

MIT
