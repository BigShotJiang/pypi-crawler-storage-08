"""Support Vector Machine matching algorithm for nomenklatura."""

from .model import SVMV1

__all__ = ["SVMV1"]