
| Method | Method Options |
|--------|----------------|
|[mads](https://nomad-4-user-guide.readthedocs.io/en/latest/Appendix.html#complete-list-of-parameters)|BB_OUTPUT_TYPE, BB_MAX_BLOCK_SIZE, MAX_BB_EVAL, MAX_EVAL, SEED, LH_SEARCH, DISPLAY_ALL_EVAL, DISPLAY_DEGREE, DISPLAY_STATS|
