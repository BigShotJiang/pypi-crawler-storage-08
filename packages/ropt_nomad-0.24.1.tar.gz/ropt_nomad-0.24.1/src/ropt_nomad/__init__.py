"""This package implements a plugin for ropt to use optimizers from NOMAD."""
