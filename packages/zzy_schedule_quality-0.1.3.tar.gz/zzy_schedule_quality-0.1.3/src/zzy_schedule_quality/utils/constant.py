DOMAIN = 'https://cm.aizzyun.com'

QUALITY_RECTIFICATION = '/bsp/user/ugs/bps/api/quality/qualityRectificationRecord'

#质量整改相关
QUALITY_RECTIFICATION_LIST_URL = DOMAIN + QUALITY_RECTIFICATION + '/queryQualityRectificationRecord'
QUALITY_RECTIFICATION_DETAIL_URL = DOMAIN + QUALITY_RECTIFICATION + '/queryRecordById/'
QUALITY_RECTIFICATION_ADD = DOMAIN + QUALITY_RECTIFICATION + '/saveQualityRectificationRecordList'
