from .fast_dataclasses import FastDataclass, dumps, loads, register_dataclass

__all__ = ["FastDataclass", "dumps", "loads", "register_dataclass"]
