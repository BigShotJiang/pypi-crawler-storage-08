# Disclaimer

This linter is heavily opinionated, and it’s perfectly fine to decide on a per-project basis to ignore certain rules.

We provide both a global exclusion policy and a per-file exclusion policy, allowing you to fine-tune the behavior and
get the most out of this linter.

> If one rule doesn't suit you, ignore it 👌
