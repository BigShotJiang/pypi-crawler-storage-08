# Abstract classes inherit from "abc.ABC" (PBR006)

Python provides a base class for abstract classes. If a class is named "abstract", it should therefore inherit from
the `abc.ABC` class.
