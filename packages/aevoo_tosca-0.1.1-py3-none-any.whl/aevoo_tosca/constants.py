import string

CHAR_ALLOWED = set(string.ascii_lowercase + string.digits + "_" + "-")

PRICE_UNIT_TIME = ("per_hour", "per_month")
