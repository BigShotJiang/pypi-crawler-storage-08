from aevoo_tosca.v2.common.default_base_model import DefaultBaseModel


class InterfaceMapping(DefaultBaseModel):
    pass
