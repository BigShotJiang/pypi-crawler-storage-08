from .requirement import RequirementAssignment
