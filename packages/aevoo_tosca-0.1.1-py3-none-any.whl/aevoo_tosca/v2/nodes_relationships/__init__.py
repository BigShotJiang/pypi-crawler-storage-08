from .capabilities_requirements import RequirementAssignment
from .node import NodeTemplate
