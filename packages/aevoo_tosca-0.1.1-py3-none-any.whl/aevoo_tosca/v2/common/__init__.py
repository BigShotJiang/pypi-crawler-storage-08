from .common_type import CommonType
