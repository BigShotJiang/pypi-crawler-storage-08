# kdp-python-connector

Python Connector for KDP Platform

## Prequisites
* Python version 3.9.x or Python version 3.10.x

## Examples

For code examples using kdp-python-connector see github https://github.com/Koverse/kdp-examples

