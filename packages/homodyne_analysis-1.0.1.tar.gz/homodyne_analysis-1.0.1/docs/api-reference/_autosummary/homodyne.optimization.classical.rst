homodyne.optimization.classical
===============================

.. currentmodule:: homodyne.optimization

.. autodata:: classical
