homodyne.core.config
====================

.. currentmodule:: homodyne.core

.. autodata:: config
