homodyne.core.kernels
=====================

.. currentmodule:: homodyne.core

.. autodata:: kernels
