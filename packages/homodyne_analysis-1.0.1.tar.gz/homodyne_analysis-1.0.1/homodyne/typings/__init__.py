"""Type stubs package for homodyne optional dependencies."""
