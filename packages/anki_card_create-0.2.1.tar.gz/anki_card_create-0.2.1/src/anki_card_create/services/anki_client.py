class AnkiClient:
    def __init__(self) -> None:
        pass
