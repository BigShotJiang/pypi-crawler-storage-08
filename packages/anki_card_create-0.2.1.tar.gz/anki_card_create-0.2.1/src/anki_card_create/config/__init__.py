from .settings import InputLang, TranslatedLang, settings

__all__ = ["InputLang", "TranslatedLang", "settings"]
