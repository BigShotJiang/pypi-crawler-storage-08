.. _worker_api:

The Worker API
==============

.. automodule:: cloud_tasks.worker
    :member-order: bysource
    :members:
    :undoc-members:
    :special-members:
    :show-inheritance:
    :exclude-members: __dict__, __hash__, __module__, __weakref__, __enter__, __exit__, __annotations__
