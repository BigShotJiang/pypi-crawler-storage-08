Examples
========

The `cloud_tasks` package includes a number of examples that demonstrate how to use the system.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   example_parallel_addition
