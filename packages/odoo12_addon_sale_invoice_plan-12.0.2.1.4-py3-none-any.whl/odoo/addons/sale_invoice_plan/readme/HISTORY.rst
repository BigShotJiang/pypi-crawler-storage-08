12.0.2.1.0 (2020-09-03)
~~~~~~~~~~~~~~~~~~~~~~~

* Invoice plan with advance, button "Create Inovice Plan" should be showing.

12.0.2.0.0 (2020-03-03)
~~~~~~~~~~~~~~~~~~~~~~~

* Plan date now passed to invoice date
* Allow edit invoice plan, if no invoice created yet (invoice_count = 0)
* Add new view Sales Invoice Plan

12.0.1.0.0 (2019-03-08)
~~~~~~~~~~~~~~~~~~~~~~~

* Start of the history
