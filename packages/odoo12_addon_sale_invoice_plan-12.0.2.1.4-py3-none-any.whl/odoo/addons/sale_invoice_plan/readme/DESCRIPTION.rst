By standard feature, user can gradually create partial invoices, one by one.
This module add ability to create invoices based on the predefined invoice plan,
either all at once, or one by one.
The plan support both advance invoice and installment invoices.
