Just install this module, and the sales order will have new option "Use Invoice Plan"
