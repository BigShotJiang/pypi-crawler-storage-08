# Freeplay Python ADK

## Development Commands

```
make check
```

## To deploy:

```
uv version --bump patch # Or major, minor, as needed
```
