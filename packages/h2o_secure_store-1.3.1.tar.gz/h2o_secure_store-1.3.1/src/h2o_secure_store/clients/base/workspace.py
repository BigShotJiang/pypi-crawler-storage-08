# Reserved name of the global workspace.
GLOBAL_WORKSPACE = "workspaces/global"

# Reserved name of the default (personal) workspace.
DEFAULT_WORKSPACE = "workspaces/default"
