from nexios.http import Request, Response


async def get(req: Request, res: Response):
    pass


async def patch(req: Request, res: Response):
    pass


async def delete(req: Request, res: Response):
    pass
