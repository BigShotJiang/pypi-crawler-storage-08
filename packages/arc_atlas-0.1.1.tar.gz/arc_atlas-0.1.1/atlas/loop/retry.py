# Retry logic with RIM feedback
