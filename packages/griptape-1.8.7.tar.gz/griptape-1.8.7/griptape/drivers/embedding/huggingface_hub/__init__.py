from griptape.drivers.embedding.huggingface_hub_embedding_driver import HuggingFaceHubEmbeddingDriver

__all__ = ["HuggingFaceHubEmbeddingDriver"]
