import numpy

with open("test.txt", "w") as f:
    f.write(str(numpy.log2(8)))
