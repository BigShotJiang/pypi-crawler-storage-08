# vsi-cli 1.0.0

a vsi cli wrapper built on top of aws cli to simply aws operations based on daily usage.
## Installation

```bash
pip install vsi-cli==1.0.0
```

## Usage
non-stable, wip.