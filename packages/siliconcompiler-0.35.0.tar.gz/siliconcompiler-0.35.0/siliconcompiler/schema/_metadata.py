# Version number following semver standard.
version = '0.52.0'
