#!/bin/sh

set -ex

sudo apt-get update

sudo apt-get install -y imagemagick
