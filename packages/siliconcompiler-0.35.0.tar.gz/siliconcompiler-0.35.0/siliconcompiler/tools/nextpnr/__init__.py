'''
nextpnr is a vendor neutral FPGA place and route tool with
support for the ICE40, ECP5, and Nexus devices from Lattice.

Documentation: https://github.com/YosysHQ/nextpnr

Sources: https://github.com/YosysHQ/nextpnr

Installation: https://github.com/YosysHQ/nextpnr
'''
