# py_slurm
Module to launch slurm jobs
