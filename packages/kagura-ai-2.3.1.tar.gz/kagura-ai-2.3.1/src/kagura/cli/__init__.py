"""CLI interface for Kagura AI"""
