#
# Copyright (c) 2023 Airbyte, Inc., all rights reserved.
#

TOKEN_SEPARATOR = ","
DEFAULT_PAGE_SIZE_FOR_LARGE_STREAM = 10
DEFAULT_PAGE_SIZE = 100
PERSONAL_ACCESS_TOKEN_TITLE = "Personal Access Token"
ACCESS_TOKEN_TITLE = "Access Token"
