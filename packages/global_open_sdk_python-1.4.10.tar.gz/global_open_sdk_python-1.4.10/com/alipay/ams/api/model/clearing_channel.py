from enum import Enum


class ClearingChannel(Enum):
    CUP = "1"
    NUCC = "2"
    OTHER = "3"
