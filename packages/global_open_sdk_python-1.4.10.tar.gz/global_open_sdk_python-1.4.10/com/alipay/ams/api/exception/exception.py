#!/usr/bin/env python
# -*- coding: utf-8 -*-


class AlipayApiException(ValueError):
    pass
