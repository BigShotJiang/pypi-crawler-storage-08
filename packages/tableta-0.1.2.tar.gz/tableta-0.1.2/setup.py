"""
Setup alternativo para compatibilidad con versiones antiguas de pip
"""
from setuptools import setup

# La configuración principal está en pyproject.toml
# Este archivo es solo para compatibilidad
setup()
