Hash
======================
.. autodoxygenfile:: hash.hpp
   :project: cimod
