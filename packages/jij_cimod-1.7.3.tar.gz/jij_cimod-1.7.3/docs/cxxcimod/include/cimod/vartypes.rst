Vartypes
======================
.. autodoxygenfile:: vartypes.hpp
   :project: cimod
