:orphan:

Simple Module
=============

.. autofunction:: dummy_module_simple_default_role.function
