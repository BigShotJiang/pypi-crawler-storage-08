from __future__ import annotations


class A:
    pass


def f() -> A:
    pass
