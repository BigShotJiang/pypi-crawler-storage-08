"""AI Shell Command Generator - AI-powered shell command generation."""

__version__ = "1.0.0"

from .main import main

__all__ = ["main"]
