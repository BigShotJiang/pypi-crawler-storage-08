__version__ = "5.4.2"
__author__ = "Matheus J. Castro"

from meafs_code import gui
