from meafs_code import gui
gui.main()