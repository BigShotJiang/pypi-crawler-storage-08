pyuic6 -x meafs.ui -o gui_qt.py
pyuic6 -x fitsettings.ui -o fitsettings_qt.py
