from typing import override

from notionary.blocks.schemas import BlockColor, CreateParagraphBlock, ParagraphData
from notionary.page.content.parser.parsers.base import (
    BlockParsingContext,
    LineParser,
)
from notionary.page.content.syntax.service import SyntaxRegistry


class SpaceParser(LineParser):
    """
    Parser for [space] markers that create empty paragraph blocks.
    Uses SyntaxRegistry for centralized syntax definition.
    """

    def __init__(self, syntax_registry: SyntaxRegistry) -> None:
        super().__init__(syntax_registry)
        self._syntax = syntax_registry.get_space_syntax()

    @override
    def _can_handle(self, context: BlockParsingContext) -> bool:
        if context.is_inside_parent_context():
            return False
        return self._syntax.regex_pattern.match(context.line.strip()) is not None

    @override
    async def _process(self, context: BlockParsingContext) -> None:
        block = self._create_space_block()
        if block:
            context.result_blocks.append(block)

    def _create_space_block(self) -> CreateParagraphBlock:
        paragraph_data = ParagraphData(rich_text=[], color=BlockColor.DEFAULT)
        return CreateParagraphBlock(paragraph=paragraph_data)
