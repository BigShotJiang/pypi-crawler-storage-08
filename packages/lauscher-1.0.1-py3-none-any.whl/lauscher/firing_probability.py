from lauscher.abstract import SampledTimeSeries


class FiringProbability(SampledTimeSeries):
    pass
