from lauscher.abstract import SampledTimeSeries


class MembraneVelocity(SampledTimeSeries):
    pass
