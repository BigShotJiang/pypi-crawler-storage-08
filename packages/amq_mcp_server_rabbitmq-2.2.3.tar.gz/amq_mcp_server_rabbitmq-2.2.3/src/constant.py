## Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
## SPDX-License-Identifier: Apache-2.0

"""Constants for the RabbitMQ MCP server."""

MCP_SERVER_VERSION = "3.0.0"
