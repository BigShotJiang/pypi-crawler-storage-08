"""
Thin compatibility wrapper: re-export ResponseBuilder from verbatim_core.
"""

from verbatim_core.response_builder import ResponseBuilder

__all__ = ["ResponseBuilder"]
