#exonware/xwsystem/tests/core/patterns/__init__.py
"""
Patterns Core Tests Package

Tests for XSystem design patterns including context managers, dynamic facades,
handler factories, import registries, and object pools.
"""
