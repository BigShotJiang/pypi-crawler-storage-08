This module split the column "Quantity" in the invoice report
into new "Quantity" column and "UoM" Column to improve readability of the invoices.

**Without this module**

.. figure:: ../static/description/1_without_module.png

**With this module**

.. figure:: ../static/description/2_with_module.png
