"""codex-resume: browse and resume Codex CLI sessions."""

__all__ = ["__version__"]
__version__ = "0.4.2"
