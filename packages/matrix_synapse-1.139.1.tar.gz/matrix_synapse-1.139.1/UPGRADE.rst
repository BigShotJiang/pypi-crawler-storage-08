Upgrading Synapse
=================

This document has moved to the `Synapse documentation website <https://element-hq.github.io/synapse/latest/upgrade>`_.
Please update your links.

The markdown source is available in `docs/upgrade.md <docs/upgrade.md>`_.
