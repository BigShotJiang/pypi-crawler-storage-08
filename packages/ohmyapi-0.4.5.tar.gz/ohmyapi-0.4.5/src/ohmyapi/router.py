from http import HTTPStatus

from fastapi import APIRouter, Depends, HTTPException
