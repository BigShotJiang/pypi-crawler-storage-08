"""Internals of array-api-extra."""

from ._backends import Backend

__all__ = ["Backend"]
