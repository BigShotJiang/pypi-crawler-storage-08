from .xkcd_rgb import xkcd_rgb  # noqa: F401
from .crayons import crayons  # noqa: F401
