"""
Feature engineering/EDA.

Explore and diagnose input variables like Correlation, missingness, MI, drift.
"""
