"""
Learning analysis.

Visualize training curves, overfitting like Loss vs. epoch, early stopping.
"""
