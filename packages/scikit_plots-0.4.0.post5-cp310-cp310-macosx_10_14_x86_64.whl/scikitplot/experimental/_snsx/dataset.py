"""
Dataset structure & health.

Profile entire dataset for schema, quality, complexity like Null heatmap, types, duplicates, schema mismatch.
"""
