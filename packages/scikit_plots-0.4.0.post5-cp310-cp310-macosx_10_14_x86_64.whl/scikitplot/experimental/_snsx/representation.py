"""
Feature space embedding.

Unsupervised / latent space representation like PCA, t-SNE, UMAP, autoencoders.

projection (or representation)
"""
