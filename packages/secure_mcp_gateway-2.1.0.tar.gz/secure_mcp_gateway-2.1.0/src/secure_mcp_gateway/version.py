"""
Version of the Enkrypt Secure MCP Gateway package
"""

__version__ = "2.1.0"
