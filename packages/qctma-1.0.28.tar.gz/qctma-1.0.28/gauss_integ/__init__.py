import sys, os
sys.path.append(os.path.split(__file__)[0])