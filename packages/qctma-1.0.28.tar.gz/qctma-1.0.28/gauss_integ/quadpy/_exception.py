class QuadpyError(Exception):
    pass
