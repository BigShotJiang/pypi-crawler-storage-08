"""Example Commands Package.

This package contains example command implementations demonstrating
various patterns for creating custom commands in MCP Proxy Adapter.
"""
