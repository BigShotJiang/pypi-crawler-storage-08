"""galgopy - Genetic algorithm."""
