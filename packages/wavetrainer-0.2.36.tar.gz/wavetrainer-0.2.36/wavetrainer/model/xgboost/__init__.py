"""The wavetrain xgboost model module."""
