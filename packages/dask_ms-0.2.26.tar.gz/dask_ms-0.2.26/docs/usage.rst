=====
Usage
=====

To use dask-ms in a project::

    import daskms
