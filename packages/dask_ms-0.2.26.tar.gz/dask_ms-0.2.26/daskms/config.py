from donfig import Config

config = Config("dask-ms")
