DASKMS_PARTITION_KEY = "__daskms_partition_schema__"
DASKMS_METADATA = "__daskms_metadata__"
DASKMS_PARQUET_VERSION = "0.0.1"
