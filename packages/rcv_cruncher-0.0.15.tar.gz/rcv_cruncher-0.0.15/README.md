# rcv_cruncher

A python package for tabulating and analysing Ranked Choice Voting results.

For full documentation visit https://rcv-cruncher.readthedocs.io/en/latest/

## Install

Requires python version >= 3.9

<br/>

```
pip install rcv-cruncher
```

