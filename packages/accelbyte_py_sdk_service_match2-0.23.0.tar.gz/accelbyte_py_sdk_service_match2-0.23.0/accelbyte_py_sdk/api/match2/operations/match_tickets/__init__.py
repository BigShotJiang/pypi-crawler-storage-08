# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Match Service V2."""

__version__ = "2.36.0"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .create_match_ticket import CreateMatchTicket
from .delete_match_ticket import DeleteMatchTicket
from .get_my_match_tickets import GetMyMatchTickets
from .match_ticket_details import MatchTicketDetails
