from enum import Enum


class RuntimeMode(Enum):
    DEV = "dev"
    TEST = "test"
