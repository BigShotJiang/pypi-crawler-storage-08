#!/usr/bin/env python3
from bloodyAD import main
import asyncio

if __name__ == "__main__":
    asyncio.run(main.main())
