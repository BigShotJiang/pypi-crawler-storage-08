#. Go to Purchases > Products > Products.
#. Create a Storable product, set the 'Buy' route and some vendor in the 'Purchase' tab.
#. Set the Procurement: 'Propose a call for tenders' option in the 'Reordering' section of the 'Purchase' tab.
