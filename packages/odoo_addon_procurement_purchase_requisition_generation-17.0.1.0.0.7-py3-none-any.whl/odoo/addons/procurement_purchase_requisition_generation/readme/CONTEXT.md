The decision of who to buy from is decided by sales order, so it is not useful to group by supplier in purchase orders.
