#. Click on the 'Replenish' button of the previously created product.
#. The 'Buy' route and 'Vendor' field will be defined automatically.
#. Click on the 'Confirm' button.
#. A new Blanket Order will be generated.
