This module restores the v15 functionality in which you can configure products for
generating purchase tenders instead of draft purchase orders.
