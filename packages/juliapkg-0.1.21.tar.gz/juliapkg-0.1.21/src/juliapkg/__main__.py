"""Entry point for python -m juliapkg."""

if __name__ == "__main__":
    from .cli import cli

    cli()
