自定义 Exception
---------------

自定义异常处理模块

.. automodule:: rayvision_api.exception
   :members:
   :undoc-members:
   :show-inheritance: