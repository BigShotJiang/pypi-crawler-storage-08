RayvisionAPI
--------------------------


rayvision_api的入口脚本

.. automodule:: rayvision_api.core
   :members:
   :undoc-members:
   :show-inheritance: