Env
----------------------------

设置变量类型,环境配置的参数类型

.. automodule:: rayvision_api.fields
   :members:
   :undoc-members:
   :show-inheritance: