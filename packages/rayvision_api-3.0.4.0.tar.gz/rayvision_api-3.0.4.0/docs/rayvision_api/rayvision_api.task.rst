.. note::
   **task** 包主要是校验分析结果和配置一些初始task信息

task package
=============

.. toctree::
   :maxdepth: 2

   task/check.rst
   task/handle.rst