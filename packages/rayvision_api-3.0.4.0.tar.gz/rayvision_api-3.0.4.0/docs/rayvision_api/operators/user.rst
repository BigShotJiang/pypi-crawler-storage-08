用户信息(User)
========

`user.py`: 获取用户相关信息的接口

.. automodule:: rayvision_api.operators.user
   :members:
   :undoc-members:
   :show-inheritance: