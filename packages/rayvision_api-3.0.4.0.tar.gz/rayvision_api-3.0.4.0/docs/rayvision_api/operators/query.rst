查询(Query)
=========

`query.py`: 渲染过程中调用平台服务器的操作接口

.. automodule:: rayvision_api.operators.query
   :members:
   :undoc-members:
   :show-inheritance: