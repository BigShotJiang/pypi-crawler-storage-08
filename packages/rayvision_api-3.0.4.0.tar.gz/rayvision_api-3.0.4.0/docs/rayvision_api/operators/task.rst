任务(Task)
========

`task.py`: 操作任务(task)相关接口，主要包括“停止任务”，“删除任务”，“放弃任务”等等

.. automodule:: rayvision_api.operators.task
   :members:
   :undoc-members:
   :show-inheritance: