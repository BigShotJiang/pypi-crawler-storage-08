任务自定义标记(Tag)
=======

`tag.py`: 自定义标签相关接口

.. automodule:: rayvision_api.operators.tag
   :members:
   :undoc-members:
   :show-inheritance: