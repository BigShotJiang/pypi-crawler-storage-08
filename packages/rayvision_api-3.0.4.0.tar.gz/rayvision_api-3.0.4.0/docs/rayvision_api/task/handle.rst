.. note::
   **handle.py** 为任务设置资产信息和一般配置信息


任务模块(RayvisionTask)
===========================

.. automodule:: rayvision_api.task.handle
   :members:
   :undoc-members:
   :show-inheritance: