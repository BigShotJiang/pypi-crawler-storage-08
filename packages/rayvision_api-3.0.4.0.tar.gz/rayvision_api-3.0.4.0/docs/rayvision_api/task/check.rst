.. note::
   **check.py** 主要是校验分析结果

校验模块(RayvisionCheck)
===========================

   主要是检查任务信息(task_info)和上传(upload)资产信息

.. automodule:: rayvision_api.task.check
   :members:
   :undoc-members:
   :show-inheritance: