"""Automated literature surveys."""
