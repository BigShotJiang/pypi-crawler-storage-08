class RipsError(Exception):
    pass
