"""
Tests for the reports module.
"""
