from .sys_info import SystemInfo

__version__ = "0.1.0"  # ОБНОВИТЕ ВЕРСИЮ!
__author__ = "John Stephans"
__email__ = "bchsjbcsabcja131312cjbsacsc@gmail.com"

__all__ = [
    "SystemInfo",
]