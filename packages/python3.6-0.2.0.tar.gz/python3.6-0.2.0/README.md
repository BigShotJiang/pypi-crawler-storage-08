# Best Dev Utils

Check python version

## Установка

```bash
pip install python