"""Resource components package."""
