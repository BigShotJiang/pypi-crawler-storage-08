"""Model Context Protocol integration."""
from .server_config import MCPServerConfig

__all__ = ["MCPServerConfig"]
