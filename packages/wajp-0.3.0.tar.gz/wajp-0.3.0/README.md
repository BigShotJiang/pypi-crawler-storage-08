# Wajp

Wipe anything without limits.