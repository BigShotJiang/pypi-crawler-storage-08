from dlt.extract.exceptions import DltResourceException


class InsightsJobTimeout(DltResourceException):
    pass
