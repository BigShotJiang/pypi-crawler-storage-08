import enum


class ProcessingStep(enum.StrEnum):
    AVERAGE = "average"
