dict_of_parts = {
    "SLA-Battery": "",
    "on-off-switch": "",
    "charging-port": "",
    "dsn-vc288": "",
}
