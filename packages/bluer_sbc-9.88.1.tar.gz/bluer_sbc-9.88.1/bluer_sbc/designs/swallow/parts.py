dict_of_parts = {
    "BTS7960": "2 x",
    "connector": "2 females",
    "white-terminal": "8 x",
    "nuts-bolts-spacers": "M3: (8 x 25 mm + 4 x 30 mm + 4 x nut)",
    "solid-cable-1-15": "20 cm x (red + black/blue)",
}
