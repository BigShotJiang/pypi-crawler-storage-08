// Cytosim was created by Francois Nedelec. Copyright 2022 Cambridge University

#ifdef __APPLE__
#   include "GLFW/glfw3.h"
#else
#   define GLFW_INCLUDE_NONE
#   include <GLFW/glfw3.h>
#endif
