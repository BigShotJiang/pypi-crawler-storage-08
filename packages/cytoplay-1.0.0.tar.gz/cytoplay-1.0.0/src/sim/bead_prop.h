// Cytosim was created by Francois Nedelec. Copyright 2007-2017 EMBL.

#ifndef BEAD_PROP_H
#define BEAD_PROP_H

#include "solid_prop.h"

/// BeadProp is an alias to SolidProp
typedef SolidProp BeadProp;

#endif
