# coding: utf-8

from snaptrade_client.apis.tags.account_information_api_generated import AccountInformationApiGenerated

class AccountInformationApi(AccountInformationApiGenerated):
    pass
