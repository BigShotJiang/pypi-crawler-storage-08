from snaptrade_client.paths.trade_impact.post import ApiForpost


class TradeImpact(
    ApiForpost,
):
    pass
