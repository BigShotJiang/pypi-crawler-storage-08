from snaptrade_client.paths.currencies_rates.get import ApiForget


class CurrenciesRates(
    ApiForget,
):
    pass
