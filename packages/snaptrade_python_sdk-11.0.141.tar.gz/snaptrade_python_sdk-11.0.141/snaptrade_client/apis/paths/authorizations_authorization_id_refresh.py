from snaptrade_client.paths.authorizations_authorization_id_refresh.post import ApiForpost


class AuthorizationsAuthorizationIdRefresh(
    ApiForpost,
):
    pass
