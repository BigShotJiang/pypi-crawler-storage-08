from ttkbootstrap.style import Style
from ttkbootstrap.style import Bootstyle
from ttkbootstrap.widgets import *
from ttkbootstrap.window import Window, Toplevel

from tkinter.scrolledtext import ScrolledText
from tkinter import Variable, StringVar, IntVar, BooleanVar, DoubleVar
from tkinter import Canvas, Menu, Text
from tkinter import PhotoImage

Bootstyle.setup_ttkbootstrap_api()
