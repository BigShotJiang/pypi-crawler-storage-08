import bw_functional as bf
import pytest

def test_database_proces(basic):
    basic.process()
