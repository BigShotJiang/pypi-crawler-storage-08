"""
simplemath package

Expose a tiny add function for demonstration.
"""

from .core import add

__all__ = ["add"]
__version__ = "0.0.1"
