# simplemath

A tiny example package providing simple math helpers.

## Installation

Using pip (PyPI):

```bash
pip install simplemath
