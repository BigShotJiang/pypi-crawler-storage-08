# flake8: noqa
from janim.constants.alignment import *
from janim.constants.colors import *
from janim.constants.coord import *
from janim.constants.degrees import *

FRAME_PPI = 144
DEFAULT_DURATION = 1
FOREVER = ...
