'''A library for creating smooth animations'''

__version__ = '3.9.2'
