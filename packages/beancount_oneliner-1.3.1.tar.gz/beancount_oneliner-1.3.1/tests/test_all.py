from pytest_bdd import scenarios

import conftest

scenarios("features/basics.feature")
scenarios("features/payee.feature")
scenarios("features/link.feature")
scenarios("features/tag.feature")
