Tritium Remote (Python)
=======================

A pure python library for remote Tritium system access.

https://docs.engineeredarts.co.uk/en/user/tritium_remote

*Requires Python >= 3.9*