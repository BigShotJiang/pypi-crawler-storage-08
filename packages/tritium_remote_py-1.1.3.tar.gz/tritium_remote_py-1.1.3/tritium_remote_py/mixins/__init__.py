"""
Specialized GraphQL operations exposed by `tritium_remote_py.client.TritiumRemote`.
"""
