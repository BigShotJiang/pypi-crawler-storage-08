# Documentation

This directory contains project documentation.

## Structure

- `README.md` - This file
- Project-specific documentation goes here

## Getting Started

Add your project documentation in this directory.
