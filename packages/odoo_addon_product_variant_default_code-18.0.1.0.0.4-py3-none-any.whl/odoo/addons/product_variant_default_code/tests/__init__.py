from . import test_variant_default_code
