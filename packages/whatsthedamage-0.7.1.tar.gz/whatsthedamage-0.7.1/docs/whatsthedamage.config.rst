whatsthedamage.config package
=============================

.. automodule:: whatsthedamage.config
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

whatsthedamage.config.config module
-----------------------------------

.. automodule:: whatsthedamage.config.config
   :members:
   :show-inheritance:
   :undoc-members:

whatsthedamage.config.flask\_config module
------------------------------------------

.. automodule:: whatsthedamage.config.flask_config
   :members:
   :show-inheritance:
   :undoc-members:
