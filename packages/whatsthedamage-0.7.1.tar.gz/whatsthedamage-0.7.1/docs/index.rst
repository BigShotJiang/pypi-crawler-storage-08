Welcome to whatsthedamage's documentation!
==========================================

A package to process KHBHU CSV files and a web application written in Flask.

Contents
--------

.. toctree::
   :maxdepth: 3
   :caption: API Reference

   whatsthedamage

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`