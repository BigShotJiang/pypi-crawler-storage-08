whatsthedamage package
======================

.. automodule:: whatsthedamage
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   whatsthedamage.config
   whatsthedamage.controllers
   whatsthedamage.models
   whatsthedamage.utils
   whatsthedamage.view

Submodules
----------

whatsthedamage.app module
-------------------------

.. automodule:: whatsthedamage.app
   :members:
   :show-inheritance:
   :undoc-members:
