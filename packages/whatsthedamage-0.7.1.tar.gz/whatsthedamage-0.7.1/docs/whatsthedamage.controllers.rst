whatsthedamage.controllers package
==================================

.. automodule:: whatsthedamage.controllers
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

whatsthedamage.controllers.cli module
-------------------------------------

.. automodule:: whatsthedamage.controllers.cli
   :members:
   :show-inheritance:
   :undoc-members:

whatsthedamage.controllers.routes module
----------------------------------------

.. automodule:: whatsthedamage.controllers.routes
   :members:
   :show-inheritance:
   :undoc-members:

whatsthedamage.controllers.whatsthedamage module
------------------------------------------------

.. automodule:: whatsthedamage.controllers.whatsthedamage
   :members:
   :show-inheritance:
   :undoc-members:
