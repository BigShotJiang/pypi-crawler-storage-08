class Side(object):
    Buy = 0
    Sell = 1

class Tif(object):
    Gtc = 0
    Ioc = 1
    Alo = 2