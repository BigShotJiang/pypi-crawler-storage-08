def main():
    print("Hello from rlkit!")


if __name__ == "__main__":
    main()
