"""MCP server for Conceptual Keywords & Creative Performance API."""

__version__ = "0.2.3"