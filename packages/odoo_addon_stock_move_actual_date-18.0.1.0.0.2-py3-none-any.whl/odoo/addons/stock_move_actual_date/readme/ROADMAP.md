Updating the Actual Date of a completed receipt picking for a foreign
currency purchase does not trigger a recalculation of the amounts in the
associated journal entries, even if the currency rate for the new date
differs.

For the Actual Date of existing stock move and stock move line records
created before this module was installed, the user's timezone will not
be considered, and only the date part from the 'date' field in the UTC
timezone will be assigned.
