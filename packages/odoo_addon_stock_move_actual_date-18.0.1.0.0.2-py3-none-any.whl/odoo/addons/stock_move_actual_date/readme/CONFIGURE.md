- Go to Settings \> Users & Companies \> Groups.
- Open 'Modify Actual Date' and add the users who are allowed to edit
  the actual date of completed records (e.g., pickings, scraps).
