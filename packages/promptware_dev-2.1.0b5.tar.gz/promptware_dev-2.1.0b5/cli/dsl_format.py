#!/usr/bin/env python3
from cli.formatters.promptware_dsl_formatter import main

if __name__ == "__main__":
    main()
