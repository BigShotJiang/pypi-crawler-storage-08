## 🚀 Commands

- `login` - Authenticate with Sphinx (opens web browser)
- `logout` - Clear stored authentication tokens
- `status` - Check authentication status
- `chat [options]` - Start a chat session with Sphinx