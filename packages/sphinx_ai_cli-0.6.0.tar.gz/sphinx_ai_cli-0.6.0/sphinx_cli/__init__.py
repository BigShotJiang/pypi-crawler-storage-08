"""Sphinx CLI package for AI-powered Jupyter notebook interactions."""

__version__ = "0.6.0"
__author__ = "Sphinx AI"
__email__ = "support@sphinx.ai"
