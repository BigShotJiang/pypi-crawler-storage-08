from .img_compress import main

if __name__ == "__main__":
    main()
