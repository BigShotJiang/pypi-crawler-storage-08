nlsq.least_squares module
==========================

This module contains the core least squares solver implementation.

.. automodule:: nlsq.least_squares
   :members:
   :undoc-members:
   :show-inheritance:
