nlsq.config module
==================

Configuration management and environment setup.

.. automodule:: nlsq.config
   :members:
   :undoc-members:
   :show-inheritance:
   :no-index:
