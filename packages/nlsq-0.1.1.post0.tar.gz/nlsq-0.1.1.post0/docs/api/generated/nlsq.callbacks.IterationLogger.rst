﻿nlsq.callbacks.IterationLogger
==============================

.. currentmodule:: nlsq.callbacks

.. autoclass:: IterationLogger
