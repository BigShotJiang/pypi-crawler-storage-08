﻿nlsq.functions.sigmoid
======================

.. currentmodule:: nlsq.functions

.. autofunction:: sigmoid
