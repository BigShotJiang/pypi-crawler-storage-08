﻿nlsq.diagnostics.OptimizationDiagnostics
========================================

.. currentmodule:: nlsq.diagnostics

.. autoclass:: OptimizationDiagnostics
