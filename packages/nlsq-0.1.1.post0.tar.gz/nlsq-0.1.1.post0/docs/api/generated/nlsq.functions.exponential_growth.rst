﻿nlsq.functions.exponential\_growth
==================================

.. currentmodule:: nlsq.functions

.. autofunction:: exponential_growth
