﻿nlsq.functions.exponential\_decay
=================================

.. currentmodule:: nlsq.functions

.. autofunction:: exponential_decay
