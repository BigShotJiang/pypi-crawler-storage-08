﻿nlsq.memory\_manager.get\_memory\_stats
=======================================

.. currentmodule:: nlsq.memory_manager

.. autofunction:: get_memory_stats
