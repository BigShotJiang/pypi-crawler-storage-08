﻿nlsq.functions.gaussian
=======================

.. currentmodule:: nlsq.functions

.. autofunction:: gaussian
