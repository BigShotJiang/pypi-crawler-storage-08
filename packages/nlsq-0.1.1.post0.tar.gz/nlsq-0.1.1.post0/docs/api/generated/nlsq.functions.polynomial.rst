﻿nlsq.functions.polynomial
=========================

.. currentmodule:: nlsq.functions

.. autofunction:: polynomial
