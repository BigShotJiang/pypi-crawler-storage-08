﻿nlsq.streaming\_optimizer.create\_hdf5\_dataset
===============================================

.. currentmodule:: nlsq.streaming_optimizer

.. autofunction:: create_hdf5_dataset
