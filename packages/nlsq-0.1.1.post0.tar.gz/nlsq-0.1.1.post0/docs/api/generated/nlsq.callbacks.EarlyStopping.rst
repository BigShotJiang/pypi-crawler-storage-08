﻿nlsq.callbacks.EarlyStopping
============================

.. currentmodule:: nlsq.callbacks

.. autoclass:: EarlyStopping
