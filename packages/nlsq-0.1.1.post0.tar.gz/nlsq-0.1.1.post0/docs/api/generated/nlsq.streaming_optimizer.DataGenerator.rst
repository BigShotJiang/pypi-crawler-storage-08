﻿nlsq.streaming\_optimizer.DataGenerator
=======================================

.. currentmodule:: nlsq.streaming_optimizer

.. autoclass:: DataGenerator
