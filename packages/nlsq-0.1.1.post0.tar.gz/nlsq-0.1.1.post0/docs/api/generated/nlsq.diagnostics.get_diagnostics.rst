﻿nlsq.diagnostics.get\_diagnostics
=================================

.. currentmodule:: nlsq.diagnostics

.. autofunction:: get_diagnostics
