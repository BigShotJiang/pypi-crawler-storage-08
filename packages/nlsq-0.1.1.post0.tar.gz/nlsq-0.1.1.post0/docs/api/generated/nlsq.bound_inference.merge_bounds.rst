﻿nlsq.bound\_inference.merge\_bounds
===================================

.. currentmodule:: nlsq.bound_inference

.. autofunction:: merge_bounds
