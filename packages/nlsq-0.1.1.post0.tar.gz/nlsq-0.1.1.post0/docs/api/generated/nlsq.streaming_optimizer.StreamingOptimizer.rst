﻿nlsq.streaming\_optimizer.StreamingOptimizer
============================================

.. currentmodule:: nlsq.streaming_optimizer

.. autoclass:: StreamingOptimizer
