﻿nlsq.functions.power\_law
=========================

.. currentmodule:: nlsq.functions

.. autofunction:: power_law
