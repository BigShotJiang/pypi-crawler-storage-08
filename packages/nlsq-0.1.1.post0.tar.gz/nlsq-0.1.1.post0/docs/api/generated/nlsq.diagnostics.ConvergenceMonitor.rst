﻿nlsq.diagnostics.ConvergenceMonitor
===================================

.. currentmodule:: nlsq.diagnostics

.. autoclass:: ConvergenceMonitor
