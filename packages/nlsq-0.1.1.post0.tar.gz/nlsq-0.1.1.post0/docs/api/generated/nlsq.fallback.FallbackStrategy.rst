﻿nlsq.fallback.FallbackStrategy
==============================

.. currentmodule:: nlsq.fallback

.. autoclass:: FallbackStrategy
