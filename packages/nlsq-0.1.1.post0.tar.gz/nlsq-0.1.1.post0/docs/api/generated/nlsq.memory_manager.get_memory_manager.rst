﻿nlsq.memory\_manager.get\_memory\_manager
=========================================

.. currentmodule:: nlsq.memory_manager

.. autofunction:: get_memory_manager
