nlsq.common_jax module
=======================

JAX-specific utilities and functions.

.. automodule:: nlsq.common_jax
   :members:
   :undoc-members:
   :show-inheritance:
