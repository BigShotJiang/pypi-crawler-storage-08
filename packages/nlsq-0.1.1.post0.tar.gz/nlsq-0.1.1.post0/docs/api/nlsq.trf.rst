nlsq.trf module
===============

Trust Region Reflective algorithm implementation.

.. automodule:: nlsq.trf
   :members:
   :undoc-members:
   :show-inheritance:
