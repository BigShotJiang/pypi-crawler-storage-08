nlsq.minpack module
===================

This module provides the main user-facing API with the ``CurveFit`` class and ``curve_fit`` function.

.. automodule:: nlsq.minpack
   :members:
   :undoc-members:
   :show-inheritance:
