nlsq.optimizer_base module
===========================

Base classes for optimization algorithms.

.. automodule:: nlsq.optimizer_base
   :members:
   :undoc-members:
   :show-inheritance:
