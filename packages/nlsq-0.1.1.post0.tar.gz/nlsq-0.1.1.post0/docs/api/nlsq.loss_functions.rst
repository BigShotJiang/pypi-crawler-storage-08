nlsq.loss_functions module
===========================

Robust loss functions for outlier handling.

.. automodule:: nlsq.loss_functions
   :members:
   :undoc-members:
   :show-inheritance:
