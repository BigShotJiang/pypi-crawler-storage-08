__all__ = ["version", "version_info"]


version = "0.8.0"
version_info = (0, 8, 0, "final", 0)
