"""Domain services for repository module."""
