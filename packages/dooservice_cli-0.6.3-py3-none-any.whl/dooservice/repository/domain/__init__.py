"""Domain layer for repository module."""
