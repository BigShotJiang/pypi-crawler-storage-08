"""Repository interfaces for repository module."""
