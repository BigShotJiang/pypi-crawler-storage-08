"""Use cases for repository operations."""
