"""Driven adapters for repository module."""
