"""Driving adapters for repository module."""
