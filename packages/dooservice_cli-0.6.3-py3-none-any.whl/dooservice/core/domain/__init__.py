"""Domain layer of the core module."""
