"""Driving adapters for entry points."""
