"""Infrastructure layer of the core module."""
