"""
Backup module for dooservice-cli.

This module provides backup and restore functionality for Odoo instances.
"""
