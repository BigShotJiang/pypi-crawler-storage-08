├── client.py                                   # 核心 API 客户端，处理请求、响应、认证
├── consts.py                                   # 项目常量定义，如 API 地址、错误码等
├── exceptions.py                               # 自定义异常类定义
├── utils.py                                    # 通用工具函数和辅助函数
│
├── Account_api.py                              # 账户相关 API (余额、资产等)
├── Affiliate_api.py                            # 推广/联属计划相关 API
├── Broker_api.py                               # 经纪商相关 API
├── Convert_api.py                              # 币种兑换相关 API
├── Copytrading_api.py                          # 跟单交易相关 API
├── FDBroker_api.py                             # 金融衍生品经纪商相关 API (或特定经纪商)
├── Finance_api.py                              # 金融服务相关 API (质押、借贷等)
├── Funding_api.py                              # 资金账户相关 API (充值、提现等)
├── Market_api.py                               # 市场数据相关 API (K线、深度、行情等)
├── Public_api.py                               # 公共 API (无需认证，如服务器时间)
├── Recurring_api.py                            # 定期定投/循环订单相关 API
├── Rfq_api.py                                  # 询价 (Request for Quote) 相关 API
├── Singal_api.py                               # 交易信号相关 API (可能是 Signal_api.py 的拼写错误)
├── SprdApi_api.py                              # 价差交易 (Spread Trading) 相关 API
├── status_api.py                               # 系统/服务状态查询 API
├── subAccount_api.py                           # 子账户管理相关 API
├── Trade_api.py                                # 核心交易 API (下单、撤单、查订单等)
├── TradingBot_api.py                           # 交易机器人相关 API/功能
└── TradingData_api.py                          # 交易历史数据相关 API