{
    "version": "16.0.0.0.2",
    "name": "La Directa Website Sale customizations",
    "summary": """
    """,
    "depends": [
        "website_sale",
        "ladirecta",
        "partner_firstname",
        "partner_contact_birthdate",
        "partner_contact_birthplace",
        "partner_contact_gender",
    ],
    "author": "Coopdevs Treball SCCL",
    "category": "Website/Website",
    "website": "https://git.coopdevs.org/talaios/addons/odoo-directa#",
    "license": "AGPL-3",
    "data": [
        "views/website_templates.xml",
        "data/data.xml",
    ],
    "demo": [],
    "application": False,
    "installable": True,
}
