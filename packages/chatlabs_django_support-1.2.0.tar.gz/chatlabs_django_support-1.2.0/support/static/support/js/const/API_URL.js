const BASE_PATH = window.BASE_PATH || "";
export const API_URL=`${window.location.origin}${BASE_PATH}/support/`;
