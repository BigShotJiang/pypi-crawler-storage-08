.. :changelog:

History
-------

.. to_doc

---------------------
0.2.1 (2025-10-09)
---------------------

* Fix recent API changes for Pulsar tests - thanks to @nsoranzo.

---------------------
0.2.0 (2025-10-03)
---------------------

* Various updates to support migrating to the Galaxy job files to Fast API
  (thanks to @kysrpex).

---------------------
0.1.1 (2022-10-12)
---------------------

* Fix up project to parameterize application for Docker.

---------------------
0.1.0 (2022-10-12)
---------------------

* Inital version.
