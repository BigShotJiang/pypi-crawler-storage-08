"""NASDAQ provider data models."""
