"""The command line and Python client for GPAS."""

__version__ = "2.2.3"
