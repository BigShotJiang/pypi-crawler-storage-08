from . import system_desc_checker

system_desc_checker.main()
