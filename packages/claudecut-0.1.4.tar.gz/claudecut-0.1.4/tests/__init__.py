"""Tests for SubtitleCraft"""
