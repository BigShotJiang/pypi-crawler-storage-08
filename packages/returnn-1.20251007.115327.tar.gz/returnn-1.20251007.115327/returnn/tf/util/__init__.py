"""
Here we provide some basic TF utilities, which are mostly independent from RETURNN.
"""
