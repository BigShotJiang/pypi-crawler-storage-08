from .base import BaseBackend


class InMemoryBackend(BaseBackend):
    pass
