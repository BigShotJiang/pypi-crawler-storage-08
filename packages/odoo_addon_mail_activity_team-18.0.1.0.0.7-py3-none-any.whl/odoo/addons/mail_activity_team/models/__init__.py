from . import ir_actions_server
from . import mail_activity_team
from . import mail_activity
from . import mail_activity_mixin
from . import res_users
from . import mail_activity_type
