To set up new teams:

1.  Go to *Settings / Activate developer mode*
2.  Go to *Settings / Technical / Discuss / Activity Teams*
3.  Create a new Team and assign (optionally) the models in which it
    will be used, and the members of the team.

You can also assign a user to Activity teams going to *Settings / Users
& Companies / Users*, and in the *Preferences* tab, field Activity
Teams.

When you create a new activity the application will propose the user's
assigned team.

You can report on the activities assigned to a team going to *Dashboards
/ Activities*, and then filter by a specific team or group by teams.
