# Security Policy

If you discover a vulnerability, please do **not** open a public issue.

Instead, contact @Masen222 directly or open a private advisory in the repository's
"Security Advisories" tab. All reports will be acknowledged and handled responsibly.
