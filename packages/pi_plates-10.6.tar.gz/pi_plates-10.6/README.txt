Pi-Plates installation page for TINKERplate, THERMOplate, DAQCplate, DAQC2plate,
MOTORplate, RELAYplate, RELAYplate2, CURRENTplate, DIGIplate, ADCplate,
POWERplate, and POWERplate24 modules.