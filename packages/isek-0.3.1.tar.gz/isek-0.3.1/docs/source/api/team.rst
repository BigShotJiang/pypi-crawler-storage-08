Team Module
===========

.. automodule:: isek.team
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: isek.team.isek_team
   :members:
   :undoc-members:
   :show-inheritance: 