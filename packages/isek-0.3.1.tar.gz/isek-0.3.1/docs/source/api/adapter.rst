Adapter Module
==============

.. automodule:: isek.adapter
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: isek.adapter.base
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: isek.adapter.isek_adapter
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: isek.adapter.simple_adapter
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: isek.adapter.agno_adapter
   :members:
   :undoc-members:
   :show-inheritance: 