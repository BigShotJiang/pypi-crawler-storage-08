import pytest
import pip_importer


def test_1():
    from pip_importer import pip_import
    assert pip_import

