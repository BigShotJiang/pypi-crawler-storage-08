"""A demo project for subtitle generation and video editing"""

__version__ = "0.1.0"
