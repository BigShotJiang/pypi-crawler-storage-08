"""Embedded Jinja2 templates for richframe."""
