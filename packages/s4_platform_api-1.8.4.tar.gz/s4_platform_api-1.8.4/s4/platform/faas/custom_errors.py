# Copyright 2022 Semaphore Solutions
# ---------------------------------------------------------------------------


class ClientError(Exception):
    """ This error is intended to represent avoidable errors introduced by the client """
    pass
