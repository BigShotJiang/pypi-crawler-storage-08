"""AWS Bedrock AgentCore A2A Proxy."""

from .main import create_app

__all__ = [
    "create_app",
]
