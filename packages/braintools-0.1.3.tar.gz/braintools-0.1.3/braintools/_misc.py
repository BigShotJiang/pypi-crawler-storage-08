# Copyright 2025 BrainX Ecosystem Limited. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================


from typing import Callable, Any, Union, Optional

import brainstate
import brainunit as u
import jax


def set_module_as(module: str):
    def wrapper(fun: callable):
        fun.__module__ = module
        return fun

    return wrapper


def tree_map(f: Callable[..., Any], tree: Any, *rest: Any):
    return jax.tree.map(f, tree, *rest, is_leaf=u.math.is_quantity)


def randn_like(y):
    return brainstate.random.randn(*u.math.shape(y))


Initializer = Union[brainstate.typing.ArrayLike, Callable]
InitializerOrNot = Optional[Union[brainstate.typing.ArrayLike, Callable]]
