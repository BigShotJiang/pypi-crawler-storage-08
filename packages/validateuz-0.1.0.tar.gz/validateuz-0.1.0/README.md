# The best Validator in Uzbekistan by email, password, username, birthday validation

# The Installation
```
pip install validateuz
```

# Tutorial

```
import validateuz

validateuz.pass8and64(password) #email, username, fullname
```