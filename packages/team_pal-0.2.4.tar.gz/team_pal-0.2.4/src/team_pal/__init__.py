"""Team Pal package initialization."""

__all__: list[str] = []
