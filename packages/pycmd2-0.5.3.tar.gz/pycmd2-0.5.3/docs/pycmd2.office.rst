pycmd2.office package
=====================

Submodules
----------

pycmd2.office.pdf\_crypt module
-------------------------------

.. automodule:: pycmd2.office.pdf_crypt
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.office.pdf\_merge module
-------------------------------

.. automodule:: pycmd2.office.pdf_merge
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.office.pdf\_split module
-------------------------------

.. automodule:: pycmd2.office.pdf_split
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pycmd2.office
   :members:
   :undoc-members:
   :show-inheritance:
