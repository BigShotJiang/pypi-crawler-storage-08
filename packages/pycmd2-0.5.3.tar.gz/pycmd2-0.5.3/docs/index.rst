欢迎访问 `pycmd2`_ 手册!
==================================================

.. _pycmd2: https://gitee.com/gooker_young/pycmd2

.. toctree::
   :maxdepth: 2

   readme
   installation
   tutorial
   modules
   contributing
   authors
   history

导航 & 索引
=============
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
