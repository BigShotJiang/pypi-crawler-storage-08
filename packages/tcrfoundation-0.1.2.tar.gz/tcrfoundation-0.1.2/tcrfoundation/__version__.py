"""Version information for TCRfoundation."""

__version__ = "0.1.2"
