from . import cli
cli.start_cli()
