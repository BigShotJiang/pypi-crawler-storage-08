# VideoSDK ElevenLabs Plugin

Agent Framework plugin for TTS services from ElevenLabs.

## Installation

```bash
pip install videosdk-plugins-elevenlabs
```