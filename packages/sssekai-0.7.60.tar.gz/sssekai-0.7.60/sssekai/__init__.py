__VERSION_MAJOR__ = 0
__VERSION_MINOR__ = 7
__VERSION_PATCH__ = 60

__version_tuple__ = (__VERSION_MAJOR__, __VERSION_MINOR__, __VERSION_PATCH__)
__version__ = "%s.%s.%s" % __version_tuple__
