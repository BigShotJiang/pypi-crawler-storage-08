On most companies there are products that must be purchased often but
cannot be stored as a usual product because no consumption moves are
made. Usually, they are stored as consumables or putaway rules are
defined. In both cases, reordering rules cannot be used. This module
allows to use stock request as reordering rules for this kind of
products.

It is created following the concept of lean kanban cards.
