# Copyright 2018 Creu Blanca
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl.html).

from . import stock_request
from . import stock_request_kanban
from . import stock_inventory_kanban
from . import product
