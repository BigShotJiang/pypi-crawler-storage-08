# Copyright 2018 Creu Blanca
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl.html).

from . import wizard_stock_request_kanban_abstract
from . import wizard_stock_request_kanban
from . import wizard_stock_request_order_kanban
from . import wizard_stock_inventory_kanban
