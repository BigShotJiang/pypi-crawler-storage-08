class SurveyError(Exception):
    pass
