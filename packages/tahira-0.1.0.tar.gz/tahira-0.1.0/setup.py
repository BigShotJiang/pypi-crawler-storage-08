from setuptools import setup, find_packages

setup(
    name='Tahira',
    version='0.1.0',
    packages=find_packages(),
    description='A simple library for YOU',
    author='Ahmed',
    license='Free-to-use (proprietary)',
)
