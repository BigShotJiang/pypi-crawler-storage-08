from enum import Enum, auto


class QuotationMarkDirection(Enum):
    OPENING = auto()
    CLOSING = auto()
