"""Compatibility shim re-exporting :mod:`pandas_app.pandas_app_args`."""

from .pandas_app_args import *  # noqa: F401,F403
