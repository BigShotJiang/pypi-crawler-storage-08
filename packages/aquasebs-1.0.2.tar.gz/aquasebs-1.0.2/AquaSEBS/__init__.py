from .AquaSEBS import *
from .version import __version__

__author__ = "Gregory H. Halverson"
