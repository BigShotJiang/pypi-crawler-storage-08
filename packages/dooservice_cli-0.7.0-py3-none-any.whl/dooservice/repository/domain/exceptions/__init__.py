"""Domain exceptions for repository module."""
