"""Domain entities for repository module."""
