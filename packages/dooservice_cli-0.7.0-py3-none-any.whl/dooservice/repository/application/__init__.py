"""Application layer for repository module."""
