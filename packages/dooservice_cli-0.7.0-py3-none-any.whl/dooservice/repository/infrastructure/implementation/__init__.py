"""Repository implementations for repository module."""
