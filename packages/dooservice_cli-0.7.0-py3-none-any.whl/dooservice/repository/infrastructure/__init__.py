"""Infrastructure layer for repository module."""
