"""CLI driving adapter for repository module."""
