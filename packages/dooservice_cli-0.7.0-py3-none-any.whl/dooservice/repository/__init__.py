"""Repository management module for DooService.

This module handles repository operations including listing, status checking,
and synchronization of Git repositories for DooService instances.
"""
