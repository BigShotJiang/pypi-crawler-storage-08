"""Application layer of the core module."""
