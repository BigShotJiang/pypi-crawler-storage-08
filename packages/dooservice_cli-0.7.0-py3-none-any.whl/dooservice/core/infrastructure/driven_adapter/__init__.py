"""Driven adapters for external dependencies."""
