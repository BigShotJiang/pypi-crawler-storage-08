# fastquadtree

Rust powered quadtree for Python.  
See the sidebar for Quickstart and API.
