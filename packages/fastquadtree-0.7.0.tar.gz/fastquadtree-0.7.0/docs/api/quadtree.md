# fastquadtree.QuadTree
::: fastquadtree.QuadTree
