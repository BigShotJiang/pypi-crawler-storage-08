"""
This is an integration of canvas with edX.
"""

__version__ = "0.5.3"

default_app_config = "ol_openedx_canvas_integration.app.CanvasIntegrationConfig"  # pylint: disable=invalid-name
