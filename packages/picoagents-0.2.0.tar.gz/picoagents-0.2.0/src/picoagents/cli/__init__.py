"""
PicoAgents CLI - Unified command-line interface.

Provides subcommands for various PicoAgents functionality.
"""

from ._main import main

__all__ = ["main"]
