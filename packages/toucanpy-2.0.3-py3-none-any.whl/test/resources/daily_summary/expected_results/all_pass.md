# Toucan daily
## Today - 2024-10-02

## All applications supported - ✅
| Date       | App name                                                               | Version      | Support   | Run status   |
|:-----------|:-----------------------------------------------------------------------|:-------------|:----------|:-------------|
| 2024-10-02 | [Whatsapp](./Whatsapp/README.md)<br />[Telegram](./Telegram/README.md) | 2.0<br />2.5 | ✅<br />✅  | -<br />-     |

__________
## Previous days

| Date       | App name                                                               | Version      | Support      | Run status   |
|:-----------|:-----------------------------------------------------------------------|:-------------|:-------------|:-------------|
| 2024-10-02 | [Whatsapp](./Whatsapp/README.md)<br />[Telegram](./Telegram/README.md) | 2.0<br />2.5 | ✅<br />✅     | -<br />-     |
| 2024-10-01 | [Whatsapp](./Whatsapp/README.md)<br />[Telegram](./Telegram/README.md) | 1.0<br />2.1 | ✅<br />✅     | -<br />-     |
| 2024-09-30 | [WhatsApp](./WhatsApp/README.md)<br />[Telegram](./Telegram/README.md) | -<br />-     | N/A<br />N/A | -<br />-     |