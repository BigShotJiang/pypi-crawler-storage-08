# Application daily
## Today - 2024-10-02

### New version: -
### Recognition: N/A
### Support: N/A

| Date       | New version   | Recognition   | Parsing   | Run status   |
|:-----------|:--------------|:--------------|:----------|:-------------|
| 2024-10-02 | -             | N/A           | N/A       | ⚠️           |

__________

## Previous days

In the Recognition and Parsing columns, only the files that have possible regression are listed.

| Date       | New version   | Recognition   | Parsing   | Run status   |
|:-----------|:--------------|:--------------|:----------|:-------------|
| 2024-10-02 | -             | N/A           | N/A       | ⚠️           |
| 2024-10-01 | 1.0           | ✅             | ✅         | -            |
