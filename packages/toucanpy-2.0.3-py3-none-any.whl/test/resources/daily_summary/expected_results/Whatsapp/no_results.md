# Application daily
## Today - 2024-10-02

### New version: 2.0
### Recognition: ❔
### Support: ❔

| Date       |   New version | Recognition   | Parsing   | Run status   |
|:-----------|--------------:|:--------------|:----------|:-------------|
| 2024-10-02 |           2.0 | -             | -         | -            |

__________

## Previous days

In the Recognition and Parsing columns, only the files that have possible regression are listed.

| Date       |   New version | Recognition   | Parsing   | Run status   |
|:-----------|--------------:|:--------------|:----------|:-------------|
| 2024-10-02 |           2.0 | -             | -         | -            |
| 2024-10-01 |           1.0 | ✅             | ✅         | -            |
