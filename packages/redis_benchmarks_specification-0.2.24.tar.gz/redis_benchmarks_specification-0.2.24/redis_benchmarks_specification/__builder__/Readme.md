
## Run in local development mode

Within root project folder
```
poetry run redis-benchmarks-spec-builder
```
