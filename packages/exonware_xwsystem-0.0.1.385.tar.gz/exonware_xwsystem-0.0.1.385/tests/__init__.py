"""
xSystem Unit Tests Package

Unit tests for xSystem components.
Organized by component functionality following pytest best practices.
"""

from exonware.xwsystem.version import __version__ 