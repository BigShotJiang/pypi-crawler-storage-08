def hello():
    print("Hello from flibbyno!")
