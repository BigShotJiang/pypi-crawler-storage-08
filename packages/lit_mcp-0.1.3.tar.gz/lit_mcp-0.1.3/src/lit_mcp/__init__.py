"""lit-mcp: A MCP server for academic literature search."""

__version__ = "0.1.0"
