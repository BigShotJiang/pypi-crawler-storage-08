from collections import namedtuple

CharacterizedRow = namedtuple(
    "CharacterizedRow", ["date", "amount", "flow", "activity"]
)
