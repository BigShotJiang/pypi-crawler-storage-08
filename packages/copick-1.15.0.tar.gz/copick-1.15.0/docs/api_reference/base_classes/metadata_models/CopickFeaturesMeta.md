[](){#CopickFeaturesMeta}
::: copick.models.CopickFeaturesMeta
    options:
        show_if_no_docstring: true
