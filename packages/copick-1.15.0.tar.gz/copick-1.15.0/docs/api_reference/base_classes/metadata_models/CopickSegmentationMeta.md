[](){#CopickSegmentationMeta}
::: copick.models.CopickSegmentationMeta
    options:
        show_if_no_docstring: true
