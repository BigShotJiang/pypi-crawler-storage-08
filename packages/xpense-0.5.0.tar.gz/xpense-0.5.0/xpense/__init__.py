"""xpense - A beautiful CLI expense and income tracker."""

__version__ = "0.5.0"