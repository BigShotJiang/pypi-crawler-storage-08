#pragma once

#include "structures/array.hpp"
#include "structures/arrayfunctions.hpp"