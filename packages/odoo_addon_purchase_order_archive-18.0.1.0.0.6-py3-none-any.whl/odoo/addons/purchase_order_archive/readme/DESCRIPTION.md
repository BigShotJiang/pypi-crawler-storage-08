On a system with a high volume of purchases, the number of purchase
orders displayed in the list view can become huge. This module allows to
archive Purchase Orders that are in status Locked or Cancelled.

If a purchase order is archived, it will be hidden from the purchase
orders list view.

This module only depends on module purchase, but it could be used in
combination with OCA module 'record_archiver' in order to automatically
archive old purchase orders.
