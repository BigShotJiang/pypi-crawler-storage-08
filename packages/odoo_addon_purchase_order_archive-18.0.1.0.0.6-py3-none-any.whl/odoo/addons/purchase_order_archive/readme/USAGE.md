To archive purchase orders, you need to:

1.  Open the tree view of purchase orders.
2.  Select a purchase order (in status Locked or Cancelled) you want to
    archive.
3.  Click on Action \> Archive. Confirm.
4.  The purchase order is now archived.

To unarchive purchase orders, you need to:

1.  Open the tree view of purchase orders.
2.  In the filter box select the Archived filter. The list of archived
    purchase orders will be displayed.
3.  Select the purchase order (in status Locked or Cancelled) you want
    to restore to Active.
4.  Click on Action \> Unarchive.
5.  The purchase order is now active.
