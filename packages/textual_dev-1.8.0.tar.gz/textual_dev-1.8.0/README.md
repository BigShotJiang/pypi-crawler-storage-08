# textual-dev

Development tools for Textual.

![checks](https://github.com/Textualize/textual-dev/actions/workflows/pythonpackage.yml/badge.svg?event=push)


This package contains the `textual` command line app, which will help to develop Textual applications.

See [Getting Started](https://textual.textualize.io/getting_started/) for how to use it.
