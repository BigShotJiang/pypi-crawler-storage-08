"""Redis Pydantic - Pydantic models with Redis as the backend."""

from .base import BaseRedisModel

__version__ = "0.1.0"
__all__ = ["BaseRedisModel"]
