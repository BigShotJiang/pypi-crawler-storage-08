

class Options:

# basic options boilerplate here
    def __init__(self):
        self.verbose = False
        self.log_file = None
        self.temp_dir = None
        self.data_dir = None


options = Options()