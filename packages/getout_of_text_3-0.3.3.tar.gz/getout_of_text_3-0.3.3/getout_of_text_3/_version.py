__version__ = "0.3.3"

def get_versions():
    return {"version": __version__}
