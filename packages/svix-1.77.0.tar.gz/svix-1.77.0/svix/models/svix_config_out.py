# this file is @generated

from .common import BaseModel


class SvixConfigOut(BaseModel):
    pass
