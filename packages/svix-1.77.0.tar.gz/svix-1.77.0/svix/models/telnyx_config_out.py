# this file is @generated

from .common import BaseModel


class TelnyxConfigOut(BaseModel):
    public_key: str
