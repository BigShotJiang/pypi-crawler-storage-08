# this file is @generated

from .common import BaseModel


class OrumIoConfig(BaseModel):
    public_key: str
