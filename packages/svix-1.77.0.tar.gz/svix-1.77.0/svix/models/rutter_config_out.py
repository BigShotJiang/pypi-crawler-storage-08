# this file is @generated

from .common import BaseModel


class RutterConfigOut(BaseModel):
    pass
