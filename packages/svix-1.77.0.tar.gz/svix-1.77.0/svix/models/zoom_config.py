# this file is @generated

from .common import BaseModel


class ZoomConfig(BaseModel):
    secret: str
