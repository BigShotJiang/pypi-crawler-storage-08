## [2.0.12] - 2025-10-09

### Changed
- Use dict for Header class by @cmancone in [#23](https://github.com/clearskies-py/clearskies/pull/23)
- Make headers a dict

