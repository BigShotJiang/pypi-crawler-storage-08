class Authorization(Exception):
    pass
