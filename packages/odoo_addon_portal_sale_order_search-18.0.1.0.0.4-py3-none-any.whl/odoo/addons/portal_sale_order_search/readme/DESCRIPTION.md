This module enables the portal search feature for sales orders and
quotations.
