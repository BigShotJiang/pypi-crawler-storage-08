"""Внутренняя библиотека для pygismeteo и aiopygismeteo."""

from __future__ import annotations

__version__ = "6.0.2"
