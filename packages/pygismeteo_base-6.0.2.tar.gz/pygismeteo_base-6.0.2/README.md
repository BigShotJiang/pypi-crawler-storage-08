# pygismeteo-base

[![CI](https://github.com/monosans/pygismeteo-base/actions/workflows/ci.yml/badge.svg)](https://github.com/monosans/pygismeteo-base/actions/workflows/ci.yml)
[![Downloads](https://static.pepy.tech/badge/pygismeteo-base)](https://pepy.tech/project/pygismeteo-base)

Внутренняя библиотека для [pygismeteo](https://github.com/monosans/pygismeteo) и [aiopygismeteo](https://github.com/monosans/aiopygismeteo).

## License / Лицензия

[MIT](https://github.com/monosans/pygismeteo-base/blob/main/LICENSE)
