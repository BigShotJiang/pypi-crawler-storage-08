"""Python bindings for html-to-markdown Rust library."""

from html_to_markdown._html_to_markdown import convert

__all__ = ["convert"]
