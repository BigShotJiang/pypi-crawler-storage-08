"""Dallinger version number."""

__version__ = "11.5.2"
