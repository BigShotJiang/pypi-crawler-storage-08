def main():
    from dallinger.heroku.clock import launch

    launch()


if __name__ == "__main__":
    main()
