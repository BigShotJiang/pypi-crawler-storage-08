API Reference
=============

.. automodapi:: curies
    :no-heading:

.. automodapi:: curies.dataframe
    :no-heading:
