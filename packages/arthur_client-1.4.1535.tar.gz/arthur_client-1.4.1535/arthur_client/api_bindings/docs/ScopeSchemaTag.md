# ScopeSchemaTag


## Enum

* `LLM_CONTEXT` (value: `'llm_context'`)

* `LLM_PROMPT` (value: `'llm_prompt'`)

* `LLM_RESPONSE` (value: `'llm_response'`)

* `PRIMARY_TIMESTAMP` (value: `'primary_timestamp'`)

* `CATEGORICAL` (value: `'categorical'`)

* `CONTINUOUS` (value: `'continuous'`)

* `PREDICTION` (value: `'prediction'`)

* `GROUND_TRUTH` (value: `'ground_truth'`)

* `PIN_IN_DEEP_DIVE` (value: `'pin_in_deep_dive'`)

* `POSSIBLE_SEGMENTATION` (value: `'possible_segmentation'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


