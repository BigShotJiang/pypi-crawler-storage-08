.. _manager:

Project Configuration and Management - ``ORBIT.manager``
==============================================================

.. autoclass:: ORBIT.manager.ProjectManager
   :members:
