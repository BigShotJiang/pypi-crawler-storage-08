Mooring System Installation API
===============================

For detailed methodology, please see
:doc:`Mooring System Installation Methodology <doc_MooringSystemInstallation>`.

.. autoclass:: ORBIT.phases.install.MooringSystemInstallation
   :members:
