Gravity-Based Foundation Installation Methodology
=================================================

For details of the code implementation, please see
:doc:`Moored Substructure Installation API <api_GravityBasedInstallation>`.

Overview
--------

This module will be expanded in a future release.
