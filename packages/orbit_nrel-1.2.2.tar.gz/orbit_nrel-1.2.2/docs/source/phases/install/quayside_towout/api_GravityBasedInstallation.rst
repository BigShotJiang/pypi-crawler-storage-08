Gravity-Based Foundation Installation API
=========================================

For detailed methodology, please see
:doc:`Gravity-Based Foundation Installation Methodology <doc_GravityBasedInstallation>`.

.. autoclass:: ORBIT.phases.install.GravityBasedInstallation
   :members:
