Moored Substructure Installation API
====================================

For detailed methodology, please see
:doc:`Moored Substructure Installation Methodology <doc_MooredSubInstallation>`.

.. autoclass:: ORBIT.phases.install.MooredSubInstallation
   :members:
