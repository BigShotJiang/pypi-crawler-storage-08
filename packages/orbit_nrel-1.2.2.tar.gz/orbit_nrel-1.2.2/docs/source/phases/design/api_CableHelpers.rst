Cabling Helper Classes
======================

For detailed methodology, please see
:doc:`Cable Helper Design <doc_CableHelpers>`.

.. autoclass:: ORBIT.phases.design._cables.Cable
   :members:

.. autoclass:: ORBIT.phases.design._cables.Plant
   :members:

.. autoclass:: ORBIT.phases.design._cables.CableSystem
   :members:
