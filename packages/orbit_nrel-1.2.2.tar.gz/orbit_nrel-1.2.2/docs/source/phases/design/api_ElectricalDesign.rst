Electrical System Design API
============================

For detailed methodology, please see
:doc:`Electrical System Design <doc_ElectricalDesign>`.

.. autoclass:: ORBIT.phases.design.ElectricalDesign
   :members:
