Scour Protection Design API
===========================

For detailed methodology, please see
:doc:`Scour Protection Design <doc_ScourProtectionDesign>`.

.. autoclass:: ORBIT.phases.design.ScourProtectionDesign
   :members:
