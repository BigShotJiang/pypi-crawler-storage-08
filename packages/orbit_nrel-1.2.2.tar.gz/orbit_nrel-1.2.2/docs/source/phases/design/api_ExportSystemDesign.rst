Export System Design API
========================

For detailed methodology, please see
:doc:`Export System Design <doc_ExportSystemDesign>`.

.. autoclass:: ORBIT.phases.design.ExportSystemDesign
   :members:
