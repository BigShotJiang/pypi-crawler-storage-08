Semi-Submersible Design API
===========================

For detailed methodology, please see
:doc:`Semi-Submersible Design <doc_SemiSubmersibleDesign>`.

.. autoclass:: ORBIT.phases.design.SemiSubmersibleDesign
   :members:
