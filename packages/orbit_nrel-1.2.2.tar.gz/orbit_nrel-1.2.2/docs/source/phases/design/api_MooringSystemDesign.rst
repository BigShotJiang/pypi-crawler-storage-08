Mooring System Design API
=========================

For detailed methodology, please see
:doc:`Mooring System Design <doc_MooringSystemDesign>`.

.. autoclass:: ORBIT.phases.design.MooringSystemDesign
   :members:
