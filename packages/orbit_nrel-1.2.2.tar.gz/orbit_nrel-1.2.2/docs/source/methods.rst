.. _methods:

Methodology
===========

.. toctree::
   :maxdepth: 2

   doc_ProjectManager
   doc_ParametricManager
   doc_DesignPhase
   doc_InstallPhase
   doc_CommonCost
