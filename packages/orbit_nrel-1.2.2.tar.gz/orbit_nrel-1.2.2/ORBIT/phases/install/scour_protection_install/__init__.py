__author__ = "Rob Hammond"
__copyright__ = "Copyright 2020, National Renewable Energy Laboratory"
__maintainer__ = "Rob Hammond"
__email__ = "rob.hammond@nrel.gov"

from .standard import ScourProtectionInstallation
