# ---------------------------------------------------------------------
# Copyright (c) 2025 Qualcomm Technologies, Inc. and/or its subsidiaries.
# SPDX-License-Identifier: BSD-3-Clause
# ---------------------------------------------------------------------

import numpy as np
import pytest

from qai_hub_models.models._shared.cityscapes_segmentation.app import (
    CityscapesSegmentationApp,
)
from qai_hub_models.models.efficientvit_l2_seg.demo import main as demo_main
from qai_hub_models.models.efficientvit_l2_seg.model import (
    MODEL_ASSET_VERSION,
    MODEL_ID,
    EfficientViT,
)
from qai_hub_models.utils.asset_loaders import CachedWebModelAsset, load_image
from qai_hub_models.utils.testing import assert_most_same, skip_clone_repo_check

# This image showcases the Cityscapes classes (but is not from the dataset)
TEST_CITYSCAPES_LIKE_IMAGE_NAME = "cityscapes_like_demo_2048x1024.jpg"
TEST_CITYSCAPES_LIKE_IMAGE_ASSET = CachedWebModelAsset.from_asset_store(
    MODEL_ID, MODEL_ASSET_VERSION, TEST_CITYSCAPES_LIKE_IMAGE_NAME
)

OUTPUT_IMAGE_NAME = "reference_output_image.png"
OUTPUT_IMAGE_ASSET = CachedWebModelAsset.from_asset_store(
    MODEL_ID, MODEL_ASSET_VERSION, OUTPUT_IMAGE_NAME
)


# Verify that the output from Torch is as expected.
@skip_clone_repo_check
def test_task() -> None:
    app = CityscapesSegmentationApp(
        EfficientViT.from_pretrained(), EfficientViT.get_input_spec()
    )
    # fetch and load images
    image = TEST_CITYSCAPES_LIKE_IMAGE_ASSET.fetch()
    orig_image = load_image(image)
    image = OUTPUT_IMAGE_ASSET.fetch()
    output_image = load_image(image)
    # Run and assert accuracy
    image_annotated = app.predict(orig_image)
    assert_most_same(
        np.asarray(image_annotated), np.asarray(output_image), diff_tol=0.01
    )


@pytest.mark.trace
@skip_clone_repo_check
def test_trace() -> None:
    app = CityscapesSegmentationApp(
        EfficientViT.from_pretrained().convert_to_torchscript(),
        EfficientViT.get_input_spec(),
    )
    # fetch and load images
    image = TEST_CITYSCAPES_LIKE_IMAGE_ASSET.fetch()
    orig_image = load_image(image)
    image = OUTPUT_IMAGE_ASSET.fetch()
    output_image = load_image(image)
    # Run and assert accuracy
    image_annotated = app.predict(orig_image)
    assert_most_same(
        np.asarray(image_annotated), np.asarray(output_image), diff_tol=0.01
    )


@skip_clone_repo_check
def test_demo() -> None:
    demo_main(is_test=True)
