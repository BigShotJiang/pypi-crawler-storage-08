# ---------------------------------------------------------------------
# Copyright (c) 2025 Qualcomm Technologies, Inc. and/or its subsidiaries.
# SPDX-License-Identifier: BSD-3-Clause
# ---------------------------------------------------------------------

from qai_hub_models.models._shared.repaint.app import (  # noqa: F401
    RepaintMaskApp as App,
)

from .model import AOTGAN as Model  # noqa: F401
from .model import MODEL_ID  # noqa: F401
