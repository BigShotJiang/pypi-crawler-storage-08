class ImproperlyConfiguredError(Exception):
    pass
