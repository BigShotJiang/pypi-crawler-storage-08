"""Compatibility exports for code referencing the old schema module."""

from atlas.config.models import AtlasConfig

__all__ = ["AtlasConfig"]
