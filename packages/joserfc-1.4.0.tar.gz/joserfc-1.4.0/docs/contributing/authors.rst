Authors
=======

``joserfc`` is written and maintained by `Hsiaoming Yang <https://lepture.com>`_.


Contributors
------------

Here is the list of the main contributors:

.. contributors:: authlib/joserfc
    :contributions:

And more on https://github.com/authlib/joserfc/graphs/contributors
