"""
BioQL 5.0.0 - Visualization Examples

This package contains example scripts demonstrating BioQL's QEC
visualization and resource estimation capabilities.
"""
