var x= "    lalalala;
