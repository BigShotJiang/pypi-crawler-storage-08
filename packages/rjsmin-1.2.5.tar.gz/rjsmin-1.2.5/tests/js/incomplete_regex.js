var x= /lalalala
