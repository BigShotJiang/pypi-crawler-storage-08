
from setuptools import setup

setup(package_data={'flake8_rst_docstrings-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
