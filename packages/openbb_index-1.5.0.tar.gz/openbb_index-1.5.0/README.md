# OpenBB Index Extension

The Index extension provides global and european index data access for the OpenBB Platform.

## Installation

To install the extension, run the following command in this folder:

```bash
pip install openbb-index
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
