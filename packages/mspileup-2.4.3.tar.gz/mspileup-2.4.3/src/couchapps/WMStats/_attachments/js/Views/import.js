//import common scripts
WMStats.Globals.importScripts(["js/Views/WMStats.CategoryMap.js",
                               "js/Views/WMStats.View.IndexHTML.js"]);