# __init__.py

from multimodal_sdk.knowledge_base.main import KnowledgeBase