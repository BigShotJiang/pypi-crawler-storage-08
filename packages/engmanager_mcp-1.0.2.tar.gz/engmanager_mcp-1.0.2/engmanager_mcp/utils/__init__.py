"""Utility modules for Engineering Manager MCP"""
