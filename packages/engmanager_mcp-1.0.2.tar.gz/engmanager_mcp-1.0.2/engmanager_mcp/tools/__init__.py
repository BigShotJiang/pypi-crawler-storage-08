"""MCP tools for workflow guidance"""
