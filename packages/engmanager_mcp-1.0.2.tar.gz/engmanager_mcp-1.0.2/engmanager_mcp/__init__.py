"""Engineering Manager MCP - Workflow guidance for LLMs"""

__version__ = "1.0.0"
__author__ = "Simon Carr"
__email__ = "simon.carr@gmail.com"
