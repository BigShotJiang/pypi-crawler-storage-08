"""Configuration module for Engineering Manager MCP"""
