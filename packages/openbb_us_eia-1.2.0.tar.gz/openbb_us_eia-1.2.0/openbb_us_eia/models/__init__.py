"""OpenBB EIA Provider Models."""
