"""
STIX2 to Colander conversion module.

This module provides functionality for converting between STIX2 and Colander data formats.
"""
