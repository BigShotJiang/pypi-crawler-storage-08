from toucan.utils import PROJECT_ROOT

RESOURCE_ROOT = PROJECT_ROOT / "test" / "resources"
