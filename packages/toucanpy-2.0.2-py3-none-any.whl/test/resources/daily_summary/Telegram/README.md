# Application daily
## Today - 2024-10-02

### New version: 2.5
### Recognition: ❌
### Support: ❌

|    | Date       |   New version | Recognition                                       | Parsing                                                                                                                                                                              | Run status   |
|---:|:-----------|--------------:|:--------------------------------------------------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:-------------|
|  0 | 2024-10-02 |           2.5 | ❌ wa.db<br/>❌ locations.db<br/>✅ contacts.db<br/> | ❌ wa.db:has_pictures<br/>❌ wa.db:has_locations<br/>❌ contacts.db:has_contact_names<br/>✅ wa.db:has_messages<br/>✅ contacts.db:has_phone_numbers<br/>✅ locations.db:has_location<br/> | -            |

__________

## Previous days

In the Recognition and Parsing columns, only the files that have possible regression are listed.

|    | Date       |   New version | Recognition                                       | Parsing                                                                                                                                                                              | Run status   |
|---:|:-----------|--------------:|:--------------------------------------------------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:-------------|
|  0 | 2024-10-02 |           2.5 | ❌ wa.db<br/>❌ locations.db<br/>✅ contacts.db<br/> | ❌ wa.db:has_pictures<br/>❌ wa.db:has_locations<br/>❌ contacts.db:has_contact_names<br/>✅ wa.db:has_messages<br/>✅ contacts.db:has_phone_numbers<br/>✅ locations.db:has_location<br/> | -            |
|  1 |            |           2.5 | ❌ wa.db<br/>❌ locations.db<br/>✅ contacts.db<br/> | ❌ wa.db:has_pictures<br/>❌ wa.db:has_locations<br/>❌ contacts.db:has_contact_names<br/>✅ wa.db:has_messages<br/>✅ contacts.db:has_phone_numbers<br/>✅ locations.db:has_location<br/> | -            |
|  2 | 2024-10-02 |           2.5 | ❌ wa.db<br/>❌ locations.db<br/>✅ contacts.db<br/> | ❌ wa.db:has_pictures<br/>❌ wa.db:has_locations<br/>❌ contacts.db:has_contact_names<br/>✅ wa.db:has_messages<br/>✅ contacts.db:has_phone_numbers<br/>✅ locations.db:has_location<br/> | -            |
|  3 | 2024-10-02 |           2.5 | ❌ wa.db<br/>❌ locations.db<br/>✅ contacts.db<br/> | ❌ wa.db:has_pictures<br/>❌ wa.db:has_locations<br/>❌ contacts.db:has_contact_names<br/>✅ wa.db:has_messages<br/>✅ contacts.db:has_phone_numbers<br/>✅ locations.db:has_location<br/> | -            |
