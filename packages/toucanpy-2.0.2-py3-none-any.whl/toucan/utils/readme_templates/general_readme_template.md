# Toucan daily
## Today - CURRENT_DATE

## All applications supported - SUPPORT
TABLE_TODAY

__________
## Previous days

TABLE_PREVIOUS