# Application daily
## Today - CURRENT_DATE

### New version: NEW_VERSION
### Recognition: RECOGNITION
### Support: SUPPORT

TABLE_TODAY

__________

## Previous days

In the Recognition and Parsing columns, only the files that have possible regression are listed.

TABLE_PREVIOUS
