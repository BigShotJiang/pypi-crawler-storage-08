import logging


RUN_SNAPSHOT_PREFIX = 'Toucan_run'

logger = logging.getLogger(__name__)  # note that log setup is done in `run.py`
