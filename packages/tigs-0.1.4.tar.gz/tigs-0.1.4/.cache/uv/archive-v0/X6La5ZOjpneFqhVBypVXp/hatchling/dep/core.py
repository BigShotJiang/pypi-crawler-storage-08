from hatchling.cli.dep.core import dependencies_in_sync  # noqa: F401
