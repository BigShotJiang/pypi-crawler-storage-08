"""Tests for the Tig package."""
