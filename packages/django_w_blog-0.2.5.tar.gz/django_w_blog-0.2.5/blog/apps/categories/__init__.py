"""Blog article categories"""
