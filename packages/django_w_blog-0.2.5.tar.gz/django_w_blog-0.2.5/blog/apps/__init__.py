"""Django blog Apps"""
