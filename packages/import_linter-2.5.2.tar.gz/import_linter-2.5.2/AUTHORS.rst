
Authors
=======

* David Seddon - https://seddonym.me


Contributors
============

* Anthony Sottile - https://github.com/asottile
* Łukasz Skarżyński - https://github.com/skarzi
* Daniel Jurczak - https://github.com/danieljurczak
* Ben Warren - https://github.com/bwarren
* Aaron Gokaslan - https://github.com/Skylion007
* Kai Mueller - https://github.com/kasium
* Daniele Esposti - https://github.com/expobrain
* Petter Friberg - https://github.com/flaeppe
* James Owen - https://github.com/leamingrad
* Matthew Gamble - https://github.com/mwgamble
* Nick Pope - https://github.com/ngnpope
* piglei - https://github.com/piglei
* Anton Gruebel - https://github.com/gruebel
* Peter Byfield - https://github.com/Peter554
* Fabian Binz - https://github.com/fbinz
* Neil Williams - https://github.com/spladug
* Nicholas Bunn - https://github.com/NicholasBunn
* Felix Uhl - https://github.com/iFreilicht
* Ilya S. (Tapeline) - https://github.com/Tapeline
* Uberto Barbini - https://github.com/uberto
* Alexandre Beaufays - https://github.com/abeaufays
