.. include:: ../README.rst

For more details, see :doc:`usage`.
