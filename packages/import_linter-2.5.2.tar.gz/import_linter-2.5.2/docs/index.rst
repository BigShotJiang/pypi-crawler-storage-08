========
Contents
========

.. toctree::
   :maxdepth: 2

   readme
   installation
   usage
   api
   contract_types
   custom_contract_types
   caching
   toml
   contributing
   authors
   changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

