from typing import Any, Dict, List, Union

CompositeIdAlias = List[Union[str, int]]
RecordsDataAlias = Dict[str, Any]
