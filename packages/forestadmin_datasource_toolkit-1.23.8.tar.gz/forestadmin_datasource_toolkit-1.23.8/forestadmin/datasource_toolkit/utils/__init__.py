def removeprefix(base: str, prefix: str):
    return base[len(prefix) :]
