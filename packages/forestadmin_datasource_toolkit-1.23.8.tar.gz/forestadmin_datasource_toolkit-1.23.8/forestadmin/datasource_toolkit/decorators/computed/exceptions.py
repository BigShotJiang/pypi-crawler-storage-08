from forestadmin.datasource_toolkit.exceptions import DatasourceToolkitException


class ComputedDecoratorException(DatasourceToolkitException):
    pass
