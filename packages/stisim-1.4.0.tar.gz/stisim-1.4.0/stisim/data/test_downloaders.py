"""
Test data downloaders; does not require a full STIsim install
"""

import downloaders as dl
dl.download_data('kenya', start=2000)
