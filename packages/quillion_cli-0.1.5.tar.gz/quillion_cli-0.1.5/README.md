Quillion CLI

Internal CLI tool for the Quillion web framework.

Overview

Part of the Quillion package. Provides development utilities for Quillion applications.

Usage

```bash
q [command]
```

Commands

· new - Create project

· run - Start server

Quillion CLI is included with the Quillion framework installation.

License

MIT