---
title: Welcome
description: A page description. It overrides the default description.
---

This is an example of a regular page. It uses the `page.jinja` view.

This markdown file can be placed directly inside `content` or on any subfolder inside of it.

If you don't include this markdown file in your `pages` list, it will not appear in your documentation.
