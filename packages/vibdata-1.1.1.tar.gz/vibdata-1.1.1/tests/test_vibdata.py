from vibdata import __version__


def test_version():
    assert __version__ == "0.7.0"
