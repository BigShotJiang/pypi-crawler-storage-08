* Not all the taxes combination can be compatible with global discounts. An
  error is raised in that cases.
* Currently, taxes in invoice lines are mandatory with global discounts.
