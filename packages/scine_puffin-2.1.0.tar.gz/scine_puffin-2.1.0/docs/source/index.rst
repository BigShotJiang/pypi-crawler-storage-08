.. scine_puffin master file

Puffin
======

.. image:: res/puffin_header.png
   :width: 100 %
   :alt: Puffin

.. toctree::
   :maxdepth: 3

   readme
   configuration
   programs
   jobs
   api
   utilities
   changelog
