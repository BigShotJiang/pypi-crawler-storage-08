Settings
========

All settings in Puffin are controlled via the ``Configuration``. The
``puffin.yml`` file represents the content of this class. All settings are
explained defined in the documentation of the ``Configuration``, hence it is
shown below.

.. autoclass:: scine_puffin.config.Configuration
   :noindex:
