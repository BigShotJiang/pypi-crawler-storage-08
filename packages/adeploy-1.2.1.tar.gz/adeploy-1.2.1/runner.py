#!/usr/bin/env python
"""Convenience wrapper for running directly from source tree, without installation via setuptools."""
from adeploy.main import main

if __name__ == '__main__':
    main()