ASCIINEMA_PLAYER_VERSION=3.7.0

wget https://github.com/asciinema/asciinema-player/releases/download/v${ASCIINEMA_PLAYER_VERSION}/asciinema-player.css -O css/asciinema-player.css
wget https://github.com/asciinema/asciinema-player/releases/download/v${ASCIINEMA_PLAYER_VERSION}/asciinema-player.min.js -O js/asciinema-player.min.js
