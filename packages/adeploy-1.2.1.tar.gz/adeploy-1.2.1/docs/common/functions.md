# Jinja Functions
<!-- md:provider Jinja --> <!-- md:provider Helm -->

::: adeploy.common.jinja.globals.Handler
    handler: python
    options:
      show_bases: false
      show_root_heading: false
      show_source: true
