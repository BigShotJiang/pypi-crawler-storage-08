from adeploy.common.yaml.update import update

__all__ = ['update']