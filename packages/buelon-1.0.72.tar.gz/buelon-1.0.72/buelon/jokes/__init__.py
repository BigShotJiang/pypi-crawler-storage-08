from . import jokes





__all__ = ['jokes']
