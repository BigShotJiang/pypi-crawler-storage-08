"""Neo - A self-improving code reasoning engine with persistent semantic memory."""

__version__ = "0.7.0"

__all__ = ["__version__"]
