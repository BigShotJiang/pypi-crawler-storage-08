#[derive(tensorzero_derive::TensorZeroDeserialize)]
struct MyStruct {
    field: u8,
}

fn main() {}
