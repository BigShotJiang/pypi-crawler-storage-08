# Single source of truth for package/app version
__version__ = "0.1.4"
