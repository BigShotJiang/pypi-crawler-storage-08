===========
alfasim-sdk
===========


.. image:: https://img.shields.io/pypi/v/alfasim-sdk.svg
        :target: https://pypi.python.org/pypi/alfasim-sdk

.. image:: https://github.com/ESSS/alfasim-sdk/workflows/ALFAsim%20SDK/badge.svg
    :target: https://github.com/ESSS/alfasim-sdk/actions?query=workflow%3A%22ALFAsim+SDK%22

.. image:: https://codecov.io/gh/ESSS/alfasim-sdk/branch/master/graph/badge.svg
    :target: https://codecov.io/gh/ESSS/alfasim-sdk

.. image:: https://readthedocs.org/projects/alfasim-sdk/badge/?version=latest
    :target: https://alfasim-sdk.readthedocs.io/en/latest/?badge=latest
    :alt: Documentation Status

.. image:: https://img.shields.io/badge/code%20style-black-000000.svg
    :target: https://github.com/python/black

.. image:: https://sonarcloud.io/api/project_badges/measure?project=ESSS_alfasim-sdk&metric=alert_status
    :target: https://sonarcloud.io/project/overview?id=ESSS_alfasim-sdk



ALFAsim API/SDK


* Free software: MIT license
* Documentation: https://alfasim-sdk.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
