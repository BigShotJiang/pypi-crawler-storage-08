mod layered;
pub(crate) use layered::LayeredGraph;
mod random;
pub use random::gnm_graph_edges;
