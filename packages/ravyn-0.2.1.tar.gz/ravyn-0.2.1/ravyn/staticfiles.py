from lilya.staticfiles import StaticFiles as StaticFiles  # noqa
