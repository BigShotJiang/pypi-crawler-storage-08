from lilya.middleware.wsgi import WSGIMiddleware

__all__ = ["WSGIMiddleware"]
