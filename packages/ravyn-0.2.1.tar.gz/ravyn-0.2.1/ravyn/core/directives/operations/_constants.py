import os

PATH = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
SECRET_KEY_INSECURE_PREFIX = "ravyn-insecure-"
RAVYN_SETTINGS_MODULE = "RAVYN_SETTINGS_MODULE"
