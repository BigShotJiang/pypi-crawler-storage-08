"""Opentrons CLI application entry point."""

from . import main

main()
