CLIENT_ID = "nl-public"
AUTHORIZE_URL = "https://keycloak.ngiapi.no/auth/realms/tenant-geohub-public/protocol/openid-connect/auth"
TOKENS_URL = "https://keycloak.ngiapi.no/auth/realms/tenant-geohub-public/protocol/openid-connect/token"
BASE_URL = "https://api.ngilive.no"

APP_NAME = "NGILive"
