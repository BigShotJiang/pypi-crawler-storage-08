"""Cloud-init template system for spot deployer."""
