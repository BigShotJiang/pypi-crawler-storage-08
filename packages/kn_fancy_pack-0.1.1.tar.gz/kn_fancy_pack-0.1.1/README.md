# kn-fancy-pack

Tiny guessing game library with a programatic API and CLI. Exported function:

- startguesssing(start, end): interactive guessing game between start and end (inclusive).

See tests and CLI for usage.
