"""kn_fancy_pack: tiny guessing game API"""

from .game import startguesssing

__all__ = ["startguesssing"]
