"""
Business Agent - AI-Powered Business Execution Assistant
"""

__version__ = "1.0.0"
