"""Package entry point."""
from . import main

if "__main__" == __name__:
    main.run()
