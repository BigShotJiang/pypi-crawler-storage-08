
from . import conf
from . import hero
from . import metadata
from . import version
from . metadata import Savefile

__version__ = conf.Version
__VERSION__ = conf.Version


version.init()
