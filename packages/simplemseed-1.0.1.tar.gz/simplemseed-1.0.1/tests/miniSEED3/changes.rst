.. _changes:

========================
Changes
========================

Changes to this specification are listed below.

April 2023
--------------

* Specification revision 2023-01-18 adopted by FDSN.
* Reference data were refined following the specification revision.


2021
--------------

* Initial specification of miniSEED 3
