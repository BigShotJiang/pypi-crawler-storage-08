:py:mod:`simplemseed.version`
=============================

.. py:module:: simplemseed.version

.. autodoc2-docstring:: simplemseed.version
   :allowtitles:

Module Contents
---------------

Data
~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`VERSION <simplemseed.version.VERSION>`
     - .. autodoc2-docstring:: simplemseed.version.VERSION
          :summary:

API
~~~

.. py:data:: VERSION
   :canonical: simplemseed.version.VERSION
   :value: None

   .. autodoc2-docstring:: simplemseed.version.VERSION
