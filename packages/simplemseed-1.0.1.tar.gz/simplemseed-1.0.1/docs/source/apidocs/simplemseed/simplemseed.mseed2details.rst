:py:mod:`simplemseed.mseed2details`
===================================

.. py:module:: simplemseed.mseed2details

.. autodoc2-docstring:: simplemseed.mseed2details
   :allowtitles:

Module Contents
---------------

Functions
~~~~~~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`do_details <simplemseed.mseed2details.do_details>`
     - .. autodoc2-docstring:: simplemseed.mseed2details.do_details
          :summary:
   * - :py:obj:`do_parseargs <simplemseed.mseed2details.do_parseargs>`
     - .. autodoc2-docstring:: simplemseed.mseed2details.do_parseargs
          :summary:
   * - :py:obj:`main <simplemseed.mseed2details.main>`
     - .. autodoc2-docstring:: simplemseed.mseed2details.main
          :summary:

API
~~~

.. py:function:: do_details()
   :canonical: simplemseed.mseed2details.do_details

   .. autodoc2-docstring:: simplemseed.mseed2details.do_details

.. py:function:: do_parseargs()
   :canonical: simplemseed.mseed2details.do_parseargs

   .. autodoc2-docstring:: simplemseed.mseed2details.do_parseargs

.. py:function:: main()
   :canonical: simplemseed.mseed2details.main

   .. autodoc2-docstring:: simplemseed.mseed2details.main
