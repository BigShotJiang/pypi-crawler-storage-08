:py:mod:`simplemseed.util`
==========================

.. py:module:: simplemseed.util

.. autodoc2-docstring:: simplemseed.util
   :allowtitles:

Module Contents
---------------

Functions
~~~~~~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`isoWZ <simplemseed.util.isoWZ>`
     - .. autodoc2-docstring:: simplemseed.util.isoWZ
          :summary:

API
~~~

.. py:function:: isoWZ(time) -> str
   :canonical: simplemseed.util.isoWZ

   .. autodoc2-docstring:: simplemseed.util.isoWZ
