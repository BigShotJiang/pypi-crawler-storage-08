:py:mod:`simplemseed.mseed3merge`
=================================

.. py:module:: simplemseed.mseed3merge

.. autodoc2-docstring:: simplemseed.mseed3merge
   :allowtitles:

Module Contents
---------------

Functions
~~~~~~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`do_parseargs <simplemseed.mseed3merge.do_parseargs>`
     - .. autodoc2-docstring:: simplemseed.mseed3merge.do_parseargs
          :summary:
   * - :py:obj:`main <simplemseed.mseed3merge.main>`
     - .. autodoc2-docstring:: simplemseed.mseed3merge.main
          :summary:

API
~~~

.. py:function:: do_parseargs()
   :canonical: simplemseed.mseed3merge.do_parseargs

   .. autodoc2-docstring:: simplemseed.mseed3merge.do_parseargs

.. py:function:: main()
   :canonical: simplemseed.mseed3merge.main

   .. autodoc2-docstring:: simplemseed.mseed3merge.main
