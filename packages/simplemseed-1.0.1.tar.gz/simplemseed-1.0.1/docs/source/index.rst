.. simplemseed documentation master file, created by
   sphinx-quickstart on Wed Feb 28 09:34:51 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

SimpleMSeed
===========


`Miniseed3 <http://docs.fdsn.org/projects/miniseed3>`_ (and reading 2) in pure python.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   README <readme_link>
   apidocs/index



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
