from django.apps import AppConfig


class SodarcacheConfig(AppConfig):
    name = 'sodarcache'
