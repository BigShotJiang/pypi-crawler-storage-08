from django.contrib import admin

from appalerts.models import AppAlert

# Register your models here.
admin.site.register(AppAlert)
