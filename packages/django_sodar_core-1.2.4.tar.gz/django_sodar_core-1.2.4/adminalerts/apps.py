from django.apps import AppConfig


class AdminalertsConfig(AppConfig):
    name = 'adminalerts'
