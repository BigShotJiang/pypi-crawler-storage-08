"""Web interface for building polymo REST configurations."""

from .app import create_app

__all__ = ["create_app"]
