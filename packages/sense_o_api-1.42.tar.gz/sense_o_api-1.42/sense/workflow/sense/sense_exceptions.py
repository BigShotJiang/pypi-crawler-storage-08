class SenseException(Exception):
    """Base class for other exceptions"""
    pass
