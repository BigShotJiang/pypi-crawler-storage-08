from bitcoinrpc.authproxy import AuthServiceProxy as ServiceProxy, JSONRPCException
