#!/usr/bin/env python

from setuptools import setup

# All configuration is now in pyproject.toml
# This setup.py is kept for backward compatibility
setup()
