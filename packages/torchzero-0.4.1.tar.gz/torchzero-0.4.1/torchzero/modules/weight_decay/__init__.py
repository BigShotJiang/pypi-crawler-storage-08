from .weight_decay import WeightDecay, DirectWeightDecay, decay_weights_, RelativeWeightDecay
from .reinit import RandomReinitialize