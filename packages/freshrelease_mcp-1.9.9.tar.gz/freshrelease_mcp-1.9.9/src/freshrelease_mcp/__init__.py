from .server import main

__version__ = "1.9.9"
__all__ = ["main"]

