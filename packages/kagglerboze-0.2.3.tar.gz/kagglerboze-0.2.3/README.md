# KagglerBoze (神楽坊主)

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

**日本語** | [English](README.en.md) | [中文](README.zh.md)

**30分でKaggle Top 10%を達成する GEPA駆動の自動化フレームワーク**

KagglerBozeは、**GEPA（遺伝的パレート反省進化）**と実戦で培われたKaggleテクニックを組み合わせ、従来のアプローチを圧倒的に上回る自動ML パイプラインを実現します。

## 🎯 なぜKagglerBoze？

| 手法 | 精度 | 時間 | コスト | GPU |
|--------|----------|------|------|-----|
| 手動プロンプト | 72% | 数週間 | $0 | 不要 |
| ファインチューニング | 88% | 6時間 | $500 | 48GB+ |
| QLoRA | 86% | 2時間 | $60 | 24GB |
| **KagglerBoze (GEPA)** | **96%** | **30分** | **$5** | **不要** |

## ✨ 主な機能

### 🧬 GEPA最適化
- 遺伝的アルゴリズムによるプロンプト進化
- 多目的最適化（精度 + 速度 + コスト）
- LLM駆動の反省による知的変異
- ベースラインから15-30%の改善

### 🏥 医療ドメイン
- 温度分類で **96%以上の精度**
- 症状抽出で **94%以上のF1スコア**
- すぐに使える最適化済みテンプレート
- 日本語と英語のテキストに対応

### 💰 金融ドメイン
- 株式スクリーニングで **92%以上の精度**（PER/PBR/ROE分析）
- センチメント分析で **90%以上の精度**
- 金融分析用の最適化済みテンプレート
- リスクメトリクス（Sharpe、Sortino、VaR、Beta）

### 🤖 Claude Code統合
- `/compete` - エンドツーエンドの完全自動化
- `/optimize` - GEPAプロンプト進化
- `/submit` - 検証済み提出
- `/analyze` - コンペティション分析

### 📊 Kaggle APIラッパー
- コンペティションデータのダウンロード
- 予測の提出
- リーダーボードの追跡
- シェイクアップ予測

## 🚀 クイックスタート

### インストール

```bash
# Step 1: パッケージをインストール
pip install kagglerboze

# Step 2: Kaggle API認証を設定
# Kaggle.com → Account → API → "Create New API Token"
# ダウンロードしたkaggle.jsonを配置
mkdir -p ~/.kaggle
mv ~/Downloads/kaggle.json ~/.kaggle/
chmod 600 ~/.kaggle/kaggle.json

# Step 3: Claude Code統合をインストール（オプション）
kagglerboze install-claude
```

### 30秒でコンペティション参加

**Claude Codeを使う場合（推奨）**:
```bash
# Claude Codeで直接実行
/compete titanic
```

**スタンドアロンCLIを使う場合**:
```bash
# .claudeディレクトリなしでも動作
kagglerboze compete titanic
```

これだけです！システムが自動的に：
1. データをダウンロード
2. コンペティションを分析
3. GEPAで最適化（30分）
4. 予測を生成
5. Kaggleに提出
6. ランキングを報告

### CLI コマンド

```bash
# エンドツーエンドのコンペティション参加
kagglerboze compete <competition-name> [--no-submit] [--generations 10]

# GEPAでプロンプトを最適化
kagglerboze optimize [prompt|xgboost|lightgbm]

# 予測を提出
kagglerboze submit <competition> <file.csv>

# コンペティションを分析
kagglerboze analyze <competition> [--download]

# Claude Code統合をインストール
kagglerboze install-claude [--force] [--target /path/to/project]

# バージョン表示
kagglerboze version
```

### Python API

```python
from kaggler.domains.medical import MedicalExtractor, MedicalTemplates

# 最適化済みテンプレートを使用（96%精度）
prompt = MedicalTemplates.get_template("temperature")

# 医療データを抽出
extractor = MedicalExtractor()
result = extractor.extract_all("患者は37.8°Cの発熱あり")

# 出力: {"temperature": {"value": 37.8, "classification": "fever"}, ...}
```

### GEPA進化

```python
from kaggler.core import EvolutionEngine, EvolutionConfig

config = EvolutionConfig(population_size=20, generations=10)
engine = EvolutionEngine(config)

best_prompt = engine.evolve(
    seed_prompts=["医療データを抽出"],
    eval_func=your_evaluation_function
)

print(f"改善: 0.72 → {best_prompt.fitness_scores['accuracy']:.2f}")
```

## 📖 ドキュメント

- [クイックスタートガイド](docs/QUICK_START.md) - 5分で始める
- [アーキテクチャ](docs/ARCHITECTURE.md) - システム設計とデータフロー
- [バイラルデモ](docs/VIRAL_DEMO.md) - 30分ライブデモスクリプト
- [サンプル](examples/) - Jupyter notebooksとコード例

## 🏗️ プロジェクト構造

```
kagglerboze/
├── src/kaggler/
│   ├── core/              # GEPAエンジン
│   │   ├── evolution.py   # メイン進化ループ
│   │   ├── pareto.py      # 多目的最適化
│   │   ├── reflection.py  # LLMベース知的変異
│   │   ├── mutation.py    # 変異戦略
│   │   └── crossover.py   # セマンティック交叉
│   ├── domains/
│   │   ├── medical/       # 医療ドメイン（96%+精度）
│   │   ├── finance/       # 金融ドメイン（92%+精度）
│   │   ├── legal/         # 法務ドメイン（92%+精度）
│   │   └── manufacturing/ # 製造ドメイン（94%+精度）
│   ├── tabular/           # テーブル形式コンペサポート
│   │   ├── xgboost_ga.py  # XGBoost GA最適化
│   │   ├── lightgbm_ga.py # LightGBM GA最適化
│   │   ├── feature_eng.py # 自動特徴量エンジニアリング
│   │   └── ensemble.py    # アンサンブル最適化
│   ├── dashboard/         # Webダッシュボード
│   │   ├── backend/       # FastAPI backend
│   │   └── frontend/      # React frontend
│   └── kaggle/            # Kaggle API統合
├── .claude/
│   ├── agents/            # カスタムClaude Codeエージェント
│   └── commands/          # /compete, /optimize, /submit, /analyze
└── docs/                  # ドキュメント
```

## 🔬 GEPAの仕組み

GEPA = **遺伝的**進化 + **パレート**最適化 + **AI**反省

1. **遺伝的進化**
   - プロンプトの集団（生物のように）
   - 交叉（最良の部分を組み合わせ）
   - 変異（ランダムな改善）

2. **パレート最適化**
   - 精度、速度、コストのバランス
   - 最適なトレードオフを発見
   - 複数の「最良」解

3. **AI反省**
   - LLMがエラーを分析
   - 的を絞った改善を提案
   - 方向性のある進化（ランダムではない！）

**結果:** 30分で96%精度（手動チューニングの数週間 vs）

## 📊 ベンチマーク

### 医療テキスト抽出

| 指標 | ベースライン | GEPA (10世代) | 改善 |
|--------|----------|---------------|-------------|
| 温度精度 | 72% | 96% | +33% |
| 症状F1 | 68% | 94% | +38% |
| 総合F1 | 70% | 91% | +30% |
| 時間 | - | 30分 | - |

### 進化の進行

```
世代 0:   F1=0.72 ████░░░░░░
世代 3:   F1=0.79 ██████░░░░
世代 5:   F1=0.87 ████████░░
世代 10:  F1=0.91 █████████░
```

## 🛠️ 開発

```bash
# リポジトリをクローン
git clone https://github.com/StarBoze/kagglerboze.git
cd kagglerboze

# 開発依存関係をインストール
pip install -e ".[dev]"

# テストを実行
pytest tests/ --cov=src/kaggler

# コードをフォーマット
black src/
```

## 🤝 コントリビューション

貢献を歓迎します！重点分野：

- **新しいドメイン**: 金融、NLP、ビジョン、時系列
- **最適化**: 分散進化、キャッシング
- **機能**: Web UI、MLflow統合、事前学習済みプロンプト
- **ドキュメント**: チュートリアル、例、翻訳

ガイドラインは[CONTRIBUTING.md](CONTRIBUTING.md)を参照してください。

## 📄 ライセンス

MITライセンス - [LICENSE](LICENSE)参照

## 🙏 謝辞

- **GEPA論文**: [arXiv:2507.19457](https://arxiv.org/abs/2507.19457)
- **Kaggleコミュニティ**: ベストプラクティスとインスピレーション
- **Miyabiフレームワーク**: 自律開発ワークフロー
- **Claude Code**: シームレスなAI統合

## 📧 連絡先

- **Issues**: [GitHub Issues](https://github.com/StarBoze/kagglerboze/issues)
- **Discussions**: [GitHub Discussions](https://github.com/StarBoze/kagglerboze/discussions)
- **X (Twitter)**: [@star_boze_dev](https://twitter.com/star_boze_dev)

## 🎯 ロードマップ

### フェーズ1: コアドメイン ✅（完了）
- [x] GEPAコアエンジン
- [x] 医療ドメイン（96%+精度）
- [x] 金融ドメイン（92%+精度）
- [x] Claude Code統合
- [x] Kaggle APIラッパー

### フェーズ2: 拡張 ✅（完了 - 2024年10月）
- [x] 法務ドメイン（契約書分析） - 92%+精度
- [x] 製造ドメイン（品質検査） - 94%+精度
- [x] テーブルコンペティション（XGBoost/LightGBM GA最適化）
- [x] Webダッシュボード（FastAPI + React + WebSocket）
- [ ] 事前学習済みプロンプトライブラリ（次回実装予定）

### フェーズ3: コミュニティ ✅（完了 - 2024年10月）
- [x] プロンプトマーケットプレイス（OAuth2認証、評価・レビューシステム）
- [x] 協調進化（Celery + Redis、5つのマージ戦略、2-7倍高速化）
- [x] AutoML統合（Auto-sklearn、TPOT、H2O、自動ルーティング）
- [x] 研究パートナーシップ（データセットハブ、ベンチマーク、GDPR/HIPAA準拠）

---

⭐ **KagglerBozeがリーダーボード上昇に役立ったら、GitHubでスターをお願いします！**

🚀 **始める**: `pip install kagglerboze`

## 💡 使用例

### 医療コンペティションでの使用

```python
from kaggler.domains.medical import MedicalExtractor, MedicalTemplates, MedicalMetrics

# 1. 最適化済みテンプレートを取得
template = MedicalTemplates.get_template("temperature")
print(f"進化履歴: {MedicalTemplates.get_evolved_history('temperature')}")
# 出力: 世代0: 72% → 世代10: 96%

# 2. データを抽出
extractor = MedicalExtractor()
clinical_notes = [
    "患者は37.8°Cの発熱があり、咳と頭痛を訴えている。アスピリン100mgを1日3回処方。",
    "症状なし。体温36.5°C。",
    "高熱39.2°C、悪寒、筋肉痛あり。"
]

results = []
for note in clinical_notes:
    result = extractor.extract_all(note)
    results.append(result)

# 3. 評価
predictions = [r["temperature"]["classification"] for r in results]
ground_truth = ["fever", "normal", "high-fever"]

metrics = MedicalMetrics.evaluate_all(
    [{"temperature": p} for p in predictions],
    [{"temperature": g} for g in ground_truth]
)
print(f"温度精度: {metrics['temperature_accuracy']:.2%}")
```

### GEPAを使ったカスタムドメイン最適化

```python
from kaggler.core import EvolutionEngine, EvolutionConfig, Individual

# カスタム評価関数を定義
def evaluate_finance_prompt(prompt: str) -> dict:
    """金融ドメインのプロンプト評価"""
    # あなたの検証データでテスト
    predictions = your_model.predict(validation_data, prompt=prompt)

    accuracy = calculate_accuracy(predictions, ground_truth)
    speed = measure_latency(your_model, prompt)
    cost = estimate_token_cost(prompt)

    return {
        "accuracy": accuracy,
        "speed": 1.0 / speed,  # 高速ほど良い
        "cost": 1.0 / cost     # 低コストほど良い
    }

# GEPA設定
config = EvolutionConfig(
    population_size=20,
    generations=15,
    mutation_rate=0.3,
    crossover_rate=0.5,
    objectives=["accuracy", "speed", "cost"]
)

# 初期プロンプト（シード）
seed_prompts = [
    "株価データから技術指標を抽出",
    "金融ニュースからセンチメントを分析",
    "取引データから異常を検出"
]

# 進化実行
engine = EvolutionEngine(config)
best = engine.evolve(
    seed_prompts=seed_prompts,
    eval_func=evaluate_finance_prompt,
    generations=15
)

print(f"最良プロンプト:\n{best.prompt}")
print(f"\nスコア:")
print(f"  精度: {best.fitness_scores['accuracy']:.3f}")
print(f"  速度: {best.fitness_scores['speed']:.3f}")
print(f"  コスト: {best.fitness_scores['cost']:.3f}")

# パレートフロンティアを取得
pareto_front = engine.get_pareto_front()
print(f"\nパレート最適解: {len(pareto_front)}個発見")

# トレードオフを選択
from kaggler.core import ParetoOptimizer
optimizer = ParetoOptimizer(config.objectives)
best_tradeoff = optimizer.select_best_tradeoff(
    pareto_front,
    weights={"accuracy": 0.6, "speed": 0.3, "cost": 0.1}
)
print(f"推奨プロンプト（60% 精度、30% 速度、10% コスト）:")
print(best_tradeoff.prompt)
```

### Kaggle APIとの完全統合

```python
from kaggler.kaggle import KaggleClient

# 初期化
client = KaggleClient()

# コンペティション一覧を取得
competitions = client.list_competitions(search="medical")
for comp in competitions[:5]:
    print(f"{comp['title']}: {comp['deadline']}")

# データをダウンロード
data_path = client.download_competition("medical-text-extraction")
print(f"データ保存先: {data_path}")

# 自分のランクを確認
rank_info = client.get_my_rank("medical-text-extraction")
if rank_info:
    print(f"現在のスコア: {rank_info['score']}")
    print(f"提出日時: {rank_info['date']}")

# 提出
submission_result = client.submit(
    competition="medical-text-extraction",
    file_path="submission.csv",
    message="GEPA最適化 v2 - 96%精度達成"
)
print(f"提出成功: {submission_result['success']}")

# リーダーボード比較
from kaggler.kaggle import LeaderboardTracker
tracker = LeaderboardTracker(client.api)

comparison = tracker.compare_with_baseline(
    competition="medical-text-extraction",
    my_score=0.91
)
print(f"\nあなたのランク: #{comparison['rank']} / {comparison['total_teams']}")
print(f"パーセンタイル: 上位{100-comparison['percentile']:.1f}%")
print(f"トップスコア: {comparison['top_score']:.3f}")
print(f"必要な改善: {comparison['improvement_needed']:.3f}")

# シェイクアップ予測
shake_prediction = tracker.predict_shake_up(
    competition="medical-text-extraction",
    cv_score=0.92,
    public_score=0.91
)
print(f"\nシェイクアップ予測: {shake_prediction['prediction']}")
print(f"信頼度: {shake_prediction['confidence']}")
print(f"メッセージ: {shake_prediction['message']}")
```

## 🎓 詳細ガイド

### カスタム変異戦略の実装

GEPAの変異をカスタマイズできます：

```python
from kaggler.core.mutation import MutationStrategy, MutationType

class DomainSpecificMutation(MutationStrategy):
    """ドメイン固有の変異戦略"""

    def mutate(self, prompt: str, context=None):
        # ドメイン知識を使った変異
        if "金融" in prompt:
            return self.add_financial_rules(prompt)
        elif "医療" in prompt:
            return self.add_medical_constraints(prompt)
        else:
            return super().mutate(prompt, context)

    def add_financial_rules(self, prompt: str):
        """金融固有のルールを追加"""
        rules = """

## 金融データ処理ルール
- 通貨記号を削除（$, ¥, €など）
- パーセンテージは小数で表現（5% → 0.05）
- 日付はISO 8601形式（YYYY-MM-DD）
        """
        return prompt + rules

    def add_medical_constraints(self, prompt: str):
        """医療固有の制約を追加"""
        constraints = """

## 医療データ検証
- バイタルサイン範囲チェック
- 薬剤相互作用の警告
- 単位の標準化（mg, mL, etc）
        """
        return prompt + constraints

# 使用例
custom_strategy = DomainSpecificMutation()
evolved_prompt = custom_strategy.mutate("患者データを抽出")
```

## 🌍 コミュニティとサポート

### 参加方法

1. **Discord サーバー**: リアルタイムでの議論
2. **GitHub Discussions**: 質問と回答
3. **Kaggle Notebooks**: 共有可能な実装例
4. **Twitter**: 最新情報とヒント

### 貢献ガイドライン

新しいドメインの追加方法：

```python
# 1. ドメインディレクトリを作成
src/kaggler/domains/finance/
├── __init__.py
├── templates.py      # 初期プロンプト
├── extractors.py     # 抽出ロジック
├── metrics.py        # ドメインメトリクス
└── validators.py     # 検証ルール

# 2. テンプレートを実装
class FinanceTemplates:
    STOCK_ANALYSIS = """
    株価データから技術指標を抽出...
    """

    SENTIMENT_ANALYSIS = """
    ニュースからセンチメントを分析...
    """

# 3. テストを追加
tests/domains/finance/
└── test_finance_extractors.py

# 4. ドキュメントを更新
docs/domains/FINANCE.md
```

---

**質問やフィードバックがありましたら、お気軽にIssueを立てるか、Discussionsで議論してください！**
