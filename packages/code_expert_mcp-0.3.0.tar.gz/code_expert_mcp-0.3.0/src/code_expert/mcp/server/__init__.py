"""MCP server module initialization."""

from code_expert.mcp.server.app import server, create_mcp_server

__all__ = ["server", "create_mcp_server"]
