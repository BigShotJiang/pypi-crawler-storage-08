def test_import():
    import picoanim  # noqa: F401
