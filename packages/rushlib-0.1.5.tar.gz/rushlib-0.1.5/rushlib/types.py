from pathlib import Path
from typing import Union

path_type = Union[str, Path]
