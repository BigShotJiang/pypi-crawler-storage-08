from orso.logging import get_logger
from orso.logging import set_log_name

__all__ = ("get_logger", "set_log_name")
