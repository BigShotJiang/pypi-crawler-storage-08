project = "cbor-diag"
author = "Christian Amsüss"
copyright = "see project web page"

extensions = [
    "sphinx.ext.autodoc",
]
