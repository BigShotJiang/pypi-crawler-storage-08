=======================================
cbor-diag: Diagnostic notation for CBOR
=======================================

See the project README_ file for installation, maintenance and license information.

.. _README: https://github.com/chrysn/cbor-diag-py/blob/main/README.rst

.. automodule:: cbor_diag
   :members:
