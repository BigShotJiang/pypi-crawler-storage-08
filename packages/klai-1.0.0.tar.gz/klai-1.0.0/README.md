# klai - A Local-First AI Terminal Companion

This is a command-line AI assistant that runs entirely on your local machine.
