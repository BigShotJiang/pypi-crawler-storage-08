from .doode import Dood

def usage():
	Dood().main()

if __name__ == '__main__':
	usage()
