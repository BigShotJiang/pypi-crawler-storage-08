#!/usr/bin/env python3
# file: dood/__init__.py
# Author: Hadi Cahyadi <cumulus13@gmail.com>
# Date: 2025-10-09 12:06:19.500811
# Description: 
# License: MIT

from .doode import Dood