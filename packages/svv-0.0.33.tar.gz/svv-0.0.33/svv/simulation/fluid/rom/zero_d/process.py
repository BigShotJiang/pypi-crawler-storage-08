run_0d_script="""import os
import sys
sys.path.append('{}')
import svzerodsolver
svzerodsolver.solver.set_up_and_run_0d_simulation('{}')
"""

run_0d_cmdline="{} solver_0d.in"