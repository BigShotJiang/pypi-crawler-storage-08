from .survey import standardize as standardize
