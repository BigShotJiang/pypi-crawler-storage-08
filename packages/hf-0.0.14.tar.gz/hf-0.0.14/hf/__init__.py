"""Huggingface interface"""

from hf.base import datasets, models, spaces, papers, HfMapping, get_size
