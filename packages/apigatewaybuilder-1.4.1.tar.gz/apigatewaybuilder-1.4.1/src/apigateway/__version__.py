"""Version information for apigateway package."""
__version__ = "1.3.1"
__version_info__ = tuple(int(i) for i in __version__.split('.'))