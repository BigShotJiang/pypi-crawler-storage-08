from .main import MmkUpdaterQt
