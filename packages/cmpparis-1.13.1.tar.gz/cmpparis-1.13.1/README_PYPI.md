# cmpparis

`cmpparis` est une petite bibliothèque Python pour CMP afin de ne pas réecrire les différentes fonctions et de gagner du temps.

## Installation

```bash
pip install cmpparis
```