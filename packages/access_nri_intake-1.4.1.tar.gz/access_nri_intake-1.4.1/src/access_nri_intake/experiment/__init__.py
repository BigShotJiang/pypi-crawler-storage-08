from .main import use_datastore

__all__ = ["use_datastore"]
