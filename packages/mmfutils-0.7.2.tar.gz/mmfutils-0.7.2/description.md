Small set of utilities: containers and interfaces.

This package provides some utilities that I tend to rely on during development. Since I
use these in many different projects, I turned this into a repository so that I can
easily sync and keep track of updates. Once the intreface and contents become stable, it
will probably make sense to include these directly along with the original project so
that an additional dependency is not introduced.
