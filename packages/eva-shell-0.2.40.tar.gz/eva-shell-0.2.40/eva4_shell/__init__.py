__version__ = '0.2.40'

DEFAULT_REPOSITORY_URL = 'https://pub.bma.ai/eva4'
