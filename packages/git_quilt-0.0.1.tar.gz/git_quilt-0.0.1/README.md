# git-quilt

##  ⚠️ 🪏 Work In Progress 🪏 ⚠️ 

This is currently a work in progress and doesn't do much yet.

There is a tool called git-swap which can re-order commits with less manual
conflict resolution than `git rebase -i`

## Description

This is my second attempt to make a git-based patch queue tool.

It's similar to `git-pq`, `quilt`, `stgit`, and others.
