__version__ = "0.2.12rc7"
__VERSION__ = __version__
