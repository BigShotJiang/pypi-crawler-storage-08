Crown Court records are more likely held in local archives rather than at The National Archives.
