The Primary Health List deals with appeals and applications arising from decisions made by Primary Care Trusts and NHS England in England and Health Boards in Wales as part of the local management of lists of medical practitioners, dental practitioners, ophthalmic practitioners and some pharmacists who are able to provide NHS service.

The appeals include appeals against decisions to refuse to include any practitioner on the performers list, imposition of any conditions and removal of any practitioner from the performers list.

You can read more about the tribunal on its website [Primary Health Lists - Courts and Tribunals Judiciary](https://www.judiciary.uk/courts-and-tribunals/tribunals/first-tier-tribunal/health-education-and-social-care-chamber/special-educational-needs-and-disability-care-standards-and-primary-health-lists-send/primary-health-lists/).
