The Mercantile Court is now known as The Circuit Commercial Court and is closely associated with the Commercial Court. [You can find cases decided by the Mercantile Court here](https://caselaw.nationalarchives.gov.uk/judgments/search?query=&from_day=&from_month=&from_year=&to_day=&to_month=&to_year=&court=ewhc%2Fmercantile&party=&judge=){target="\_blank"}.

This court does not transfer judgments to The National Archives. The judgments from this court included in Find Case Law are from 2008 to 2014.

You can read more about it on [the Commercial Court on the Judiciary website](https://www.judiciary.uk/courts-and-tribunals/business-and-property-courts/commercial-court/){target="\_blank"}.
