The King’s Bench Division is one of three Divisions of the High Court. It handles a wide range of civil claims across contract disputes and civil wrongs (tort) including claims of: negligence, defamation, assault, trespass. This Division contains specialist courts including Administrative, Admiralty, Commercial, and Technology and Construction Courts.

This court began to regularly transfer judgments to The National Archives in 2022. The oldest judgment from this court included in Find Case Law is from {start_year}.

You can read more about it on [the King’s Bench Division on the judiciary website](https://www.judiciary.uk/courts-and-tribunals/kings-bench-division/){target="\_blank"}.
