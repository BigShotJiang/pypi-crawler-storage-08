The Find Case Law service publishes decisions from two first-tier tribunals. These are the General Regulatory Chamber and the Tax Chamber.

You can read more about first-tier tribunals on the [HM Courts and Tribunals website](https://www.gov.uk/government/organisations/hm-courts-and-tribunals-service/about){target="\_blank"}.
