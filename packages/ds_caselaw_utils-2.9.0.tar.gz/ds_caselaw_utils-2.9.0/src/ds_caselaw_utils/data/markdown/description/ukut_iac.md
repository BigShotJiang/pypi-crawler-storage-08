The Immigration and Asylum Chamber is responsible for handling appeals against some decisions made by the Home Office relating to permission to stay in the UK, deportation from the UK, and entry clearance to the UK.

They also handle applications for immigration bail from people being held by the Home Office on immigration matters.

This tribunal began to regularly transfer decisions to The National Archives in 2022. The oldest decision from this court included in Find Case Law is from {start_year}.

You can read more about it on the Immigration and Asylum Chamber on the [HM Courts and Tribunals Service website](https://www.gov.uk/courts-tribunals/upper-tribunal-immigration-and-asylum-chamber){target="\_blank"}.
