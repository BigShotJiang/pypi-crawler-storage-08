The Court of Appeal Civil Division is the second most senior court for non-criminal cases in England and Wales.

This court began to regularly transfer judgments to The National Archives in 2022. The oldest judgment from this court included in Find Case Law is from {start_year}.

You can read more about it on the [Court of Appeal Civil Division page](https://www.gov.uk/courts-tribunals/court-of-appeal-civil-division){target="\_blank"} on the [HM Courts and Tribunals Service website](https://www.gov.uk/government/organisations/hm-courts-and-tribunals-service/about){target="\_blank"}.
