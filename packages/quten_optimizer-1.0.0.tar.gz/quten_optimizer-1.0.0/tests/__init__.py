"""QUTEN optimizer tests."""
