from __future__ import annotations

import os


StrPath = str | os.PathLike[str]
