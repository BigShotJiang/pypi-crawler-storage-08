[![Python Tests](https://github.com/renderbox/django-site-configs/actions/workflows/python-test.yml/badge.svg)](https://github.com/renderbox/django-site-configs/actions/workflows/python-test.yml)

[![Publish Python 🐍 distribution 📦 to PyPI](https://github.com/renderbox/django-site-configs/actions/workflows/python-publish.yml/badge.svg)](https://github.com/renderbox/django-site-configs/actions/workflows/python-publish.yml)

# Site Configs

A Django app that manages configurations per-site on a multi-site setup. These settings can be made avaialble to users of different sites or administerd via the Django admin.
