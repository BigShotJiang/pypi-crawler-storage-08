from django.apps import AppConfig


class SiteConfigsConfig(AppConfig):
    name = "siteconfigs"
