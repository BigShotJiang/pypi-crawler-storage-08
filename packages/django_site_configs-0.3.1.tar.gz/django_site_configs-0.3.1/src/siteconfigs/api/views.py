# from rest_framework import generics

# from siteconfigs.models import SampleModel
# from siteconfigs.api.serializers import SampleModelSerializer


# class SampleModelListAPIView(generics.ListAPIView):
#     queryset = SampleModel.objects.filter(enabled=True)
#     serializer_class = SampleModelSerializer
