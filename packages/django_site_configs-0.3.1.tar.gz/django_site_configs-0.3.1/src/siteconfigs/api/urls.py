# from django.urls import path

# from siteconfigs.api import views

# urlpatterns = [
#     # path('samplemodel/list/', views.SampleModelListAPIView.as_view(), name='sample-model-list'),
# ]
