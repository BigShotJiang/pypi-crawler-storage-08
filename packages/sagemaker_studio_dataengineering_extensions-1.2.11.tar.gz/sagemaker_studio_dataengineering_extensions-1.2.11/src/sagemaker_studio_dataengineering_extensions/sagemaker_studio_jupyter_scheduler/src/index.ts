import { ScheduleNotebookPlugin, SchedulerTelemetryPlugin } from './plugins';

export default [ScheduleNotebookPlugin, SchedulerTelemetryPlugin];
