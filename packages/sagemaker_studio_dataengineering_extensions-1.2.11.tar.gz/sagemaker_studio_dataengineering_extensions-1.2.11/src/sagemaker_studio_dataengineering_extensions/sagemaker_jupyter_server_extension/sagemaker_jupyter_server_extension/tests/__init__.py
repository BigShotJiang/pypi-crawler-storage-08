"""Python unit tests for sagemaker_jupyter_server_extension."""
