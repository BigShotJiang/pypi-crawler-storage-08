class Stop(Exception):
    pass
