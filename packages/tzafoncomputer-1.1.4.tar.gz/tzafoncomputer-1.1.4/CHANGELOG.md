# Changelog

## 1.1.4 (2025-10-08)

Full Changelog: [v1.1.3...v1.1.4](https://github.com/atulgavandetzafon/computer-python/compare/v1.1.3...v1.1.4)

## 1.1.3 (2025-10-08)

Full Changelog: [v1.1.2...v1.1.3](https://github.com/atulgavandetzafon/computer-python/compare/v1.1.2...v1.1.3)

## 1.1.2 (2025-10-08)

Full Changelog: [v1.1.1...v1.1.2](https://github.com/atulgavandetzafon/computer-python/compare/v1.1.1...v1.1.2)

## 1.1.1 (2025-10-08)

Full Changelog: [v1.1.0...v1.1.1](https://github.com/atulgavandetzafon/computer-python/compare/v1.1.0...v1.1.1)

## 1.1.0 (2025-10-07)

Full Changelog: [v1.0.1...v1.1.0](https://github.com/atulgavandetzafon/computer-python/compare/v1.0.1...v1.1.0)

### Features

* **api:** manual updates ([aaf8e53](https://github.com/atulgavandetzafon/computer-python/commit/aaf8e534415ea6bc8420f2ed8e3b854011a7bf71))
* **api:** manual updates ([833115e](https://github.com/atulgavandetzafon/computer-python/commit/833115e5e6814f6347de3e0521faceb4bf9e15e8))


### Chores

* update SDK settings ([0b62c4b](https://github.com/atulgavandetzafon/computer-python/commit/0b62c4b04323dabf192fe31e11f45ea94f366411))

## 1.0.1 (2025-10-07)

Full Changelog: [v0.0.1...v1.0.1](https://github.com/atulgavandetzafon/computer-python/compare/v0.0.1...v1.0.1)

### Features

* **api:** added python ([7bc6a73](https://github.com/atulgavandetzafon/computer-python/commit/7bc6a73f549bb57bb176de454d395fd692159a0e))
* **api:** manual updates ([57e4841](https://github.com/atulgavandetzafon/computer-python/commit/57e4841180a11f953e1d8db5e3c1ea7eebbb1d3e))
* **api:** manual updates ([a23814e](https://github.com/atulgavandetzafon/computer-python/commit/a23814e85afaa64e2a429b2bcb6507b0accb46bc))
* **api:** Updated to bearer auth ([c95903e](https://github.com/atulgavandetzafon/computer-python/commit/c95903e3795de2823b6266f914647dd55dc4eeba))
* **api:** v2 api ([db7fdb5](https://github.com/atulgavandetzafon/computer-python/commit/db7fdb5cbcb3ed5f38c2fcebe824573172c223d1))
* async ([38d796c](https://github.com/atulgavandetzafon/computer-python/commit/38d796c6538fad278abf122887a57a379c5a532b))
* lets test functionality ([3d5f515](https://github.com/atulgavandetzafon/computer-python/commit/3d5f515098e71964a431849a37c88a7a017424d2))
* wrapper test1 ([e329ec1](https://github.com/atulgavandetzafon/computer-python/commit/e329ec12ae711d64cad28e04a74bd7c1283669ce))


### Bug Fixes

* removed old async ([1b5c5cd](https://github.com/atulgavandetzafon/computer-python/commit/1b5c5cdf4a7c80089e8ca67e13540bdae898ac98))


### Chores

* update SDK settings ([a5da45a](https://github.com/atulgavandetzafon/computer-python/commit/a5da45a676c091d3d02fde9352d98d458e4dfe7f))
* update SDK settings ([3e68f6d](https://github.com/atulgavandetzafon/computer-python/commit/3e68f6db27fae3f75f411d76e15a6df07d22fa2b))
