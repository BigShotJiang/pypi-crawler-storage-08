import typing as t

ProjectURI: t.TypeAlias = str
