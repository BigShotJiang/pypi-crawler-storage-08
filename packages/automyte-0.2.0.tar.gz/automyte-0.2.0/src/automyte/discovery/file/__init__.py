from .base import File
from .os_file import OSFile

__all__ = [
    "File",
    "OSFile",
]
