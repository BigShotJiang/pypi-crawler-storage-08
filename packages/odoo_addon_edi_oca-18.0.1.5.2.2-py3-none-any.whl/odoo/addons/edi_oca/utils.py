# ruff: noqa: F401

from odoo.addons.edi_core_oca.utils import get_checksum, normalize_string
from odoo.addons.edi_queue_oca.utils import exchange_record_job_identity_exact
