Minimal module used only to avoid issues on the migration to the new splitted model of edi_oca.

Might be removed on 19 but we keep it as part of the transition after the split between EDI and components.
