# Auth Tool

Produce authentication headers for API calls (API key, JWT).
