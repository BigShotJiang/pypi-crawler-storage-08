"""Logging factory functions."""

from .factory import configure_logging

__all__ = ["configure_logging"]
