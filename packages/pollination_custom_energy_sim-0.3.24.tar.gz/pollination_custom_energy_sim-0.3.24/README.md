# custom-energy-sim

Run an energy simulation with full control over other parameters.

This type of simulation is useful when the result files will undergo
custom postprocessing with a Grasshopper script or App.
