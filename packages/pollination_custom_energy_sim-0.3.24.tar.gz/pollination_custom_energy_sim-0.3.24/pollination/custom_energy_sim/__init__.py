from .entry import CustomEnergySimEntryPoint


__pollination__ = {
    'entry_point': CustomEnergySimEntryPoint,
    'app_version': '3.1.0',  # tag for version of Openstudio
}
