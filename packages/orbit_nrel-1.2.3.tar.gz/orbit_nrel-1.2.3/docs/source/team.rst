.. _team:

ORBIT Team
==========

Authors
-------
- Jake Nunemaker (NREL)
- Matt Shields (NREL)
- Rob Hammond (NREL)
- Patrick Duffy (NREL)
- Nick Riccobono (NREL)
- Daniel Mulas Hernando (NREL)

Maintainer
-----------
- Nick Riccobono (NREL)


.. Contributors
.. ------------

.. Coming soon!

.. Reviewers
.. ---------

.. Coming soon!
