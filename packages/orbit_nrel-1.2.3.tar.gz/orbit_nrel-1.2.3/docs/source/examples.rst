.. _examples:

Examples
========

There are several example interactive notebooks located in the ORBIT
`repository <https://github.com/WISDEM/ORBIT/tree/master/examples>`_

For information on running jupyter notebooks, please see this
`tutorial <https://www.dataquest.io/blog/jupyter-notebook-tutorial/>`_.
