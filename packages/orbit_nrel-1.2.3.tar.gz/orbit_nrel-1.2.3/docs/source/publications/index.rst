.. _publications:

Publications
============

- `"ORBIT: Offshore Renewables Balance-of-System and Installation Tool" <https://www.nrel.gov/docs/fy20osti/77081.pdf>`_
- `"Process-Based Balance-of-System Cost Modeling for Offshore Wind Power Plants in the United States" <https://www.nrel.gov/docs/fy20osti/74933.pdf>`_
- `"Impacts of Turbine and Plant Upsizing on the Levelized Cost of Energy for Offshore Wind" <https://www.sciencedirect.com/science/article/pii/S0306261921006164>`_
