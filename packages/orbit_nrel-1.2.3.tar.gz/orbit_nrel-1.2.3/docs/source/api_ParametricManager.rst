.. _manager:

Parametric Configurations - ``ORBIT.ParametricManager``
=======================================================

.. autoclass:: ORBIT.ParametricManager
   :members:
