Scour Protection Installation API
=================================

For detailed methodology, please see
:doc:`Scour Protection Installation Methodology <doc_ScourProtectionInstall>`.

.. autoclass:: ORBIT.phases.install.ScourProtectionInstallation
   :members:
