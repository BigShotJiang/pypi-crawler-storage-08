Offshore Substation Installation API
====================================

For detailed methodology, please see
:doc:`Offshore Substation Installation Methodology <doc_OffshoreSubstationInstall>`.

.. autoclass:: ORBIT.phases.install.OffshoreSubstationInstallation
   :members:
