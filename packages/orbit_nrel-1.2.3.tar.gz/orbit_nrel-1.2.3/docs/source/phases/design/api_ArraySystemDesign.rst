Array System Design API
=======================

For detailed methodology, please see
:doc:`Array System Design <doc_ArraySystemDesign>`.

.. autoclass:: ORBIT.phases.design.ArraySystemDesign
   :members:
