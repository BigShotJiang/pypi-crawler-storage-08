Offshore Substation Design API
==============================

For detailed methodology, please see
:doc:`Offshore Substation Design <doc_OffshoreSubstationDesign>`.

.. autoclass:: ORBIT.phases.design.OffshoreSubstationDesign
   :members:
