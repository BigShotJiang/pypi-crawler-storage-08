Spar Design API
===============

For detailed methodology, please see
:doc:`Spar Design <doc_SparDesign>`.

.. autoclass:: ORBIT.phases.design.SparDesign
   :members:
