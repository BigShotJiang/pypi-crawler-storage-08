Monopile Design API
===================

For detailed methodology, please see :doc:`Monopile Design <doc_MonopileDesign>`.

.. autoclass:: ORBIT.phases.design.MonopileDesign
   :members:
