.. _managertoc:

Parametric Manager
=============

The following pages cover the methodology behind the parametric manager. For
more details of the code implementation, please see :doc:`Parametric Manager API <api_ParametricManager>`.

.. note::

    Page currently under construction.
