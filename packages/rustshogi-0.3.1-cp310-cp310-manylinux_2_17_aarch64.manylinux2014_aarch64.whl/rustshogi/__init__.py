from .rustshogi import *

__doc__ = rustshogi.__doc__
if hasattr(rustshogi, "__all__"):
    __all__ = rustshogi.__all__