.. Copyright (C) 2016 Robin Schneider <ypid@riseup.net>
.. Copyright (C) 2016 DebOps <https://debops.org/>
.. SPDX-License-Identifier: GPL-3.0-only

.. _debops-contrib.btrfs:

Ansible role: debops-contrib.btrfs
==================================

.. toctree::
   :maxdepth: 2

   introduction
   getting-started
   defaults
   copyright
   changelog

..
 Local Variables:
 mode: rst
 ispell-local-dictionary: "american"
 End:
