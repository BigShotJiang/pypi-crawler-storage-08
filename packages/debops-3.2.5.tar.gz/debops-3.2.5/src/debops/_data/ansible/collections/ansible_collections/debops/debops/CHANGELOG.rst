DebOps Collection Changelog
===========================

Copyright (C) 2023 Maciej Delmanowski <drybjed@gmail.com>
Copyright (C) 2023 DebOps <https://debops.org/>
SPDX-License-Identifier: GPL-3.0-or-later

This is a "stub" changelog meant for the "ansible-lint" tool which complains if
a changelog file is not found in an Ansible Collection. The real changelog is
located in the root of the DebOps repository.
