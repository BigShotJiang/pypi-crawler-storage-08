.. Copyright (C) 2016 Robin Schneider <ypid@riseup.net>
.. Copyright (C) 2016 DebOps <https://debops.org/>
.. SPDX-License-Identifier: GPL-3.0-only

.. include:: includes/global.rst
