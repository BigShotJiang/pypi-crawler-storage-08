.. Copyright (C) 2017 Robin Schneider <ypid@riseup.net>
.. Copyright (C) 2017 DebOps <https://debops.org/>
.. SPDX-License-Identifier: GPL-3.0-only

.. include:: includes/global.rst
.. include:: includes/role.rst
