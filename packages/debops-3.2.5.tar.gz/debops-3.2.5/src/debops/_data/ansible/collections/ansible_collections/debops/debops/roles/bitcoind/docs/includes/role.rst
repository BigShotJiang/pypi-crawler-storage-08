.. Copyright (C) 2017 Robin Schneider <ypid@riseup.net>
.. Copyright (C) 2017 DebOps <https://debops.org/>
.. SPDX-License-Identifier: GPL-3.0-only

.. _Bitcoin: https://bitcoin.org
.. _bitcoind: https://en.bitcoin.it/wiki/Bitcoind
.. _full node: https://en.bitcoin.it/wiki/Full_node
.. _Running A Full Node: https://bitcoin.org/en/full-node
