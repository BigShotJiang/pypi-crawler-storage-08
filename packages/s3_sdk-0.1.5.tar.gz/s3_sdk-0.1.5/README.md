# s3_sdk

A simple SDK for interacting with AWS S3 using boto3. Supports file upload, download, existence check, and presigned URL generation.

## Installation

```bash
pip install s3_sdk
