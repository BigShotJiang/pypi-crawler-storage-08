class AuthorizationFailedException(Exception):
    pass
