# Positive tests - expect specific findings
