#!/bin/bash


# ruleid: npm-install-public
npm install internal-package-42 --registry=https://registry.npmjs.org/
