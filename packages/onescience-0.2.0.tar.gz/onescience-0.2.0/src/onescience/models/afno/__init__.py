from .afnonet import AFNONet, PrecipNet
from .distributed import DistributedAFNO

