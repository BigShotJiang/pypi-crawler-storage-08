
from __future__ import annotations

from onescience.models.UMA.units.mlip_unit.api.inference import (
    InferenceSettings,
)

__all__ = ["InferenceSettings"]
