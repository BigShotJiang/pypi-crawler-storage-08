

from __future__ import annotations

from .scale_factor import ScaleFactor

__all__ = ["ScaleFactor"]
