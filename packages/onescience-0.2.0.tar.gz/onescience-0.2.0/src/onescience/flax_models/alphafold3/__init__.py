

"""An implementation of the inference pipeline of AlphaFold 3."""
