# =====================================
# generator=datazen
# version=3.2.3
# hash=940874292201d38dfaaf344ff5181488
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "An interface generator for distributed computing."
PKG_NAME = "ifgen"
VERSION = "4.6.1"
