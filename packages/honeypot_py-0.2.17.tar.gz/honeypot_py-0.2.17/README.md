Official Python client for Honeypot.

## Installation

```sh
pip install honeypot-py
```