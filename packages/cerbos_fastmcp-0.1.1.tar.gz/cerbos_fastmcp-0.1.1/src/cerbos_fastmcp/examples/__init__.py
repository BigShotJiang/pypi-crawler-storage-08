"""Example utilities and demo servers for cerbos-fastmcp."""

from .server import create_example_server, main

__all__ = ["create_example_server", "main"]
