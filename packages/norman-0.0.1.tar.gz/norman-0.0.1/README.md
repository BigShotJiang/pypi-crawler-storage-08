# norman

**Status: Under Development**

This is a placeholder package for Norman AI. The package is currently under active development.

## Coming Soon

Norman will provide tools and utilities for interacting with Norman AI services.

Stay tuned for updates!

## License

Copyright © Norman Artificial Intelligence LTD. Licensed under the Apache License 2.0.