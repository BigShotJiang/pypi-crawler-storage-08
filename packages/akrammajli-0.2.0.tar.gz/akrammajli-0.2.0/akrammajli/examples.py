def show_example():
    print('هذا مثال جاهز للاستخدام')
