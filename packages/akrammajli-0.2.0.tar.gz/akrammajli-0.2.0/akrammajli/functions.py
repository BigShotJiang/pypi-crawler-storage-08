def example_function():
    print('هذه دالة مثال')
