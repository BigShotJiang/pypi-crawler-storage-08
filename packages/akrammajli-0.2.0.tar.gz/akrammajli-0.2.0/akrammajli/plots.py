import matplotlib.pyplot as plt

def plot_example():
    plt.plot([1,2,3],[4,5,6])
    plt.title('مثال رسم بياني')
    plt.show()
