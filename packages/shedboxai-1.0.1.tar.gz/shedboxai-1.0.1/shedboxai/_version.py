"""Version information for ShedBoxAI."""

__version__ = "1.0.1"
