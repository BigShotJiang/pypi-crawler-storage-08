#ifndef INCLUDE_AND_SETTING_H
#define INCLUDE_AND_SETTING_H

#ifndef OCTOMAP_DEPRECATED
#define insertScan insertPointCloud
#endif
#include <octomap/OccupancyOcTreeBase.h>
#include <octomap/OcTree.h>

#endif
