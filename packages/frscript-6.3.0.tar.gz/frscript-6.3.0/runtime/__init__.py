"""
FrScript C Runtime VM

This package contains the C-based virtual machine runtime for FrScript.
"""
