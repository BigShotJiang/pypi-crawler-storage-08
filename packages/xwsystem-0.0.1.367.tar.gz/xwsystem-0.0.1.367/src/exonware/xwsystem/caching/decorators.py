"""
Company: eXonware.com
Author: Eng. Muhammad AlShehri
Email: connect@exonware.com
Version: 0.0.1.367
Generation Date: September 04, 2025

Cache decorators - Placeholder.
"""

def cache(func):
    return func

def async_cache(func):
    return func
    
def cache_result(func):
    return func
    
def async_cache_result(func):
    return func
