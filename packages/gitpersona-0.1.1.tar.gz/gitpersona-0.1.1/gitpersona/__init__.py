"""GitPersona package

Lightweight toolkit to analyze GitHub profiles locally.
"""

__version__ = "0.1.1"

# Keep the package surface minimal. Import CLI at runtime via:
#     from gitpersona import cli
# or use the installed `gitpersona` console script.
