# SPDX-License-Identifier: MPL-2.0
# Copyright (c) 2025 Daniel Schmidt

import nac_test.cli.main

if __name__ == "__main__":
    nac_test.cli.main.app()
