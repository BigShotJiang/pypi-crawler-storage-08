"""Exposes version constant to avoid circular dependencies."""

VERSION = "3.20.0"
