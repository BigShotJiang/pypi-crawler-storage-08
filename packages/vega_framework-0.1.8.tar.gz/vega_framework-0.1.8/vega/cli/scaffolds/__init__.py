"""Scaffolding helpers for Vega CLI."""

from .fastapi import create_fastapi_scaffold

__all__ = [
    "create_fastapi_scaffold",
]
