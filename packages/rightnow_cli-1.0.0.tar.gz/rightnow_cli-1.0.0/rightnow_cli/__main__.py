"""Main entry point for python -m rightnow_cli."""

from . import main

if __name__ == "__main__":
    main()