__version__ = "1.0.0"

from .cli_minimal import main

__all__ = ["main", "__version__"]