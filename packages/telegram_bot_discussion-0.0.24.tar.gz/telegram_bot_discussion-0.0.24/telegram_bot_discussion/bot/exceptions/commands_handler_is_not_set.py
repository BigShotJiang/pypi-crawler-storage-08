class CommandsHandlerIsNotSet(Exception):
    def __str__(self):
        return "Commands-handler is not set"
