from .page import PageReplica as PageReplica
