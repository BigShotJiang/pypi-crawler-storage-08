"""cmem-plugin-kafka"""
