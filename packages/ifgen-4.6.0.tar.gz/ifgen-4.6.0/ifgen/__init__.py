# =====================================
# generator=datazen
# version=3.2.3
# hash=1d9a445cd0a6b0e0126151d1aa677943
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "An interface generator for distributed computing."
PKG_NAME = "ifgen"
VERSION = "4.6.0"
