# Contributing

Welcome to aioqzone community.

## Add Test

Our tests are not fully coveraged. New unittests are needed.

No special rules for tests. Just create a pull request if you've done your work.
