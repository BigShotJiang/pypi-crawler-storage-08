"""aioqzone typing system. Aims at making full use of pydantic type-validation
and python typing support after py36."""

from .api import *
from .protocol import *
