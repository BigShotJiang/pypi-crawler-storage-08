QrLogin Types
========================

.. currentmodule:: qqqr.qr.type

.. automodule:: qqqr.qr.type
    :members:
    :undoc-members:
