QrLogin and QrSession
=========================

.. currentmodule:: qqqr.qr

.. autoclass:: QR
    :members:
    :inherited-members: LoginBase

.. autoclass:: QrSession
    :members:

.. autoclass:: QrLogin
    :members:
