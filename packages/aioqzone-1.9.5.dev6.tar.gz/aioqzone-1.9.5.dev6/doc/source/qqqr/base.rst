QQQR Bases
=================

.. currentmodule:: qqqr.base

.. automodule:: qqqr.base
    :members:
