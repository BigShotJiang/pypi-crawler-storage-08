QQQR Exceptions
=====================

.. automodule:: qqqr.exception
    :members:
    :undoc-members:
