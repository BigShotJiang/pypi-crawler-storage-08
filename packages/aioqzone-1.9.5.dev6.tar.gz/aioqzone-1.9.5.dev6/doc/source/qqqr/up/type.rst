UpLogin Types
========================

.. currentmodule:: qqqr.up._model

.. automodule:: qqqr.up._model
    :members:
    :undoc-members:
