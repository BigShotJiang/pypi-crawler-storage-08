Password Encoder
=============================

.. automodule:: qqqr.up.encrypt
    :members:
