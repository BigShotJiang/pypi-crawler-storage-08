==========================
UpLogin and UpSession
==========================

.. currentmodule:: qqqr.up

.. autoclass:: UpWebLogin
    :members:
    :inherited-members: LoginBase

.. autoclass:: UpH5Login
    :members:
