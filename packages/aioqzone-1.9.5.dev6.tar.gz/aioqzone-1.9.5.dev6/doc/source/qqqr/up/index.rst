========================
Uin-Password Login
========================

.. toctree::
    :maxdepth: 1

    login
    type

-----------------------
Encrypt and Captcha
-----------------------

.. toctree::
    :maxdepth: 1

    encrypt
    captcha/index
