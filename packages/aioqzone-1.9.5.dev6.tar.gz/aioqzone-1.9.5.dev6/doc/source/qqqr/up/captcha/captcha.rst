Captcha and TcaptchaSession
================================

.. currentmodule:: qqqr.up.captcha

.. autoclass:: Captcha
    :members:

.. autoclass:: TcaptchaSession
    :members:
