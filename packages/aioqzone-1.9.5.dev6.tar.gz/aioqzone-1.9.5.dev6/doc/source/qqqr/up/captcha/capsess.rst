Captcha Sessions
================================

.. currentmodule:: qqqr.up.captcha

.. autoclass:: qqqr.up.captcha.capsess.BaseTcaptchaSession

Slide Captcha Session
-----------------------------------
.. automodule:: qqqr.up.captcha.slide._types

Select Captcha Session
-----------------------------------
.. automodule:: qqqr.up.captcha.select._types
