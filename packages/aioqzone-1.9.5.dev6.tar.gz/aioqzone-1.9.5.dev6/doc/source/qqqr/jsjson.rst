Parsing Javascript Dictionary
==================================

.. currentmodule:: qqqr.utils.jsjson

.. automodule:: qqqr.utils.jsjson
    :members:
