Login Managers
================

.. currentmodule:: aioqzone.api.login

Loginable
----------------------

.. automodule:: aioqzone.api.login._base
    :members: Loginable

Built-in Login Managers
----------------------------------

.. automodule:: aioqzone.api.login
    :members: ConstLoginMan, UpLoginManager, QrLoginManager
