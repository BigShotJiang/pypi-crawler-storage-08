aioqzone Exceptions
=======================

.. automodule:: aioqzone.exception
    :members:
    :undoc-members:
