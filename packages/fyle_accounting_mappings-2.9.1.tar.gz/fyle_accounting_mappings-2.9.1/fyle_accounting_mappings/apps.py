from django.apps import AppConfig


class FyleAccountingMappingsConfig(AppConfig):
    name = 'fyle_accounting_mappings'
