from django.apps import AppConfig


class FyleAccountingLibraryFylePlatformConfig(AppConfig):
    name = 'fyle_accounting_library.fyle_platform'
