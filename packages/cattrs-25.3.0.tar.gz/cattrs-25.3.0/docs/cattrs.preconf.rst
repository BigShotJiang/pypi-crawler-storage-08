cattrs.preconf package
======================

.. automodule:: cattrs.preconf
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

cattrs.preconf.bson module
--------------------------

.. automodule:: cattrs.preconf.bson
   :members:
   :undoc-members:
   :show-inheritance:

cattrs.preconf.cbor2 module
---------------------------

.. automodule:: cattrs.preconf.cbor2
   :members:
   :undoc-members:
   :show-inheritance:

cattrs.preconf.json module
--------------------------

.. automodule:: cattrs.preconf.json
   :members:
   :undoc-members:
   :show-inheritance:

cattrs.preconf.msgpack module
-----------------------------

.. automodule:: cattrs.preconf.msgpack
   :members:
   :undoc-members:
   :show-inheritance:

cattrs.preconf.msgspec module
-----------------------------

.. automodule:: cattrs.preconf.msgspec
   :members:
   :undoc-members:
   :show-inheritance:

cattrs.preconf.orjson module
----------------------------

.. automodule:: cattrs.preconf.orjson
   :members:
   :undoc-members:
   :show-inheritance:

cattrs.preconf.pyyaml module
----------------------------

.. automodule:: cattrs.preconf.pyyaml
   :members:
   :undoc-members:
   :show-inheritance:

cattrs.preconf.tomlkit module
-----------------------------

.. automodule:: cattrs.preconf.tomlkit
   :members:
   :undoc-members:
   :show-inheritance:

cattrs.preconf.ujson module
---------------------------

.. automodule:: cattrs.preconf.ujson
   :members:
   :undoc-members:
   :show-inheritance:
