1. Overview
===========
MeetingCommunes is a specific profile for the package Products.PloneMeeting

It configures PloneMeeting to be useable for college and council of belgian cities

2. Project resources
====================
Homepage:       http://www.plonegov.org/
                http://www.communesplone.org/
Project page:   http://plonegov.org/software/products/plonemeeting
Mailing list:   https://lists.plonegov.org/cgi-bin/mailman/listinfo/
                https://lists.communesplone.org/cgi-bin/mailman/listinfo
SVN repository: http://svn.communesplone.org/svn/communesplone/Products.MeetingCommunes/
IRC:            irc://freenode.net/#plone.be

3. License
==========
Please look at LICENSE.txt, LICENSE.ZPL and LICENSE.GPL

The authors,

        Gauthier BASTIEN - 2008-2013 <g.bastien@imio.be>, 
        Stephan GEULETTE - 2008-2013 <s.geulette@imio.be>,
        André NUYENS - 2010-2013 <a.nuyens@imio.be>

4. Changes
==========
Please look at HISTORY.txt
