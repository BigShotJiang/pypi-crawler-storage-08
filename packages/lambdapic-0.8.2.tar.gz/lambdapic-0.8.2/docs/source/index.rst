Welcome to λpic's documentation!
=====================================

Porject repository: https://github.com/xsgeng/lambdapic

.. toctree::
   :maxdepth: 2
   
   introduction
   installation
   example
   AI_prompt
   api
   write_callbacks
   extension


.. Indices and tables
.. ==================

.. * :ref:`genindex`

.. * :ref:`modindex`

.. * :ref:`search`
