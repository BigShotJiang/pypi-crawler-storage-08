Extending λPIC
================

TODO.