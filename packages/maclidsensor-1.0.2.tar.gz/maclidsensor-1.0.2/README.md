# maclidsensor


[![image](https://img.shields.io/pypi/v/maclidsensor.svg)](https://pypi.python.org/pypi/maclidsensor)


**Python Boilerplate contains all the boilerplate you need to create a Python package.**


-   Free software: MIT License
-   Documentation: https://YashwanKafle.github.io/maclidsensor
    

## Features

-   TODO
