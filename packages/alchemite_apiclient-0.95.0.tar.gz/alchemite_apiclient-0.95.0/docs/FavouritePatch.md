# FavouritePatch

Update metadata for favourite reference

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result_indices** | **[int]** | The indices of the favourite results in the favourited job. This will replace the previous value for resultIndices on the job | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


