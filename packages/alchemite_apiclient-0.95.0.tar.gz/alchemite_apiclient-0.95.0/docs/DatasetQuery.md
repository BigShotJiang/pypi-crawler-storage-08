# DatasetQuery

Query for datasets

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sort** | [**[DatasetsMetadataSort]**](DatasetsMetadataSort.md) | Sort the result by the dataset&#39;s attributes.  | [optional] 
**filters** | [**DatasetsMetadataFilters**](DatasetsMetadataFilters.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


