# DatasetQueryResponse


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **int** |  | 
**result** | [**[DatasetQueryResponseResult]**](DatasetQueryResponseResult.md) |  | 
**type** | **str** |  | defaults to "dataset"

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


