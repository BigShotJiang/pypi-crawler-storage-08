# DatasetFavouriteQuery

Query for favourite datasets

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**DatasetsFavouritesFilters**](DatasetsFavouritesFilters.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


