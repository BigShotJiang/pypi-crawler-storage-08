from elemental_tools.audio.core import AudioGenerator, AudioRecognition
from elemental_tools.audio.specs import AudioPath

