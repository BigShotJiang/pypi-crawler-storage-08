"""Clean command package."""
