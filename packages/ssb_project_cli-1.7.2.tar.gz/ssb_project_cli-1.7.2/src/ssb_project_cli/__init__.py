"""SSB Project CLI."""
