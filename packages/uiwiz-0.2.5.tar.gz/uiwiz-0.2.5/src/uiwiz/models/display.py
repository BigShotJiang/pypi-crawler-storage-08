def display_name(input: str) -> str:
    value = str(input)
    return value.replace("_", " ")
