"""Version information for databricks-claude."""

__version__ = "1.0.0"
