# Databricks Claude CLI

[![CI/CD Pipeline](https://github.com/databricks/databricks-claude/actions/workflows/ci.yml/badge.svg)](https://github.com/databricks/databricks-claude/actions/workflows/ci.yml)
[![codecov](https://codecov.io/gh/databricks/databricks-claude/branch/main/graph/badge.svg)](https://codecov.io/gh/databricks/databricks-claude)
[![PyPI version](https://badge.fury.io/py/databricks-claude.svg)](https://badge.fury.io/py/databricks-claude)
[![Python versions](https://img.shields.io/pypi/pyversions/databricks-claude.svg)](https://pypi.org/project/databricks-claude/)
[![License](https://img.shields.io/github/license/databricks/databricks-claude.svg)](https://github.com/databricks/databricks-claude/blob/main/LICENSE)

Production-grade Databricks Claude CLI integration with seamless OAuth authentication.

## Features

✅ **Seamless Authentication**: Automatic OAuth token management with Databricks  
✅ **Zero Configuration**: Works out of the box with sensible defaults  
✅ **Production Ready**: Comprehensive error handling, logging, and retry logic  
✅ **Cross-Platform**: Supports macOS, Linux, and Windows  
✅ **Type Safe**: Full type hints and mypy compliance  
✅ **Well Tested**: 95%+ test coverage with unit and integration tests  

## Quick Start

### Installation

```bash
pip install databricks-claude
```

### Authentication

```bash
# One-time setup with browser-based OAuth
databricks-claude login
```

### Usage

```bash
# Interactive Claude session
databricks-claude "Explain this Python code: print('hello')"

# Non-interactive mode
databricks-claude --print "What is machine learning?"

# Continue previous conversation
databricks-claude --continue

# Check system status
databricks-claude status
```

## How It Works

1. **Automatic Token Management**: Seamlessly manages Databricks OAuth tokens
2. **Transparent Operation**: Updates Claude configuration automatically
3. **Smart Refresh**: Only refreshes tokens when needed for optimal performance
4. **Graceful Errors**: Clear error messages with actionable guidance

## Architecture

```
User Command → Authentication Check → Token Refresh → Claude CLI Execution
                        ↓
                Databricks OAuth ← → Claude Configuration
```

## Configuration

The CLI uses these configuration locations:

- **Main Config**: `~/.databricks-claude/config.json`
- **Claude Config**: `~/.claude/settings.json` (managed automatically)
- **Databricks Config**: `~/.databrickscfg` (managed by Databricks CLI)

### Custom Configuration

```bash
# Use custom Databricks host
databricks-claude --host https://my-workspace.databricks.com login

# Enable debug logging
databricks-claude --debug "test command"
```

## Development

### Setup Development Environment

```bash
git clone https://github.com/databricks/databricks-claude.git
cd databricks-claude

# Install in development mode
pip install -e ".[dev]"

# Install pre-commit hooks
pre-commit install
```

### Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=databricks_claude

# Run specific test file
pytest tests/test_core.py

# Run integration tests
pytest tests/integration/
```

### Code Quality

```bash
# Format code
black src tests

# Sort imports
isort src tests

# Lint code
flake8 src tests

# Type check
mypy src

# Security check
bandit -r src

# Check dependencies
safety check
```

### Building and Publishing

```bash
# Build package
python -m build

# Check package
twine check dist/*

# Upload to PyPI (maintainers only)
twine upload dist/*
```

## API Reference

### Core Classes

#### `DatabricksClaudeCore`

Main class for Databricks Claude integration.

```python
from databricks_claude.core import DatabricksClaudeCore

core = DatabricksClaudeCore(
    databricks_host="https://workspace.databricks.com",
    debug=True
)

# Check authentication
is_auth, email = core.is_authenticated()

# Get fresh token
token = core.get_databricks_token()

# Execute Claude with token refresh
exit_code = core.refresh_token_and_execute(["--print", "hello"])
```

### CLI Commands

#### `login`
Set up authentication with Databricks using browser-based OAuth.

```bash
databricks-claude login
```

#### `logout`
Clear all authentication data.

```bash
databricks-claude logout
```

#### `status`
Check authentication and system status.

```bash
databricks-claude status
```

### Error Handling

The package includes comprehensive error handling:

- `DatabricksClaudeError`: Base exception class
- `AuthenticationError`: Authentication-related errors
- `ConfigurationError`: Configuration-related errors
- `TokenExpiredError`: Token expiration errors

## Enterprise Deployment

### Docker

```dockerfile
FROM python:3.11-slim

RUN pip install databricks-claude

COPY entrypoint.sh /entrypoint.sh
RUN chmod +x /entrypoint.sh

ENTRYPOINT ["/entrypoint.sh"]
```

### Kubernetes

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: databricks-claude
spec:
  replicas: 1
  selector:
    matchLabels:
      app: databricks-claude
  template:
    metadata:
      labels:
        app: databricks-claude
    spec:
      containers:
      - name: databricks-claude
        image: ghcr.io/databricks/databricks-claude:latest
        env:
        - name: DATABRICKS_HOST
          value: "https://workspace.databricks.com"
```

### Environment Variables

- `DATABRICKS_HOST`: Default Databricks workspace URL
- `DATABRICKS_CLAUDE_DEBUG`: Enable debug logging
- `DATABRICKS_CLAUDE_CONFIG_DIR`: Custom config directory

## Troubleshooting

### Common Issues

**"Not authenticated with Databricks"**
```bash
# Solution: Run login command
databricks-claude login
```

**"Claude CLI not found"**
```bash
# Solution: Install Claude CLI
# Download from https://claude.ai/download
```

**"Token refresh failed"**
```bash
# Solution: Re-authenticate
databricks-claude logout
databricks-claude login
```

### Debug Mode

Enable detailed logging:

```bash
databricks-claude --debug status
```

### Getting Help

1. Check the [documentation](https://databricks-claude.readthedocs.io/)
2. Search [existing issues](https://github.com/databricks/databricks-claude/issues)
3. Create a [new issue](https://github.com/databricks/databricks-claude/issues/new)

## Security

### Security Policy

Please see [SECURITY.md](SECURITY.md) for our security policy and how to report vulnerabilities.

### Token Security

- OAuth tokens are stored securely with restricted file permissions (600)
- Tokens are automatically refreshed to minimize exposure time
- No tokens are logged or exposed in debug output
- Configuration files use secure permissions

## Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

### Development Workflow

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Run tests (`pytest`)
5. Commit your changes (`git commit -m 'Add amazing feature'`)
6. Push to the branch (`git push origin feature/amazing-feature`)
7. Open a Pull Request

## License

This project is licensed under the Apache License 2.0 - see the [LICENSE](LICENSE) file for details.

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a history of changes.

## Support

- **Documentation**: https://databricks-claude.readthedocs.io/
- **Issues**: https://github.com/databricks/databricks-claude/issues
- **Discussions**: https://github.com/databricks/databricks-claude/discussions
- **Email**: databricks-claude-support@databricks.com
