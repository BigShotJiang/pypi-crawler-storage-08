"""Functions to test the coregistration filters."""
