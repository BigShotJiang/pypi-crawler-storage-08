(credits)=
# Credits and background

```{toctree}
:maxdepth: 2

history
mission
authors
funding
license
```
