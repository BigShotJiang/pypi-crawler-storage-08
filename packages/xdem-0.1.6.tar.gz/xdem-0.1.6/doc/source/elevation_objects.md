(elevation-objects)=
# Elevation data objects

Elevation data objects of xDEM inherit their characteristics from raster and vector objects of
our sister-package [GeoUtils](https://geoutils.readthedocs.io/en/stable/).

```{toctree}
:maxdepth: 2

dem_class
elevation_point_cloud
```
