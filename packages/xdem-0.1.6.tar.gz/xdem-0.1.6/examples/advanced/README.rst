.. _examples-advanced:

Advanced
========

Examples for setting up **specific coregistration or bias-correction pipelines**, **comparing terrain methods**,
or **refining an error model for DEM uncertainty analysis**.
