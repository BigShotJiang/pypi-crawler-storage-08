.. _examples-basic:

Basic
=====

Examples using **terrain methods** and **DEM differences**, as well as
pre-defined **coregistration** and **uncertainty analysis** pipelines.
