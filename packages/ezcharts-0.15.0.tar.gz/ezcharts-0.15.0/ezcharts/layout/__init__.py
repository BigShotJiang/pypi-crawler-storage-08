"""ezcharts layout functionality."""
