from __future__ import annotations

import ert


@ert.plugin(name="fmu_dataio")
def installable_workflow_jobs() -> dict:
    return {}
