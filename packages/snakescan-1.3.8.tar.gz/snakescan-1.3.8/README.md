##SnakeScan##


import SnakeScan
----------------------------
and use module to scan port 

#For full compatibility, I recommend using python 3.x.x#

#added new check all port search#


 [$]Port--> --a 
 
#added new check all port using thread#
 
 
 [$]Port--> --t 
 
 #added new dos attack#
 
 
 [$]Host-->https://example.com --d
 
 
 #added new check ip#
 
 
 --l to use need internet connection
 
 #added help hint#
 
 
 --h