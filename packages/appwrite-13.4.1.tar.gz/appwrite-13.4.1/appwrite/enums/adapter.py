from enum import Enum

class Adapter(Enum):
    STATIC = "static"
    SSR = "ssr"
