from enum import Enum

class HealthCheckStatus(Enum):
    PASS = "pass"
    FAIL = "fail"
