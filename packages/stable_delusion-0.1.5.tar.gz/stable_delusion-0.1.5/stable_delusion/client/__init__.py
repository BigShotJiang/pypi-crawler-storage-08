"""
Client implementations for AI model integrations.
"""

__author__ = 'Lene Preuss <lene.preuss@gmail.com>'
