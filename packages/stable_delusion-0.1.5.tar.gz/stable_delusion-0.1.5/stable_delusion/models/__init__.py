"""
Models package for NanoAPIClient.
Contains DTOs and data models for API contracts.
"""

__author__ = "Lene Preuss <lene.preuss@gmail.com>"
