"""
Capa of Infraestructura - Implementaciones técnicas concretas.
"""

# Re-exportar componentes principales for facilitar imports
# Commented out problematic imports for now to fix Clean Architecture structure
# from .storage.dicom_repository import DICOMImageRepository
# from .visualization.vtk_renderer import MedicalVTKRenderer
# from .di.medical_service_container import MedicalServiceContainer

__all__ = [
    # 'DICOMImageRepository',
    # 'MedicalVTKRenderer',
    # 'MedicalServiceContainer'
]