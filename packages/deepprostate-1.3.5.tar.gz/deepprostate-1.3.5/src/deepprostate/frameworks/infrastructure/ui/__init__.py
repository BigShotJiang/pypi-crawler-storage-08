"""
Medical user interface components.
"""

from .main_window import MedicalMainWindow

__all__ = [
    'MedicalMainWindow'
]