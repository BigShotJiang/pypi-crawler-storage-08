"""Command line interface module for MedVision."""
