"""A library of Nitpick styles.

Building blocks that can be combined and reused.
"""
