"""Styles for Python."""
