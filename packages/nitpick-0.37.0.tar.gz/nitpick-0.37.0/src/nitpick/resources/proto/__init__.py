"""Styles for Protobuf files."""
