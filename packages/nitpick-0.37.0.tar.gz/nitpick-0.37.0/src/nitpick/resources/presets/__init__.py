"""Style presets."""
