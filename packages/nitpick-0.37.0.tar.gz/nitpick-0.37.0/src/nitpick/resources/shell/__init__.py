"""Styles for shell scripts."""
