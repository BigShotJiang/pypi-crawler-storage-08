"""Styles for Markdown files."""
