"""Cast CLI - Command line interface for Cast Sync."""

__version__ = "0.3.1"
