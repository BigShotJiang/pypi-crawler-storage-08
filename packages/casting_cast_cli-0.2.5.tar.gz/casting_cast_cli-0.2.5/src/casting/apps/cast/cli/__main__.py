"""Entry point for running cast-cli as a module."""

from casting.apps.cast.cli.cli import app

if __name__ == "__main__":
    app()
