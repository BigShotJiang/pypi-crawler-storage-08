FOO = 123

from . import bar
