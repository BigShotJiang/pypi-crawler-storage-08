.. _weston-config:

Weston config
=============

.. doxygengroup:: weston-config
   :content-only:
