#ifndef REAPER_CLEANUP_H_
#define REAPER_CLEANUP_H_

void wait_all();
void close_all_descendants();

#endif
