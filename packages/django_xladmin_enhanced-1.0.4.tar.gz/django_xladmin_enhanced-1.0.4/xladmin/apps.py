﻿from django.apps import AppConfig
from django.core import checks
from django.utils.translation import gettext_lazy as _
import xladmin


class XAdminConfig(AppConfig):
    """Simple AppConfig which does not do automatic discovery."""

    name = 'xladmin'
    verbose_name = _("Administration")

    def ready(self):
        self.module.autodiscover()
        setattr(xladmin,'site',xladmin.site)

