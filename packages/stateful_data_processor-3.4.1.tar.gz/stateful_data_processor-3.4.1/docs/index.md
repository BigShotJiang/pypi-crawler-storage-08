# Documentation

```{toctree}
:maxdepth: 2
:caption: Contents

Overview <../README.md>
API Reference <api/modules>         # fixes modules.rst warning
Changelog <changelog>               # docs/changelog.rst
Contributing <contributing>         # docs/contributing.rst
Authors <authors>                   # docs/authors.rst
License <license>                   # docs/license.rst
