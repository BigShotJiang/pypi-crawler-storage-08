from rsalor.structure.residue import Residue
from rsalor.structure.structure import Structure
