"""Matchbox API."""

from matchbox.server.api.main import app

__all__ = ("app",)
