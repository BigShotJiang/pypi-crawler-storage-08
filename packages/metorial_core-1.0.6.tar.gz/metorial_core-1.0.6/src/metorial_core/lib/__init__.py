"""
Metorial Core Library
"""
