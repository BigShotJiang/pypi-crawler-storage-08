"""PyTorch Forecasting test suite."""
