from pytorch_forecasting.layers._blocks._residual_block_dsipts import ResidualBlock

__all__ = ["ResidualBlock"]
