"""PyTorch Forecasting registry."""

from pytorch_forecasting._registry._lookup import all_objects

__all__ = ["all_objects"]
