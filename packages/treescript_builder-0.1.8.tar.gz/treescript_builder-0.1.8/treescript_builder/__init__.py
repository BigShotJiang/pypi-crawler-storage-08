""" TreeScript Builder.
 - Previously, and sometimes referred to as FileTreeBuilder.
 Author: DK96-OS 2024 - 2025
"""