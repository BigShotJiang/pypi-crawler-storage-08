__version__ = '0.1.4'

import json
import os
import re
from fnmatch import fnmatch
from typing import List, Pattern


def filter_paths(config_json: str, resolve_base: str = "cwd") -> list[str]:
    """
    Given a JSON string defining 'root_dir' and 'filters',
    returns a list of file paths matching the rules.
    """
    data = json.loads(config_json)
    cfg = Config(data, resolve_base=resolve_base)
    return collect_files(cfg)


def normalize_path(p: str) -> str:
    """Collapse backslashes and multiple slashes to '/', trim whitespace (comparison only)."""
    p = re.sub(r"[\\/]+", "/", p)
    return p.strip()


# ---------- Directory glob to regex (supports ** across /) ----------

def _dir_glob_to_regex_body(glob_pat: str) -> str:
    """
    Convert a casefolded directory glob (with ** allowed to cross '/')
    into a regex body that matches path segments separated by '/'.
    - '*'  -> [^/]*    (does not cross '/')
    - '?'  -> [^/]     (single non-slash)
    - '**' -> .*       (may cross '/')
    Other characters are escaped.
    """
    out = []
    i = 0
    while i < len(glob_pat):
        if i + 1 < len(glob_pat) and glob_pat[i] == "*" and glob_pat[i + 1] == "*":
            out.append(".*")
            i += 2
            continue
        c = glob_pat[i]
        if c == "*":
            out.append("[^/]*")
        elif c == "?":
            out.append("[^/]")
        else:
            out.append(re.escape(c))
        i += 1
    return "".join(out)


def _compile_dir_globs(patterns: List[str]) -> List[Pattern]:
    """
    Compile dir patterns into regexes that:
      - are case-insensitive
      - respect segment boundaries
      - treat leading '/' as anchored-to-start
      - allow deeper subpaths after a match
    """
    regexes: List[Pattern] = []
    for raw in patterns or []:
        p = normalize_path(raw)
        if not p:
            continue
        anchored = p.startswith("/")
        p_body = p.lstrip("/").casefold()

        body = _dir_glob_to_regex_body(p_body)
        if anchored:
            # start-of-dirpath; allow deeper subpaths
            # ^BODY(?:/.*)?$  matches BODY or BODY/<anything>
            rx = re.compile(rf"^{body}(?:/.*)?$", re.IGNORECASE)
        else:
            # anywhere: (^|.*/)<BODY>(/.*)?$
            # ensures a segment boundary before and '/' or end after the body
            rx = re.compile(rf"(^|.*/){body}(/.*)?$", re.IGNORECASE)
        regexes.append(rx)
    return regexes


# ---------- File pattern/extension helpers ----------

def parse_file_patterns(patterns):
    """Normalize and casefold filename patterns (fnmatch semantics)."""
    return [normalize_path(p).casefold() for p in patterns or []]


def parse_extensions(patterns):
    """
    Normalize extensions so both 'ext' and '.ext' are treated the same.
    Stored as casefolded, with a leading '.'. Supports multi-dot suffixes.
    """
    out: list[str] = []
    for e in patterns or []:
        if not isinstance(e, str):
            continue
        s = e.strip().lstrip(".")
        if not s:
            continue
        out.append("." + s.casefold())
    return out


class Config:
    def __init__(self, data: dict, resolve_base: str = "cwd"):
        self.verbose = bool(data.get("verbose", False))

        raw_root_original = str(data["root_dir"]).strip()
        if os.path.isabs(raw_root_original):
            root = raw_root_original
        else:
            if resolve_base in ("", "cwd"):
                base_dir = os.getcwd()
            elif resolve_base == "script":
                base_dir = os.path.dirname(os.path.abspath(__file__))
            else:
                base_dir = resolve_base
            root = os.path.join(base_dir, raw_root_original)

        # OS-native absolute normalized root
        self.root_dir = os.path.abspath(os.path.normpath(root))

        inc = data["filters"]["include"]
        exc = data["filters"]["exclude"]

        # Presence gates (so empty lists still enforce deny-all unless include.files matches)
        self.inc_dirs_enabled = "dirs" in inc
        self.inc_exts_enabled = "extensions" in inc

        # Directory patterns -> compiled regex (supports **)
        self.inc_dir_regexes = _compile_dir_globs(inc.get("dirs", []))
        self.exc_dir_regexes = _compile_dir_globs(exc.get("dirs", []))

        # Filename patterns
        self.include_files = parse_file_patterns(inc.get("files", []))
        self.exclude_files = parse_file_patterns(exc.get("files", []))

        # Extensions
        self.inc_exts = parse_extensions(inc.get("extensions", []))
        self.exc_exts = parse_extensions(exc.get("extensions", []))

        if self.verbose:
            print(f"[config] root_dir: {self.root_dir}")
            print(f"[config] include.dirs enabled={self.inc_dirs_enabled}, patterns={inc.get('dirs', [])}")
            print(f"[config] exclude.dirs patterns={exc.get('dirs', [])}")
            print(f"[config] include.files={self.include_files}")
            print(f"[config] exclude.files={self.exclude_files}")
            print(f"[config] include.ext enabled={self.inc_exts_enabled}, list={self.inc_exts}")
            print(f"[config] exclude.ext={self.exc_exts}")


def _name_endswith_any(name_cf: str, suffixes: list[str]) -> bool:
    """Case-insensitive suffix match for file name against extension list."""
    return any(name_cf.endswith(suf) for suf in suffixes)


def _dirpath_matches_any(dirpath: str, regexes: List[Pattern]) -> bool:
    """Return True if any compiled dir regex matches the relative dirpath."""
    if not regexes:
        return False
    # dirpath is '' at root; patterns won’t match unless anchored pattern is empty (we don't have that)
    return any(rx.search(dirpath) for rx in regexes)


def should_include(full_path: str, cfg: Config) -> bool:
    """Determine if a file should be included based on the config rules."""
    # Build comparison-ready relative dirpath
    rel = os.path.relpath(full_path, cfg.root_dir)
    rel_cmp = normalize_path(rel).casefold()
    segments = rel_cmp.split("/")
    name_cf = segments[-1]
    ancestors = segments[:-1]
    dirpath = "/".join(ancestors)  # '' if at root

    if cfg.verbose:
        print(f"[check] {rel}")

    # 1) Include-files override (always wins)
    for patt in cfg.include_files:
        if fnmatch(name_cf, patt):
            if cfg.verbose:
                print(f"  -> include by filename pattern '{patt}'")
            return True

    # 2) Excludes: extension
    if cfg.exc_exts and _name_endswith_any(name_cf, cfg.exc_exts):
        if cfg.verbose:
            print(f"  -> excluded by extension in {cfg.exc_exts}")
        return False

    # 3) Excludes: filename
    for patt in cfg.exclude_files:
        if fnmatch(name_cf, patt):
            if cfg.verbose:
                print(f"  -> excluded by filename '{patt}'")
            return False

    # 4) Excludes: directories (regex over full dirpath)
    if dirpath and _dirpath_matches_any(dirpath, cfg.exc_dir_regexes):
        if cfg.verbose:
            print("  -> excluded by directory pattern")
        return False

    # 5) Include by directories (allowlist behavior driven by presence)
    if cfg.inc_dirs_enabled:
        if not cfg.inc_dir_regexes:
            # include.dirs present but empty -> only include.files allowed
            if cfg.verbose:
                print("  -> excluded: include.dirs present but empty (only include.files allowed)")
            return False
        # If at root, still pass the dir gate (preserving previous behavior)
        if dirpath:
            if not _dirpath_matches_any(dirpath, cfg.inc_dir_regexes):
                if cfg.verbose:
                    print("  -> excluded: no matching include-dir pattern")
                return False

    # 6) Include by extension (allowlist) — enabled by presence
    if cfg.inc_exts_enabled:
        if not _name_endswith_any(name_cf, cfg.inc_exts):
            if cfg.verbose:
                print("  -> excluded: extension not in include list")
            return False

    if cfg.verbose:
        print("  -> included")
    return True


def collect_files(cfg: Config) -> list[str]:
    """Walk root_dir and collect files passing should_include."""
    matches: list[str] = []
    if cfg.verbose:
        print(f"[walk] scanning {cfg.root_dir}")

    for root, _, files in os.walk(cfg.root_dir, followlinks=False):
        for fn in files:
            full = os.path.join(root, fn)
            if os.path.islink(full):
                if cfg.verbose:
                    print(f"[skip] symlink: {full}")
                continue
            if should_include(full, cfg):
                matches.append(os.path.abspath(os.path.normpath(full)))

    if cfg.verbose:
        print(f"[result] total matches: {len(matches)}")
    return matches
