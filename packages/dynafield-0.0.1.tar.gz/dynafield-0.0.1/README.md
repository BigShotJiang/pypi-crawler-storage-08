# dynafield
Python dynamic schema
