from . import pkglog

if __name__ == '__main__':
    pkglog.main()
