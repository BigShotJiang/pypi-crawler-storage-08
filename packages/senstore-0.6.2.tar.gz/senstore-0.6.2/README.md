Minimalistic vector store for sentences segmented from text.
See test.py for examples of use.