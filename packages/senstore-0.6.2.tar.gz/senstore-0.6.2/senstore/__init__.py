__version__ = "0.6.2"


def get_version():
    return __version__
