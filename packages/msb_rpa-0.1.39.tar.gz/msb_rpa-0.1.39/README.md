# Introduction
This is a collection of functions generally used in RPA projects in AAK MSB.

# Getting Started
Use pip install aak_msb_generelt and import any function relevant in the current file.

## Recent Changes

## [1.26] - 09-04-2025 /MFL
### Added
- Added Selenium-Wire option for Modulus login.