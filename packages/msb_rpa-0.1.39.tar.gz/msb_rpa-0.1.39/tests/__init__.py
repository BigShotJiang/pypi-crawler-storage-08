from msb_rpa.logins import opus_login

opus_login('test',"pass")