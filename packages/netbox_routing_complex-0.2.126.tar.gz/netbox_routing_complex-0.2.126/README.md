## netbox-routing-complex

Manage complex routing structures in NetBox