from django import forms
from netbox.forms import NetBoxModelForm
from .models import VNI, VXLAN, AddressFamilyChoices, BFDConfig, BGPGlobalConfig, BGPPeer, BGPPeerGroup, BGPSessionConfig, ISISConfig
from utilities.forms.fields import CommentField

class BFDConfigForm(NetBoxModelForm):
    comments = CommentField()

    class Meta:
        model = BFDConfig
        fields = ('hello_interval', 'multiplier', 'description', 'comments', 'tags')

class BGPGlobalConfigForm(NetBoxModelForm):
    comments = CommentField()

    class Meta:
        model = BGPGlobalConfig
        fields = (
            'device', 'asn', 'use_cluster_id', 'router_id_override', 'cluster_id_override', 'graceful_restart', 'up_down_logging', 'comments', 'tags'
        )

class BGPSessionConfigForm(NetBoxModelForm):
    comments = CommentField()
    #address_families should be a dropdown in the GUI
    address_families = forms.MultipleChoiceField(
        choices=AddressFamilyChoices,
        required=False
    )

    class Meta:
        model = BGPSessionConfig
        fields = (
            'name', 'address_families', 'peer_asn', 'import_policy', 'export_policy',
            'next_hop_self', 'hardcoded_description', 'hello_interval', 'keepalive_interval',
            'ebgp_multihop', 'unencrypted_password', 'encrypted_password', 'source_interface',
            'source_ip', 'local_asn', 'bfd_config', 'use_route_reflector_client', 'comments', 'tags'
        )

class BGPPeerForm(NetBoxModelForm):
    comments = CommentField()

    class Meta:
        model = BGPPeer
        fields = ('device', 'name', 'peer_ip', 'session_config', 'comments', 'tags')

class BGPPeerGroupForm(NetBoxModelForm):
    comments = CommentField()

    class Meta:
        model = BGPPeerGroup
        fields = ('device', 'name', 'description', 'session_config', 'peers', 'comments', 'tags')

class VNIForm(NetBoxModelForm):
    comments = CommentField()

    class Meta:
        model = VNI
        fields = ('vlan', 'vnid', 'tenant', 'description', 'comments', 'tags')

class VXLANForm(NetBoxModelForm):
    comments = CommentField()

    class Meta:
        model = VXLAN
        fields = (
            'ipv4_gateway', 'ipv6_gateway', 'vni', 'l3mtu', 'ingress_replication', 'comments', 'tags'
        )

class ISISConfigForm(NetBoxModelForm):
    comments = CommentField()

    class Meta:
        model = ISISConfig
        fields = (
            'device', 'router_id', 'pid', 'afi', 'area_id', 'network_selector', 'net_hardcoded', 'default_link_metric', 'comments', 'tags'
        )