"""
Spymot V2 Scripts: Command-line interfaces for enhanced functionality.
"""

# This module provides access to V2 CLI scripts
# The actual scripts are imported from the V2 directory
