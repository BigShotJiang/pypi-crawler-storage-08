# Copyright (c) 2025 Microsoft Corporation.
# Licensed under the MIT License

"""GraphRAG Language Models module. Allows for provider registrations while providing some out-of-the-box solutions."""
