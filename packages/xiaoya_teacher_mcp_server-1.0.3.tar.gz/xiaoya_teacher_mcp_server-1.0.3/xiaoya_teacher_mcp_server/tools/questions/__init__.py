"""题目管理模块"""

from . import create, delete, update, query  # noqa: F401
