"""资源管理模块"""

# 导出所有工具函数
from . import create, delete, update, query  # noqa: F401
