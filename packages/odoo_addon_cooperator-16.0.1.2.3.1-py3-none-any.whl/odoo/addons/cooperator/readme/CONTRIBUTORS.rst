* `Coop IT Easy SC <https://coopiteasy.be>`_:

  * Houssine Bakkali
  * Robin Keunen
  * Rémy Taymans
  * Victor Champonnois
  * Vincent Van Rossem
  * Manuel Claeys Bouuaert
  * Carmen Bianca Bakker
  * hugues de keyzer
