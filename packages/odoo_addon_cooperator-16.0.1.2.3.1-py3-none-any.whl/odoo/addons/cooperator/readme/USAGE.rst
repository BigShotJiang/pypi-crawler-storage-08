See the `documentation <https://doc.it4socialeconomy.org/books/application-cooperators>`_ (not available in english ATM).

A localization module is needed with this module.
