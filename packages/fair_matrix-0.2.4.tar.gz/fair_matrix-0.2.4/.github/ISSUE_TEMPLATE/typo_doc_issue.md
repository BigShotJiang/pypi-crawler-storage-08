---
name: Typo or Documentation Issue
about: Report a typo or an issue related to documentation.
labels: 'documentation, needs triage'
---

For typos, please go ahead; fix the typo and submit a PR. For documentation issues, please describe the issue here and wait for approval before submitting a PR.
