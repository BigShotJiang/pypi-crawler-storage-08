# Package marker for characterization tests
