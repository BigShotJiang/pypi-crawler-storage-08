# fiuai-sdk-python
fiuai frappe python sdk
