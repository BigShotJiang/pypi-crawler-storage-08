import setuptools
setuptools.setup(
name = 'GENERAL7',
version = '3.1.0',
author = 'GENERAL:@GN_R7',
description = 'This library is from my programming For Accounts,Users..GENERAL_Iraq_@GN_R7',
packages = setuptools.find_packages(),
classifiers = [
"Programming Language :: Python :: 3",
"Operating System :: OS Independent",
"License :: OSI Approved :: MIT License",

]
)