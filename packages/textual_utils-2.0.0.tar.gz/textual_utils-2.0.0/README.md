# textual-utils

Variious utilities for use with the Textual package

## Features

Dialogs - AboutScreen, ConfirmScreen, SettingsScreen

AboutHeaderIcon - replacement for standard HeaderIcon for displaying AboutScreen

## Installation

```bash
$ pip install textual-utils
```

## License

`textual-utils` was created by Rafal Padkowski. It is licensed under the terms
of the MIT license.
