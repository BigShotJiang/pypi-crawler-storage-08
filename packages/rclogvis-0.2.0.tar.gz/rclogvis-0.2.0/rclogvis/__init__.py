from rclogvis.version import __version__
