This module makes the system to always respect the planned (or scheduled)
date set by the user when creating a Purchase Order.

Additionally, this module modifies the PO views and sets in red the lines
that are predicted to arrive late compared to the scheduled date and vendor
lead time.
