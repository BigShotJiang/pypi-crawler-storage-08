To use this module you could follow any of the two options below:

#. Go to 'Purchase' and create a purchase order.
#. Manually set the scheduled date in the PO lines.
#. This date will never be modified by the system and the lines that are
   expected to be late are highlighted in red.

Or:

#. Create a procurement order for a product that can be bought and have the
   route 'buy' activated.
#. Run the procurement.
#. Now the scheduled date in the procurement is respected even if the line is
   added to a previously existing PO.
