# Static assets for pysuricata

