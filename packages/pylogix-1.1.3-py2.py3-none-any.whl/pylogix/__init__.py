from .eip import PLC
__version_info__ = (1, 1, 3)
__version__ = '.'.join(str(x) for x in __version_info__)
