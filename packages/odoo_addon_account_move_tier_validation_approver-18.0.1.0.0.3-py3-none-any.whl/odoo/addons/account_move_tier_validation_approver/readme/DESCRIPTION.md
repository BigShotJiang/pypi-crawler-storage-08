This module allows to select a Responsible for approval in the partner
form. If a tier definition is set and configured with the "Responsible
for Approval" field, the approver will be the one chosen in the partner
form.
