To configure this module, you need to:

1.  Go to *Settings \> Technical \> Tier Validations \> Tier
    Definition*.
2.  Create a new tier or edit an existing one.
3.  Set the "Validated by" field to "Field in related record".
4.  Set the "Reviewer field" to "Responsible for Approval".

A default tier validation called "Validation with Approver field" is set
with this configuration.
