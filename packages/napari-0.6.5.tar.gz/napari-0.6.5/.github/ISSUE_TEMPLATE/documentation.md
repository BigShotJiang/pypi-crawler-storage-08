---
name: "\U0001F4DA Documentation"
about: Report an issue with napari code documentation
title: ''
labels: documentation
assignees: ''

---

## 📚 Documentation
<!-- A clear and concise description of the documentation that needs to be created/updated -->
<!-- If you found that something is documented in code but not in the docs, please report it in [napari/docs](https://github.com/napari/docs/issues) instead -->
