from napari._qt.layer_controls.widgets._surface.qt_shading_combobox import (
    QtShadingComboBoxControl,
)

__all__ = [
    'QtShadingComboBoxControl',
]
