# JupyterPower

This is a Python Package for use in Data Science + Jupyter Notebooks for end-to-end ML Engineering, MLOps, Data Science productions tasks

## Uninstall any old packages

### Make sure your project .venv is active:
`source .venv/bin/activate`

### Uninstall any old packages (jupyterpower & jpower), and show any leftovers

```
# sanity
which python
python -m pip --version

# uninstall both names (safe even if not present)
python -m pip uninstall -y jupyterpower jpower

# look for any stragglers in site-packages (dry run list)
python - <<'PY'
import sys, sysconfig, pathlib
sp = pathlib.Path(sysconfig.get_paths()["purelib"])
candidates = [p for p in sp.iterdir() if p.name.lower().startswith(("jpower","jupyterpower"))]
print("Site-packages:", sp)
print("Leftovers:", [p.name for p in candidates] or "None")
PY
```

### Install the newest from PyPI (clean)

`python -m pip install --upgrade --no-cache-dir jupyterpower`

### Verify jupyterpower is installed

```
# package metadata
python -m pip show jupyterpower

# freeze view (should show jupyterpower==0.9.5, and NOT jpower)
python -m pip freeze | egrep -i '^(jupyterpower|jpower)'

# python-level verification (import + dist check + scan site-packages)
python - <<'PY'
import sys, importlib, importlib.metadata as md, sysconfig, pathlib
print("PY:", sys.executable)
# import should succeed
m = importlib.import_module("jupyterpower")
print("✅ import jupyterpower OK")
print("CODE version:", getattr(m, "__version__", "unknown"))
print("CODE file   :", getattr(m, "__file__", "unknown"))
# distribution metadata
print("DIST version:", md.version("jupyterpower"))
# ensure no 'jpower' dist present
bad = [d for d in md.distributions() if d.metadata["Name"].lower()=="jpower"]
print("Other dist named 'jpower':", [b.metadata["Version"] for b in bad] or "None")
# scan site-packages for any top-level jpower folders
sp = pathlib.Path(sysconfig.get_paths()["purelib"])
leftovers = [p.name for p in sp.iterdir() if p.name.lower().startswith("jpower")]
print("Site-packages leftovers starting with 'jpower':", leftovers or "None")
PY
```


## Installation Support
From PyPI:
```bash
pip install jupyterpower

## Check install
python -c "import jupyterpower; print(jupyterpower.__version__)"

## Load a CSV, smooth a column, fit a simple baseline, and save a plot:
from jupyterpower import DATA_DIR, RESULTS_DIR, load_csv, moving_average, fit_linear_time
from jupyterpower.viz import plot_series_with_smooth, save_fig

# explicit columns for this demo schema
time_col  = "time"
value_col = "signal"

df = load_csv(DATA_DIR / "sample.csv", create_placeholder=True)
smooth = moving_average(df, value_col=value_col, window=7)
model, X, y, pred = fit_linear_time(df, time_col=time_col, y_col=value_col)

fig, ax = plot_series_with_smooth(df, time_col=time_col, value_col=value_col, smooth=smooth)
out_png = RESULTS_DIR / "quickstart_plot.png"
save_fig(fig, out_png)
print("Saved:", out_png)


## Using a Jupyter Notebook
%load_ext autoreload
%autoreload 2
import jupyterpower; print("jupyterpower", jupyterpower.__version__)



