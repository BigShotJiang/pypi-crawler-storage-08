To make a report encryptable mark the field Encryption in the report
record.
