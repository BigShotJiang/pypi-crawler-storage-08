# Constants for Entry Fields - Input Types
DIGITAL_OBJECT_INPUT = 13
SELECT_COMBO_INPUT = 4