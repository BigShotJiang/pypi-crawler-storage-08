"""Shortcut for imports of only the exposed components."""
from .cli import download  # noqa: F401
