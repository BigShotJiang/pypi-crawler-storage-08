"""Sample manifest commands."""
from .cli import sample_manifests  # noqa: F401
