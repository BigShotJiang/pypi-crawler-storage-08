"""S3 autoimports management commands."""
from .cli import autoimports  # noqa: F401
