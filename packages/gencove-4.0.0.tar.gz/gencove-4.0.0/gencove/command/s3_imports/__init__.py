"""S3 imports management commands."""
from .cli import s3  # noqa: F401
