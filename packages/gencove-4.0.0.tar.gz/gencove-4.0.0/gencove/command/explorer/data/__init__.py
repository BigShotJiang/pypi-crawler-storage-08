"""Shortcut for imports of only the exposed components."""
from .cli import data  # noqa: F401
