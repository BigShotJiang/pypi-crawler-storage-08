from dataclasses import dataclass


@dataclass
class ModelTest:
    name: str
    age: int
