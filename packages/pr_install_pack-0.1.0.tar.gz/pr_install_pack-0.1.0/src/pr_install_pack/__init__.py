def main() -> None:
    print("Hello from pr-install-pack!")
