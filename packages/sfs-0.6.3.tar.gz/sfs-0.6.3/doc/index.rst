.. include:: ../README.rst

----

.. toctree::

    installation
    examples
    api
    references
    contributing
    version-history

.. only:: html

    * :ref:`genindex`
