API Documentation
=================

.. automodule:: sfs
