# This is a configuration file that's used when opening the Jupyter notebooks
# in this directory.
# See https://nbviewer.jupyter.org/github/mgeier/python-audio/blob/master/plotting/matplotlib-inline-defaults.ipynb

c.InlineBackend.figure_formats = {'svg'}
c.InlineBackend.rc = {'figure.dpi': 96}
