.. default-role:: py:obj

.. include:: ../NEWS.rst
