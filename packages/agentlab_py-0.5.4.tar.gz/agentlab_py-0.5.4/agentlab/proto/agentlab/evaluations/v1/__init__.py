"""Evaluations service v1 protobuf definitions."""
