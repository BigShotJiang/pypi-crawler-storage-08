# Multpl Provider Extension

This is an implementation of the data published to (https://multpl.com)[https;//multpl.com]

## Installation

```
pip install openbb-multpl
```

## Endpoints

- `obb.index.sp500_multiples`
