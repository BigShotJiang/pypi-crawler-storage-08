def test_utils_import():
    import eynollah.utils
    import eynollah.utils.contour
    import eynollah.utils.drop_capitals
    import eynollah.utils.drop_capitals
    import eynollah.utils.is_nan
    import eynollah.utils.rotate
