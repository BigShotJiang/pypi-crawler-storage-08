"""
Entry point for module invocation via `python -m`.
"""

import sys

import scfw.main as main


if __name__ == "__main__":
    sys.exit(main.main())
