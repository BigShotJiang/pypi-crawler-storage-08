from __future__ import annotations

"""Provide namespace package."""

__path__ = __import__("pkgutil").extend_path(__path__, __name__)
