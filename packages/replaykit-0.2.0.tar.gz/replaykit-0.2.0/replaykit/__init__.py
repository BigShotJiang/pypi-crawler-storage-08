"""ReplayKit - Record and replay mouse, keyboard, and scroll actions."""

__version__ = "0.1.0"
