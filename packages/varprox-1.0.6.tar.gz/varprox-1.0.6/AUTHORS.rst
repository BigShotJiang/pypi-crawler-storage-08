Credits
=======

Varprox is written and maintained by Arthur Marmin and Frederic Richard, Aix-Marseille University, France. 
