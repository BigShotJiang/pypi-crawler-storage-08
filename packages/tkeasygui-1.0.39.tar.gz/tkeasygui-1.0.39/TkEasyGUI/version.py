# pylint: disable=line-too-long
"""
# TkEasyGUI version 1.0.39

audo generated from [pyproject.toml](https://github.com/kujirahand/tkeasygui-python/blob/main/pyproject.toml) by update_version.py
"""
__version__ = "1.0.39"
