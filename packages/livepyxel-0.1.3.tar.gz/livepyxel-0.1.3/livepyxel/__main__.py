# livepyxel/__main__.py
from .imageAnnotator import main

if __name__ == "__main__":
    raise SystemExit(main())