from .placements_summary import _PlacementsSummary  # noqa
