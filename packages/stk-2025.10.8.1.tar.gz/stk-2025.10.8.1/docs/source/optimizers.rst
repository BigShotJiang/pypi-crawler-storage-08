Optimizers
==========

.. toctree::
  :maxdepth: 1

  Optimizer <_autosummary/stk.Optimizer>
  Collapser <_autosummary/stk.Collapser>
  Periodic Collapser <_autosummary/stk.PeriodicCollapser>
  MCHammer <_autosummary/stk.MCHammer>
  Spinner <_autosummary/stk.Spinner>
  NullOptimizer <_autosummary/stk.NullOptimizer>
