This module automatically assigns the EDI source to records created through the EDI mechanism.
