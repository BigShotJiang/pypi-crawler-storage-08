"""
Tests para pdf-notes-extractor
"""
