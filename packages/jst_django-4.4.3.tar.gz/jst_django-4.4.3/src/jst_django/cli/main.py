from jst_django.cli.app import app
from jst_django.commands import *  # noqa

if __name__ == "__main__":
    app()
