Binary 20x16 digits of '0' through '9' and capital 'A' through 'Z'. 39 examples
of each class.
