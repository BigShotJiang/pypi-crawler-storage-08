import { Application, Controller } from "@hotwired/stimulus"

const Stimulus = Application.start();
export { Stimulus, Controller };