"""
应用程序模块

包含主要的用户界面和应用程序逻辑。
"""

from .simple_start import simple_start

__all__ = ["simple_start"]
