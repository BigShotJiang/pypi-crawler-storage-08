"""Vega Framework CLI tools"""

from vega.cli.main import cli

__all__ = ["cli"]
