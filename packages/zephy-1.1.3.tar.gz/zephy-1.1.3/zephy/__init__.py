"""Zephy Azure TFE Resources Toolkit - Compare Azure resources with Terraform Enterprise workspaces."""
