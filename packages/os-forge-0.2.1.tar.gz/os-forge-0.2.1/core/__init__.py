"""
Core module for OS Forge
Contains API, CLI, and configuration management
"""

__version__ = "1.0.0"

