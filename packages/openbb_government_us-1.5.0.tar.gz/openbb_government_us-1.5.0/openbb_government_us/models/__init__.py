"""CIRO Data models."""
