## suletree

This package provides a function to print the structure (including classes and functions) of Python modules in a tree-like format.

---
### Usage
```bash
suletree <directory>
```