# Plain Templates AGENTS.md

- Plain templates use Jinja2.
