from .console import Console, LEVEL

console = Console()
'''The logger used by the core'''