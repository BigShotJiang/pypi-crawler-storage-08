def parse_script_from_raw(raw : str):
    return raw