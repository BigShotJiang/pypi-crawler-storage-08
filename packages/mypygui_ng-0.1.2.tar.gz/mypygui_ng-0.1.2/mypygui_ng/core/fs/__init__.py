from .uri import URI
from .reading import load, load_local, load_web, FileType