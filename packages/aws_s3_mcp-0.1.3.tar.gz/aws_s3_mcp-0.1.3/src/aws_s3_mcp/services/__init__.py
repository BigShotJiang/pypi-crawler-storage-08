"""
Service layer for AWS S3 MCP server.

This module contains the business logic for interacting with AWS S3 APIs.
"""
