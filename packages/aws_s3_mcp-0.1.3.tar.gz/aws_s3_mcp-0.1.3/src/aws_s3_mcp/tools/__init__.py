"""
MCP tools for AWS S3 operations.

This module contains the MCP tool definitions that expose S3 functionality
to AI models through the Model Context Protocol.
"""
