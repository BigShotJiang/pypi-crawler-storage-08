# Author: Mark Blakeney, Feb 2024.
from sys import exit

from . import pipxu

if __name__ == '__main__':
    exit(pipxu.main())
