
class OptionType:
    CALL = 1
    PUT = 2