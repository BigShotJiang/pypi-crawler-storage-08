# Copyright (C) 2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""SuperSimpleNet model."""

from .lightning_model import Supersimplenet

__all__ = ["Supersimplenet"]
