"""FPlanck: Solve the Fokker-Planck equation in N dimensions."""
