# terminal_monkeytype package
from .main import main