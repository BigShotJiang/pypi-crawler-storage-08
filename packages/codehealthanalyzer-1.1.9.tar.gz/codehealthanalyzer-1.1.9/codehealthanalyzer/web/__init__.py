"""Módulo web para dashboard interativo do CodeHealthAnalyzer.

Este módulo fornece uma interface web com dashboard interativo
para visualização de métricas de qualidade de código em tempo real.
"""

__version__ = "1.0.0"
__author__ = "Luarco Team"
