# Code

## Format

We are using `ruff` to automatically format the code. The command is defined as an environment in Tox:

```sh
tox -e format
```
