Usage Examples
##############

.. toctree::
   :maxdepth: 2

   SK Model and Transpilation
   Sparse Maxcut
   Portfolio Optimization
   Training the QAOA
   Which Qubits on the QPU Are Used