import lib_speak
import lib_helper
import lib_sl_text