"""
Transformers DLT pour l'ETL Enedis.
Architecture modulaire avec chaînage de transformations.
"""