#pragma once

namespace ecole::scip {
class Model;
}
