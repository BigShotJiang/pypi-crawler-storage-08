# __init__.py : _susi_iot

__version__ = '1.0.0'