from enum import Enum

class _SusiIotGpioDirectionType(Enum):
    OUTPUT = 0
    INPUT = 1
     
class _SusiIotGpioLevelType(Enum):
    
    LOW = 0
    HIGH = 1