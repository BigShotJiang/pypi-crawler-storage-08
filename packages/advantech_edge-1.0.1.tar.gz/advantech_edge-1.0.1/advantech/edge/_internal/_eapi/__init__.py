# __init__.py : _eapi

__version__ = '1.0.0'