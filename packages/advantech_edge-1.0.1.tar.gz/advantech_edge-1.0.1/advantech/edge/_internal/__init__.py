# __init__.py : _internal

__version__ = '1.0.0'