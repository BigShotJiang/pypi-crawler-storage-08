# __init__.py : idevices

__version__ = '1.0.0'

# Import sub packages

# Import modules in sub packages
from .idevice import IDevice