"""AI Configurator - Cross-platform configuration manager for Amazon Q CLI."""

__version__ = "0.1.0"
__author__ = "AI Configurator Team"
__description__ = "Cross-platform configuration manager for Amazon Q CLI"
