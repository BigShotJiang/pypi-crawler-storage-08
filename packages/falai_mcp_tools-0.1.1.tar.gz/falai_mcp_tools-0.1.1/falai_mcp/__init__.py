"""fal.ai MCP server powered by FastMCP."""

from .server import build_server, get_server

__all__ = ["build_server", "get_server"]
