def mock_process(geom, model):
  with open('/palm-4u-preprocessor-oap/palm_4u_preprocessor_oap/mock.zip', 'rb') as f:
    data = f.read()

  return data
