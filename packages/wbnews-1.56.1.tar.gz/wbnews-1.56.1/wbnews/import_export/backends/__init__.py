from .news import DataBackend
