"""Tiingo models."""
