"""Tiingo helpers."""
