HTTP_READ_TIMEOUT = 30

# Resolution constants for API requests
RESOLUTION_HOUR = "hour"
RESOLUTION_QUARTER = "quarter"
