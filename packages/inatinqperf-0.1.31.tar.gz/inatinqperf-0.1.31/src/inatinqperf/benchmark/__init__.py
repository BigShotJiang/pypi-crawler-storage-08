"""__init__.py for benchmark."""

from .benchmark import Benchmarker  # noqa: F401
