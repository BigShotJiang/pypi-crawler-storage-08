# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Statistics Service."""

__version__ = "3.0.2"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .get_global_stat_item_by_f4e6d4 import GetGlobalStatItemByStatCode
from .get_global_stat_item_by_4617a3 import GetGlobalStatItemByStatCode1
from .get_global_stat_items import GetGlobalStatItems
from .get_global_stat_items_1 import GetGlobalStatItems1
