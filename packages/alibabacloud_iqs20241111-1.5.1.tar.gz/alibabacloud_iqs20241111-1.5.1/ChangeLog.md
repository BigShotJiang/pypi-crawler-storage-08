2025-10-10 Version: 1.5.0
- Support API ReadPageBasic.
- Update API GenericSearch: add request parameters returnRichMainBody.


2025-09-08 Version: 1.4.3
- Generated python 2024-11-11 for IQS.

2025-09-08 Version: 1.4.2
- Generated python 2024-11-11 for IQS.

2025-08-07 Version: 1.4.1
- Generated python 2024-11-11 for IQS.

2025-07-24 Version: 1.4.0
- Support API GetIqsUsage.


2025-07-01 Version: 1.3.2
- Generated python 2024-11-11 for IQS.

2025-07-01 Version: 1.3.1
- Generated python 2024-11-11 for IQS.

2025-05-08 Version: 1.3.0
- Support API UnifiedSearch.


2025-05-08 Version: 1.2.1
- Generated python 2024-11-11 for IQS.

2025-04-08 Version: 1.2.0
- Support API GlobalSearch.


2025-03-29 Version: 1.1.6
- Update API GenericSearch: add request parameters enableRerank.
- Update API GenericSearch: add request parameters returnMainText.
- Update API GenericSearch: add request parameters returnMarkdownText.
- Update API GenericSearch: add request parameters returnSummary.


2025-02-27 Version: 1.1.5
- Update API GenericAdvancedSearch: add param industry.


2025-02-18 Version: 1.1.4
- Generated python 2024-11-11 for IQS.

2025-01-16 Version: 1.1.3
- Generated python 2024-11-11 for IQS.

2024-12-20 Version: 1.1.2
- Update API AiSearch: update response param.


2024-12-12 Version: 1.1.1
- Generated python 2024-11-11 for IQS.

2024-11-15 Version: 1.1.0
- Support API AiSearch.
- Support API GenericAdvancedSearch.
- Update API GenericSearch: add param industry.
- Update API GenericSearch: add param page.
- Update API GenericSearch: add param sessionId.
- Update API GenericSearch: update param query.
- Update API GenericSearch: update param timeRange.


2024-11-05 Version: 1.0.1
- Generated python 2024-11-11 for IQS.

2024-11-05 Version: 1.0.0
- Generated python 2024-11-11 for IQS.

