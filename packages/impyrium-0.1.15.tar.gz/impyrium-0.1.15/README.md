# impyrium
A python device control program that can handle sending commands to devices
and integrating everything into keyboard shortcuts

## Getting started
```
pip3 install watchdog
pip3 install pynput
pip3 install PySide6
```

### Setting up a project
```
python3 -m impyrium
cd impyre
python3 run.py
```

Then configure as you like!
