"""
Typically I add a subdirectory to my modules with CLI interfaces called "cli",
but I already added a Python module named that to scriptconfig, and to maintain
backwards compat, I'm calling this one "_cli". This may change in a major
version bump.
"""
