def test_import():
    import scriptconfig