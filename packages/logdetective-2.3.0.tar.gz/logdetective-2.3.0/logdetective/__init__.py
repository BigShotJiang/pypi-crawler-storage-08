import logging

logger = logging.getLogger("logdetective")
