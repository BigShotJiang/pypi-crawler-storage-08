name = "pytrinamic"
desc = "TRINAMIC's Python Technology Access Package"


def show_info():
    print(name + " - " + desc)
