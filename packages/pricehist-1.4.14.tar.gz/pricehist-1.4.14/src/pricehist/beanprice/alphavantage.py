from pricehist import beanprice
from pricehist.sources.alphavantage import AlphaVantage

Source = beanprice.source(AlphaVantage())
