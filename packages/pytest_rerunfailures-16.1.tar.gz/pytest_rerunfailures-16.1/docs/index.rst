pytest-rerunfailures
====================

.. include:: ../README.rst
    :start-after: .. START-SHORT-DESCRIPTION
    :end-before: .. END-SHORT-DESCRIPTION

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   quickstart
   cli
   configuration
   mark
   contributing
   changelog
