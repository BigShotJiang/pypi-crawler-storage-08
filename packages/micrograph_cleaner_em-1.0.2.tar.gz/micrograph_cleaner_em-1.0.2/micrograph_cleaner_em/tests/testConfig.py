import os
TEST_DATA_ROOT_DIR= os.path.abspath(os.path.join(__file__,"..", "data/"))
print(TEST_DATA_ROOT_DIR)
