"""
Docker Monitor - A powerful desktop tool for monitoring and managing Docker containers.
"""

__version__ = "1.0.1"
__author__ = "Amir Khoshdel Louyeh"
__email__ = "amirkhoshdellouyeh@gmail.com"