

class ExporterConfiguration:
    """The configuration for the exporter.

    This class can be extended by exporters to add custom configuration options.
    """
