# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- This changelog file
- Minimal working example CLI with `export` subcommand
- POC CMake and esp-idf project files
- Support for SemVer, `vSemVer` and quasi-PEP440 version strings

### Changed

### Removed


## [0.0.1] - 2025-10-04

### Added

- Initial git tag for package version tracking.

### Fixed

### Changed

### Removed
