# SPDX-FileCopyrightText: 2025-present Ricardo Marchesan <ricardo@azevem.com>
#
# SPDX-License-Identifier: MIT
