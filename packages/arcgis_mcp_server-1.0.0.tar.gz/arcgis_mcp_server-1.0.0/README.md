https://github.com/modelcontextprotocol/registry/blob/main/docs/guides/publishing/publish-server.md

