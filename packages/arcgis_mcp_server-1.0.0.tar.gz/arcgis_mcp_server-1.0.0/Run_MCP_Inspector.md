1. activate your environment by :
	conda env list
	activate [name of env]
2. cd to the path of mcpserver.py
3. npx @modelcontextprotocol/inspector
4. in the environment add MCP_RUNNING_AS_TOOL: true