"""Brynq SDK Visma Lon HR package"""
from .visma import Visma
