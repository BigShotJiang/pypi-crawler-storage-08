from django.apps import AppConfig


class DjangoPaddleBillingConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_paddle_billing"
    verbose_name = "Paddle Billing"
