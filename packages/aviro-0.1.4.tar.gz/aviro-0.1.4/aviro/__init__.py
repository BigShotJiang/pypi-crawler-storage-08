"""Aviro - A Python package for [describe your package's purpose here]."""

__version__ = "0.1.4"
__author__ = "Your Name"
__email__ = "your.email@example.com"

# Import main classes/functions here if needed
# from .span import SomeClass
