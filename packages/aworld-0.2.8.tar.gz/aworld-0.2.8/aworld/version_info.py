# auto generated
class VersionInfo:
    BUILD_DATE = "2025-10-08 16:37:22"
    BUILD_VERSION = "0.2.8"
    BUILD_USER = "grs" 
    SCENARIO = "AWORLD_SDIST"
