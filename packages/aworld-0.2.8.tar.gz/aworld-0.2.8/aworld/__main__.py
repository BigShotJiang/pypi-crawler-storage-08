# coding: utf-8
# Copyright (c) 2025 inclusionAI.

from aworld.cmd.cli import main

if __name__ == "__main__":
    main()
