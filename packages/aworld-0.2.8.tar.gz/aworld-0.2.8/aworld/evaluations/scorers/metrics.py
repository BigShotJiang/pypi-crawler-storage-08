class MetricNames:
    LABEL_DISTRIBUTION = 'label_distribution'
    SUMMARIZE_QUALITY = 'summarize_quality'
    ANSWER_ACCURACY = 'answer_accuracy'
    PREDICT_TIME_COST_MS = 'predict_time_cost_ms'