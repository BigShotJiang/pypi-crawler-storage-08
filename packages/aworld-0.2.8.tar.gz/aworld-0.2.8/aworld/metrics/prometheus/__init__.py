# coding: utf-8
# Copyright (c) 2025 inclusionAI.
from aworld.utils.import_package import import_packages

import_packages(['prometheus_client'])
