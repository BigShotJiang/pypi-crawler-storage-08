
# auto generated
class VersionInfo(object):
    @property
    def build_date(self):
      return "2025-10-08 16:37:22"

    @property
    def version(self):
      return "0.2.8"

    @property
    def build_user(self):
      return "grs"
