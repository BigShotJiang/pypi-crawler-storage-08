# coding: utf-8
# Copyright (c) 2025 inclusionAI.
from aworld.core.event.event_bus import InMemoryEventbus

# global
eventbus = InMemoryEventbus()