Command Line Utilities
----------------------

The following command line utilities are installed.
Run each utility's help for further information.

.. code-block:: console

    $ utility --help

plot-filter
~~~~~~~~~~~

Plots convolution filters.

plot-taper
~~~~~~~~~~

Plots tapers associated with convolution filters.
