=====
Usage
=====

To use Codex Africanus in a project::

    import africanus
