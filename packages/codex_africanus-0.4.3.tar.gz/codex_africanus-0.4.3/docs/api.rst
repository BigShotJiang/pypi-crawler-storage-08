API
===

.. toctree::
    :maxdepth: 1

    rime-api.rst
    dft-api.rst
    gridding-api.rst
    deconv-api.rst
    coordinates-api.rst
    model-api.rst
    averaging-api.rst
    util-api.rst
    calibration-api.rst
    linalg-api.rst
    gps-api.rst

    experimental.rst
