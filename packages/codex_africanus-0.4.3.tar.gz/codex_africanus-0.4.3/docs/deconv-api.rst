------------------------
Deconvolution Algorithms
------------------------

.. currentmodule:: africanus.deconv.hogbom


.. autofunction:: hogbom_clean
