===========================================
Welcome to Codex Africanus's documentation!
===========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   usage
   cmdline-utils
   api
   contributing
   authors
   history

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
