=======
Credits
=======

Development Lead
----------------

* Simon Perkins <sperkins@ska.ac.za>

Contributors
------------

* Landman Bester <lbester@ska.ac.za>
* Benjamin Hugo <bhugo@ska.ac.za>
* Jonathan Kenyon <jkenyon@ska.ac.za>
* Gijs Molenaar <gijs@pythonic.nl>
* Joshua van Staden <joshvstaden14@gmail.com>
* Oleg Smirnov <oms@ska.ac.za, osmirnov@gmail.com>
