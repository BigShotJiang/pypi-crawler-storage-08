# -*- coding: utf-8 -*-


def test_cub_download():
    from africanus.util.cub import cub_dir

    cub_dir()
