# -*- coding: utf-8 -*-


def test_trove_download():
    from africanus.util.trove import trove_dir

    trove_dir()
