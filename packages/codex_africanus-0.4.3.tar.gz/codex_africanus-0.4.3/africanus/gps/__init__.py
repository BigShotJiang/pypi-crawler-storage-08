# flake8: noqa

from africanus.gps.kernels import exponential_squared
from africanus.gps.utils import abs_diff
