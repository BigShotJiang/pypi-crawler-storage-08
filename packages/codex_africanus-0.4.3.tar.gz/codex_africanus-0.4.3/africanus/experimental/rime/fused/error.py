class InvalidSignature(ValueError):
    pass
