from africanus.experimental.rime.fused.specification import RimeSpecification  # noqa
from africanus.experimental.rime.fused.core import rime  # noqa
