Experimental RIME with Google JAX
=================================

Google `jax <https://github.com/google/jax_>`_ supports

- jit compilation of numpy code to both CPU and GPU targets
- autodiff gradients, jacobians and hessians
