# NOTE(sjperkins)
# Imports at this level should be avoided,
# or should fail gracefully as functionality
# in these modules is called by setup.py
