__all__ = ["load", "spectra"]

from africanus.model.wsclean.file_model import load
from africanus.model.wsclean.spec_model import spectra
