__all__ = ["spectral_model"]

from africanus.model.spectral.spec_model import spectral_model
