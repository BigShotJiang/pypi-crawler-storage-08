===============
Codex Africanus
===============


.. image:: https://img.shields.io/pypi/v/codex-africanus.svg
        :target: https://pypi.python.org/pypi/codex-africanus

.. image:: https://img.shields.io/travis/ska-sa/codex-africanus.svg
        :target: https://travis-ci.org/ska-sa/codex-africanus

.. image:: https://readthedocs.org/projects/codex-africanus/badge/?version=latest
        :target: https://codex-africanus.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status


.. image:: https://pyup.io/repos/github/ska-sa/codex-africanus/shield.svg
     :target: https://pyup.io/repos/github/ska-sa/codex-africanus/
     :alt: Updates



Radio Astronomy Building Blocks


Documentation
-------------

https://codex-africanus.readthedocs.io.
