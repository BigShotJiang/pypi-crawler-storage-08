from django.apps import AppConfig


class DjVditorConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "dj_vditor"
