"""Main code for module."""

from __future__ import annotations

from . import cti2bibtex

if __name__ == "__main__":
    cti2bibtex()
