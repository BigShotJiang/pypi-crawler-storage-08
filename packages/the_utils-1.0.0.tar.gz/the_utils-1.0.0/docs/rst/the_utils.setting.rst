Setting
----------------------------------------------------------

.. automodule:: the_utils.setting
   :members:
   :no-undoc-members:
   :show-inheritance:
