.. A11y Algorithm documentation master file, created by
   sphinx-quickstart on Sun Apr 10 10:22:04 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to the_utils' documentation!
======================================================

.. toctree::
   :maxdepth: 4
   :caption: Setting
   :glob:

   rst/the_utils.setting

.. toctree::
   :maxdepth: 4
   :caption: Plt
   :glob:

   rst/the_utils.plt

.. toctree::
   :maxdepth: 4
   :caption: File
   :glob:

   rst/the_utils.file

.. toctree::
   :maxdepth: 4
   :caption: Save_load
   :glob:

   rst/the_utils.save_load

.. toctree::
   :maxdepth: 4
   :caption: Evaluation
   :glob:

   rst/the_utils.evaluation

.. toctree::
   :maxdepth: 4
   :caption: Common
   :glob:

   rst/the_utils.common

.. toctree::
   :maxdepth: 4
   :caption: Bot
   :glob:

   rst/the_utils.bot



Index
==================

* :ref:`genindex`
