#!/usr/bin/env python
# -*- coding: utf-8 -*-

name = "py3comtrade"
__version__ = "4.1.6"
