# Guide

```{toctree}
:hidden:
:caption: "How to"

query-search
track
curate
manage-ontologies
transfer
```

```{toctree}
:hidden:
:caption: Other topics

faq
storage
```
