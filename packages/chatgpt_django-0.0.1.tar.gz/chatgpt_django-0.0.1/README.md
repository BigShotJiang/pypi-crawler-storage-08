# chatgpt-django

A placeholder package to reserve the name `chatgpt-django`.

## Installation

```bash
pip install chatgpt-django
```

## License

MIT
