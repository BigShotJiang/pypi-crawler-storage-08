"""An example project using buildsys-dateversion with flit."""

__version__ = "0"
