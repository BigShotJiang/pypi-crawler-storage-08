__version__ = "0"


def some_func() -> str:
    return __version__
