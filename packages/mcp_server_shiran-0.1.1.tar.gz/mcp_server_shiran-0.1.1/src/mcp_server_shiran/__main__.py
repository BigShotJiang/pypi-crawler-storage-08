from mcp_server_shiran import main 
main()