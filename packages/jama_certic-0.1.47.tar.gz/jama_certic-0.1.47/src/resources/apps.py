from django.apps import AppConfig


class ResourcesConfig(AppConfig):
    name = "resources"
