# UI

Instanciation de la lib [vue3-jama](https://git.unicaen.fr/pdn-certic/vue3-jama).

Pour désactiver les annotations, ajouter avant compilation dans un fichier .env de ce dossier:

```
VITE_ANNOTATIONS_ENABLED=0
```

