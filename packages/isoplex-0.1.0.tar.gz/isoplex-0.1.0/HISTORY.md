# History

## 0.1.0 (2025-09-29)

* First release on PyPI.
