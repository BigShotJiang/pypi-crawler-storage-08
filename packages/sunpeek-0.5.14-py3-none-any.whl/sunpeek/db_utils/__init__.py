DATETIME_COL_NAME = "ds"
PARTITION_COLS = ['year', 'quarter']