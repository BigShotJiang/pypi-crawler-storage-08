from __future__ import annotations

"""Legacy arXiv tool package for autodiscovery."""

__all__ = []

# Legacy arXiv client and query utilities
