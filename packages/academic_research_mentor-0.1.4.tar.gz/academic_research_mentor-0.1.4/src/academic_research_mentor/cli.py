from __future__ import annotations

from .cli.main import main

__all__ = ["main"]
