# pirborg
pirborg: Intermediate representation optimized to make building prompt compilers, dialect extensions, and code generation easier and more intuitive
