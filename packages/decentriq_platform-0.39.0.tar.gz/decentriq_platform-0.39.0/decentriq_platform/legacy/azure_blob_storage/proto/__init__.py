from .azure_blob_storage_pb2 import (
    AzureBlobStorageWorkerConfiguration,
    ExportRole,
    ImportRole,
    RawFile,
    SingleFile,
    SinkInput,
    ZipFile,
)
