from .microsoft_dsp_pb2 import (
    MicrosoftDspWorkerConfiguration,
    RawFile,
    SingleFile,
    SinkInput,
    ZipFile,
    SegmentInfo,
    MemberInfo,
)
