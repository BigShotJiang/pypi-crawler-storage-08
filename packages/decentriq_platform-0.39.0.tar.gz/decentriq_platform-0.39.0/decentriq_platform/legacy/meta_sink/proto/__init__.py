from .meta_sink_pb2 import (
    MetaSinkWorkerConfiguration,
    RawFile,
    SingleFile,
    SinkInput,
    ZipFile,
)
