"""Unit tests for YSA Signal application"""
