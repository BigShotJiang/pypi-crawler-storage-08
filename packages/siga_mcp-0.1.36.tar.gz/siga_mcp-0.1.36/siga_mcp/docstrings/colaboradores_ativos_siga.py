from textwrap import dedent


def docs() -> str:
    return dedent("""\
                  Retorna a lista de colaboradores ativos.
                  """)
