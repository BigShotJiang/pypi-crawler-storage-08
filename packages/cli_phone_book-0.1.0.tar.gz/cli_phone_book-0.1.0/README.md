# Example Package

CLI телефонный справочник с --help.