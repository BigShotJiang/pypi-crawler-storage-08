---
title: Redirecting…
---

<meta http-equiv="refresh" content="0; url=https://lancedb.com/docs/geneva/">
<link rel="canonical" href="url=https://lancedb.com/docs/geneva/">

If you are not redirected, <a href="url=https://lancedb.com/docs/geneva/">click here</a>.

## Prototyping your Python function

Build your Python feature generator function in an IDE or notebook using your project's Python versions and dependencies.

*That's it.*

Geneva will automate much of the dependency and version management needed to move from prototype to scale and production.

