---
title: Redirecting…
---

<meta http-equiv="refresh" content="0; url=https://lancedb.com/docs/geneva/jobs/startup/">
<link rel="canonical" href="url=https://lancedb.com/docs/geneva/jobs/startup/">

If you are not redirected, <a href="url=https://lancedb.com/docs/geneva/jobs/startup/">click here</a>.
