---
title: Redirecting…
---

<meta http-equiv="refresh" content="0; url=https://lancedb.com/docs/geneva/udfs/blobs/">
<link rel="canonical" href="url=https://lancedb.com/docs/geneva/udfs/blobs/">

If you are not redirected, <a href="url=https://lancedb.com/docs/geneva/udfs/blobs/">click here</a>.
