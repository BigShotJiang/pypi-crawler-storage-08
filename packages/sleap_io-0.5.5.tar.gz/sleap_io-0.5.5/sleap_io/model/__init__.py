"""This subpackage contains data model interfaces."""
