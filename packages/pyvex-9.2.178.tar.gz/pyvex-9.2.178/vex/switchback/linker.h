
extern
void* linker_top_level_LINK ( int n_object_names, char** object_names );

extern void* mymalloc ( int );
