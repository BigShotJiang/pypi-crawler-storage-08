"""Azure Provider package."""

from githarbor.providers.azure_provider.repository import AzureRepository

__all__ = ["AzureRepository"]
