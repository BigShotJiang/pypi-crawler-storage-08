"""GitHub Provider package."""

from githarbor.providers.github_provider.repository import GitHubRepository

__all__ = ["GitHubRepository"]
