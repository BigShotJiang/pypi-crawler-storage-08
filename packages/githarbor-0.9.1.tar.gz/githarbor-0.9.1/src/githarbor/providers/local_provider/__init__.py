"""Local Provider package."""

from githarbor.providers.local_provider.repository import LocalRepository

__all__ = ["LocalRepository"]
