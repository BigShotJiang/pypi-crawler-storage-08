# init file for photomap.backend.routers
