__version__ = "1.9.5"

from .plugin import CognitoAuth

__all__ = ["CognitoAuth"]
