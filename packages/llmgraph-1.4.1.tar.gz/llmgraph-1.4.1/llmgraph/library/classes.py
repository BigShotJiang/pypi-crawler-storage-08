class AppUsageException(Exception):
    pass
