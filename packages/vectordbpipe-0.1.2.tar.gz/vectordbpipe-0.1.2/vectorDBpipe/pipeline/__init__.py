# Placeholder for main text pipeline
# Will be implemented in Stage 2

from vectorDBpipe.pipeline.text_pipeline import TextPipeline  # future import placeholder
__all__ = ["TextPipeline"]
