from typing import Optional


class SyncedEventBody:
    synced: Optional[bool]
