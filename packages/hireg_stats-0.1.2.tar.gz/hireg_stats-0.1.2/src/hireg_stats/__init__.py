# pkgs/hireg/src/hireg/__init__.py
from .estimator import HIREG
__all__ = ["HIREG"]