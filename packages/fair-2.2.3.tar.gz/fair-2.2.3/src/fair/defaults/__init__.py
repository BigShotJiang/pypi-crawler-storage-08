"""Module for defaults."""
