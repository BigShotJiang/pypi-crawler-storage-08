# -*- coding: utf-8 -*-
"""ficoxpress-mosel modules."""