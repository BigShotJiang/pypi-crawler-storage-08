# chatgpt-app

A simple Python package that provides a text file.

## Installation

```bash
pip install chatgpt-app
```

## Usage

```python
import chatgpt_app
print(chatgpt_app.get_text())
```

## License

MIT

