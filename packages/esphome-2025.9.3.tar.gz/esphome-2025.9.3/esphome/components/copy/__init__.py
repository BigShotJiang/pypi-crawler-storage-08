import esphome.codegen as cg

CODEOWNERS = ["@OttoWinter"]

copy_ns = cg.esphome_ns.namespace("copy")
