mod check_stopping;
mod estimate_optimal_probabilities;
