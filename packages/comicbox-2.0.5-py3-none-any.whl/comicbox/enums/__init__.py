"""Generic enums."""
