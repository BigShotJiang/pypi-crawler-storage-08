
class VersionAlreadyExists(Exception):
    pass
