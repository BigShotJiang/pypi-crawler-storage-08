from .classifier import *  # noqa:F403
from .navigation import *  # noqa:F403
from .project import *  # noqa:F403
from .search import *  # noqa:F403
from .sphinx_page import *  # noqa:F403
from .version import *  # noqa:F403
