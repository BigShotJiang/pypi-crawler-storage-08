import logging

logger = logging.getLogger("sphinx_hosting")
