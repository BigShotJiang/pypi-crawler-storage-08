# ghcontribs: Simple analytics for GitHub contributions across an organization

## Contributing

Please run `pre-commit install` and `gitmoji -i` on the CLI before starting to work on this repository!
