#pragma once

namespace coro
{
using fd_t = int;

} // namespace coro
