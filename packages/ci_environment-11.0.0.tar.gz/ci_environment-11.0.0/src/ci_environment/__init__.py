from ci_environment.ci_environment import detect_ci_environment

__all__ = ["detect_ci_environment"]
