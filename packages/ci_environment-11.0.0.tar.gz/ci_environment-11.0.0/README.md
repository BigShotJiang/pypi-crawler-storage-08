# CiEnvironment

Python implementation of https://github.com/cucumber/ci-environment
