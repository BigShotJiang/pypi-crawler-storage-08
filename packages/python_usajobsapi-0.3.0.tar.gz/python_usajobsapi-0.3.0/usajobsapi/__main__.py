import usajobsapi.cli

if __name__ == "__main__":
    usajobsapi.cli.main()
