---
name: Issue
about: Report a bug or request a feature to help us improve
title: ""
labels: ""
assignees: ""
---

## Description of feature request or bug

## Expected/Desired Behavior

## Actual/Current Behavior

## Specifications

- python-usajobsapi version:
