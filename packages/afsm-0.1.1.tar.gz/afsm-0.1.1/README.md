# Async-aware documentation-first Finite State Machine.

Generates typed state machine code from UML diagram in PlantUML format.

Funded by the European Union and UKRI. Views and opinions expressed are however those of the author(s)
only and do not necessarily reflect those of the European Union, CINEA or UKRI. Neither the European Union
nor the granting authority can be held responsible for them.
