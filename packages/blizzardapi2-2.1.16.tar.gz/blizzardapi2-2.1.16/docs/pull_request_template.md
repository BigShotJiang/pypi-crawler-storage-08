## Pull Requests
If you submit a PR, please include the description of the proposed changes and, preferably, a reference to the issue here in the repo.
Aside from that, see the contribution guidelines for a quick rundown of what you can do to help the project.
