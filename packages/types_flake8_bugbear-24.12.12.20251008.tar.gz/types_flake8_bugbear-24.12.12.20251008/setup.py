
from setuptools import setup

setup(package_data={'bugbear-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
