import sys,os,re
from .Publisher import Publisher

class StandardPublisher(Publisher):
  pass  