"""Config - re-exports from prime_core for backwards compatibility."""

from prime_core import Config

__all__ = ["Config"]
