from xpense.dashboard.app import main

__all__ = ["main"]
