"""LabVIEW FPGA HDL Tools."""

from importlib.metadata import version

__version__ = version("labview-fpga-hdl-tools")
