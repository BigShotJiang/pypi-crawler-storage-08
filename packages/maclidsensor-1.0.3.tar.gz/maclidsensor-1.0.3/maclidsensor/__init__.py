"""Top-level package for maclidsensor."""

__author__ = """Yashwan Kafle"""
__email__ = "yashwankafle@gmail.com"
__version__ = "1.0.3"
