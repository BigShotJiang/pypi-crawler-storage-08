"""MCP Atlassian Servers Package."""

from .main import main_mcp

__all__ = ["main_mcp"]
