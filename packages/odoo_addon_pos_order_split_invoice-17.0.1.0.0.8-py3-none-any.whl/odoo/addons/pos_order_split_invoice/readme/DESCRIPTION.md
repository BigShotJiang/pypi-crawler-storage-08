This module would allow use to split a pos.order in two moves.

The first one will be payed inside the PoS Order, and the second one
will be payed after by this secondary partner.

This approach might appear in several cases, mainly on co-payments
(Medical centers, Pharmacies...)

The pricelists created with split method shouldn't be used on Sale Orders,
as they are only supported with pos orders made in the pos UI.
