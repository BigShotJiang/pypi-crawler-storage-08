# Profanity Filter Hinglish

A small package to detect and filter **English + Hinglish** profanity.  
Built on top of [better_profanity](https://pypi.org/project/better-profanity/).

## Installation

```bash
pip install profanity-hinglish
```
