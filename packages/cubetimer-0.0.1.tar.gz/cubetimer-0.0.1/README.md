# cubetimer

A Rubik's Cube timer for speedcubers for speedsolving/training with a
Textual-based terminal user interface (TUI).
