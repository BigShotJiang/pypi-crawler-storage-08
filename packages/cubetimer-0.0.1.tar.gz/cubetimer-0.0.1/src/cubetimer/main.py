from __future__ import annotations

from .app import CubeTimer


def main() -> None:
    CubeTimer().run()
