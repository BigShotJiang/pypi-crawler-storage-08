"""Version information for Zephy."""

__version__ = "1.1.1"
__author__ = "Henry Bravo"
__date__ = "October 2025"
