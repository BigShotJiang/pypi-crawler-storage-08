import streamlit as st


def show():
    """
    Display the settings for IoT Inspector
    """
    st.markdown('Settings Haha')