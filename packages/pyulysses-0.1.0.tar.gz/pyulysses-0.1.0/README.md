# pygalp-data-process

## 🎯 Objective
O objetivo deste projeto é fornecer uma ferramenta de **ETL (Extração, Transformação e Carga)** desenvolvida em **Python**, projetada para uso interno, capaz de processar dados armazenados no **S3** ou na plataforma interna **Ulysses**.

Principais funcionalidades:
- **Extração e carga de dados** de múltiplas fontes de forma automatizada.
- Validações de **qualidade de dados** para garantir a integridade e consistência das informações.
- **Testes unitários** para assegurar a qualidade e robustez do código.
- Integração de **CI/CD** para facilitar o deploy e a atualização contínua.

## 🏛️ Architecture

A arquitetura é modular e escalável, composta pelos seguintes componentes principais:

- **Conectores de Fonte de Dados**
  Interfaces responsáveis por ler dados a partir de:
  - Buckets do Amazon S3
  - Plataforma interna Ulysses

- **Pipeline de ETL**
  Responsável por:
  - Extração dos dados brutos
  - Transformação e limpeza dos dados
  - Validação de qualidade dos dados

- **Testes Automatizados**
  Cobertura de testes unitários para garantir a qualidade e detectar possíveis regressões.

- **Integração Contínua / Entrega Contínua (CI/CD)**
  Pipelines automatizados para testes, build e deploy da aplicação.


## ⚙️ Stack
- boto3==1.37.24
- python-dotenv==1.1.0
- pandas==2.2.3
- pyarrow==19.0.1
- pytest==8.3.5
- duckdb==1.2.1

## 📝 Prerequisites
* Python:3.11.9

## 💡  How to use the project ❓
Clone o repositório:
```
git clone http://gitlab.ulysses.galpenergia.corp/code-as-a-service/pygalp-data-process.git
```
Navigate to the project folder:
```
cd caas-commercial-analytics/pygalp-data-process
```

## 💡 How to create and activate the virtual environment ❓
Run the command to create the virtual environment:
```
python -m venv venv
```
Run the command to activate the virtual environment (Windows):
```
 .\venv\Scripts\activate
```

## 💡 How to install the required libraries in the virtual environment ❓
```
pip install -r requirements.txt
```

## 📚 References
https://confluence.galp.com/

## 🤖 Developers
| Desenvolvedor      |  Role          |         Email            |
|--------------------|----------------|--------------------------|
| Wallace Camargo    | Data Engineer  | wallace.camargo@galp.com |
