# Psycopg2Logger

Psycopg2Logger is a high-performance logging library that captures PostgreSQL database queries from psycopg2 and transmits them via TCP to a monitoring application in real-time. It provides detailed SQL query logging with parameter interpolation, execution duration tracking. The logger is optimized for development use with connection pooling, reflection caching, compiled regex patterns, and async logging to minimize performance impact on your application. **Do not run this in production; this is intended for development only.**

## Installation

Install the package via pip:

```bash
pip install psycopg2sqllogger
```

## Usage

### For FastAPI Applications

```python
from fastapi import FastAPI
from psycopg2logger.middleware import SQLInterceptorMiddleware

app = FastAPI()

# Add the middleware to your FastAPI application
app.add_middleware(SQLInterceptorMiddleware)

@app.get("/example")
async def example_endpoint():
    # Your database logic here
    return {"message": "Example endpoint"}

# Run your FastAPI application
# uvicorn main:app --reload
```

### Performance Optimization

For high-throughput applications, you can disable certain features to improve performance:

```python
app.add_middleware(SQLInterceptorMiddleware, enable_caller_detection=False)
```

## Monitoring Application

To view the captured SQL queries, you'll need the companion monitoring application [pgquerymon](https://github.com/larswise/pgquerymon) which provides a real-time dashboard for analyzing your database interactions.

## Features

- **Real-time SQL logging** with parameter interpolation
- **Execution duration tracking** for performance analysis
- **Intelligent caller detection** to identify source business logic
- **High-performance design** with connection pooling and caching
- **Async logging** to prevent blocking your application
- **Support for FastAPI applications**
- **Configurable performance settings** for different use cases

## Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `enable_caller_detection` | true | Enable stack trace analysis (disable for better performance) |
