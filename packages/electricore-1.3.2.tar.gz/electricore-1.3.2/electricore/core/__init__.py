# Imports supprimés pour éviter l'import circulaire
# Utilisez plutôt : from electricore.core.services import ...

# import electricore.core.périmètre
# import electricore.core.relevés
# import electricore.core.énergies