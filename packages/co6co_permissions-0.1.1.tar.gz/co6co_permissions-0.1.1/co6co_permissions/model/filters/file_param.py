
class FileParam:
    name: str = None
    root: str = None

    def __init__(self):
        self.root = None
        self.name = None
        pass
