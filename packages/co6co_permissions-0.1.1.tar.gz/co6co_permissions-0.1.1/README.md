# web 常用服务

# 历史版本

```
0.1.0
    新版本 依赖
        co6co>=0.0.33
        co6co.sanic-ext==0.0.13
        co6co.db-ext==0.0.17
        co6co.web-db==0.0.18
0.1.1
    captchaVerify
```
