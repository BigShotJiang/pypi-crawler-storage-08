"""Fake implementations for testing."""
