# readylog
Readylog is a logging configuration template for Python's logging.
