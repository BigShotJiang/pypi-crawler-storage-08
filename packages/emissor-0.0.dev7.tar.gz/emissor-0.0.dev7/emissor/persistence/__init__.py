from .persistence import file_name, base_name, ScenarioStorage
