# Output Tool

Write content to stdout or files.
