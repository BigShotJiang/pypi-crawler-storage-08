# Custom Tool Template

Provide template scaffolding metadata.
