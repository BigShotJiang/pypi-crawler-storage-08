.. _external_resources:

##################
External Resources
##################

.. include:: external_resources.txt