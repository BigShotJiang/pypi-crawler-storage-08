.. _devops_manual:

################
Developer Manual
################

.. include:: dependencies.txt

.. include:: contribution.txt

.. include:: documentation.txt

.. include:: creating_workflows.txt
