# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 0.1.1

([Full Changelog](https://github.com/jupyter-ai-contrib/jupyter-floating-chat/compare/2391f427a07f1bca30bf3707001ec999e3e239a7...e21369bbe6ecb17112fec33071ef271835ea9038))

### Maintenance and upkeep improvements

- Rename package [#2](https://github.com/jupyter-ai-contrib/jupyter-floating-chat/pull/2) ([@brichet](https://github.com/brichet))
- Move to jupyter-ai-contrib [#1](https://github.com/jupyter-ai-contrib/jupyter-floating-chat/pull/1) ([@brichet](https://github.com/brichet))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-ai-contrib/jupyter-floating-chat/graphs/contributors?from=2025-10-06&to=2025-10-07&type=c))

[@brichet](https://github.com/search?q=repo%3Ajupyter-ai-contrib%2Fjupyter-floating-chat+involves%3Abrichet+updated%3A2025-10-06..2025-10-07&type=Issues)

<!-- <END NEW CHANGELOG ENTRY> -->
