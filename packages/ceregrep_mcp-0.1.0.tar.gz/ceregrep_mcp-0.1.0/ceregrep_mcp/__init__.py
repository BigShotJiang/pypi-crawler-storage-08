"""Ceregrep MCP Server - Exposes ceregrep query capabilities to other agents."""

__version__ = "0.1.0"
