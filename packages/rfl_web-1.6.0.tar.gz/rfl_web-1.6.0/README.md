# RFL: web package

Predefined Flask application templates.
