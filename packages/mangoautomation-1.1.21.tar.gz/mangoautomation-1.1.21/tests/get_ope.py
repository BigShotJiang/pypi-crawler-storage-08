# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-08-31 17:41
# @Author : 毛鹏
loc = 'await page.cdeadapage.'
cleaned_loc = loc.replace('page.', '').replace('await', '')
print(cleaned_loc)