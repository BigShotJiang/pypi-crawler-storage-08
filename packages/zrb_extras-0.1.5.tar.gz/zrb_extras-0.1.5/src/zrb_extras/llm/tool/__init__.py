from zrb_extras.llm.tool.voice import create_listen_tool, create_speak_tool

assert create_listen_tool
assert create_speak_tool
