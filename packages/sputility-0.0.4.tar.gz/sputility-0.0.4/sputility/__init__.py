from .sputility import SPUtility

__version_info__ = (0, 0, 4)
__version__ = '.'.join(str(x) for x in __version_info__)