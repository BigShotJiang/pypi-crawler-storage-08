# -*- coding: utf-8 -*-

__author__ = """Stuart Littlefair"""
__email__ = 's.littlefair@shef.ac.uk'
__version__ = '1.3.10'

from .hcam_finder import *
