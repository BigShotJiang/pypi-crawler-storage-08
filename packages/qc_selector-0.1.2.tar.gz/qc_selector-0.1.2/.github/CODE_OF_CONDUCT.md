# Contributor Covenant Code of Conduct

It is recommended to follow the code of conduct as described in
https://qcdevs.org/guidelines/QCDevsCodeOfConduct/.
