"""Version information for SQLBot."""
__version__ = "1.3.1"


