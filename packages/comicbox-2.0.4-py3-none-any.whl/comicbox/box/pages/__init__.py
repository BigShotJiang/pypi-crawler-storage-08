"""Pages."""

from comicbox.box.pages.extract import ComicboxExtractPages


class ComicboxPages(ComicboxExtractPages):
    """ComicboxPages."""
