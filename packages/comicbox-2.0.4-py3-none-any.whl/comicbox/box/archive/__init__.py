"""Comicbox Archive."""

from comicbox.box.archive.pages import ComicboxArchivePages

__all__ = ("ComicboxArchive",)


class ComicboxArchive(ComicboxArchivePages):
    """Comicbox Archive."""
