from typing import Any, List, Optional, Sequence


ListOfAny = List[Any]
OptionalListOfAny = Optional[ListOfAny]
SequenceOfAny = Sequence[Any]
OptionalSequenceOfAny = Optional[SequenceOfAny]
