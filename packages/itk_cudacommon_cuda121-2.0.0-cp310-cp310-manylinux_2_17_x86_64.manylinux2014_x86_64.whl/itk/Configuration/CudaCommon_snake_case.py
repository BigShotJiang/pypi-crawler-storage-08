snake_case_functions = ('cuda_image_from_image_filter', 'image_source', 'image_to_image_filter', )
