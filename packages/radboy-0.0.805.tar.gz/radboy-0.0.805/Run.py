#!/usr/bin/env python3
#!/usr/bin/env python3
from pathlib import Path
ROOTDIR=str(Path().cwd())
from radboy import RecordMyCodes as rmc
rmc.quikRn(rootdir=ROOTDIR)