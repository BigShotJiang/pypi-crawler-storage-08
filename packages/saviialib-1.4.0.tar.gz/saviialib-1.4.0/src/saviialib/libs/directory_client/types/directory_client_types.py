from dataclasses import dataclass


@dataclass
class DirectoryClientArgs:
    client_name: str = "os_client"
