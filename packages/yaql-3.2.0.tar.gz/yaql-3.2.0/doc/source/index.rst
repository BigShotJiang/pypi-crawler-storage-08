.. yaql documentation master file, created by
   sphinx-quickstart on Tue Jul  9 22:26:36 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to yaql documentation!
==============================

.. toctree::
   :maxdepth: 2

   readme
   what_is_yaql
   getting_started
   usage

.. toctree::
   :maxdepth: 3

   language_reference
   extending_yaql

.. toctree::

   standard_library

For Contributors
================

* If you are a new contributor to Yaql please refer: :doc:`contributor/contributing`

  .. toctree::
     :hidden:

     contributor/contributing
