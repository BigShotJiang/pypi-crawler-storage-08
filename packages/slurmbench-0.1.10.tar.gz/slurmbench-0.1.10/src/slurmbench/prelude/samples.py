"""Samples prelude."""

# ruff: noqa: PLC0414

# DOCU user can use the sample prelude

from slurmbench.samples.file_system import TSVHeader as TSVHeader
from slurmbench.samples.status import Status as Status
