"""Main entry point for the UniFi MCP server."""

from unifi_mcp.main import main

if __name__ == "__main__":
    main()
