# AppScriptify

A simple Python package that greets you.

## Installation
```bash
pip install appscriptify
