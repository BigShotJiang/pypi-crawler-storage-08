__version__ = "10.6.1"
KPOPS = "KPOps"
KPOPS_MODULE = "kpops."
