from pathlib import Path

RESOURCES_PATH = Path(__file__).parent.parent / "resources"
