# Overview

This section explains the different components of KPOps, their usage and configuration in the pipeline
definition [`pipeline.yaml`](../../../resources/pipeline-components/pipeline.md).

--8<--
./docs/resources/architecture/components-hierarchy.md
--8<--
