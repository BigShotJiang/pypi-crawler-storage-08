# Streams Bootstrap

Subclass of [_HelmApp_](helm-app.md).

### Usage

- Defines a [streams-bootstrap](https://github.com/bakdata/streams-bootstrap){target=_blank} component

- Often used in `defaults.yaml`

### Operations

#### deploy

Deploy using Helm.

#### destroy

Uninstall Helm release.

#### reset

Do nothing.

#### clean

Do nothing.
