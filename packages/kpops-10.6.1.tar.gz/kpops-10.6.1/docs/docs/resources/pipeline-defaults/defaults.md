# defaults.yaml

[:material-download:](./defaults.yaml)

```yaml
--8<--
./docs/resources/pipeline-defaults/defaults.yaml
--8<--
```
