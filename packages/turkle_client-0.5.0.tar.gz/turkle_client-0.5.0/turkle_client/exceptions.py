
class TurkleClientException(Exception):
    """An error occurred in the turkle client."""
