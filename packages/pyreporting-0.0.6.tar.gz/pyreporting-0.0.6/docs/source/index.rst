..
   Note: Items in this toctree form the top-level navigation. See `software_documentation.rst` for the `autosummary` directive, and for why `software_documentation.rst` isn't called directly.

.. toctree::
   :hidden:

   Tutorial <tutorial>
   API reference <_autosummary/pyreporting>


.. include:: readme.md
   :parser: myst_parser.sphinx_
