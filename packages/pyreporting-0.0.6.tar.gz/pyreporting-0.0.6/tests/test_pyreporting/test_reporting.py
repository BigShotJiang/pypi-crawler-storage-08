from pyreporting.reporting import get_reporting


def test_reporting():
    get_reporting()
