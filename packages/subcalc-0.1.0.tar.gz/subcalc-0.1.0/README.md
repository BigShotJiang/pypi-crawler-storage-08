# Subcalc - Subnet Calculator

## Summary

A simple TUI Subnet calculator.

run "subcalc" command to open
