PERMISSIONS_DICT = {
    "role_1": {
        "auth.view_user",
        "auth.add_user",
    },
    "role_2": {},
}

PERMISSIONS_LIST = []
