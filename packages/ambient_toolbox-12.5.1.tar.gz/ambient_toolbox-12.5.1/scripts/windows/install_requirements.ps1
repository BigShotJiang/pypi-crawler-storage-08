pip install -U uv
uv sync --frozen --group dev--group drf--group graphql--group import-linter--group bleacher--group gitlab-coverage--group sentry--group view-layer
