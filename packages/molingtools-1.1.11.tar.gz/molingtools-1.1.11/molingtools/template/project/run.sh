#!/bin/bash

# source .venv/bin/activate
source ~/miniconda3/etc/profile.d/conda.sh
conda activate ./.conda

# uv python main.py
# python main.py