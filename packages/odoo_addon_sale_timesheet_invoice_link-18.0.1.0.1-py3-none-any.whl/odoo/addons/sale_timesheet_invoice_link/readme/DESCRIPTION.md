This module extends the functionality of timesheets to support linking them to
preexisting invoices and to allow you to anticipate invoicing, even before the
work hours are actually done.
