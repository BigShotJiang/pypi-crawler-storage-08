To use this module, you need to:

1. Go to *Timesheets / Timesheets / All Timesheets*.
1. Select the list view.
1. Click on the icon in the top-right corner and display the column *Invoice*.
1. Link the timesheet lines with the invoices you want from the same customer.
