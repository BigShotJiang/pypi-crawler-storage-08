To be able to use this module, you need these permissions:
- *Timesheets / Administrator*.
