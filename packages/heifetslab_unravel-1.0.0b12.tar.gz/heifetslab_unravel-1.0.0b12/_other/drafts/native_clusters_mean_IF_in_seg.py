#!/usr/bin/env python3

"""
For each cluster, load cropped <ochann>, cluster mask, and <*_seg_ilastik_1> and mul together to measure mean IF in segmented voxels

Usage:
------
native_clusters_mean_IF_in_seg.py -c clusters/output_folder -i iba1_rb20_cropped -s iba1_seg_ilastik_1/sample03_iba1_seg_ilastik_1.nii.gz_cropped -o th_seg_ilastik_3 -v

-o glm_iba1_rb20_saline_v_meth_vox_p_tstat1 -cn iba1_rb20 -s iba1_seg_ilastik_1 -v

Run native_clusters_mean_IF_in_seg.py from the experiment directory containing sample?? folders or a sample?? folder.

Version 2 allows for more flexibility (e.g., use seg from one label as a mask for another label), but paths in args more complex.

"""

from pathlib import Path
import re
import numpy as np
from rich import print
from rich.live import Live
from rich.traceback import install

from unravel.core.help_formatter import RichArgumentParser, SuppressMetavar, SM

from unravel.core.config import Configuration
from unravel.core.img_io import load_3D_img
from unravel.core.utils import match_files, print_cmd_and_times, initialize_progress_bar, get_samples


def parse_args():
    parser = RichArgumentParser(formatter_class=SuppressMetavar, add_help=False, docstring=__doc__)

    reqs = parser.add_argument_group('Required arguments')
    reqs.add_argument('-c', '--clusters_dir', help='Path relative to sample?? with cluster data: clusters/<output_dir>', action=SM)
    reqs.add_argument('-i', '--input_dir', help='Dir in <output_dir> with cropped immunofluo images', action=SM)
    reqs.add_argument('-s', '--seg_dir', help='Dir in <output_dir> with cropped segmentation image', action=SM)
    reqs.add_argument('-o', '--out_dir', help='Output dir prefix (e.g., th_seg_ilastik_3)', action=SM)

    general = parser.add_argument_group('General arguments')
    general.add_argument('-p', '--pattern', help='Pattern for folders to process. If no matches, use current dir. Default: sample??', default='sample??', action=SM)
    general.add_argument('--dirs', help='List of folders to process. Overrides --pattern', nargs='*', default=None, action=SM)
    general.add_argument('-v', '--verbose', help='Enable verbose mode', action='store_true')

    return parser.parse_args()

def binarize(array, threshold=0.5):
    return (array > threshold).astype(int)

def main():
    args = parse_args()

    samples = get_samples(args.dirs, args.pattern)

    if samples == ['.']:
        samples[0] = Path.cwd().name

    progress, task_id = initialize_progress_bar(len(samples), "[red]Processing samples...")
    with Live(progress):
        for sample in samples:

            # Resolve path to tif directory
            cwd = Path(".").resolve()

            sample_path = Path(sample).resolve() if sample != cwd.name else Path().resolve()

            # Define input path
            clusters_dir_path = Path(sample_path, args.clusters_dir).resolve()
                
            # Define path to bounding box directory
            bbox_dir = Path(clusters_dir_path, "bounding_boxes")

            # Get cluster IDs
            file_pattern = f"bounding_box_{sample}_cluster_*.txt"
            file_list = match_files([file_pattern], base_path=bbox_dir)
                       
            clusters = [int(re.search(r"cluster_(\d+).txt", file).group(1)) for file in file_list] # Extract cluster IDs
            for cluster in clusters:

                # Load cropped image (e.g., iba1_rb20_cropped)
                cropped_img_path = Path(clusters_dir_path, args.input_dir, f"{sample}_cluster_{cluster}.nii.gz")
                cropped_img = load_3D_img(cropped_img_path, return_res=False, verbose=args.verbose)

                # Load cropped cluster
                cropped_cluster_path = Path(clusters_dir_path, f"clusters_cropped", f"crop_{sample}_native_cluster_{cluster}.nii.gz")
                cropped_cluster_img = load_3D_img(cropped_cluster_path, return_res=False, verbose=args.verbose)

                # Load segmentation (e.g., iba1_seg_ilastik_1/sample03_iba1_seg_ilastik_1.nii.gz_cropped)
                seg_img_path = Path(clusters_dir_path, args.seg_dir, f"{sample}_cluster_{cluster}.nii.gz")
                seg_img = load_3D_img(seg_img_path, return_res=False, verbose=args.verbose)

                # Binarize the arrays
                cropped_cluster_img = binarize(cropped_cluster_img)
                seg_img = binarize(seg_img)

                # Multiply the binarized arrays
                seg_cluster_mask = cropped_cluster_img * seg_img

                # Calculate and save the mean fluo intensity of voxels within the cluster that were segmented
                mean_intensity = np.mean(cropped_img[seg_cluster_mask > 0])

                # Save mean intensity to .txt
                output_dir_path = Path(clusters_dir_path, f"{args.out_dir}_cropped", "3D_counts", f"crop_{args.out_dir}_{sample}_native_cluster_{cluster}_3dc")
                output = Path(output_dir_path,f"crop_{args.out_dir}_{sample}_native_cluster_{cluster}_mean_IF_in_seg.txt") 
                with open(output, 'w') as f:
                    f.write(f"{mean_intensity}")

                # Save image paths to .txt
                output = Path(output_dir_path,f"crop_{args.out_dir}_{sample}_native_cluster_{cluster}_mean_IF_in_seg_parameters.txt") 
                with open(output, 'w') as f:
                    f.write(f"cropped_img_path: {cropped_img_path} \nseg_img_path: {seg_img_path}")

                print(f'\n    Mean {args.input_dir} intensity in {sample} cluster_{cluster} {args.seg_dir}: {mean_intensity}\n')

            progress.update(task_id, advance=1)


if __name__ == '__main__': 
    install()
    args = parse_args()
    Configuration.verbose = args.verbose
    print_cmd_and_times(main)()
