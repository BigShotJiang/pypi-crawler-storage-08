class MagicCommandException(Exception):
    pass
