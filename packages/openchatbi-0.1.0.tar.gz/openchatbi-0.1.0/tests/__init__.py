"""Test package for OpenChatBI."""
