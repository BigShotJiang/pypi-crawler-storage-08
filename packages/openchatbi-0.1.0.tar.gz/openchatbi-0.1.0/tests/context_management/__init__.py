"""Context management test package."""

# Test package initialization
