"""Utility to transfer data from MySQL to SQLite 3."""

__version__ = "2.5.0"

from .transporter import MySQLtoSQLite
