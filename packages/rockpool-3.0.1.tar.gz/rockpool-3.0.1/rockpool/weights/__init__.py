"""
Defines functions for generating recurrent weight matrices
"""

from .reservoirweights import *
