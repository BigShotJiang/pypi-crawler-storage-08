"""
Contains packages for assisting with NN training
"""
