"""
The current version of rockpool

Access the rockpool version with ``rockpool.__version__``.
"""

__all__ = ["__version__"]

__version__ = "3.0.1"
