"""
Dynap-SE high level property conversion and computation utility class implementations

* Non User Facing *
"""

from ._time import *
from ._gain import *
