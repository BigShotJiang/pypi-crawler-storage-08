"""
Implements the :py:class:`.Quantizer` module, a helper module for Xylo IMU
"""

from .quantizer import *
