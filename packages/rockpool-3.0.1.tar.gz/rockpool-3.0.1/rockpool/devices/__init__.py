"""
Package collecting facilities for HW device support
"""
