## Where are the images?

The images for all odoo versions from 8 to 16 version community are hosted in [docker](https://registry.hub.docker.com/r/jobiols/odoo-jeo/tags)

And the dockerfiles to create those images are in [github](https://github.com/jobiols/docker-odoo-jeo)

You are encouraged to fork this and make your own images, or to use it freely
