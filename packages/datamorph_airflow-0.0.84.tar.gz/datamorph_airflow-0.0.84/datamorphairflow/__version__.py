"""
Module contains the version of datamorph-airflow,
ChangeLog.md with the release details for the version change needs to be updated
"""
__version__ = "0.0.84"

"""
0.0.83 - loadparams action introduced and updated s3resources to read json file
"""