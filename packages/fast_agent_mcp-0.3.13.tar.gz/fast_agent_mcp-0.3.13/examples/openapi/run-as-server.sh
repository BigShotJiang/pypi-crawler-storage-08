# change model and api keys as needed
uv run agent.py petstore.yaml --model grok-4-fast --server --port 8001



