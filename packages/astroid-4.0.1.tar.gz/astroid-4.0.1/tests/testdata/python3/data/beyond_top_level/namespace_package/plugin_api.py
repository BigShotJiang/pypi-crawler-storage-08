def top_message(msg):
    return "top_message: %s" % msg
