
class Connection:

    def __init__(self, ctx, sock=None):
        print('init Connection')
