import re


class MyModel:
    class_attribute = 1
