/* Copyright (C) The libssh2 project and its contributors.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
#include <inttypes.h>

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size);
