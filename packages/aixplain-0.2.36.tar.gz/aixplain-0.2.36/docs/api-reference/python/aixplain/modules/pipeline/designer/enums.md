---
sidebar_label: enums
title: aixplain.modules.pipeline.designer.enums
---

