---
draft: true
sidebar_label: processes
title: aixplain.processes
---

