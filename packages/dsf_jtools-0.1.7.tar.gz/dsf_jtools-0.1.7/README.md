# JTools: simple tools, easy life


## Building

```cmd

python setup.py sdist bdist_wheel
twine upload dist/*
```

## Logging

+ v0.1.6:
  + fix: trading dates funcs
  + add: is_trading_date