"""Version information for cloudmask."""

__version__ = "0.3.0"
