"""Allow running TripWire CLI as a module via 'python -m tripwire.cli'."""

from tripwire.cli import main

if __name__ == "__main__":
    main()
