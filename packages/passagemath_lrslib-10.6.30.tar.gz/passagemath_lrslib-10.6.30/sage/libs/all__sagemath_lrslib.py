# sage_setup: distribution = sagemath-lrslib
