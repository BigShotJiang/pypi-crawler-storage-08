"""TUI widget components."""
