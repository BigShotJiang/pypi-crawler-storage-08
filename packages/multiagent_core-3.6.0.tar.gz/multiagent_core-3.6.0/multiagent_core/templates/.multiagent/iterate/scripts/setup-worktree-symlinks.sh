#!/bin/bash
# Agent Worktree Symlink Setup
# Location: .multiagent/iterate/scripts/setup-worktree-symlinks.sh
# Usage: .multiagent/iterate/scripts/setup-worktree-symlinks.sh <spec-name>
# Example: .multiagent/iterate/scripts/setup-worktree-symlinks.sh 005-documentation-management-system

set -e

SPEC_NAME="$1"

if [[ -z "$SPEC_NAME" ]]; then
    echo "Usage: setup-worktree-symlinks.sh <spec-name>"
    echo "Example: setup-worktree-symlinks.sh 005-documentation-management-system"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Script is at: .multiagent/iterate/scripts/setup-worktree-symlinks.sh
# Go up three levels to get repo root (either main or worktree)
REPO_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"

# Main repo is typically named "multiagent-core"
# If we're in a worktree, we need to go to the actual main repo
if [[ "$(basename "$REPO_ROOT")" == "multiagent-core" ]]; then
    # We're in main repo
    MAIN_REPO_PATH="$REPO_ROOT"
else
    # We're in a worktree (project-codex, project-qwen, etc)
    # Main repo is sibling directory named multiagent-core
    MAIN_REPO_PATH="$(cd "$REPO_ROOT/../multiagent-core" && pwd)"
fi

MAIN_LAYERED_TASKS="$MAIN_REPO_PATH/specs/$SPEC_NAME/agent-tasks/layered-tasks.md"

# Create symlink in worktree's spec directory
SPEC_DIR="$REPO_ROOT/specs/$SPEC_NAME"
WORKTREE_LINK="$SPEC_DIR/layered-tasks-main.md"

echo "🔗 Setting up worktree symlink for task visibility..."
echo "   Main repo: $MAIN_REPO_PATH"
echo "   Spec: $SPEC_NAME"

if [[ ! -f "$MAIN_LAYERED_TASKS" ]]; then
    echo "❌ ERROR: Main layered-tasks.md not found at: $MAIN_LAYERED_TASKS"
    echo "   Make sure you're running this from an agent worktree"
    exit 1
fi

# Create symlink
ln -sf "$MAIN_LAYERED_TASKS" "$WORKTREE_LINK"

echo "✅ Symlink created successfully!"
echo "   Link: $WORKTREE_LINK"
echo "   Target: $MAIN_LAYERED_TASKS"
echo ""
echo "📋 Now you can:"
echo "   - Check off tasks in your worktree"
echo "   - Updates visible in main repo instantly"
echo "   - Monitor progress: cat layered-tasks-main.md"