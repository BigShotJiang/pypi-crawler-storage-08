"""rslearn training tasks."""

from .task import Task

__all__ = ("Task",)
