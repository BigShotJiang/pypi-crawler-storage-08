"""Model registry."""

from class_registry import ClassRegistry

Models = ClassRegistry()
