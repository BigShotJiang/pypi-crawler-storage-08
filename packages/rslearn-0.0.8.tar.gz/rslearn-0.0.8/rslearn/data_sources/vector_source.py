"""Placeholder for a vector data source."""
