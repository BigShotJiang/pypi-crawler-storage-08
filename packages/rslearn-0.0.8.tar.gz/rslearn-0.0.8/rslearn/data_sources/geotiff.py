"""Placeholder for a GeoTIFF data source."""
