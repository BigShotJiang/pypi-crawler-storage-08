"""Python unit tests for jupyter_ai_persona_manager."""
