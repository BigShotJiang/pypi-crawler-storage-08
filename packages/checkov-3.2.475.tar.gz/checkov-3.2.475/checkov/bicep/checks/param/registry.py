from checkov.bicep.checks.param.base_registry import Registry

registry = Registry()
