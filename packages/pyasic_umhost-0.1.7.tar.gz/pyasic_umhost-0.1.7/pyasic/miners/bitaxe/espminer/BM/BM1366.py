from pyasic.miners.backends.bitaxe import BitAxe
from pyasic.miners.device.models.bitaxe import Ultra


class BitAxeUltra(BitAxe, Ultra):
    pass
