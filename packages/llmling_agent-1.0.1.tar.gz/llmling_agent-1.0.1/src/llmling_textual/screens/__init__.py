"""Package containing various screens for the textual application."""
