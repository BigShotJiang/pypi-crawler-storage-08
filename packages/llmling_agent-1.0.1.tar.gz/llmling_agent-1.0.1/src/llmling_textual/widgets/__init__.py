"""Package containing various widgets for the textual application."""
