

class WrongParamException(Exception):
    pass

class WrongTypeException(Exception):
    pass

class NoAgentAvailableException(Exception):
    pass

class NoSuchEquationException(Exception):
    pass

class NoDataProducedException(Exception):
    pass