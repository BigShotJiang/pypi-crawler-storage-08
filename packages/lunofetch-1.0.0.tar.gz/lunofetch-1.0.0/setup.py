from setuptools import setup, find_packages

setup(
    name='lunofetch',
    version='1.0.0',
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'lunofetch = lunofetch.__main__:main'
        ]
    },
    install_requires=['psutil', 'distro'],
    description='Custom Neofetch-like system info tool',
    author='B. Tharun Bala',
    license='MIT',
)

