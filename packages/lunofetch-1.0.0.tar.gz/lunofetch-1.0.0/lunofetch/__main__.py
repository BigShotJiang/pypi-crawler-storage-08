from lunofetch import main
main()

