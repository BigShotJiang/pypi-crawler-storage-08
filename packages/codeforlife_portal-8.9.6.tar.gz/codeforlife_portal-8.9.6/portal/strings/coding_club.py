CODING_CLUB_BANNER = {
    "title": "Coding clubs",
    "subtitle": "A FREE set of slides and guides to run your own coding clubs",
    "text": "",
    "button": "",
    "image_class": "banner--picture--coding-club",
    "alt": "Boy using a laptop",
    "image_description": "Credit: Jeswin Thomas, Unsplash",
}
