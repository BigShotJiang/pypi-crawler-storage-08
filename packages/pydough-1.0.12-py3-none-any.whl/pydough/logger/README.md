# Logger

This directory of PyDough deals with logger utilities.

## Available APIs

- `get_logger`: The main function to get a logger as defined in `./logger.py`. You can find more details at [Logging Documentation](../../documentation/usage.md#logging)