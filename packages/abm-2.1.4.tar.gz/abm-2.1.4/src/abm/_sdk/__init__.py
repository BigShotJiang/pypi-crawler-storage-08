from .client_interface import Client

client = Client()
