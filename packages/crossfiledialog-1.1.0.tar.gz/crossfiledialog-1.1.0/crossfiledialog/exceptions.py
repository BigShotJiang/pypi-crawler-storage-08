class FileDialogException(Exception):
    pass


class NoImplementationFoundException(FileDialogException):
    pass
