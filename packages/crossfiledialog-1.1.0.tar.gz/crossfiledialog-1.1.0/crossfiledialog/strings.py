open_file = 'Choose a file'
open_multiple = 'Choose one or more files'
save_file = 'Enter the name of the file to save to'
choose_folder = 'Choose a folder'
