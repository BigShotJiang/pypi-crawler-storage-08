"""Version information for gac package."""

__version__ = "1.5.2"
