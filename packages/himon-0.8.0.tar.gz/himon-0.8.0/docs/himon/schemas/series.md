# Series

::: himon.schemas.series.Series
