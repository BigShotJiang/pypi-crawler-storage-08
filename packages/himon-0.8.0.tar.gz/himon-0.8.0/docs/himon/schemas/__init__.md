# Package Contents

::: himon.schemas.BaseModel
