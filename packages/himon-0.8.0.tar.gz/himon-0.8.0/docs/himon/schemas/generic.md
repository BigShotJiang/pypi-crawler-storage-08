# Generic

::: himon.schemas.generic.ComicFormat
::: himon.schemas.generic.CoverType
::: himon.schemas.generic.GenericComic
::: himon.schemas.generic.GenericCover
