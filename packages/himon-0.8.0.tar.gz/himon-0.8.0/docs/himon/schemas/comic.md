# Comic

::: himon.schemas.comic.Character
::: himon.schemas.comic.CharacterType
::: himon.schemas.comic.Comic
::: himon.schemas.comic.Creator
::: himon.schemas.comic.KeyEvent
::: himon.schemas.comic.KeyEventType
::: himon.schemas.comic.Variant
