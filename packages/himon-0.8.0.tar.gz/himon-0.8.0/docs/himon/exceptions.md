# Exceptions

::: himon.exceptions.AuthenticationError
::: himon.exceptions.RateLimitError
::: himon.exceptions.ServiceError
