"""Chapter management system for Phase 3."""

from .chapter_manager import ChapterManager, ChapterInfo

__all__ = ['ChapterManager', 'ChapterInfo']