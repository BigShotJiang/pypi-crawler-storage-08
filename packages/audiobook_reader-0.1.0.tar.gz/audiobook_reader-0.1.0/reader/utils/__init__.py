"""Utility functions for the reader package."""
