# exosims-plugins
A set of plugin modules I've created for EXOSIMS that for one reason or another don't belong in the core EXOSIMS repository
