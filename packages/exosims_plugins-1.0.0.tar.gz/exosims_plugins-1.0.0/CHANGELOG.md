# Changelog

## 1.0.0 (2025-10-07)


### Features

* Full implementation of orbix modules ([18450cb](https://github.com/CoreySpohn/exosims-plugins/commit/18450cb083a4d8d93f267d7f15923f3ec433efce))
