from .partial import PartialModelMixin as PartialModelMixin
from .partial import create_partial_model as create_partial_model
