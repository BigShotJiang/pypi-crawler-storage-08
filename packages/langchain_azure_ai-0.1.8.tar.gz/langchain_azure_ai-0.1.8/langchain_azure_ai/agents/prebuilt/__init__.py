"""Prebuilt agents for Azure AI Foundry."""

from langchain_azure_ai.agents.prebuilt.declarative import DeclarativeChatAgentNode

__all__ = ["DeclarativeChatAgentNode"]
