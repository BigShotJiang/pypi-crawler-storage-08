GeoCAT-comp's contributor guidelines [can be found in our online documentation](https://geocat-comp.readthedocs.io/en/stable/contrib.html).
