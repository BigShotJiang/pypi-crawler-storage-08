# How to install GeoCAT-comp

Please see our [GeoCAT-comp Installation](https://geocat-comp.readthedocs.io/en/latest/installation.html)
instructions for detailed information!
