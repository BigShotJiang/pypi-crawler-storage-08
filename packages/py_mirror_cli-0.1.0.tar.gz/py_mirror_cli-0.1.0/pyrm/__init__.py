"""pyrm - Python pip 镜像源管理工具"""

__version__ = "0.1.0"
__author__ = "Your Name"
__description__ = "Python pip 镜像源管理工具，类似 nrm"

