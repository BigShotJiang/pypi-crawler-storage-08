from enum import Enum


class CommissionType(Enum):
    PERCENTAGE = 0
    CASH = 1