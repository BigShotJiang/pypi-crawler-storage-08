#include "../../munit/munit.h"

MunitSuite* simde_tests_arm_sve_get_suite(void);
