#include "../../munit/munit.h"

MunitSuite* simde_tests_wasm_relaxed_simd_get_suite(void);
