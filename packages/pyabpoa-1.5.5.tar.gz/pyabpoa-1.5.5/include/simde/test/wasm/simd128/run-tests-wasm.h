#include "../../munit/munit.h"

MunitSuite* simde_tests_wasm_simd128_get_suite(void);
