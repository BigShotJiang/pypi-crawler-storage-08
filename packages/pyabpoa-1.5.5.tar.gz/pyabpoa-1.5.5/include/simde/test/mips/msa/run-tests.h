#if defined(SIMDE_TESTS_MIPS_MSA_RUN_TESTS_H)
  #error File already included.
#endif
#define SIMDE_TESTS_MIPS_MSA_RUN_TESTS_H

#include "../../munit/munit.h"

MunitSuite* simde_tests_mips_msa_get_suite(void);
