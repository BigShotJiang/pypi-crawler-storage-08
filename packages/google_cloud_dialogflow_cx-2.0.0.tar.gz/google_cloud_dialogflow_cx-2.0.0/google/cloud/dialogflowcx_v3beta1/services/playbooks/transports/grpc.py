# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import json
import logging as std_logging
import pickle
from typing import Callable, Dict, Optional, Sequence, Tuple, Union
import warnings

from google.api_core import gapic_v1, grpc_helpers, operations_v1
import google.auth  # type: ignore
from google.auth import credentials as ga_credentials  # type: ignore
from google.auth.transport.grpc import SslCredentials  # type: ignore
from google.cloud.location import locations_pb2  # type: ignore
from google.longrunning import operations_pb2  # type: ignore
from google.protobuf import empty_pb2  # type: ignore
from google.protobuf.json_format import MessageToJson
import google.protobuf.message
import grpc  # type: ignore
import proto  # type: ignore

from google.cloud.dialogflowcx_v3beta1.types import playbook
from google.cloud.dialogflowcx_v3beta1.types import playbook as gcdc_playbook

from .base import DEFAULT_CLIENT_INFO, PlaybooksTransport

try:
    from google.api_core import client_logging  # type: ignore

    CLIENT_LOGGING_SUPPORTED = True  # pragma: NO COVER
except ImportError:  # pragma: NO COVER
    CLIENT_LOGGING_SUPPORTED = False

_LOGGER = std_logging.getLogger(__name__)


class _LoggingClientInterceptor(grpc.UnaryUnaryClientInterceptor):  # pragma: NO COVER
    def intercept_unary_unary(self, continuation, client_call_details, request):
        logging_enabled = CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(
            std_logging.DEBUG
        )
        if logging_enabled:  # pragma: NO COVER
            request_metadata = client_call_details.metadata
            if isinstance(request, proto.Message):
                request_payload = type(request).to_json(request)
            elif isinstance(request, google.protobuf.message.Message):
                request_payload = MessageToJson(request)
            else:
                request_payload = f"{type(request).__name__}: {pickle.dumps(request)}"

            request_metadata = {
                key: value.decode("utf-8") if isinstance(value, bytes) else value
                for key, value in request_metadata
            }
            grpc_request = {
                "payload": request_payload,
                "requestMethod": "grpc",
                "metadata": dict(request_metadata),
            }
            _LOGGER.debug(
                f"Sending request for {client_call_details.method}",
                extra={
                    "serviceName": "google.cloud.dialogflow.cx.v3beta1.Playbooks",
                    "rpcName": str(client_call_details.method),
                    "request": grpc_request,
                    "metadata": grpc_request["metadata"],
                },
            )
        response = continuation(client_call_details, request)
        if logging_enabled:  # pragma: NO COVER
            response_metadata = response.trailing_metadata()
            # Convert gRPC metadata `<class 'grpc.aio._metadata.Metadata'>` to list of tuples
            metadata = (
                dict([(k, str(v)) for k, v in response_metadata])
                if response_metadata
                else None
            )
            result = response.result()
            if isinstance(result, proto.Message):
                response_payload = type(result).to_json(result)
            elif isinstance(result, google.protobuf.message.Message):
                response_payload = MessageToJson(result)
            else:
                response_payload = f"{type(result).__name__}: {pickle.dumps(result)}"
            grpc_response = {
                "payload": response_payload,
                "metadata": metadata,
                "status": "OK",
            }
            _LOGGER.debug(
                f"Received response for {client_call_details.method}.",
                extra={
                    "serviceName": "google.cloud.dialogflow.cx.v3beta1.Playbooks",
                    "rpcName": client_call_details.method,
                    "response": grpc_response,
                    "metadata": grpc_response["metadata"],
                },
            )
        return response


class PlaybooksGrpcTransport(PlaybooksTransport):
    """gRPC backend transport for Playbooks.

    Service for managing
    [Playbooks][google.cloud.dialogflow.cx.v3beta1.Playbook].

    This class defines the same methods as the primary client, so the
    primary client can load the underlying transport implementation
    and call it.

    It sends protocol buffers over the wire using gRPC (which is built on
    top of HTTP/2); the ``grpcio`` package must be installed.
    """

    _stubs: Dict[str, Callable]

    def __init__(
        self,
        *,
        host: str = "dialogflow.googleapis.com",
        credentials: Optional[ga_credentials.Credentials] = None,
        credentials_file: Optional[str] = None,
        scopes: Optional[Sequence[str]] = None,
        channel: Optional[Union[grpc.Channel, Callable[..., grpc.Channel]]] = None,
        api_mtls_endpoint: Optional[str] = None,
        client_cert_source: Optional[Callable[[], Tuple[bytes, bytes]]] = None,
        ssl_channel_credentials: Optional[grpc.ChannelCredentials] = None,
        client_cert_source_for_mtls: Optional[Callable[[], Tuple[bytes, bytes]]] = None,
        quota_project_id: Optional[str] = None,
        client_info: gapic_v1.client_info.ClientInfo = DEFAULT_CLIENT_INFO,
        always_use_jwt_access: Optional[bool] = False,
        api_audience: Optional[str] = None,
    ) -> None:
        """Instantiate the transport.

        Args:
            host (Optional[str]):
                 The hostname to connect to (default: 'dialogflow.googleapis.com').
            credentials (Optional[google.auth.credentials.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify the application to the service; if none
                are specified, the client will attempt to ascertain the
                credentials from the environment.
                This argument is ignored if a ``channel`` instance is provided.
            credentials_file (Optional[str]): Deprecated. A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`.
                This argument is ignored if a ``channel`` instance is provided.
                This argument will be removed in the next major version of this library.
            scopes (Optional(Sequence[str])): A list of scopes. This argument is
                ignored if a ``channel`` instance is provided.
            channel (Optional[Union[grpc.Channel, Callable[..., grpc.Channel]]]):
                A ``Channel`` instance through which to make calls, or a Callable
                that constructs and returns one. If set to None, ``self.create_channel``
                is used to create the channel. If a Callable is given, it will be called
                with the same arguments as used in ``self.create_channel``.
            api_mtls_endpoint (Optional[str]): Deprecated. The mutual TLS endpoint.
                If provided, it overrides the ``host`` argument and tries to create
                a mutual TLS channel with client SSL credentials from
                ``client_cert_source`` or application default SSL credentials.
            client_cert_source (Optional[Callable[[], Tuple[bytes, bytes]]]):
                Deprecated. A callback to provide client SSL certificate bytes and
                private key bytes, both in PEM format. It is ignored if
                ``api_mtls_endpoint`` is None.
            ssl_channel_credentials (grpc.ChannelCredentials): SSL credentials
                for the grpc channel. It is ignored if a ``channel`` instance is provided.
            client_cert_source_for_mtls (Optional[Callable[[], Tuple[bytes, bytes]]]):
                A callback to provide client certificate bytes and private key bytes,
                both in PEM format. It is used to configure a mutual TLS channel. It is
                ignored if a ``channel`` instance or ``ssl_channel_credentials`` is provided.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            client_info (google.api_core.gapic_v1.client_info.ClientInfo):
                The client info used to send a user-agent string along with
                API requests. If ``None``, then default info will be used.
                Generally, you only need to set this if you're developing
                your own client library.
            always_use_jwt_access (Optional[bool]): Whether self signed JWT should
                be used for service account credentials.

        Raises:
          google.auth.exceptions.MutualTLSChannelError: If mutual TLS transport
              creation failed for any reason.
          google.api_core.exceptions.DuplicateCredentialArgs: If both ``credentials``
              and ``credentials_file`` are passed.
        """
        self._grpc_channel = None
        self._ssl_channel_credentials = ssl_channel_credentials
        self._stubs: Dict[str, Callable] = {}
        self._operations_client: Optional[operations_v1.OperationsClient] = None

        if api_mtls_endpoint:
            warnings.warn("api_mtls_endpoint is deprecated", DeprecationWarning)
        if client_cert_source:
            warnings.warn("client_cert_source is deprecated", DeprecationWarning)

        if isinstance(channel, grpc.Channel):
            # Ignore credentials if a channel was passed.
            credentials = None
            self._ignore_credentials = True
            # If a channel was explicitly provided, set it.
            self._grpc_channel = channel
            self._ssl_channel_credentials = None

        else:
            if api_mtls_endpoint:
                host = api_mtls_endpoint

                # Create SSL credentials with client_cert_source or application
                # default SSL credentials.
                if client_cert_source:
                    cert, key = client_cert_source()
                    self._ssl_channel_credentials = grpc.ssl_channel_credentials(
                        certificate_chain=cert, private_key=key
                    )
                else:
                    self._ssl_channel_credentials = SslCredentials().ssl_credentials

            else:
                if client_cert_source_for_mtls and not ssl_channel_credentials:
                    cert, key = client_cert_source_for_mtls()
                    self._ssl_channel_credentials = grpc.ssl_channel_credentials(
                        certificate_chain=cert, private_key=key
                    )

        # The base transport sets the host, credentials and scopes
        super().__init__(
            host=host,
            credentials=credentials,
            credentials_file=credentials_file,
            scopes=scopes,
            quota_project_id=quota_project_id,
            client_info=client_info,
            always_use_jwt_access=always_use_jwt_access,
            api_audience=api_audience,
        )

        if not self._grpc_channel:
            # initialize with the provided callable or the default channel
            channel_init = channel or type(self).create_channel
            self._grpc_channel = channel_init(
                self._host,
                # use the credentials which are saved
                credentials=self._credentials,
                # Set ``credentials_file`` to ``None`` here as
                # the credentials that we saved earlier should be used.
                credentials_file=None,
                scopes=self._scopes,
                ssl_credentials=self._ssl_channel_credentials,
                quota_project_id=quota_project_id,
                options=[
                    ("grpc.max_send_message_length", -1),
                    ("grpc.max_receive_message_length", -1),
                ],
            )

        self._interceptor = _LoggingClientInterceptor()
        self._logged_channel = grpc.intercept_channel(
            self._grpc_channel, self._interceptor
        )

        # Wrap messages. This must be done after self._logged_channel exists
        self._prep_wrapped_messages(client_info)

    @classmethod
    def create_channel(
        cls,
        host: str = "dialogflow.googleapis.com",
        credentials: Optional[ga_credentials.Credentials] = None,
        credentials_file: Optional[str] = None,
        scopes: Optional[Sequence[str]] = None,
        quota_project_id: Optional[str] = None,
        **kwargs,
    ) -> grpc.Channel:
        """Create and return a gRPC channel object.
        Args:
            host (Optional[str]): The host for the channel to use.
            credentials (Optional[~.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify this application to the service. If
                none are specified, the client will attempt to ascertain
                the credentials from the environment.
            credentials_file (Optional[str]): Deprecated. A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`.
                This argument is mutually exclusive with credentials.  This argument will be
                removed in the next major version of this library.
            scopes (Optional[Sequence[str]]): A optional list of scopes needed for this
                service. These are only used when credentials are not specified and
                are passed to :func:`google.auth.default`.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            kwargs (Optional[dict]): Keyword arguments, which are passed to the
                channel creation.
        Returns:
            grpc.Channel: A gRPC channel object.

        Raises:
            google.api_core.exceptions.DuplicateCredentialArgs: If both ``credentials``
              and ``credentials_file`` are passed.
        """

        return grpc_helpers.create_channel(
            host,
            credentials=credentials,
            credentials_file=credentials_file,
            quota_project_id=quota_project_id,
            default_scopes=cls.AUTH_SCOPES,
            scopes=scopes,
            default_host=cls.DEFAULT_HOST,
            **kwargs,
        )

    @property
    def grpc_channel(self) -> grpc.Channel:
        """Return the channel designed to connect to this service."""
        return self._grpc_channel

    @property
    def operations_client(self) -> operations_v1.OperationsClient:
        """Create the client designed to process long-running operations.

        This property caches on the instance; repeated calls return the same
        client.
        """
        # Quick check: Only create a new client if we do not already have one.
        if self._operations_client is None:
            self._operations_client = operations_v1.OperationsClient(
                self._logged_channel
            )

        # Return the client from cache.
        return self._operations_client

    @property
    def create_playbook(
        self,
    ) -> Callable[[gcdc_playbook.CreatePlaybookRequest], gcdc_playbook.Playbook]:
        r"""Return a callable for the create playbook method over gRPC.

        Creates a playbook in a specified agent.

        Returns:
            Callable[[~.CreatePlaybookRequest],
                    ~.Playbook]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "create_playbook" not in self._stubs:
            self._stubs["create_playbook"] = self._logged_channel.unary_unary(
                "/google.cloud.dialogflow.cx.v3beta1.Playbooks/CreatePlaybook",
                request_serializer=gcdc_playbook.CreatePlaybookRequest.serialize,
                response_deserializer=gcdc_playbook.Playbook.deserialize,
            )
        return self._stubs["create_playbook"]

    @property
    def delete_playbook(
        self,
    ) -> Callable[[playbook.DeletePlaybookRequest], empty_pb2.Empty]:
        r"""Return a callable for the delete playbook method over gRPC.

        Deletes a specified playbook.

        Returns:
            Callable[[~.DeletePlaybookRequest],
                    ~.Empty]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "delete_playbook" not in self._stubs:
            self._stubs["delete_playbook"] = self._logged_channel.unary_unary(
                "/google.cloud.dialogflow.cx.v3beta1.Playbooks/DeletePlaybook",
                request_serializer=playbook.DeletePlaybookRequest.serialize,
                response_deserializer=empty_pb2.Empty.FromString,
            )
        return self._stubs["delete_playbook"]

    @property
    def list_playbooks(
        self,
    ) -> Callable[[playbook.ListPlaybooksRequest], playbook.ListPlaybooksResponse]:
        r"""Return a callable for the list playbooks method over gRPC.

        Returns a list of playbooks in the specified agent.

        Returns:
            Callable[[~.ListPlaybooksRequest],
                    ~.ListPlaybooksResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "list_playbooks" not in self._stubs:
            self._stubs["list_playbooks"] = self._logged_channel.unary_unary(
                "/google.cloud.dialogflow.cx.v3beta1.Playbooks/ListPlaybooks",
                request_serializer=playbook.ListPlaybooksRequest.serialize,
                response_deserializer=playbook.ListPlaybooksResponse.deserialize,
            )
        return self._stubs["list_playbooks"]

    @property
    def get_playbook(
        self,
    ) -> Callable[[playbook.GetPlaybookRequest], playbook.Playbook]:
        r"""Return a callable for the get playbook method over gRPC.

        Retrieves the specified Playbook.

        Returns:
            Callable[[~.GetPlaybookRequest],
                    ~.Playbook]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "get_playbook" not in self._stubs:
            self._stubs["get_playbook"] = self._logged_channel.unary_unary(
                "/google.cloud.dialogflow.cx.v3beta1.Playbooks/GetPlaybook",
                request_serializer=playbook.GetPlaybookRequest.serialize,
                response_deserializer=playbook.Playbook.deserialize,
            )
        return self._stubs["get_playbook"]

    @property
    def export_playbook(
        self,
    ) -> Callable[[playbook.ExportPlaybookRequest], operations_pb2.Operation]:
        r"""Return a callable for the export playbook method over gRPC.

        Exports the specified playbook to a binary file.

        Note that resources (e.g. examples, tools) that the
        playbook references will also be exported.

        Returns:
            Callable[[~.ExportPlaybookRequest],
                    ~.Operation]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "export_playbook" not in self._stubs:
            self._stubs["export_playbook"] = self._logged_channel.unary_unary(
                "/google.cloud.dialogflow.cx.v3beta1.Playbooks/ExportPlaybook",
                request_serializer=playbook.ExportPlaybookRequest.serialize,
                response_deserializer=operations_pb2.Operation.FromString,
            )
        return self._stubs["export_playbook"]

    @property
    def import_playbook(
        self,
    ) -> Callable[[playbook.ImportPlaybookRequest], operations_pb2.Operation]:
        r"""Return a callable for the import playbook method over gRPC.

        Imports the specified playbook to the specified agent
        from a binary file.

        Returns:
            Callable[[~.ImportPlaybookRequest],
                    ~.Operation]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "import_playbook" not in self._stubs:
            self._stubs["import_playbook"] = self._logged_channel.unary_unary(
                "/google.cloud.dialogflow.cx.v3beta1.Playbooks/ImportPlaybook",
                request_serializer=playbook.ImportPlaybookRequest.serialize,
                response_deserializer=operations_pb2.Operation.FromString,
            )
        return self._stubs["import_playbook"]

    @property
    def update_playbook(
        self,
    ) -> Callable[[gcdc_playbook.UpdatePlaybookRequest], gcdc_playbook.Playbook]:
        r"""Return a callable for the update playbook method over gRPC.

        Updates the specified Playbook.

        Returns:
            Callable[[~.UpdatePlaybookRequest],
                    ~.Playbook]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "update_playbook" not in self._stubs:
            self._stubs["update_playbook"] = self._logged_channel.unary_unary(
                "/google.cloud.dialogflow.cx.v3beta1.Playbooks/UpdatePlaybook",
                request_serializer=gcdc_playbook.UpdatePlaybookRequest.serialize,
                response_deserializer=gcdc_playbook.Playbook.deserialize,
            )
        return self._stubs["update_playbook"]

    @property
    def create_playbook_version(
        self,
    ) -> Callable[[playbook.CreatePlaybookVersionRequest], playbook.PlaybookVersion]:
        r"""Return a callable for the create playbook version method over gRPC.

        Creates a version for the specified Playbook.

        Returns:
            Callable[[~.CreatePlaybookVersionRequest],
                    ~.PlaybookVersion]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "create_playbook_version" not in self._stubs:
            self._stubs["create_playbook_version"] = self._logged_channel.unary_unary(
                "/google.cloud.dialogflow.cx.v3beta1.Playbooks/CreatePlaybookVersion",
                request_serializer=playbook.CreatePlaybookVersionRequest.serialize,
                response_deserializer=playbook.PlaybookVersion.deserialize,
            )
        return self._stubs["create_playbook_version"]

    @property
    def get_playbook_version(
        self,
    ) -> Callable[[playbook.GetPlaybookVersionRequest], playbook.PlaybookVersion]:
        r"""Return a callable for the get playbook version method over gRPC.

        Retrieves the specified version of the Playbook.

        Returns:
            Callable[[~.GetPlaybookVersionRequest],
                    ~.PlaybookVersion]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "get_playbook_version" not in self._stubs:
            self._stubs["get_playbook_version"] = self._logged_channel.unary_unary(
                "/google.cloud.dialogflow.cx.v3beta1.Playbooks/GetPlaybookVersion",
                request_serializer=playbook.GetPlaybookVersionRequest.serialize,
                response_deserializer=playbook.PlaybookVersion.deserialize,
            )
        return self._stubs["get_playbook_version"]

    @property
    def restore_playbook_version(
        self,
    ) -> Callable[
        [playbook.RestorePlaybookVersionRequest],
        playbook.RestorePlaybookVersionResponse,
    ]:
        r"""Return a callable for the restore playbook version method over gRPC.

        Retrieves the specified version of the Playbook and
        stores it as the current playbook draft, returning the
        playbook with resources updated.

        Returns:
            Callable[[~.RestorePlaybookVersionRequest],
                    ~.RestorePlaybookVersionResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "restore_playbook_version" not in self._stubs:
            self._stubs["restore_playbook_version"] = self._logged_channel.unary_unary(
                "/google.cloud.dialogflow.cx.v3beta1.Playbooks/RestorePlaybookVersion",
                request_serializer=playbook.RestorePlaybookVersionRequest.serialize,
                response_deserializer=playbook.RestorePlaybookVersionResponse.deserialize,
            )
        return self._stubs["restore_playbook_version"]

    @property
    def list_playbook_versions(
        self,
    ) -> Callable[
        [playbook.ListPlaybookVersionsRequest], playbook.ListPlaybookVersionsResponse
    ]:
        r"""Return a callable for the list playbook versions method over gRPC.

        Lists versions for the specified Playbook.

        Returns:
            Callable[[~.ListPlaybookVersionsRequest],
                    ~.ListPlaybookVersionsResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "list_playbook_versions" not in self._stubs:
            self._stubs["list_playbook_versions"] = self._logged_channel.unary_unary(
                "/google.cloud.dialogflow.cx.v3beta1.Playbooks/ListPlaybookVersions",
                request_serializer=playbook.ListPlaybookVersionsRequest.serialize,
                response_deserializer=playbook.ListPlaybookVersionsResponse.deserialize,
            )
        return self._stubs["list_playbook_versions"]

    @property
    def delete_playbook_version(
        self,
    ) -> Callable[[playbook.DeletePlaybookVersionRequest], empty_pb2.Empty]:
        r"""Return a callable for the delete playbook version method over gRPC.

        Deletes the specified version of the Playbook.

        Returns:
            Callable[[~.DeletePlaybookVersionRequest],
                    ~.Empty]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "delete_playbook_version" not in self._stubs:
            self._stubs["delete_playbook_version"] = self._logged_channel.unary_unary(
                "/google.cloud.dialogflow.cx.v3beta1.Playbooks/DeletePlaybookVersion",
                request_serializer=playbook.DeletePlaybookVersionRequest.serialize,
                response_deserializer=empty_pb2.Empty.FromString,
            )
        return self._stubs["delete_playbook_version"]

    def close(self):
        self._logged_channel.close()

    @property
    def cancel_operation(
        self,
    ) -> Callable[[operations_pb2.CancelOperationRequest], None]:
        r"""Return a callable for the cancel_operation method over gRPC."""
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "cancel_operation" not in self._stubs:
            self._stubs["cancel_operation"] = self._logged_channel.unary_unary(
                "/google.longrunning.Operations/CancelOperation",
                request_serializer=operations_pb2.CancelOperationRequest.SerializeToString,
                response_deserializer=None,
            )
        return self._stubs["cancel_operation"]

    @property
    def get_operation(
        self,
    ) -> Callable[[operations_pb2.GetOperationRequest], operations_pb2.Operation]:
        r"""Return a callable for the get_operation method over gRPC."""
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "get_operation" not in self._stubs:
            self._stubs["get_operation"] = self._logged_channel.unary_unary(
                "/google.longrunning.Operations/GetOperation",
                request_serializer=operations_pb2.GetOperationRequest.SerializeToString,
                response_deserializer=operations_pb2.Operation.FromString,
            )
        return self._stubs["get_operation"]

    @property
    def list_operations(
        self,
    ) -> Callable[
        [operations_pb2.ListOperationsRequest], operations_pb2.ListOperationsResponse
    ]:
        r"""Return a callable for the list_operations method over gRPC."""
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "list_operations" not in self._stubs:
            self._stubs["list_operations"] = self._logged_channel.unary_unary(
                "/google.longrunning.Operations/ListOperations",
                request_serializer=operations_pb2.ListOperationsRequest.SerializeToString,
                response_deserializer=operations_pb2.ListOperationsResponse.FromString,
            )
        return self._stubs["list_operations"]

    @property
    def list_locations(
        self,
    ) -> Callable[
        [locations_pb2.ListLocationsRequest], locations_pb2.ListLocationsResponse
    ]:
        r"""Return a callable for the list locations method over gRPC."""
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "list_locations" not in self._stubs:
            self._stubs["list_locations"] = self._logged_channel.unary_unary(
                "/google.cloud.location.Locations/ListLocations",
                request_serializer=locations_pb2.ListLocationsRequest.SerializeToString,
                response_deserializer=locations_pb2.ListLocationsResponse.FromString,
            )
        return self._stubs["list_locations"]

    @property
    def get_location(
        self,
    ) -> Callable[[locations_pb2.GetLocationRequest], locations_pb2.Location]:
        r"""Return a callable for the list locations method over gRPC."""
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "get_location" not in self._stubs:
            self._stubs["get_location"] = self._logged_channel.unary_unary(
                "/google.cloud.location.Locations/GetLocation",
                request_serializer=locations_pb2.GetLocationRequest.SerializeToString,
                response_deserializer=locations_pb2.Location.FromString,
            )
        return self._stubs["get_location"]

    @property
    def kind(self) -> str:
        return "grpc"


__all__ = ("PlaybooksGrpcTransport",)
