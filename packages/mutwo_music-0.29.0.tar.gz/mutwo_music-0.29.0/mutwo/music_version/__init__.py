MAJOR, MINOR, PATCH = 0, 29, 0

VERSION = f"{MAJOR}.{MINOR}.{PATCH}"
"""The version of the package ``mutwo.music``."""

del MAJOR, MINOR, PATCH
