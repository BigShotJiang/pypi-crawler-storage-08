DEFAULT_LANGUAGE_CODE = "deu-Latn"
"""The default language code for
:class:`mutwo.music_parameters.LanguageBasedLyric`. This has to be supported
by epitran.
"""
