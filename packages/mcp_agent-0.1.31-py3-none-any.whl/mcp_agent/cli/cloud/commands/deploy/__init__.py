"""MCP Agent Cloud deploy command."""

from .main import deploy_config

__all__ = ["deploy_config"]
