"""Logger tail command."""

from .main import tail_logs

__all__ = ["tail_logs"]
