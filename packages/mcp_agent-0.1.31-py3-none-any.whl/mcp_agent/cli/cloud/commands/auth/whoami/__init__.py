"""MCP Agent Cloud whoami command."""

from .main import whoami

__all__ = ["whoami"]
