# OpenSeesPy visualization module

# Copyright (C) 2020-2022 Seweryn Kokot
# Faculty of Civil Engineering and Architecture
# Opole University of Technology, Poland
# License: GNU GPL version 3


