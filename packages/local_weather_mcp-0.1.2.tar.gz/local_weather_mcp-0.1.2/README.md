# Weather MCP

A simple weather MCP for learning

## Features

- Fetches and current weather data

## License

MIT License