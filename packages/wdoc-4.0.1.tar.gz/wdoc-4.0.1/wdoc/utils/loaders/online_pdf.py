from wdoc.utils.loaders.pdf import load_online_pdf
