# WJ = Wowool Json
WJ_ID = "id"
WJ_MIME_TYPE = "mime_type"
WJ_ENCODING = "encoding"
WJ_DATA = "data"
WJ_METADATA = "metadata"
