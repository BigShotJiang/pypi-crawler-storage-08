# Reference

::: imxInsights.file.containerizedImx.imxContainer

::: imxInsights.file.containerizedImx.imxContainerMetadata


::: imxInsights.file.containerizedImx.imxContainerFiles

::: imxInsights.file.containerizedImx.imxDesignCoreFile

::: imxInsights.file.containerizedImx.imxDesignPetalFile

::: imxInsights.file.containerizedImx.imxContainerFile
