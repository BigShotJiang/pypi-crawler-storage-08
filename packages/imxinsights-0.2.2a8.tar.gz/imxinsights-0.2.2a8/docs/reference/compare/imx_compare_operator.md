# Reference


::: imxInsights.compare.custom_operators.diff_shapely


::: imxInsights.compare.custom_operators.diff_refs
