# Reference

::: imxInsights.file.imxFile
