"""Resource modules for Nexus AI SDK."""
