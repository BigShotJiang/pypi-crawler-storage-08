"""Version information for Nexus AI SDK."""

__version__ = "0.2.2"
