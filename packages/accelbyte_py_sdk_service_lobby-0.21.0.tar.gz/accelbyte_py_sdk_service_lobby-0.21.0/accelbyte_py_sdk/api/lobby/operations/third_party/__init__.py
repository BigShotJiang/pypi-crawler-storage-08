# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Lobby Server."""

__version__ = "3.39.0"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .admin_create_third_part_225a9c import AdminCreateThirdPartyConfig
from .admin_delete_third_part_c9d441 import AdminDeleteThirdPartyConfig
from .admin_get_third_party_config import AdminGetThirdPartyConfig
from .admin_update_third_part_9b81f7 import AdminUpdateThirdPartyConfig
