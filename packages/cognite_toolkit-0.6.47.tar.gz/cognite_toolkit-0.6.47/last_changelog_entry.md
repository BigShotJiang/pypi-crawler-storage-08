## cdf 

### Added

- [alpha] (Migration) Adds mapping for CogniteExtractorTimeSeries and
CogniteExtractorFiles. This is deployed when you run `cdf migrate
prepare` and will be available to use in the upcoming improvement of
`cdf migrate timeseries/files`.

## templates

No changes.