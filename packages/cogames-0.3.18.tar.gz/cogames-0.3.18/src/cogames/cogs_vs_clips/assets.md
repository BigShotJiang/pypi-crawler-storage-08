## Resources

- energy
- carbon
- oxygen
- germanium
- silicon

## Gear

- heart

(open to other names if easier to make sprites)

- decoder
- modulator
- resonator
- scrambler

## Stations

- assembler
  - valid protocol
  - inputs available

- resource extractor
  - type (carbon, oxygen, germanium, silicon, energy)
  - depleted
  - ready (vs cooldown. cooldown percentage?)
  - clipped

- chest
  - input and output positions
  - empty, not empty

# Cogs

    - energy (out of energy, 0-100)
    - cargo (0-100, % of each resource)
    - glyph

## Terrain

- empty
- wall
- footsteps
