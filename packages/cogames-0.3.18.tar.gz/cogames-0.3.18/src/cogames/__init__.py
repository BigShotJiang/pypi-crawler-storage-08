from cogames.logging import init_logging

init_logging()
