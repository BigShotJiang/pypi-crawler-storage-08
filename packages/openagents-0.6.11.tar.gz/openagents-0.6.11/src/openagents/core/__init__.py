"""Core components of the OpenAgents framework."""
