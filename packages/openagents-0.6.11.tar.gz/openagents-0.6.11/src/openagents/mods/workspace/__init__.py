"""
Workspace mods for OpenAgents.

This package contains workspace-related mods that provide various workspace
management and collaboration capabilities.
"""

__all__ = []
