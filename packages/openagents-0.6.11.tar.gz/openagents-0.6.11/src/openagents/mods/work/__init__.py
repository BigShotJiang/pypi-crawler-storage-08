"""Work-related mods for OpenAgents."""

# Note: shared_document has been moved to openagents.mods.workspace.documents
# This module is kept for backwards compatibility but is now empty

__all__ = []
