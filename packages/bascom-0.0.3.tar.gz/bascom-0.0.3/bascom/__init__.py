"""bascom module."""
from __future__ import annotations

from .utils import setup_logging

__all__ = ('setup_logging',)
__version__ = '0.0.3'
