# Patching code

Originally from [whatthepatch](https://github.com/cscorley/whatthepatch)
(MIT license)
