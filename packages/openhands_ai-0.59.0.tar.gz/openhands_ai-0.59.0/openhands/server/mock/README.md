# OpenHands mock server
This is a simple mock server to facilitate development in the frontend.

## Start the Server
Follow the instructions in the README to install dependencies. Then run:
```
python listen.py
```

Then open the frontend to connect to the mock server. It will simply reply to every received message.
