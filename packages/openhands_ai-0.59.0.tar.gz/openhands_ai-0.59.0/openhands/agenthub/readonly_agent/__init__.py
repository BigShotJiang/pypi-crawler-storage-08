from openhands.agenthub.readonly_agent.readonly_agent import ReadOnlyAgent
from openhands.controller.agent import Agent

Agent.register('ReadOnlyAgent', ReadOnlyAgent)
