"""AI Script Generator MCP Server - AL Parser for Business Central
"""

__version__ = "0.2.9"

from .server import main

__all__ = ["main", "__version__"]
