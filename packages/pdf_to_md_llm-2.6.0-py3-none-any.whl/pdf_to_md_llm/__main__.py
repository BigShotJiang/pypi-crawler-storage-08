"""
Allow running the CLI via `python -m pdf_to_md_llm`
"""

from .cli import cli

if __name__ == "__main__":
    cli()
