from . import obsid

from .version import VERSION

__version__ = f'obsid - (obsid-{VERSION})'