from . import pyutils

from .version import VERSION

__version__ = f'pyutils - (pyutils-{VERSION})'