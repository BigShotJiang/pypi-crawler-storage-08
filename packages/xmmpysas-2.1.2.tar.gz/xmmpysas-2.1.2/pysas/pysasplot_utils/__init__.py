from . import pysasplot_utils

from .version import VERSION

__version__ = f'pysasplot_utils - (pysasplot_utils-{VERSION})'