import mlx.core as mx
from mlx import nn
from tqdm import tqdm

from mflux.callbacks.callbacks import Callbacks
from mflux.config.config import Config
from mflux.config.model_config import ModelConfig
from mflux.config.runtime_config import RuntimeConfig
from mflux.error.exceptions import StopImageGenerationException
from mflux.latent_creator.latent_creator import LatentCreator
from mflux.models.flux.flux_initializer import FluxInitializer
from mflux.models.flux.model.flux_text_encoder.clip_encoder.clip_encoder import CLIPEncoder
from mflux.models.flux.model.flux_text_encoder.prompt_encoder import PromptEncoder
from mflux.models.flux.model.flux_text_encoder.t5_encoder.t5_encoder import T5Encoder
from mflux.models.flux.model.flux_vae.vae import VAE
from mflux.models.flux.variants.concept_attention.attention_data import GenerationAttentionData
from mflux.models.flux.variants.concept_attention.concept_util import ConceptUtil
from mflux.models.flux.variants.concept_attention.transformer_concept import TransformerConcept
from mflux.post_processing.array_util import ArrayUtil
from mflux.post_processing.generated_image import GeneratedImage
from mflux.post_processing.image_util import ImageUtil


class Flux1ConceptFromImage(nn.Module):
    vae: VAE
    transformer: TransformerConcept
    t5_text_encoder: T5Encoder
    clip_text_encoder: CLIPEncoder

    def __init__(
        self,
        model_config: ModelConfig,
        quantize: int | None = None,
        local_path: str | None = None,
        lora_paths: list[str] | None = None,
        lora_scales: list[float] | None = None,
    ):
        super().__init__()
        FluxInitializer.init_concept(
            flux_model=self,
            model_config=model_config,
            quantize=quantize,
            local_path=local_path,
            lora_paths=lora_paths,
            lora_scales=lora_scales,
        )

    def generate_image(
        self,
        seed: int,
        prompt: str,
        concept: str,
        image_path: str,
        config: Config,
        heatmap_layer_indices: list[int] | None = None,
        heatmap_timesteps: list[int] | None = None,
    ) -> GeneratedImage:
        # 0. Create a new runtime config based on the model type and input parameters
        config = RuntimeConfig(config, self.model_config)
        time_steps = tqdm(range(config.init_time_step, config.num_inference_steps))

        # 1. Create the initial latents from the reference image
        encoded_image = LatentCreator.encode_image(
            vae=self.vae,
            image_path=image_path,
            height=config.height,
            width=config.width,
        )

        # Create static noise for blending at each timestep
        static_noise = LatentCreator.create(
            seed=seed,
            height=config.height,
            width=config.width,
        )

        # Start with an appropriately noised version of the encoded image
        latents = LatentCreator.add_noise_by_interpolation(
            clean=ArrayUtil.pack_latents(latents=encoded_image, height=config.height, width=config.width),
            noise=static_noise,
            sigma=config.scheduler.sigmas[config.init_time_step],
        )

        # 2. Encode the main prompt
        prompt_embeds, pooled_prompt_embeds = PromptEncoder.encode_prompt(
            prompt=prompt,
            prompt_cache=self.prompt_cache,
            t5_tokenizer=self.t5_tokenizer,
            clip_tokenizer=self.clip_tokenizer,
            t5_text_encoder=self.t5_text_encoder,
            clip_text_encoder=self.clip_text_encoder,
        )

        # 3. Encode the concept prompt
        prompt_embeds_concept, pooled_prompt_embeds_concept = PromptEncoder.encode_prompt(
            prompt=concept,
            prompt_cache=self.prompt_cache,
            t5_tokenizer=self.t5_tokenizer,
            clip_tokenizer=self.clip_tokenizer,
            t5_text_encoder=self.t5_text_encoder,
            clip_text_encoder=self.clip_text_encoder,
        )

        # (Optional) Call subscribers for beginning of loop
        Callbacks.before_loop(
            seed=seed,
            prompt=prompt,
            latents=latents,
            config=config,
        )

        attention_data = GenerationAttentionData()
        for t in time_steps:
            try:
                # Scale model input if needed by the scheduler
                latents = config.scheduler.scale_model_input(latents, t)

                # 4.t Predict the noise (we don't use the noise, only the attention)
                _, attention = self.transformer(
                    t=t,
                    config=config,
                    hidden_states=latents,
                    prompt_embeds=prompt_embeds,
                    prompt_embeds_concept=prompt_embeds_concept,
                    pooled_prompt_embeds=pooled_prompt_embeds,
                    pooled_prompt_embeds_concept=pooled_prompt_embeds_concept,
                )
                attention_data.append(attention)

                # 5.t Follow reverse diffusion trajectory
                latents = LatentCreator.add_noise_by_interpolation(
                    clean=ArrayUtil.pack_latents(latents=encoded_image, height=config.height, width=config.width),
                    noise=static_noise,
                    sigma=config.scheduler.sigmas[t + 1],
                )

                # (Optional) Call subscribers in-loop
                Callbacks.in_loop(
                    t=t,
                    seed=seed,
                    prompt=prompt,
                    latents=latents,
                    config=config,
                    time_steps=time_steps,
                )

                # Evaluate attention data to force MLX computation for progress tracking
                mx.eval(
                    [layer.img_attention for layer in attention.attention_information]
                    + [layer.concept_attention for layer in attention.attention_information]
                )

            except KeyboardInterrupt:  # noqa: PERF203
                Callbacks.interruption(
                    t=t,
                    seed=seed,
                    prompt=prompt,
                    latents=latents,
                    config=config,
                    time_steps=time_steps,
                )
                raise StopImageGenerationException(f"Stopping image generation at step {t + 1}/{len(time_steps)}")

        # (Optional) Call subscribers after loop
        Callbacks.after_loop(
            seed=seed,
            prompt=prompt,
            latents=latents,
            config=config,
        )

        # 6. Generate concept attention heatmap
        concept_heatmap = ConceptUtil.create_heatmap(
            concept=concept,
            attention_data=attention_data,
            height=config.height,
            width=config.width,
            layer_indices=heatmap_layer_indices or list(range(15, 19)),
            timesteps=heatmap_timesteps or list(range(config.num_inference_steps)),
        )

        # 7. Decode the latent array and return the image
        latents = ArrayUtil.unpack_latents(latents=latents, height=config.height, width=config.width)
        decoded = self.vae.decode(latents)

        return ImageUtil.to_image(
            decoded_latents=decoded,
            config=config,
            seed=seed,
            prompt=prompt,
            quantization=self.bits,
            lora_paths=self.lora_paths,
            lora_scales=self.lora_scales,
            image_path=image_path,
            image_strength=config.image_strength,
            generation_time=time_steps.format_dict["elapsed"],
            concept_heatmap=concept_heatmap,
        )
