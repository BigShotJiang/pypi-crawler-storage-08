# Qwen Text Encoder components
