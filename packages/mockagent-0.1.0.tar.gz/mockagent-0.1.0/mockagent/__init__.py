"""mockagent - A Python package for mocking agents."""

__version__ = "0.1.0"
