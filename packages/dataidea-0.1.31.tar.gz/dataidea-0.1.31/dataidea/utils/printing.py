from rich.console import Console

console = Console()
print = console.print
log = console.log
status = console.status
rule = console.rule