# do not import all endpoints into this module because that uses a lot of memory and stack frames
# if you need the ability to import all endpoints then import them from
# tags, paths, or path_to_api, or tag_to_api