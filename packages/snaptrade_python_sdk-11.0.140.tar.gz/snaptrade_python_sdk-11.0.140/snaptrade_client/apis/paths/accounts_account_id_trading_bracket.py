from snaptrade_client.paths.accounts_account_id_trading_bracket.post import ApiForpost


class AccountsAccountIdTradingBracket(
    ApiForpost,
):
    pass
