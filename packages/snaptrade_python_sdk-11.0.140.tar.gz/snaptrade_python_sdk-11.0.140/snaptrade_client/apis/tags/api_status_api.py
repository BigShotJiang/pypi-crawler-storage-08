# coding: utf-8

from snaptrade_client.apis.tags.api_status_api_generated import APIStatusApiGenerated

class APIStatusApi(APIStatusApiGenerated):
    pass
