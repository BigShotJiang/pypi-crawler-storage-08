import os

__version__ = os.environ.get("VERSION", "0.0.0")
