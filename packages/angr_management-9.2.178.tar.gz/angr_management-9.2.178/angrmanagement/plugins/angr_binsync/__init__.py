from __future__ import annotations

from binsync.interface_overrides.angr import BinsyncPlugin

__all__ = ["BinsyncPlugin"]
