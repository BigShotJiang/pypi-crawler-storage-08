# tortoise-pydantic-bridge
### Мост между Tortoise ORM и Pydantic для конвертации моделей
