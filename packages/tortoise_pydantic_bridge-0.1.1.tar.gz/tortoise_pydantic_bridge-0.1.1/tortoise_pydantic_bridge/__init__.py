from .crud import CRUDMixin

__all__ = ['CRUDMixin']
