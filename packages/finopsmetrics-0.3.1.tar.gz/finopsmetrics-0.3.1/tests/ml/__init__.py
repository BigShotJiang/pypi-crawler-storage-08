"""Tests for ML-powered anomaly detection and prediction."""
