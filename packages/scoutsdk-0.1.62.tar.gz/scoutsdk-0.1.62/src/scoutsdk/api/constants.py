SCOUT_CUSTOM_FUNCTION_CONTENT_TYPE = "scout/custom function"
