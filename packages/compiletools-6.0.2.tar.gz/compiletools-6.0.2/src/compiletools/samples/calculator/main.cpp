#include "calculator.h"
#include <iostream>

int main()
{
    int result = calculate(5, 3);
    std::cout << "5 + 3 = " << result << std::endl;
    return 0;
}