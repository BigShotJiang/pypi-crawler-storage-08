#pragma once

#ifdef ENABLE_RENDERING
#include "renderer.h"
#endif

void init_config();
