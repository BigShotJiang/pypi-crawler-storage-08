#ifndef ENABLE_RENDERING
#define ENABLE_RENDERING
#endif

#include "config.h"

int main() {
    return 0;
}
