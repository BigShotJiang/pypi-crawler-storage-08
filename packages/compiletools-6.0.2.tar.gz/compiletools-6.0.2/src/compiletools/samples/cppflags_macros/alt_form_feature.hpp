#ifndef ALT_FORM_FEATURE_HPP
#define ALT_FORM_FEATURE_HPP
// Alternative form test feature
#endif