#ifndef NUMA_THREADING_HPP
#define NUMA_THREADING_HPP
// NUMA-aware threading implementation
class NumaThreading {
public:
    void bind_to_numa_nodes();
};
#endif