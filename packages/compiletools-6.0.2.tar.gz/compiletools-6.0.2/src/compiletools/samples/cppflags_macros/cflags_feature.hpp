#ifndef CFLAGS_FEATURE_HPP
#define CFLAGS_FEATURE_HPP
// Feature enabled via CFLAGS macro
#endif