#ifndef AARCH64_FEATURE_HPP
#define AARCH64_FEATURE_HPP
// ARM 64-bit (AArch64) architecture-specific feature
#endif