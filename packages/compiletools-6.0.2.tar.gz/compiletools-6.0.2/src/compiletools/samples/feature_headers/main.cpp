#define ENABLE_DATABASE
#define ENABLE_LOGGING
// Note: ENABLE_GRAPHICS is not defined

#include "feature_config.h"

int main() {
    return 0;
}