// Networking functionality header
#ifndef NETWORKING_H
#define NETWORKING_H

void init_networking(void);
void close_networking(void);

#endif