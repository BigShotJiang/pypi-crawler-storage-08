// Graphics functionality header  
#ifndef GRAPHICS_H
#define GRAPHICS_H

void init_graphics(void);
void close_graphics(void);

#endif