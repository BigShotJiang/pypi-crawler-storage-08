// Windows-specific header  
void windows_function(void);