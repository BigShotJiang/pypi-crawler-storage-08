#include "../d1/./d1.hpp"
#include "./d2.hpp"

int f2()
{
    return 1+f1();
}
