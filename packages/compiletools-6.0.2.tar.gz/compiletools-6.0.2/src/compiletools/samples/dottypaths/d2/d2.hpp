#pragma once

int f2();
