"""Medallion utilities."""
