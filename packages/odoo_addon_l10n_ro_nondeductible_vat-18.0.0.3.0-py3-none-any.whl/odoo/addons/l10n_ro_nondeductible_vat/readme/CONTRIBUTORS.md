- [Dakai Soft SRL](https://www.dakai.ro):
  - Adrian Vacaru \<<adrian.vacaru@dakai.ro>\>
- [NextERP Romania](https://www.nexterp.ro):
  - Fekete Mihai \<<feketemihai@nexterp.ro>\>

Do not contact contributors directly about support or help with
technical issues.
