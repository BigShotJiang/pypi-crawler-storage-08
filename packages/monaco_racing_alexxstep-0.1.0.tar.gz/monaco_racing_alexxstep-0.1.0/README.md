# Monaco 2018 Racing Q1 Report

A Python CLI tool for generating Formula 1 Monaco 2018 Q1 qualification reports.

## Features

- Parse race data from log files
- Generate sorted race reports
- Filter by specific driver
- Sort ascending or descending by lap time
- Show top 15 racers with separator

## Installation

```bash
pip install monaco-racing-alexxstep
```

## Usage

### Show all racers (ascending order - default)

```bash
# Using entry point (recommended)
uv run monaco-report --files data/

# OR using Python module
python -m src.races.cli --files data/
```

### Show all racers (descending order)

```bash
uv run monaco-report --files data/ --desc
```

### Show specific driver statistics

```bash
uv run monaco-report --files data/ --driver "Sebastian Vettel"
```

### Help

```bash
uv run monaco-report --help
```

### Example Output

```
======================================================================
MONACO 2018 RACING Q1 REPORT (ASC ORDER)
======================================================================

 1. Sebastian Vettel          | FERRARI                          | 1:04.415
 2. Valtteri Bottas           | MERCEDES                         | 1:12.434
 3. Stoffel Vandoorne         | MCLAREN RENAULT                  | 1:12.463
...
15. Kevin Magnussen           | HAAS FERRARI                     | 1:13.393
---------------------------------------------------------------------------
16. Brendon Hartley           | SCUDERIA TORO ROSSO HONDA        | 1:13.179
...
```

## Data Format

### abbreviations.txt

```
DRR_Daniel Ricciardo_RED BULL RACING TAG HEUER
SVF_Sebastian Vettel_FERRARI
```

### start.log

```
SVF2018-05-24_12:02:58.917
DRR2018-05-24_12:14:12.054
```

### end.log

```
SVF2018-05-24_12:04:03.332
DRR2018-05-24_12:15:24.067
```

## Development

### Install for development

```bash
git clone <repo-url>
cd task6-report-of-monaco-2018-racing

# Install dependencies using uv
uv sync

# OR install in editable mode
uv pip install -e .
```

### Activate virtual environment

```bash
# On Windows (Git Bash)
source .venv/Scripts/activate

# On Linux/Mac
source .venv/bin/activate
```

### Run tests

```bash
# With uv run (no activation needed)
uv run pytest tests/ -v
uv run pytest tests/ --cov=src/races --cov-report=term-missing

# OR with activated venv
pytest tests/ -v
pytest tests/ --cov=src/races --cov-report=term-missing
```

### Code quality

```bash
# Check linting and auto-fix
uv run ruff check . --fix

# Format code
uv run ruff format .

# Run all checks
uv run ruff check .
```

## License

MIT License - see [LICENSE](LICENSE) file

## Author

Oleksiy Stypanets (Alex Step)
Email: astep2004@gmail.com
