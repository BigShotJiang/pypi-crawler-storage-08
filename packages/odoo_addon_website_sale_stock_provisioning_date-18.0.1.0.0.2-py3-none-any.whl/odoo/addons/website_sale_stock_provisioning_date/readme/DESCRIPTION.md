This module extends the functionality of website to show you the future
provisioning date closest to the current date for a product in the
eCommerce.
