To use this module you need:
  - Go to Invoicing > Configuration > Settings and check Verify VAT Numbers
  - Go to Invoicing > Configuration > Fiscal Position and create or select one
  - Set a Show Vies Warning