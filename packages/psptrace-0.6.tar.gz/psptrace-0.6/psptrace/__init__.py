from .psptrace import PSPTrace

import pkg_resources
__version__ = pkg_resources.get_distribution("psptrace").version
