class ModelNotFoundError(Exception):
    """
    Raised when a requested model is not found in the registry.
    """

    pass
