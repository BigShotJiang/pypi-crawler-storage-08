# Makes cli a package for packaging entry points
