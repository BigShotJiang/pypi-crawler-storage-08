This is a fork of [escnn](https://github.com/QUVA-Lab/escnn) that implements a 
number of features and bug fixes needed by the 
[atompaint](https://github.com/kalekundert/atompaint) package.
