from deep_phonemizer.result import PhonemizerResult, Prediction
