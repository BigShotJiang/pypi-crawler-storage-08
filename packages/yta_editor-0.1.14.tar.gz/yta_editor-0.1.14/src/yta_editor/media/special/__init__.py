"""
A module for the special media.

TODO: Move when the idea is clear and the
code is definitive.
"""