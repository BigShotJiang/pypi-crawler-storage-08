# Generated from mapping.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,103,578,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,
        7,6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,
        13,2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,
        20,7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,
        26,2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,
        33,7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,
        39,2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,
        46,7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,2,52,7,
        52,2,53,7,53,2,54,7,54,2,55,7,55,2,56,7,56,2,57,7,57,2,58,7,58,2,
        59,7,59,2,60,7,60,2,61,7,61,2,62,7,62,1,0,1,0,5,0,129,8,0,10,0,12,
        0,132,9,0,1,0,5,0,135,8,0,10,0,12,0,138,9,0,1,0,5,0,141,8,0,10,0,
        12,0,144,9,0,1,0,5,0,147,8,0,10,0,12,0,150,9,0,1,0,4,0,153,8,0,11,
        0,12,0,154,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,2,1,2,1,3,1,3,1,4,1,4,1,
        5,1,5,1,5,3,5,173,8,5,1,5,1,5,1,5,1,6,1,6,1,6,1,7,1,7,1,7,1,8,1,
        8,1,8,1,8,1,8,1,8,1,9,1,9,1,9,1,9,3,9,194,8,9,1,9,3,9,197,8,9,1,
        9,1,9,1,10,1,10,5,10,203,8,10,10,10,12,10,206,9,10,1,10,1,10,1,11,
        1,11,1,11,1,11,1,12,1,12,1,12,1,13,1,13,1,13,1,13,4,13,221,8,13,
        11,13,12,13,222,1,13,1,13,1,14,1,14,1,14,3,14,230,8,14,1,15,1,15,
        1,15,1,16,1,16,1,16,3,16,238,8,16,1,16,3,16,241,8,16,1,16,3,16,244,
        8,16,1,16,1,16,1,17,1,17,1,18,1,18,1,18,5,18,253,8,18,10,18,12,18,
        256,9,18,1,19,1,19,3,19,260,8,19,1,19,3,19,263,8,19,1,19,3,19,266,
        8,19,1,19,3,19,269,8,19,1,19,3,19,272,8,19,1,19,3,19,275,8,19,1,
        19,3,19,278,8,19,1,19,3,19,281,8,19,1,20,1,20,1,20,5,20,286,8,20,
        10,20,12,20,289,9,20,1,21,1,21,1,21,1,22,1,22,1,22,1,22,1,23,1,23,
        1,24,1,24,1,24,5,24,303,8,24,10,24,12,24,306,9,24,1,25,1,25,1,25,
        1,25,1,25,1,26,1,26,1,26,1,27,1,27,1,27,1,27,1,27,1,28,1,28,1,28,
        1,28,1,28,1,29,1,29,1,29,1,29,1,29,1,30,1,30,1,30,1,30,5,30,335,
        8,30,10,30,12,30,338,9,30,1,30,3,30,341,8,30,1,30,3,30,344,8,30,
        1,31,1,31,1,31,3,31,349,8,31,1,31,3,31,352,8,31,1,31,3,31,355,8,
        31,1,31,1,31,3,31,359,8,31,3,31,361,8,31,1,32,1,32,1,32,1,32,3,32,
        367,8,32,1,33,1,33,1,33,1,33,1,34,1,34,1,34,3,34,376,8,34,1,34,1,
        34,1,35,1,35,1,35,5,35,383,8,35,10,35,12,35,386,9,35,1,36,1,36,3,
        36,390,8,36,1,37,1,37,3,37,394,8,37,1,38,1,38,1,39,1,39,1,40,1,40,
        1,41,1,41,1,42,1,42,1,43,1,43,1,44,1,44,1,44,1,44,4,44,412,8,44,
        11,44,12,44,413,1,44,4,44,417,8,44,11,44,12,44,418,1,44,1,44,1,45,
        1,45,1,45,1,45,1,45,1,46,1,46,1,47,1,47,1,47,1,47,1,47,1,47,1,47,
        1,47,1,47,1,47,1,47,1,47,3,47,442,8,47,1,47,1,47,1,47,1,47,1,47,
        3,47,449,8,47,1,48,1,48,1,49,1,49,1,49,1,49,3,49,457,8,49,1,49,1,
        49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,
        49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,
        49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,5,49,497,8,
        49,10,49,12,49,500,9,49,1,50,1,50,1,50,1,50,1,50,1,50,1,50,3,50,
        509,8,50,1,51,1,51,1,51,1,51,1,51,1,51,1,51,1,51,1,51,1,51,3,51,
        521,8,51,1,52,1,52,1,52,3,52,526,8,52,1,53,1,53,1,53,1,53,1,53,3,
        53,533,8,53,1,54,1,54,3,54,537,8,54,1,54,1,54,3,54,541,8,54,1,54,
        1,54,1,55,1,55,1,55,5,55,548,8,55,10,55,12,55,551,9,55,1,56,1,56,
        3,56,555,8,56,1,57,1,57,1,57,3,57,560,8,57,1,58,1,58,1,59,1,59,1,
        60,1,60,1,61,1,61,1,61,5,61,571,8,61,10,61,12,61,574,9,61,1,62,1,
        62,1,62,0,1,98,63,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,
        34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,
        78,80,82,84,86,88,90,92,94,96,98,100,102,104,106,108,110,112,114,
        116,118,120,122,124,0,24,1,0,96,97,1,0,95,97,3,0,3,3,95,95,97,97,
        2,0,22,22,99,99,2,0,91,94,98,100,1,0,29,30,1,0,31,35,3,0,31,31,33,
        33,36,37,1,0,38,39,1,0,38,41,1,0,42,43,1,0,95,96,2,0,45,45,56,56,
        3,0,3,3,22,22,57,58,3,0,45,45,56,56,59,59,3,0,46,46,49,49,62,63,
        4,0,2,2,48,48,52,52,64,64,1,0,65,66,1,0,68,69,2,0,5,5,60,60,1,0,
        99,100,1,0,75,82,1,0,83,90,5,0,5,5,60,60,65,66,95,95,97,97,599,0,
        126,1,0,0,0,2,158,1,0,0,0,4,163,1,0,0,0,6,165,1,0,0,0,8,167,1,0,
        0,0,10,169,1,0,0,0,12,177,1,0,0,0,14,180,1,0,0,0,16,183,1,0,0,0,
        18,189,1,0,0,0,20,200,1,0,0,0,22,209,1,0,0,0,24,213,1,0,0,0,26,216,
        1,0,0,0,28,226,1,0,0,0,30,231,1,0,0,0,32,234,1,0,0,0,34,247,1,0,
        0,0,36,249,1,0,0,0,38,257,1,0,0,0,40,282,1,0,0,0,42,290,1,0,0,0,
        44,293,1,0,0,0,46,297,1,0,0,0,48,299,1,0,0,0,50,307,1,0,0,0,52,312,
        1,0,0,0,54,315,1,0,0,0,56,320,1,0,0,0,58,325,1,0,0,0,60,330,1,0,
        0,0,62,360,1,0,0,0,64,366,1,0,0,0,66,368,1,0,0,0,68,372,1,0,0,0,
        70,379,1,0,0,0,72,389,1,0,0,0,74,393,1,0,0,0,76,395,1,0,0,0,78,397,
        1,0,0,0,80,399,1,0,0,0,82,401,1,0,0,0,84,403,1,0,0,0,86,405,1,0,
        0,0,88,407,1,0,0,0,90,422,1,0,0,0,92,427,1,0,0,0,94,448,1,0,0,0,
        96,450,1,0,0,0,98,456,1,0,0,0,100,508,1,0,0,0,102,520,1,0,0,0,104,
        522,1,0,0,0,106,532,1,0,0,0,108,536,1,0,0,0,110,544,1,0,0,0,112,
        552,1,0,0,0,114,559,1,0,0,0,116,561,1,0,0,0,118,563,1,0,0,0,120,
        565,1,0,0,0,122,567,1,0,0,0,124,575,1,0,0,0,126,130,3,2,1,0,127,
        129,3,88,44,0,128,127,1,0,0,0,129,132,1,0,0,0,130,128,1,0,0,0,130,
        131,1,0,0,0,131,136,1,0,0,0,132,130,1,0,0,0,133,135,3,10,5,0,134,
        133,1,0,0,0,135,138,1,0,0,0,136,134,1,0,0,0,136,137,1,0,0,0,137,
        142,1,0,0,0,138,136,1,0,0,0,139,141,3,14,7,0,140,139,1,0,0,0,141,
        144,1,0,0,0,142,140,1,0,0,0,142,143,1,0,0,0,143,148,1,0,0,0,144,
        142,1,0,0,0,145,147,3,16,8,0,146,145,1,0,0,0,147,150,1,0,0,0,148,
        146,1,0,0,0,148,149,1,0,0,0,149,152,1,0,0,0,150,148,1,0,0,0,151,
        153,3,18,9,0,152,151,1,0,0,0,153,154,1,0,0,0,154,152,1,0,0,0,154,
        155,1,0,0,0,155,156,1,0,0,0,156,157,5,0,0,1,157,1,1,0,0,0,158,159,
        5,1,0,0,159,160,3,4,2,0,160,161,5,2,0,0,161,162,3,6,3,0,162,3,1,
        0,0,0,163,164,7,0,0,0,164,5,1,0,0,0,165,166,7,1,0,0,166,7,1,0,0,
        0,167,168,7,2,0,0,168,9,1,0,0,0,169,170,5,4,0,0,170,172,3,4,2,0,
        171,173,3,12,6,0,172,171,1,0,0,0,172,173,1,0,0,0,173,174,1,0,0,0,
        174,175,5,5,0,0,175,176,3,86,43,0,176,11,1,0,0,0,177,178,5,6,0,0,
        178,179,3,8,4,0,179,13,1,0,0,0,180,181,5,7,0,0,181,182,3,4,2,0,182,
        15,1,0,0,0,183,184,5,8,0,0,184,185,5,95,0,0,185,186,5,2,0,0,186,
        187,3,74,37,0,187,188,5,9,0,0,188,17,1,0,0,0,189,190,5,10,0,0,190,
        191,5,95,0,0,191,193,3,26,13,0,192,194,3,24,12,0,193,192,1,0,0,0,
        193,194,1,0,0,0,194,196,1,0,0,0,195,197,3,22,11,0,196,195,1,0,0,
        0,196,197,1,0,0,0,197,198,1,0,0,0,198,199,3,20,10,0,199,19,1,0,0,
        0,200,204,5,11,0,0,201,203,3,32,16,0,202,201,1,0,0,0,203,206,1,0,
        0,0,204,202,1,0,0,0,204,205,1,0,0,0,205,207,1,0,0,0,206,204,1,0,
        0,0,207,208,5,12,0,0,208,21,1,0,0,0,209,210,5,13,0,0,210,211,3,78,
        39,0,211,212,5,14,0,0,212,23,1,0,0,0,213,214,5,15,0,0,214,215,5,
        95,0,0,215,25,1,0,0,0,216,217,5,16,0,0,217,220,3,28,14,0,218,219,
        5,17,0,0,219,221,3,28,14,0,220,218,1,0,0,0,221,222,1,0,0,0,222,220,
        1,0,0,0,222,223,1,0,0,0,223,224,1,0,0,0,224,225,5,18,0,0,225,27,
        1,0,0,0,226,227,3,84,42,0,227,229,5,95,0,0,228,230,3,30,15,0,229,
        228,1,0,0,0,229,230,1,0,0,0,230,29,1,0,0,0,231,232,5,19,0,0,232,
        233,3,8,4,0,233,31,1,0,0,0,234,237,3,36,18,0,235,236,5,20,0,0,236,
        238,3,40,20,0,237,235,1,0,0,0,237,238,1,0,0,0,238,240,1,0,0,0,239,
        241,3,60,30,0,240,239,1,0,0,0,240,241,1,0,0,0,241,243,1,0,0,0,242,
        244,3,34,17,0,243,242,1,0,0,0,243,244,1,0,0,0,244,245,1,0,0,0,245,
        246,5,9,0,0,246,33,1,0,0,0,247,248,5,96,0,0,248,35,1,0,0,0,249,254,
        3,38,19,0,250,251,5,17,0,0,251,253,3,38,19,0,252,250,1,0,0,0,253,
        256,1,0,0,0,254,252,1,0,0,0,254,255,1,0,0,0,255,37,1,0,0,0,256,254,
        1,0,0,0,257,259,3,48,24,0,258,260,3,42,21,0,259,258,1,0,0,0,259,
        260,1,0,0,0,260,262,1,0,0,0,261,263,3,44,22,0,262,261,1,0,0,0,262,
        263,1,0,0,0,263,265,1,0,0,0,264,266,3,50,25,0,265,264,1,0,0,0,265,
        266,1,0,0,0,266,268,1,0,0,0,267,269,3,80,40,0,268,267,1,0,0,0,268,
        269,1,0,0,0,269,271,1,0,0,0,270,272,3,52,26,0,271,270,1,0,0,0,271,
        272,1,0,0,0,272,274,1,0,0,0,273,275,3,54,27,0,274,273,1,0,0,0,274,
        275,1,0,0,0,275,277,1,0,0,0,276,278,3,56,28,0,277,276,1,0,0,0,277,
        278,1,0,0,0,278,280,1,0,0,0,279,281,3,58,29,0,280,279,1,0,0,0,280,
        281,1,0,0,0,281,39,1,0,0,0,282,287,3,62,31,0,283,284,5,17,0,0,284,
        286,3,62,31,0,285,283,1,0,0,0,286,289,1,0,0,0,287,285,1,0,0,0,287,
        288,1,0,0,0,288,41,1,0,0,0,289,287,1,0,0,0,290,291,5,19,0,0,291,
        292,3,8,4,0,292,43,1,0,0,0,293,294,5,99,0,0,294,295,5,21,0,0,295,
        296,3,46,23,0,296,45,1,0,0,0,297,298,7,3,0,0,298,47,1,0,0,0,299,
        304,3,8,4,0,300,301,5,23,0,0,301,303,3,8,4,0,302,300,1,0,0,0,303,
        306,1,0,0,0,304,302,1,0,0,0,304,305,1,0,0,0,305,49,1,0,0,0,306,304,
        1,0,0,0,307,308,5,24,0,0,308,309,5,16,0,0,309,310,3,74,37,0,310,
        311,5,18,0,0,311,51,1,0,0,0,312,313,5,5,0,0,313,314,3,8,4,0,314,
        53,1,0,0,0,315,316,5,25,0,0,316,317,5,16,0,0,317,318,3,74,37,0,318,
        319,5,18,0,0,319,55,1,0,0,0,320,321,5,26,0,0,321,322,5,16,0,0,322,
        323,3,74,37,0,323,324,5,18,0,0,324,57,1,0,0,0,325,326,5,27,0,0,326,
        327,5,16,0,0,327,328,3,74,37,0,328,329,5,18,0,0,329,59,1,0,0,0,330,
        343,5,28,0,0,331,336,3,68,34,0,332,333,5,17,0,0,333,335,3,68,34,
        0,334,332,1,0,0,0,335,338,1,0,0,0,336,334,1,0,0,0,336,337,1,0,0,
        0,337,340,1,0,0,0,338,336,1,0,0,0,339,341,3,20,10,0,340,339,1,0,
        0,0,340,341,1,0,0,0,341,344,1,0,0,0,342,344,3,20,10,0,343,331,1,
        0,0,0,343,342,1,0,0,0,344,61,1,0,0,0,345,348,3,48,24,0,346,347,5,
        2,0,0,347,349,3,64,32,0,348,346,1,0,0,0,348,349,1,0,0,0,349,351,
        1,0,0,0,350,352,3,52,26,0,351,350,1,0,0,0,351,352,1,0,0,0,352,354,
        1,0,0,0,353,355,3,82,41,0,354,353,1,0,0,0,354,355,1,0,0,0,355,361,
        1,0,0,0,356,358,3,68,34,0,357,359,3,52,26,0,358,357,1,0,0,0,358,
        359,1,0,0,0,359,361,1,0,0,0,360,345,1,0,0,0,360,356,1,0,0,0,361,
        63,1,0,0,0,362,367,3,76,38,0,363,367,3,48,24,0,364,367,3,68,34,0,
        365,367,3,66,33,0,366,362,1,0,0,0,366,363,1,0,0,0,366,364,1,0,0,
        0,366,365,1,0,0,0,367,65,1,0,0,0,368,369,5,16,0,0,369,370,3,74,37,
        0,370,371,5,18,0,0,371,67,1,0,0,0,372,373,3,8,4,0,373,375,5,16,0,
        0,374,376,3,70,35,0,375,374,1,0,0,0,375,376,1,0,0,0,376,377,1,0,
        0,0,377,378,5,18,0,0,378,69,1,0,0,0,379,384,3,72,36,0,380,381,5,
        17,0,0,381,383,3,72,36,0,382,380,1,0,0,0,383,386,1,0,0,0,384,382,
        1,0,0,0,384,385,1,0,0,0,385,71,1,0,0,0,386,384,1,0,0,0,387,390,3,
        76,38,0,388,390,5,95,0,0,389,387,1,0,0,0,389,388,1,0,0,0,390,73,
        1,0,0,0,391,394,3,76,38,0,392,394,3,98,49,0,393,391,1,0,0,0,393,
        392,1,0,0,0,394,75,1,0,0,0,395,396,7,4,0,0,396,77,1,0,0,0,397,398,
        7,5,0,0,398,79,1,0,0,0,399,400,7,6,0,0,400,81,1,0,0,0,401,402,7,
        7,0,0,402,83,1,0,0,0,403,404,7,8,0,0,404,85,1,0,0,0,405,406,7,9,
        0,0,406,87,1,0,0,0,407,408,7,10,0,0,408,409,3,6,3,0,409,411,5,11,
        0,0,410,412,3,90,45,0,411,410,1,0,0,0,412,413,1,0,0,0,413,411,1,
        0,0,0,413,414,1,0,0,0,414,416,1,0,0,0,415,417,3,94,47,0,416,415,
        1,0,0,0,417,418,1,0,0,0,418,416,1,0,0,0,418,419,1,0,0,0,419,420,
        1,0,0,0,420,421,5,12,0,0,421,89,1,0,0,0,422,423,5,44,0,0,423,424,
        3,92,46,0,424,425,5,2,0,0,425,426,3,4,2,0,426,91,1,0,0,0,427,428,
        5,95,0,0,428,93,1,0,0,0,429,430,3,92,46,0,430,431,5,19,0,0,431,441,
        3,96,48,0,432,442,5,45,0,0,433,442,5,46,0,0,434,442,5,2,0,0,435,
        442,5,47,0,0,436,437,5,48,0,0,437,438,5,49,0,0,438,442,5,50,0,0,
        439,442,5,51,0,0,440,442,5,52,0,0,441,432,1,0,0,0,441,433,1,0,0,
        0,441,434,1,0,0,0,441,435,1,0,0,0,441,436,1,0,0,0,441,439,1,0,0,
        0,441,440,1,0,0,0,442,443,1,0,0,0,443,444,3,92,46,0,444,445,5,19,
        0,0,445,446,3,96,48,0,446,449,1,0,0,0,447,449,5,53,0,0,448,429,1,
        0,0,0,448,447,1,0,0,0,449,95,1,0,0,0,450,451,7,11,0,0,451,97,1,0,
        0,0,452,453,6,49,-1,0,453,457,3,100,50,0,454,455,7,12,0,0,455,457,
        3,98,49,11,456,452,1,0,0,0,456,454,1,0,0,0,457,498,1,0,0,0,458,459,
        10,10,0,0,459,460,7,13,0,0,460,497,3,98,49,11,461,462,10,9,0,0,462,
        463,7,14,0,0,463,497,3,98,49,10,464,465,10,7,0,0,465,466,5,61,0,
        0,466,497,3,98,49,8,467,468,10,6,0,0,468,469,7,15,0,0,469,497,3,
        98,49,7,470,471,10,5,0,0,471,472,7,16,0,0,472,497,3,98,49,6,473,
        474,10,4,0,0,474,475,7,17,0,0,475,497,3,98,49,5,476,477,10,3,0,0,
        477,478,5,67,0,0,478,497,3,98,49,4,479,480,10,2,0,0,480,481,7,18,
        0,0,481,497,3,98,49,3,482,483,10,1,0,0,483,484,5,70,0,0,484,497,
        3,98,49,2,485,486,10,13,0,0,486,487,5,23,0,0,487,497,3,106,53,0,
        488,489,10,12,0,0,489,490,5,54,0,0,490,491,3,98,49,0,491,492,5,55,
        0,0,492,497,1,0,0,0,493,494,10,8,0,0,494,495,7,19,0,0,495,497,3,
        120,60,0,496,458,1,0,0,0,496,461,1,0,0,0,496,464,1,0,0,0,496,467,
        1,0,0,0,496,470,1,0,0,0,496,473,1,0,0,0,496,476,1,0,0,0,496,479,
        1,0,0,0,496,482,1,0,0,0,496,485,1,0,0,0,496,488,1,0,0,0,496,493,
        1,0,0,0,497,500,1,0,0,0,498,496,1,0,0,0,498,499,1,0,0,0,499,99,1,
        0,0,0,500,498,1,0,0,0,501,509,3,106,53,0,502,509,3,102,51,0,503,
        509,3,104,52,0,504,505,5,16,0,0,505,506,3,98,49,0,506,507,5,18,0,
        0,507,509,1,0,0,0,508,501,1,0,0,0,508,502,1,0,0,0,508,503,1,0,0,
        0,508,504,1,0,0,0,509,101,1,0,0,0,510,511,5,11,0,0,511,521,5,12,
        0,0,512,521,5,91,0,0,513,521,5,98,0,0,514,521,5,100,0,0,515,521,
        5,99,0,0,516,521,5,92,0,0,517,521,5,93,0,0,518,521,5,94,0,0,519,
        521,3,112,56,0,520,510,1,0,0,0,520,512,1,0,0,0,520,513,1,0,0,0,520,
        514,1,0,0,0,520,515,1,0,0,0,520,516,1,0,0,0,520,517,1,0,0,0,520,
        518,1,0,0,0,520,519,1,0,0,0,521,103,1,0,0,0,522,525,5,71,0,0,523,
        526,3,124,62,0,524,526,5,98,0,0,525,523,1,0,0,0,525,524,1,0,0,0,
        526,105,1,0,0,0,527,533,3,124,62,0,528,533,3,108,54,0,529,533,5,
        72,0,0,530,533,5,73,0,0,531,533,5,74,0,0,532,527,1,0,0,0,532,528,
        1,0,0,0,532,529,1,0,0,0,532,530,1,0,0,0,532,531,1,0,0,0,533,107,
        1,0,0,0,534,537,3,124,62,0,535,537,5,25,0,0,536,534,1,0,0,0,536,
        535,1,0,0,0,537,538,1,0,0,0,538,540,5,16,0,0,539,541,3,110,55,0,
        540,539,1,0,0,0,540,541,1,0,0,0,541,542,1,0,0,0,542,543,5,18,0,0,
        543,109,1,0,0,0,544,549,3,98,49,0,545,546,5,17,0,0,546,548,3,98,
        49,0,547,545,1,0,0,0,548,551,1,0,0,0,549,547,1,0,0,0,549,550,1,0,
        0,0,550,111,1,0,0,0,551,549,1,0,0,0,552,554,7,20,0,0,553,555,3,114,
        57,0,554,553,1,0,0,0,554,555,1,0,0,0,555,113,1,0,0,0,556,560,3,116,
        58,0,557,560,3,118,59,0,558,560,5,98,0,0,559,556,1,0,0,0,559,557,
        1,0,0,0,559,558,1,0,0,0,560,115,1,0,0,0,561,562,7,21,0,0,562,117,
        1,0,0,0,563,564,7,22,0,0,564,119,1,0,0,0,565,566,3,122,61,0,566,
        121,1,0,0,0,567,572,3,124,62,0,568,569,5,23,0,0,569,571,3,124,62,
        0,570,568,1,0,0,0,571,574,1,0,0,0,572,570,1,0,0,0,572,573,1,0,0,
        0,573,123,1,0,0,0,574,572,1,0,0,0,575,576,7,23,0,0,576,125,1,0,0,
        0,55,130,136,142,148,154,172,193,196,204,222,229,237,240,243,254,
        259,262,265,268,271,274,277,280,287,304,336,340,343,348,351,354,
        358,360,366,375,384,389,393,413,418,441,448,456,496,498,508,520,
        525,532,536,540,549,554,559,572
    ]

class mappingParser ( Parser ):

    grammarFileName = "mapping.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'map'", "'='", "'div'", "'uses'", "'as'", 
                     "'alias'", "'imports'", "'let'", "';'", "'group'", 
                     "'{'", "'}'", "'<<'", "'>>'", "'extends'", "'('", "','", 
                     "')'", "':'", "'->'", "'..'", "'*'", "'.'", "'default'", 
                     "'where'", "'check'", "'log'", "'then'", "'types'", 
                     "'type+'", "'first'", "'not_first'", "'last'", "'not_last'", 
                     "'only_one'", "'share'", "'single'", "'source'", "'target'", 
                     "'queried'", "'produced'", "'conceptMap'", "'conceptmap'", 
                     "'prefix'", "'-'", "'<='", "'=='", "'!='", "'>='", 
                     "'>-'", "'<-'", "'~'", "'--'", "'['", "']'", "'+'", 
                     "'/'", "'mod'", "'&'", "'is'", "'|'", "'<'", "'>'", 
                     "'!~'", "'in'", "'contains'", "'and'", "'or'", "'xor'", 
                     "'implies'", "'%'", "'$this'", "'$index'", "'$total'", 
                     "'year'", "'month'", "'week'", "'day'", "'hour'", "'minute'", 
                     "'second'", "'millisecond'", "'years'", "'months'", 
                     "'weeks'", "'days'", "'hours'", "'minutes'", "'seconds'", 
                     "'milliseconds'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "BOOL", "DATE", 
                      "DATETIME", "TIME", "IDENTIFIER", "QUOTEIDENTIFIER", 
                      "DELIMITEDIDENTIFIER", "STRING", "INTEGER", "NUMBER", 
                      "WS", "COMMENT", "LINE_COMMENT" ]

    RULE_structureMap = 0
    RULE_mapId = 1
    RULE_url = 2
    RULE_quoteidentifier = 3
    RULE_mapidentifier = 4
    RULE_structure = 5
    RULE_structureAlias = 6
    RULE_imports = 7
    RULE_const = 8
    RULE_group = 9
    RULE_rules = 10
    RULE_typeMode = 11
    RULE_extends = 12
    RULE_parameters = 13
    RULE_parameter = 14
    RULE_type = 15
    RULE_rule = 16
    RULE_ruleName = 17
    RULE_ruleSources = 18
    RULE_ruleSource = 19
    RULE_ruleTargets = 20
    RULE_sourceType = 21
    RULE_sourceCardinality = 22
    RULE_upperBound = 23
    RULE_ruleContext = 24
    RULE_sourceDefault = 25
    RULE_alias = 26
    RULE_whereClause = 27
    RULE_checkClause = 28
    RULE_log = 29
    RULE_dependent = 30
    RULE_ruleTarget = 31
    RULE_transform = 32
    RULE_evaluate = 33
    RULE_mapinvocation = 34
    RULE_mapparamList = 35
    RULE_param = 36
    RULE_fhirPath = 37
    RULE_mapliteral = 38
    RULE_groupTypeMode = 39
    RULE_sourceListMode = 40
    RULE_targetListMode = 41
    RULE_inputMode = 42
    RULE_modelMode = 43
    RULE_conceptMap = 44
    RULE_prefix = 45
    RULE_conceptMappingVar = 46
    RULE_conceptMapping = 47
    RULE_field = 48
    RULE_expression = 49
    RULE_term = 50
    RULE_literal = 51
    RULE_externalConstant = 52
    RULE_invocation = 53
    RULE_function = 54
    RULE_paramList = 55
    RULE_quantity = 56
    RULE_unit = 57
    RULE_dateTimePrecision = 58
    RULE_pluralDateTimePrecision = 59
    RULE_typeSpecifier = 60
    RULE_qualifiedIdentifier = 61
    RULE_identifier = 62

    ruleNames =  [ "structureMap", "mapId", "url", "quoteidentifier", "mapidentifier", 
                   "structure", "structureAlias", "imports", "const", "group", 
                   "rules", "typeMode", "extends", "parameters", "parameter", 
                   "type", "rule", "ruleName", "ruleSources", "ruleSource", 
                   "ruleTargets", "sourceType", "sourceCardinality", "upperBound", 
                   "ruleContext", "sourceDefault", "alias", "whereClause", 
                   "checkClause", "log", "dependent", "ruleTarget", "transform", 
                   "evaluate", "mapinvocation", "mapparamList", "param", 
                   "fhirPath", "mapliteral", "groupTypeMode", "sourceListMode", 
                   "targetListMode", "inputMode", "modelMode", "conceptMap", 
                   "prefix", "conceptMappingVar", "conceptMapping", "field", 
                   "expression", "term", "literal", "externalConstant", 
                   "invocation", "function", "paramList", "quantity", "unit", 
                   "dateTimePrecision", "pluralDateTimePrecision", "typeSpecifier", 
                   "qualifiedIdentifier", "identifier" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    T__26=27
    T__27=28
    T__28=29
    T__29=30
    T__30=31
    T__31=32
    T__32=33
    T__33=34
    T__34=35
    T__35=36
    T__36=37
    T__37=38
    T__38=39
    T__39=40
    T__40=41
    T__41=42
    T__42=43
    T__43=44
    T__44=45
    T__45=46
    T__46=47
    T__47=48
    T__48=49
    T__49=50
    T__50=51
    T__51=52
    T__52=53
    T__53=54
    T__54=55
    T__55=56
    T__56=57
    T__57=58
    T__58=59
    T__59=60
    T__60=61
    T__61=62
    T__62=63
    T__63=64
    T__64=65
    T__65=66
    T__66=67
    T__67=68
    T__68=69
    T__69=70
    T__70=71
    T__71=72
    T__72=73
    T__73=74
    T__74=75
    T__75=76
    T__76=77
    T__77=78
    T__78=79
    T__79=80
    T__80=81
    T__81=82
    T__82=83
    T__83=84
    T__84=85
    T__85=86
    T__86=87
    T__87=88
    T__88=89
    T__89=90
    BOOL=91
    DATE=92
    DATETIME=93
    TIME=94
    IDENTIFIER=95
    QUOTEIDENTIFIER=96
    DELIMITEDIDENTIFIER=97
    STRING=98
    INTEGER=99
    NUMBER=100
    WS=101
    COMMENT=102
    LINE_COMMENT=103

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class StructureMapContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapId(self):
            return self.getTypedRuleContext(mappingParser.MapIdContext,0)


        def EOF(self):
            return self.getToken(mappingParser.EOF, 0)

        def conceptMap(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ConceptMapContext)
            else:
                return self.getTypedRuleContext(mappingParser.ConceptMapContext,i)


        def structure(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.StructureContext)
            else:
                return self.getTypedRuleContext(mappingParser.StructureContext,i)


        def imports(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ImportsContext)
            else:
                return self.getTypedRuleContext(mappingParser.ImportsContext,i)


        def const(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ConstContext)
            else:
                return self.getTypedRuleContext(mappingParser.ConstContext,i)


        def group(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.GroupContext)
            else:
                return self.getTypedRuleContext(mappingParser.GroupContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_structureMap

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStructureMap" ):
                listener.enterStructureMap(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStructureMap" ):
                listener.exitStructureMap(self)




    def structureMap(self):

        localctx = mappingParser.StructureMapContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_structureMap)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 126
            self.mapId()
            self.state = 130
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==42 or _la==43:
                self.state = 127
                self.conceptMap()
                self.state = 132
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 136
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==4:
                self.state = 133
                self.structure()
                self.state = 138
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 142
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==7:
                self.state = 139
                self.imports()
                self.state = 144
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 148
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==8:
                self.state = 145
                self.const()
                self.state = 150
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 152 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 151
                self.group()
                self.state = 154 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==10):
                    break

            self.state = 156
            self.match(mappingParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapIdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def url(self):
            return self.getTypedRuleContext(mappingParser.UrlContext,0)


        def quoteidentifier(self):
            return self.getTypedRuleContext(mappingParser.QuoteidentifierContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_mapId

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapId" ):
                listener.enterMapId(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapId" ):
                listener.exitMapId(self)




    def mapId(self):

        localctx = mappingParser.MapIdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_mapId)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 158
            self.match(mappingParser.T__0)
            self.state = 159
            self.url()
            self.state = 160
            self.match(mappingParser.T__1)
            self.state = 161
            self.quoteidentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UrlContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DELIMITEDIDENTIFIER(self):
            return self.getToken(mappingParser.DELIMITEDIDENTIFIER, 0)

        def QUOTEIDENTIFIER(self):
            return self.getToken(mappingParser.QUOTEIDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_url

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUrl" ):
                listener.enterUrl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUrl" ):
                listener.exitUrl(self)




    def url(self):

        localctx = mappingParser.UrlContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_url)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 163
            _la = self._input.LA(1)
            if not(_la==96 or _la==97):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class QuoteidentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def DELIMITEDIDENTIFIER(self):
            return self.getToken(mappingParser.DELIMITEDIDENTIFIER, 0)

        def QUOTEIDENTIFIER(self):
            return self.getToken(mappingParser.QUOTEIDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_quoteidentifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuoteidentifier" ):
                listener.enterQuoteidentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuoteidentifier" ):
                listener.exitQuoteidentifier(self)




    def quoteidentifier(self):

        localctx = mappingParser.QuoteidentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_quoteidentifier)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 165
            _la = self._input.LA(1)
            if not(((((_la - 95)) & ~0x3f) == 0 and ((1 << (_la - 95)) & 7) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapidentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def DELIMITEDIDENTIFIER(self):
            return self.getToken(mappingParser.DELIMITEDIDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_mapidentifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapidentifier" ):
                listener.enterMapidentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapidentifier" ):
                listener.exitMapidentifier(self)




    def mapidentifier(self):

        localctx = mappingParser.MapidentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_mapidentifier)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 167
            _la = self._input.LA(1)
            if not(_la==3 or _la==95 or _la==97):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StructureContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def url(self):
            return self.getTypedRuleContext(mappingParser.UrlContext,0)


        def modelMode(self):
            return self.getTypedRuleContext(mappingParser.ModelModeContext,0)


        def structureAlias(self):
            return self.getTypedRuleContext(mappingParser.StructureAliasContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_structure

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStructure" ):
                listener.enterStructure(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStructure" ):
                listener.exitStructure(self)




    def structure(self):

        localctx = mappingParser.StructureContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_structure)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 169
            self.match(mappingParser.T__3)
            self.state = 170
            self.url()
            self.state = 172
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==6:
                self.state = 171
                self.structureAlias()


            self.state = 174
            self.match(mappingParser.T__4)
            self.state = 175
            self.modelMode()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StructureAliasContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapidentifier(self):
            return self.getTypedRuleContext(mappingParser.MapidentifierContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_structureAlias

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStructureAlias" ):
                listener.enterStructureAlias(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStructureAlias" ):
                listener.exitStructureAlias(self)




    def structureAlias(self):

        localctx = mappingParser.StructureAliasContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_structureAlias)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 177
            self.match(mappingParser.T__5)
            self.state = 178
            self.mapidentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ImportsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def url(self):
            return self.getTypedRuleContext(mappingParser.UrlContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_imports

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImports" ):
                listener.enterImports(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImports" ):
                listener.exitImports(self)




    def imports(self):

        localctx = mappingParser.ImportsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_imports)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 180
            self.match(mappingParser.T__6)
            self.state = 181
            self.url()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def fhirPath(self):
            return self.getTypedRuleContext(mappingParser.FhirPathContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_const

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConst" ):
                listener.enterConst(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConst" ):
                listener.exitConst(self)




    def const(self):

        localctx = mappingParser.ConstContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_const)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 183
            self.match(mappingParser.T__7)
            self.state = 184
            self.match(mappingParser.IDENTIFIER)
            self.state = 185
            self.match(mappingParser.T__1)
            self.state = 186
            self.fhirPath()
            self.state = 187
            self.match(mappingParser.T__8)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GroupContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def parameters(self):
            return self.getTypedRuleContext(mappingParser.ParametersContext,0)


        def rules(self):
            return self.getTypedRuleContext(mappingParser.RulesContext,0)


        def extends(self):
            return self.getTypedRuleContext(mappingParser.ExtendsContext,0)


        def typeMode(self):
            return self.getTypedRuleContext(mappingParser.TypeModeContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_group

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGroup" ):
                listener.enterGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGroup" ):
                listener.exitGroup(self)




    def group(self):

        localctx = mappingParser.GroupContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_group)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 189
            self.match(mappingParser.T__9)
            self.state = 190
            self.match(mappingParser.IDENTIFIER)
            self.state = 191
            self.parameters()
            self.state = 193
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==15:
                self.state = 192
                self.extends()


            self.state = 196
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==13:
                self.state = 195
                self.typeMode()


            self.state = 198
            self.rules()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RulesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def rule_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.RuleContext)
            else:
                return self.getTypedRuleContext(mappingParser.RuleContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_rules

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRules" ):
                listener.enterRules(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRules" ):
                listener.exitRules(self)




    def rules(self):

        localctx = mappingParser.RulesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_rules)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 200
            self.match(mappingParser.T__10)
            self.state = 204
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==3 or _la==95 or _la==97:
                self.state = 201
                self.rule_()
                self.state = 206
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 207
            self.match(mappingParser.T__11)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeModeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def groupTypeMode(self):
            return self.getTypedRuleContext(mappingParser.GroupTypeModeContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_typeMode

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeMode" ):
                listener.enterTypeMode(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeMode" ):
                listener.exitTypeMode(self)




    def typeMode(self):

        localctx = mappingParser.TypeModeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_typeMode)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 209
            self.match(mappingParser.T__12)
            self.state = 210
            self.groupTypeMode()
            self.state = 211
            self.match(mappingParser.T__13)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExtendsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_extends

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExtends" ):
                listener.enterExtends(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExtends" ):
                listener.exitExtends(self)




    def extends(self):

        localctx = mappingParser.ExtendsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_extends)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 213
            self.match(mappingParser.T__14)
            self.state = 214
            self.match(mappingParser.IDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParametersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def parameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ParameterContext)
            else:
                return self.getTypedRuleContext(mappingParser.ParameterContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_parameters

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameters" ):
                listener.enterParameters(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameters" ):
                listener.exitParameters(self)




    def parameters(self):

        localctx = mappingParser.ParametersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_parameters)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 216
            self.match(mappingParser.T__15)
            self.state = 217
            self.parameter()
            self.state = 220 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 218
                self.match(mappingParser.T__16)
                self.state = 219
                self.parameter()
                self.state = 222 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==17):
                    break

            self.state = 224
            self.match(mappingParser.T__17)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def inputMode(self):
            return self.getTypedRuleContext(mappingParser.InputModeContext,0)


        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def type_(self):
            return self.getTypedRuleContext(mappingParser.TypeContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_parameter

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameter" ):
                listener.enterParameter(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameter" ):
                listener.exitParameter(self)




    def parameter(self):

        localctx = mappingParser.ParameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_parameter)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 226
            self.inputMode()
            self.state = 227
            self.match(mappingParser.IDENTIFIER)
            self.state = 229
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==19:
                self.state = 228
                self.type_()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapidentifier(self):
            return self.getTypedRuleContext(mappingParser.MapidentifierContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterType" ):
                listener.enterType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitType" ):
                listener.exitType(self)




    def type_(self):

        localctx = mappingParser.TypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_type)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 231
            self.match(mappingParser.T__18)
            self.state = 232
            self.mapidentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ruleSources(self):
            return self.getTypedRuleContext(mappingParser.RuleSourcesContext,0)


        def ruleTargets(self):
            return self.getTypedRuleContext(mappingParser.RuleTargetsContext,0)


        def dependent(self):
            return self.getTypedRuleContext(mappingParser.DependentContext,0)


        def ruleName(self):
            return self.getTypedRuleContext(mappingParser.RuleNameContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_rule

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRule" ):
                listener.enterRule(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRule" ):
                listener.exitRule(self)




    def rule_(self):

        localctx = mappingParser.RuleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_rule)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 234
            self.ruleSources()
            self.state = 237
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==20:
                self.state = 235
                self.match(mappingParser.T__19)
                self.state = 236
                self.ruleTargets()


            self.state = 240
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 239
                self.dependent()


            self.state = 243
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==96:
                self.state = 242
                self.ruleName()


            self.state = 245
            self.match(mappingParser.T__8)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QUOTEIDENTIFIER(self):
            return self.getToken(mappingParser.QUOTEIDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_ruleName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleName" ):
                listener.enterRuleName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleName" ):
                listener.exitRuleName(self)




    def ruleName(self):

        localctx = mappingParser.RuleNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_ruleName)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 247
            self.match(mappingParser.QUOTEIDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleSourcesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ruleSource(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.RuleSourceContext)
            else:
                return self.getTypedRuleContext(mappingParser.RuleSourceContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_ruleSources

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleSources" ):
                listener.enterRuleSources(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleSources" ):
                listener.exitRuleSources(self)




    def ruleSources(self):

        localctx = mappingParser.RuleSourcesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_ruleSources)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 249
            self.ruleSource()
            self.state = 254
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==17:
                self.state = 250
                self.match(mappingParser.T__16)
                self.state = 251
                self.ruleSource()
                self.state = 256
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleSourceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ruleContext(self):
            return self.getTypedRuleContext(mappingParser.RuleContextContext,0)


        def sourceType(self):
            return self.getTypedRuleContext(mappingParser.SourceTypeContext,0)


        def sourceCardinality(self):
            return self.getTypedRuleContext(mappingParser.SourceCardinalityContext,0)


        def sourceDefault(self):
            return self.getTypedRuleContext(mappingParser.SourceDefaultContext,0)


        def sourceListMode(self):
            return self.getTypedRuleContext(mappingParser.SourceListModeContext,0)


        def alias(self):
            return self.getTypedRuleContext(mappingParser.AliasContext,0)


        def whereClause(self):
            return self.getTypedRuleContext(mappingParser.WhereClauseContext,0)


        def checkClause(self):
            return self.getTypedRuleContext(mappingParser.CheckClauseContext,0)


        def log(self):
            return self.getTypedRuleContext(mappingParser.LogContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_ruleSource

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleSource" ):
                listener.enterRuleSource(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleSource" ):
                listener.exitRuleSource(self)




    def ruleSource(self):

        localctx = mappingParser.RuleSourceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_ruleSource)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 257
            self.ruleContext()
            self.state = 259
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==19:
                self.state = 258
                self.sourceType()


            self.state = 262
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==99:
                self.state = 261
                self.sourceCardinality()


            self.state = 265
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 264
                self.sourceDefault()


            self.state = 268
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 66571993088) != 0):
                self.state = 267
                self.sourceListMode()


            self.state = 271
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==5:
                self.state = 270
                self.alias()


            self.state = 274
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==25:
                self.state = 273
                self.whereClause()


            self.state = 277
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==26:
                self.state = 276
                self.checkClause()


            self.state = 280
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==27:
                self.state = 279
                self.log()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleTargetsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ruleTarget(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.RuleTargetContext)
            else:
                return self.getTypedRuleContext(mappingParser.RuleTargetContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_ruleTargets

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleTargets" ):
                listener.enterRuleTargets(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleTargets" ):
                listener.exitRuleTargets(self)




    def ruleTargets(self):

        localctx = mappingParser.RuleTargetsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_ruleTargets)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 282
            self.ruleTarget()
            self.state = 287
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==17:
                self.state = 283
                self.match(mappingParser.T__16)
                self.state = 284
                self.ruleTarget()
                self.state = 289
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SourceTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapidentifier(self):
            return self.getTypedRuleContext(mappingParser.MapidentifierContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_sourceType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSourceType" ):
                listener.enterSourceType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSourceType" ):
                listener.exitSourceType(self)




    def sourceType(self):

        localctx = mappingParser.SourceTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_sourceType)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 290
            self.match(mappingParser.T__18)
            self.state = 291
            self.mapidentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SourceCardinalityContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTEGER(self):
            return self.getToken(mappingParser.INTEGER, 0)

        def upperBound(self):
            return self.getTypedRuleContext(mappingParser.UpperBoundContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_sourceCardinality

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSourceCardinality" ):
                listener.enterSourceCardinality(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSourceCardinality" ):
                listener.exitSourceCardinality(self)




    def sourceCardinality(self):

        localctx = mappingParser.SourceCardinalityContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_sourceCardinality)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 293
            self.match(mappingParser.INTEGER)
            self.state = 294
            self.match(mappingParser.T__20)
            self.state = 295
            self.upperBound()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UpperBoundContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTEGER(self):
            return self.getToken(mappingParser.INTEGER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_upperBound

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUpperBound" ):
                listener.enterUpperBound(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUpperBound" ):
                listener.exitUpperBound(self)




    def upperBound(self):

        localctx = mappingParser.UpperBoundContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_upperBound)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 297
            _la = self._input.LA(1)
            if not(_la==22 or _la==99):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleContextContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapidentifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.MapidentifierContext)
            else:
                return self.getTypedRuleContext(mappingParser.MapidentifierContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_ruleContext

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleContext" ):
                listener.enterRuleContext(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleContext" ):
                listener.exitRuleContext(self)




    def ruleContext(self):

        localctx = mappingParser.RuleContextContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_ruleContext)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 299
            self.mapidentifier()
            self.state = 304
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==23:
                self.state = 300
                self.match(mappingParser.T__22)
                self.state = 301
                self.mapidentifier()
                self.state = 306
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SourceDefaultContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fhirPath(self):
            return self.getTypedRuleContext(mappingParser.FhirPathContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_sourceDefault

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSourceDefault" ):
                listener.enterSourceDefault(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSourceDefault" ):
                listener.exitSourceDefault(self)




    def sourceDefault(self):

        localctx = mappingParser.SourceDefaultContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_sourceDefault)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 307
            self.match(mappingParser.T__23)
            self.state = 308
            self.match(mappingParser.T__15)
            self.state = 309
            self.fhirPath()
            self.state = 310
            self.match(mappingParser.T__17)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AliasContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapidentifier(self):
            return self.getTypedRuleContext(mappingParser.MapidentifierContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_alias

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAlias" ):
                listener.enterAlias(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAlias" ):
                listener.exitAlias(self)




    def alias(self):

        localctx = mappingParser.AliasContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_alias)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 312
            self.match(mappingParser.T__4)
            self.state = 313
            self.mapidentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WhereClauseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fhirPath(self):
            return self.getTypedRuleContext(mappingParser.FhirPathContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_whereClause

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhereClause" ):
                listener.enterWhereClause(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhereClause" ):
                listener.exitWhereClause(self)




    def whereClause(self):

        localctx = mappingParser.WhereClauseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_whereClause)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 315
            self.match(mappingParser.T__24)
            self.state = 316
            self.match(mappingParser.T__15)
            self.state = 317
            self.fhirPath()
            self.state = 318
            self.match(mappingParser.T__17)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CheckClauseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fhirPath(self):
            return self.getTypedRuleContext(mappingParser.FhirPathContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_checkClause

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCheckClause" ):
                listener.enterCheckClause(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCheckClause" ):
                listener.exitCheckClause(self)




    def checkClause(self):

        localctx = mappingParser.CheckClauseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_checkClause)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 320
            self.match(mappingParser.T__25)
            self.state = 321
            self.match(mappingParser.T__15)
            self.state = 322
            self.fhirPath()
            self.state = 323
            self.match(mappingParser.T__17)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LogContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fhirPath(self):
            return self.getTypedRuleContext(mappingParser.FhirPathContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_log

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLog" ):
                listener.enterLog(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLog" ):
                listener.exitLog(self)




    def log(self):

        localctx = mappingParser.LogContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_log)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 325
            self.match(mappingParser.T__26)
            self.state = 326
            self.match(mappingParser.T__15)
            self.state = 327
            self.fhirPath()
            self.state = 328
            self.match(mappingParser.T__17)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DependentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapinvocation(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.MapinvocationContext)
            else:
                return self.getTypedRuleContext(mappingParser.MapinvocationContext,i)


        def rules(self):
            return self.getTypedRuleContext(mappingParser.RulesContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_dependent

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDependent" ):
                listener.enterDependent(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDependent" ):
                listener.exitDependent(self)




    def dependent(self):

        localctx = mappingParser.DependentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_dependent)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 330
            self.match(mappingParser.T__27)
            self.state = 343
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [3, 95, 97]:
                self.state = 331
                self.mapinvocation()
                self.state = 336
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==17:
                    self.state = 332
                    self.match(mappingParser.T__16)
                    self.state = 333
                    self.mapinvocation()
                    self.state = 338
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 340
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==11:
                    self.state = 339
                    self.rules()


                pass
            elif token in [11]:
                self.state = 342
                self.rules()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleTargetContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ruleContext(self):
            return self.getTypedRuleContext(mappingParser.RuleContextContext,0)


        def transform(self):
            return self.getTypedRuleContext(mappingParser.TransformContext,0)


        def alias(self):
            return self.getTypedRuleContext(mappingParser.AliasContext,0)


        def targetListMode(self):
            return self.getTypedRuleContext(mappingParser.TargetListModeContext,0)


        def mapinvocation(self):
            return self.getTypedRuleContext(mappingParser.MapinvocationContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_ruleTarget

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleTarget" ):
                listener.enterRuleTarget(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleTarget" ):
                listener.exitRuleTarget(self)




    def ruleTarget(self):

        localctx = mappingParser.RuleTargetContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_ruleTarget)
        self._la = 0 # Token type
        try:
            self.state = 360
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,32,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 345
                self.ruleContext()
                self.state = 348
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==2:
                    self.state = 346
                    self.match(mappingParser.T__1)
                    self.state = 347
                    self.transform()


                self.state = 351
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==5:
                    self.state = 350
                    self.alias()


                self.state = 354
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 216895848448) != 0):
                    self.state = 353
                    self.targetListMode()


                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 356
                self.mapinvocation()
                self.state = 358
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==5:
                    self.state = 357
                    self.alias()


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TransformContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapliteral(self):
            return self.getTypedRuleContext(mappingParser.MapliteralContext,0)


        def ruleContext(self):
            return self.getTypedRuleContext(mappingParser.RuleContextContext,0)


        def mapinvocation(self):
            return self.getTypedRuleContext(mappingParser.MapinvocationContext,0)


        def evaluate(self):
            return self.getTypedRuleContext(mappingParser.EvaluateContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_transform

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTransform" ):
                listener.enterTransform(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTransform" ):
                listener.exitTransform(self)




    def transform(self):

        localctx = mappingParser.TransformContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_transform)
        try:
            self.state = 366
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,33,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 362
                self.mapliteral()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 363
                self.ruleContext()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 364
                self.mapinvocation()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 365
                self.evaluate()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EvaluateContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fhirPath(self):
            return self.getTypedRuleContext(mappingParser.FhirPathContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_evaluate

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEvaluate" ):
                listener.enterEvaluate(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEvaluate" ):
                listener.exitEvaluate(self)




    def evaluate(self):

        localctx = mappingParser.EvaluateContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_evaluate)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 368
            self.match(mappingParser.T__15)
            self.state = 369
            self.fhirPath()
            self.state = 370
            self.match(mappingParser.T__17)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapinvocationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapidentifier(self):
            return self.getTypedRuleContext(mappingParser.MapidentifierContext,0)


        def mapparamList(self):
            return self.getTypedRuleContext(mappingParser.MapparamListContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_mapinvocation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapinvocation" ):
                listener.enterMapinvocation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapinvocation" ):
                listener.exitMapinvocation(self)




    def mapinvocation(self):

        localctx = mappingParser.MapinvocationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_mapinvocation)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 372
            self.mapidentifier()
            self.state = 373
            self.match(mappingParser.T__15)
            self.state = 375
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if ((((_la - 91)) & ~0x3f) == 0 and ((1 << (_la - 91)) & 927) != 0):
                self.state = 374
                self.mapparamList()


            self.state = 377
            self.match(mappingParser.T__17)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapparamListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def param(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ParamContext)
            else:
                return self.getTypedRuleContext(mappingParser.ParamContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_mapparamList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapparamList" ):
                listener.enterMapparamList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapparamList" ):
                listener.exitMapparamList(self)




    def mapparamList(self):

        localctx = mappingParser.MapparamListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_mapparamList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 379
            self.param()
            self.state = 384
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==17:
                self.state = 380
                self.match(mappingParser.T__16)
                self.state = 381
                self.param()
                self.state = 386
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapliteral(self):
            return self.getTypedRuleContext(mappingParser.MapliteralContext,0)


        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_param

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParam" ):
                listener.enterParam(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParam" ):
                listener.exitParam(self)




    def param(self):

        localctx = mappingParser.ParamContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_param)
        try:
            self.state = 389
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [91, 92, 93, 94, 98, 99, 100]:
                self.enterOuterAlt(localctx, 1)
                self.state = 387
                self.mapliteral()
                pass
            elif token in [95]:
                self.enterOuterAlt(localctx, 2)
                self.state = 388
                self.match(mappingParser.IDENTIFIER)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FhirPathContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapliteral(self):
            return self.getTypedRuleContext(mappingParser.MapliteralContext,0)


        def expression(self):
            return self.getTypedRuleContext(mappingParser.ExpressionContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_fhirPath

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFhirPath" ):
                listener.enterFhirPath(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFhirPath" ):
                listener.exitFhirPath(self)




    def fhirPath(self):

        localctx = mappingParser.FhirPathContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_fhirPath)
        try:
            self.state = 393
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,37,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 391
                self.mapliteral()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 392
                self.expression(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapliteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTEGER(self):
            return self.getToken(mappingParser.INTEGER, 0)

        def NUMBER(self):
            return self.getToken(mappingParser.NUMBER, 0)

        def STRING(self):
            return self.getToken(mappingParser.STRING, 0)

        def DATETIME(self):
            return self.getToken(mappingParser.DATETIME, 0)

        def DATE(self):
            return self.getToken(mappingParser.DATE, 0)

        def TIME(self):
            return self.getToken(mappingParser.TIME, 0)

        def BOOL(self):
            return self.getToken(mappingParser.BOOL, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_mapliteral

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapliteral" ):
                listener.enterMapliteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapliteral" ):
                listener.exitMapliteral(self)




    def mapliteral(self):

        localctx = mappingParser.MapliteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_mapliteral)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 395
            _la = self._input.LA(1)
            if not(((((_la - 91)) & ~0x3f) == 0 and ((1 << (_la - 91)) & 911) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GroupTypeModeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_groupTypeMode

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGroupTypeMode" ):
                listener.enterGroupTypeMode(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGroupTypeMode" ):
                listener.exitGroupTypeMode(self)




    def groupTypeMode(self):

        localctx = mappingParser.GroupTypeModeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_groupTypeMode)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 397
            _la = self._input.LA(1)
            if not(_la==29 or _la==30):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SourceListModeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_sourceListMode

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSourceListMode" ):
                listener.enterSourceListMode(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSourceListMode" ):
                listener.exitSourceListMode(self)




    def sourceListMode(self):

        localctx = mappingParser.SourceListModeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_sourceListMode)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 399
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 66571993088) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TargetListModeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_targetListMode

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTargetListMode" ):
                listener.enterTargetListMode(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTargetListMode" ):
                listener.exitTargetListMode(self)




    def targetListMode(self):

        localctx = mappingParser.TargetListModeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_targetListMode)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 401
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 216895848448) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InputModeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_inputMode

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInputMode" ):
                listener.enterInputMode(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInputMode" ):
                listener.exitInputMode(self)




    def inputMode(self):

        localctx = mappingParser.InputModeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_inputMode)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 403
            _la = self._input.LA(1)
            if not(_la==38 or _la==39):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ModelModeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_modelMode

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterModelMode" ):
                listener.enterModelMode(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitModelMode" ):
                listener.exitModelMode(self)




    def modelMode(self):

        localctx = mappingParser.ModelModeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_modelMode)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 405
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 4123168604160) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConceptMapContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def quoteidentifier(self):
            return self.getTypedRuleContext(mappingParser.QuoteidentifierContext,0)


        def prefix(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.PrefixContext)
            else:
                return self.getTypedRuleContext(mappingParser.PrefixContext,i)


        def conceptMapping(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ConceptMappingContext)
            else:
                return self.getTypedRuleContext(mappingParser.ConceptMappingContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_conceptMap

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConceptMap" ):
                listener.enterConceptMap(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConceptMap" ):
                listener.exitConceptMap(self)




    def conceptMap(self):

        localctx = mappingParser.ConceptMapContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_conceptMap)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 407
            _la = self._input.LA(1)
            if not(_la==42 or _la==43):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 408
            self.quoteidentifier()
            self.state = 409
            self.match(mappingParser.T__10)
            self.state = 411 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 410
                self.prefix()
                self.state = 413 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==44):
                    break

            self.state = 416 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 415
                self.conceptMapping()
                self.state = 418 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==53 or _la==95):
                    break

            self.state = 420
            self.match(mappingParser.T__11)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrefixContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def conceptMappingVar(self):
            return self.getTypedRuleContext(mappingParser.ConceptMappingVarContext,0)


        def url(self):
            return self.getTypedRuleContext(mappingParser.UrlContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_prefix

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrefix" ):
                listener.enterPrefix(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrefix" ):
                listener.exitPrefix(self)




    def prefix(self):

        localctx = mappingParser.PrefixContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_prefix)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 422
            self.match(mappingParser.T__43)
            self.state = 423
            self.conceptMappingVar()
            self.state = 424
            self.match(mappingParser.T__1)
            self.state = 425
            self.url()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConceptMappingVarContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_conceptMappingVar

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConceptMappingVar" ):
                listener.enterConceptMappingVar(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConceptMappingVar" ):
                listener.exitConceptMappingVar(self)




    def conceptMappingVar(self):

        localctx = mappingParser.ConceptMappingVarContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_conceptMappingVar)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 427
            self.match(mappingParser.IDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConceptMappingContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def conceptMappingVar(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ConceptMappingVarContext)
            else:
                return self.getTypedRuleContext(mappingParser.ConceptMappingVarContext,i)


        def field(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.FieldContext)
            else:
                return self.getTypedRuleContext(mappingParser.FieldContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_conceptMapping

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConceptMapping" ):
                listener.enterConceptMapping(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConceptMapping" ):
                listener.exitConceptMapping(self)




    def conceptMapping(self):

        localctx = mappingParser.ConceptMappingContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_conceptMapping)
        try:
            self.state = 448
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [95]:
                self.enterOuterAlt(localctx, 1)
                self.state = 429
                self.conceptMappingVar()
                self.state = 430
                self.match(mappingParser.T__18)
                self.state = 431
                self.field()

                self.state = 441
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [45]:
                    self.state = 432
                    self.match(mappingParser.T__44)
                    pass
                elif token in [46]:
                    self.state = 433
                    self.match(mappingParser.T__45)
                    pass
                elif token in [2]:
                    self.state = 434
                    self.match(mappingParser.T__1)
                    pass
                elif token in [47]:
                    self.state = 435
                    self.match(mappingParser.T__46)
                    pass
                elif token in [48]:
                    self.state = 436
                    self.match(mappingParser.T__47)
                    self.state = 437
                    self.match(mappingParser.T__48)
                    self.state = 438
                    self.match(mappingParser.T__49)
                    pass
                elif token in [51]:
                    self.state = 439
                    self.match(mappingParser.T__50)
                    pass
                elif token in [52]:
                    self.state = 440
                    self.match(mappingParser.T__51)
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 443
                self.conceptMappingVar()
                self.state = 444
                self.match(mappingParser.T__18)
                self.state = 445
                self.field()
                pass
            elif token in [53]:
                self.enterOuterAlt(localctx, 2)
                self.state = 447
                self.match(mappingParser.T__52)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FieldContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def QUOTEIDENTIFIER(self):
            return self.getToken(mappingParser.QUOTEIDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_field

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterField" ):
                listener.enterField(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitField" ):
                listener.exitField(self)




    def field(self):

        localctx = mappingParser.FieldContext(self, self._ctx, self.state)
        self.enterRule(localctx, 96, self.RULE_field)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 450
            _la = self._input.LA(1)
            if not(_la==95 or _la==96):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_expression

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class IndexerExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIndexerExpression" ):
                listener.enterIndexerExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIndexerExpression" ):
                listener.exitIndexerExpression(self)


    class PolarityExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(mappingParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPolarityExpression" ):
                listener.enterPolarityExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPolarityExpression" ):
                listener.exitPolarityExpression(self)


    class AdditiveExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAdditiveExpression" ):
                listener.enterAdditiveExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAdditiveExpression" ):
                listener.exitAdditiveExpression(self)


    class MultiplicativeExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultiplicativeExpression" ):
                listener.enterMultiplicativeExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultiplicativeExpression" ):
                listener.exitMultiplicativeExpression(self)


    class UnionExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnionExpression" ):
                listener.enterUnionExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnionExpression" ):
                listener.exitUnionExpression(self)


    class OrExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOrExpression" ):
                listener.enterOrExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOrExpression" ):
                listener.exitOrExpression(self)


    class AndExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAndExpression" ):
                listener.enterAndExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAndExpression" ):
                listener.exitAndExpression(self)


    class MembershipExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMembershipExpression" ):
                listener.enterMembershipExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMembershipExpression" ):
                listener.exitMembershipExpression(self)


    class InequalityExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInequalityExpression" ):
                listener.enterInequalityExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInequalityExpression" ):
                listener.exitInequalityExpression(self)


    class InvocationExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(mappingParser.ExpressionContext,0)

        def invocation(self):
            return self.getTypedRuleContext(mappingParser.InvocationContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInvocationExpression" ):
                listener.enterInvocationExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInvocationExpression" ):
                listener.exitInvocationExpression(self)


    class EqualityExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEqualityExpression" ):
                listener.enterEqualityExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEqualityExpression" ):
                listener.exitEqualityExpression(self)


    class ImpliesExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImpliesExpression" ):
                listener.enterImpliesExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImpliesExpression" ):
                listener.exitImpliesExpression(self)


    class TermExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def term(self):
            return self.getTypedRuleContext(mappingParser.TermContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTermExpression" ):
                listener.enterTermExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTermExpression" ):
                listener.exitTermExpression(self)


    class TypeExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(mappingParser.ExpressionContext,0)

        def typeSpecifier(self):
            return self.getTypedRuleContext(mappingParser.TypeSpecifierContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeExpression" ):
                listener.enterTypeExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeExpression" ):
                listener.exitTypeExpression(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = mappingParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 98
        self.enterRecursionRule(localctx, 98, self.RULE_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 456
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [5, 11, 16, 25, 60, 65, 66, 71, 72, 73, 74, 91, 92, 93, 94, 95, 97, 98, 99, 100]:
                localctx = mappingParser.TermExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 453
                self.term()
                pass
            elif token in [45, 56]:
                localctx = mappingParser.PolarityExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 454
                _la = self._input.LA(1)
                if not(_la==45 or _la==56):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 455
                self.expression(11)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 498
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,44,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 496
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,43,self._ctx)
                    if la_ == 1:
                        localctx = mappingParser.MultiplicativeExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 458
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 459
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 432345564231761928) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 460
                        self.expression(11)
                        pass

                    elif la_ == 2:
                        localctx = mappingParser.AdditiveExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 461
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 462
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 648553530713440256) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 463
                        self.expression(10)
                        pass

                    elif la_ == 3:
                        localctx = mappingParser.UnionExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 464
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 465
                        self.match(mappingParser.T__60)
                        self.state = 466
                        self.expression(8)
                        pass

                    elif la_ == 4:
                        localctx = mappingParser.InequalityExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 467
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 468
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & -4611052699729788928) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 469
                        self.expression(7)
                        pass

                    elif la_ == 5:
                        localctx = mappingParser.EqualityExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 470
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 471
                        _la = self._input.LA(1)
                        if not(((((_la - 2)) & ~0x3f) == 0 and ((1 << (_la - 2)) & 4612882287078408193) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 472
                        self.expression(6)
                        pass

                    elif la_ == 6:
                        localctx = mappingParser.MembershipExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 473
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 474
                        _la = self._input.LA(1)
                        if not(_la==65 or _la==66):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 475
                        self.expression(5)
                        pass

                    elif la_ == 7:
                        localctx = mappingParser.AndExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 476
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 477
                        self.match(mappingParser.T__66)
                        self.state = 478
                        self.expression(4)
                        pass

                    elif la_ == 8:
                        localctx = mappingParser.OrExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 479
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 480
                        _la = self._input.LA(1)
                        if not(_la==68 or _la==69):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 481
                        self.expression(3)
                        pass

                    elif la_ == 9:
                        localctx = mappingParser.ImpliesExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 482
                        if not self.precpred(self._ctx, 1):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                        self.state = 483
                        self.match(mappingParser.T__69)
                        self.state = 484
                        self.expression(2)
                        pass

                    elif la_ == 10:
                        localctx = mappingParser.InvocationExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 485
                        if not self.precpred(self._ctx, 13):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 13)")
                        self.state = 486
                        self.match(mappingParser.T__22)
                        self.state = 487
                        self.invocation()
                        pass

                    elif la_ == 11:
                        localctx = mappingParser.IndexerExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 488
                        if not self.precpred(self._ctx, 12):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 12)")
                        self.state = 489
                        self.match(mappingParser.T__53)
                        self.state = 490
                        self.expression(0)
                        self.state = 491
                        self.match(mappingParser.T__54)
                        pass

                    elif la_ == 12:
                        localctx = mappingParser.TypeExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 493
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 494
                        _la = self._input.LA(1)
                        if not(_la==5 or _la==60):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 495
                        self.typeSpecifier()
                        pass

             
                self.state = 500
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,44,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class TermContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_term

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ExternalConstantTermContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def externalConstant(self):
            return self.getTypedRuleContext(mappingParser.ExternalConstantContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExternalConstantTerm" ):
                listener.enterExternalConstantTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExternalConstantTerm" ):
                listener.exitExternalConstantTerm(self)


    class LiteralTermContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def literal(self):
            return self.getTypedRuleContext(mappingParser.LiteralContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteralTerm" ):
                listener.enterLiteralTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteralTerm" ):
                listener.exitLiteralTerm(self)


    class ParenthesizedTermContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(mappingParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParenthesizedTerm" ):
                listener.enterParenthesizedTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParenthesizedTerm" ):
                listener.exitParenthesizedTerm(self)


    class InvocationTermContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def invocation(self):
            return self.getTypedRuleContext(mappingParser.InvocationContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInvocationTerm" ):
                listener.enterInvocationTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInvocationTerm" ):
                listener.exitInvocationTerm(self)



    def term(self):

        localctx = mappingParser.TermContext(self, self._ctx, self.state)
        self.enterRule(localctx, 100, self.RULE_term)
        try:
            self.state = 508
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [5, 25, 60, 65, 66, 72, 73, 74, 95, 97]:
                localctx = mappingParser.InvocationTermContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 501
                self.invocation()
                pass
            elif token in [11, 91, 92, 93, 94, 98, 99, 100]:
                localctx = mappingParser.LiteralTermContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 502
                self.literal()
                pass
            elif token in [71]:
                localctx = mappingParser.ExternalConstantTermContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 503
                self.externalConstant()
                pass
            elif token in [16]:
                localctx = mappingParser.ParenthesizedTermContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 504
                self.match(mappingParser.T__15)
                self.state = 505
                self.expression(0)
                self.state = 506
                self.match(mappingParser.T__17)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_literal

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class TimeLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def TIME(self):
            return self.getToken(mappingParser.TIME, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTimeLiteral" ):
                listener.enterTimeLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTimeLiteral" ):
                listener.exitTimeLiteral(self)


    class NullLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNullLiteral" ):
                listener.enterNullLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNullLiteral" ):
                listener.exitNullLiteral(self)


    class DateTimeLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def DATETIME(self):
            return self.getToken(mappingParser.DATETIME, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDateTimeLiteral" ):
                listener.enterDateTimeLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDateTimeLiteral" ):
                listener.exitDateTimeLiteral(self)


    class StringLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(mappingParser.STRING, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringLiteral" ):
                listener.enterStringLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringLiteral" ):
                listener.exitStringLiteral(self)


    class IntegerLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INTEGER(self):
            return self.getToken(mappingParser.INTEGER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntegerLiteral" ):
                listener.enterIntegerLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntegerLiteral" ):
                listener.exitIntegerLiteral(self)


    class DateLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def DATE(self):
            return self.getToken(mappingParser.DATE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDateLiteral" ):
                listener.enterDateLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDateLiteral" ):
                listener.exitDateLiteral(self)


    class BooleanLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def BOOL(self):
            return self.getToken(mappingParser.BOOL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBooleanLiteral" ):
                listener.enterBooleanLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBooleanLiteral" ):
                listener.exitBooleanLiteral(self)


    class NumberLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMBER(self):
            return self.getToken(mappingParser.NUMBER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumberLiteral" ):
                listener.enterNumberLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumberLiteral" ):
                listener.exitNumberLiteral(self)


    class QuantityLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def quantity(self):
            return self.getTypedRuleContext(mappingParser.QuantityContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuantityLiteral" ):
                listener.enterQuantityLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuantityLiteral" ):
                listener.exitQuantityLiteral(self)



    def literal(self):

        localctx = mappingParser.LiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 102, self.RULE_literal)
        try:
            self.state = 520
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,46,self._ctx)
            if la_ == 1:
                localctx = mappingParser.NullLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 510
                self.match(mappingParser.T__10)
                self.state = 511
                self.match(mappingParser.T__11)
                pass

            elif la_ == 2:
                localctx = mappingParser.BooleanLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 512
                self.match(mappingParser.BOOL)
                pass

            elif la_ == 3:
                localctx = mappingParser.StringLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 513
                self.match(mappingParser.STRING)
                pass

            elif la_ == 4:
                localctx = mappingParser.NumberLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 514
                self.match(mappingParser.NUMBER)
                pass

            elif la_ == 5:
                localctx = mappingParser.IntegerLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 515
                self.match(mappingParser.INTEGER)
                pass

            elif la_ == 6:
                localctx = mappingParser.DateLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 516
                self.match(mappingParser.DATE)
                pass

            elif la_ == 7:
                localctx = mappingParser.DateTimeLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 517
                self.match(mappingParser.DATETIME)
                pass

            elif la_ == 8:
                localctx = mappingParser.TimeLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 8)
                self.state = 518
                self.match(mappingParser.TIME)
                pass

            elif la_ == 9:
                localctx = mappingParser.QuantityLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 9)
                self.state = 519
                self.quantity()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExternalConstantContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(mappingParser.IdentifierContext,0)


        def STRING(self):
            return self.getToken(mappingParser.STRING, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_externalConstant

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExternalConstant" ):
                listener.enterExternalConstant(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExternalConstant" ):
                listener.exitExternalConstant(self)




    def externalConstant(self):

        localctx = mappingParser.ExternalConstantContext(self, self._ctx, self.state)
        self.enterRule(localctx, 104, self.RULE_externalConstant)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 522
            self.match(mappingParser.T__70)
            self.state = 525
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [5, 60, 65, 66, 95, 97]:
                self.state = 523
                self.identifier()
                pass
            elif token in [98]:
                self.state = 524
                self.match(mappingParser.STRING)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InvocationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_invocation

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class TotalInvocationContext(InvocationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.InvocationContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTotalInvocation" ):
                listener.enterTotalInvocation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTotalInvocation" ):
                listener.exitTotalInvocation(self)


    class ThisInvocationContext(InvocationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.InvocationContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterThisInvocation" ):
                listener.enterThisInvocation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitThisInvocation" ):
                listener.exitThisInvocation(self)


    class IndexInvocationContext(InvocationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.InvocationContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIndexInvocation" ):
                listener.enterIndexInvocation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIndexInvocation" ):
                listener.exitIndexInvocation(self)


    class FunctionInvocationContext(InvocationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.InvocationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def function(self):
            return self.getTypedRuleContext(mappingParser.FunctionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionInvocation" ):
                listener.enterFunctionInvocation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionInvocation" ):
                listener.exitFunctionInvocation(self)


    class MemberInvocationContext(InvocationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.InvocationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def identifier(self):
            return self.getTypedRuleContext(mappingParser.IdentifierContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMemberInvocation" ):
                listener.enterMemberInvocation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMemberInvocation" ):
                listener.exitMemberInvocation(self)



    def invocation(self):

        localctx = mappingParser.InvocationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 106, self.RULE_invocation)
        try:
            self.state = 532
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,48,self._ctx)
            if la_ == 1:
                localctx = mappingParser.MemberInvocationContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 527
                self.identifier()
                pass

            elif la_ == 2:
                localctx = mappingParser.FunctionInvocationContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 528
                self.function()
                pass

            elif la_ == 3:
                localctx = mappingParser.ThisInvocationContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 529
                self.match(mappingParser.T__71)
                pass

            elif la_ == 4:
                localctx = mappingParser.IndexInvocationContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 530
                self.match(mappingParser.T__72)
                pass

            elif la_ == 5:
                localctx = mappingParser.TotalInvocationContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 531
                self.match(mappingParser.T__73)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(mappingParser.IdentifierContext,0)


        def paramList(self):
            return self.getTypedRuleContext(mappingParser.ParamListContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction" ):
                listener.enterFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction" ):
                listener.exitFunction(self)




    def function(self):

        localctx = mappingParser.FunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 108, self.RULE_function)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 536
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [5, 60, 65, 66, 95, 97]:
                self.state = 534
                self.identifier()
                pass
            elif token in [25]:
                self.state = 535
                self.match(mappingParser.T__24)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 538
            self.match(mappingParser.T__15)
            self.state = 540
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 1225014283050485792) != 0) or ((((_la - 65)) & ~0x3f) == 0 and ((1 << (_la - 65)) & 66504885187) != 0):
                self.state = 539
                self.paramList()


            self.state = 542
            self.match(mappingParser.T__17)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_paramList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParamList" ):
                listener.enterParamList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParamList" ):
                listener.exitParamList(self)




    def paramList(self):

        localctx = mappingParser.ParamListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 110, self.RULE_paramList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 544
            self.expression(0)
            self.state = 549
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==17:
                self.state = 545
                self.match(mappingParser.T__16)
                self.state = 546
                self.expression(0)
                self.state = 551
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class QuantityContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMBER(self):
            return self.getToken(mappingParser.NUMBER, 0)

        def INTEGER(self):
            return self.getToken(mappingParser.INTEGER, 0)

        def unit(self):
            return self.getTypedRuleContext(mappingParser.UnitContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_quantity

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuantity" ):
                listener.enterQuantity(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuantity" ):
                listener.exitQuantity(self)




    def quantity(self):

        localctx = mappingParser.QuantityContext(self, self._ctx, self.state)
        self.enterRule(localctx, 112, self.RULE_quantity)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 552
            _la = self._input.LA(1)
            if not(_la==99 or _la==100):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 554
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,52,self._ctx)
            if la_ == 1:
                self.state = 553
                self.unit()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnitContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def dateTimePrecision(self):
            return self.getTypedRuleContext(mappingParser.DateTimePrecisionContext,0)


        def pluralDateTimePrecision(self):
            return self.getTypedRuleContext(mappingParser.PluralDateTimePrecisionContext,0)


        def STRING(self):
            return self.getToken(mappingParser.STRING, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_unit

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnit" ):
                listener.enterUnit(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnit" ):
                listener.exitUnit(self)




    def unit(self):

        localctx = mappingParser.UnitContext(self, self._ctx, self.state)
        self.enterRule(localctx, 114, self.RULE_unit)
        try:
            self.state = 559
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [75, 76, 77, 78, 79, 80, 81, 82]:
                self.enterOuterAlt(localctx, 1)
                self.state = 556
                self.dateTimePrecision()
                pass
            elif token in [83, 84, 85, 86, 87, 88, 89, 90]:
                self.enterOuterAlt(localctx, 2)
                self.state = 557
                self.pluralDateTimePrecision()
                pass
            elif token in [98]:
                self.enterOuterAlt(localctx, 3)
                self.state = 558
                self.match(mappingParser.STRING)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DateTimePrecisionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_dateTimePrecision

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDateTimePrecision" ):
                listener.enterDateTimePrecision(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDateTimePrecision" ):
                listener.exitDateTimePrecision(self)




    def dateTimePrecision(self):

        localctx = mappingParser.DateTimePrecisionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 116, self.RULE_dateTimePrecision)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 561
            _la = self._input.LA(1)
            if not(((((_la - 75)) & ~0x3f) == 0 and ((1 << (_la - 75)) & 255) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PluralDateTimePrecisionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_pluralDateTimePrecision

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPluralDateTimePrecision" ):
                listener.enterPluralDateTimePrecision(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPluralDateTimePrecision" ):
                listener.exitPluralDateTimePrecision(self)




    def pluralDateTimePrecision(self):

        localctx = mappingParser.PluralDateTimePrecisionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 118, self.RULE_pluralDateTimePrecision)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 563
            _la = self._input.LA(1)
            if not(((((_la - 83)) & ~0x3f) == 0 and ((1 << (_la - 83)) & 255) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeSpecifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def qualifiedIdentifier(self):
            return self.getTypedRuleContext(mappingParser.QualifiedIdentifierContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_typeSpecifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeSpecifier" ):
                listener.enterTypeSpecifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeSpecifier" ):
                listener.exitTypeSpecifier(self)




    def typeSpecifier(self):

        localctx = mappingParser.TypeSpecifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 120, self.RULE_typeSpecifier)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 565
            self.qualifiedIdentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class QualifiedIdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.IdentifierContext)
            else:
                return self.getTypedRuleContext(mappingParser.IdentifierContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_qualifiedIdentifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQualifiedIdentifier" ):
                listener.enterQualifiedIdentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQualifiedIdentifier" ):
                listener.exitQualifiedIdentifier(self)




    def qualifiedIdentifier(self):

        localctx = mappingParser.QualifiedIdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 122, self.RULE_qualifiedIdentifier)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 567
            self.identifier()
            self.state = 572
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,54,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 568
                    self.match(mappingParser.T__22)
                    self.state = 569
                    self.identifier() 
                self.state = 574
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,54,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def DELIMITEDIDENTIFIER(self):
            return self.getToken(mappingParser.DELIMITEDIDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_identifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifier" ):
                listener.enterIdentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifier" ):
                listener.exitIdentifier(self)




    def identifier(self):

        localctx = mappingParser.IdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 124, self.RULE_identifier)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 575
            _la = self._input.LA(1)
            if not(_la==5 or _la==60 or ((((_la - 65)) & ~0x3f) == 0 and ((1 << (_la - 65)) & 5368709123) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[49] = self.expression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 10)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 2)
         

            if predIndex == 8:
                return self.precpred(self._ctx, 1)
         

            if predIndex == 9:
                return self.precpred(self._ctx, 13)
         

            if predIndex == 10:
                return self.precpred(self._ctx, 12)
         

            if predIndex == 11:
                return self.precpred(self._ctx, 8)
         




