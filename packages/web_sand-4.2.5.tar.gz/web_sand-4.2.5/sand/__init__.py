from gena.config import GenaConfig

GenaConfig.SERIALIZE_FOREIGN_KEY_FIELD_NAME = "db_field"
