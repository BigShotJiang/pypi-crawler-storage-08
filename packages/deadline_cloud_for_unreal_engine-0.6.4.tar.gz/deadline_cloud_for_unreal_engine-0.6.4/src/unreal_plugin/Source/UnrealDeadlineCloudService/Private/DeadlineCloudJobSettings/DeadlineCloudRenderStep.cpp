// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

#include "DeadlineCloudJobSettings/DeadlineCloudRenderStep.h"


UDeadlineCloudRenderStep::UDeadlineCloudRenderStep()
{
}
