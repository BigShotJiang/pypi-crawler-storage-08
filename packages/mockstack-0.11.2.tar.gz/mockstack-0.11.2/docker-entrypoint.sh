#!/bin/bash

# Any setup commands can go here
# For example:
# python -m alembic upgrade head

# Then run the command passed to the container
exec "$@"
