"""
Domain interfaces package.

This package contains interfaces for the domain layer.
"""
