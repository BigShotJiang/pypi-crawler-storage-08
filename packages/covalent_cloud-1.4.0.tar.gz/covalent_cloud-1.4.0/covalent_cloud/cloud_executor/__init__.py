# Copyright 2023 Agnostiq Inc.

from .models.gpu import GPU_TYPE
