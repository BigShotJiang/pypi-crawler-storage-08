# Copyright 2023 Agnostiq Inc.


from pydantic.dataclasses import dataclass


@dataclass
class SWEnvironment:
    pass
