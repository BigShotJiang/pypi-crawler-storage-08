
## Covalent Cloud SDK

[Covalent](https://github.com/AgnostiqHQ/covalent) is a python based workflow orchestration tool used to execute HPC and quantum tasks in heterogeneous environments.

Installing Covalent Cloud SDK gives users access to the enterprise version of Covalent.
