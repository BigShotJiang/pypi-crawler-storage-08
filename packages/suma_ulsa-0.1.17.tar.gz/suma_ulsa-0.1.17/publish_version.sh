maturin build --release 
maturin publish -r pypi