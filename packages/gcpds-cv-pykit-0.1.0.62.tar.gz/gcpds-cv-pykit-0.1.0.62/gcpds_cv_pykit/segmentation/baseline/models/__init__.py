from .UNet import UNet
from .FCN import FCN
from .DeepLabV3Plus import DeepLabV3Plus
from .ResUNet import ResUNet
