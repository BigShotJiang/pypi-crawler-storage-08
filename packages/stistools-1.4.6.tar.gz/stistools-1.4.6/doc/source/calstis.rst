.. _calstis:

**************************
calstis
**************************

.. currentmodule:: stistools.calstis

.. automodule:: stistools.calstis
   :members:
   :undoc-members:
