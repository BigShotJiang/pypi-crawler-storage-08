.. _tastis:

******
tastis
******

.. currentmodule:: stistools.tastis

.. automodule:: stistools.tastis
   :members:
