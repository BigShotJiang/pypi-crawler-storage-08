.. _evaldisp:

**************************
evaldisp
**************************

.. currentmodule:: stistools.evaldisp

.. automodule:: stistools.evaldisp
   :members:

