.. _ctestis:

*******
ctestis
*******

.. currentmodule:: stistools.ctestis

.. automodule:: stistools.ctestis
   :members:
