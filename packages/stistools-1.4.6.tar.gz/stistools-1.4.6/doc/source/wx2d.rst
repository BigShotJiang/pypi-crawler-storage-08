.. _wx2d:

**************************
wx2d
**************************

.. currentmodule:: stistools.wx2d

.. automodule:: stistools.wx2d
   :members:
   :undoc-members:

