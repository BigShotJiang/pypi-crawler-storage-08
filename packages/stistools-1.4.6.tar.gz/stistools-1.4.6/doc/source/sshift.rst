.. _sshift:

**************************
sshift
**************************

.. currentmodule:: stistools.sshift

.. automodule:: stistools.sshift
   :members:
   :undoc-members:

