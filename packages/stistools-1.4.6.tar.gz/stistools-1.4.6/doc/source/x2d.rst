.. _x2d:

**************************
x2d
**************************

.. currentmodule:: stistools.x2d

.. automodule:: stistools.x2d
   :members:
   :undoc-members:
