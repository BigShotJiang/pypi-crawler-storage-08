.. _gettable:

**************************
gettable
**************************

.. currentmodule:: stistools.gettable

.. automodule:: stistools.gettable
   :members:
   :undoc-members:

