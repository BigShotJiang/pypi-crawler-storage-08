.. _doppinfo:

********
doppinfo
********

.. currentmodule:: stistools.doppinfo

.. automodule:: stistools.doppinfo
    :members:
    :undoc-members:
