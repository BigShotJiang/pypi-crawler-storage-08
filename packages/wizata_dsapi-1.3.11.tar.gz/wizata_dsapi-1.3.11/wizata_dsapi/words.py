animals = [
    "Antelope", "Armadillo", "Alligator", "Cheetah", "Dolphin", "Elephant", "Firefly", "Flamingo", "Giraffe", "Hamster",
    "Kangaroo", "Koala", "Lemming", "Manatee", "Meerkat", "Mongoose", "Mosquito", "Ocelot", "Penguin", "Raccoon",
    "Salamander", "Starfish", "Termite", "Wallaby", "Walrus", "Weasel", "Wolverine", "Woodlouse", "Woodpecker", "Zebra",
    "Cat", "Dog", "Bat", "Fox", "Cow", "Pig", "Rat", "Mole", "Goat", "Fish",
    "Bird", "Frog", "Toad", "Wolf", "Bear", "Deer", "Lion", "Horse", "Mule", "Moth",
    "Mouse", "Sheep", "Snake", "Whale", "Shark", "Hawk", "Eagle", "Owl", "Crow", "Duck",
    "Swan", "Goose", "Puma", "Civet", "Seal", "Crab", "Fossa", "Hyena", "Tiger", "Jaguar",
    "Leopard", "Lizard", "Gibbon", "Gorilla", "Baboon", "Monkey", "Koala", "Panda", "Toucan", "Kiwi"
]

colors = [
    "Amaranth", "Amber", "Amethyst", "Apricot", "Aquamarine", "Azure", "Beige", "Black", "Blue", "Bronze",
    "Brown", "Carmine", "Cerise", "Cobalt", "Copper", "Coral", "Crimson", "Cyan", "Emerald", "Fuchsia",
    "Gold", "Gray", "Green", "Indigo", "Ivory", "Lavender", "Lemon", "Lilac", "Magenta", "Maroon",
    "Mauve", "Olive", "Orange", "Orchid", "Peach", "Periwinkle", "Pink", "Plum", "Purple", "Red",
    "Ruby", "Salmon", "Sapphire", "Scarlet", "Silver", "Tan", "Teal", "Turquoise", "Violet", "White", "Yellow",
    "Aqua", "Beige", "Coral", "Cyan", "Green", "Khaki", "Lemon", "Lilac", "Peach", "Plum", 
    "Salmon", "Teal", "Violet", "Wheat", "Bronze", "Copper", "Gold", "Silver", "Azure", "Pearl"
]
