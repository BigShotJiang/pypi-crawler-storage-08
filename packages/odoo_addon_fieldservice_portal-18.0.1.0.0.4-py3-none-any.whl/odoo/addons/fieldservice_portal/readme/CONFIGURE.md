Set Portal Visibility for Order Stages

You are able to control which stages of field service orders are visible
to portal users by enabling or disabling portal visiblity option on a
stage. By default, all stages are visible in the portal. Disable the
option to hide

1.  Go to Field Service \> Configuration \> Stages
2.  Select an order stage.
3.  Toggle the Visible in Portal option as desired
