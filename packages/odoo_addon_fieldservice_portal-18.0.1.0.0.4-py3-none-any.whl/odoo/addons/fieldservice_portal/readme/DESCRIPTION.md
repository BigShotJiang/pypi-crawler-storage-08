Bridge module between fieldservice and portal that allows portal users
to monitor work orders related to their locations.
