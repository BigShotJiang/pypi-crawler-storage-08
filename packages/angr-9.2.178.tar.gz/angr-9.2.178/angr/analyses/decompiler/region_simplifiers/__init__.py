from __future__ import annotations

from .region_simplifier import RegionSimplifier

__all__ = ("RegionSimplifier",)
