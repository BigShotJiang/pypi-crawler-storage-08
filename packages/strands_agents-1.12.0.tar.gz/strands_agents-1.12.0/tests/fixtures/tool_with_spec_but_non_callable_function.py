TOOL_SPEC = {"hello": "world"}

tool_with_spec_but_non_callable_function = "not a function!"
