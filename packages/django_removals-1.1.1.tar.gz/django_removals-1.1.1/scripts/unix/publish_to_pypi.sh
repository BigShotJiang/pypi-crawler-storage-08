#!/bin/bash
uv publish --publish-url https://test.pypi.org/legacy/
uv publish
