"""pylint-per-file-ignores plugin."""

from __future__ import annotations

from pylint_per_file_ignores._plugin import load_configuration, register

__all__ = ("load_configuration", "register")
