# Changelog

<!--
   You should *NOT* be adding new change log entries to this file.
   You should create a file in the news directory instead.
   For helpful instructions, please see:
   https://github.com/plone/plone.releaser/blob/master/ADD-A-NEWS-ITEM.rst
-->

<!-- towncrier release notes start -->

## 1.0.0b2 (2025-10-08)


### New features:

- Publish created rows folder @libargutxi [#4](https://github.com/collective/cs_dynamicpages/issues/4)

## 1.0.0b1 (2025-10-08)


### Internal:

- Initial release @codesyntax
