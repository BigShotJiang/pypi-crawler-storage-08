from tisit_keycloak_adapter.dependency_factory import (
    create_admin_dependency,
    create_auth_dependency,
    get_keycloak_backend_dependency,
)
