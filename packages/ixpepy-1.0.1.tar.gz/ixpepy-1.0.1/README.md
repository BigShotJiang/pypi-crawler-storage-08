# ixpepy

IXPE plugins for threeML
