"""Module for ABINIT workflows."""
