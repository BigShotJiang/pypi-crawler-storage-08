import timeit


timeit.timeit()
