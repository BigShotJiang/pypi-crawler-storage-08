=========
Changelog
=========

Version 0.1
===========

- initiate SiModIn!
- add interface
- add DWSIM and Tespy examples