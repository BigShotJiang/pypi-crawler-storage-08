"""NuCom - Numerical Computing Framework (reserved name)"""
__version__ = "0.0.0"
