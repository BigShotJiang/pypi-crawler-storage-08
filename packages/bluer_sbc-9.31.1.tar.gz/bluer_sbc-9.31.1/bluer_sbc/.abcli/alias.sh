#! /usr/bin/env bash

alias @camera=bluer_sbc_camera

alias grove=bluer_sbc_grove

alias @sbc=bluer_sbc
