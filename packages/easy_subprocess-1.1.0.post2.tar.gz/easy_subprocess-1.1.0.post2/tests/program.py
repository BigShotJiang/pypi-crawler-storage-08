while True:
    inp = input()
    print(inp, flush = True)
