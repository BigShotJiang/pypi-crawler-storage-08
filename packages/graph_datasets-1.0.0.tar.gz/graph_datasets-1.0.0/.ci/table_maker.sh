source .env/bin/activate
python -m docs.scripts.table_maker
