"""Provider-agnostic data loaders and URL resolvers.

This package replaces legacy modules under `flow._internal.data`.
"""
