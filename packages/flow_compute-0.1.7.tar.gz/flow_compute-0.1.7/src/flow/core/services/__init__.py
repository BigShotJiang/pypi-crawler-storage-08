"""Core service layer for business logic used by both CLI and SDK.

This package houses provider-agnostic services (status, pricing, etc.).
"""
