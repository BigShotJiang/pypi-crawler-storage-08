"""Core mounts pipeline modules (parser, validator, planner)."""
