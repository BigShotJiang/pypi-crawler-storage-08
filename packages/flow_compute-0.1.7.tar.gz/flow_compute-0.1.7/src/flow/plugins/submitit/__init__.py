"""Submitit frontend adapter for Flow SDK."""

from flow.plugins.submitit.adapter import SubmititFrontendAdapter

__all__ = ["SubmititFrontendAdapter"]
