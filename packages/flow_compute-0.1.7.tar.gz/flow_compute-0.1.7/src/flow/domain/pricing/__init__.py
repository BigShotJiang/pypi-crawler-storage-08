"""Domain pricing helpers.

Helper functions and types for pricing logic used internally by the domain.
"""
