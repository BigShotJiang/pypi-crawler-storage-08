"""Domain models package.

Provider-agnostic data structures used by the domain layer.
"""
