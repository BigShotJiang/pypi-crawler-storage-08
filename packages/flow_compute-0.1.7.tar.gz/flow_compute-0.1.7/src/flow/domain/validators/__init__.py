"""Domain validators package.

Pure validation logic; no imports from adapters or core modules.
"""
