"""Domain parsers package.

String parsing utilities used by domain models and validators.
"""
