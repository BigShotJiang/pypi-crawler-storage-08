"""Service layer for CLI commands.

Encapsulates non-UI business logic and provider interactions.
"""
