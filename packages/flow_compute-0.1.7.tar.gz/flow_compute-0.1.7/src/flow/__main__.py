"""Direct module execution support for flow."""

from flow.cli import main

if __name__ == "__main__":
    main()
