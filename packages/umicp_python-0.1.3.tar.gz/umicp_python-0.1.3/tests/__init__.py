"""UMICP Python bindings tests."""

