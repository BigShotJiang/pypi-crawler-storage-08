"""Persistence-Optimized Database"""

