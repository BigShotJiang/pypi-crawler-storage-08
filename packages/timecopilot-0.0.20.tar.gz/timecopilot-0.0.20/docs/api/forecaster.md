# `timecopilot.forecaster`

::: timecopilot.forecaster
    options:
        members:
            - TimeCopilotForecaster