
# `timecopilot.models.stats`

::: timecopilot.models.stats
    options:
        members:
            - ADIDA
            - AutoARIMA
            - AutoCES
            - AutoETS
            - CrostonClassic
            - DynamicOptimizedTheta
            - HistoricAverage
            - IMAPA
            - SeasonalNaive
            - Theta
            - ZeroModel