# `timecopilot.models.prophet`

::: timecopilot.models.prophet
    options:
        members:
            - Prophet