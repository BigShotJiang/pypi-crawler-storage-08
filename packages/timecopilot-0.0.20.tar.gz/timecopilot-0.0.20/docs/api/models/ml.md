
# `timecopilot.models.ml`

::: timecopilot.models.ml
    options:
        members:
            - AutoLGBM