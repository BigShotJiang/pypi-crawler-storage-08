# `timecopilot.models.foundation`

::: timecopilot.models.foundation.chronos
    options:
        members:
            - Chronos

::: timecopilot.models.foundation.flowstate
    options:
        members:
            - FlowState

::: timecopilot.models.foundation.moirai
    options:
        members:
            - Moirai

::: timecopilot.models.foundation.sundial
    options:
        members:
            - Sundial

::: timecopilot.models.foundation.tabpfn
    options:
        members:
            - TabPFN

::: timecopilot.models.foundation.timegpt
    options:
        members:
            - TimeGPT

::: timecopilot.models.foundation.timesfm
    options:
        members:
            - TimesFM

::: timecopilot.models.foundation.tirex
    options:
        members:
            - TiRex

::: timecopilot.models.foundation.toto
    options:
        members:
            - Toto