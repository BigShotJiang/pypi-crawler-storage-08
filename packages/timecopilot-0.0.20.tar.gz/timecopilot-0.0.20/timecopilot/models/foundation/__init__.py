from .timesfm import TimesFM

__all__ = [
    "TimesFM",
]
