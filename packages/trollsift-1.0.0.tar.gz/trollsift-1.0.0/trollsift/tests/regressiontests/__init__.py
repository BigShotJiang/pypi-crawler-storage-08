"""Regression tests for the trollsift package."""
