"""Integration tests for the trollsift package."""
