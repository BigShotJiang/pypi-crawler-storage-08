The :mod:`trollsift` API
===============================

trollsift parser
---------------------------

.. automodule:: trollsift.parser
   :members:
   :undoc-members:
