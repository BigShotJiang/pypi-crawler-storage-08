# Trollsift developers

The following people have made contributions to this project:

<!--- Use your GitHub account or any other personal reference URL --->
<!--- See https://gist.github.com/djhoese/52220272ec73b12eb8f4a29709be110d for auto-generating parts of this list --->

- [David Hoese (djhoese)](https://github.com/djhoese)
- [Panu Lahtinen (pnuu)](https://github.com/pnuu)
- [Martin Raspaud (mraspaud)](https://github.com/mraspaud)
- [Hrobjartur Thorsteinsson (thorsteinssonh)](https://github.com/thorsteinssonh)
- [Stephan Finkensieper (sfinkens)](https://github.com/sfinkens)
- [Paulo Medeiros (paulovcmedeiros)](https://github.com/paulovcmedeiros)
- [Regan Koopmans (Regan-Koopmans)](https://github.com/Regan-Koopmans)
