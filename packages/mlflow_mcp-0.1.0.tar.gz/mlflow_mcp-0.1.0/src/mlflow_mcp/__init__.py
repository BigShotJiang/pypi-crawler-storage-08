"""MLflow MCP Server - A Model Context Protocol server for MLflow."""

__version__ = "0.1.0"
