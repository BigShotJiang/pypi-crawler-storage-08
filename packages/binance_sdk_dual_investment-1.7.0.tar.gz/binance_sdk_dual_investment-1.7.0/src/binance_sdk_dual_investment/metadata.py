NAME = "binance-sdk-dual-investment"
