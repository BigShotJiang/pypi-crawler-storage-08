from justllms.routing.router import Router

__all__ = [
    "Router",
]
