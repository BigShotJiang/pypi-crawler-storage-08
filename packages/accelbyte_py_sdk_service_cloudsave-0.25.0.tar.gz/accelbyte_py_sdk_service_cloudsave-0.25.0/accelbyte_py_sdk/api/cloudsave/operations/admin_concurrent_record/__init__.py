# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Cloudsave Service."""

__version__ = "3.28.0"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .admin_put_admin_game_re_99ac43 import AdminPutAdminGameRecordConcurrentHandlerV1
from .admin_put_admin_player__e84e5d import AdminPutAdminPlayerRecordConcurrentHandlerV1
from .admin_put_game_record_c_886b02 import AdminPutGameRecordConcurrentHandlerV1
from .admin_put_player_public_1624a9 import (
    AdminPutPlayerPublicRecordConcurrentHandlerV1,
)
from .admin_put_player_record_233704 import AdminPutPlayerRecordConcurrentHandlerV1
