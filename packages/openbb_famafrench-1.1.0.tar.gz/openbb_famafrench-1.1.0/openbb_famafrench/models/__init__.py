"""OpenBB Fama-French Models."""
