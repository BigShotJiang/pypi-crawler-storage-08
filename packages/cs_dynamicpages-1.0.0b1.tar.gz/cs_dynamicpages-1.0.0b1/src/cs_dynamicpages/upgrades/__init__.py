import logging


logger = logging.getLogger("cs_dynamicpages")
