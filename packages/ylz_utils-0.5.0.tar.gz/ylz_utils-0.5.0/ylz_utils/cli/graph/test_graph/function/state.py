from langgraph.graph import MessagesState

class State(MessagesState):
    pass