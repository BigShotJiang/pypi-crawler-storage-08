class ConfigSchema:
    user_id:str
    llm_key:str
    llm_model:str
    embedding_key:str
    embedding_llm:str