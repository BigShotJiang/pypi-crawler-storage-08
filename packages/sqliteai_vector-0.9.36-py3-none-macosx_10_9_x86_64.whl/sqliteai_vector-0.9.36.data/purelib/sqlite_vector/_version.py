import os

__version__ = os.environ.get("PACKAGE_VERSION", "0.0.0")