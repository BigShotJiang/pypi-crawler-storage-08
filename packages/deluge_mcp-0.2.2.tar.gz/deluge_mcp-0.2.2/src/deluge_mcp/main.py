#!/usr/bin/env python3
import asyncio
import logging
import sys

from fastmcp import FastMCP

# Configure logging with more detail for debugging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stderr)],
)
logger = logging.getLogger("deluge-mcp")

# Create the FastMCP server
mcp = FastMCP("deluge-mcp")


async def run_deluge_command(command: str) -> str:
    """
    Run a deluge-console command asynchronously.

    Args:
        command: The deluge-console command to run

    Returns:
        Command output as string

    Raises:
        RuntimeError: If command fails
    """
    logger.debug(f"Running deluge command: {command}")
    try:
        process = await asyncio.create_subprocess_exec(
            "deluge-console",
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        stdout, stderr = await process.communicate()

        if process.returncode == 0:
            output = stdout.decode("utf-8").strip()
            logger.debug(f"Command succeeded. Output length: {len(output)}")
            return output
        else:
            error = stderr.decode("utf-8").strip()
            logger.error(
                f"Command failed with code {process.returncode}: {error}"
            )
            raise RuntimeError(f"Deluge command failed: {error}")

    except Exception as e:
        logger.error(f"Error running deluge command: {e}", exc_info=True)
        raise


@mcp.tool()
async def get_running_torrents() -> str:
    """
    Get information about all running torrents in Deluge.
    
    Returns details like name, state, progress, speeds, etc.
    """
    logger.info("Getting running torrents")
    output = await run_deluge_command("info")
    return f"Running Torrents:\n\n{output}"


@mcp.tool()
async def add_torrent_magnet(magnet_url: str) -> str:
    """
    Add a new torrent to Deluge using a magnet URL.
    
    Args:
        magnet_url: The magnet URL of the torrent to add (must start with 'magnet:')
    
    Returns:
        Success message with torrent details
    """
    logger.info(f"Adding torrent from magnet URL")
    
    # Validate magnet URL
    if not magnet_url.startswith("magnet:"):
        raise ValueError("Invalid magnet URL. Must start with 'magnet:'")
    
    # Add the torrent
    output = await run_deluge_command(f"add {magnet_url}")
    return f"Torrent added successfully!\n\nOutput: {output}"


if __name__ == "__main__":
    mcp.run()
    