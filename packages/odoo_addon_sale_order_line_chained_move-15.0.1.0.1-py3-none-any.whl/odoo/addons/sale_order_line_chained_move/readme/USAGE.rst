Navigate to Inventory > Configuration > Rules.

For each rule, select "Preserve Separate Sale Order Lines" if
you would like to have one move for each order line. Uncheck the
option if you're ok with Odoo merging lines with the same product.
