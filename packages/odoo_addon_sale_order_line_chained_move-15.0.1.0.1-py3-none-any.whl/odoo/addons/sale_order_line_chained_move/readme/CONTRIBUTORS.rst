* Denis Roussel <denis.roussel@acsone.eu>
* Ooops404
* PyTech SRL

    * Alessandro Uffreduzzi <alessandro.uffreduzzi@pytech.it>
