"""This is the writers submodule for writing output data and config parameters."""
