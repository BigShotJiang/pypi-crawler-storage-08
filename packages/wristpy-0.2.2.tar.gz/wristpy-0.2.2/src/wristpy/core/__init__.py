"""The core submodule contains key classes and functions.

These classes and functions are used to organize the pipeline processing
and provide functions for processing the various metrics and output analysis.
"""
