"""This is wristpy, a Python package for wrist-worn accelerometer data processing."""

__doc__ = (
    " For full documentation, please see: https://childmindresearch.github.io/wristpy/"
)
