"""
SUMA ULSA - Sistema Unificado de Métodos Avanzados
"""
# Importa directamente del módulo principal compilado
from .suma_ulsa import *

__version__ = "0.1.0"