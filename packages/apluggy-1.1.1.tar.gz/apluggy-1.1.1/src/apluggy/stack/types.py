import contextlib

GenCtxMngr = contextlib._GeneratorContextManager
AGenCtxMngr = contextlib._AsyncGeneratorContextManager
