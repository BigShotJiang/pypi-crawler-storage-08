__all__ = ["PluginManager"]

from .main import PluginManager
