"""CFTC provider extension utilities."""
