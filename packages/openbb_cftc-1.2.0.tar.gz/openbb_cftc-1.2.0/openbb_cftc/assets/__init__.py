"""CFTC Provider Module Static Assets."""
