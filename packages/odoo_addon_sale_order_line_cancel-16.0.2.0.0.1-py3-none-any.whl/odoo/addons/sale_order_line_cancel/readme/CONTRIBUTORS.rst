* Sylvain Van Hoof <sylvain@okia.be>
* Jacques-Etienne Baudoux (BCIM) <je@bcim.be>
* Souheil Bejaoui <souheil.bejaoui@acsone.eu.com>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Michael Tietz (MT Software) <mtietz@mt-software.de>
