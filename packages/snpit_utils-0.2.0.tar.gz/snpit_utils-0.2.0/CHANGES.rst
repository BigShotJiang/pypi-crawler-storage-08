.. towncrier release notes start

Package development begun 2025-05-12
=====================================================