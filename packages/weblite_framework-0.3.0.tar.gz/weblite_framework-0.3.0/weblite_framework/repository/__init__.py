"""Модуль репозиториев."""

from .base import BaseRepositoryClass

__all__ = ['BaseRepositoryClass']
