r"""
Neural network module
"""
