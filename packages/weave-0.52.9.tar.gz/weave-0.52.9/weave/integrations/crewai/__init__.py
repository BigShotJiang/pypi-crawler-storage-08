from weave.integrations.crewai.crewai_sdk import get_crewai_patcher  # noqa: F401
