ALTER TABLE calls_merged DROP INDEX idx_wb_run_id;
