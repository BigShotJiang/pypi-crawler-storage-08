from e2b import Sandbox

sandbox = Sandbox.create()
sandbox.close()
