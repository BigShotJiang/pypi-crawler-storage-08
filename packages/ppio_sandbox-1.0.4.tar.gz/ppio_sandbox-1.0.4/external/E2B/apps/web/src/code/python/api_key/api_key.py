from e2b import Sandbox

sandbox = Sandbox(api_key="YOUR_API_KEY")
sandbox.close()
