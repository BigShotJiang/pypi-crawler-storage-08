// We are in the process of migrating to the new landing page hosting.
export const landingPageHostname = 'www.e2b-landing-page.com'
export const landingPageFramerHostname = 'e2b-landing-page.framer.website'
export const blogFramerHostname = 'e2b-blog.framer.website'
export const changelogFramerHostname = 'e2b-changelog.framer.website'
