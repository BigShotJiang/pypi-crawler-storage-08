export const config = {
  github: {
    url: 'https://github.com/e2b-dev/e2b',
    api: 'https://api.github.com/repos/e2b-dev/e2b',
  },
  twitter: {
    url: 'https://x.com/e2b',
  },
}
