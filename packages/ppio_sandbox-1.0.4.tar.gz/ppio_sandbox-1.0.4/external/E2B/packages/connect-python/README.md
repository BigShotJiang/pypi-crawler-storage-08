🚧 Currently pending [an open RFC to be moved into the Connect RPC org](https://github.com/connectrpc/connectrpc.com/pull/71). Please show support. 🚧

---

# connect-python

Python client implementation for the [Connect](https://connect.build) RPC protocol.
