# Integration test template

# Build the template

`$ e2b template build -c "cd /basic-nextjs-app/ && sudo npm run dev"`
