export const defaultDockerfileName = 'e2b.Dockerfile'
export const fallbackDockerfileName = 'Dockerfile'

export const basicDockerfile = `# You can use most Debian-based base images
FROM ubuntu:22.04

# Install dependencies and customize sandbox
`
