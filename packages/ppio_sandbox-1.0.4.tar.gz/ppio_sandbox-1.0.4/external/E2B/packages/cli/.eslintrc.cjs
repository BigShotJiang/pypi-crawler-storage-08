module.exports = {
  root: true,
  extends: '../../.eslintrc.cjs',
}
