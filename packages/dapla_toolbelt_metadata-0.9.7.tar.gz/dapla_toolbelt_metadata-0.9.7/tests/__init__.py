"""Test suite for the dapla_toolbelt_metadata package."""
