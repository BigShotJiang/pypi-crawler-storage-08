from qcio import *  # noqa: F403


def test_imports():
    """Checking that import * above in module works."""
    assert True
