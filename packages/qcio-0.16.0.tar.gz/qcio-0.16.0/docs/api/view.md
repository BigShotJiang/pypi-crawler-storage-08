::: qcio.view
    options:
        members: 
            - view
            - program_outputs
            - structures
            - generate_structure_viewer_html
            - generate_output_table
            - generate_optimization_plot
            - generate_results_table
            - DEFAULT_WIDTH
            - DEFAULT_HEIGHT