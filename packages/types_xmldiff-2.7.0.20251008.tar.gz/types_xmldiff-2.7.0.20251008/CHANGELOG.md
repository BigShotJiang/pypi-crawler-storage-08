## 2.7.0.20251008 (2025-10-08)

Add types for xmldiff ([#14822](https://github.com/python/typeshed/pull/14822))

