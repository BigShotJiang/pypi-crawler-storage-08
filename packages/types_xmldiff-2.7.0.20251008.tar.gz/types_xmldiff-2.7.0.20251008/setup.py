
from setuptools import setup

setup(package_data={'xmldiff-stubs': ['__init__.pyi', 'actions.pyi', 'diff.pyi', 'diff_match_patch.pyi', 'formatting.pyi', 'main.pyi', 'patch.pyi', 'utils.pyi', 'METADATA.toml', 'py.typed']})
