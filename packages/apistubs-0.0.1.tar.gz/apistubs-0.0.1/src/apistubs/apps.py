from django.apps import AppConfig

__all__ = (
    'APIStubsConfig',
)


class APIStubsConfig(AppConfig):
    name = 'apistubs'
