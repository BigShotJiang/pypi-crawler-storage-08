
__all__ = (
    'METHODS',
)


METHODS = ['post', 'get', 'patch', 'delete', 'put', 'head']
