from django.apps import AppConfig


class DbpresetConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apistubs.dbpreset'
