# nifti_dynamic

A Python package for dynamic NIFTI analysis.

## Installation

```bash
pip install nifti_dynamic
```

## Usage

See example.py


