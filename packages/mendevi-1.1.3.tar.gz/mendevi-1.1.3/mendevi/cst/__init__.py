#!/usr/bin/env python3

"""Define the constants."""

from .profiles import PROFILES

__all__ = ["PROFILES"]
