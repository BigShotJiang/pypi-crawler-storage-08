#!/usr/bin/env python3

"""Mesures d'Encodage et Décodage Vidéo."""

from .measures import Activity


__all__ = ["Activity"]
__author__ = "Robin RICHARD (robinechuca)"
__version__ = "1.1.3"  # pep 440
