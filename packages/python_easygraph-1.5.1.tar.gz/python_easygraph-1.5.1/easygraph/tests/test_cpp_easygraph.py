#!/usr/bin/env python3
#
# from pathlib import Path
# from subprocess import run
#
#
# script_test_cpp_easygraph_path = Path(__file__).parent / "script_test_cpp_easygraph.py"
#
#
# def test_cpp_easygraph():
#     p = run(["python3", str(script_test_cpp_easygraph_path)])
#     assert p.returncode == 0
