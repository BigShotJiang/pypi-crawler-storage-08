#pragma once

#include "../../common/common.h"

py::object average_degree(py::object G);