#pragma once

#include "../common/common.h"

py::object density(py::object G);