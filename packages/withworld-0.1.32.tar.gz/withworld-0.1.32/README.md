It my favorite function for working.
dist to DELETE and CHANGE VERSION
python -m build
twine upload dist/*