from enum import Enum


class GetPurchaseOrderAdditionalCostRowsDistributionMethod(str, Enum):
    BY_VALUE = "BY_VALUE"
    NON_DISTRIBUTED = "NON_DISTRIBUTED"

    def __str__(self) -> str:
        return str(self.value)
