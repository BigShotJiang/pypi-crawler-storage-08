fashionstar uart sdk for python
