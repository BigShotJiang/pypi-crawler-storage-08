"""
Entry point for JONAS when run as a module.
"""

from .cli import main

if __name__ == "__main__":
    main()
