"""
JONAS - Just Operate Nicely And Securely

Ein intelligenter Shell-Assistent mit OpenAI Integration.
"""

__version__ = "1.4.2"
__author__ = "Peter Filz"
__email__ = "peter.filz@googlemail.com"
