/**
 * http://www.privacyidea.org
 * (c) cornelius kölbel, cornelius@privacyidea.org
 *
 * 2015-01-11 Cornelius Kölbel, <cornelius@privacyidea.org>
 *
 * This code is free software; you can redistribute it and/or
 * modify it under the terms of the GNU AFFERO GENERAL PUBLIC LICENSE
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU AFFERO GENERAL PUBLIC LICENSE for more details.
 *
 * You should have received a copy of the GNU Affero General Public
 * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
angular.module("privacyideaAuth", ['privacyideaApp.errorMessage'])
    .factory("AuthFactory", ["inform", "gettextCatalog", "$state",
        function (inform, gettextCatalog, $state) {
            /*
            Each service - just like this service factory - is a singleton.
            Here we just store the username of the authenticated user and his
            auth_token.
             */
            let user = {};

            return {
                setUser: function (username, realm, auth_token, role, rights, menus) {
                    user.username = username;
                    user.realm = realm;
                    user.auth_token = auth_token;
                    user.role = role;
                    user.rights = rights;
                    user.menus = menus;
                    user.isAdmin = (role === "admin");
                },
                authError: function (error) {
                    const authErrorCodes = Array(403, 4031, 4032, 4033, 4034, 4035, 4036);
                    if (error === null) {
                        console.warn('No error object available, maybe the request was aborted?');
                        return;
                    }
                    if (typeof (error) === "string") {
                        inform.add(gettextCatalog.getString("Failed to get a valid JSON response from the privacyIDEA server."),
                            {type: "danger", ttl: 10000});
                        console.warn(error);
                    } else {
                        inform.add(error.result.error.message, {type: "danger", ttl: 10000});
                        if (authErrorCodes.indexOf(error.result.error.code) >= 0) {
                            if ($state.current.controller === "registerController") {
                                $state.go('register');
                            } else if ($state.current.controller === "recoveryController") {
                                $state.go('recovery');
                            } else {
                                $state.go('login');
                            }
                        }
                        // If the error is 4305 Signature expired, redirect to login
                        else if (error.result.error.code === 4305) {
                            $state.go('login');
                        }
                    }
                },
                dropUser: function () {
                    user = {};
                },
                getUser: function () {
                    return user;
                },
                getRealm: function () {
                    return user.realm;
                },
                getAuthToken: function () {
                    return user.auth_token;
                },
                getRole: function () {
                    return user.role;
                },
                checkRight: function (action) {
                    if (user.rights) {
                        // check if the action is contained in user.rights
                        ////debug: console.log("checking right: " + action + ": " + res);
                        return (user.rights.indexOf(action) >= 0);
                    }
                },
                getRightsValue: function (action, defaultValue = false) {
                    // return the value of an action like otp_pin_minlength
                    let res = defaultValue;
                    if (user.rights) {
                        user.rights.forEach(function (entry) {
                            if (entry.indexOf("=") >= 0) {
                                // this is a value action
                                const components = entry.split("=");
                                if (components[0] === action) {
                                    res = components[1];
                                }
                            }
                        });
                    }
                    return res;
                },
                checkMainMenu: function (menu) {
                    return (user.menus.indexOf(menu) >= 0);
                },
                checkEnroll: function () {
                    // Check if any enroll* action is contained in user.rights
                    let res = false;
                    if (user.rights) {
                        user.rights.forEach(function (entry) {
                            // check if the action starts with "enroll"
                            if (entry.indexOf("enroll") === 0) {
                                res = true;
                            }
                        });
                    }
                    return res;
                }
            };
        }]);

//
// Taken from
// https://timesheets.altamiracorp.com/blog/employee-posts/simple-polling-service-in-angularjs
angular.module('privacyideaAuth')
    .factory('PollingAuthFactory', ['$http', 'authUrl', function ($http,
                                                                  authUrl) {
        const pollingTime = 1000;
        const polls = {};
        // We only need one poller
        const name = "authPoller";

        return {
            start: function (polling_func) {
                // Check to make sure poller doesn't already exist
                if (!polls[name]) {
                    polls[name] = setInterval(polling_func, pollingTime);
                }
            },

            stop: function () {
                clearInterval(polls[name]);
                delete polls[name];
            }
        };
    }]);
