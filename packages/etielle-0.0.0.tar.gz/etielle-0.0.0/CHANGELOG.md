# CHANGELOG


## v0.1.1 (2025-10-10)

### Bug Fixes

- Remove private classifier
  ([`5b2a23c`](https://github.com/Promptly-Technologies-LLC/etielle/commit/5b2a23c0fd16c3add2d26e05a565e2918a52575a))


## v0.1.0 (2025-10-10)

### Bug Fixes

- Declare environment
  ([`3f6d1d3`](https://github.com/Promptly-Technologies-LLC/etielle/commit/3f6d1d368d0ffa8aed6445412e8a6fd01260e223))

### Features

- Refactored module organization
  ([`faf2932`](https://github.com/Promptly-Technologies-LLC/etielle/commit/faf2932bac73ee5f69b71cca87197b15d7209aeb))
