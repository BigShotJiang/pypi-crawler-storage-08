"""Tests for noctua-py."""
