def main() -> None:
    print("Hello from specflow!")
