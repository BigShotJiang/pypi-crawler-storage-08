# shoestring_assembler
