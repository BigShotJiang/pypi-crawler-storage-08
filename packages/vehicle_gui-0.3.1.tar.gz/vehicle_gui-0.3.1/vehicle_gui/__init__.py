import os
from vehicle_gui.counter_example_view.base_renderer import BaseRenderer

__all__ = ["BaseRenderer"]

VEHICLE_DIR = os.path.join(os.path.expanduser("~"), ".vehicle", "GUI")