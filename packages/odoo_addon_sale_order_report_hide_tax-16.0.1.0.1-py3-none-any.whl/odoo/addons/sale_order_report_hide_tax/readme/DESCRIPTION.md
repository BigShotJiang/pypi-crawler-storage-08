Hide taxes column in the quotation document that is sent to the customer.
