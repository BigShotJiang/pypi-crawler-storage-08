#pragma once

namespace scaler {
namespace object_storage {

int getAvailableTCPPort();

};  // namespace object_storage
};  // namespace scaler
