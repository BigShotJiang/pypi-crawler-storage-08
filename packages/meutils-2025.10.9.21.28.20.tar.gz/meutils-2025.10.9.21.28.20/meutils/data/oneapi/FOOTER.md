<div class="custom-footer">@2025  <a href="https://api.chatfire.cn">🔥ChatfireAPI</a>  由火宝AI出品 
| <a href="https://api.chatfire.cn" target="_blank">支持对公&发票</a> 
| <a href="https://api.chatfire.cn" target="_blank">提供模型定制化服务</a> 
| <a href="https://api.chatfire.cn" target="_blank">个性化智能体</a> 
|  🛎<a href="https://cdn.apifox.com/app/apidoc-image/custom/20241110/f36e2152-b4fb-43be-a33d-a380b4d97ef6.jpeg" target="_blank">企微客服，咨询更多</a>

</div>