# AutoMod
*Auto*mated *Mod*ification and crossover placement for the design of curved DNA origami structures.
