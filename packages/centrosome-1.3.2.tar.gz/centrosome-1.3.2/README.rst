centrosome
==========

.. image:: https://travis-ci.org/CellProfiler/centrosome.svg?branch=master
    :target: https://travis-ci.org/CellProfiler/centrosome

.. image:: https://codeclimate.com/github/CellProfiler/centrosome/badges/gpa.svg
   :target: https://codeclimate.com/github/CellProfiler/centrosome
   :alt: Code Climate
