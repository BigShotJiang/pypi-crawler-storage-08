class Pys:
    pass