"""EDF Iron Core Library"""
