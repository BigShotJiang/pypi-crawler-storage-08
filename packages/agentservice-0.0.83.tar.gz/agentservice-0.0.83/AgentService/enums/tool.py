
import enum


class ToolResponse(enum.Enum):
    retry = "retry"
