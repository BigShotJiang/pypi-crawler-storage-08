
import enum


class AgentResponseType(enum.Enum):
    tools = "tools"
    answer = "answer"
