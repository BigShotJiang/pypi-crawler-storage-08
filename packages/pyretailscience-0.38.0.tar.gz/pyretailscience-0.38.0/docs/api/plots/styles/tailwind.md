# Tailwind Colors

::: pyretailscience.plots.styles.tailwind
