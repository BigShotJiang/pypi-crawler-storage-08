from django.apps import AppConfig


class DjangoAppConfig(AppConfig):
    name = "w.tests.fixtures.datasets.django_app"
