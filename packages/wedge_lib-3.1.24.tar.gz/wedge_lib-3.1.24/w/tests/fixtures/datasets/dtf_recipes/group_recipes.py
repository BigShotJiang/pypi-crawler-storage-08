from w.django.tests.factories.auth_factories import GroupFactory

base_group = {"factory": GroupFactory}
