# PASL
PASL (Python As a Scripting Language) is a cross-platform project dedicated to allowing easier use of Python as a scripting language, mainly with the goal of replacing .sh or .ps1.