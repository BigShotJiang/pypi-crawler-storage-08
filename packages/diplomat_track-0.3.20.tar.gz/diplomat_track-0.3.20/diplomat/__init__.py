"""
A tool providing multi-animal tracking capabilities on top of other Deep learning based tracking software.
"""

__version__ = "0.3.20"

import warnings

# Can be used by functions to determine if diplomat was invoked through it's CLI interface.
CLI_RUN = False

from diplomat.predictor_ops import (
    list_predictor_plugins,
    get_predictor_settings,
    test_predictor_plugin,
)
from diplomat.frontend_ops import list_all_frontends, list_loaded_frontends
from diplomat.utils.video_splitter import split_videos
from diplomat.core_ops import (
    track_with,
    track,
    track_and_interact,
    annotate,
    tweak,
    yaml,
    interact,
    convert_tracks,
)

__all__ = [
    "list_predictor_plugins",
    "get_predictor_settings",
    "test_predictor_plugin",
    "list_all_frontends",
    "list_loaded_frontends",
    "split_videos",
    "track_with",
    "track_and_interact",
    "track",
    "annotate",
    "tweak",
    "yaml",
    "interact",
    "convert_tracks",
]

# Attempt to load all frontends, putting their public functions into submodules of diplomat.
def _load_frontends():
    from diplomat import frontends
    from diplomat.frontends import DIPLOMATFrontend
    from diplomat.utils.pluginloader import load_plugin_classes
    from diplomat.utils._function_tools import replace_function_name_and_module
    from types import ModuleType
    from multiprocessing import current_process

    if current_process().name != "MainProcess":
        # If something in this package is using multiprocessing, disable the automatic frontend loading code.
        # This is done because some to save memory...
        return (set(), {})

    frontends = load_plugin_classes(frontends, DIPLOMATFrontend, recursive=False)
    loaded_funcs = {}

    for frontend in frontends:
        res = None
        try:
            res = frontend.init()
        except ImportError:
            import traceback

            warnings.warn(
                f"Can't load frontend '{frontend}'. Due to issue below: \n {traceback.format_exc()}",
                ImportWarning,
            )

        if res is not None:
            name = frontend.get_package_name()
            mod = ModuleType(__name__ + "." + name)
            mod.__all__ = []

            globals()[name] = mod
            loaded_funcs[name] = res

            if hasattr(frontend, "__doc__"):
                mod.__doc__ = frontend.__doc__

            for name, func in res:
                if not name.startswith("_"):
                    func = replace_function_name_and_module(func, name, mod.__name__)
                    setattr(mod, name, func)
                    mod.__all__.append(name)

    return frontends, loaded_funcs


def _move_core_functions():
    # We change module of core functions to be the root module...
    for item in __all__:
        core_func = globals()[item]
        core_func.__module__ = _move_core_functions.__module__


_move_core_functions()
_FRONTENDS, _LOADED_FRONTENDS = _load_frontends()
