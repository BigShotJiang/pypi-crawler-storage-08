# Streamlit Bar Visualizer

Audio frequency visualizer component for Streamlit, inspired by ElevenLabs UI design.

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Python](https://img.shields.io/badge/python-3.8+-blue.svg)

## Installation

```bash
pip install streamlit-bar-visualizer
```

## Quick Start

```python
from streamlit_bar_visualizer import bar_visualizer

# Basic usage
bar_visualizer(state="listening")

# With audio stream
bar_visualizer(
    state="speaking",
    stream_url="https://stream.live.vc.bbcmedia.co.uk/bbc_world_service"
)

# Auto mode - automatically changes state based on audio playback
bar_visualizer(
    state="auto",
    stream_url="https://stream.live.vc.bbcmedia.co.uk/bbc_world_service"
)
```

## API

### `bar_visualizer(state, stream_url, key)`

**Parameters:**
- `state` (str): Animation state
  - `"listening"` - Breathing animation
  - `"speaking"` - Active speaking animation
  - `"thinking"` - Pulsing animation
  - `"connecting"` - Wave animation
  - `"initializing"` - Building up animation
  - `"auto"` - Auto-switch based on audio playback (thinking → speaking → initializing)
- `stream_url` (str, optional): Audio stream URL to visualize
- `key` (str, optional): Unique component identifier

**Returns:** Current component state (str)

## Development

```bash
# Install dependencies
cd streamlit_bar_visualizer/frontend
npm install

# Start dev server
npm run start

# Build for production
npm run build
```

## License

MIT

