import os
import streamlit.components.v1 as components

# Create a _RELEASE constant. We'll set this to False while we're developing
# the component, and True when we're ready to package and distribute it.
_RELEASE = True

if not _RELEASE:
    _component_func = components.declare_component(
        "bar_visualizer",
        url="http://localhost:3001",
    )
else:
    parent_dir = os.path.dirname(os.path.abspath(__file__))
    build_dir = os.path.join(parent_dir, "frontend/build")
    _component_func = components.declare_component("bar_visualizer", path=build_dir)


def bar_visualizer(
    state="listening",
    stream_url=None,
    key=None,
):
    """Display an audio frequency visualizer with animated state transitions.
    
    Parameters
    ----------
    state : str
        Voice assistant state: "connecting", "initializing", "listening", "speaking", "thinking", "auto"
        - "auto": Automatically switch states based on audio playback:
          * thinking: Audio loading
          * speaking: Audio playing
          * initializing: Audio ended
        Default: "listening"
    demo : bool
        Enable demo mode with fake audio data.
        Default: True
    stream_url : str or None
        URL of an audio stream to visualize. If provided, the component will
        visualize this stream instead of using the microphone.
        Default: None
    key : str or None
        An optional key that uniquely identifies this component. If this is
        None, and the component's arguments are changed, the component will
        be re-mounted in the Streamlit frontend and lose its current state.

    Returns
    -------
    str
        The current state of the component
    """
    component_value = _component_func(
        state=state,
        barCount=20,
        minHeight=15,
        maxHeight=90,
        demo=True,
        centerAlign=True,
        streamUrl=stream_url,
        key=key,
        default=state,
    )
    return component_value


__all__ = ["bar_visualizer"]

