# Changelog

## 1.0.0 (2025-10-07)

Full Changelog: [v0.0.1...v1.0.0](https://github.com/deeprails/deeprails-python-sdk/compare/v0.0.1...v1.0.0)

### Chores

* update SDK settings ([3dcb5cb](https://github.com/deeprails/deeprails-python-sdk/commit/3dcb5cb41ee6c1008f66dace32125fd38626bdca))
* update SDK settings ([b283586](https://github.com/deeprails/deeprails-python-sdk/commit/b28358658ea8cbea0d2cb679343a9cf1c342fbd2))
