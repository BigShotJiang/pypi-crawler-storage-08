from django.apps import AppConfig


class AuthCheckConfig(AppConfig):
	name = 'notalib.django_xauth'
