BOM = b'\xEF\xBB\xBF'		# Can be replaced with codecs.BOM_UTF8
