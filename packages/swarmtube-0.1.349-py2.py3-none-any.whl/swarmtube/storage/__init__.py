"""
@tags: Hexagonal, port, pydantic

This module contains all persistence ports needed to store and retrieve
processed data from logic to other

"""

# TODO: implement as 2nd ports
