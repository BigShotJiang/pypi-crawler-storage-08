from altscore.altdata.model.common_schemas import SourceConfig
from altscore.altdata.model.data_request import InputKeys
