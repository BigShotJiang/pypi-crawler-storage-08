import struct

h = struct.Struct("<h")
I = struct.Struct("<I")  # noqa: E741
H = struct.Struct("<H")
Q = struct.Struct("<Q")
i = struct.Struct("<i")
B = struct.Struct("!B")
B_ = struct.Struct("B")
HBB = struct.Struct("<HBB")
iB = struct.Struct("<iB")
IIB = struct.Struct("<IIB")
iIB23s = struct.Struct("<iIB23s")
BHHB = struct.Struct("<BHHB")
HB = struct.Struct("<HB")
xHIBHBxx = struct.Struct("<xHIBHBxx")
xhh = struct.Struct("<xhh")
HH = struct.Struct("<HH")
