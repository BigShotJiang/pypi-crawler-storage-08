# -*- coding: utf-8 -*-

from .tasks_manager import TaskResult, TasksManager


__all__ = [
    "TaskResult",
    "TasksManager",
]
