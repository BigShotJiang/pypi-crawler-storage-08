# pybot-gram

Telegram bot control library for server management.

## Installation

```bash
pip install pybot_gramesezz
