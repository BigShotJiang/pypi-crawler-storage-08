class Defines:
    timeout = 20