Software Heritage Datasets
==========================

This page lists the different public datasets and periodic data dumps of the
archive produced and released by `Software Heritage`_.

.. _Software Heritage: https://www.softwareheritage.org
