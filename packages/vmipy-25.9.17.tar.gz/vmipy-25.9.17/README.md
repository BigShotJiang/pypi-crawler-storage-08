# vmipy

[![Upload Python Package](https://github.com/openvmi/vmipy/actions/workflows/python-publish.yml/badge.svg)](https://github.com/openvmi/vmipy/actions/workflows/python-publish.yml)

SDK for openvmi org.

## Note

To reduce the installation issue, please install the below dependency by maunal if need to use `ohand` or  `gforce` SDK:

* bleak==0.20.2
* bleak-winrt==1.2.0
* numpy==1.25.2