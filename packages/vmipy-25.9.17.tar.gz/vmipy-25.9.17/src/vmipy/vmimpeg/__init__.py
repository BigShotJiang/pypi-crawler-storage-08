from ._stream import startMpegStream

__version__ = "0.1.0"