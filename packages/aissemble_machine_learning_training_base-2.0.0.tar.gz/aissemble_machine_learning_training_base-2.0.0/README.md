## aiSSEMBLE&trade; Test Data Delivery PySpark Model

[![PyPI](https://img.shields.io/pypi/v/aissemble-machine-learning-training-base?logo=python&logoColor=gold)](https://pypi.org/project/aissemble-machine-learning-training-base/)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/aissemble-machine-learning-training-base?logo=python&logoColor=gold)
![PyPI - Wheel](https://img.shields.io/pypi/wheel/aissemble-machine-learning-training-base?logo=python&logoColor=gold)

This module is for testing purposes and is not intended for direct reuse.