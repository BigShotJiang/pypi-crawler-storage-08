# LangBot to Plugin Runtime API Definition

## `list_plugins`

### Request

```json
{}
```

### Response

```json
{
    "plugins": [
        {
            "id": "plugin_id",
            "name": "plugin_name",
            "version": "plugin_version"
        }
    ]
}
```

## `install_plugin`

### Request

```json
```

### Response

```json
```

## `emit_event`

### Request

```json
```

### Response

```json
```

## `list_tools`

### Request

```json
```

### Response

```json
```

## `call_tool`

### Request

```json
```

### Response

```json
```