# Get Started with Microsoft Agent Framework Azure AI

Please install this package via pip:

```bash
pip install agent-framework-azure-ai --pre
```

and see the [README](https://github.com/microsoft/agent-framework/tree/main/python/README.md) for more information.
