..
    SPDX-FileCopyrightText: 2017 Free Software Foundation Europe e.V. <https://fsfe.org>

    SPDX-License-Identifier: CC-BY-SA-4.0

.. include:: ../AUTHORS.rst
