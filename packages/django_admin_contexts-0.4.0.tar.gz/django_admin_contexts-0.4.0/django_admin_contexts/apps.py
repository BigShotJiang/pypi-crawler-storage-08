from django.apps import AppConfig


class DjangoAdminContextsConfig(AppConfig):
    name = "django_admin_contexts"
    default = True
