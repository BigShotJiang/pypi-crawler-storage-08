"""Core application framework with composable apps architecture.

Core application framework for Cognite Functions with type safety,
FastAPI-style decorators, and composable app architecture.

This module provides the main CogniteApp class, which offers a
FastAPI-inspired interface for building type-safe Cognite Functions. It
handles route registration, parameter validation, automatic type
conversion, and error handling. Multiple CogniteApp instances can be
composed together to create modular, reusable functionality.

Key Components:
    - CogniteApp: Main application class with route decorators (@app.get,
      @app.post, etc.)
    - Composable architecture: Multiple apps can be combined using
      create_cognite_handler([app1, app2, app3])
    - Route handling: Automatic parameter extraction from URLs, query
      strings, and request bodies
    - Type safety: Automatic conversion and validation using Pydantic
      models and type hints
    - Error handling: Comprehensive error catching and formatting for
      Cognite Functions
    - Schema generation: OpenAPI-style documentation generation
    - Built-in extensions: MCP integration and introspection endpoints

Example usage:
    ```python
    from cognite_typed_functions import CogniteApp, create_cognite_handler
    from cognite_typed_functions.mcp import create_mcp_app
    from cognite_typed_functions.introspection import create_introspection_app
    from pydantic import BaseModel

    # Main business logic app
    app = CogniteApp("My Function", "1.0.0")

    class ItemResponse(BaseModel):
        id: int
        name: str
        price: float

    @app.get("/items/{item_id}")
    def get_item(client, item_id: int) -> ItemResponse:
        # Function automatically gets typed parameters
        return ItemResponse(id=item_id, name="Widget", price=29.99)

    # Create composable extensions
    mcp_app = create_mcp_app("my-server")
    introspection_app = create_introspection_app()

    # Optionally expose routes via MCP
    @mcp_app.tool("Get item by ID")
    @app.get("/items/{item_id}")  # Can decorate the same function
    def get_item_mcp(client, item_id: int) -> ItemResponse:
        return get_item(client, item_id)

    # Compose all apps together (introspection first to see all apps)
    handle = create_cognite_handler(introspection_app, mcp_app, app)
    ```

The framework supports:
- Path parameters: /items/{item_id}
- Query parameters: ?include_tax=true&category=electronics
- Request body parsing and validation
- Automatic type conversion based on function signatures
- Input/output model validation with Pydantic
- Composable apps architecture for modular functionality
- MCP (Model Context Protocol) integration
- Built-in introspection endpoints (/__health__, /__schema__, etc.)
- Pattern-based routing for advanced use cases
- Comprehensive error handling with structured responses
"""

import inspect
from collections.abc import Callable, Mapping, Sequence
from functools import wraps
from typing import (
    Any,
    ParamSpec,
    TypeVar,
    cast,
    get_type_hints,
)

from cognite.client import CogniteClient
from pydantic import BaseModel, ValidationError

from ._version import __version__
from .convert import ConvertError, convert_arguments_to_typed_params
from .models import (
    CogniteTypedError,
    CogniteTypedResponse,
    DataDict,
    FunctionCallInfo,
    Handler,
    HTTPMethod,
    RequestData,
    TypedParam,
    TypedResponse,
)
from .routing import PathParams, RouteInfo, Router

_P = ParamSpec("_P")  # , bound=RequestHandler, wait for Python 3.13)
_R = TypeVar("_R")


class CogniteApp:
    """FastAPI-style app service for Cognite Functions."""

    def __init__(self, title: str = "Cognite Typed Functions", version: str = __version__):
        """Initialize the CogniteApp.

        Args:
            title: The title of the app.
            version: The version of the app.
        """
        self.title = title
        self.version = version

        self.router = Router()

    def set_context(self, routes: Mapping[str, Mapping[HTTPMethod, RouteInfo]], apps: Sequence["CogniteApp"]) -> None:
        """Set the composition context for this app.

        This method is called automatically during app composition and can be
        overridden by apps that need access to routes and apps from the entire composition.

        Args:
            routes: Routes from apps with lower priority (to the right in composition order)
            apps: Apps with lower priority (to the right in composition order)
        """
        # Default implementation does nothing - apps can override as needed
        pass

    def extract_path_params(self, path: str) -> Sequence[str]:
        """Extract parameter names from path like /items/{item_id}."""
        return self.router.extract_path_params(path)

    def register_route(
        self,
        path: str,
        method: HTTPMethod,
        # We use Callable[..., TypedResponse] instead of RouteHandler here to avoid being too strict on the type
        # when decorating functions, i.e not requiring the function to have secrets, function_call_info, etc.
        func: Callable[..., TypedResponse],
        description: str = "",
    ) -> None:
        """Register a route with the app."""
        # Extract function signature for parameter inspection
        sig = inspect.signature(func)
        try:
            type_hints = get_type_hints(func)
        except (NameError, AttributeError):
            # Fallback for functions with type hints that can't be resolved
            # (e.g., adapter functions with JSONLike references)
            type_hints = {}

        # Skip dependency injection parameters (client, secrets, function_call_info)
        # These are framework-provided and not part of the user's request parameters
        dependency_params = {"client", "secrets", "function_call_info", "logger"}
        params = {name: param for name, param in sig.parameters.items() if name not in dependency_params}

        route_info = RouteInfo(
            method=method,
            route_handler=func,
            signature=sig,
            parameters=params,
            type_hints=type_hints,
            path_params=self.extract_path_params(path),
            description=description or func.__doc__ or f"{method} {path}",
        )

        self.router.register_route(path, method, route_info)

    @property
    def routes(self) -> Mapping[str, Mapping[HTTPMethod, RouteInfo]]:
        """Get all routes registered with the app."""
        return self.router.routes

    def dispatch_request(
        self,
        request: RequestData,
        client: CogniteClient,
        secrets: Mapping[str, str] | None = None,
        function_call_info: FunctionCallInfo | None = None,
    ) -> DataDict | None:
        """Dispatch a request and return the response.

        This method enables flexible inter-app communication by allowing
        one app to dispatch requests to another app or to itself.

        Args:
            request: The request data containing path, method, body, and query parameters
            client: The Cognite client instance
            secrets: Optional secrets mapping (injected if handler declares it)
            function_call_info: Optional function call metadata (injected if handler declares it)

        Returns:
            Response data dict if a route matches, None if no route matches

        Raises:
            ValidationError: If input validation fails
            ConvertError: If parameter conversion fails
            Exception: If function execution fails
        """
        # Find matching route and extract path parameters
        route_match, path_params = self.router.find_matching_route(request.clean_path, request.method)

        if not route_match:
            # No route matched
            return None

        # Prepare function arguments with validation and type coercion
        kwargs = _prepare_function_arguments(
            client,
            route_match,
            request.body,
            request.query,
            path_params,
            secrets,
            function_call_info,
        )

        # Execute function and format response
        return execute_function_and_format_response(route_match, kwargs)

    def _create_route_decorator(
        self,
        method: HTTPMethod,
        path: str,
    ) -> Callable[[Callable[_P, TypedResponse]], Callable[_P, TypedResponse]]:
        """Create a route decorator for the specified HTTP method."""

        def decorator(
            func: Callable[_P, TypedResponse],
        ) -> Callable[_P, TypedResponse]:
            self.register_route(path, method, func)
            return func

        return decorator

    def get(
        self,
        path: str,
    ) -> Callable[[Callable[_P, TypedResponse]], Callable[_P, TypedResponse]]:
        """Decorator for GET operations (data retrieval)."""
        return self._create_route_decorator(HTTPMethod.GET, path)

    def post(
        self,
        path: str,
    ) -> Callable[[Callable[_P, TypedResponse]], Callable[_P, TypedResponse]]:
        """Decorator for POST operations (create/process)."""
        return self._create_route_decorator(HTTPMethod.POST, path)

    def put(
        self,
        path: str,
    ) -> Callable[[Callable[_P, TypedResponse]], Callable[_P, TypedResponse]]:
        """Decorator for PUT operations (update/replace)."""
        return self._create_route_decorator(HTTPMethod.PUT, path)

    def delete(
        self,
        path: str,
    ) -> Callable[[Callable[_P, TypedResponse]], Callable[_P, TypedResponse]]:
        """Decorator for DELETE operations."""
        return self._create_route_decorator(HTTPMethod.DELETE, path)


def _prepare_function_arguments(
    client: CogniteClient,
    route_match: RouteInfo,
    body: DataDict,
    query: Mapping[str, str | Sequence[str]],
    path_params: PathParams,
    secrets: Mapping[str, str] | None = None,
    function_call_info: FunctionCallInfo | None = None,
) -> dict[str, TypedParam]:
    """Prepare and validate function arguments with type coercion and dependency injection."""
    # Combine body, query, and path parameters
    all_params = {**body, **query, **path_params}

    # Use the shared type conversion logic that handles Pydantic models, defaults, and dependency injection
    func = route_match.route_handler
    return convert_arguments_to_typed_params(client, func, all_params, secrets, function_call_info)


def cognite_error_handler(
    func: Callable[_P, DataDict],
) -> Callable[_P, DataDict]:
    """Decorator that handles common errors in Cognite Function handlers."""

    @wraps(func)
    def wrapper(*args: _P.args, **kwargs: _P.kwargs) -> DataDict:
        try:
            return func(*args, **kwargs)
        except ValidationError as e:
            # Handle validation errors from Pydantic on the returned data
            return CogniteTypedError(
                error_type="ValidationError",
                message=f"Input validation failed: {e.error_count()} error(s)",
                details={"errors": e.errors()},
            ).model_dump()
        except ConvertError as e:
            # Handle parameter conversion and validation errors on input data
            return CogniteTypedError(
                error_type="ValidationError",
                message=f"Input validation failed: {e!s}",
                details={"exception_type": type(e).__name__},
            ).model_dump()
        except Exception as e:
            return CogniteTypedError(
                error_type="ExecutionError",
                message=f"Function execution failed: {e!s}",
                details={"exception_type": type(e).__name__},
            ).model_dump()

    return wrapper


def execute_function_and_format_response(
    route_match: RouteInfo,
    kwargs: Mapping[str, Any],  # This must be Any
) -> DataDict:
    """Execute the function and format the response."""
    func = route_match.route_handler
    result = func(**kwargs)

    # Handle result conversion based on type
    data = result.model_dump() if isinstance(result, BaseModel) else result

    return CogniteTypedResponse(data=data).model_dump()


def create_function_handle(*apps: CogniteApp) -> Handler:
    """Create function handle for single app or composed apps (left-to-right evaluation).

    Args:
        apps: Single CogniteApp or sequence of CogniteApp to compose.
              For composed apps, routing tries each app left-to-right
              until one matches.

    Returns:
        Handler function compatible with Cognite Functions

    Example:
        # Single app
        handle = create_function_handle(main_app)

        # Composed apps (Introspection first to see all, then MCP, then Main)
        handle = create_function_handle(introspection_app, mcp_app, main_app)
    """
    # Normalize to list
    app_list = list(apps)

    # Provide composition context to apps that implement CompositionAware
    _set_app_context(app_list)

    @cognite_error_handler
    def handle(
        *,
        client: CogniteClient,
        data: DataDict,
        secrets: Mapping[str, Any] | None = None,
        function_call_info: FunctionCallInfo | None = None,
    ) -> DataDict:
        """Auto-generated dispatcher for Cognite Function routes.

        Expected data format:
        {
            "path": "/items/123?include_tax=true&q=search",  # Full URL with query string
            "method": "GET",
            "body": {...}  # Optional request body for POST/PUT operations
        }
        """
        # Parse request data using Pydantic (we need the cast here since Pytantic is doing the validation)
        request = RequestData(**cast(dict[str, Any], data))

        # Try each app in order (left-to-right evaluation)
        for app in app_list:
            # Dispatch request to app and get response if route matches
            response = app.dispatch_request(request, client, secrets, function_call_info)

            if response is not None:
                return response

        # No app matched the route
        all_routes: list[str] = []
        for app in app_list:
            all_routes.extend(app.router.routes.keys())

        return CogniteTypedError(
            error_type="RouteNotFound",
            message=f"No route found for {request.method} {request.clean_path}",
            details={"available_routes": all_routes},
        ).model_dump()

    return handle


def _set_app_context(app_list: list[CogniteApp]) -> None:
    """Provide composition context to all apps in the composition.

    Following layered architecture principles, each app only sees downstream apps
    (lower priority apps to their right). If an app needs global visibility,
    put it first in the composition order.
    """
    # Provide context to each app based on its position
    for i, app in enumerate(app_list):
        # Collect downstream apps and routes (lower priority, to the right)
        downstream_apps = app_list[i + 1 :]
        downstream_routes: dict[str, dict[HTTPMethod, RouteInfo]] = {}
        for downstream_app in reversed(downstream_apps):
            for path, methods in downstream_app.routes.items():
                downstream_routes.setdefault(path, {}).update(methods)
        # Provide downstream visibility directly to the app
        app.set_context(downstream_routes, downstream_apps)
