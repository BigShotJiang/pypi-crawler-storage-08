"""Useful Tensorflow callbacks

Not implemented yet.
"""
