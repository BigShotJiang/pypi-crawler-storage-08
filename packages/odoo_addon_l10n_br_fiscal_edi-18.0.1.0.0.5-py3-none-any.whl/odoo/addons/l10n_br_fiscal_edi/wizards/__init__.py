# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html

from . import base_wizard_mixin
from . import document_cancel_wizard
from . import document_correction_wizard
from . import invalidate_number_wizard
