Use os botões na barra de header do documento fiscal para alterar o
estado do documento fiscal, para abrir os wizards e para interagir com a
fazenda... Quando o módulo `l10n_br_account` ou alguns módulos de
documentos fiscais específicos como `l10n_br_nfe` ou `l10n_br_nfse` são
instalados, alguns métodos de transição de estado do módulo
`l10n_br_fiscal_edi` são chamados automaticamente, por exemplo ao
confirmar ou cancelar uma nota.
