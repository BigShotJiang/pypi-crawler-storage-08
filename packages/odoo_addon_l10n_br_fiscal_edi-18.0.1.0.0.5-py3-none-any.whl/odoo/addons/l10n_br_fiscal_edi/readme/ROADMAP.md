O código deste módulo foi feito antes dos repos `OCA/edi` e
`OCA/edi-framework`. O código do `document_workflow.py` por exemplo foi
uma espécie de tradução em código do "workflow de state machine" que
tinha sido customizado para a NFe na versão 8.0 mas que teve que ser
re-escrito quando o engine de workflow foi removido na versão 10.0.
Nisso o código deste módulo tem bastante possibilidades de melhorias...
