from tysins.android_transfer import AndroidTransfer

def main():
    AndroidTransfer().run()
