from brutils.data.enums.uf import UF, UF_CODE
