from .cep import CEPNotFound, InvalidCEP
