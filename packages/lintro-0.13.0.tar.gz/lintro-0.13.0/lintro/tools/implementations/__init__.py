"""Concrete tool integrations (Ruff, Black, Prettier, etc.)."""
