"""Parsing utilities and types for Yamllint output."""
