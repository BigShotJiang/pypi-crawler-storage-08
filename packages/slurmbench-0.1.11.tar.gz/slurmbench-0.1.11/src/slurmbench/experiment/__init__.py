"""Experiment asbtract module.

Common parts for all topics, all tools.
"""
