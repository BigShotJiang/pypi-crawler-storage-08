"""Experiment Bash logics."""
