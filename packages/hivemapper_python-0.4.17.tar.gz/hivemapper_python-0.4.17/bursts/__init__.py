from .query import create_bursts

__all__ = ['create_bursts']
