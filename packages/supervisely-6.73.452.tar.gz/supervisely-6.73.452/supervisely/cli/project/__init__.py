from supervisely.cli.project.project_get import get_project_name_run

from supervisely.cli.project.project_download import download_run
from supervisely.cli.project.project_upload import upload_run
