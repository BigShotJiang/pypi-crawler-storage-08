====================================
Tutorial: toolkit for classification
====================================

In this tutorial, we will show how to use the toolkit in the context of a classification problem.

.. warning::

    Work in progress.
