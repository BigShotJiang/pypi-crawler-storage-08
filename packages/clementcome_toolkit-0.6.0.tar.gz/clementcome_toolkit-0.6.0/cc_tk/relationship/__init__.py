"""`relationship` module is dedicated to testing statistical relationship."""

from cc_tk.relationship.significance import (
    get_significance,  # noqa: F401
)
from cc_tk.relationship.summary import RelationshipSummary  # noqa: F401
