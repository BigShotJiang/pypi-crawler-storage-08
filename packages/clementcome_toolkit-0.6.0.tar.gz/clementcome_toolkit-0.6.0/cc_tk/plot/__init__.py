"""Module for plotting data."""
