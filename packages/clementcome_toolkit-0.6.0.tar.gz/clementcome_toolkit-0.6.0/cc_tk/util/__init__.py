"""Utility functions for the cc_tk package."""
