
def remove_leading_slash(s: str) -> str:
    return s.lstrip("/")