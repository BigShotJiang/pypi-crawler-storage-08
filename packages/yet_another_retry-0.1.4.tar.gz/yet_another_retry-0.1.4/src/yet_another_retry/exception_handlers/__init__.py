from yet_another_retry.exception_handlers.default_exception import default_exception

__all__ = ["default_exception"]
