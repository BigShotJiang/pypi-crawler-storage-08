# gloser
Simple i18n for Python
