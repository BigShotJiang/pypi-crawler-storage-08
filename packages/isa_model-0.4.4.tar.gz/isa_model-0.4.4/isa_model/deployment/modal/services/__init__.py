"""
Modal service implementations organized by capability
"""