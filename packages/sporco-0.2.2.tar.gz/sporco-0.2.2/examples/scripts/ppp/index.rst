Plug and Play Priors
====================

.. toc-start

* `Plug and Play Priors ADMM solution of a demosaicing problem <ppp_admm_dmsc.py>`__
* `Plug and Play Priors ADMM Consensus solution of a demosaicing problem <ppp_admmcns_dmsc.py>`__
* `Plug and Play Priors PGM solution of a demosaicing problem <ppp_pgm_dmsc.py>`__

.. toc-end
