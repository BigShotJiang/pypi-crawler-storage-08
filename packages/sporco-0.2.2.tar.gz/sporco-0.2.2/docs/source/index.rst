SPORCO Documentation
====================

.. toctree::
   :maxdepth: 1

   overview
   install
   invprob/index
   admm/index
   pgm/index
   util
   examples/index
   notes
   modules/index
   zreferences



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
