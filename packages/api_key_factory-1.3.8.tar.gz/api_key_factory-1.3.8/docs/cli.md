# CLI Reference

This page provides documentation for the command line `api_key_factory` application.

::: mkdocs-click
    :module: api_key_factory.api_key_factory
    :command: generate
