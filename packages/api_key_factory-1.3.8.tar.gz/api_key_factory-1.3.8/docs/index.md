# Overview

Version: 1.3.8

A simple CLI tools to generate API keys and their corresponding SHA-256 hashes.
