import importlib.metadata

__version__ = importlib.metadata.version("freegsnke")
__author__ = "The FreeGSNKE Developers"
