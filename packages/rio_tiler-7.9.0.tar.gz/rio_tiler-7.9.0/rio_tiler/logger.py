"""rio-tiler logger."""

import logging

logger = logging.getLogger("rio-tiler")
