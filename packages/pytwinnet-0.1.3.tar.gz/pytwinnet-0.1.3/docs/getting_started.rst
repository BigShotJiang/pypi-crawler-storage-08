
Getting Started
===============

Install (editable) and run examples::

    pip install -r requirements-dev.txt
    pip install -e .
    python -m examples.basic_simulation
