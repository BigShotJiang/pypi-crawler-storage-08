Heterogeneous Network Placement
===============================

Run:
.. code-block:: bash

   pytwinnet run configs/het_net_placement.yaml

.. literalinclude:: ../../configs/het_net_placement.yaml
   :language: yaml
```