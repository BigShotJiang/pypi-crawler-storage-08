# Config-Driven Experiments

Run from YAML:
```shell
pytwinnet run configs/het_net_placement.yaml
```


# Examples
========

```markdown
## Keys
environment.dimensions_m

propagation.model

nodes

scenario.events

optimize

visualization.heatmap
```
