
```markdown
# Real-Time Dashboard

Streamlit dashboard for monitoring a Digital Twin.
```
## Install
```bash
pip install "pytwinnet[dashboard]"
```
```bash
streamlit run examples/run_dashboard.py
```