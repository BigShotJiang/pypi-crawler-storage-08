"""morchaos - A collection of utilities for file management,
 deduplication, and system monitoring."""

__version__ = "0.1.0"
