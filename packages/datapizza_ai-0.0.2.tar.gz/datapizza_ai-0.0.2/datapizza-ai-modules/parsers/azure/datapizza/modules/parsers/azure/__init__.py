from .azure_parser import AzureParser

__all__ = ["AzureParser"]
