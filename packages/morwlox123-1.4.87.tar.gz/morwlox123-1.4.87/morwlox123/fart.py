def fart(colicshestvo):
    return f'напреееедеелел {colicshestvo}ййййййцуууущщщщщщщщщщщщщ раз'

def mega_farting(colicshestvo):
    return f'супер ьупф напреееедеелел {colicshestvo}йщщ раз'