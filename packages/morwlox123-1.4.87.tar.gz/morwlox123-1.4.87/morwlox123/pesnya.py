class петь():
    def песня_про_какашку_и_говняшку():
        return 'govno kakashkaaaaaaaaa jopa jopa piska'

    def klazermp3():
        return ''

    def рустам():
        return ''