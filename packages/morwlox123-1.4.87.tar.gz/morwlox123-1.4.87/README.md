# ti lox suck kok #

## ты лох ##

говнищеееееееееееее

---

    ты говнооооооооооооооййоойооойй
    пук пук пук пук

###
xyuuuuuuuuuuuuuuuuuu

----

idi nax lol lox morw daun