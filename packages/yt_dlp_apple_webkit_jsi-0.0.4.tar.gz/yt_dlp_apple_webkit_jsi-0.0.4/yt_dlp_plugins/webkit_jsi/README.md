# PyNeApple

> [!NOTE]  
> Still a WIP

A simple pure-python library for interoperation with Apple's [Objective-C Runtime](<https://developer.apple.com/documentation/objectivec?language=objc>) and its Objective-C APIs provided by the frameworks via the [ctypes](<https://docs.python.org/3/library/ctypes.html>) standard library.

# WKJS

A simple pure python library for executing javascript with Apple's WebKit framework, only depends on PyNeApple.

