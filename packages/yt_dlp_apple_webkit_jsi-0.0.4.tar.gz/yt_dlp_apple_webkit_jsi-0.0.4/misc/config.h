#ifndef CONFIG_H
#define CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif

extern const unsigned char *szHTMLString;
extern const unsigned char *szBaseURL;
extern const unsigned char *szScript;

#ifdef __cplusplus
}
#endif

#endif
