# Copyright 2024 Canonical Ltd.
# See LICENSE file for licensing details.
"""The core objects and code for mongo charms."""
