def main():
    print("Hello from medilinda-ml!")


if __name__ == "__main__":
    main()
