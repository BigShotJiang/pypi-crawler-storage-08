class YPathError(Exception):
    pass
