"""Support for direct pav3 execution."""

from .cli import main

if __name__ == '__main__':
    main()
