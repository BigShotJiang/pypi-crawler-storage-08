# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .parse_metadata import ParseMetadata as ParseMetadata
from .parse_grounding_box import ParseGroundingBox as ParseGroundingBox
