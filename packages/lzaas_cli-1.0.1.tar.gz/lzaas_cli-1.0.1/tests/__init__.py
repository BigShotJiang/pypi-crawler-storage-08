# Tests for LZaaS CLI
