from typing import Optional
import pulse as ps


@ps.react_component("Indicator", "@mantine/core")
def Indicator(*children: ps.Child, key: Optional[str] = None, **props): ...

