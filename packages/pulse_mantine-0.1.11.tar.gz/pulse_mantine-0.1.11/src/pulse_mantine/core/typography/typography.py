from typing import Optional
import pulse as ps


@ps.react_component("Typography", "@mantine/core")
def Typography(key: Optional[str] = None, **props): ...

