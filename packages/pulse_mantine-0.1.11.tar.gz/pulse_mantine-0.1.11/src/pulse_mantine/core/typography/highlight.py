from typing import Optional
import pulse as ps


@ps.react_component("Highlight", "@mantine/core")
def Highlight(key: Optional[str] = None, **props): ...

