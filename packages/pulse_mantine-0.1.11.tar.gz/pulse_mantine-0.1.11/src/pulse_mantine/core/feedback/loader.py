from typing import Optional
import pulse as ps


@ps.react_component("Loader", "@mantine/core")
def Loader(*children: ps.Child, key: Optional[str] = None, **props): ...

