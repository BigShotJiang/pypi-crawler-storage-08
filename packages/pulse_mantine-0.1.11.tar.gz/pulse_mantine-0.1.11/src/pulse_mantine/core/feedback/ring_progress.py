from typing import Optional
import pulse as ps


@ps.react_component("RingProgress", "@mantine/core")
def RingProgress(key: Optional[str] = None, **props): ...

