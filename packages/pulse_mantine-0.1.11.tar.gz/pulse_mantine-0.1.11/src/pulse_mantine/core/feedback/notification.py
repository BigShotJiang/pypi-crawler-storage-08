from typing import Optional
import pulse as ps


@ps.react_component("Notification", "@mantine/core")
def Notification(*children: ps.Child, key: Optional[str] = None, **props): ...

