from typing import Optional
import pulse as ps


@ps.react_component("AngleSlider", "pulse-mantine")
def AngleSlider(key: Optional[str] = None, **props): ...
