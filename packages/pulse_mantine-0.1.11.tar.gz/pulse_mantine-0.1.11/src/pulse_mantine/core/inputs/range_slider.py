from typing import Optional
import pulse as ps


@ps.react_component("RangeSlider", "pulse-mantine")
def RangeSlider(*children: ps.Child, key: Optional[str] = None, **props): ...
