from typing import Optional
import pulse as ps


@ps.react_component("Switch", "pulse-mantine")
def Switch(key: Optional[str] = None, **props): ...
