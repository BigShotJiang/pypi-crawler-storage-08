from typing import Optional
import pulse as ps


@ps.react_component("Rating", "pulse-mantine")
def Rating(key: Optional[str] = None, **props): ...
