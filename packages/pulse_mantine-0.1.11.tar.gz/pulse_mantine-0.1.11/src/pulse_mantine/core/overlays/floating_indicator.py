from typing import Optional
import pulse as ps


@ps.react_component("FloatingIndicator", "@mantine/core")
def FloatingIndicator(key: Optional[str] = None, **props): ...

