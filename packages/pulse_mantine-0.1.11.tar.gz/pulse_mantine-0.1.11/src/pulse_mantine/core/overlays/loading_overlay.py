from typing import Optional
import pulse as ps


@ps.react_component("LoadingOverlay", "@mantine/core")
def LoadingOverlay(key: Optional[str] = None, **props): ...

