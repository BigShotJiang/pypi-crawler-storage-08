from typing import Optional
import pulse as ps


@ps.react_component("TableOfContents", "@mantine/core")
def TableOfContents(key: Optional[str] = None, **props): ...

