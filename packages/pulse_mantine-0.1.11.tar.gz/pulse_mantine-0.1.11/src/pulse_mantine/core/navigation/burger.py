from typing import Optional
import pulse as ps


@ps.react_component("Burger", "@mantine/core")
def Burger(key: Optional[str] = None, **props): ...

