from typing import Optional
import pulse as ps


@ps.react_component("Collapse", "@mantine/core")
def Collapse(*children: ps.Child, key: Optional[str] = None, **props): ...

