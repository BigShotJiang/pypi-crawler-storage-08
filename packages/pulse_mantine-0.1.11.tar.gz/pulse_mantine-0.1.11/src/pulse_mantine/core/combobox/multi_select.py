from typing import Optional
import pulse as ps


@ps.react_component("MultiSelect", "@mantine/core")
def MultiSelect(key: Optional[str] = None, **props): ...

