from typing import Optional
import pulse as ps


@ps.react_component("DatePickerInput", "pulse-mantine")
def DatePickerInput(key: Optional[str] = None, **props): ...

