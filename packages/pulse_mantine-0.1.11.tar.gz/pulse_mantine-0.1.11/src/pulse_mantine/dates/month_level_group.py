from typing import Optional
import pulse as ps


@ps.react_component("MonthLevelGroup", "pulse-mantine")
def MonthLevelGroup(key: Optional[str] = None, **props): ...

