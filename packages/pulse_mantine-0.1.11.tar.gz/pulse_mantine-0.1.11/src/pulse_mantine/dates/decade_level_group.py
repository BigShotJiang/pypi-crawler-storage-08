from typing import Optional
import pulse as ps


@ps.react_component("DecadeLevelGroup", "pulse-mantine")
def DecadeLevelGroup(key: Optional[str] = None, **props): ...

