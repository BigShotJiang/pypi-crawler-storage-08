from typing import Optional
import pulse as ps


@ps.react_component("Calendar", "pulse-mantine")
def Calendar(key: Optional[str] = None, **props): ...

