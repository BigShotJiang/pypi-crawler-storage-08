from typing import Optional
import pulse as ps


@ps.react_component("CalendarHeader", "pulse-mantine")
def CalendarHeader(key: Optional[str] = None, **props): ...

