from typing import Optional
import pulse as ps


@ps.react_component("TimePicker", "pulse-mantine")
def TimePicker(key: Optional[str] = None, **props): ...

