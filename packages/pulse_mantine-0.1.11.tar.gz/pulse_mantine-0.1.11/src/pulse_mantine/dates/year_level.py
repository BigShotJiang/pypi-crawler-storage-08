from typing import Optional
import pulse as ps


@ps.react_component("YearLevel", "pulse-mantine")
def YearLevel(key: Optional[str] = None, **props): ...

