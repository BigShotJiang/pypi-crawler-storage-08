from typing import Optional
import pulse as ps


@ps.react_component("YearPickerInput", "pulse-mantine")
def YearPickerInput(key: Optional[str] = None, **props): ...

