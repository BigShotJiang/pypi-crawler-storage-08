from typing import Optional
import pulse as ps


@ps.react_component("PickerInputBase", "pulse-mantine")
def PickerInputBase(key: Optional[str] = None, **props): ...

