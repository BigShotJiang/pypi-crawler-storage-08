from typing import Optional
import pulse as ps


@ps.react_component("MonthsList", "pulse-mantine")
def MonthsList(key: Optional[str] = None, **props): ...

