from typing import Optional
import pulse as ps


@ps.react_component("YearPicker", "pulse-mantine")
def YearPicker(key: Optional[str] = None, **props): ...

