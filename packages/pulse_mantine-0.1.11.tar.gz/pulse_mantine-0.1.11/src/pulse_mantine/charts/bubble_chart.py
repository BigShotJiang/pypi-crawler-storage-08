from typing import Optional
import pulse as ps


@ps.react_component("BubbleChart", "@mantine/charts")
def BubbleChart(key: Optional[str] = None, **props): ...

