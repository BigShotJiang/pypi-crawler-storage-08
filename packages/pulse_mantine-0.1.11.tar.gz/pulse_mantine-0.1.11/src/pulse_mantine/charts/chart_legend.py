from typing import Optional
import pulse as ps


@ps.react_component("ChartLegend", "@mantine/charts")
def ChartLegend(key: Optional[str] = None, **props): ...

