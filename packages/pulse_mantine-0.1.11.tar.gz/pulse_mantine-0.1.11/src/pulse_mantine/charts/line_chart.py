from typing import Optional
import pulse as ps


@ps.react_component("LineChart", "@mantine/charts")
def LineChart(key: Optional[str] = None, **props): ...

