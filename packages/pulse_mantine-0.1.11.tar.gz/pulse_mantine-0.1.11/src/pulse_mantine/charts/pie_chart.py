from typing import Optional
import pulse as ps


@ps.react_component("PieChart", "@mantine/charts")
def PieChart(key: Optional[str] = None, **props): ...

