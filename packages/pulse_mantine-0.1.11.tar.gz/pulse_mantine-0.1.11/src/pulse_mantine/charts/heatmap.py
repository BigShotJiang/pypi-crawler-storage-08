from typing import Optional
import pulse as ps


@ps.react_component("Heatmap", "@mantine/charts")
def Heatmap(key: Optional[str] = None, **props): ...

