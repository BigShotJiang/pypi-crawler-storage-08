# seleniumbase package
__version__ = "4.42.3"
