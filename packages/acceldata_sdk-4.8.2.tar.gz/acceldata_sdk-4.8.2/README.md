# acceldata SDK

Acceldata SDK for instrumenting support in [ADOC](https://docs.acceldata.io/documentation/what-is-adoc-platform).

Refer to the [documentation](https://docs.acceldata.io/sdk/getting-started-python) for details.