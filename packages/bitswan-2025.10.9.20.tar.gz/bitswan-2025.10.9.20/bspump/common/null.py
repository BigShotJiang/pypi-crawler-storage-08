from ..abc.sink import Sink


class NullSink(Sink):
    """
    Description:

    |

    """

    def process(self, context, event):
        """
        Description:

        |

        """
        pass
