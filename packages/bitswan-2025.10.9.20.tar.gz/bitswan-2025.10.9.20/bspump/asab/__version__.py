# THIS-FILE-WILL-BE-REPLACED !!! DO NOT CHANGE OR MODIFY THIS FILE !!!

# During `setup.py build_py`, this file is overwritten
# __version__ = '[git describe --abbrev=7 --tags --dirty=+dirty --always]
# __build__ = '[git rev-parse HEAD]'

# PEP 440 -- Version Identification and Dependency Specification
# https://www.python.org/dev/peps/pep-0440/


__version__ = "devel"
__build__ = "devel"
