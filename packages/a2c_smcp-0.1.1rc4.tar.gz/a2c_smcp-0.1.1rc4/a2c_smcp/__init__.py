# -*- coding: utf-8 -*-
# filename: __init__.py.py
# @Time    : 2025/9/28 15:33
# @Author  : JQQ
# @Email   : jqq1716@gmail.com
# @Software: PyCharm
__version__: str = "0.1.1-rc4"
