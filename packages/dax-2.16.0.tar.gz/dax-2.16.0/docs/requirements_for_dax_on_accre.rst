Requirements for DAX in the ACCRE Environment
=============================================

Table of Contents
~~~~~~~~~~~~~~~~~

  1.  `Required Modules <#required-modules>`__

----------------
Required Modules
----------------

When running dax on ACCRE, there are some required modules that need to be loaded. They can be loaded with the following:

::

	module load GCCcore/.10.2.0 git/2.28.0-nodocs Python/3.8.6 pbzip2/1.1.13
