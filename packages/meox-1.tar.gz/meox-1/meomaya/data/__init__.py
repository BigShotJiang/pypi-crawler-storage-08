from .corpus_loader import CorpusLoader

__all__ = ["CorpusLoader"]
