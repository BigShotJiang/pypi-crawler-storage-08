__VERSION__ = "0.1.17"
LOGGER_NAME = "fractal-health"
