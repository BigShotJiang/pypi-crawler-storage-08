default_app_config = "wagtail_ai.apps.WagtailAiAppConfig"


VERSION = (3, 0, 0)
__version__ = ".".join(map(str, VERSION))
