import numpy as np


class Encoder:
    def __init__(self):
        pass

    def inference(self, img: np.ndarray, dets: np.ndarray) -> np.ndarray: # return size [num_of_dets, num_of_feats]
        pass

    