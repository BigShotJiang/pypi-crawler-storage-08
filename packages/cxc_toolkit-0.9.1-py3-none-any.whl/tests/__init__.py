import logging.config

logging.config.fileConfig('logging_config.ini')
