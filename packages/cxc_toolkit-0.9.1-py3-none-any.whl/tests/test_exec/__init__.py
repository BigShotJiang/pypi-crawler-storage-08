import cxc_toolkit

cxc_toolkit.exec.run_command("echo 'hello'")
