## "lokzzpylib"

![Upload Python Package](https://github.com/lokzz/pylibrary/actions/workflows/python-publish.yml/badge.svg)\
my own personal library
