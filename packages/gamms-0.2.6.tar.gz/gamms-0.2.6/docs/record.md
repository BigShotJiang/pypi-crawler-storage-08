# Recorder

::: gamms.typing.IRecorder
    options:
        members: true