
extern "C" void enable_forcedexec();
extern "C" void disable_forcedexec();

