class DegenerateWarning(Warning):
    pass
