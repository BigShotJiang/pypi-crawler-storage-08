#!/bin/bash

echo "this file and the docker is not currently working and may be not needed"
echo "Please disregard this folder at the moment"
# docker build -t e3_project .
# docker run -it -v $(pwd)/output:/workspace/output e3_project

