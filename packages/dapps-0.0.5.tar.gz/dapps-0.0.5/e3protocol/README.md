# E3 protocol

Examples of the implemetation of E3AP and E3SM.

In order to use the examples, you must satisfy the prerequisites:
- `asn1c` compiler for compiling the C ASNs

You can build the ASNs using the `build_asn.sh` script.

For a client-server example check the files inside.