#ifndef THIRD
#define THIRD
#include "main.h"
#endif
