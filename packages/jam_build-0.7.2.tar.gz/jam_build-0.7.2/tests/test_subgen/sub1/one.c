#include "test.h"

void func1() {
    PRINT_1();
}
