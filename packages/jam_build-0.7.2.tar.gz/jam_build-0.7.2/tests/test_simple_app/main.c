int print(char *s);
int say(char *s);

int main()
{
    say("hi");
    print("you");
    return 0;
}
