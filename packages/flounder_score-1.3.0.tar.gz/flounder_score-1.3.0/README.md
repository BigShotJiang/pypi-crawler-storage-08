# Flounder Score

[![DNA](https://imgs.xkcd.com/comics/dna.png)](https://xkcd.com/1605/)

[![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/davep/flounder_score/code-checks.yaml)](https://github.com/davep/flounder_score/actions)
[![GitHub commits since latest release](https://img.shields.io/github/commits-since/davep/flounder_score/latest)](https://github.com/davep/flounder_score/commits/main/)
[![GitHub Issues or Pull Requests](https://img.shields.io/github/issues/davep/flounder_score)](https://github.com/davep/flounder_score/issues)
[![GitHub Release Date](https://img.shields.io/github/release-date/davep/flounder_score)](https://github.com/davep/flounder_score/releases)
[![PyPI - License](https://img.shields.io/pypi/l/flounder_score)](https://github.com/davep/flounder_score/blob/main/LICENSE)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/flounder_score)](https://github.com/davep/flounder_score/blob/main/pyproject.toml)
[![PyPI - Version](https://img.shields.io/pypi/v/flounder-score)](https://pypi.org/project/flounder-score/)

From early 2018 until late 2022 I worked as a software developer attached to
a bioinformatics team. One of the things I saw the team around me doing was
a lot of "scoring" of sequences, etc (imagine a lot of layman hand-waving
here, obviously).

Playing on the "DNA is just code" nonsense trope, it became a bit of a
running joke for me to suggest that they should try a scoring system based
on a popular tile-based word game. Eventually, with a bit of spare time on
my hands, I decided to actually write and publish a library that implemented
this.

And so the *Flounder Score* was born.

No, it's not a serious library, but I also think it makes a serious point
about [people who think "it's just code"](https://xkcd.com/1605/).

## Installation

The library can be installed [from
PyPI](https://pypi.org/project/flounder-score/):

```sh
$ pip install flounder-score
```

## Usage

See [the main documentation](https://flounder-score.davep.dev/) for details
on what this library provides and how to use it.

[//]: # (README.md ends here)
