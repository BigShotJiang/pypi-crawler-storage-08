"""
This namespace contains the command-line related modules.
"""
