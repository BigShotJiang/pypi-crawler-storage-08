DAMAST_MAJOR_VERSION = 0
DAMAST_MINOR_VERSION = 2
DAMAST_PATCH_LEVEL = 1

__version_info__ = (str(DAMAST_MAJOR_VERSION), str(DAMAST_MINOR_VERSION), str(DAMAST_PATCH_LEVEL))
__version__ = '.'.join(__version_info__)
