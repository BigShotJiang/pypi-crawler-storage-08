"""
This namespace contains domain specific functionalities.
"""
from damast.domains import maritime

__all__ = ["maritime"]
