"""Test cases for cASO."""
