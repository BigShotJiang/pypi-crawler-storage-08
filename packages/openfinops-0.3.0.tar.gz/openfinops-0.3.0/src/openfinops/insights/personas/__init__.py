"""Persona-specific insight generators."""
