"""Tests for persona-specific insights system."""
