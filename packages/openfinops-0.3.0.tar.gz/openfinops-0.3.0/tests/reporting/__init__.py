"""Tests for reporting and BI integrations system."""

# Copyright (c) 2025 OpenFinOps Contributors
# Licensed under the Apache License, Version 2.0
