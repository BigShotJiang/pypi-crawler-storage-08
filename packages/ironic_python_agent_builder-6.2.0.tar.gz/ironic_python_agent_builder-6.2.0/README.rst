===========================
Ironic Python Agent Builder
===========================

Tools and scripts to build a deployment, cleaning or inspection ramdisk
based on `Ironic Python Agent`_.

* Free software: Apache license
* Documentation: https://docs.openstack.org/ironic-python-agent-builder
* Source: https://opendev.org/openstack/ironic-python-agent-builder
* Bugs: https://bugs.launchpad.net/ironic-python-agent-builder
* Release Notes: https://docs.openstack.org/releasenotes/ironic-python-agent-builder/

.. _Ironic Python Agent: https://docs.openstack.org/ironic-python-agent
