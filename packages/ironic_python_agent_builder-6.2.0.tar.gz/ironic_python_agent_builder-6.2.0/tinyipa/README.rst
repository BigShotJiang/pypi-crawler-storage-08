=============================
Tiny Core Ironic Python Agent
=============================

See
https://docs.openstack.org/ironic-python-agent-builder/latest/admin/tinyipa.html
