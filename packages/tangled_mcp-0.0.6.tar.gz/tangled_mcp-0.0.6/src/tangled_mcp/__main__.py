from tangled_mcp.server import tangled_mcp


def main():
    tangled_mcp.run()


if __name__ == "__main__":
    main()
