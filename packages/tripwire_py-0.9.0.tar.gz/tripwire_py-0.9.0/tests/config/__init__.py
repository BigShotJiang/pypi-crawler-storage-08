"""Tests for the config module."""
