"""Tests for core TripWire components."""
