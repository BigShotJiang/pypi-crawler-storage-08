from .globals import (
    Globals as Globals,
)
from .globals import (
    GlobalsMiddleware as GlobalsMiddleware,
)
from .globals import (
    g as g,
)
