"""Tests for Griffonner plugin system."""
