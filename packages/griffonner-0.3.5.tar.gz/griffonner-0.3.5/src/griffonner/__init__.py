"""A templating tool for Griffe."""

from importlib.metadata import version

from .cli import main as main

__version__ = version("griffonner")
