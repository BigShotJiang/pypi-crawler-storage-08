Please read the following file completely and execute all instructions within.
This file defines the entire development workflow and verification steps.

File path:
./doc/CLINE_TASK_CURRENT.md

After reading, start with the Clarification & Planning Phase as described in the file.
