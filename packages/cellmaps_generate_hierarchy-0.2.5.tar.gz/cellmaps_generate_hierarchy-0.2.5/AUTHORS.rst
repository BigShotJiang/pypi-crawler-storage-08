=======
Credits
=======

Developers
----------------

* Leah Schaffer <lvschaffer@health.ucsd.edu>

* Clara Hu <mhu@health.ucsd.edu>

* Christopher Churas <cchuras@ucsd.edu>

Contributors
------------

None yet. Why not be the first?

