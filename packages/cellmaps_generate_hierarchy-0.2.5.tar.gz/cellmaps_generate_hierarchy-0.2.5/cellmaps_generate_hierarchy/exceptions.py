# -*- coding: utf-8 -*-


class CellmapsGenerateHierarchyError(Exception):
    """
    Base exception for cellmaps_generate_hierarchy
    """
    pass
