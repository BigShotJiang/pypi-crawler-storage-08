class GraphDeferredIllegalOperationError(TypeError):
    """Raised when a future (Socket) is used in an illegal concrete operation."""

    pass
