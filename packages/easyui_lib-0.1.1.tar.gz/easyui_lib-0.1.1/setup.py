from setuptools import setup

# Minimal setup.py to rely on pyproject.toml metadata
if __name__ == "__main__":
    setup()

