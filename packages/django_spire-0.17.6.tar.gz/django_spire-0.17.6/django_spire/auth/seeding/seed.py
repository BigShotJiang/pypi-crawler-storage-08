from django_spire.auth.seeding.seeder import UserSeeder

UserSeeder.seed_database(count=20)
