class OrderingMixinExceptionGroup(Exception):
    pass

class OrderingMixinException(Exception):
    pass