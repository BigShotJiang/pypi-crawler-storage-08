"""AI Script Generator MCP Server - AL Parser for Business Central
"""

__version__ = "0.1.5"

from .server import main

__all__ = ["main", "__version__"]
