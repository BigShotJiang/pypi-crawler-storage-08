"""Entry point for running stdem as a module: python -m stdem"""

from .main import main

if __name__ == "__main__":
    main()
