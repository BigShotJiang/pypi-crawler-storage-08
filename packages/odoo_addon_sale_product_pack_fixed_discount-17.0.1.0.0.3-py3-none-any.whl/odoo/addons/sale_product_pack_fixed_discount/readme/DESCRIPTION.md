This module is glue module between *Sale Product Pack* and *Sale fixed
discount*'s modules.

For the time being this avoid fixed discount on sale order lines linked
to a pack or a pack component excepted for pack with modifiable
components.
