"""Unicycler tool for assembly topic."""
