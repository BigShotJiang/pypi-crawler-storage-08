"""SKESA tool for assembly topic."""
