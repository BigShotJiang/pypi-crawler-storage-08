"""GFA connector from SKESA assembly tool."""
