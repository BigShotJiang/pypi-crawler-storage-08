"""Classification topic description."""

from slurmbench.prelude.topic import description as core

DESCRIPTION = core.Description("CLASSIFICATION", "classification")
