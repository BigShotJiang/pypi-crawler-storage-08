# Environment wrapper script: nothing required

pangebin asm-pbf once "${GFA}" "${SEEDS}" "${PLASMIDNESS}" --outdir "${WORK_EXP_SAMPLE_DIR}" "${USER_TOOL_OPTIONS[@]}"
