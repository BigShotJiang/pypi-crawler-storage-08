"""Topic description."""

from slurmbench.prelude.topic import description as core

DESCRIPTION = core.Description("BINNING", "binning")
