"""CloudCIX API Module autodoc test"""
__version__ = '1.0.2'
