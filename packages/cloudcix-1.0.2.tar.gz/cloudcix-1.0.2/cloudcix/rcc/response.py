# Default response structure for rcc modules
RESPONSE_DICT = {
    'channel_code': None,
    'channel_error': None,
    'channel_message': None,
    'payload_code': None,
    'payload_error': None,
    'payload_message': None,
}
