__version__ = "0.16.5"


def get_version() -> str:
    return __version__
