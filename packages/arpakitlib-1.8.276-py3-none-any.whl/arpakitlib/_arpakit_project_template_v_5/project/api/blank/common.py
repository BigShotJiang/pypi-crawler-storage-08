from arpakitlib.ar_blank_util import BaseBlank


class SimpleBlankAPI(BaseBlank):
    pass
