from typing import Literal

PEGA_VERSIONS: Literal["8.8", "23.1", "24.1", "24.2"]
supported_pega_versions = ["8.8", "23.1", "24.1", "24.2"]
METRIC = Literal["Performance", "Total_responses", "Lift", "Success_rate"]
