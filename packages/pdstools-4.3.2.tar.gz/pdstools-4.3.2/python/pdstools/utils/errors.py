class NotApplicableError(ValueError):
    pass
