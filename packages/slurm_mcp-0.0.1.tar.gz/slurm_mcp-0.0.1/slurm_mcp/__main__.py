from .s_mcp import main

if __name__ == "__main__":
    main()
