function n(t){for(const e in t)t[e]=!1;return t}function a(t){return new Date(t*1e3).toLocaleString("en-US")}export{n as r,a as t};
