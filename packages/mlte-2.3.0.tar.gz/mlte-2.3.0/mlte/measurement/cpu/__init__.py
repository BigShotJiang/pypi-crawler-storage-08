from .local_process_cpu_utilization import (
    CPUStatistics,
    LocalProcessCPUUtilization,
)

__all__ = ["LocalProcessCPUUtilization", "CPUStatistics"]
