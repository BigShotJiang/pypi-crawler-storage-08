"""Scriptworker chain of trust modules."""
