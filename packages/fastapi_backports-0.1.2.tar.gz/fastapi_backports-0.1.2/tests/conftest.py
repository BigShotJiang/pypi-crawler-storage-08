import fastapi_backports.apply  # noqa: F401
