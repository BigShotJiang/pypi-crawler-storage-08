from django.apps import AppConfig


class YandexadmanagerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'YandexAdManager'
