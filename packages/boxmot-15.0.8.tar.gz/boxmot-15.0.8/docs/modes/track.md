# track

::: mkdocs-click
    :module: boxmot.engine.cli
    :command: boxmot
    :depth: 1
    :command: track
    :style: table
    :prog_name: boxmot track