Mid-level APIs for concept layers
==============================================

:mod:`torch_concepts.nn.bottleneck`

.. automodule:: torch_concepts.nn.bottleneck
    :members: