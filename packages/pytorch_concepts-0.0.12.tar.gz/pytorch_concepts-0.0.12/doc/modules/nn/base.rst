Low-level APIs for concept layers
==============================================

:mod:`torch_concepts.nn.base`

.. automodule:: torch_concepts.nn.base
    :members: