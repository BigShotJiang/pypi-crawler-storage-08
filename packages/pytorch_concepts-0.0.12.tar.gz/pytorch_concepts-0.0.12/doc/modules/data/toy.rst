APIs for toy data
==============================================

:mod:`torch_concepts.data.toy`

.. automodule:: torch_concepts.data.toy
    :members: