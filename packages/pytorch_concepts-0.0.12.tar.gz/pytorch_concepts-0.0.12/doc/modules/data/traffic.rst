APIs for the TrafficLights dataset
==============================================

:mod:`torch_concepts.data.traffic`

.. automodule:: torch_concepts.data.traffic
    :members: