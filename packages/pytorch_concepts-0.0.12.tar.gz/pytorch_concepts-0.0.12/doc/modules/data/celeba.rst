APIs for CelebA dataset
==============================================

:mod:`torch_concepts.data.celeba`

.. automodule:: torch_concepts.data.celeba
    :members: