# Who-Installed

Helps you figure out which CLI installer installeda CLI utility.

Currently only supports Windows

## Status

The project is in early stages.
It works on my machine, but was not heavily tested.
Also, the output is very raw.

If it fails for you, please submit a bug report!

## Usage

```shell
uvx who-installed <name>
```
