#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UProxier 模块主入口
"""

from .cli import cli

if __name__ == "__main__":
    cli()
