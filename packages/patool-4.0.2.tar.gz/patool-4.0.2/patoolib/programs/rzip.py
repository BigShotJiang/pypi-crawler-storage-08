# Copyright (C) 2010-2023 Bastian Kleineidam
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""Archive commands for the rzip program."""

from .. import fileutil


def extract_rzip(archive, compression, cmd, verbosity, interactive, outdir):
    """Extract an RZIP archive."""
    cmdlist = [cmd, '-d', '-k']
    if verbosity > 1:
        cmdlist.append('-v')
    outfile = fileutil.get_single_outfile(outdir, archive)
    cmdlist.extend(["-o", outfile, archive])
    return cmdlist


def create_rzip(archive, compression, cmd, verbosity, interactive, filenames):
    """Create an RZIP archive."""
    cmdlist = [cmd, '-k', '-o', archive]
    if verbosity > 1:
        cmdlist.append('-v')
    cmdlist.extend(filenames)
    return cmdlist
