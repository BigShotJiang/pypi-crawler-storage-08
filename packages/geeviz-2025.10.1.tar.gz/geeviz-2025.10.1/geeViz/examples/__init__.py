"""
Examples of how to use geeViz for numerous use cases. Varies from data processing to more visualization-focused examples.
"""

"""
   Copyright 2025 Ian Housman

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
"""
__author__ = "Ian Housman"
__email__ = "ian.housman@gmail.com"

# Version format yyyy.m.n
__version__ = "2025.10.1"
