from datetime import datetime
from test.unit.base import ClientBaseCase
from test.unit.objects.linode_interface_test import (
    LinodeInterfaceTest,
    build_interface_options_public,
    build_interface_options_vlan,
    build_interface_options_vpc,
)

from linode_api4 import (
    InstanceDiskEncryptionType,
    InterfaceGeneration,
    NetworkInterface,
)
from linode_api4.objects import (
    Config,
    ConfigInterface,
    ConfigInterfaceIPv4,
    Disk,
    Image,
    Instance,
    StackScript,
    Type,
    VPCSubnet,
)


class LinodeTest(ClientBaseCase):
    """
    Tests methods of the Linode class
    """

    def test_get_linode(self):
        """
        Tests that a client is loaded correctly by ID
        """
        linode = Instance(self.client, 123)
        self.assertEqual(linode._populated, False)

        self.assertEqual(linode.label, "linode123")
        self.assertEqual(linode.group, "test")

        self.assertTrue(isinstance(linode.image, Image))
        self.assertEqual(linode.image.label, "Ubuntu 17.04")
        self.assertEqual(
            linode.host_uuid, "3a3ddd59d9a78bb8de041391075df44de62bfec8"
        )
        self.assertEqual(linode.watchdog_enabled, True)
        self.assertEqual(
            linode.disk_encryption, InstanceDiskEncryptionType.disabled
        )
        self.assertEqual(linode.lke_cluster_id, None)
        self.assertEqual(linode.maintenance_policy, "linode/migrate")

        json = linode._raw_json
        self.assertIsNotNone(json)
        self.assertEqual(json["id"], 123)
        self.assertEqual(json["label"], "linode123")
        self.assertEqual(json["group"], "test")

        # test that the _raw_json stored on the object is sufficient to populate
        # a new object
        linode2 = Instance(self.client, json["id"], json=json)

        self.assertTrue(linode2._populated)
        self.assertEqual(linode2.id, linode.id)
        self.assertEqual(linode2.label, linode.label)
        self.assertEqual(linode2.group, linode.group)
        self.assertEqual(linode2._raw_json, linode._raw_json)

    def test_transfer(self):
        """
        Tests that you can get transfer
        """
        linode = Instance(self.client, 123)

        transfer = linode.transfer

        self.assertEqual(transfer.quota, 471)
        self.assertEqual(transfer.billable, 0)
        self.assertEqual(transfer.used, 10369075)

    def test_rebuild(self):
        """
        Tests that you can rebuild with an image
        """
        linode = Instance(self.client, 123)

        with self.mock_post("/linode/instances/123") as m:
            pw = linode.rebuild(
                "linode/debian9",
                disk_encryption=InstanceDiskEncryptionType.enabled,
            )

            self.assertIsNotNone(pw)
            self.assertTrue(isinstance(pw, str))

            self.assertEqual(m.call_url, "/linode/instances/123/rebuild")

            self.assertEqual(
                m.call_data,
                {
                    "image": "linode/debian9",
                    "root_pass": pw,
                    "disk_encryption": "enabled",
                },
            )

    def test_available_backups(self):
        """
        Tests that a Linode can retrieve its own backups
        """
        linode = Instance(self.client, 123)

        backups = linode.available_backups

        # assert we got the correct number of automatic backups
        self.assertEqual(len(backups.automatic), 3)

        # examine one automatic backup
        b = backups.automatic[0]
        self.assertEqual(b.id, 12345)
        self.assertEqual(b._populated, True)
        self.assertEqual(b.status, "successful")
        self.assertEqual(b.type, "auto")
        self.assertEqual(
            b.created,
            datetime(year=2018, month=1, day=9, hour=0, minute=1, second=1),
        )
        self.assertEqual(
            b.updated,
            datetime(year=2018, month=1, day=9, hour=0, minute=1, second=1),
        )
        self.assertEqual(
            b.finished,
            datetime(year=2018, month=1, day=9, hour=0, minute=1, second=1),
        )
        self.assertEqual(b.region.id, "us-east-1a")
        self.assertEqual(b.label, None)
        self.assertEqual(b.message, None)
        self.assertEqual(b.available, True)

        self.assertEqual(len(b.disks), 2)
        self.assertEqual(b.disks[0].size, 1024)
        self.assertEqual(b.disks[0].label, "Debian 8.1 Disk")
        self.assertEqual(b.disks[0].filesystem, "ext4")
        self.assertEqual(b.disks[1].size, 0)
        self.assertEqual(b.disks[1].label, "256MB Swap Image")
        self.assertEqual(b.disks[1].filesystem, "swap")

        self.assertEqual(len(b.configs), 1)
        self.assertEqual(b.configs[0], "My Debian 8.1 Profile")

        # assert that snapshots came back as expected
        self.assertEqual(backups.snapshot.current, None)
        self.assertEqual(backups.snapshot.in_progress, None)

    def test_update_linode(self):
        """
        Tests that a Linode can be updated
        """
        with self.mock_put("linode/instances/123") as m:
            linode = self.client.load(Instance, 123)

            linode.label = "NewLinodeLabel"
            linode.group = "new_group"
            linode.maintenance_policy = "linode/power_off_on"
            linode.save()

            self.assertEqual(m.call_url, "/linode/instances/123")
            self.assertEqual(
                m.call_data,
                {
                    "alerts": {
                        "cpu": 90,
                        "io": 5000,
                        "network_in": 5,
                        "network_out": 5,
                        "transfer_quota": 80,
                    },
                    "backups": {
                        "enabled": True,
                        "schedule": {"day": "Scheduling", "window": "W02"},
                    },
                    "label": "NewLinodeLabel",
                    "group": "new_group",
                    "tags": ["something"],
                    "watchdog_enabled": True,
                    "maintenance_policy": "linode/power_off_on",
                },
            )

    def test_delete_linode(self):
        """
        Tests that deleting a Linode creates the correct api request
        """
        with self.mock_delete() as m:
            linode = Instance(self.client, 123)
            linode.delete()

            self.assertEqual(m.call_url, "/linode/instances/123")

    def test_reboot(self):
        """
        Tests that you can submit a correct reboot api request
        """
        linode = Instance(self.client, 123)
        result = {}

        with self.mock_post(result) as m:
            linode.reboot()
            self.assertEqual(m.call_url, "/linode/instances/123/reboot")

    def test_shutdown(self):
        """
        Tests that you can submit a correct shutdown api request
        """
        linode = Instance(self.client, 123)
        result = {}

        with self.mock_post(result) as m:
            linode.shutdown()
            self.assertEqual(m.call_url, "/linode/instances/123/shutdown")

    def test_boot(self):
        """
        Tests that you can submit a correct boot api request
        """
        linode = Instance(self.client, 123)
        result = {}

        with self.mock_post(result) as m:
            linode.boot()
            self.assertEqual(m.call_url, "/linode/instances/123/boot")

    def test_resize(self):
        """
        Tests that you can submit a correct resize api request
        """
        linode = Instance(self.client, 123)
        result = {}

        with self.mock_post(result) as m:
            linode.resize(new_type="g6-standard-1")
            self.assertEqual(m.call_url, "/linode/instances/123/resize")
            self.assertEqual(m.call_data["type"], "g6-standard-1")

    def test_resize_with_class(self):
        """
        Tests that you can submit a correct resize api request with a Base class type
        """
        linode = Instance(self.client, 123)
        ltype = Type(self.client, "g6-standard-2")
        result = {}

        with self.mock_post(result) as m:
            linode.resize(new_type=ltype)
            self.assertEqual(m.call_url, "/linode/instances/123/resize")
            self.assertEqual(m.call_data["type"], "g6-standard-2")

    def test_boot_with_config(self):
        """
        Tests that you can submit a correct boot with a config api request
        """
        linode = Instance(self.client, 123)
        config = linode.configs[0]
        result = {}

        with self.mock_post(result) as m:
            linode.boot(config=config)
            self.assertEqual(m.call_url, "/linode/instances/123/boot")

    def test_mutate(self):
        """
        Tests that you can submit a correct mutate api request
        """
        linode = Instance(self.client, 123)
        result = {}

        with self.mock_post(result) as m:
            linode.mutate()
            self.assertEqual(m.call_url, "/linode/instances/123/mutate")
            self.assertEqual(m.call_data["allow_auto_disk_resize"], True)

    def test_firewalls(self):
        """
        Tests that you can submit a correct firewalls api request
        """
        linode = Instance(self.client, 123)

        with self.mock_get("/linode/instances/123/firewalls") as m:
            result = linode.firewalls()
            self.assertEqual(m.call_url, "/linode/instances/123/firewalls")
            self.assertEqual(len(result), 1)

    def test_apply_firewalls(self):
        """
        Tests that you can submit a correct apply firewalls api request
        """
        linode = Instance(self.client, 123)

        with self.mock_post({}) as m:
            result = linode.apply_firewalls()
            self.assertEqual(
                m.call_url, "/linode/instances/123/firewalls/apply"
            )
            self.assertEqual(result, True)

    def test_volumes(self):
        """
        Tests that you can submit a correct volumes api request
        """
        linode = Instance(self.client, 123)

        with self.mock_get("/linode/instances/123/volumes") as m:
            result = linode.volumes()
            self.assertEqual(m.call_url, "/linode/instances/123/volumes")
            self.assertEqual(len(result), 1)

    def test_nodebalancers(self):
        """
        Tests that you can submit a correct nodebalancers api request
        """
        linode = Instance(self.client, 123)

        with self.mock_get("/linode/instances/123/nodebalancers") as m:
            result = linode.nodebalancers()
            self.assertEqual(m.call_url, "/linode/instances/123/nodebalancers")
            self.assertEqual(len(result), 1)

    def test_transfer_year_month(self):
        """
        Tests that you can submit a correct transfer api request
        """
        linode = Instance(self.client, 123)

        with self.mock_get("/linode/instances/123/transfer/2023/4") as m:
            linode.transfer_year_month(2023, 4)
            self.assertEqual(
                m.call_url, "/linode/instances/123/transfer/2023/4"
            )

    def test_lke_cluster(self):
        """
        Tests that you can grab the parent LKE cluster from an instance node
        """
        linode = Instance(self.client, 456)

        assert linode.lke_cluster_id == 18881
        assert linode.lke_cluster.id == linode.lke_cluster_id

    def test_duplicate(self):
        """
        Tests that you can submit a correct disk clone api request
        """
        disk = Disk(self.client, 12345, 123)

        with self.mock_post("/linode/instances/123/disks/12345/clone") as m:
            disk.duplicate()
            self.assertEqual(
                m.call_url, "/linode/instances/123/disks/12345/clone"
            )

        assert disk.disk_encryption == InstanceDiskEncryptionType.disabled

    def test_disk_password(self):
        """
        Tests that you can submit a correct disk password reset api request
        """
        disk = Disk(self.client, 12345, 123)

        with self.mock_post({}) as m:
            disk.reset_root_password()
            self.assertEqual(
                m.call_url, "/linode/instances/123/disks/12345/password"
            )

    def test_instance_password(self):
        """
        Tests that you can submit a correct instance password reset api request
        """
        instance = Instance(self.client, 123)

        with self.mock_post({}) as m:
            instance.reset_instance_root_password()
            self.assertEqual(m.call_url, "/linode/instances/123/password")

    def test_ips(self):
        """
        Tests that you can submit a correct ips api request
        """
        linode = Instance(self.client, 123)

        ips = linode.ips

        assert ips.ipv4 is not None
        assert ips.ipv6 is not None
        assert ips.ipv4.public is not None
        assert ips.ipv4.private is not None
        assert ips.ipv4.shared is not None
        assert ips.ipv4.reserved is not None
        assert ips.ipv4.vpc is not None
        assert ips.ipv6.slaac is not None
        assert ips.ipv6.link_local is not None
        assert ips.ipv6.ranges is not None

        vpc_ip = ips.ipv4.vpc[0]
        assert vpc_ip.nat_1_1 == "172.233.179.133"
        assert vpc_ip.address_range == None
        assert vpc_ip.vpc_id == 39246
        assert vpc_ip.subnet_id == 39388
        assert vpc_ip.config_id == 59036295
        assert vpc_ip.interface_id == 1186165
        assert vpc_ip.active

    def test_initiate_migration(self):
        """
        Tests that you can initiate a pending migration
        """
        linode = Instance(self.client, 123)
        result = {}

        with self.mock_post(result) as m:
            linode.initiate_migration()
            self.assertEqual(m.call_url, "/linode/instances/123/migrate")

    def test_create_disk(self):
        """
        Tests that disk_create behaves as expected
        """
        linode = Instance(self.client, 123)

        with self.mock_post("/linode/instances/123/disks/12345") as m:
            disk, gen_pass = linode.disk_create(
                1234,
                label="test",
                authorized_users=["test"],
                image="linode/debian12",
            )
            self.assertEqual(m.call_url, "/linode/instances/123/disks")
            self.assertEqual(
                m.call_data,
                {
                    "size": 1234,
                    "label": "test",
                    "root_pass": gen_pass,
                    "image": "linode/debian12",
                    "authorized_users": ["test"],
                    "read_only": False,
                },
            )

        assert disk.id == 12345
        assert disk.disk_encryption == InstanceDiskEncryptionType.disabled

    def test_get_placement_group(self):
        """
        Tests that you can get the placement group for a Linode
        """
        linode = Instance(self.client, 123)

        pg = linode.placement_group

        assert pg.id == 123
        assert pg.label == "test"
        assert pg.placement_group_type == "anti_affinity:local"

        # Invalidate the instance and try again
        # This makes sure the implicit refresh/cache logic works
        # as expected
        linode.invalidate()

        pg = linode.placement_group

        assert pg.id == 123
        assert pg.label == "test"
        assert pg.placement_group_type == "anti_affinity:local"

    def test_get_interfaces(self):
        instance = Instance(self.client, 124)

        assert instance.interface_generation == InterfaceGeneration.LINODE

        interfaces = instance.linode_interfaces

        LinodeInterfaceTest.assert_linode_124_interface_123(
            next(iface for iface in interfaces if iface.id == 123)
        )

        LinodeInterfaceTest.assert_linode_124_interface_456(
            next(iface for iface in interfaces if iface.id == 456)
        )

        LinodeInterfaceTest.assert_linode_124_interface_789(
            next(iface for iface in interfaces if iface.id == 789)
        )

    def test_get_interfaces_settings(self):
        instance = Instance(self.client, 124)
        iface_settings = instance.interfaces_settings

        assert iface_settings.network_helper

        assert iface_settings.default_route.ipv4_interface_id == 123
        assert iface_settings.default_route.ipv4_eligible_interface_ids == [
            123,
            456,
            789,
        ]

        assert iface_settings.default_route.ipv6_interface_id == 456
        assert iface_settings.default_route.ipv6_eligible_interface_ids == [
            123,
            456,
        ]

    def test_update_interfaces_settings(self):
        instance = Instance(self.client, 124)
        iface_settings = instance.interfaces_settings

        iface_settings.network_helper = False
        iface_settings.default_route.ipv4_interface_id = 456
        iface_settings.default_route.ipv6_interface_id = 123

        with self.mock_put("/linode/instances/124/interfaces/settings") as m:
            iface_settings.save()

            assert m.call_data == {
                "network_helper": False,
                "default_route": {
                    "ipv4_interface_id": 456,
                    "ipv6_interface_id": 123,
                },
            }

    def test_upgrade_interfaces(self):
        instance = Instance(self.client, 124)

        with self.mock_post("/linode/instances/124/upgrade-interfaces") as m:
            result = instance.upgrade_interfaces(123)

            assert m.called
            assert m.call_data == {"config_id": 123, "dry_run": False}

        assert result.config_id == 123
        assert result.dry_run

        LinodeInterfaceTest.assert_linode_124_interface_123(
            result.interfaces[0]
        )
        LinodeInterfaceTest.assert_linode_124_interface_456(
            result.interfaces[1]
        )
        LinodeInterfaceTest.assert_linode_124_interface_789(
            result.interfaces[2]
        )

    def test_upgrade_interfaces_dry(self):
        instance = Instance(self.client, 124)

        with self.mock_post("/linode/instances/124/upgrade-interfaces") as m:
            result = instance.upgrade_interfaces(123, dry_run=True)

            assert m.called
            assert m.call_data == {
                "config_id": 123,
                "dry_run": True,
            }

        assert result.config_id == 123
        assert result.dry_run

        # We don't use the assertion helpers here because dry runs return
        # a MappedObject.
        assert result.interfaces[0].id == 123
        assert result.interfaces[0].public is not None

        assert result.interfaces[1].id == 456
        assert result.interfaces[1].vpc is not None

        assert result.interfaces[2].id == 789
        assert result.interfaces[2].vlan is not None

    def test_create_interface_public(self):
        instance = Instance(self.client, 124)

        iface = build_interface_options_public()

        with self.mock_post("/linode/instances/124/interfaces/123") as m:
            result = instance.interface_create(**vars(iface))

            assert m.call_data == {
                "firewall_id": iface.firewall_id,
                "default_route": iface.default_route._serialize(),
                "public": iface.public._serialize(),
            }

        LinodeInterfaceTest.assert_linode_124_interface_123(result)

    def test_create_interface_vpc(self):
        instance = Instance(self.client, 124)

        iface = build_interface_options_vpc()

        with self.mock_post("/linode/instances/124/interfaces/456") as m:
            result = instance.interface_create(**vars(iface))

            assert m.call_data == {
                "firewall_id": iface.firewall_id,
                "default_route": iface.default_route._serialize(),
                "vpc": iface.vpc._serialize(),
            }

        LinodeInterfaceTest.assert_linode_124_interface_456(result)

    def test_create_interface_vlan(self):
        instance = Instance(self.client, 124)

        iface = build_interface_options_vlan()

        with self.mock_post("/linode/instances/124/interfaces/789") as m:
            result = instance.interface_create(**vars(iface))

            assert m.call_data == {"vlan": iface.vlan._serialize()}

        LinodeInterfaceTest.assert_linode_124_interface_789(result)


class DiskTest(ClientBaseCase):
    """
    Tests for the Disk object
    """

    def test_resize(self):
        """
        Tests that a resize is submitted correctly
        """
        disk = Disk(self.client, 12345, 123)

        with self.mock_post({}) as m:
            r = disk.resize(1000)

            self.assertTrue(r)

            self.assertEqual(
                m.call_url, "/linode/instances/123/disks/12345/resize"
            )
            self.assertEqual(m.call_data, {"size": 1000})


class ConfigTest(ClientBaseCase):
    """
    Tests for the Config object
    """

    def test_update_interfaces(self):
        """
        Tests that a configs interfaces update correctly
        """

        json = self.client.get("/linode/instances/123/configs/456789")
        config = Config(self.client, 456789, 123, json=json)

        with self.mock_put("/linode/instances/123/configs/456789") as m:
            new_interfaces = [
                {"purpose": "public", "primary": True},
                ConfigInterface("vlan", label="cool-vlan"),
            ]
            expected_body = [new_interfaces[0], new_interfaces[1]._serialize()]

            config.interfaces = new_interfaces

            config.save()

            self.assertEqual(m.call_url, "/linode/instances/123/configs/456789")
            self.assertEqual(m.call_data.get("interfaces"), expected_body)

    def test_get_config(self):
        json = self.client.get("/linode/instances/123/configs/456789")
        config = Config(self.client, 456789, 123, json=json)

        self.assertEqual(config.root_device, "/dev/sda")
        self.assertEqual(config.comments, "")
        self.assertIsNotNone(config.helpers)
        self.assertEqual(config.label, "My Ubuntu 17.04 LTS Profile")
        self.assertEqual(
            config.created,
            datetime(year=2014, month=10, day=7, hour=20, minute=4, second=0),
        )
        self.assertEqual(config.memory_limit, 0)
        self.assertEqual(config.id, 456789)
        self.assertIsNotNone(config.interfaces)
        self.assertEqual(config.run_level, "default")
        self.assertIsNone(config.initrd)
        self.assertEqual(config.virt_mode, "paravirt")
        self.assertIsNotNone(config.devices)

    def test_interface_ipv4(self):
        json = {"vpc": "10.0.0.1", "nat_1_1": "any"}

        ipv4 = ConfigInterfaceIPv4.from_json(json)

        self.assertEqual(ipv4.vpc, "10.0.0.1")
        self.assertEqual(ipv4.nat_1_1, "any")

    def test_config_devices_unwrap(self):
        """
        Tests that config devices can be successfully converted to a dict.
        """

        inst = Instance(self.client, 123)
        assert inst.configs[0].devices.dict.get("sda").get("id") == 12345


class StackScriptTest(ClientBaseCase):
    """
    Tests the methods of the StackScript class.
    """

    def test_get_stackscript(self):
        """
        Tests that a stackscript is loaded correctly by ID
        """
        stackscript = StackScript(self.client, 10079)

        self.assertEqual(stackscript.id, 10079)
        self.assertEqual(stackscript.deployments_active, 1)
        self.assertEqual(stackscript.deployments_total, 12)
        self.assertEqual(stackscript.rev_note, "Set up MySQL")
        self.assertTrue(stackscript.mine)
        self.assertTrue(stackscript.is_public)
        self.assertIsNotNone(stackscript.user_defined_fields)
        self.assertIsNotNone(stackscript.images)


class TypeTest(ClientBaseCase):

    def test_get_type_by_id(self):
        """
        Tests that a Linode type is loaded correctly by ID
        """
        t = Type(self.client, "g6-nanode-1")
        self.assertEqual(t._populated, False)

        self.assertEqual(t.vcpus, 1)
        self.assertEqual(t.gpus, 0)
        self.assertEqual(t.label, "Linode 1024")
        self.assertEqual(t.disk, 20480)
        self.assertEqual(t.type_class, "nanode")
        self.assertEqual(t.region_prices[0].id, "us-east")

    def test_get_type_gpu(self):
        """
        Tests that gpu types load up right
        """
        t = Type(self.client, "g6-gpu-2")
        self.assertEqual(t._populated, False)

        self.assertEqual(t.gpus, 1)
        self.assertEqual(t._populated, True)

    def test_load_type(self):
        """
        Tests that a type can be loaded using LinodeClient.load(...)
        """

        t = self.client.load(Type, "g6-nanode-1")
        self.assertEqual(t._populated, True)
        self.assertEqual(t.type_class, "nanode")

    def test_save_noforce(self):
        """
        Tests that a client will only save if changes are detected
        """
        linode = Instance(self.client, 123)
        self.assertEqual(linode._populated, False)

        self.assertEqual(linode.label, "linode123")
        self.assertEqual(linode.group, "test")

        assert not linode._changed

        with self.mock_put("linode/instances") as m:
            linode.save(force=False)
            assert not m.called

        linode.label = "blah"
        assert linode._changed

        with self.mock_put("linode/instances") as m:
            linode.save(force=False)
            assert m.called
            assert m.call_url == "/linode/instances/123"
            assert m.call_data["label"] == "blah"

        assert not linode._changed

    def test_save_force(self):
        """
        Tests that a client will forcibly save by default
        """
        linode = Instance(self.client, 123)
        self.assertEqual(linode._populated, False)

        self.assertEqual(linode.label, "linode123")
        self.assertEqual(linode.group, "test")

        assert not linode._changed

        with self.mock_put("linode/instances") as m:
            linode.save()
            assert m.called


class ConfigInterfaceTest(ClientBaseCase):
    def test_list(self):
        config = Config(self.client, 456789, 123)
        config._api_get()
        assert {v.id for v in config.interfaces} == {123, 321, 456}
        assert {v.purpose for v in config.interfaces} == {
            "vlan",
            "vpc",
            "public",
        }

    def test_update(self):
        config = Config(self.client, 456789, 123)
        config._api_get()
        config.interfaces = [
            {"purpose": "public"},
            ConfigInterface(
                purpose="vlan", label="cool-vlan", ipam_address="10.0.0.4/32"
            ),
        ]

        with self.mock_put("linode/instances/123/configs/456789") as m:
            config.save()
            assert m.call_url == "/linode/instances/123/configs/456789"
            assert m.call_data["interfaces"] == [
                {"purpose": "public"},
                {
                    "purpose": "vlan",
                    "label": "cool-vlan",
                    "ipam_address": "10.0.0.4/32",
                },
            ]


class TestNetworkInterface(ClientBaseCase):
    def test_create_interface_public(self):
        config = Config(self.client, 456789, 123)
        config._api_get()

        with self.mock_post(
            "linode/instances/123/configs/456789/interfaces/456"
        ) as m:
            interface = config.interface_create_public(primary=True)

            assert m.called
            assert (
                m.call_url == "/linode/instances/123/configs/456789/interfaces"
            )
            assert m.method == "post"
            assert m.call_data == {"purpose": "public", "primary": True}

            assert interface.id == 456
            assert interface.purpose == "public"
            assert interface.primary

    def test_create_interface_vlan(self):
        config = Config(self.client, 456789, 123)
        config._api_get()

        with self.mock_post(
            "linode/instances/123/configs/456789/interfaces/321"
        ) as m:
            interface = config.interface_create_vlan(
                "test-interface", ipam_address="10.0.0.2/32"
            )

            assert m.called
            assert (
                m.call_url == "/linode/instances/123/configs/456789/interfaces"
            )
            assert m.method == "post"
            assert m.call_data == {
                "purpose": "vlan",
                "label": "test-interface",
                "ipam_address": "10.0.0.2/32",
            }

            assert interface.id == 321
            assert interface.purpose == "vlan"
            assert not interface.primary
            assert interface.label == "test-interface"
            assert interface.ipam_address == "10.0.0.2"

    def test_create_interface_vpc(self):
        config = Config(self.client, 456789, 123)
        config._api_get()

        with self.mock_post(
            "linode/instances/123/configs/456789/interfaces/123"
        ) as m:
            interface = config.interface_create_vpc(
                subnet=VPCSubnet(self.client, 789, 123456),
                primary=True,
                ipv4=ConfigInterfaceIPv4(vpc="10.0.0.4", nat_1_1="any"),
                ip_ranges=["10.0.0.0/24"],
            )

            assert m.called
            assert (
                m.call_url == "/linode/instances/123/configs/456789/interfaces"
            )
            assert m.method == "post"
            assert m.call_data == {
                "purpose": "vpc",
                "primary": True,
                "subnet_id": 789,
                "ipv4": {"vpc": "10.0.0.4", "nat_1_1": "any"},
                "ip_ranges": ["10.0.0.0/24"],
            }

            assert interface.id == 123
            assert interface.purpose == "vpc"
            assert interface.primary
            assert interface.vpc.id == 123456
            assert interface.subnet.id == 789
            assert interface.ipv4.vpc == "10.0.0.2"
            assert interface.ipv4.nat_1_1 == "any"
            assert interface.ip_ranges == ["10.0.0.0/24"]

    def test_update(self):
        interface = NetworkInterface(self.client, 123, 456789, 123)
        interface._api_get()

        interface.ipv4.vpc = "10.0.0.3"
        interface.primary = False
        interface.ip_ranges = ["10.0.0.2/32"]

        with self.mock_put(
            "linode/instances/123/configs/456789/interfaces/123/put"
        ) as m:
            interface.save()

            assert m.called
            assert (
                m.call_url
                == "/linode/instances/123/configs/456789/interfaces/123"
            )
            assert m.method == "put"
            assert m.call_data == {
                "primary": False,
                "ipv4": {"vpc": "10.0.0.3", "nat_1_1": "any"},
                "ip_ranges": ["10.0.0.2/32"],
            }

    def test_get_vlan(self):
        interface = NetworkInterface(self.client, 321, 456789, instance_id=123)
        interface._api_get()

        self.assertEqual(interface.id, 321)
        self.assertEqual(interface.ipam_address, "10.0.0.2")
        self.assertEqual(interface.purpose, "vlan")
        self.assertEqual(interface.label, "test-interface")

    def test_get_vpc(self):
        interface = NetworkInterface(self.client, 123, 456789, instance_id=123)
        interface._api_get()

        self.assertEqual(interface.id, 123)
        self.assertEqual(interface.purpose, "vpc")
        self.assertEqual(interface.vpc.id, 123456)
        self.assertEqual(interface.subnet.id, 789)
        self.assertEqual(interface.ipv4.vpc, "10.0.0.2")
        self.assertEqual(interface.ipv4.nat_1_1, "any")
        self.assertEqual(interface.ip_ranges, ["10.0.0.0/24"])
        self.assertEqual(interface.active, True)

    def test_list(self):
        config = Config(self.client, 456789, 123)
        config._api_get()
        interfaces = config.network_interfaces

        assert {v.id for v in interfaces} == {123, 321, 456}
        assert {v.purpose for v in interfaces} == {
            "vlan",
            "vpc",
            "public",
        }

        for v in interfaces:
            assert isinstance(v, NetworkInterface)

    def test_reorder(self):
        config = Config(self.client, 456789, 123)
        config._api_get()
        interfaces = config.network_interfaces

        with self.mock_post({}) as m:
            interfaces.reverse()
            # Let's make sure it supports both IDs and NetworkInterfaces
            interfaces[2] = interfaces[2].id

            config.interface_reorder(interfaces)

            assert (
                m.call_url
                == "/linode/instances/123/configs/456789/interfaces/order"
            )

            assert m.call_data == {"ids": [321, 123, 456]}
