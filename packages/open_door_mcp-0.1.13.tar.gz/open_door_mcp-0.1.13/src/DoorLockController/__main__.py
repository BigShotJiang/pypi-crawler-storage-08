from .mcp_tools import run

def main():
    run()

if __name__ == "__main__":
    main()