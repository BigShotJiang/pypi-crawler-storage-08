#ifndef OT_LAYOUT_GPOS_CHAINCONTEXTPOS_HH
#define OT_LAYOUT_GPOS_CHAINCONTEXTPOS_HH

namespace OT {
namespace Layout {
namespace GPOS_impl {

struct ChainContextPos : ChainContext {};

}
}
}

#endif /* OT_LAYOUT_GPOS_CHAINCONTEXTPOS_HH */
