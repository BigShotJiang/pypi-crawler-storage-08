from logging import (
    LogRecord,
)


class WebEduLogRecord(LogRecord):
    """Запись лога проекта ЭШ."""
