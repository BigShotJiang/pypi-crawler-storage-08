# TODOs

* set correct function signature for the dummy functions attached to the instance in class RemoteObject
* Implement remote attributes