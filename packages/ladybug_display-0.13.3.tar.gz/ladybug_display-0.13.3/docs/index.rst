Welcome to ladybug-display's documentation!
===================================

A library that assigns basic display attributes to ladybug-geometry objects (color, line weight, line type, etc).


Installation
============

``pip install ladybug-display``


ladybug-display
=======

.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. include:: modules.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
