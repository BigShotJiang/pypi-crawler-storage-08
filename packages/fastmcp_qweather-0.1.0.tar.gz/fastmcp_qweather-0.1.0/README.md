# Weather MCP Server

一个基于 FastMCP 的和风天气（QWeather）查询服务，提供以下工具：

- `lookup_city(location)`: 城市/位置查询（名称或经纬度）
- `get_warning(location)`: 天气预警查询（LocationID 或经纬度）
- `get_forecast(location)`: 当前天气查询（LocationID 或经纬度）

## 安装与运行

- 克隆仓库：

```bash
git clone --depth 1 https://github.com/gandli/Weather-MCP-Server
uv sync
```

- 在支持 MCP 的客户端中，可添加如下配置以 `stdio` 方式启动本服务：

```json
{
  "mcpServers": {
    "weather": {
      "name": "weather",
      "type": "stdio",
      "description": "一个基于 FastMCP 的和风天气（QWeather）查询服务",
      "isActive": true,
      "registryUrl": "",
      "command": "uv",
      "args": [
        "--directory",
        "path/to/Weather-MCP-Server",
        "run",
        "main.py"
      ],
      "env": {
        "QWEATHER_API_HOST": "your_api_host",
        "QWEATHER_API_KEY": "your_api_key"
      }
    }
  }
}
```

### 零克隆使用（更省事的方式）
- 如果已发布到 PyPI（控制台脚本 `weather-mcp`），可在客户端直接使用 `uvx` 调用，无需克隆仓库：

```
{
  "mcpServers": {
    "weather": {
      "name": "weather",
      "type": "stdio",
      "command": "uvx",
      "args": [
        "weather-mcp"
      ],
      "env": {
        "QWEATHER_API_HOST": "your_api_host",
        "QWEATHER_API_KEY": "your_api_key"
      }
    }
  }
}
```

- 或者使用本地已安装的脚本入口（`pipx` 或 `uv pip install -e .` 后）：

```
{
  "mcpServers": {
    "weather": {
      "name": "weather",
      "type": "stdio",
      "command": "weather-mcp",
      "env": {
        "QWEATHER_API_HOST": "your_api_host",
        "QWEATHER_API_KEY": "your_api_key"
      }
    }
  }
}
```

说明：
- `uvx` 会临时拉取并运行已发布工具的控制台脚本，适合无需克隆的快速使用；
- 若尚未发布到 PyPI，可先克隆仓库后执行 `uv pip install -e .` 安装脚本入口；
- 服务会从环境变量或 `.env` 读取 `QWEATHER_API_HOST` 与 `QWEATHER_API_KEY`。

## 发布到 PyPI
- 确认唯一包名：建议将 `pyproject.toml` 的 `name` 设为不与现有包冲突（当前为 `fastmcp-qweather`）。
- 构建系统：已配置 `[build-system]` 为 `hatchling`，遵循 PEP 517。
- 安装构建与发布工具：
  - `uv pip install build twine`
- 构建发行包：
  - `uv run -m build`
  - 产物位于 `dist/`（包含 `.whl` 和 `.tar.gz`）。
- 先发布到 TestPyPI（推荐）：
  - `uv run -m twine upload --repository-url https://test.pypi.org/legacy/ dist/*`
  - 验证安装：`pip install -i https://test.pypi.org/simple fastmcp-qweather`
- 正式发布到 PyPI：
  - `uv run -m twine upload dist/*`
  - 使用 API Token 更安全：用户名填 `__token__`，密码填从 PyPI 生成的 `pypi-***`。
- 发布后使用：
  - 客户端可用 `uvx weather-mcp`（临时运行控制台脚本），或直接 `command: "weather-mcp"`（已安装）。
- 提示：发布前请更新 `version`，并保证 `README.md` 与环境变量说明最新。

## 许可

未设置专有许可证。如需开源协议，请在 `pyproject.toml` 或根目录添加相应许可文件。
