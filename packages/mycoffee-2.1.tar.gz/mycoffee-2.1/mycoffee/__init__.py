# -*- coding: utf-8 -*-
"""mycoffee modules."""
from mycoffee.params import MY_COFFEE_VERSION
__version__ = MY_COFFEE_VERSION
