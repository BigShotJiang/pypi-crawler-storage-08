# Core Developers
----------
- [@sepandhaghighi](http://github.com/sepandhaghighi)


# Other Contributors
----------
- [@boreshnavard](https://github.com/boreshnavard) **
- [@AHReccese](https://github.com/AHReccese)
- [@sadrasabouri](https://github.com/sadrasabouri)


** Graphic designer
