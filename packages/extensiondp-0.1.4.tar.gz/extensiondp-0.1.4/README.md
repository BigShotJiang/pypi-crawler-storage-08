# Extension DP

Extension DP (Data Package Extension Template) is a GitHub repository template for rapid Data Package extension development
