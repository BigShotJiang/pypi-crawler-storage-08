# nova-meta-prompter

Transform prompts to align with Amazon Nova guidelines.

## Installation

```bash
pip install nova-meta-prompter
```

Or install from source:

```bash
git clone <repository-url>
cd nova_metaprompter
pip install -e .
```

## Quick Start

```python
from nova_meta_prompter import transform_prompt

# Transform a prompt
result = transform_prompt("Summarize this document: {document_text}")

# Get the Nova-aligned prompt
print(result['nova_final'])

# View the transformation process
print(result['thinking'])      # Analysis of changes
print(result['nova_draft'])    # Initial draft
print(result['reflection'])    # Reflection on draft
```

## Advanced Usage

### Custom Model

```python
# Use Claude Sonnet instead of default Nova Premier
result = transform_prompt(
    "Your prompt here",
    model_id='global.anthropic.claude-sonnet-4-5-20250929-v1:0'
)
```

### Custom Boto Client

```python
import boto3
from botocore.config import Config

# Create custom client
config = Config(region_name='us-east-1', read_timeout=2000)
client = boto3.client('bedrock-runtime', config=config)

# Use with transform_prompt
result = transform_prompt("Your prompt", boto_client=client)
```

## Interactive Notebook

Explore the package with the included Jupyter notebook:

```bash
export AWS_PROFILE=your-profile
jupyter notebook nova_metaprompter_showcase.ipynb
```

## AWS Configuration

Set your AWS credentials:

```bash
export AWS_PROFILE=your-profile-name
export AWS_REGION=us-west-2
```

Or use AWS CLI:

```bash
aws configure
```

## Requirements

- Python 3.8+
- AWS Bedrock access with Nova model permissions
- Valid AWS credentials

## What It Does

The transformer:
- Analyzes your existing prompts
- Identifies alignment opportunities with Nova guidelines
- Applies Nova best practices (clear headers, structured format, step-by-step instructions)
- Provides detailed reasoning and reflection on changes

## Development

Run tests:

```bash
pip install -e ".[dev]"
pytest
```

## License

MIT
