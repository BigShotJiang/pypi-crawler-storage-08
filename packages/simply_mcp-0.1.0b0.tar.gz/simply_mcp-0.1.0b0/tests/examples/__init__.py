"""Tests for example servers."""
