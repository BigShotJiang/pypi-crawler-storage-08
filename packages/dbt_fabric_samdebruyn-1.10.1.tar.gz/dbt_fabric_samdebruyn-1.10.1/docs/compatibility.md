# Compatibility

This first release of the fork of this adapter was version 1.10.0. It's compatible with dbt-core 1.9 and 1.10.
