(python-api)=

# Python API

In the pages listed below, one can find the documentation for the Python modules of LightlyTrain.

```{toctree}
:maxdepth: 1

lightly_train
```
