"""Entry point for the MLflow MCP server."""

from mlflow_mcp.server import main

if __name__ == "__main__":
    main()
