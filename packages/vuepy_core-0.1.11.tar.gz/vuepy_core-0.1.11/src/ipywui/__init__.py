# ---------------------------------------------------------
# Copyright (c) vuepy.org. All rights reserved.
# ---------------------------------------------------------
from ipywui.comps import *
from ipywui.core import IPywidgetsComponent
from ipywui.core import wui
from vuepy.version import VERSION

__version__ = VERSION
