<template>
  <slot></slot>
</template>

<script>
export default {
  name: "AccordionItem",
  props: {
    title: String,
  }
}
</script>

<style scoped>

</style>