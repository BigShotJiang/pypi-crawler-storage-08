<template>

</template>

<script>
export default {
  name: "Display",
  props: {
    obj: Object,
    multi_thread: {
      type: Boolean,
      default: false,
    },
  }
}
</script>

<style scoped>

</style>