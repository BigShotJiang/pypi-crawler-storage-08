<template>

</template>

<script>
export default {
  name: "HtmlMath",
  props: {
    value: {
      type: String
    },
    placeholder: {
      type: String,
      default: ''
    },
    description: {
      type: String,
      default: ''
    },
  },
}
</script>

<style scoped>

</style>