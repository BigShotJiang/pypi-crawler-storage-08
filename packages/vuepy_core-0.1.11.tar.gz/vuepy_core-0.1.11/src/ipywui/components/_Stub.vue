<template>

</template>

<script>
export default {
  name: "_Stub.vue"
}
</script>

<style scoped>

</style>