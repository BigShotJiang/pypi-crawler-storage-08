<template>

</template>

<script>
export default {
  name: 'MarkdownViewer',
  props: {
    value: String,
  }
}
</script>

<style scoped>

</style>
