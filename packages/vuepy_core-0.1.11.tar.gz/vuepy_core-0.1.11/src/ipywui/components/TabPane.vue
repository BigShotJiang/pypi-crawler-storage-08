<template>
  <slot></slot>
</template>

<script>
export default {
  name: "TabPane",
  props: {
    title: String,
  },
}
</script>

<style scoped>

</style>
