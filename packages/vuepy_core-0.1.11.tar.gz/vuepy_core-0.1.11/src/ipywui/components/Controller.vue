<template>

</template>

<script>
export default {
  name: "Controller",
  props: {
    index: {
      type: Number,
      default: 0,
    },
  },
}
</script>

<style scoped>

</style>