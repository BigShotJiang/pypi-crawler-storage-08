<template>
 <slot></slot>
</template>

<script>
export default {
  name: 'StackItem',
  props: {
    label: {
      type: String,
    },
  },
}
</script>

<style scoped>

</style>
