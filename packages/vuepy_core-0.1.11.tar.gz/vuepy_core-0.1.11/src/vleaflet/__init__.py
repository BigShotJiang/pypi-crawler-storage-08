# ---------------------------------------------------------
# Copyright (c) vuepy.org. All rights reserved.
# ---------------------------------------------------------
from vuepy.version import VERSION
from vleaflet.core import leaflet
from vleaflet.comps import *

__version__ = VERSION
__all__ = ['leaflet']

'''
store_true参数
-_参数
'''
