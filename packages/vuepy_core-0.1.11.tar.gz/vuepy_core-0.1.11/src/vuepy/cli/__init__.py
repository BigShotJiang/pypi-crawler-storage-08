# ---------------------------------------------------------
# Copyright (c) vuepy.org. All rights reserved.
# ---------------------------------------------------------


def log_info(msg):
    print(f"{msg}")


def log_error(msg):
    print(f"✗ {msg}")


def log_warn(msg):
    print(f"! {msg}")