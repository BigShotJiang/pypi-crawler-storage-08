# coding: utf-8
from vuepy import ref, reactive, App


def setup(props, ctx, app: App):
    return locals()
