<template>
  <Box>Hello Vue.py!</Box>
</template>

<script src="./app.py"></script>
<script setup>
import { ref, reactive } from '$js_stubs_path/vue'
import Box from "$ipywui_path/Box";

</script>

<style scoped>

</style>