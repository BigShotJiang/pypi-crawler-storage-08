import logging


__DEV__ = False
LOG_LEVEL = logging.INFO
