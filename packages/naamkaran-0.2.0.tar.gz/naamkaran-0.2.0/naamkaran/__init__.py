"""
Naamkaran is a library to generate random names.
"""

from naamkaran.generate import generate_names

__all__ = ["generate_names"]
