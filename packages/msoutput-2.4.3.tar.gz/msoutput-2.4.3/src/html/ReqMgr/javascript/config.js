/*
 * Configuration variables for the ReqMgr display
 */

var config = 
{
    // number of additional requests to display on demand
    limitedViewNumOfMoreRequests: 100,
    
} // config