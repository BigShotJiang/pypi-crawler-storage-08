def main():
    print("Hello from hydlpy!")


if __name__ == "__main__":
    main()
