# =====================================
# generator=datazen
# version=3.2.3
# hash=4f118783c6fe63c7193fc7ea2902268b
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "An interface generator for distributed computing."
PKG_NAME = "ifgen"
VERSION = "4.6.2"
