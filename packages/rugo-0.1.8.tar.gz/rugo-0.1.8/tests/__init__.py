"""
Test suite for rugo package.
"""