from agentsyun_coupon_mcp_server import main

main()