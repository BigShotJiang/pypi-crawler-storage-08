from honeybee_display.cli import display

if __name__ == '__main__':
    display()
