"""Extension of honeybee-radiance with display attributes."""
