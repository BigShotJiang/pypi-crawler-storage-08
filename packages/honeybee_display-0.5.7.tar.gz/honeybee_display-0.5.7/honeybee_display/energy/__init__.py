"""Extension of honeybee-energy with display attributes."""
