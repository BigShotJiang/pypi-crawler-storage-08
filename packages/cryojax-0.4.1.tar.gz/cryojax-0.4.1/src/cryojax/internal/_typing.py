import numpy as np
from jaxtyping import Array


NDArrayLike = Array | np.ndarray
