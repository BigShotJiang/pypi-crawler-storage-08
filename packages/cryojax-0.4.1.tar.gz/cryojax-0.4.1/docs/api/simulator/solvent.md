# Modeling the solvent in cryo-EM images
