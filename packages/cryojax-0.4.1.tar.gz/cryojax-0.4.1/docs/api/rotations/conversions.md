# Helpers for converting angular parameterizations
