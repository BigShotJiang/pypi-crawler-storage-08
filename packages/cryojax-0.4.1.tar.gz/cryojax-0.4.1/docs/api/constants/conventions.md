# Converting between common conventions

Here, helper functions for converting between common conventions are described.

::: cryojax.constants.convert_b_factor_to_variance

::: cryojax.constants.convert_variance_to_b_factor
