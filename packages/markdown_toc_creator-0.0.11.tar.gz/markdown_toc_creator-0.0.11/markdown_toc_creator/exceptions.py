class HeaderLevelNotContinuousException(Exception):
    pass
