"""Top-level annobel namespace package."""
from .main import main, run  # noqa: F401

__all__ = ["main", "run"]
__version__ = "0.0.2"
