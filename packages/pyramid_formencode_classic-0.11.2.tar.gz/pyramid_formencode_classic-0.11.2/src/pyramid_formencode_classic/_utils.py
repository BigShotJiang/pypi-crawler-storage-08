from typing import Dict
from typing import Iterable
from typing import Union

# ==============================================================================

TYPES_ERRORS = Union[str, Dict, Iterable, None]
