PCT_COVERED_KEY = "pct_coverage"
