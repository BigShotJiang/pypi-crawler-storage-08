from ddtrace.internal.logger import get_logger


log = get_logger(__name__)
