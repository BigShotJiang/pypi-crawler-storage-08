class Cancelled(Exception):
    pass

class Audiomode(Exception):
    pass

class Videomode(Exception):
    pass

class Filesmode(Exception):
    pass
