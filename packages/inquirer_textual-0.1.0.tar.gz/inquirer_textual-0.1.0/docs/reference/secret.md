# InquirerSecret

::: inquirer_textual.widgets.InquirerSecret.InquirerSecret
