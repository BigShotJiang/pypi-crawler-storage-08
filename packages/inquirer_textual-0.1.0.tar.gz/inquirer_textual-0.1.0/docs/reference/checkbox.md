# InquirerCheckbox

::: inquirer_textual.widgets.InquirerCheckbox.InquirerCheckbox
