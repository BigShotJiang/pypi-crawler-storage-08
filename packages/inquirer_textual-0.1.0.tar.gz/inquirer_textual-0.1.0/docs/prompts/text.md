# Text

```python
--8<-- "examples/prompts/text.py"
```
