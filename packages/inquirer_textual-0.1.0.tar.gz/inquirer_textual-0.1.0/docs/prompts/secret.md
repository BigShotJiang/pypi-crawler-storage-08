# Secret

A secret input prompt that allows the user to enter a secret value (e.g.,
password).

## Example

![Example](secret.gif)

```python
--8<-- "examples/prompts/secret.py"
```
