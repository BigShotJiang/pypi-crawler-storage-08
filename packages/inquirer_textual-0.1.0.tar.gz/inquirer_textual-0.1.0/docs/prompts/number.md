# Number

A number input widget that allows the user to input a numerical value.

## Example

![Example](number.gif)

```python
--8<-- "examples/prompts/number.py"
```
