# Checkbox

A checkbox widget that allows multiple selections from a list of choices.

## Example

![Example](checkbox.gif)

```python
--8<-- "examples/prompts/checkbox.py"
```

