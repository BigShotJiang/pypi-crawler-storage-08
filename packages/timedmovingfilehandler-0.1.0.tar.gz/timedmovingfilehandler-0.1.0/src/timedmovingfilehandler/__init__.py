#!/usr/bin/env python3

from .main import TimedMovingFileHandler

__all__ = ["TimedMovingFileHandler"]
