.. _getting-started:

Getting started
===============
Work in progress, consult https://puzzlepiece.readthedocs.io/en/stable/ and its tutorial
for an introduction to ``puzzlepiece`` in the meantime!