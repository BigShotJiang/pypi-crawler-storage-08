from omada_client.client import OmadaClient

__all__ = ['OmadaClient']
__author__ = "Erilov Nikita"