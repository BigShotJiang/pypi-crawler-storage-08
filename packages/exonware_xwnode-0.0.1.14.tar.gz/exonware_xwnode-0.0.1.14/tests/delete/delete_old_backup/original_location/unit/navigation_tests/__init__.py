"""
xNode Navigation Tests
======================

Path resolution and navigation functionality tests for XNode.
"""

__version__ = "1.0.0" 