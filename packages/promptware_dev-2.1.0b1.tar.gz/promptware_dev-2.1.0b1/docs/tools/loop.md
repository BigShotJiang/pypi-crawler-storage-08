# Loop Tool

Iterate items and report iteration count.
