Publications using Eelbrain
---------------------------

Ordered by year and alphabetically according to authors' last name:

.. bibliography:: publications.bib
   :all:
   :style: year
   :filter: type % "^(?!.*thesis).+$"
