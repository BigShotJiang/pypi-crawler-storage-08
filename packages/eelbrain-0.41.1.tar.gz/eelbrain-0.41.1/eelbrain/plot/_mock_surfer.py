"""Replace surfer for building docs on readthedocs"""


class Brain:
    pass
