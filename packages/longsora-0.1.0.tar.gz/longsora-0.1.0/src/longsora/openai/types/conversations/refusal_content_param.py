# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from ..responses.response_output_refusal_param import \
    ResponseOutputRefusalParam

RefusalContentParam = ResponseOutputRefusalParam
