# Minimal shim: configuration lives in pyproject.toml (PEP 621).
# Prefer: `pip install -e .` or `python -m build`.
from setuptools import setup

if __name__ == "__main__":
    setup()

