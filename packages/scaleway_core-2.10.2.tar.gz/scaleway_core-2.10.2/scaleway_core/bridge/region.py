Region = str
REGION_FR_PAR = Region("fr-par")
REGION_NL_AMS = Region("nl-ams")
REGION_PL_WAW = Region("pl-waw")

ALL_REGIONS = [
    REGION_FR_PAR,
    REGION_NL_AMS,
    REGION_PL_WAW,
]
