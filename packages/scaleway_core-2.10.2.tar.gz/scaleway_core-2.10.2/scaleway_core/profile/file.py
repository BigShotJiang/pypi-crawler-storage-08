CONFIG_PROPERTIES_TO_PROFILE = {
    "access_key": "access_key",
    "secret_key": "secret_key",
    "api_url": "api_url",
    "default_organization_id": "default_organization_id",
    "default_project_id": "default_project_id",
    "default_region": "default_region",
    "default_zone": "default_zone",
}
