"""Scaleway SDK for Python - Core"""

import importlib.metadata

__version__: str = importlib.metadata.version(__name__)
