# Release Notes for v1.0.0-rc2

## ✨  Features

## 🚀 Improvements

**Command line history**

**Documentation restructure**
- The documentation is now stored under `docs/` directory and have a newly written "User Guide".

**More example BN**
- Additional example of Bayesian Networks are included under the `exmples/` directory

## 🐛 Bug Fixes
- None (no-reported bugs)

## 🛠  Build system
- Renamed main entry point to `bayescalc.main`


## 📚 Documentation
- Major rehaul


**Full Changelog**: 