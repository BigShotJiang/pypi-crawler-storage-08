from pathlib import Path

import pytest
from docling.document_converter import DocumentConverter

from hierarchical.hierarchy_builder_metadata import HierarchyBuilderMetadata

results_path = Path(__file__).parent / "results"
sample_path = Path(__file__).parent / "samples"


def test_convert():
    ref_output = """  Some kind of text document
  1. Introduction
    1.1 Background
    1.2 Purpose
  2. Main Content
    2.1 Section One
      2.1.1 Subsection
      2.1.2 Another Subsection
    2.2 Section Two
  3. Conclusion
"""

    source = sample_path / "sample_document.pdf"  # document per local path or URL
    converter = DocumentConverter()
    result = converter.convert(source)
    hbm = HierarchyBuilderMetadata(result)
    root = hbm.infer()
    assert str(root) == ref_output


@pytest.mark.skip(
    reason="essentially tests the same thing as test_convert, but on a 46 page document. Takes a long time to run."
)
def test_convert_r10():
    ref_output = """  Abkürzungsverzeichnis
  1 Veranlagungsschritte im Zollveranlagungsverfahren
    1.1 Zuführen
    1.2 Zollüberwachung und Zollprüfung
    1.3 Gestellen und summarisches Anmelden
      1.3.1 Allgemeines
      1.3.2 Form der summarischen Anmeldung
      1.3.3 Manipulationen
      1.3.4 Präzisierungen zum Ende des Gewahrsams des BAZG
      1.3.5 Abstellen auf dem Amtsplatz
    1.4 Anmelden
      1.4.1 Allgemeines
      1.4.2 Form der Einfuhrzollanmeldung (EZA)
      1.4.3 Vereinfachte Zollanmeldung für abgabenfreie Sendungen
      1.4.4 Bedeutung der zolltarifarischen Einreihung
      1.4.5 Veranlagungstext
      1.4.6 Antrag auf Zollermässigung oder Zollbefreiung
      1.4.7 Zollbemessung
      1.4.8 Kollektive Zollanmeldung
      1.4.9 Begleitdokumente
    1.5 Summarische Prüfung
    1.6 Annahme der EZA
      1.6.1 Selektion e-dec Import
      1.6.2 Selektion e-dec-web Import
    1.7 Formelle Überprüfung der angenommenen EZA
      1.7.1 Allgemeines
      1.7.2 Prüfung von Ursprungsnachweisen
      1.7.3 Unstimmigkeiten bei der formellen Überprüfung der EZA
      1.7.4 Erneute Vorlage einer beanstandeten EZA
    1.8 Beschau
      1.8.1 Allgemeines
      1.8.2 Zweck der Beschau
      1.8.3 Vorgehen bei der Beschau
      1.8.4 Protokollierung von Schäden
      1.8.5 Unstimmigkeiten bei der Beschau
      1.8.6 Beschau am Domizil
      1.8.7 Kontrolle des Bruttogewichts
      1.8.8 Kontrolle der Eigenmasse
      1.8.9 Musterentnahme
      1.8.10  Zollbefund
    1.9 Ausstellen und eröffnen der Veranlagungsverfügung
      1.9.1 Allgemeines
      1.9.2 Zweck
      1.9.3 Ausstellen der Veranlagungsverfügung
        1.9.3.1 Barzahlung
        1.9.3.2 Zahlung im Rahmen des zentralisierten Abrechnungsverfahrens des BAZG (ZAZ)
        1.9.3.3 Hinweis auf Rechtsmittel in e-dec
      1.9.4 Ausstellen von Duplikaten
        1.9.4.1 Allgemein
        1.9.4.2 Ausfuhrerstattung in der EU; Duplikate VVZ und VVM
    1.10  Freigabe und Abtransport von Waren
      1.10.1  Allgemeines
      1.10.2  Vorzeitiger Abtransport von Waren
      1.10.3  Unveranlagte Auslieferung
  2 Besonderheiten
    2.1 Vernichtung von Waren
    2.2 Haftung des Bundes
  3 Zeiten und Fristen
    3.1 Übersicht
    3.2 Frist zur Zollanmeldung
      3.2.1 Zollanmeldung bei Gestellung
      3.2.2 Voranmeldung
    3.3 Frist zur Vorlage der Zollanmeldung
    3.4 Frist zum Abtransport von Waren
  4 Pflichten und Rechte der anmeldepflichtigen Person
    4.1 Übersicht
    4.2 Rechte vor Abgabe der Zollanmeldung
    4.3 Schriftliche Zolltarifauskunft
      4.3.1 Allgemeines
      4.3.2 Zuständigkeit
      4.3.3 Warensortimente
      4.3.4 Tarifanfrage (Form 40.10)
      4.3.5 E-Mail - Anfragen
    4.4 Mündliche Zolltarifauskunft
    4.5 Besichtigung
    4.6 Mitwirkung bei der Beschau
  5 Archivierung von Daten und Dokumenten
    5.1 Aufbewahrung durch die anmeldepflichtige Person
    5.2 Aufbewahrung durch das BAZG
  6 Rechtsgrundlagen
  7 Begriffe
    7.1 Anmeldepflichtige Personen
    7.2 Veranlagungsbehörde
    7.3 Veranlagungsobjekt
    7.4 Veranlagungspartei
    7.5 Zollveranlagung
    7.6 Zuführungspflichtige Personen
"""

    source = sample_path / "R-10-00.pdf"  # document per local path or URL
    converter = DocumentConverter()
    result = converter.convert(source)
    hbm = HierarchyBuilderMetadata(result)
    root = hbm.infer()
    assert str(root) == ref_output
