class ComponentType():
    unDef   = 'undef'
    std     = 'std'
    hmCloud = 'hmCloud'
    mqtt    = 'mqtt' # MQTT Datapoint
    mqttServer = 'mqttServer' # MQTT-Server Connector