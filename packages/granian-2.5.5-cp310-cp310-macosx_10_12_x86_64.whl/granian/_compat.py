import sys


_PYV = int(sys.version_info.major * 100 + sys.version_info.minor)
_PY_312 = 312
