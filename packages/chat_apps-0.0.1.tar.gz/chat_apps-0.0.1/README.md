# chat-apps

A placeholder package to reserve the name `chat-apps`.

## Installation

```bash
pip install chat-apps
```

## License

MIT
