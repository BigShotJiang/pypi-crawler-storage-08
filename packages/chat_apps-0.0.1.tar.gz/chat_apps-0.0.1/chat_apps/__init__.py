"""
chat-apps: A placeholder package to reserve the name
"""

__version__ = "0.0.1"

def get_package_name():
    """Return the package name"""
    return "chat-apps"
