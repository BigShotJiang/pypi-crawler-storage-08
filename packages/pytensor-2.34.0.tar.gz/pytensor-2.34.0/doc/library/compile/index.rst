
.. _libdoc_compile:

==============================================================
:mod:`compile` -- Transforming Expression Graphs to Functions
==============================================================

.. module:: compile
   :platform: Unix, Windows
   :synopsis: transforming expression graphs to functions
.. moduleauthor:: LISA

.. toctree::
    :maxdepth: 1

    shared
    function
    io
    ops
    mode
    debugmode
    nanguardmode



