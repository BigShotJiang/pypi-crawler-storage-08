..  ../../../../pytensor/sandbox/slinalg.py

.. _libdoc_slinalg:

===================================================================
:mod:`tensor.slinalg` --  Linear Algebra Ops Using Scipy
===================================================================

.. module:: tensor.slinalg
   :platform: Unix, Windows
   :synopsis: Linear Algebra Ops Using Scipy
.. moduleauthor:: LISA

.. note::

   This module is not imported by default. You need to import it to use it.

API
===

.. automodule:: pytensor.tensor.slinalg
    :members:

