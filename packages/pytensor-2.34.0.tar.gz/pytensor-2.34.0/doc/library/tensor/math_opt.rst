===================================================================
:mod:`tensor.rewriting.math` -- Tensor Rewrites for Math Operations
===================================================================

.. module:: tensor.rewriting.math
   :platform: Unix, Windows
   :synopsis: Tensor Rewrites for Math Operations
.. moduleauthor:: LISA, PyMC Developers, PyTensor Developers

.. automodule:: pytensor.tensor.rewriting.math
    :members:
