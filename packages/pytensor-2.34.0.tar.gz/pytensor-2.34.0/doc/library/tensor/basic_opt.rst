================================================
:mod:`tensor.rewriting.basic` -- Tensor Rewrites
================================================

.. module:: tensor.rewriting.basic
   :platform: Unix, Windows
   :synopsis: Tensor Rewrites
.. moduleauthor:: LISA, PyMC Developers, PyTensor Developers

.. automodule:: pytensor.tensor.rewriting.basic
    :members:
