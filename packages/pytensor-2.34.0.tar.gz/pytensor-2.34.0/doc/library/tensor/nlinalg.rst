..  ../../../../pytensor/sandbox/nlinalg.py

.. _libdoc_linalg:

===================================================================
:mod:`tensor.nlinalg` --  Linear Algebra Ops Using Numpy
===================================================================

.. module:: tensor.nlinalg
   :platform: Unix, Windows
   :synopsis: Linear Algebra Ops Using Numpy
.. moduleauthor:: LISA

.. note::

   This module is not imported by default. You need to import it to use it.

API
===

.. automodule:: pytensor.tensor.nlinalg
    :members:
