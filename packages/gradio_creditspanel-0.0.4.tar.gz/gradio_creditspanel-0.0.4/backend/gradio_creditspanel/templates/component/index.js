var so = Object.defineProperty;
var Wn = (o) => {
  throw TypeError(o);
};
var ro = (o, e, t) => e in o ? so(o, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : o[e] = t;
var H = (o, e, t) => ro(o, typeof e != "symbol" ? e + "" : e, t), uo = (o, e, t) => e.has(o) || Wn("Cannot " + t);
var Kn = (o, e, t) => e.has(o) ? Wn("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(o) : e.set(o, t);
var Kt = (o, e, t) => (uo(o, e, "access private method"), t);
const {
  SvelteComponent: _o,
  append_hydration: En,
  assign: co,
  attr: oe,
  binding_callbacks: fo,
  children: Tt,
  claim_element: Al,
  claim_space: Sl,
  claim_svg_element: Dn,
  create_slot: ho,
  detach: He,
  element: ql,
  empty: Qn,
  get_all_dirty_from_scope: po,
  get_slot_changes: mo,
  get_spread_update: go,
  init: vo,
  insert_hydration: Lt,
  listen: bo,
  noop: Do,
  safe_not_equal: yo,
  set_dynamic_element_data: Jn,
  set_style: O,
  space: Bl,
  svg_element: yn,
  toggle_class: ee,
  transition_in: Tl,
  transition_out: zl,
  update_slot_base: wo
} = window.__gradio__svelte__internal;
function ei(o) {
  let e, t, n, l, i;
  return {
    c() {
      e = yn("svg"), t = yn("line"), n = yn("line"), this.h();
    },
    l(a) {
      e = Dn(a, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var s = Tt(e);
      t = Dn(s, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Tt(t).forEach(He), n = Dn(s, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Tt(n).forEach(He), s.forEach(He), this.h();
    },
    h() {
      oe(t, "x1", "1"), oe(t, "y1", "9"), oe(t, "x2", "9"), oe(t, "y2", "1"), oe(t, "stroke", "gray"), oe(t, "stroke-width", "0.5"), oe(n, "x1", "5"), oe(n, "y1", "9"), oe(n, "x2", "9"), oe(n, "y2", "5"), oe(n, "stroke", "gray"), oe(n, "stroke-width", "0.5"), oe(e, "class", "resize-handle svelte-239wnu"), oe(e, "xmlns", "http://www.w3.org/2000/svg"), oe(e, "viewBox", "0 0 10 10");
    },
    m(a, s) {
      Lt(a, e, s), En(e, t), En(e, n), l || (i = bo(
        e,
        "mousedown",
        /*resize*/
        o[27]
      ), l = !0);
    },
    p: Do,
    d(a) {
      a && He(e), l = !1, i();
    }
  };
}
function ko(o) {
  var d;
  let e, t, n, l, i;
  const a = (
    /*#slots*/
    o[31].default
  ), s = ho(
    a,
    o,
    /*$$scope*/
    o[30],
    null
  );
  let r = (
    /*resizable*/
    o[19] && ei(o)
  ), u = [
    { "data-testid": (
      /*test_id*/
      o[11]
    ) },
    { id: (
      /*elem_id*/
      o[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((d = o[7]) == null ? void 0 : d.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: l = /*rtl*/
      o[20] ? "rtl" : "ltr"
    }
  ], _ = {};
  for (let c = 0; c < u.length; c += 1)
    _ = co(_, u[c]);
  return {
    c() {
      e = ql(
        /*tag*/
        o[25]
      ), s && s.c(), t = Bl(), r && r.c(), this.h();
    },
    l(c) {
      e = Al(
        c,
        /*tag*/
        (o[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var h = Tt(e);
      s && s.l(h), t = Sl(h), r && r.l(h), h.forEach(He), this.h();
    },
    h() {
      Jn(
        /*tag*/
        o[25]
      )(e, _), ee(
        e,
        "hidden",
        /*visible*/
        o[14] === !1
      ), ee(
        e,
        "padded",
        /*padding*/
        o[10]
      ), ee(
        e,
        "flex",
        /*flex*/
        o[1]
      ), ee(
        e,
        "border_focus",
        /*border_mode*/
        o[9] === "focus"
      ), ee(
        e,
        "border_contrast",
        /*border_mode*/
        o[9] === "contrast"
      ), ee(e, "hide-container", !/*explicit_call*/
      o[12] && !/*container*/
      o[13]), ee(
        e,
        "fullscreen",
        /*fullscreen*/
        o[0]
      ), ee(
        e,
        "animating",
        /*fullscreen*/
        o[0] && /*preexpansionBoundingRect*/
        o[24] !== null
      ), ee(
        e,
        "auto-margin",
        /*scale*/
        o[17] === null
      ), O(
        e,
        "height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*height*/
            o[2]
          )
        )
      ), O(
        e,
        "min-height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*min_height*/
            o[3]
          )
        )
      ), O(
        e,
        "max-height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*max_height*/
            o[4]
          )
        )
      ), O(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].top}px` : "0px"
      ), O(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].left}px` : "0px"
      ), O(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].width}px` : "0px"
      ), O(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].height}px` : "0px"
      ), O(
        e,
        "width",
        /*fullscreen*/
        o[0] ? void 0 : typeof /*width*/
        o[5] == "number" ? `calc(min(${/*width*/
        o[5]}px, 100%))` : (
          /*get_dimension*/
          o[26](
            /*width*/
            o[5]
          )
        )
      ), O(
        e,
        "border-style",
        /*variant*/
        o[8]
      ), O(
        e,
        "overflow",
        /*allow_overflow*/
        o[15] ? (
          /*overflow_behavior*/
          o[16]
        ) : "hidden"
      ), O(
        e,
        "flex-grow",
        /*scale*/
        o[17]
      ), O(e, "min-width", `calc(min(${/*min_width*/
      o[18]}px, 100%))`), O(e, "border-width", "var(--block-border-width)");
    },
    m(c, h) {
      Lt(c, e, h), s && s.m(e, null), En(e, t), r && r.m(e, null), o[32](e), i = !0;
    },
    p(c, h) {
      var m;
      s && s.p && (!i || h[0] & /*$$scope*/
      1073741824) && wo(
        s,
        a,
        c,
        /*$$scope*/
        c[30],
        i ? mo(
          a,
          /*$$scope*/
          c[30],
          h,
          null
        ) : po(
          /*$$scope*/
          c[30]
        ),
        null
      ), /*resizable*/
      c[19] ? r ? r.p(c, h) : (r = ei(c), r.c(), r.m(e, null)) : r && (r.d(1), r = null), Jn(
        /*tag*/
        c[25]
      )(e, _ = go(u, [
        (!i || h[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          c[11]
        ) },
        (!i || h[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          c[6]
        ) },
        (!i || h[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((m = c[7]) == null ? void 0 : m.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!i || h[0] & /*rtl*/
        1048576 && l !== (l = /*rtl*/
        c[20] ? "rtl" : "ltr")) && { dir: l }
      ])), ee(
        e,
        "hidden",
        /*visible*/
        c[14] === !1
      ), ee(
        e,
        "padded",
        /*padding*/
        c[10]
      ), ee(
        e,
        "flex",
        /*flex*/
        c[1]
      ), ee(
        e,
        "border_focus",
        /*border_mode*/
        c[9] === "focus"
      ), ee(
        e,
        "border_contrast",
        /*border_mode*/
        c[9] === "contrast"
      ), ee(e, "hide-container", !/*explicit_call*/
      c[12] && !/*container*/
      c[13]), ee(
        e,
        "fullscreen",
        /*fullscreen*/
        c[0]
      ), ee(
        e,
        "animating",
        /*fullscreen*/
        c[0] && /*preexpansionBoundingRect*/
        c[24] !== null
      ), ee(
        e,
        "auto-margin",
        /*scale*/
        c[17] === null
      ), h[0] & /*fullscreen, height*/
      5 && O(
        e,
        "height",
        /*fullscreen*/
        c[0] ? void 0 : (
          /*get_dimension*/
          c[26](
            /*height*/
            c[2]
          )
        )
      ), h[0] & /*fullscreen, min_height*/
      9 && O(
        e,
        "min-height",
        /*fullscreen*/
        c[0] ? void 0 : (
          /*get_dimension*/
          c[26](
            /*min_height*/
            c[3]
          )
        )
      ), h[0] & /*fullscreen, max_height*/
      17 && O(
        e,
        "max-height",
        /*fullscreen*/
        c[0] ? void 0 : (
          /*get_dimension*/
          c[26](
            /*max_height*/
            c[4]
          )
        )
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && O(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].top}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && O(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].left}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && O(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].width}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && O(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].height}px` : "0px"
      ), h[0] & /*fullscreen, width*/
      33 && O(
        e,
        "width",
        /*fullscreen*/
        c[0] ? void 0 : typeof /*width*/
        c[5] == "number" ? `calc(min(${/*width*/
        c[5]}px, 100%))` : (
          /*get_dimension*/
          c[26](
            /*width*/
            c[5]
          )
        )
      ), h[0] & /*variant*/
      256 && O(
        e,
        "border-style",
        /*variant*/
        c[8]
      ), h[0] & /*allow_overflow, overflow_behavior*/
      98304 && O(
        e,
        "overflow",
        /*allow_overflow*/
        c[15] ? (
          /*overflow_behavior*/
          c[16]
        ) : "hidden"
      ), h[0] & /*scale*/
      131072 && O(
        e,
        "flex-grow",
        /*scale*/
        c[17]
      ), h[0] & /*min_width*/
      262144 && O(e, "min-width", `calc(min(${/*min_width*/
      c[18]}px, 100%))`);
    },
    i(c) {
      i || (Tl(s, c), i = !0);
    },
    o(c) {
      zl(s, c), i = !1;
    },
    d(c) {
      c && He(e), s && s.d(c), r && r.d(), o[32](null);
    }
  };
}
function ti(o) {
  let e;
  return {
    c() {
      e = ql("div"), this.h();
    },
    l(t) {
      e = Al(t, "DIV", { class: !0 }), Tt(e).forEach(He), this.h();
    },
    h() {
      oe(e, "class", "placeholder svelte-239wnu"), O(
        e,
        "height",
        /*placeholder_height*/
        o[22] + "px"
      ), O(
        e,
        "width",
        /*placeholder_width*/
        o[23] + "px"
      );
    },
    m(t, n) {
      Lt(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && O(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && O(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && He(e);
    }
  };
}
function Fo(o) {
  let e, t, n, l = (
    /*tag*/
    o[25] && ko(o)
  ), i = (
    /*fullscreen*/
    o[0] && ti(o)
  );
  return {
    c() {
      l && l.c(), e = Bl(), i && i.c(), t = Qn();
    },
    l(a) {
      l && l.l(a), e = Sl(a), i && i.l(a), t = Qn();
    },
    m(a, s) {
      l && l.m(a, s), Lt(a, e, s), i && i.m(a, s), Lt(a, t, s), n = !0;
    },
    p(a, s) {
      /*tag*/
      a[25] && l.p(a, s), /*fullscreen*/
      a[0] ? i ? i.p(a, s) : (i = ti(a), i.c(), i.m(t.parentNode, t)) : i && (i.d(1), i = null);
    },
    i(a) {
      n || (Tl(l, a), n = !0);
    },
    o(a) {
      zl(l, a), n = !1;
    },
    d(a) {
      a && (He(e), He(t)), l && l.d(a), i && i.d(a);
    }
  };
}
function $o(o, e, t) {
  let { $$slots: n = {}, $$scope: l } = e, { height: i = void 0 } = e, { min_height: a = void 0 } = e, { max_height: s = void 0 } = e, { width: r = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: _ = [] } = e, { variant: d = "solid" } = e, { border_mode: c = "base" } = e, { padding: h = !0 } = e, { type: m = "normal" } = e, { test_id: p = void 0 } = e, { explicit_call: b = !1 } = e, { container: k = !0 } = e, { visible: g = !0 } = e, { allow_overflow: f = !0 } = e, { overflow_behavior: v = "auto" } = e, { scale: D = null } = e, { min_width: w = 0 } = e, { flex: F = !1 } = e, { resizable: A = !1 } = e, { rtl: y = !1 } = e, { fullscreen: T = !1 } = e, E = T, L, B = m === "fieldset" ? "fieldset" : "div", $ = 0, ue = 0, he = null;
  function lt(C) {
    T && C.key === "Escape" && t(0, T = !1);
  }
  const K = (C) => {
    if (C !== void 0) {
      if (typeof C == "number")
        return C + "px";
      if (typeof C == "string")
        return C;
    }
  }, _e = (C) => {
    let ie = C.clientY;
    const vt = (S) => {
      const bt = S.clientY - ie;
      ie = S.clientY, t(21, L.style.height = `${L.offsetHeight + bt}px`, L);
    }, ge = () => {
      window.removeEventListener("mousemove", vt), window.removeEventListener("mouseup", ge);
    };
    window.addEventListener("mousemove", vt), window.addEventListener("mouseup", ge);
  };
  function ze(C) {
    fo[C ? "unshift" : "push"](() => {
      L = C, t(21, L);
    });
  }
  return o.$$set = (C) => {
    "height" in C && t(2, i = C.height), "min_height" in C && t(3, a = C.min_height), "max_height" in C && t(4, s = C.max_height), "width" in C && t(5, r = C.width), "elem_id" in C && t(6, u = C.elem_id), "elem_classes" in C && t(7, _ = C.elem_classes), "variant" in C && t(8, d = C.variant), "border_mode" in C && t(9, c = C.border_mode), "padding" in C && t(10, h = C.padding), "type" in C && t(28, m = C.type), "test_id" in C && t(11, p = C.test_id), "explicit_call" in C && t(12, b = C.explicit_call), "container" in C && t(13, k = C.container), "visible" in C && t(14, g = C.visible), "allow_overflow" in C && t(15, f = C.allow_overflow), "overflow_behavior" in C && t(16, v = C.overflow_behavior), "scale" in C && t(17, D = C.scale), "min_width" in C && t(18, w = C.min_width), "flex" in C && t(1, F = C.flex), "resizable" in C && t(19, A = C.resizable), "rtl" in C && t(20, y = C.rtl), "fullscreen" in C && t(0, T = C.fullscreen), "$$scope" in C && t(30, l = C.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && T !== E && (t(29, E = T), T ? (t(24, he = L.getBoundingClientRect()), t(22, $ = L.offsetHeight), t(23, ue = L.offsetWidth), window.addEventListener("keydown", lt)) : (t(24, he = null), window.removeEventListener("keydown", lt))), o.$$.dirty[0] & /*visible*/
    16384 && (g || t(1, F = !1));
  }, [
    T,
    F,
    i,
    a,
    s,
    r,
    u,
    _,
    d,
    c,
    h,
    p,
    b,
    k,
    g,
    f,
    v,
    D,
    w,
    A,
    y,
    L,
    $,
    ue,
    he,
    B,
    K,
    _e,
    m,
    E,
    l,
    n,
    ze
  ];
}
class Co extends _o {
  constructor(e) {
    super(), vo(
      this,
      e,
      $o,
      Fo,
      yo,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function jn() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let gt = jn();
function Il(o) {
  gt = o;
}
const Rl = /[&<>"']/, Eo = new RegExp(Rl.source, "g"), Ll = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Ao = new RegExp(Ll.source, "g"), So = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, ni = (o) => So[o];
function be(o, e) {
  if (e) {
    if (Rl.test(o))
      return o.replace(Eo, ni);
  } else if (Ll.test(o))
    return o.replace(Ao, ni);
  return o;
}
const qo = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Bo(o) {
  return o.replace(qo, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const To = /(^|[^\[])\^/g;
function N(o, e) {
  let t = typeof o == "string" ? o : o.source;
  e = e || "";
  const n = {
    replace: (l, i) => {
      let a = typeof i == "string" ? i : i.source;
      return a = a.replace(To, "$1"), t = t.replace(l, a), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function ii(o) {
  try {
    o = encodeURI(o).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return o;
}
const zt = { exec: () => null };
function li(o, e) {
  const t = o.replace(/\|/g, (i, a, s) => {
    let r = !1, u = a;
    for (; --u >= 0 && s[u] === "\\"; )
      r = !r;
    return r ? "|" : " |";
  }), n = t.split(/ \|/);
  let l = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; l < n.length; l++)
    n[l] = n[l].trim().replace(/\\\|/g, "|");
  return n;
}
function Qt(o, e, t) {
  const n = o.length;
  if (n === 0)
    return "";
  let l = 0;
  for (; l < n && o.charAt(n - l - 1) === e; )
    l++;
  return o.slice(0, n - l);
}
function zo(o, e) {
  if (o.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < o.length; n++)
    if (o[n] === "\\")
      n++;
    else if (o[n] === e[0])
      t++;
    else if (o[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function oi(o, e, t, n) {
  const l = e.href, i = e.title ? be(e.title) : null, a = o[1].replace(/\\([\[\]])/g, "$1");
  if (o[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const s = {
      type: "link",
      raw: t,
      href: l,
      title: i,
      text: a,
      tokens: n.inlineTokens(a)
    };
    return n.state.inLink = !1, s;
  }
  return {
    type: "image",
    raw: t,
    href: l,
    title: i,
    text: be(a)
  };
}
function Io(o, e) {
  const t = o.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((l) => {
    const i = l.match(/^\s+/);
    if (i === null)
      return l;
    const [a] = i;
    return a.length >= n.length ? l.slice(n.length) : l;
  }).join(`
`);
}
class _n {
  // set by the lexer
  constructor(e) {
    H(this, "options");
    H(this, "rules");
    // set by the lexer
    H(this, "lexer");
    this.options = e || gt;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : Qt(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], l = Io(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: l
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const l = Qt(n, "#");
        (this.options.pedantic || !l || / $/.test(l)) && (n = l.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = Qt(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const l = this.lexer.state.top;
      this.lexer.state.top = !0;
      const i = this.lexer.blockTokens(n);
      return this.lexer.state.top = l, {
        type: "blockquote",
        raw: t[0],
        tokens: i,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const l = n.length > 1, i = {
        type: "list",
        raw: "",
        ordered: l,
        start: l ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = l ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = l ? n : "[*+-]");
      const a = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let s = "", r = "", u = !1;
      for (; e; ) {
        let _ = !1;
        if (!(t = a.exec(e)) || this.rules.block.hr.test(e))
          break;
        s = t[0], e = e.substring(s.length);
        let d = t[2].split(`
`, 1)[0].replace(/^\t+/, (k) => " ".repeat(3 * k.length)), c = e.split(`
`, 1)[0], h = 0;
        this.options.pedantic ? (h = 2, r = d.trimStart()) : (h = t[2].search(/[^ ]/), h = h > 4 ? 1 : h, r = d.slice(h), h += t[1].length);
        let m = !1;
        if (!d && /^ *$/.test(c) && (s += c + `
`, e = e.substring(c.length + 1), _ = !0), !_) {
          const k = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), g = new RegExp(`^ {0,${Math.min(3, h - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), f = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:\`\`\`|~~~)`), v = new RegExp(`^ {0,${Math.min(3, h - 1)}}#`);
          for (; e; ) {
            const D = e.split(`
`, 1)[0];
            if (c = D, this.options.pedantic && (c = c.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), f.test(c) || v.test(c) || k.test(c) || g.test(e))
              break;
            if (c.search(/[^ ]/) >= h || !c.trim())
              r += `
` + c.slice(h);
            else {
              if (m || d.search(/[^ ]/) >= 4 || f.test(d) || v.test(d) || g.test(d))
                break;
              r += `
` + c;
            }
            !m && !c.trim() && (m = !0), s += D + `
`, e = e.substring(D.length + 1), d = c.slice(h);
          }
        }
        i.loose || (u ? i.loose = !0 : /\n *\n *$/.test(s) && (u = !0));
        let p = null, b;
        this.options.gfm && (p = /^\[[ xX]\] /.exec(r), p && (b = p[0] !== "[ ] ", r = r.replace(/^\[[ xX]\] +/, ""))), i.items.push({
          type: "list_item",
          raw: s,
          task: !!p,
          checked: b,
          loose: !1,
          text: r,
          tokens: []
        }), i.raw += s;
      }
      i.items[i.items.length - 1].raw = s.trimEnd(), i.items[i.items.length - 1].text = r.trimEnd(), i.raw = i.raw.trimEnd();
      for (let _ = 0; _ < i.items.length; _++)
        if (this.lexer.state.top = !1, i.items[_].tokens = this.lexer.blockTokens(i.items[_].text, []), !i.loose) {
          const d = i.items[_].tokens.filter((h) => h.type === "space"), c = d.length > 0 && d.some((h) => /\n.*\n/.test(h.raw));
          i.loose = c;
        }
      if (i.loose)
        for (let _ = 0; _ < i.items.length; _++)
          i.items[_].loose = !0;
      return i;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), l = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", i = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: l,
        title: i
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = li(t[1]), l = t[2].replace(/^\||\| *$/g, "").split("|"), i = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], a = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === l.length) {
      for (const s of l)
        /^ *-+: *$/.test(s) ? a.align.push("right") : /^ *:-+: *$/.test(s) ? a.align.push("center") : /^ *:-+ *$/.test(s) ? a.align.push("left") : a.align.push(null);
      for (const s of n)
        a.header.push({
          text: s,
          tokens: this.lexer.inline(s)
        });
      for (const s of i)
        a.rows.push(li(s, a.header.length).map((r) => ({
          text: r,
          tokens: this.lexer.inline(r)
        })));
      return a;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: be(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const a = Qt(n.slice(0, -1), "\\");
        if ((n.length - a.length) % 2 === 0)
          return;
      } else {
        const a = zo(t[2], "()");
        if (a > -1) {
          const r = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + a;
          t[2] = t[2].substring(0, a), t[0] = t[0].substring(0, r).trim(), t[3] = "";
        }
      }
      let l = t[2], i = "";
      if (this.options.pedantic) {
        const a = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(l);
        a && (l = a[1], i = a[3]);
      } else
        i = t[3] ? t[3].slice(1, -1) : "";
      return l = l.trim(), /^</.test(l) && (this.options.pedantic && !/>$/.test(n) ? l = l.slice(1) : l = l.slice(1, -1)), oi(t, {
        href: l && l.replace(this.rules.inline.anyPunctuation, "$1"),
        title: i && i.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const l = (n[2] || n[1]).replace(/\s+/g, " "), i = t[l.toLowerCase()];
      if (!i) {
        const a = n[0].charAt(0);
        return {
          type: "text",
          raw: a,
          text: a
        };
      }
      return oi(n, i, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let l = this.rules.inline.emStrongLDelim.exec(e);
    if (!l || l[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(l[1] || l[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const a = [...l[0]].length - 1;
      let s, r, u = a, _ = 0;
      const d = l[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (d.lastIndex = 0, t = t.slice(-1 * e.length + a); (l = d.exec(t)) != null; ) {
        if (s = l[1] || l[2] || l[3] || l[4] || l[5] || l[6], !s)
          continue;
        if (r = [...s].length, l[3] || l[4]) {
          u += r;
          continue;
        } else if ((l[5] || l[6]) && a % 3 && !((a + r) % 3)) {
          _ += r;
          continue;
        }
        if (u -= r, u > 0)
          continue;
        r = Math.min(r, r + u + _);
        const c = [...l[0]][0].length, h = e.slice(0, a + l.index + c + r);
        if (Math.min(a, r) % 2) {
          const p = h.slice(1, -1);
          return {
            type: "em",
            raw: h,
            text: p,
            tokens: this.lexer.inlineTokens(p)
          };
        }
        const m = h.slice(2, -2);
        return {
          type: "strong",
          raw: h,
          text: m,
          tokens: this.lexer.inlineTokens(m)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const l = /[^ ]/.test(n), i = /^ /.test(n) && / $/.test(n);
      return l && i && (n = n.substring(1, n.length - 1)), n = be(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, l;
      return t[2] === "@" ? (n = be(t[1]), l = "mailto:" + n) : (n = be(t[1]), l = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: l,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let l, i;
      if (t[2] === "@")
        l = be(t[0]), i = "mailto:" + l;
      else {
        let a;
        do
          a = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (a !== t[0]);
        l = be(t[0]), t[1] === "www." ? i = "http://" + t[0] : i = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: l,
        href: i,
        tokens: [
          {
            type: "text",
            raw: l,
            text: l
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = be(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Ro = /^(?: *(?:\n|$))+/, Lo = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Oo = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, xt = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Po = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Ol = /(?:[*+-]|\d{1,9}[.)])/, Pl = N(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, Ol).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Vn = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Mo = /^[^\n]+/, Hn = /(?!\s*\])(?:\\.|[^\[\]\\])+/, No = N(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", Hn).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), jo = N(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Ol).getRegex(), pn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Gn = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Vo = N("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Gn).replace("tag", pn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Ml = N(Vn).replace("hr", xt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", pn).getRegex(), Ho = N(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Ml).getRegex(), Un = {
  blockquote: Ho,
  code: Lo,
  def: No,
  fences: Oo,
  heading: Po,
  hr: xt,
  html: Vo,
  lheading: Pl,
  list: jo,
  newline: Ro,
  paragraph: Ml,
  table: zt,
  text: Mo
}, ai = N("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", xt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", pn).getRegex(), Go = {
  ...Un,
  table: ai,
  paragraph: N(Vn).replace("hr", xt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", ai).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", pn).getRegex()
}, Uo = {
  ...Un,
  html: N(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Gn).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: zt,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: N(Vn).replace("hr", xt).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Pl).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Nl = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Zo = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, jl = /^( {2,}|\\)\n(?!\s*$)/, xo = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Xt = "\\p{P}\\p{S}", Xo = N(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Xt).getRegex(), Yo = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Wo = N(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Xt).getRegex(), Ko = N("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Xt).getRegex(), Qo = N("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Xt).getRegex(), Jo = N(/\\([punct])/, "gu").replace(/punct/g, Xt).getRegex(), ea = N(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), ta = N(Gn).replace("(?:-->|$)", "-->").getRegex(), na = N("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", ta).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), cn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, ia = N(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", cn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), Vl = N(/^!?\[(label)\]\[(ref)\]/).replace("label", cn).replace("ref", Hn).getRegex(), Hl = N(/^!?\[(ref)\](?:\[\])?/).replace("ref", Hn).getRegex(), la = N("reflink|nolink(?!\\()", "g").replace("reflink", Vl).replace("nolink", Hl).getRegex(), Zn = {
  _backpedal: zt,
  // only used for GFM url
  anyPunctuation: Jo,
  autolink: ea,
  blockSkip: Yo,
  br: jl,
  code: Zo,
  del: zt,
  emStrongLDelim: Wo,
  emStrongRDelimAst: Ko,
  emStrongRDelimUnd: Qo,
  escape: Nl,
  link: ia,
  nolink: Hl,
  punctuation: Xo,
  reflink: Vl,
  reflinkSearch: la,
  tag: na,
  text: xo,
  url: zt
}, oa = {
  ...Zn,
  link: N(/^!?\[(label)\]\((.*?)\)/).replace("label", cn).getRegex(),
  reflink: N(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", cn).getRegex()
}, An = {
  ...Zn,
  escape: N(Nl).replace("])", "~|])").getRegex(),
  url: N(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, aa = {
  ...An,
  br: N(jl).replace("{2,}", "*").getRegex(),
  text: N(An.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Jt = {
  normal: Un,
  gfm: Go,
  pedantic: Uo
}, St = {
  normal: Zn,
  gfm: An,
  breaks: aa,
  pedantic: oa
};
class Ge {
  constructor(e) {
    H(this, "tokens");
    H(this, "options");
    H(this, "state");
    H(this, "tokenizer");
    H(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || gt, this.options.tokenizer = this.options.tokenizer || new _n(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: Jt.normal,
      inline: St.normal
    };
    this.options.pedantic ? (t.block = Jt.pedantic, t.inline = St.pedantic) : this.options.gfm && (t.block = Jt.gfm, this.options.breaks ? t.inline = St.breaks : t.inline = St.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Jt,
      inline: St
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new Ge(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new Ge(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (s, r, u) => r + "    ".repeat(u.length));
    let n, l, i, a;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((s) => (n = s.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && (l.type === "paragraph" || l.type === "text") ? (l.raw += `
` + n.raw, l.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && (l.type === "paragraph" || l.type === "text") ? (l.raw += `
` + n.raw, l.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startBlock) {
          let s = 1 / 0;
          const r = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((_) => {
            u = _.call({ lexer: this }, r), typeof u == "number" && u >= 0 && (s = Math.min(s, u));
          }), s < 1 / 0 && s >= 0 && (i = e.substring(0, s + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(i))) {
          l = t[t.length - 1], a && l.type === "paragraph" ? (l.raw += `
` + n.raw, l.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : t.push(n), a = i.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && l.type === "text" ? (l.raw += `
` + n.raw, l.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : t.push(n);
          continue;
        }
        if (e) {
          const s = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(s);
            break;
          } else
            throw new Error(s);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, l, i, a = e, s, r, u;
    if (this.tokens.links) {
      const _ = Object.keys(this.tokens.links);
      if (_.length > 0)
        for (; (s = this.tokenizer.rules.inline.reflinkSearch.exec(a)) != null; )
          _.includes(s[0].slice(s[0].lastIndexOf("[") + 1, -1)) && (a = a.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (s = this.tokenizer.rules.inline.blockSkip.exec(a)) != null; )
      a = a.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (s = this.tokenizer.rules.inline.anyPunctuation.exec(a)) != null; )
      a = a.slice(0, s.index) + "++" + a.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (r || (u = ""), r = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((_) => (n = _.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && n.type === "text" && l.type === "text" ? (l.raw += n.raw, l.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && n.type === "text" && l.type === "text" ? (l.raw += n.raw, l.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, a, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startInline) {
          let _ = 1 / 0;
          const d = e.slice(1);
          let c;
          this.options.extensions.startInline.forEach((h) => {
            c = h.call({ lexer: this }, d), typeof c == "number" && c >= 0 && (_ = Math.min(_, c));
          }), _ < 1 / 0 && _ >= 0 && (i = e.substring(0, _ + 1));
        }
        if (n = this.tokenizer.inlineText(i)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), r = !0, l = t[t.length - 1], l && l.type === "text" ? (l.raw += n.raw, l.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const _ = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(_);
            break;
          } else
            throw new Error(_);
        }
      }
    return t;
  }
}
class dn {
  constructor(e) {
    H(this, "options");
    this.options = e || gt;
  }
  code(e, t, n) {
    var i;
    const l = (i = (t || "").match(/^\S*/)) == null ? void 0 : i[0];
    return e = e.replace(/\n$/, "") + `
`, l ? '<pre><code class="language-' + be(l) + '">' + (n ? e : be(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : be(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const l = t ? "ol" : "ul", i = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + l + i + `>
` + e + "</" + l + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const l = ii(e);
    if (l === null)
      return n;
    e = l;
    let i = '<a href="' + e + '"';
    return t && (i += ' title="' + t + '"'), i += ">" + n + "</a>", i;
  }
  image(e, t, n) {
    const l = ii(e);
    if (l === null)
      return n;
    e = l;
    let i = `<img src="${e}" alt="${n}"`;
    return t && (i += ` title="${t}"`), i += ">", i;
  }
  text(e) {
    return e;
  }
}
class xn {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class Ue {
  constructor(e) {
    H(this, "options");
    H(this, "renderer");
    H(this, "textRenderer");
    this.options = e || gt, this.options.renderer = this.options.renderer || new dn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new xn();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new Ue(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new Ue(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let l = 0; l < e.length; l++) {
      const i = e[l];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const a = i, s = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (s !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(a.type)) {
          n += s || "";
          continue;
        }
      }
      switch (i.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const a = i;
          n += this.renderer.heading(this.parseInline(a.tokens), a.depth, Bo(this.parseInline(a.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const a = i;
          n += this.renderer.code(a.text, a.lang, !!a.escaped);
          continue;
        }
        case "table": {
          const a = i;
          let s = "", r = "";
          for (let _ = 0; _ < a.header.length; _++)
            r += this.renderer.tablecell(this.parseInline(a.header[_].tokens), { header: !0, align: a.align[_] });
          s += this.renderer.tablerow(r);
          let u = "";
          for (let _ = 0; _ < a.rows.length; _++) {
            const d = a.rows[_];
            r = "";
            for (let c = 0; c < d.length; c++)
              r += this.renderer.tablecell(this.parseInline(d[c].tokens), { header: !1, align: a.align[c] });
            u += this.renderer.tablerow(r);
          }
          n += this.renderer.table(s, u);
          continue;
        }
        case "blockquote": {
          const a = i, s = this.parse(a.tokens);
          n += this.renderer.blockquote(s);
          continue;
        }
        case "list": {
          const a = i, s = a.ordered, r = a.start, u = a.loose;
          let _ = "";
          for (let d = 0; d < a.items.length; d++) {
            const c = a.items[d], h = c.checked, m = c.task;
            let p = "";
            if (c.task) {
              const b = this.renderer.checkbox(!!h);
              u ? c.tokens.length > 0 && c.tokens[0].type === "paragraph" ? (c.tokens[0].text = b + " " + c.tokens[0].text, c.tokens[0].tokens && c.tokens[0].tokens.length > 0 && c.tokens[0].tokens[0].type === "text" && (c.tokens[0].tokens[0].text = b + " " + c.tokens[0].tokens[0].text)) : c.tokens.unshift({
                type: "text",
                text: b + " "
              }) : p += b + " ";
            }
            p += this.parse(c.tokens, u), _ += this.renderer.listitem(p, m, !!h);
          }
          n += this.renderer.list(_, s, r);
          continue;
        }
        case "html": {
          const a = i;
          n += this.renderer.html(a.text, a.block);
          continue;
        }
        case "paragraph": {
          const a = i;
          n += this.renderer.paragraph(this.parseInline(a.tokens));
          continue;
        }
        case "text": {
          let a = i, s = a.tokens ? this.parseInline(a.tokens) : a.text;
          for (; l + 1 < e.length && e[l + 1].type === "text"; )
            a = e[++l], s += `
` + (a.tokens ? this.parseInline(a.tokens) : a.text);
          n += t ? this.renderer.paragraph(s) : s;
          continue;
        }
        default: {
          const a = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let l = 0; l < e.length; l++) {
      const i = e[l];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const a = this.options.extensions.renderers[i.type].call({ parser: this }, i);
        if (a !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(i.type)) {
          n += a || "";
          continue;
        }
      }
      switch (i.type) {
        case "escape": {
          const a = i;
          n += t.text(a.text);
          break;
        }
        case "html": {
          const a = i;
          n += t.html(a.text);
          break;
        }
        case "link": {
          const a = i;
          n += t.link(a.href, a.title, this.parseInline(a.tokens, t));
          break;
        }
        case "image": {
          const a = i;
          n += t.image(a.href, a.title, a.text);
          break;
        }
        case "strong": {
          const a = i;
          n += t.strong(this.parseInline(a.tokens, t));
          break;
        }
        case "em": {
          const a = i;
          n += t.em(this.parseInline(a.tokens, t));
          break;
        }
        case "codespan": {
          const a = i;
          n += t.codespan(a.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const a = i;
          n += t.del(this.parseInline(a.tokens, t));
          break;
        }
        case "text": {
          const a = i;
          n += t.text(a.text);
          break;
        }
        default: {
          const a = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return n;
  }
}
class It {
  constructor(e) {
    H(this, "options");
    this.options = e || gt;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
H(It, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var mt, Sn, Gl;
class sa {
  constructor(...e) {
    Kn(this, mt);
    H(this, "defaults", jn());
    H(this, "options", this.setOptions);
    H(this, "parse", Kt(this, mt, Sn).call(this, Ge.lex, Ue.parse));
    H(this, "parseInline", Kt(this, mt, Sn).call(this, Ge.lexInline, Ue.parseInline));
    H(this, "Parser", Ue);
    H(this, "Renderer", dn);
    H(this, "TextRenderer", xn);
    H(this, "Lexer", Ge);
    H(this, "Tokenizer", _n);
    H(this, "Hooks", It);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var l, i;
    let n = [];
    for (const a of e)
      switch (n = n.concat(t.call(this, a)), a.type) {
        case "table": {
          const s = a;
          for (const r of s.header)
            n = n.concat(this.walkTokens(r.tokens, t));
          for (const r of s.rows)
            for (const u of r)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const s = a;
          n = n.concat(this.walkTokens(s.items, t));
          break;
        }
        default: {
          const s = a;
          (i = (l = this.defaults.extensions) == null ? void 0 : l.childTokens) != null && i[s.type] ? this.defaults.extensions.childTokens[s.type].forEach((r) => {
            const u = s[r].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : s.tokens && (n = n.concat(this.walkTokens(s.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const l = { ...n };
      if (l.async = this.defaults.async || l.async || !1, n.extensions && (n.extensions.forEach((i) => {
        if (!i.name)
          throw new Error("extension name required");
        if ("renderer" in i) {
          const a = t.renderers[i.name];
          a ? t.renderers[i.name] = function(...s) {
            let r = i.renderer.apply(this, s);
            return r === !1 && (r = a.apply(this, s)), r;
          } : t.renderers[i.name] = i.renderer;
        }
        if ("tokenizer" in i) {
          if (!i.level || i.level !== "block" && i.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const a = t[i.level];
          a ? a.unshift(i.tokenizer) : t[i.level] = [i.tokenizer], i.start && (i.level === "block" ? t.startBlock ? t.startBlock.push(i.start) : t.startBlock = [i.start] : i.level === "inline" && (t.startInline ? t.startInline.push(i.start) : t.startInline = [i.start]));
        }
        "childTokens" in i && i.childTokens && (t.childTokens[i.name] = i.childTokens);
      }), l.extensions = t), n.renderer) {
        const i = this.defaults.renderer || new dn(this.defaults);
        for (const a in n.renderer) {
          if (!(a in i))
            throw new Error(`renderer '${a}' does not exist`);
          if (a === "options")
            continue;
          const s = a, r = n.renderer[s], u = i[s];
          i[s] = (..._) => {
            let d = r.apply(i, _);
            return d === !1 && (d = u.apply(i, _)), d || "";
          };
        }
        l.renderer = i;
      }
      if (n.tokenizer) {
        const i = this.defaults.tokenizer || new _n(this.defaults);
        for (const a in n.tokenizer) {
          if (!(a in i))
            throw new Error(`tokenizer '${a}' does not exist`);
          if (["options", "rules", "lexer"].includes(a))
            continue;
          const s = a, r = n.tokenizer[s], u = i[s];
          i[s] = (..._) => {
            let d = r.apply(i, _);
            return d === !1 && (d = u.apply(i, _)), d;
          };
        }
        l.tokenizer = i;
      }
      if (n.hooks) {
        const i = this.defaults.hooks || new It();
        for (const a in n.hooks) {
          if (!(a in i))
            throw new Error(`hook '${a}' does not exist`);
          if (a === "options")
            continue;
          const s = a, r = n.hooks[s], u = i[s];
          It.passThroughHooks.has(a) ? i[s] = (_) => {
            if (this.defaults.async)
              return Promise.resolve(r.call(i, _)).then((c) => u.call(i, c));
            const d = r.call(i, _);
            return u.call(i, d);
          } : i[s] = (..._) => {
            let d = r.apply(i, _);
            return d === !1 && (d = u.apply(i, _)), d;
          };
        }
        l.hooks = i;
      }
      if (n.walkTokens) {
        const i = this.defaults.walkTokens, a = n.walkTokens;
        l.walkTokens = function(s) {
          let r = [];
          return r.push(a.call(this, s)), i && (r = r.concat(i.call(this, s))), r;
        };
      }
      this.defaults = { ...this.defaults, ...l };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return Ge.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Ue.parse(e, t ?? this.defaults);
  }
}
mt = new WeakSet(), Sn = function(e, t) {
  return (n, l) => {
    const i = { ...l }, a = { ...this.defaults, ...i };
    this.defaults.async === !0 && i.async === !1 && (a.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), a.async = !0);
    const s = Kt(this, mt, Gl).call(this, !!a.silent, !!a.async);
    if (typeof n > "u" || n === null)
      return s(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return s(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (a.hooks && (a.hooks.options = a), a.async)
      return Promise.resolve(a.hooks ? a.hooks.preprocess(n) : n).then((r) => e(r, a)).then((r) => a.hooks ? a.hooks.processAllTokens(r) : r).then((r) => a.walkTokens ? Promise.all(this.walkTokens(r, a.walkTokens)).then(() => r) : r).then((r) => t(r, a)).then((r) => a.hooks ? a.hooks.postprocess(r) : r).catch(s);
    try {
      a.hooks && (n = a.hooks.preprocess(n));
      let r = e(n, a);
      a.hooks && (r = a.hooks.processAllTokens(r)), a.walkTokens && this.walkTokens(r, a.walkTokens);
      let u = t(r, a);
      return a.hooks && (u = a.hooks.postprocess(u)), u;
    } catch (r) {
      return s(r);
    }
  };
}, Gl = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const l = "<p>An error occurred:</p><pre>" + be(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(l) : l;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const ft = new sa();
function M(o, e) {
  return ft.parse(o, e);
}
M.options = M.setOptions = function(o) {
  return ft.setOptions(o), M.defaults = ft.defaults, Il(M.defaults), M;
};
M.getDefaults = jn;
M.defaults = gt;
M.use = function(...o) {
  return ft.use(...o), M.defaults = ft.defaults, Il(M.defaults), M;
};
M.walkTokens = function(o, e) {
  return ft.walkTokens(o, e);
};
M.parseInline = ft.parseInline;
M.Parser = Ue;
M.parser = Ue.parse;
M.Renderer = dn;
M.TextRenderer = xn;
M.Lexer = Ge;
M.lexer = Ge.lex;
M.Tokenizer = _n;
M.Hooks = It;
M.parse = M;
M.options;
M.setOptions;
M.use;
M.walkTokens;
M.parseInline;
Ue.parse;
Ge.lex;
const ra = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, ua = Object.hasOwnProperty;
class Ul {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let l = _a(e, t === !0);
    const i = l;
    for (; ua.call(n.occurrences, l); )
      n.occurrences[i]++, l = i + "-" + n.occurrences[i];
    return n.occurrences[l] = 0, l;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function _a(o, e) {
  return typeof o != "string" ? "" : (e || (o = o.toLowerCase()), o.replace(ra, "").replace(/ /g, "-"));
}
new Ul();
var si = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, ca = { exports: {} };
(function(o) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var l = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, i = 0, a = {}, s = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function g(f) {
          return f instanceof r ? new r(f.type, g(f.content), f.alias) : Array.isArray(f) ? f.map(g) : f.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(g) {
          return Object.prototype.toString.call(g).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(g) {
          return g.__id || Object.defineProperty(g, "__id", { value: ++i }), g.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function g(f, v) {
          v = v || {};
          var D, w;
          switch (s.util.type(f)) {
            case "Object":
              if (w = s.util.objId(f), v[w])
                return v[w];
              D = /** @type {Record<string, any>} */
              {}, v[w] = D;
              for (var F in f)
                f.hasOwnProperty(F) && (D[F] = g(f[F], v));
              return (
                /** @type {any} */
                D
              );
            case "Array":
              return w = s.util.objId(f), v[w] ? v[w] : (D = [], v[w] = D, /** @type {Array} */
              /** @type {any} */
              f.forEach(function(A, y) {
                D[y] = g(A, v);
              }), /** @type {any} */
              D);
            default:
              return f;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(g) {
          for (; g; ) {
            var f = l.exec(g.className);
            if (f)
              return f[1].toLowerCase();
            g = g.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(g, f) {
          g.className = g.className.replace(RegExp(l, "gi"), ""), g.classList.add("language-" + f);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (D) {
            var g = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(D.stack) || [])[1];
            if (g) {
              var f = document.getElementsByTagName("script");
              for (var v in f)
                if (f[v].src == g)
                  return f[v];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(g, f, v) {
          for (var D = "no-" + f; g; ) {
            var w = g.classList;
            if (w.contains(f))
              return !0;
            if (w.contains(D))
              return !1;
            g = g.parentElement;
          }
          return !!v;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: a,
        plaintext: a,
        text: a,
        txt: a,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(g, f) {
          var v = s.util.clone(s.languages[g]);
          for (var D in f)
            v[D] = f[D];
          return v;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(g, f, v, D) {
          D = D || /** @type {any} */
          s.languages;
          var w = D[g], F = {};
          for (var A in w)
            if (w.hasOwnProperty(A)) {
              if (A == f)
                for (var y in v)
                  v.hasOwnProperty(y) && (F[y] = v[y]);
              v.hasOwnProperty(A) || (F[A] = w[A]);
            }
          var T = D[g];
          return D[g] = F, s.languages.DFS(s.languages, function(E, L) {
            L === T && E != g && (this[E] = F);
          }), F;
        },
        // Traverse a language definition with Depth First Search
        DFS: function g(f, v, D, w) {
          w = w || {};
          var F = s.util.objId;
          for (var A in f)
            if (f.hasOwnProperty(A)) {
              v.call(f, A, f[A], D || A);
              var y = f[A], T = s.util.type(y);
              T === "Object" && !w[F(y)] ? (w[F(y)] = !0, g(y, v, null, w)) : T === "Array" && !w[F(y)] && (w[F(y)] = !0, g(y, v, A, w));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(g, f) {
        s.highlightAllUnder(document, g, f);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(g, f, v) {
        var D = {
          callback: v,
          container: g,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        s.hooks.run("before-highlightall", D), D.elements = Array.prototype.slice.apply(D.container.querySelectorAll(D.selector)), s.hooks.run("before-all-elements-highlight", D);
        for (var w = 0, F; F = D.elements[w++]; )
          s.highlightElement(F, f === !0, D.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(g, f, v) {
        var D = s.util.getLanguage(g), w = s.languages[D];
        s.util.setLanguage(g, D);
        var F = g.parentElement;
        F && F.nodeName.toLowerCase() === "pre" && s.util.setLanguage(F, D);
        var A = g.textContent, y = {
          element: g,
          language: D,
          grammar: w,
          code: A
        };
        function T(L) {
          y.highlightedCode = L, s.hooks.run("before-insert", y), y.element.innerHTML = y.highlightedCode, s.hooks.run("after-highlight", y), s.hooks.run("complete", y), v && v.call(y.element);
        }
        if (s.hooks.run("before-sanity-check", y), F = y.element.parentElement, F && F.nodeName.toLowerCase() === "pre" && !F.hasAttribute("tabindex") && F.setAttribute("tabindex", "0"), !y.code) {
          s.hooks.run("complete", y), v && v.call(y.element);
          return;
        }
        if (s.hooks.run("before-highlight", y), !y.grammar) {
          T(s.util.encode(y.code));
          return;
        }
        if (f && n.Worker) {
          var E = new Worker(s.filename);
          E.onmessage = function(L) {
            T(L.data);
          }, E.postMessage(JSON.stringify({
            language: y.language,
            code: y.code,
            immediateClose: !0
          }));
        } else
          T(s.highlight(y.code, y.grammar, y.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(g, f, v) {
        var D = {
          code: g,
          grammar: f,
          language: v
        };
        if (s.hooks.run("before-tokenize", D), !D.grammar)
          throw new Error('The language "' + D.language + '" has no grammar.');
        return D.tokens = s.tokenize(D.code, D.grammar), s.hooks.run("after-tokenize", D), r.stringify(s.util.encode(D.tokens), D.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(g, f) {
        var v = f.rest;
        if (v) {
          for (var D in v)
            f[D] = v[D];
          delete f.rest;
        }
        var w = new d();
        return c(w, w.head, g), _(g, w, f, w.head, 0), m(w);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(g, f) {
          var v = s.hooks.all;
          v[g] = v[g] || [], v[g].push(f);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(g, f) {
          var v = s.hooks.all[g];
          if (!(!v || !v.length))
            for (var D = 0, w; w = v[D++]; )
              w(f);
        }
      },
      Token: r
    };
    n.Prism = s;
    function r(g, f, v, D) {
      this.type = g, this.content = f, this.alias = v, this.length = (D || "").length | 0;
    }
    r.stringify = function g(f, v) {
      if (typeof f == "string")
        return f;
      if (Array.isArray(f)) {
        var D = "";
        return f.forEach(function(T) {
          D += g(T, v);
        }), D;
      }
      var w = {
        type: f.type,
        content: g(f.content, v),
        tag: "span",
        classes: ["token", f.type],
        attributes: {},
        language: v
      }, F = f.alias;
      F && (Array.isArray(F) ? Array.prototype.push.apply(w.classes, F) : w.classes.push(F)), s.hooks.run("wrap", w);
      var A = "";
      for (var y in w.attributes)
        A += " " + y + '="' + (w.attributes[y] || "").replace(/"/g, "&quot;") + '"';
      return "<" + w.tag + ' class="' + w.classes.join(" ") + '"' + A + ">" + w.content + "</" + w.tag + ">";
    };
    function u(g, f, v, D) {
      g.lastIndex = f;
      var w = g.exec(v);
      if (w && D && w[1]) {
        var F = w[1].length;
        w.index += F, w[0] = w[0].slice(F);
      }
      return w;
    }
    function _(g, f, v, D, w, F) {
      for (var A in v)
        if (!(!v.hasOwnProperty(A) || !v[A])) {
          var y = v[A];
          y = Array.isArray(y) ? y : [y];
          for (var T = 0; T < y.length; ++T) {
            if (F && F.cause == A + "," + T)
              return;
            var E = y[T], L = E.inside, B = !!E.lookbehind, $ = !!E.greedy, ue = E.alias;
            if ($ && !E.pattern.global) {
              var he = E.pattern.toString().match(/[imsuy]*$/)[0];
              E.pattern = RegExp(E.pattern.source, he + "g");
            }
            for (var lt = E.pattern || E, K = D.next, _e = w; K !== f.tail && !(F && _e >= F.reach); _e += K.value.length, K = K.next) {
              var ze = K.value;
              if (f.length > g.length)
                return;
              if (!(ze instanceof r)) {
                var C = 1, ie;
                if ($) {
                  if (ie = u(lt, _e, g, B), !ie || ie.index >= g.length)
                    break;
                  var bt = ie.index, vt = ie.index + ie[0].length, ge = _e;
                  for (ge += K.value.length; bt >= ge; )
                    K = K.next, ge += K.value.length;
                  if (ge -= K.value.length, _e = ge, K.value instanceof r)
                    continue;
                  for (var S = K; S !== f.tail && (ge < vt || typeof S.value == "string"); S = S.next)
                    C++, ge += S.value.length;
                  C--, ze = g.slice(_e, ge), ie.index -= _e;
                } else if (ie = u(lt, 0, ze, B), !ie)
                  continue;
                var bt = ie.index, Yt = ie[0], gn = ze.slice(0, bt), Yn = ze.slice(bt + Yt.length), vn = _e + ze.length;
                F && vn > F.reach && (F.reach = vn);
                var Wt = K.prev;
                gn && (Wt = c(f, Wt, gn), _e += gn.length), h(f, Wt, C);
                var ao = new r(A, L ? s.tokenize(Yt, L) : Yt, ue, Yt);
                if (K = c(f, Wt, ao), Yn && c(f, K, Yn), C > 1) {
                  var bn = {
                    cause: A + "," + T,
                    reach: vn
                  };
                  _(g, f, v, K.prev, _e, bn), F && bn.reach > F.reach && (F.reach = bn.reach);
                }
              }
            }
          }
        }
    }
    function d() {
      var g = { value: null, prev: null, next: null }, f = { value: null, prev: g, next: null };
      g.next = f, this.head = g, this.tail = f, this.length = 0;
    }
    function c(g, f, v) {
      var D = f.next, w = { value: v, prev: f, next: D };
      return f.next = w, D.prev = w, g.length++, w;
    }
    function h(g, f, v) {
      for (var D = f.next, w = 0; w < v && D !== g.tail; w++)
        D = D.next;
      f.next = D, D.prev = f, g.length -= w;
    }
    function m(g) {
      for (var f = [], v = g.head.next; v !== g.tail; )
        f.push(v.value), v = v.next;
      return f;
    }
    if (!n.document)
      return n.addEventListener && (s.disableWorkerMessageHandler || n.addEventListener("message", function(g) {
        var f = JSON.parse(g.data), v = f.language, D = f.code, w = f.immediateClose;
        n.postMessage(s.highlight(D, s.languages[v], v)), w && n.close();
      }, !1)), s;
    var p = s.util.currentScript();
    p && (s.filename = p.src, p.hasAttribute("data-manual") && (s.manual = !0));
    function b() {
      s.manual || s.highlightAll();
    }
    if (!s.manual) {
      var k = document.readyState;
      k === "loading" || k === "interactive" && p && p.defer ? document.addEventListener("DOMContentLoaded", b) : window.requestAnimationFrame ? window.requestAnimationFrame(b) : window.setTimeout(b, 16);
    }
    return s;
  }(e);
  o.exports && (o.exports = t), typeof si < "u" && (si.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(l, i) {
      var a = {};
      a["language-" + i] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[i]
      }, a.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var s = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: a
        }
      };
      s["language-" + i] = {
        pattern: /[\s\S]+/,
        inside: t.languages[i]
      };
      var r = {};
      r[l] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return l;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: s
      }, t.languages.insertBefore("markup", "cdata", r);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, l) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [l, "language-" + l],
                inside: t.languages[l]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var l = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + l.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + l.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + l.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + l.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: l,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var i = n.languages.markup;
    i && (i.tag.addInlined("style", "css"), i.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", l = function(p, b) {
      return "✖ Error " + p + " while fetching file: " + b;
    }, i = "✖ Error: File does not exist or is empty", a = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, s = "data-src-status", r = "loading", u = "loaded", _ = "failed", d = "pre[data-src]:not([" + s + '="' + u + '"]):not([' + s + '="' + r + '"])';
    function c(p, b, k) {
      var g = new XMLHttpRequest();
      g.open("GET", p, !0), g.onreadystatechange = function() {
        g.readyState == 4 && (g.status < 400 && g.responseText ? b(g.responseText) : g.status >= 400 ? k(l(g.status, g.statusText)) : k(i));
      }, g.send(null);
    }
    function h(p) {
      var b = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(p || "");
      if (b) {
        var k = Number(b[1]), g = b[2], f = b[3];
        return g ? f ? [k, Number(f)] : [k, void 0] : [k, k];
      }
    }
    t.hooks.add("before-highlightall", function(p) {
      p.selector += ", " + d;
    }), t.hooks.add("before-sanity-check", function(p) {
      var b = (
        /** @type {HTMLPreElement} */
        p.element
      );
      if (b.matches(d)) {
        p.code = "", b.setAttribute(s, r);
        var k = b.appendChild(document.createElement("CODE"));
        k.textContent = n;
        var g = b.getAttribute("data-src"), f = p.language;
        if (f === "none") {
          var v = (/\.(\w+)$/.exec(g) || [, "none"])[1];
          f = a[v] || v;
        }
        t.util.setLanguage(k, f), t.util.setLanguage(b, f);
        var D = t.plugins.autoloader;
        D && D.loadLanguages(f), c(
          g,
          function(w) {
            b.setAttribute(s, u);
            var F = h(b.getAttribute("data-range"));
            if (F) {
              var A = w.split(/\r\n?|\n/g), y = F[0], T = F[1] == null ? A.length : F[1];
              y < 0 && (y += A.length), y = Math.max(0, Math.min(y - 1, A.length)), T < 0 && (T += A.length), T = Math.max(0, Math.min(T, A.length)), w = A.slice(y, T).join(`
`), b.hasAttribute("data-start") || b.setAttribute("data-start", String(y + 1));
            }
            k.textContent = w, t.highlightElement(k);
          },
          function(w) {
            b.setAttribute(s, _), k.textContent = w;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(b) {
        for (var k = (b || document).querySelectorAll(d), g = 0, f; f = k[g++]; )
          t.highlightElement(f);
      }
    };
    var m = !1;
    t.fileHighlight = function() {
      m || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), m = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(ca);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(o) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  o.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, o.languages.tex = o.languages.latex, o.languages.context = o.languages.latex;
})(Prism);
(function(o) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  o.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = o.languages.bash;
  for (var l = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], i = n.variable[1].inside, a = 0; a < l.length; a++)
    i[l[a]] = o.languages.bash[l[a]];
  o.languages.sh = o.languages.bash, o.languages.shell = o.languages.bash;
})(Prism);
new Ul();
const da = (o) => {
  const e = {};
  for (let t = 0, n = o.length; t < n; t++) {
    const l = o[t];
    for (const i in l)
      e[i] ? e[i] = e[i].concat(l[i]) : e[i] = l[i];
  }
  return e;
}, fa = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], ha = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], pa = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
da([
  Object.fromEntries(fa.map((o) => [o, ["*"]])),
  Object.fromEntries(ha.map((o) => [o, ["svg:*"]])),
  Object.fromEntries(pa.map((o) => [o, ["math:*"]]))
]);
const {
  HtmlTagHydration: Xr,
  SvelteComponent: Yr,
  attr: Wr,
  binding_callbacks: Kr,
  children: Qr,
  claim_element: Jr,
  claim_html_tag: eu,
  detach: tu,
  element: nu,
  init: iu,
  insert_hydration: lu,
  noop: ou,
  safe_not_equal: au,
  toggle_class: su
} = window.__gradio__svelte__internal, { afterUpdate: ru, tick: uu, onMount: _u } = window.__gradio__svelte__internal, {
  SvelteComponent: cu,
  attr: du,
  children: fu,
  claim_component: hu,
  claim_element: pu,
  create_component: mu,
  destroy_component: gu,
  detach: vu,
  element: bu,
  init: Du,
  insert_hydration: yu,
  mount_component: wu,
  safe_not_equal: ku,
  transition_in: Fu,
  transition_out: $u
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cu,
  attr: Eu,
  check_outros: Au,
  children: Su,
  claim_component: qu,
  claim_element: Bu,
  claim_space: Tu,
  create_component: zu,
  create_slot: Iu,
  destroy_component: Ru,
  detach: Lu,
  element: Ou,
  empty: Pu,
  get_all_dirty_from_scope: Mu,
  get_slot_changes: Nu,
  group_outros: ju,
  init: Vu,
  insert_hydration: Hu,
  mount_component: Gu,
  safe_not_equal: Uu,
  space: Zu,
  toggle_class: xu,
  transition_in: Xu,
  transition_out: Yu,
  update_slot_base: Wu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ku,
  append_hydration: Qu,
  attr: Ju,
  children: e_,
  claim_component: t_,
  claim_element: n_,
  claim_space: i_,
  claim_text: l_,
  create_component: o_,
  destroy_component: a_,
  detach: s_,
  element: r_,
  init: u_,
  insert_hydration: __,
  mount_component: c_,
  safe_not_equal: d_,
  set_data: f_,
  space: h_,
  text: p_,
  toggle_class: m_,
  transition_in: g_,
  transition_out: v_
} = window.__gradio__svelte__internal, {
  SvelteComponent: ma,
  append_hydration: rn,
  attr: Je,
  bubble: ga,
  check_outros: va,
  children: qn,
  claim_component: ba,
  claim_element: Bn,
  claim_space: ri,
  claim_text: Da,
  construct_svelte_component: ui,
  create_component: _i,
  create_slot: ya,
  destroy_component: ci,
  detach: Rt,
  element: Tn,
  get_all_dirty_from_scope: wa,
  get_slot_changes: ka,
  group_outros: Fa,
  init: $a,
  insert_hydration: Zl,
  listen: Ca,
  mount_component: di,
  safe_not_equal: Ea,
  set_data: Aa,
  set_style: en,
  space: fi,
  text: Sa,
  toggle_class: le,
  transition_in: wn,
  transition_out: kn,
  update_slot_base: qa
} = window.__gradio__svelte__internal;
function hi(o) {
  let e, t;
  return {
    c() {
      e = Tn("span"), t = Sa(
        /*label*/
        o[1]
      ), this.h();
    },
    l(n) {
      e = Bn(n, "SPAN", { class: !0 });
      var l = qn(e);
      t = Da(
        l,
        /*label*/
        o[1]
      ), l.forEach(Rt), this.h();
    },
    h() {
      Je(e, "class", "svelte-qgco6m");
    },
    m(n, l) {
      Zl(n, e, l), rn(e, t);
    },
    p(n, l) {
      l & /*label*/
      2 && Aa(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && Rt(e);
    }
  };
}
function Ba(o) {
  let e, t, n, l, i, a, s, r, u = (
    /*show_label*/
    o[2] && hi(o)
  );
  var _ = (
    /*Icon*/
    o[0]
  );
  function d(m, p) {
    return {};
  }
  _ && (l = ui(_, d()));
  const c = (
    /*#slots*/
    o[14].default
  ), h = ya(
    c,
    o,
    /*$$scope*/
    o[13],
    null
  );
  return {
    c() {
      e = Tn("button"), u && u.c(), t = fi(), n = Tn("div"), l && _i(l.$$.fragment), i = fi(), h && h.c(), this.h();
    },
    l(m) {
      e = Bn(m, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var p = qn(e);
      u && u.l(p), t = ri(p), n = Bn(p, "DIV", { class: !0 });
      var b = qn(n);
      l && ba(l.$$.fragment, b), i = ri(b), h && h.l(b), b.forEach(Rt), p.forEach(Rt), this.h();
    },
    h() {
      Je(n, "class", "svelte-qgco6m"), le(
        n,
        "x-small",
        /*size*/
        o[4] === "x-small"
      ), le(
        n,
        "small",
        /*size*/
        o[4] === "small"
      ), le(
        n,
        "large",
        /*size*/
        o[4] === "large"
      ), le(
        n,
        "medium",
        /*size*/
        o[4] === "medium"
      ), e.disabled = /*disabled*/
      o[7], Je(
        e,
        "aria-label",
        /*label*/
        o[1]
      ), Je(
        e,
        "aria-haspopup",
        /*hasPopup*/
        o[8]
      ), Je(
        e,
        "title",
        /*label*/
        o[1]
      ), Je(e, "class", "svelte-qgco6m"), le(
        e,
        "pending",
        /*pending*/
        o[3]
      ), le(
        e,
        "padded",
        /*padded*/
        o[5]
      ), le(
        e,
        "highlight",
        /*highlight*/
        o[6]
      ), le(
        e,
        "transparent",
        /*transparent*/
        o[9]
      ), en(e, "color", !/*disabled*/
      o[7] && /*_color*/
      o[11] ? (
        /*_color*/
        o[11]
      ) : "var(--block-label-text-color)"), en(e, "--bg-color", /*disabled*/
      o[7] ? "auto" : (
        /*background*/
        o[10]
      ));
    },
    m(m, p) {
      Zl(m, e, p), u && u.m(e, null), rn(e, t), rn(e, n), l && di(l, n, null), rn(n, i), h && h.m(n, null), a = !0, s || (r = Ca(
        e,
        "click",
        /*click_handler*/
        o[15]
      ), s = !0);
    },
    p(m, [p]) {
      if (/*show_label*/
      m[2] ? u ? u.p(m, p) : (u = hi(m), u.c(), u.m(e, t)) : u && (u.d(1), u = null), p & /*Icon*/
      1 && _ !== (_ = /*Icon*/
      m[0])) {
        if (l) {
          Fa();
          const b = l;
          kn(b.$$.fragment, 1, 0, () => {
            ci(b, 1);
          }), va();
        }
        _ ? (l = ui(_, d()), _i(l.$$.fragment), wn(l.$$.fragment, 1), di(l, n, i)) : l = null;
      }
      h && h.p && (!a || p & /*$$scope*/
      8192) && qa(
        h,
        c,
        m,
        /*$$scope*/
        m[13],
        a ? ka(
          c,
          /*$$scope*/
          m[13],
          p,
          null
        ) : wa(
          /*$$scope*/
          m[13]
        ),
        null
      ), (!a || p & /*size*/
      16) && le(
        n,
        "x-small",
        /*size*/
        m[4] === "x-small"
      ), (!a || p & /*size*/
      16) && le(
        n,
        "small",
        /*size*/
        m[4] === "small"
      ), (!a || p & /*size*/
      16) && le(
        n,
        "large",
        /*size*/
        m[4] === "large"
      ), (!a || p & /*size*/
      16) && le(
        n,
        "medium",
        /*size*/
        m[4] === "medium"
      ), (!a || p & /*disabled*/
      128) && (e.disabled = /*disabled*/
      m[7]), (!a || p & /*label*/
      2) && Je(
        e,
        "aria-label",
        /*label*/
        m[1]
      ), (!a || p & /*hasPopup*/
      256) && Je(
        e,
        "aria-haspopup",
        /*hasPopup*/
        m[8]
      ), (!a || p & /*label*/
      2) && Je(
        e,
        "title",
        /*label*/
        m[1]
      ), (!a || p & /*pending*/
      8) && le(
        e,
        "pending",
        /*pending*/
        m[3]
      ), (!a || p & /*padded*/
      32) && le(
        e,
        "padded",
        /*padded*/
        m[5]
      ), (!a || p & /*highlight*/
      64) && le(
        e,
        "highlight",
        /*highlight*/
        m[6]
      ), (!a || p & /*transparent*/
      512) && le(
        e,
        "transparent",
        /*transparent*/
        m[9]
      ), p & /*disabled, _color*/
      2176 && en(e, "color", !/*disabled*/
      m[7] && /*_color*/
      m[11] ? (
        /*_color*/
        m[11]
      ) : "var(--block-label-text-color)"), p & /*disabled, background*/
      1152 && en(e, "--bg-color", /*disabled*/
      m[7] ? "auto" : (
        /*background*/
        m[10]
      ));
    },
    i(m) {
      a || (l && wn(l.$$.fragment, m), wn(h, m), a = !0);
    },
    o(m) {
      l && kn(l.$$.fragment, m), kn(h, m), a = !1;
    },
    d(m) {
      m && Rt(e), u && u.d(), l && ci(l), h && h.d(m), s = !1, r();
    }
  };
}
function Ta(o, e, t) {
  let n, { $$slots: l = {}, $$scope: i } = e, { Icon: a } = e, { label: s = "" } = e, { show_label: r = !1 } = e, { pending: u = !1 } = e, { size: _ = "small" } = e, { padded: d = !0 } = e, { highlight: c = !1 } = e, { disabled: h = !1 } = e, { hasPopup: m = !1 } = e, { color: p = "var(--block-label-text-color)" } = e, { transparent: b = !1 } = e, { background: k = "var(--block-background-fill)" } = e;
  function g(f) {
    ga.call(this, o, f);
  }
  return o.$$set = (f) => {
    "Icon" in f && t(0, a = f.Icon), "label" in f && t(1, s = f.label), "show_label" in f && t(2, r = f.show_label), "pending" in f && t(3, u = f.pending), "size" in f && t(4, _ = f.size), "padded" in f && t(5, d = f.padded), "highlight" in f && t(6, c = f.highlight), "disabled" in f && t(7, h = f.disabled), "hasPopup" in f && t(8, m = f.hasPopup), "color" in f && t(12, p = f.color), "transparent" in f && t(9, b = f.transparent), "background" in f && t(10, k = f.background), "$$scope" in f && t(13, i = f.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty & /*highlight, color*/
    4160 && t(11, n = c ? "var(--color-accent)" : p);
  }, [
    a,
    s,
    r,
    u,
    _,
    d,
    c,
    h,
    m,
    b,
    k,
    n,
    p,
    i,
    l,
    g
  ];
}
class za extends ma {
  constructor(e) {
    super(), $a(this, e, Ta, Ba, Ea, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: b_,
  append_hydration: D_,
  attr: y_,
  binding_callbacks: w_,
  children: k_,
  claim_element: F_,
  create_slot: $_,
  detach: C_,
  element: E_,
  get_all_dirty_from_scope: A_,
  get_slot_changes: S_,
  init: q_,
  insert_hydration: B_,
  safe_not_equal: T_,
  toggle_class: z_,
  transition_in: I_,
  transition_out: R_,
  update_slot_base: L_
} = window.__gradio__svelte__internal, {
  SvelteComponent: O_,
  append_hydration: P_,
  attr: M_,
  children: N_,
  claim_svg_element: j_,
  detach: V_,
  init: H_,
  insert_hydration: G_,
  noop: U_,
  safe_not_equal: Z_,
  svg_element: x_
} = window.__gradio__svelte__internal, {
  SvelteComponent: X_,
  append_hydration: Y_,
  attr: W_,
  children: K_,
  claim_svg_element: Q_,
  detach: J_,
  init: ec,
  insert_hydration: tc,
  noop: nc,
  safe_not_equal: ic,
  svg_element: lc
} = window.__gradio__svelte__internal, {
  SvelteComponent: oc,
  append_hydration: ac,
  attr: sc,
  children: rc,
  claim_svg_element: uc,
  detach: _c,
  init: cc,
  insert_hydration: dc,
  noop: fc,
  safe_not_equal: hc,
  svg_element: pc
} = window.__gradio__svelte__internal, {
  SvelteComponent: mc,
  append_hydration: gc,
  attr: vc,
  children: bc,
  claim_svg_element: Dc,
  detach: yc,
  init: wc,
  insert_hydration: kc,
  noop: Fc,
  safe_not_equal: $c,
  svg_element: Cc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ec,
  append_hydration: Ac,
  attr: Sc,
  children: qc,
  claim_svg_element: Bc,
  detach: Tc,
  init: zc,
  insert_hydration: Ic,
  noop: Rc,
  safe_not_equal: Lc,
  svg_element: Oc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pc,
  append_hydration: Mc,
  attr: Nc,
  children: jc,
  claim_svg_element: Vc,
  detach: Hc,
  init: Gc,
  insert_hydration: Uc,
  noop: Zc,
  safe_not_equal: xc,
  svg_element: Xc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yc,
  append_hydration: Wc,
  attr: Kc,
  children: Qc,
  claim_svg_element: Jc,
  detach: ed,
  init: td,
  insert_hydration: nd,
  noop: id,
  safe_not_equal: ld,
  svg_element: od
} = window.__gradio__svelte__internal, {
  SvelteComponent: ad,
  append_hydration: sd,
  attr: rd,
  children: ud,
  claim_svg_element: _d,
  detach: cd,
  init: dd,
  insert_hydration: fd,
  noop: hd,
  safe_not_equal: pd,
  svg_element: md
} = window.__gradio__svelte__internal, {
  SvelteComponent: gd,
  append_hydration: vd,
  attr: bd,
  children: Dd,
  claim_svg_element: yd,
  detach: wd,
  init: kd,
  insert_hydration: Fd,
  noop: $d,
  safe_not_equal: Cd,
  svg_element: Ed
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ad,
  append_hydration: Sd,
  attr: qd,
  children: Bd,
  claim_svg_element: Td,
  detach: zd,
  init: Id,
  insert_hydration: Rd,
  noop: Ld,
  safe_not_equal: Od,
  svg_element: Pd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Md,
  append_hydration: Nd,
  attr: jd,
  children: Vd,
  claim_svg_element: Hd,
  detach: Gd,
  init: Ud,
  insert_hydration: Zd,
  noop: xd,
  safe_not_equal: Xd,
  svg_element: Yd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wd,
  append_hydration: Kd,
  attr: Qd,
  children: Jd,
  claim_svg_element: ef,
  detach: tf,
  init: nf,
  insert_hydration: lf,
  noop: of,
  safe_not_equal: af,
  svg_element: sf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ia,
  append_hydration: Fn,
  attr: Ie,
  children: tn,
  claim_svg_element: nn,
  detach: qt,
  init: Ra,
  insert_hydration: La,
  noop: $n,
  safe_not_equal: Oa,
  set_style: Ve,
  svg_element: ln
} = window.__gradio__svelte__internal;
function Pa(o) {
  let e, t, n, l;
  return {
    c() {
      e = ln("svg"), t = ln("g"), n = ln("path"), l = ln("path"), this.h();
    },
    l(i) {
      e = nn(i, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var a = tn(e);
      t = nn(a, "g", { transform: !0 });
      var s = tn(t);
      n = nn(s, "path", { d: !0, style: !0 }), tn(n).forEach(qt), s.forEach(qt), l = nn(a, "path", { d: !0, style: !0 }), tn(l).forEach(qt), a.forEach(qt), this.h();
    },
    h() {
      Ie(n, "d", "M18,6L6.087,17.913"), Ve(n, "fill", "none"), Ve(n, "fill-rule", "nonzero"), Ve(n, "stroke-width", "2px"), Ie(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Ie(l, "d", "M4.364,4.364L19.636,19.636"), Ve(l, "fill", "none"), Ve(l, "fill-rule", "nonzero"), Ve(l, "stroke-width", "2px"), Ie(e, "width", "100%"), Ie(e, "height", "100%"), Ie(e, "viewBox", "0 0 24 24"), Ie(e, "version", "1.1"), Ie(e, "xmlns", "http://www.w3.org/2000/svg"), Ie(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Ie(e, "xml:space", "preserve"), Ie(e, "stroke", "currentColor"), Ve(e, "fill-rule", "evenodd"), Ve(e, "clip-rule", "evenodd"), Ve(e, "stroke-linecap", "round"), Ve(e, "stroke-linejoin", "round");
    },
    m(i, a) {
      La(i, e, a), Fn(e, t), Fn(t, n), Fn(e, l);
    },
    p: $n,
    i: $n,
    o: $n,
    d(i) {
      i && qt(e);
    }
  };
}
class Ma extends Ia {
  constructor(e) {
    super(), Ra(this, e, null, Pa, Oa, {});
  }
}
const {
  SvelteComponent: rf,
  append_hydration: uf,
  attr: _f,
  children: cf,
  claim_svg_element: df,
  detach: ff,
  init: hf,
  insert_hydration: pf,
  noop: mf,
  safe_not_equal: gf,
  svg_element: vf
} = window.__gradio__svelte__internal, {
  SvelteComponent: bf,
  append_hydration: Df,
  attr: yf,
  children: wf,
  claim_svg_element: kf,
  detach: Ff,
  init: $f,
  insert_hydration: Cf,
  noop: Ef,
  safe_not_equal: Af,
  svg_element: Sf
} = window.__gradio__svelte__internal, {
  SvelteComponent: qf,
  append_hydration: Bf,
  attr: Tf,
  children: zf,
  claim_svg_element: If,
  detach: Rf,
  init: Lf,
  insert_hydration: Of,
  noop: Pf,
  safe_not_equal: Mf,
  svg_element: Nf
} = window.__gradio__svelte__internal, {
  SvelteComponent: jf,
  append_hydration: Vf,
  attr: Hf,
  children: Gf,
  claim_svg_element: Uf,
  detach: Zf,
  init: xf,
  insert_hydration: Xf,
  noop: Yf,
  safe_not_equal: Wf,
  svg_element: Kf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qf,
  append_hydration: Jf,
  attr: eh,
  children: th,
  claim_svg_element: nh,
  detach: ih,
  init: lh,
  insert_hydration: oh,
  noop: ah,
  safe_not_equal: sh,
  svg_element: rh
} = window.__gradio__svelte__internal, {
  SvelteComponent: uh,
  append_hydration: _h,
  attr: ch,
  children: dh,
  claim_svg_element: fh,
  detach: hh,
  init: ph,
  insert_hydration: mh,
  noop: gh,
  safe_not_equal: vh,
  svg_element: bh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dh,
  append_hydration: yh,
  attr: wh,
  children: kh,
  claim_svg_element: Fh,
  detach: $h,
  init: Ch,
  insert_hydration: Eh,
  noop: Ah,
  safe_not_equal: Sh,
  svg_element: qh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bh,
  append_hydration: Th,
  attr: zh,
  children: Ih,
  claim_svg_element: Rh,
  detach: Lh,
  init: Oh,
  insert_hydration: Ph,
  noop: Mh,
  safe_not_equal: Nh,
  svg_element: jh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vh,
  append_hydration: Hh,
  attr: Gh,
  children: Uh,
  claim_svg_element: Zh,
  detach: xh,
  init: Xh,
  insert_hydration: Yh,
  noop: Wh,
  safe_not_equal: Kh,
  svg_element: Qh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jh,
  append_hydration: ep,
  attr: tp,
  children: np,
  claim_svg_element: ip,
  detach: lp,
  init: op,
  insert_hydration: ap,
  noop: sp,
  safe_not_equal: rp,
  svg_element: up
} = window.__gradio__svelte__internal, {
  SvelteComponent: _p,
  append_hydration: cp,
  attr: dp,
  children: fp,
  claim_svg_element: hp,
  detach: pp,
  init: mp,
  insert_hydration: gp,
  noop: vp,
  safe_not_equal: bp,
  svg_element: Dp
} = window.__gradio__svelte__internal, {
  SvelteComponent: yp,
  append_hydration: wp,
  attr: kp,
  children: Fp,
  claim_svg_element: $p,
  detach: Cp,
  init: Ep,
  insert_hydration: Ap,
  noop: Sp,
  safe_not_equal: qp,
  svg_element: Bp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tp,
  append_hydration: zp,
  attr: Ip,
  children: Rp,
  claim_svg_element: Lp,
  detach: Op,
  init: Pp,
  insert_hydration: Mp,
  noop: Np,
  safe_not_equal: jp,
  svg_element: Vp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hp,
  append_hydration: Gp,
  attr: Up,
  children: Zp,
  claim_svg_element: xp,
  detach: Xp,
  init: Yp,
  insert_hydration: Wp,
  noop: Kp,
  safe_not_equal: Qp,
  svg_element: Jp
} = window.__gradio__svelte__internal, {
  SvelteComponent: em,
  append_hydration: tm,
  attr: nm,
  children: im,
  claim_svg_element: lm,
  detach: om,
  init: am,
  insert_hydration: sm,
  noop: rm,
  safe_not_equal: um,
  svg_element: _m
} = window.__gradio__svelte__internal, {
  SvelteComponent: cm,
  append_hydration: dm,
  attr: fm,
  children: hm,
  claim_svg_element: pm,
  detach: mm,
  init: gm,
  insert_hydration: vm,
  noop: bm,
  safe_not_equal: Dm,
  svg_element: ym
} = window.__gradio__svelte__internal, {
  SvelteComponent: wm,
  append_hydration: km,
  attr: Fm,
  children: $m,
  claim_svg_element: Cm,
  detach: Em,
  init: Am,
  insert_hydration: Sm,
  noop: qm,
  safe_not_equal: Bm,
  svg_element: Tm
} = window.__gradio__svelte__internal, {
  SvelteComponent: zm,
  append_hydration: Im,
  attr: Rm,
  children: Lm,
  claim_svg_element: Om,
  detach: Pm,
  init: Mm,
  insert_hydration: Nm,
  noop: jm,
  safe_not_equal: Vm,
  svg_element: Hm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gm,
  append_hydration: Um,
  attr: Zm,
  children: xm,
  claim_svg_element: Xm,
  detach: Ym,
  init: Wm,
  insert_hydration: Km,
  noop: Qm,
  safe_not_equal: Jm,
  svg_element: eg
} = window.__gradio__svelte__internal, {
  SvelteComponent: tg,
  append_hydration: ng,
  attr: ig,
  children: lg,
  claim_svg_element: og,
  detach: ag,
  init: sg,
  insert_hydration: rg,
  noop: ug,
  safe_not_equal: _g,
  svg_element: cg
} = window.__gradio__svelte__internal, {
  SvelteComponent: dg,
  append_hydration: fg,
  attr: hg,
  children: pg,
  claim_svg_element: mg,
  detach: gg,
  init: vg,
  insert_hydration: bg,
  noop: Dg,
  safe_not_equal: yg,
  svg_element: wg
} = window.__gradio__svelte__internal, {
  SvelteComponent: kg,
  append_hydration: Fg,
  attr: $g,
  children: Cg,
  claim_svg_element: Eg,
  detach: Ag,
  init: Sg,
  insert_hydration: qg,
  noop: Bg,
  safe_not_equal: Tg,
  svg_element: zg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ig,
  append_hydration: Rg,
  attr: Lg,
  children: Og,
  claim_svg_element: Pg,
  detach: Mg,
  init: Ng,
  insert_hydration: jg,
  noop: Vg,
  safe_not_equal: Hg,
  svg_element: Gg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ug,
  append_hydration: Zg,
  attr: xg,
  children: Xg,
  claim_svg_element: Yg,
  detach: Wg,
  init: Kg,
  insert_hydration: Qg,
  noop: Jg,
  safe_not_equal: e0,
  svg_element: t0
} = window.__gradio__svelte__internal, {
  SvelteComponent: n0,
  append_hydration: i0,
  attr: l0,
  children: o0,
  claim_svg_element: a0,
  detach: s0,
  init: r0,
  insert_hydration: u0,
  noop: _0,
  safe_not_equal: c0,
  svg_element: d0
} = window.__gradio__svelte__internal, {
  SvelteComponent: f0,
  append_hydration: h0,
  attr: p0,
  children: m0,
  claim_svg_element: g0,
  detach: v0,
  init: b0,
  insert_hydration: D0,
  noop: y0,
  safe_not_equal: w0,
  svg_element: k0
} = window.__gradio__svelte__internal, {
  SvelteComponent: F0,
  append_hydration: $0,
  attr: C0,
  children: E0,
  claim_svg_element: A0,
  detach: S0,
  init: q0,
  insert_hydration: B0,
  noop: T0,
  safe_not_equal: z0,
  svg_element: I0
} = window.__gradio__svelte__internal, {
  SvelteComponent: R0,
  append_hydration: L0,
  attr: O0,
  children: P0,
  claim_svg_element: M0,
  detach: N0,
  init: j0,
  insert_hydration: V0,
  noop: H0,
  safe_not_equal: G0,
  svg_element: U0
} = window.__gradio__svelte__internal, {
  SvelteComponent: Z0,
  append_hydration: x0,
  attr: X0,
  children: Y0,
  claim_svg_element: W0,
  detach: K0,
  init: Q0,
  insert_hydration: J0,
  noop: e1,
  safe_not_equal: t1,
  svg_element: n1
} = window.__gradio__svelte__internal, {
  SvelteComponent: i1,
  append_hydration: l1,
  attr: o1,
  children: a1,
  claim_svg_element: s1,
  detach: r1,
  init: u1,
  insert_hydration: _1,
  noop: c1,
  safe_not_equal: d1,
  svg_element: f1
} = window.__gradio__svelte__internal, {
  SvelteComponent: h1,
  append_hydration: p1,
  attr: m1,
  children: g1,
  claim_svg_element: v1,
  detach: b1,
  init: D1,
  insert_hydration: y1,
  noop: w1,
  safe_not_equal: k1,
  svg_element: F1
} = window.__gradio__svelte__internal, {
  SvelteComponent: $1,
  append_hydration: C1,
  attr: E1,
  children: A1,
  claim_svg_element: S1,
  detach: q1,
  init: B1,
  insert_hydration: T1,
  noop: z1,
  safe_not_equal: I1,
  svg_element: R1
} = window.__gradio__svelte__internal, {
  SvelteComponent: L1,
  append_hydration: O1,
  attr: P1,
  children: M1,
  claim_svg_element: N1,
  detach: j1,
  init: V1,
  insert_hydration: H1,
  noop: G1,
  safe_not_equal: U1,
  svg_element: Z1
} = window.__gradio__svelte__internal, {
  SvelteComponent: x1,
  append_hydration: X1,
  attr: Y1,
  children: W1,
  claim_svg_element: K1,
  detach: Q1,
  init: J1,
  insert_hydration: ev,
  noop: tv,
  safe_not_equal: nv,
  set_style: iv,
  svg_element: lv
} = window.__gradio__svelte__internal, {
  SvelteComponent: ov,
  append_hydration: av,
  attr: sv,
  children: rv,
  claim_svg_element: uv,
  detach: _v,
  init: cv,
  insert_hydration: dv,
  noop: fv,
  safe_not_equal: hv,
  svg_element: pv
} = window.__gradio__svelte__internal, {
  SvelteComponent: mv,
  append_hydration: gv,
  attr: vv,
  children: bv,
  claim_svg_element: Dv,
  detach: yv,
  init: wv,
  insert_hydration: kv,
  noop: Fv,
  safe_not_equal: $v,
  svg_element: Cv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ev,
  append_hydration: Av,
  attr: Sv,
  children: qv,
  claim_svg_element: Bv,
  detach: Tv,
  init: zv,
  insert_hydration: Iv,
  noop: Rv,
  safe_not_equal: Lv,
  svg_element: Ov
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pv,
  append_hydration: Mv,
  attr: Nv,
  children: jv,
  claim_svg_element: Vv,
  detach: Hv,
  init: Gv,
  insert_hydration: Uv,
  noop: Zv,
  safe_not_equal: xv,
  svg_element: Xv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yv,
  append_hydration: Wv,
  attr: Kv,
  children: Qv,
  claim_svg_element: Jv,
  detach: eb,
  init: tb,
  insert_hydration: nb,
  noop: ib,
  safe_not_equal: lb,
  svg_element: ob
} = window.__gradio__svelte__internal, {
  SvelteComponent: ab,
  append_hydration: sb,
  attr: rb,
  children: ub,
  claim_svg_element: _b,
  detach: cb,
  init: db,
  insert_hydration: fb,
  noop: hb,
  safe_not_equal: pb,
  svg_element: mb
} = window.__gradio__svelte__internal, {
  SvelteComponent: gb,
  append_hydration: vb,
  attr: bb,
  children: Db,
  claim_svg_element: yb,
  detach: wb,
  init: kb,
  insert_hydration: Fb,
  noop: $b,
  safe_not_equal: Cb,
  svg_element: Eb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ab,
  append_hydration: Sb,
  attr: qb,
  children: Bb,
  claim_svg_element: Tb,
  detach: zb,
  init: Ib,
  insert_hydration: Rb,
  noop: Lb,
  safe_not_equal: Ob,
  svg_element: Pb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mb,
  append_hydration: Nb,
  attr: jb,
  children: Vb,
  claim_svg_element: Hb,
  claim_text: Gb,
  detach: Ub,
  init: Zb,
  insert_hydration: xb,
  noop: Xb,
  safe_not_equal: Yb,
  svg_element: Wb,
  text: Kb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qb,
  append_hydration: Jb,
  attr: e2,
  children: t2,
  claim_svg_element: n2,
  detach: i2,
  init: l2,
  insert_hydration: o2,
  noop: a2,
  safe_not_equal: s2,
  svg_element: r2
} = window.__gradio__svelte__internal, {
  SvelteComponent: u2,
  append_hydration: _2,
  attr: c2,
  children: d2,
  claim_svg_element: f2,
  detach: h2,
  init: p2,
  insert_hydration: m2,
  noop: g2,
  safe_not_equal: v2,
  svg_element: b2
} = window.__gradio__svelte__internal, {
  SvelteComponent: D2,
  append_hydration: y2,
  attr: w2,
  children: k2,
  claim_svg_element: F2,
  detach: $2,
  init: C2,
  insert_hydration: E2,
  noop: A2,
  safe_not_equal: S2,
  svg_element: q2
} = window.__gradio__svelte__internal, {
  SvelteComponent: B2,
  append_hydration: T2,
  attr: z2,
  children: I2,
  claim_svg_element: R2,
  detach: L2,
  init: O2,
  insert_hydration: P2,
  noop: M2,
  safe_not_equal: N2,
  svg_element: j2
} = window.__gradio__svelte__internal, {
  SvelteComponent: V2,
  append_hydration: H2,
  attr: G2,
  children: U2,
  claim_svg_element: Z2,
  detach: x2,
  init: X2,
  insert_hydration: Y2,
  noop: W2,
  safe_not_equal: K2,
  svg_element: Q2
} = window.__gradio__svelte__internal, {
  SvelteComponent: J2,
  append_hydration: eD,
  attr: tD,
  children: nD,
  claim_svg_element: iD,
  detach: lD,
  init: oD,
  insert_hydration: aD,
  noop: sD,
  safe_not_equal: rD,
  svg_element: uD
} = window.__gradio__svelte__internal, {
  SvelteComponent: _D,
  append_hydration: cD,
  attr: dD,
  children: fD,
  claim_svg_element: hD,
  detach: pD,
  init: mD,
  insert_hydration: gD,
  noop: vD,
  safe_not_equal: bD,
  svg_element: DD
} = window.__gradio__svelte__internal, {
  SvelteComponent: yD,
  append_hydration: wD,
  attr: kD,
  children: FD,
  claim_svg_element: $D,
  claim_text: CD,
  detach: ED,
  init: AD,
  insert_hydration: SD,
  noop: qD,
  safe_not_equal: BD,
  svg_element: TD,
  text: zD
} = window.__gradio__svelte__internal, {
  SvelteComponent: ID,
  append_hydration: RD,
  attr: LD,
  children: OD,
  claim_svg_element: PD,
  claim_text: MD,
  detach: ND,
  init: jD,
  insert_hydration: VD,
  noop: HD,
  safe_not_equal: GD,
  svg_element: UD,
  text: ZD
} = window.__gradio__svelte__internal, {
  SvelteComponent: xD,
  append_hydration: XD,
  attr: YD,
  children: WD,
  claim_svg_element: KD,
  claim_text: QD,
  detach: JD,
  init: ey,
  insert_hydration: ty,
  noop: ny,
  safe_not_equal: iy,
  svg_element: ly,
  text: oy
} = window.__gradio__svelte__internal, {
  SvelteComponent: ay,
  append_hydration: sy,
  attr: ry,
  children: uy,
  claim_svg_element: _y,
  detach: cy,
  init: dy,
  insert_hydration: fy,
  noop: hy,
  safe_not_equal: py,
  svg_element: my
} = window.__gradio__svelte__internal, {
  SvelteComponent: gy,
  append_hydration: vy,
  attr: by,
  children: Dy,
  claim_svg_element: yy,
  detach: wy,
  init: ky,
  insert_hydration: Fy,
  noop: $y,
  safe_not_equal: Cy,
  svg_element: Ey
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ay,
  append_hydration: Sy,
  attr: qy,
  children: By,
  claim_svg_element: Ty,
  detach: zy,
  init: Iy,
  insert_hydration: Ry,
  noop: Ly,
  safe_not_equal: Oy,
  svg_element: Py
} = window.__gradio__svelte__internal, {
  SvelteComponent: My,
  append_hydration: Ny,
  attr: jy,
  children: Vy,
  claim_svg_element: Hy,
  detach: Gy,
  init: Uy,
  insert_hydration: Zy,
  noop: xy,
  safe_not_equal: Xy,
  svg_element: Yy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wy,
  append_hydration: Ky,
  attr: Qy,
  children: Jy,
  claim_svg_element: ew,
  detach: tw,
  init: nw,
  insert_hydration: iw,
  noop: lw,
  safe_not_equal: ow,
  svg_element: aw
} = window.__gradio__svelte__internal, {
  SvelteComponent: sw,
  append_hydration: rw,
  attr: uw,
  children: _w,
  claim_svg_element: cw,
  detach: dw,
  init: fw,
  insert_hydration: hw,
  noop: pw,
  safe_not_equal: mw,
  svg_element: gw
} = window.__gradio__svelte__internal, {
  SvelteComponent: vw,
  append_hydration: bw,
  attr: Dw,
  children: yw,
  claim_svg_element: ww,
  detach: kw,
  init: Fw,
  insert_hydration: $w,
  noop: Cw,
  safe_not_equal: Ew,
  svg_element: Aw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sw,
  append_hydration: qw,
  attr: Bw,
  children: Tw,
  claim_svg_element: zw,
  detach: Iw,
  init: Rw,
  insert_hydration: Lw,
  noop: Ow,
  safe_not_equal: Pw,
  svg_element: Mw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nw,
  append_hydration: jw,
  attr: Vw,
  children: Hw,
  claim_svg_element: Gw,
  detach: Uw,
  init: Zw,
  insert_hydration: xw,
  noop: Xw,
  safe_not_equal: Yw,
  svg_element: Ww
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kw,
  append_hydration: Qw,
  attr: Jw,
  children: ek,
  claim_svg_element: tk,
  detach: nk,
  init: ik,
  insert_hydration: lk,
  noop: ok,
  safe_not_equal: ak,
  svg_element: sk
} = window.__gradio__svelte__internal, {
  SvelteComponent: rk,
  append_hydration: uk,
  attr: _k,
  children: ck,
  claim_svg_element: dk,
  detach: fk,
  init: hk,
  insert_hydration: pk,
  noop: mk,
  safe_not_equal: gk,
  svg_element: vk
} = window.__gradio__svelte__internal, Na = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], pi = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Na.reduce(
  (o, { color: e, primary: t, secondary: n }) => ({
    ...o,
    [e]: {
      primary: pi[e][t],
      secondary: pi[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: bk,
  claim_component: Dk,
  create_component: yk,
  destroy_component: wk,
  init: kk,
  mount_component: Fk,
  safe_not_equal: $k,
  transition_in: Ck,
  transition_out: Ek
} = window.__gradio__svelte__internal, { createEventDispatcher: Ak } = window.__gradio__svelte__internal, {
  SvelteComponent: Sk,
  append_hydration: qk,
  attr: Bk,
  check_outros: Tk,
  children: zk,
  claim_component: Ik,
  claim_element: Rk,
  claim_space: Lk,
  claim_text: Ok,
  create_component: Pk,
  destroy_component: Mk,
  detach: Nk,
  element: jk,
  empty: Vk,
  group_outros: Hk,
  init: Gk,
  insert_hydration: Uk,
  mount_component: Zk,
  safe_not_equal: xk,
  set_data: Xk,
  space: Yk,
  text: Wk,
  toggle_class: Kk,
  transition_in: Qk,
  transition_out: Jk
} = window.__gradio__svelte__internal, {
  SvelteComponent: eF,
  attr: tF,
  children: nF,
  claim_element: iF,
  create_slot: lF,
  detach: oF,
  element: aF,
  get_all_dirty_from_scope: sF,
  get_slot_changes: rF,
  init: uF,
  insert_hydration: _F,
  safe_not_equal: cF,
  toggle_class: dF,
  transition_in: fF,
  transition_out: hF,
  update_slot_base: pF
} = window.__gradio__svelte__internal, {
  SvelteComponent: mF,
  append_hydration: gF,
  attr: vF,
  check_outros: bF,
  children: DF,
  claim_component: yF,
  claim_element: wF,
  claim_space: kF,
  create_component: FF,
  destroy_component: $F,
  detach: CF,
  element: EF,
  empty: AF,
  group_outros: SF,
  init: qF,
  insert_hydration: BF,
  listen: TF,
  mount_component: zF,
  safe_not_equal: IF,
  space: RF,
  toggle_class: LF,
  transition_in: OF,
  transition_out: PF
} = window.__gradio__svelte__internal, {
  SvelteComponent: MF,
  attr: NF,
  children: jF,
  claim_element: VF,
  create_slot: HF,
  detach: GF,
  element: UF,
  get_all_dirty_from_scope: ZF,
  get_slot_changes: xF,
  init: XF,
  insert_hydration: YF,
  null_to_empty: WF,
  safe_not_equal: KF,
  transition_in: QF,
  transition_out: JF,
  update_slot_base: e$
} = window.__gradio__svelte__internal, {
  SvelteComponent: t$,
  check_outros: n$,
  claim_component: i$,
  create_component: l$,
  destroy_component: o$,
  detach: a$,
  empty: s$,
  group_outros: r$,
  init: u$,
  insert_hydration: _$,
  mount_component: c$,
  noop: d$,
  safe_not_equal: f$,
  transition_in: h$,
  transition_out: p$
} = window.__gradio__svelte__internal, { createEventDispatcher: m$ } = window.__gradio__svelte__internal;
function yt(o) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; o > 1e3 && t < e.length - 1; )
    o /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(o) ? o : o.toFixed(1)) + n;
}
function un() {
}
const xl = typeof window < "u";
let mi = xl ? () => window.performance.now() : () => Date.now(), Xl = xl ? (o) => requestAnimationFrame(o) : un;
const wt = /* @__PURE__ */ new Set();
function Yl(o) {
  wt.forEach((e) => {
    e.c(o) || (wt.delete(e), e.f());
  }), wt.size !== 0 && Xl(Yl);
}
function ja(o) {
  let e;
  return wt.size === 0 && Xl(Yl), { promise: new Promise((t) => {
    wt.add(e = { c: o, f: t });
  }), abort() {
    wt.delete(e);
  } };
}
const Dt = [];
function Va(o, e = un) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function l(a) {
    if (r = a, ((s = o) != s ? r == r : s !== r || s && typeof s == "object" || typeof s == "function") && (o = a, t)) {
      const u = !Dt.length;
      for (const _ of n) _[1](), Dt.push(_, o);
      if (u) {
        for (let _ = 0; _ < Dt.length; _ += 2) Dt[_][0](Dt[_ + 1]);
        Dt.length = 0;
      }
    }
    var s, r;
  }
  function i(a) {
    l(a(o));
  }
  return { set: l, update: i, subscribe: function(a, s = un) {
    const r = [a, s];
    return n.add(r), n.size === 1 && (t = e(l, i) || un), a(o), () => {
      n.delete(r), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function gi(o) {
  return Object.prototype.toString.call(o) === "[object Date]";
}
function zn(o, e, t, n) {
  if (typeof t == "number" || gi(t)) {
    const l = n - t, i = (t - e) / (o.dt || 1 / 60), a = (i + (o.opts.stiffness * l - o.opts.damping * i) * o.inv_mass) * o.dt;
    return Math.abs(a) < o.opts.precision && Math.abs(l) < o.opts.precision ? n : (o.settled = !1, gi(t) ? new Date(t.getTime() + a) : t + a);
  }
  if (Array.isArray(t)) return t.map((l, i) => zn(o, e[i], t[i], n[i]));
  if (typeof t == "object") {
    const l = {};
    for (const i in t) l[i] = zn(o, e[i], t[i], n[i]);
    return l;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function vi(o, e = {}) {
  const t = Va(o), { stiffness: n = 0.15, damping: l = 0.8, precision: i = 0.01 } = e;
  let a, s, r, u = o, _ = o, d = 1, c = 0, h = !1;
  function m(b, k = {}) {
    _ = b;
    const g = r = {};
    return o == null || k.hard || p.stiffness >= 1 && p.damping >= 1 ? (h = !0, a = mi(), u = b, t.set(o = _), Promise.resolve()) : (k.soft && (c = 1 / (60 * (k.soft === !0 ? 0.5 : +k.soft)), d = 0), s || (a = mi(), h = !1, s = ja((f) => {
      if (h) return h = !1, s = null, !1;
      d = Math.min(d + c, 1);
      const v = { inv_mass: d, opts: p, settled: !0, dt: 60 * (f - a) / 1e3 }, D = zn(v, u, o, _);
      return a = f, u = o, t.set(o = D), v.settled && (s = null), !v.settled;
    })), new Promise((f) => {
      s.promise.then(() => {
        g === r && f();
      });
    }));
  }
  const p = { set: m, update: (b, k) => m(b(_, o), k), subscribe: t.subscribe, stiffness: n, damping: l, precision: i };
  return p;
}
const {
  SvelteComponent: Ha,
  append_hydration: Re,
  attr: I,
  children: we,
  claim_element: Ga,
  claim_svg_element: Le,
  component_subscribe: bi,
  detach: ve,
  element: Ua,
  init: Za,
  insert_hydration: xa,
  noop: Di,
  safe_not_equal: Xa,
  set_style: on,
  svg_element: Oe,
  toggle_class: yi
} = window.__gradio__svelte__internal, { onMount: Ya } = window.__gradio__svelte__internal;
function Wa(o) {
  let e, t, n, l, i, a, s, r, u, _, d, c;
  return {
    c() {
      e = Ua("div"), t = Oe("svg"), n = Oe("g"), l = Oe("path"), i = Oe("path"), a = Oe("path"), s = Oe("path"), r = Oe("g"), u = Oe("path"), _ = Oe("path"), d = Oe("path"), c = Oe("path"), this.h();
    },
    l(h) {
      e = Ga(h, "DIV", { class: !0 });
      var m = we(e);
      t = Le(m, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var p = we(t);
      n = Le(p, "g", { style: !0 });
      var b = we(n);
      l = Le(b, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), we(l).forEach(ve), i = Le(b, "path", { d: !0, fill: !0, class: !0 }), we(i).forEach(ve), a = Le(b, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), we(a).forEach(ve), s = Le(b, "path", { d: !0, fill: !0, class: !0 }), we(s).forEach(ve), b.forEach(ve), r = Le(p, "g", { style: !0 });
      var k = we(r);
      u = Le(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), we(u).forEach(ve), _ = Le(k, "path", { d: !0, fill: !0, class: !0 }), we(_).forEach(ve), d = Le(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), we(d).forEach(ve), c = Le(k, "path", { d: !0, fill: !0, class: !0 }), we(c).forEach(ve), k.forEach(ve), p.forEach(ve), m.forEach(ve), this.h();
    },
    h() {
      I(l, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), I(l, "fill", "#FF7C00"), I(l, "fill-opacity", "0.4"), I(l, "class", "svelte-43sxxs"), I(i, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), I(i, "fill", "#FF7C00"), I(i, "class", "svelte-43sxxs"), I(a, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), I(a, "fill", "#FF7C00"), I(a, "fill-opacity", "0.4"), I(a, "class", "svelte-43sxxs"), I(s, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), I(s, "fill", "#FF7C00"), I(s, "class", "svelte-43sxxs"), on(n, "transform", "translate(" + /*$top*/
      o[1][0] + "px, " + /*$top*/
      o[1][1] + "px)"), I(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), I(u, "fill", "#FF7C00"), I(u, "fill-opacity", "0.4"), I(u, "class", "svelte-43sxxs"), I(_, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), I(_, "fill", "#FF7C00"), I(_, "class", "svelte-43sxxs"), I(d, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), I(d, "fill", "#FF7C00"), I(d, "fill-opacity", "0.4"), I(d, "class", "svelte-43sxxs"), I(c, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), I(c, "fill", "#FF7C00"), I(c, "class", "svelte-43sxxs"), on(r, "transform", "translate(" + /*$bottom*/
      o[2][0] + "px, " + /*$bottom*/
      o[2][1] + "px)"), I(t, "viewBox", "-1200 -1200 3000 3000"), I(t, "fill", "none"), I(t, "xmlns", "http://www.w3.org/2000/svg"), I(t, "class", "svelte-43sxxs"), I(e, "class", "svelte-43sxxs"), yi(
        e,
        "margin",
        /*margin*/
        o[0]
      );
    },
    m(h, m) {
      xa(h, e, m), Re(e, t), Re(t, n), Re(n, l), Re(n, i), Re(n, a), Re(n, s), Re(t, r), Re(r, u), Re(r, _), Re(r, d), Re(r, c);
    },
    p(h, [m]) {
      m & /*$top*/
      2 && on(n, "transform", "translate(" + /*$top*/
      h[1][0] + "px, " + /*$top*/
      h[1][1] + "px)"), m & /*$bottom*/
      4 && on(r, "transform", "translate(" + /*$bottom*/
      h[2][0] + "px, " + /*$bottom*/
      h[2][1] + "px)"), m & /*margin*/
      1 && yi(
        e,
        "margin",
        /*margin*/
        h[0]
      );
    },
    i: Di,
    o: Di,
    d(h) {
      h && ve(e);
    }
  };
}
function Ka(o, e, t) {
  let n, l;
  var i = this && this.__awaiter || function(h, m, p, b) {
    function k(g) {
      return g instanceof p ? g : new p(function(f) {
        f(g);
      });
    }
    return new (p || (p = Promise))(function(g, f) {
      function v(F) {
        try {
          w(b.next(F));
        } catch (A) {
          f(A);
        }
      }
      function D(F) {
        try {
          w(b.throw(F));
        } catch (A) {
          f(A);
        }
      }
      function w(F) {
        F.done ? g(F.value) : k(F.value).then(v, D);
      }
      w((b = b.apply(h, m || [])).next());
    });
  };
  let { margin: a = !0 } = e;
  const s = vi([0, 0]);
  bi(o, s, (h) => t(1, n = h));
  const r = vi([0, 0]);
  bi(o, r, (h) => t(2, l = h));
  let u;
  function _() {
    return i(this, void 0, void 0, function* () {
      yield Promise.all([s.set([125, 140]), r.set([-125, -140])]), yield Promise.all([s.set([-125, 140]), r.set([125, -140])]), yield Promise.all([s.set([-125, 0]), r.set([125, -0])]), yield Promise.all([s.set([125, 0]), r.set([-125, 0])]);
    });
  }
  function d() {
    return i(this, void 0, void 0, function* () {
      yield _(), u || d();
    });
  }
  function c() {
    return i(this, void 0, void 0, function* () {
      yield Promise.all([s.set([125, 0]), r.set([-125, 0])]), d();
    });
  }
  return Ya(() => (c(), () => u = !0)), o.$$set = (h) => {
    "margin" in h && t(0, a = h.margin);
  }, [a, n, l, s, r];
}
class Qa extends Ha {
  constructor(e) {
    super(), Za(this, e, Ka, Wa, Xa, { margin: 0 });
  }
}
const {
  SvelteComponent: Ja,
  append_hydration: dt,
  attr: Me,
  binding_callbacks: wi,
  check_outros: In,
  children: Ze,
  claim_component: Wl,
  claim_element: xe,
  claim_space: Fe,
  claim_text: X,
  create_component: Kl,
  create_slot: Ql,
  destroy_component: Jl,
  destroy_each: eo,
  detach: q,
  element: Xe,
  empty: Be,
  ensure_array_like: fn,
  get_all_dirty_from_scope: to,
  get_slot_changes: no,
  group_outros: Rn,
  init: es,
  insert_hydration: z,
  mount_component: io,
  noop: Ln,
  safe_not_equal: ts,
  set_data: Te,
  set_style: ot,
  space: $e,
  text: Y,
  toggle_class: ke,
  transition_in: Pe,
  transition_out: Ye,
  update_slot_base: lo
} = window.__gradio__svelte__internal, { tick: ns } = window.__gradio__svelte__internal, { onDestroy: is } = window.__gradio__svelte__internal, { createEventDispatcher: ls } = window.__gradio__svelte__internal, os = (o) => ({}), ki = (o) => ({}), as = (o) => ({}), Fi = (o) => ({});
function $i(o, e, t) {
  const n = o.slice();
  return n[40] = e[t], n[42] = t, n;
}
function Ci(o, e, t) {
  const n = o.slice();
  return n[40] = e[t], n;
}
function ss(o) {
  let e, t, n, l, i = (
    /*i18n*/
    o[1]("common.error") + ""
  ), a, s, r;
  t = new za({
    props: {
      Icon: Ma,
      label: (
        /*i18n*/
        o[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    o[32]
  );
  const u = (
    /*#slots*/
    o[30].error
  ), _ = Ql(
    u,
    o,
    /*$$scope*/
    o[29],
    ki
  );
  return {
    c() {
      e = Xe("div"), Kl(t.$$.fragment), n = $e(), l = Xe("span"), a = Y(i), s = $e(), _ && _.c(), this.h();
    },
    l(d) {
      e = xe(d, "DIV", { class: !0 });
      var c = Ze(e);
      Wl(t.$$.fragment, c), c.forEach(q), n = Fe(d), l = xe(d, "SPAN", { class: !0 });
      var h = Ze(l);
      a = X(h, i), h.forEach(q), s = Fe(d), _ && _.l(d), this.h();
    },
    h() {
      Me(e, "class", "clear-status svelte-17v219f"), Me(l, "class", "error svelte-17v219f");
    },
    m(d, c) {
      z(d, e, c), io(t, e, null), z(d, n, c), z(d, l, c), dt(l, a), z(d, s, c), _ && _.m(d, c), r = !0;
    },
    p(d, c) {
      const h = {};
      c[0] & /*i18n*/
      2 && (h.label = /*i18n*/
      d[1]("common.clear")), t.$set(h), (!r || c[0] & /*i18n*/
      2) && i !== (i = /*i18n*/
      d[1]("common.error") + "") && Te(a, i), _ && _.p && (!r || c[0] & /*$$scope*/
      536870912) && lo(
        _,
        u,
        d,
        /*$$scope*/
        d[29],
        r ? no(
          u,
          /*$$scope*/
          d[29],
          c,
          os
        ) : to(
          /*$$scope*/
          d[29]
        ),
        ki
      );
    },
    i(d) {
      r || (Pe(t.$$.fragment, d), Pe(_, d), r = !0);
    },
    o(d) {
      Ye(t.$$.fragment, d), Ye(_, d), r = !1;
    },
    d(d) {
      d && (q(e), q(n), q(l), q(s)), Jl(t), _ && _.d(d);
    }
  };
}
function rs(o) {
  let e, t, n, l, i, a, s, r, u, _ = (
    /*variant*/
    o[8] === "default" && /*show_eta_bar*/
    o[18] && /*show_progress*/
    o[6] === "full" && Ei(o)
  );
  function d(f, v) {
    if (
      /*progress*/
      f[7]
    ) return cs;
    if (
      /*queue_position*/
      f[2] !== null && /*queue_size*/
      f[3] !== void 0 && /*queue_position*/
      f[2] >= 0
    ) return _s;
    if (
      /*queue_position*/
      f[2] === 0
    ) return us;
  }
  let c = d(o), h = c && c(o), m = (
    /*timer*/
    o[5] && qi(o)
  );
  const p = [ps, hs], b = [];
  function k(f, v) {
    return (
      /*last_progress_level*/
      f[15] != null ? 0 : (
        /*show_progress*/
        f[6] === "full" ? 1 : -1
      )
    );
  }
  ~(i = k(o)) && (a = b[i] = p[i](o));
  let g = !/*timer*/
  o[5] && Oi(o);
  return {
    c() {
      _ && _.c(), e = $e(), t = Xe("div"), h && h.c(), n = $e(), m && m.c(), l = $e(), a && a.c(), s = $e(), g && g.c(), r = Be(), this.h();
    },
    l(f) {
      _ && _.l(f), e = Fe(f), t = xe(f, "DIV", { class: !0 });
      var v = Ze(t);
      h && h.l(v), n = Fe(v), m && m.l(v), v.forEach(q), l = Fe(f), a && a.l(f), s = Fe(f), g && g.l(f), r = Be(), this.h();
    },
    h() {
      Me(t, "class", "progress-text svelte-17v219f"), ke(
        t,
        "meta-text-center",
        /*variant*/
        o[8] === "center"
      ), ke(
        t,
        "meta-text",
        /*variant*/
        o[8] === "default"
      );
    },
    m(f, v) {
      _ && _.m(f, v), z(f, e, v), z(f, t, v), h && h.m(t, null), dt(t, n), m && m.m(t, null), z(f, l, v), ~i && b[i].m(f, v), z(f, s, v), g && g.m(f, v), z(f, r, v), u = !0;
    },
    p(f, v) {
      /*variant*/
      f[8] === "default" && /*show_eta_bar*/
      f[18] && /*show_progress*/
      f[6] === "full" ? _ ? _.p(f, v) : (_ = Ei(f), _.c(), _.m(e.parentNode, e)) : _ && (_.d(1), _ = null), c === (c = d(f)) && h ? h.p(f, v) : (h && h.d(1), h = c && c(f), h && (h.c(), h.m(t, n))), /*timer*/
      f[5] ? m ? m.p(f, v) : (m = qi(f), m.c(), m.m(t, null)) : m && (m.d(1), m = null), (!u || v[0] & /*variant*/
      256) && ke(
        t,
        "meta-text-center",
        /*variant*/
        f[8] === "center"
      ), (!u || v[0] & /*variant*/
      256) && ke(
        t,
        "meta-text",
        /*variant*/
        f[8] === "default"
      );
      let D = i;
      i = k(f), i === D ? ~i && b[i].p(f, v) : (a && (Rn(), Ye(b[D], 1, 1, () => {
        b[D] = null;
      }), In()), ~i ? (a = b[i], a ? a.p(f, v) : (a = b[i] = p[i](f), a.c()), Pe(a, 1), a.m(s.parentNode, s)) : a = null), /*timer*/
      f[5] ? g && (Rn(), Ye(g, 1, 1, () => {
        g = null;
      }), In()) : g ? (g.p(f, v), v[0] & /*timer*/
      32 && Pe(g, 1)) : (g = Oi(f), g.c(), Pe(g, 1), g.m(r.parentNode, r));
    },
    i(f) {
      u || (Pe(a), Pe(g), u = !0);
    },
    o(f) {
      Ye(a), Ye(g), u = !1;
    },
    d(f) {
      f && (q(e), q(t), q(l), q(s), q(r)), _ && _.d(f), h && h.d(), m && m.d(), ~i && b[i].d(f), g && g.d(f);
    }
  };
}
function Ei(o) {
  let e, t = `translateX(${/*eta_level*/
  (o[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Xe("div"), this.h();
    },
    l(n) {
      e = xe(n, "DIV", { class: !0 }), Ze(e).forEach(q), this.h();
    },
    h() {
      Me(e, "class", "eta-bar svelte-17v219f"), ot(e, "transform", t);
    },
    m(n, l) {
      z(n, e, l);
    },
    p(n, l) {
      l[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && ot(e, "transform", t);
    },
    d(n) {
      n && q(e);
    }
  };
}
function us(o) {
  let e;
  return {
    c() {
      e = Y("processing |");
    },
    l(t) {
      e = X(t, "processing |");
    },
    m(t, n) {
      z(t, e, n);
    },
    p: Ln,
    d(t) {
      t && q(e);
    }
  };
}
function _s(o) {
  let e, t = (
    /*queue_position*/
    o[2] + 1 + ""
  ), n, l, i, a;
  return {
    c() {
      e = Y("queue: "), n = Y(t), l = Y("/"), i = Y(
        /*queue_size*/
        o[3]
      ), a = Y(" |");
    },
    l(s) {
      e = X(s, "queue: "), n = X(s, t), l = X(s, "/"), i = X(
        s,
        /*queue_size*/
        o[3]
      ), a = X(s, " |");
    },
    m(s, r) {
      z(s, e, r), z(s, n, r), z(s, l, r), z(s, i, r), z(s, a, r);
    },
    p(s, r) {
      r[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      s[2] + 1 + "") && Te(n, t), r[0] & /*queue_size*/
      8 && Te(
        i,
        /*queue_size*/
        s[3]
      );
    },
    d(s) {
      s && (q(e), q(n), q(l), q(i), q(a));
    }
  };
}
function cs(o) {
  let e, t = fn(
    /*progress*/
    o[7]
  ), n = [];
  for (let l = 0; l < t.length; l += 1)
    n[l] = Si(Ci(o, t, l));
  return {
    c() {
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      e = Be();
    },
    l(l) {
      for (let i = 0; i < n.length; i += 1)
        n[i].l(l);
      e = Be();
    },
    m(l, i) {
      for (let a = 0; a < n.length; a += 1)
        n[a] && n[a].m(l, i);
      z(l, e, i);
    },
    p(l, i) {
      if (i[0] & /*progress*/
      128) {
        t = fn(
          /*progress*/
          l[7]
        );
        let a;
        for (a = 0; a < t.length; a += 1) {
          const s = Ci(l, t, a);
          n[a] ? n[a].p(s, i) : (n[a] = Si(s), n[a].c(), n[a].m(e.parentNode, e));
        }
        for (; a < n.length; a += 1)
          n[a].d(1);
        n.length = t.length;
      }
    },
    d(l) {
      l && q(e), eo(n, l);
    }
  };
}
function Ai(o) {
  let e, t = (
    /*p*/
    o[40].unit + ""
  ), n, l, i = " ", a;
  function s(_, d) {
    return (
      /*p*/
      _[40].length != null ? fs : ds
    );
  }
  let r = s(o), u = r(o);
  return {
    c() {
      u.c(), e = $e(), n = Y(t), l = Y(" | "), a = Y(i);
    },
    l(_) {
      u.l(_), e = Fe(_), n = X(_, t), l = X(_, " | "), a = X(_, i);
    },
    m(_, d) {
      u.m(_, d), z(_, e, d), z(_, n, d), z(_, l, d), z(_, a, d);
    },
    p(_, d) {
      r === (r = s(_)) && u ? u.p(_, d) : (u.d(1), u = r(_), u && (u.c(), u.m(e.parentNode, e))), d[0] & /*progress*/
      128 && t !== (t = /*p*/
      _[40].unit + "") && Te(n, t);
    },
    d(_) {
      _ && (q(e), q(n), q(l), q(a)), u.d(_);
    }
  };
}
function ds(o) {
  let e = yt(
    /*p*/
    o[40].index || 0
  ) + "", t;
  return {
    c() {
      t = Y(e);
    },
    l(n) {
      t = X(n, e);
    },
    m(n, l) {
      z(n, t, l);
    },
    p(n, l) {
      l[0] & /*progress*/
      128 && e !== (e = yt(
        /*p*/
        n[40].index || 0
      ) + "") && Te(t, e);
    },
    d(n) {
      n && q(t);
    }
  };
}
function fs(o) {
  let e = yt(
    /*p*/
    o[40].index || 0
  ) + "", t, n, l = yt(
    /*p*/
    o[40].length
  ) + "", i;
  return {
    c() {
      t = Y(e), n = Y("/"), i = Y(l);
    },
    l(a) {
      t = X(a, e), n = X(a, "/"), i = X(a, l);
    },
    m(a, s) {
      z(a, t, s), z(a, n, s), z(a, i, s);
    },
    p(a, s) {
      s[0] & /*progress*/
      128 && e !== (e = yt(
        /*p*/
        a[40].index || 0
      ) + "") && Te(t, e), s[0] & /*progress*/
      128 && l !== (l = yt(
        /*p*/
        a[40].length
      ) + "") && Te(i, l);
    },
    d(a) {
      a && (q(t), q(n), q(i));
    }
  };
}
function Si(o) {
  let e, t = (
    /*p*/
    o[40].index != null && Ai(o)
  );
  return {
    c() {
      t && t.c(), e = Be();
    },
    l(n) {
      t && t.l(n), e = Be();
    },
    m(n, l) {
      t && t.m(n, l), z(n, e, l);
    },
    p(n, l) {
      /*p*/
      n[40].index != null ? t ? t.p(n, l) : (t = Ai(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && q(e), t && t.d(n);
    }
  };
}
function qi(o) {
  let e, t = (
    /*eta*/
    o[0] ? `/${/*formatted_eta*/
    o[19]}` : ""
  ), n, l;
  return {
    c() {
      e = Y(
        /*formatted_timer*/
        o[20]
      ), n = Y(t), l = Y("s");
    },
    l(i) {
      e = X(
        i,
        /*formatted_timer*/
        o[20]
      ), n = X(i, t), l = X(i, "s");
    },
    m(i, a) {
      z(i, e, a), z(i, n, a), z(i, l, a);
    },
    p(i, a) {
      a[0] & /*formatted_timer*/
      1048576 && Te(
        e,
        /*formatted_timer*/
        i[20]
      ), a[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      i[0] ? `/${/*formatted_eta*/
      i[19]}` : "") && Te(n, t);
    },
    d(i) {
      i && (q(e), q(n), q(l));
    }
  };
}
function hs(o) {
  let e, t;
  return e = new Qa({
    props: { margin: (
      /*variant*/
      o[8] === "default"
    ) }
  }), {
    c() {
      Kl(e.$$.fragment);
    },
    l(n) {
      Wl(e.$$.fragment, n);
    },
    m(n, l) {
      io(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l[0] & /*variant*/
      256 && (i.margin = /*variant*/
      n[8] === "default"), e.$set(i);
    },
    i(n) {
      t || (Pe(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ye(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Jl(e, n);
    }
  };
}
function ps(o) {
  let e, t, n, l, i, a = `${/*last_progress_level*/
  o[15] * 100}%`, s = (
    /*progress*/
    o[7] != null && Bi(o)
  );
  return {
    c() {
      e = Xe("div"), t = Xe("div"), s && s.c(), n = $e(), l = Xe("div"), i = Xe("div"), this.h();
    },
    l(r) {
      e = xe(r, "DIV", { class: !0 });
      var u = Ze(e);
      t = xe(u, "DIV", { class: !0 });
      var _ = Ze(t);
      s && s.l(_), _.forEach(q), n = Fe(u), l = xe(u, "DIV", { class: !0 });
      var d = Ze(l);
      i = xe(d, "DIV", { class: !0 }), Ze(i).forEach(q), d.forEach(q), u.forEach(q), this.h();
    },
    h() {
      Me(t, "class", "progress-level-inner svelte-17v219f"), Me(i, "class", "progress-bar svelte-17v219f"), ot(i, "width", a), Me(l, "class", "progress-bar-wrap svelte-17v219f"), Me(e, "class", "progress-level svelte-17v219f");
    },
    m(r, u) {
      z(r, e, u), dt(e, t), s && s.m(t, null), dt(e, n), dt(e, l), dt(l, i), o[31](i);
    },
    p(r, u) {
      /*progress*/
      r[7] != null ? s ? s.p(r, u) : (s = Bi(r), s.c(), s.m(t, null)) : s && (s.d(1), s = null), u[0] & /*last_progress_level*/
      32768 && a !== (a = `${/*last_progress_level*/
      r[15] * 100}%`) && ot(i, "width", a);
    },
    i: Ln,
    o: Ln,
    d(r) {
      r && q(e), s && s.d(), o[31](null);
    }
  };
}
function Bi(o) {
  let e, t = fn(
    /*progress*/
    o[7]
  ), n = [];
  for (let l = 0; l < t.length; l += 1)
    n[l] = Li($i(o, t, l));
  return {
    c() {
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      e = Be();
    },
    l(l) {
      for (let i = 0; i < n.length; i += 1)
        n[i].l(l);
      e = Be();
    },
    m(l, i) {
      for (let a = 0; a < n.length; a += 1)
        n[a] && n[a].m(l, i);
      z(l, e, i);
    },
    p(l, i) {
      if (i[0] & /*progress_level, progress*/
      16512) {
        t = fn(
          /*progress*/
          l[7]
        );
        let a;
        for (a = 0; a < t.length; a += 1) {
          const s = $i(l, t, a);
          n[a] ? n[a].p(s, i) : (n[a] = Li(s), n[a].c(), n[a].m(e.parentNode, e));
        }
        for (; a < n.length; a += 1)
          n[a].d(1);
        n.length = t.length;
      }
    },
    d(l) {
      l && q(e), eo(n, l);
    }
  };
}
function Ti(o) {
  let e, t, n, l, i = (
    /*i*/
    o[42] !== 0 && ms()
  ), a = (
    /*p*/
    o[40].desc != null && zi(o)
  ), s = (
    /*p*/
    o[40].desc != null && /*progress_level*/
    o[14] && /*progress_level*/
    o[14][
      /*i*/
      o[42]
    ] != null && Ii()
  ), r = (
    /*progress_level*/
    o[14] != null && Ri(o)
  );
  return {
    c() {
      i && i.c(), e = $e(), a && a.c(), t = $e(), s && s.c(), n = $e(), r && r.c(), l = Be();
    },
    l(u) {
      i && i.l(u), e = Fe(u), a && a.l(u), t = Fe(u), s && s.l(u), n = Fe(u), r && r.l(u), l = Be();
    },
    m(u, _) {
      i && i.m(u, _), z(u, e, _), a && a.m(u, _), z(u, t, _), s && s.m(u, _), z(u, n, _), r && r.m(u, _), z(u, l, _);
    },
    p(u, _) {
      /*p*/
      u[40].desc != null ? a ? a.p(u, _) : (a = zi(u), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? s || (s = Ii(), s.c(), s.m(n.parentNode, n)) : s && (s.d(1), s = null), /*progress_level*/
      u[14] != null ? r ? r.p(u, _) : (r = Ri(u), r.c(), r.m(l.parentNode, l)) : r && (r.d(1), r = null);
    },
    d(u) {
      u && (q(e), q(t), q(n), q(l)), i && i.d(u), a && a.d(u), s && s.d(u), r && r.d(u);
    }
  };
}
function ms(o) {
  let e;
  return {
    c() {
      e = Y(" /");
    },
    l(t) {
      e = X(t, " /");
    },
    m(t, n) {
      z(t, e, n);
    },
    d(t) {
      t && q(e);
    }
  };
}
function zi(o) {
  let e = (
    /*p*/
    o[40].desc + ""
  ), t;
  return {
    c() {
      t = Y(e);
    },
    l(n) {
      t = X(n, e);
    },
    m(n, l) {
      z(n, t, l);
    },
    p(n, l) {
      l[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && Te(t, e);
    },
    d(n) {
      n && q(t);
    }
  };
}
function Ii(o) {
  let e;
  return {
    c() {
      e = Y("-");
    },
    l(t) {
      e = X(t, "-");
    },
    m(t, n) {
      z(t, e, n);
    },
    d(t) {
      t && q(e);
    }
  };
}
function Ri(o) {
  let e = (100 * /*progress_level*/
  (o[14][
    /*i*/
    o[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = Y(e), n = Y("%");
    },
    l(l) {
      t = X(l, e), n = X(l, "%");
    },
    m(l, i) {
      z(l, t, i), z(l, n, i);
    },
    p(l, i) {
      i[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (l[14][
        /*i*/
        l[42]
      ] || 0)).toFixed(1) + "") && Te(t, e);
    },
    d(l) {
      l && (q(t), q(n));
    }
  };
}
function Li(o) {
  let e, t = (
    /*p*/
    (o[40].desc != null || /*progress_level*/
    o[14] && /*progress_level*/
    o[14][
      /*i*/
      o[42]
    ] != null) && Ti(o)
  );
  return {
    c() {
      t && t.c(), e = Be();
    },
    l(n) {
      t && t.l(n), e = Be();
    },
    m(n, l) {
      t && t.m(n, l), z(n, e, l);
    },
    p(n, l) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, l) : (t = Ti(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && q(e), t && t.d(n);
    }
  };
}
function Oi(o) {
  let e, t, n, l;
  const i = (
    /*#slots*/
    o[30]["additional-loading-text"]
  ), a = Ql(
    i,
    o,
    /*$$scope*/
    o[29],
    Fi
  );
  return {
    c() {
      e = Xe("p"), t = Y(
        /*loading_text*/
        o[9]
      ), n = $e(), a && a.c(), this.h();
    },
    l(s) {
      e = xe(s, "P", { class: !0 });
      var r = Ze(e);
      t = X(
        r,
        /*loading_text*/
        o[9]
      ), r.forEach(q), n = Fe(s), a && a.l(s), this.h();
    },
    h() {
      Me(e, "class", "loading svelte-17v219f");
    },
    m(s, r) {
      z(s, e, r), dt(e, t), z(s, n, r), a && a.m(s, r), l = !0;
    },
    p(s, r) {
      (!l || r[0] & /*loading_text*/
      512) && Te(
        t,
        /*loading_text*/
        s[9]
      ), a && a.p && (!l || r[0] & /*$$scope*/
      536870912) && lo(
        a,
        i,
        s,
        /*$$scope*/
        s[29],
        l ? no(
          i,
          /*$$scope*/
          s[29],
          r,
          as
        ) : to(
          /*$$scope*/
          s[29]
        ),
        Fi
      );
    },
    i(s) {
      l || (Pe(a, s), l = !0);
    },
    o(s) {
      Ye(a, s), l = !1;
    },
    d(s) {
      s && (q(e), q(n)), a && a.d(s);
    }
  };
}
function gs(o) {
  let e, t, n, l, i;
  const a = [rs, ss], s = [];
  function r(u, _) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = r(o)) && (n = s[t] = a[t](o)), {
    c() {
      e = Xe("div"), n && n.c(), this.h();
    },
    l(u) {
      e = xe(u, "DIV", { class: !0 });
      var _ = Ze(e);
      n && n.l(_), _.forEach(q), this.h();
    },
    h() {
      Me(e, "class", l = "wrap " + /*variant*/
      o[8] + " " + /*show_progress*/
      o[6] + " svelte-17v219f"), ke(e, "hide", !/*status*/
      o[4] || /*status*/
      o[4] === "complete" || /*show_progress*/
      o[6] === "hidden" || /*status*/
      o[4] == "streaming"), ke(
        e,
        "translucent",
        /*variant*/
        o[8] === "center" && /*status*/
        (o[4] === "pending" || /*status*/
        o[4] === "error") || /*translucent*/
        o[11] || /*show_progress*/
        o[6] === "minimal"
      ), ke(
        e,
        "generating",
        /*status*/
        o[4] === "generating" && /*show_progress*/
        o[6] === "full"
      ), ke(
        e,
        "border",
        /*border*/
        o[12]
      ), ot(
        e,
        "position",
        /*absolute*/
        o[10] ? "absolute" : "static"
      ), ot(
        e,
        "padding",
        /*absolute*/
        o[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, _) {
      z(u, e, _), ~t && s[t].m(e, null), o[33](e), i = !0;
    },
    p(u, _) {
      let d = t;
      t = r(u), t === d ? ~t && s[t].p(u, _) : (n && (Rn(), Ye(s[d], 1, 1, () => {
        s[d] = null;
      }), In()), ~t ? (n = s[t], n ? n.p(u, _) : (n = s[t] = a[t](u), n.c()), Pe(n, 1), n.m(e, null)) : n = null), (!i || _[0] & /*variant, show_progress*/
      320 && l !== (l = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Me(e, "class", l), (!i || _[0] & /*variant, show_progress, status, show_progress*/
      336) && ke(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!i || _[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && ke(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!i || _[0] & /*variant, show_progress, status, show_progress*/
      336) && ke(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!i || _[0] & /*variant, show_progress, border*/
      4416) && ke(
        e,
        "border",
        /*border*/
        u[12]
      ), _[0] & /*absolute*/
      1024 && ot(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), _[0] & /*absolute*/
      1024 && ot(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      i || (Pe(n), i = !0);
    },
    o(u) {
      Ye(n), i = !1;
    },
    d(u) {
      u && q(e), ~t && s[t].d(), o[33](null);
    }
  };
}
var vs = function(o, e, t, n) {
  function l(i) {
    return i instanceof t ? i : new t(function(a) {
      a(i);
    });
  }
  return new (t || (t = Promise))(function(i, a) {
    function s(_) {
      try {
        u(n.next(_));
      } catch (d) {
        a(d);
      }
    }
    function r(_) {
      try {
        u(n.throw(_));
      } catch (d) {
        a(d);
      }
    }
    function u(_) {
      _.done ? i(_.value) : l(_.value).then(s, r);
    }
    u((n = n.apply(o, e || [])).next());
  });
};
let an = [], Cn = !1;
const bs = typeof window < "u", oo = bs ? window.requestAnimationFrame : (o) => {
};
function Ds(o) {
  return vs(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (an.push(e), !Cn) Cn = !0;
      else return;
      yield ns(), oo(() => {
        let n = [0, 0];
        for (let l = 0; l < an.length; l++) {
          const a = an[l].getBoundingClientRect();
          (l === 0 || a.top + window.scrollY <= n[0]) && (n[0] = a.top + window.scrollY, n[1] = l);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), Cn = !1, an = [];
      });
    }
  });
}
function ys(o, e, t) {
  let n, { $$slots: l = {}, $$scope: i } = e;
  const a = ls();
  let { i18n: s } = e, { eta: r = null } = e, { queue_position: u } = e, { queue_size: _ } = e, { status: d } = e, { scroll_to_output: c = !1 } = e, { timer: h = !0 } = e, { show_progress: m = "full" } = e, { message: p = null } = e, { progress: b = null } = e, { variant: k = "default" } = e, { loading_text: g = "Loading..." } = e, { absolute: f = !0 } = e, { translucent: v = !1 } = e, { border: D = !1 } = e, { autoscroll: w } = e, F, A = !1, y = 0, T = 0, E = null, L = null, B = 0, $ = null, ue, he = null, lt = !0;
  const K = () => {
    t(0, r = t(27, E = t(19, C = null))), t(25, y = performance.now()), t(26, T = 0), A = !0, _e();
  };
  function _e() {
    oo(() => {
      t(26, T = (performance.now() - y) / 1e3), A && _e();
    });
  }
  function ze() {
    t(26, T = 0), t(0, r = t(27, E = t(19, C = null))), A && (A = !1);
  }
  is(() => {
    A && ze();
  });
  let C = null;
  function ie(S) {
    wi[S ? "unshift" : "push"](() => {
      he = S, t(16, he), t(7, b), t(14, $), t(15, ue);
    });
  }
  const vt = () => {
    a("clear_status");
  };
  function ge(S) {
    wi[S ? "unshift" : "push"](() => {
      F = S, t(13, F);
    });
  }
  return o.$$set = (S) => {
    "i18n" in S && t(1, s = S.i18n), "eta" in S && t(0, r = S.eta), "queue_position" in S && t(2, u = S.queue_position), "queue_size" in S && t(3, _ = S.queue_size), "status" in S && t(4, d = S.status), "scroll_to_output" in S && t(22, c = S.scroll_to_output), "timer" in S && t(5, h = S.timer), "show_progress" in S && t(6, m = S.show_progress), "message" in S && t(23, p = S.message), "progress" in S && t(7, b = S.progress), "variant" in S && t(8, k = S.variant), "loading_text" in S && t(9, g = S.loading_text), "absolute" in S && t(10, f = S.absolute), "translucent" in S && t(11, v = S.translucent), "border" in S && t(12, D = S.border), "autoscroll" in S && t(24, w = S.autoscroll), "$$scope" in S && t(29, i = S.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (r === null && t(0, r = E), r != null && E !== r && (t(28, L = (performance.now() - y) / 1e3 + r), t(19, C = L.toFixed(1)), t(27, E = r))), o.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, B = L === null || L <= 0 || !T ? null : Math.min(T / L, 1)), o.$$.dirty[0] & /*progress*/
    128 && b != null && t(18, lt = !1), o.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (b != null ? t(14, $ = b.map((S) => {
      if (S.index != null && S.length != null)
        return S.index / S.length;
      if (S.progress != null)
        return S.progress;
    })) : t(14, $ = null), $ ? (t(15, ue = $[$.length - 1]), he && (ue === 0 ? t(16, he.style.transition = "0", he) : t(16, he.style.transition = "150ms", he))) : t(15, ue = void 0)), o.$$.dirty[0] & /*status*/
    16 && (d === "pending" ? K() : ze()), o.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && F && c && (d === "pending" || d === "complete") && Ds(F, w), o.$$.dirty[0] & /*status, message*/
    8388624, o.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = T.toFixed(1));
  }, [
    r,
    s,
    u,
    _,
    d,
    h,
    m,
    b,
    k,
    g,
    f,
    v,
    D,
    F,
    $,
    ue,
    he,
    B,
    lt,
    C,
    n,
    a,
    c,
    p,
    w,
    y,
    T,
    E,
    L,
    i,
    l,
    ie,
    vt,
    ge
  ];
}
class ws extends Ja {
  constructor(e) {
    super(), es(
      this,
      e,
      ys,
      gs,
      ts,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: g$,
  SvelteComponent: v$,
  add_render_callback: b$,
  append_hydration: D$,
  attr: y$,
  bubble: w$,
  check_outros: k$,
  children: F$,
  claim_component: $$,
  claim_element: C$,
  claim_html_tag: E$,
  claim_space: A$,
  claim_text: S$,
  create_component: q$,
  create_in_transition: B$,
  create_out_transition: T$,
  destroy_component: z$,
  detach: I$,
  element: R$,
  get_svelte_dataset: L$,
  group_outros: O$,
  init: P$,
  insert_hydration: M$,
  listen: N$,
  mount_component: j$,
  run_all: V$,
  safe_not_equal: H$,
  set_data: G$,
  space: U$,
  stop_propagation: Z$,
  text: x$,
  toggle_class: X$,
  transition_in: Y$,
  transition_out: W$
} = window.__gradio__svelte__internal, { createEventDispatcher: K$, onMount: Q$ } = window.__gradio__svelte__internal, {
  SvelteComponent: J$,
  append_hydration: e3,
  attr: t3,
  bubble: n3,
  check_outros: i3,
  children: l3,
  claim_component: o3,
  claim_element: a3,
  claim_space: s3,
  create_animation: r3,
  create_component: u3,
  destroy_component: _3,
  detach: c3,
  element: d3,
  ensure_array_like: f3,
  fix_and_outro_and_destroy_block: h3,
  fix_position: p3,
  group_outros: m3,
  init: g3,
  insert_hydration: v3,
  mount_component: b3,
  noop: D3,
  safe_not_equal: y3,
  set_style: w3,
  space: k3,
  transition_in: F3,
  transition_out: $3,
  update_keyed_each: C3
} = window.__gradio__svelte__internal, {
  SvelteComponent: E3,
  attr: A3,
  children: S3,
  claim_element: q3,
  detach: B3,
  element: T3,
  empty: z3,
  init: I3,
  insert_hydration: R3,
  noop: L3,
  safe_not_equal: O3,
  set_style: P3
} = window.__gradio__svelte__internal, {
  SvelteComponent: ks,
  append_hydration: pe,
  attr: U,
  children: Qe,
  claim_element: Ne,
  claim_space: kt,
  claim_text: Ot,
  destroy_each: Fs,
  detach: J,
  element: je,
  empty: Pi,
  ensure_array_like: Mi,
  init: $s,
  insert_hydration: it,
  noop: Ni,
  safe_not_equal: Cs,
  set_data: Pt,
  set_style: at,
  space: Ft,
  src_url_equal: ji,
  text: Mt,
  toggle_class: Ce
} = window.__gradio__svelte__internal;
function Vi(o, e, t) {
  const n = o.slice();
  return n[22] = e[t], n;
}
function Hi(o) {
  var a;
  let e, t, n = (
    /*scroll_logo_path*/
    ((a = o[7]) == null ? void 0 : a.url) && Gi(o)
  ), l = Mi(
    /*display_items*/
    o[13]
  ), i = [];
  for (let s = 0; s < l.length; s += 1)
    i[s] = Zi(Vi(o, l, s));
  return {
    c() {
      e = je("div"), n && n.c(), t = Ft();
      for (let s = 0; s < i.length; s += 1)
        i[s].c();
      this.h();
    },
    l(s) {
      e = Ne(s, "DIV", { class: !0 });
      var r = Qe(e);
      n && n.l(r), t = kt(r);
      for (let u = 0; u < i.length; u += 1)
        i[u].l(r);
      r.forEach(J), this.h();
    },
    h() {
      U(e, "class", "credits-container svelte-1nrfbo6");
    },
    m(s, r) {
      it(s, e, r), n && n.m(e, null), pe(e, t);
      for (let u = 0; u < i.length; u += 1)
        i[u] && i[u].m(e, null);
    },
    p(s, r) {
      var u;
      if (/*scroll_logo_path*/
      (u = s[7]) != null && u.url ? n ? n.p(s, r) : (n = Gi(s), n.c(), n.m(e, t)) : n && (n.d(1), n = null), r & /*section_title_style, section_title_uppercase, display_items, swap_font_sizes_on_two_column, title_style, name_style, name_uppercase, title_uppercase, layout_style*/
      15484) {
        l = Mi(
          /*display_items*/
          s[13]
        );
        let _;
        for (_ = 0; _ < l.length; _ += 1) {
          const d = Vi(s, l, _);
          i[_] ? i[_].p(d, r) : (i[_] = Zi(d), i[_].c(), i[_].m(e, null));
        }
        for (; _ < i.length; _ += 1)
          i[_].d(1);
        i.length = l.length;
      }
    },
    d(s) {
      s && J(e), n && n.d(), Fs(i, s);
    }
  };
}
function Gi(o) {
  let e, t, n;
  return {
    c() {
      e = je("div"), t = je("img"), this.h();
    },
    l(l) {
      e = Ne(l, "DIV", { class: !0 });
      var i = Qe(e);
      t = Ne(i, "IMG", { src: !0, alt: !0, class: !0 }), i.forEach(J), this.h();
    },
    h() {
      ji(t.src, n = /*scroll_logo_path*/
      o[7].url) || U(t, "src", n), U(t, "alt", "Scrolling Logo"), U(t, "class", "svelte-1nrfbo6"), at(
        t,
        "height",
        /*scroll_logo_height*/
        o[8]
      ), U(e, "class", "scroll-logo-container svelte-1nrfbo6"), at(
        e,
        "height",
        /*scroll_logo_height*/
        o[8]
      );
    },
    m(l, i) {
      it(l, e, i), pe(e, t);
    },
    p(l, i) {
      i & /*scroll_logo_path*/
      128 && !ji(t.src, n = /*scroll_logo_path*/
      l[7].url) && U(t, "src", n), i & /*scroll_logo_height*/
      256 && at(
        t,
        "height",
        /*scroll_logo_height*/
        l[8]
      ), i & /*scroll_logo_height*/
      256 && at(
        e,
        "height",
        /*scroll_logo_height*/
        l[8]
      );
    },
    d(l) {
      l && J(e);
    }
  };
}
function Es(o) {
  let e, t, n = (
    /*item*/
    o[22].title + ""
  ), l, i, a, s, r = (
    /*item*/
    o[22].name && Ui(o)
  );
  return {
    c() {
      e = je("div"), t = je("h2"), l = Mt(n), a = Ft(), r && r.c(), s = Ft(), this.h();
    },
    l(u) {
      e = Ne(u, "DIV", { class: !0 });
      var _ = Qe(e);
      t = Ne(_, "H2", { style: !0, class: !0 });
      var d = Qe(t);
      l = Ot(d, n), d.forEach(J), a = kt(_), r && r.l(_), s = kt(_), _.forEach(J), this.h();
    },
    h() {
      U(t, "style", i = /*title_style*/
      o[12](
        /*item*/
        o[22].is_intro
      )), U(t, "class", "svelte-1nrfbo6"), Ce(
        t,
        "uppercase",
        /*title_uppercase*/
        o[3] && !/*item*/
        o[22].is_intro
      ), U(e, "class", "credit svelte-1nrfbo6"), Ce(
        e,
        "intro-block",
        /*item*/
        o[22].is_intro
      );
    },
    m(u, _) {
      it(u, e, _), pe(e, t), pe(t, l), pe(e, a), r && r.m(e, null), pe(e, s);
    },
    p(u, _) {
      _ & /*display_items*/
      8192 && n !== (n = /*item*/
      u[22].title + "") && Pt(l, n), _ & /*title_style, display_items*/
      12288 && i !== (i = /*title_style*/
      u[12](
        /*item*/
        u[22].is_intro
      )) && U(t, "style", i), _ & /*title_uppercase, display_items*/
      8200 && Ce(
        t,
        "uppercase",
        /*title_uppercase*/
        u[3] && !/*item*/
        u[22].is_intro
      ), /*item*/
      u[22].name ? r ? r.p(u, _) : (r = Ui(u), r.c(), r.m(e, s)) : r && (r.d(1), r = null), _ & /*display_items*/
      8192 && Ce(
        e,
        "intro-block",
        /*item*/
        u[22].is_intro
      );
    },
    d(u) {
      u && J(e), r && r.d();
    }
  };
}
function As(o) {
  let e, t, n = (
    /*item*/
    o[22].title + ""
  ), l, i, a, s, r = (
    /*item*/
    o[22].name + ""
  ), u, _, d;
  return {
    c() {
      e = je("div"), t = je("div"), l = Mt(n), a = Ft(), s = je("div"), u = Mt(r), d = Ft(), this.h();
    },
    l(c) {
      e = Ne(c, "DIV", { class: !0 });
      var h = Qe(e);
      t = Ne(h, "DIV", { class: !0, style: !0 });
      var m = Qe(t);
      l = Ot(m, n), m.forEach(J), a = kt(h), s = Ne(h, "DIV", { class: !0, style: !0 });
      var p = Qe(s);
      u = Ot(p, r), p.forEach(J), d = kt(h), h.forEach(J), this.h();
    },
    h() {
      U(t, "class", "title svelte-1nrfbo6"), U(t, "style", i = /*swap_font_sizes_on_two_column*/
      o[6] ? (
        /*name_style*/
        o[11](!1)
      ) : (
        /*title_style*/
        o[12](!1)
      )), Ce(
        t,
        "uppercase",
        /*title_uppercase*/
        o[3]
      ), U(s, "class", "name svelte-1nrfbo6"), U(s, "style", _ = /*swap_font_sizes_on_two_column*/
      o[6] ? (
        /*title_style*/
        o[12](!1)
      ) : (
        /*name_style*/
        o[11](!1)
      )), Ce(
        s,
        "uppercase",
        /*name_uppercase*/
        o[4]
      ), U(e, "class", "credit-two-column svelte-1nrfbo6");
    },
    m(c, h) {
      it(c, e, h), pe(e, t), pe(t, l), pe(e, a), pe(e, s), pe(s, u), pe(e, d);
    },
    p(c, h) {
      h & /*display_items*/
      8192 && n !== (n = /*item*/
      c[22].title + "") && Pt(l, n), h & /*swap_font_sizes_on_two_column, name_style, title_style*/
      6208 && i !== (i = /*swap_font_sizes_on_two_column*/
      c[6] ? (
        /*name_style*/
        c[11](!1)
      ) : (
        /*title_style*/
        c[12](!1)
      )) && U(t, "style", i), h & /*title_uppercase*/
      8 && Ce(
        t,
        "uppercase",
        /*title_uppercase*/
        c[3]
      ), h & /*display_items*/
      8192 && r !== (r = /*item*/
      c[22].name + "") && Pt(u, r), h & /*swap_font_sizes_on_two_column, title_style, name_style*/
      6208 && _ !== (_ = /*swap_font_sizes_on_two_column*/
      c[6] ? (
        /*title_style*/
        c[12](!1)
      ) : (
        /*name_style*/
        c[11](!1)
      )) && U(s, "style", _), h & /*name_uppercase*/
      16 && Ce(
        s,
        "uppercase",
        /*name_uppercase*/
        c[4]
      );
    },
    d(c) {
      c && J(e);
    }
  };
}
function Ss(o) {
  let e, t = (
    /*item*/
    o[22].section_title + ""
  ), n, l;
  return {
    c() {
      e = je("div"), n = Mt(t), l = Ft(), this.h();
    },
    l(i) {
      e = Ne(i, "DIV", { class: !0, style: !0 });
      var a = Qe(e);
      n = Ot(a, t), a.forEach(J), l = kt(i), this.h();
    },
    h() {
      U(e, "class", "section-title svelte-1nrfbo6"), U(
        e,
        "style",
        /*section_title_style*/
        o[10]
      ), Ce(
        e,
        "uppercase",
        /*section_title_uppercase*/
        o[5]
      );
    },
    m(i, a) {
      it(i, e, a), pe(e, n), it(i, l, a);
    },
    p(i, a) {
      a & /*display_items*/
      8192 && t !== (t = /*item*/
      i[22].section_title + "") && Pt(n, t), a & /*section_title_style*/
      1024 && U(
        e,
        "style",
        /*section_title_style*/
        i[10]
      ), a & /*section_title_uppercase*/
      32 && Ce(
        e,
        "uppercase",
        /*section_title_uppercase*/
        i[5]
      );
    },
    d(i) {
      i && (J(e), J(l));
    }
  };
}
function Ui(o) {
  let e, t = (
    /*item*/
    o[22].name + ""
  ), n, l;
  return {
    c() {
      e = je("p"), n = Mt(t), this.h();
    },
    l(i) {
      e = Ne(i, "P", { style: !0, class: !0 });
      var a = Qe(e);
      n = Ot(a, t), a.forEach(J), this.h();
    },
    h() {
      U(e, "style", l = /*name_style*/
      o[11](
        /*item*/
        o[22].is_intro
      )), U(e, "class", "svelte-1nrfbo6"), Ce(
        e,
        "uppercase",
        /*name_uppercase*/
        o[4] && !/*item*/
        o[22].is_intro
      );
    },
    m(i, a) {
      it(i, e, a), pe(e, n);
    },
    p(i, a) {
      a & /*display_items*/
      8192 && t !== (t = /*item*/
      i[22].name + "") && Pt(n, t), a & /*name_style, display_items*/
      10240 && l !== (l = /*name_style*/
      i[11](
        /*item*/
        i[22].is_intro
      )) && U(e, "style", l), a & /*name_uppercase, display_items*/
      8208 && Ce(
        e,
        "uppercase",
        /*name_uppercase*/
        i[4] && !/*item*/
        i[22].is_intro
      );
    },
    d(i) {
      i && J(e);
    }
  };
}
function Zi(o) {
  let e;
  function t(i, a) {
    return (
      /*item*/
      i[22].section_title ? Ss : (
        /*layout_style*/
        i[2] === "two-column" && !/*item*/
        i[22].is_intro ? As : Es
      )
    );
  }
  let n = t(o), l = n(o);
  return {
    c() {
      l.c(), e = Pi();
    },
    l(i) {
      l.l(i), e = Pi();
    },
    m(i, a) {
      l.m(i, a), it(i, e, a);
    },
    p(i, a) {
      n === (n = t(i)) && l ? l.p(i, a) : (l.d(1), l = n(i), l && (l.c(), l.m(e.parentNode, e)));
    },
    d(i) {
      i && J(e), l.d(i);
    }
  };
}
function qs(o) {
  let e, t = `${/*speed*/
  o[0]}s`, n = !/*reset*/
  o[9] && Hi(o);
  return {
    c() {
      e = je("div"), n && n.c(), this.h();
    },
    l(l) {
      e = Ne(l, "DIV", { class: !0 });
      var i = Qe(e);
      n && n.l(i), i.forEach(J), this.h();
    },
    h() {
      U(e, "class", "wrapper svelte-1nrfbo6"), at(e, "--animation-duration", t), at(
        e,
        "background",
        /*background_color*/
        o[1] || "black"
      );
    },
    m(l, i) {
      it(l, e, i), n && n.m(e, null);
    },
    p(l, [i]) {
      /*reset*/
      l[9] ? n && (n.d(1), n = null) : n ? n.p(l, i) : (n = Hi(l), n.c(), n.m(e, null)), i & /*speed*/
      1 && t !== (t = `${/*speed*/
      l[0]}s`) && at(e, "--animation-duration", t), i & /*background_color*/
      2 && at(
        e,
        "background",
        /*background_color*/
        l[1] || "black"
      );
    },
    i: Ni,
    o: Ni,
    d(l) {
      l && J(e), n && n.d();
    }
  };
}
function Bs(o, e, t) {
  let n, l, i, a, { credits: s } = e, { speed: r } = e, { base_font_size: u = 1.5 } = e, { background_color: _ = null } = e, { title_color: d = null } = e, { scroll_section_title_color: c = null } = e, { name_color: h = null } = e, { intro_title: m = null } = e, { intro_subtitle: p = null } = e, { layout_style: b = "stacked" } = e, { title_uppercase: k = !1 } = e, { name_uppercase: g = !1 } = e, { section_title_uppercase: f = !0 } = e, { swap_font_sizes_on_two_column: v = !1 } = e, { scroll_logo_path: D = null } = e, { scroll_logo_height: w = "120px" } = e, F = !1;
  function A() {
    t(9, F = !0), setTimeout(() => t(9, F = !1), 0);
  }
  return o.$$set = (y) => {
    "credits" in y && t(14, s = y.credits), "speed" in y && t(0, r = y.speed), "base_font_size" in y && t(15, u = y.base_font_size), "background_color" in y && t(1, _ = y.background_color), "title_color" in y && t(16, d = y.title_color), "scroll_section_title_color" in y && t(17, c = y.scroll_section_title_color), "name_color" in y && t(18, h = y.name_color), "intro_title" in y && t(19, m = y.intro_title), "intro_subtitle" in y && t(20, p = y.intro_subtitle), "layout_style" in y && t(2, b = y.layout_style), "title_uppercase" in y && t(3, k = y.title_uppercase), "name_uppercase" in y && t(4, g = y.name_uppercase), "section_title_uppercase" in y && t(5, f = y.section_title_uppercase), "swap_font_sizes_on_two_column" in y && t(6, v = y.swap_font_sizes_on_two_column), "scroll_logo_path" in y && t(7, D = y.scroll_logo_path), "scroll_logo_height" in y && t(8, w = y.scroll_logo_height);
  }, o.$$.update = () => {
    o.$$.dirty & /*intro_title, intro_subtitle, credits*/
    1589248 && t(13, n = (() => {
      const y = [];
      return (m || p) && y.push({
        title: m || "",
        name: p || "",
        is_intro: !0
      }), [
        ...y,
        ...s.map((T) => Object.assign(Object.assign({}, T), { is_intro: !1 }))
      ];
    })()), o.$$.dirty & /*title_color, base_font_size*/
    98304 && t(12, l = (y) => `color: ${d || "white"}; font-size: ${y ? u * 1.5 : u}rem;`), o.$$.dirty & /*name_color, base_font_size*/
    294912 && t(11, i = (y) => `color: ${h || "white"}; font-size: ${y ? u * 0.9 : u * 0.8}rem;`), o.$$.dirty & /*scroll_section_title_color, title_color, base_font_size*/
    229376 && t(10, a = `color: ${c || d || "white"}; font-size: ${u * 1.2}rem;`), o.$$.dirty & /*credits, speed*/
    16385 && A();
  }, [
    r,
    _,
    b,
    k,
    g,
    f,
    v,
    D,
    w,
    F,
    a,
    i,
    l,
    n,
    s,
    u,
    d,
    c,
    h,
    m,
    p
  ];
}
class Ts extends ks {
  constructor(e) {
    super(), $s(this, e, Bs, qs, Cs, {
      credits: 14,
      speed: 0,
      base_font_size: 15,
      background_color: 1,
      title_color: 16,
      scroll_section_title_color: 17,
      name_color: 18,
      intro_title: 19,
      intro_subtitle: 20,
      layout_style: 2,
      title_uppercase: 3,
      name_uppercase: 4,
      section_title_uppercase: 5,
      swap_font_sizes_on_two_column: 6,
      scroll_logo_path: 7,
      scroll_logo_height: 8
    });
  }
}
const {
  SvelteComponent: zs,
  append_hydration: Z,
  attr: P,
  binding_callbacks: Is,
  children: me,
  claim_element: ce,
  claim_space: We,
  claim_text: Nt,
  destroy_each: Rs,
  detach: W,
  element: de,
  empty: xi,
  ensure_array_like: Xi,
  init: Ls,
  insert_hydration: st,
  noop: Yi,
  safe_not_equal: Os,
  set_data: jt,
  set_style: et,
  space: Ke,
  src_url_equal: Wi,
  text: Vt,
  toggle_class: Ee
} = window.__gradio__svelte__internal, { onMount: Ps, onDestroy: Ms } = window.__gradio__svelte__internal;
function Ki(o, e, t) {
  const n = o.slice();
  return n[26] = e[t], n;
}
function Qi(o) {
  let e, t, n;
  return {
    c() {
      e = de("div"), t = de("img"), this.h();
    },
    l(l) {
      e = ce(l, "DIV", { class: !0 });
      var i = me(e);
      t = ce(i, "IMG", { src: !0, alt: !0, class: !0 }), i.forEach(W), this.h();
    },
    h() {
      Wi(t.src, n = /*scroll_logo_path*/
      o[7].url) || P(t, "src", n), P(t, "alt", "Scrolling Logo"), P(t, "class", "svelte-1hia40q"), et(
        t,
        "height",
        /*scroll_logo_height*/
        o[8]
      ), P(e, "class", "scroll-logo-container svelte-1hia40q");
    },
    m(l, i) {
      st(l, e, i), Z(e, t);
    },
    p(l, i) {
      i & /*scroll_logo_path*/
      128 && !Wi(t.src, n = /*scroll_logo_path*/
      l[7].url) && P(t, "src", n), i & /*scroll_logo_height*/
      256 && et(
        t,
        "height",
        /*scroll_logo_height*/
        l[8]
      );
    },
    d(l) {
      l && W(e);
    }
  };
}
function Ns(o) {
  let e, t, n = (
    /*item*/
    o[26].title + ""
  ), l, i, a, s, r = (
    /*item*/
    o[26].name && Ji(o)
  );
  return {
    c() {
      e = de("div"), t = de("h2"), l = Vt(n), a = Ke(), r && r.c(), s = Ke(), this.h();
    },
    l(u) {
      e = ce(u, "DIV", { class: !0 });
      var _ = me(e);
      t = ce(_, "H2", { style: !0, class: !0 });
      var d = me(t);
      l = Nt(d, n), d.forEach(W), a = We(_), r && r.l(_), s = We(_), _.forEach(W), this.h();
    },
    h() {
      P(t, "style", i = /*title_style*/
      o[13](
        /*item*/
        o[26].is_intro
      )), P(t, "class", "svelte-1hia40q"), Ee(
        t,
        "uppercase",
        /*title_uppercase*/
        o[3] && !/*item*/
        o[26].is_intro
      ), P(e, "class", "credit svelte-1hia40q"), Ee(
        e,
        "intro-block",
        /*item*/
        o[26].is_intro
      );
    },
    m(u, _) {
      st(u, e, _), Z(e, t), Z(t, l), Z(e, a), r && r.m(e, null), Z(e, s);
    },
    p(u, _) {
      _ & /*display_items*/
      1024 && n !== (n = /*item*/
      u[26].title + "") && jt(l, n), _ & /*title_style, display_items*/
      9216 && i !== (i = /*title_style*/
      u[13](
        /*item*/
        u[26].is_intro
      )) && P(t, "style", i), _ & /*title_uppercase, display_items*/
      1032 && Ee(
        t,
        "uppercase",
        /*title_uppercase*/
        u[3] && !/*item*/
        u[26].is_intro
      ), /*item*/
      u[26].name ? r ? r.p(u, _) : (r = Ji(u), r.c(), r.m(e, s)) : r && (r.d(1), r = null), _ & /*display_items*/
      1024 && Ee(
        e,
        "intro-block",
        /*item*/
        u[26].is_intro
      );
    },
    d(u) {
      u && W(e), r && r.d();
    }
  };
}
function js(o) {
  let e, t, n = (
    /*item*/
    o[26].title + ""
  ), l, i, a, s, r, u, _ = (
    /*item*/
    o[26].name + ""
  ), d, c, h;
  return {
    c() {
      e = de("div"), t = de("span"), l = Vt(n), a = Ke(), s = de("span"), r = Ke(), u = de("span"), d = Vt(_), h = Ke(), this.h();
    },
    l(m) {
      e = ce(m, "DIV", { class: !0 });
      var p = me(e);
      t = ce(p, "SPAN", { style: !0, class: !0 });
      var b = me(t);
      l = Nt(b, n), b.forEach(W), a = We(p), s = ce(p, "SPAN", { class: !0 }), me(s).forEach(W), r = We(p), u = ce(p, "SPAN", { style: !0, class: !0 });
      var k = me(u);
      d = Nt(k, _), k.forEach(W), h = We(p), p.forEach(W), this.h();
    },
    h() {
      P(t, "style", i = /*swap_font_sizes_on_two_column*/
      o[6] ? (
        /*name_style*/
        o[12](!1)
      ) : (
        /*title_style*/
        o[13](!1)
      )), P(t, "class", "svelte-1hia40q"), Ee(
        t,
        "uppercase",
        /*title_uppercase*/
        o[3]
      ), P(s, "class", "spacer svelte-1hia40q"), P(u, "style", c = /*swap_font_sizes_on_two_column*/
      o[6] ? (
        /*title_style*/
        o[13](!1)
      ) : (
        /*name_style*/
        o[12](!1)
      )), P(u, "class", "svelte-1hia40q"), Ee(
        u,
        "uppercase",
        /*name_uppercase*/
        o[4]
      ), P(e, "class", "credit-two-column svelte-1hia40q");
    },
    m(m, p) {
      st(m, e, p), Z(e, t), Z(t, l), Z(e, a), Z(e, s), Z(e, r), Z(e, u), Z(u, d), Z(e, h);
    },
    p(m, p) {
      p & /*display_items*/
      1024 && n !== (n = /*item*/
      m[26].title + "") && jt(l, n), p & /*swap_font_sizes_on_two_column, name_style, title_style*/
      12352 && i !== (i = /*swap_font_sizes_on_two_column*/
      m[6] ? (
        /*name_style*/
        m[12](!1)
      ) : (
        /*title_style*/
        m[13](!1)
      )) && P(t, "style", i), p & /*title_uppercase*/
      8 && Ee(
        t,
        "uppercase",
        /*title_uppercase*/
        m[3]
      ), p & /*display_items*/
      1024 && _ !== (_ = /*item*/
      m[26].name + "") && jt(d, _), p & /*swap_font_sizes_on_two_column, title_style, name_style*/
      12352 && c !== (c = /*swap_font_sizes_on_two_column*/
      m[6] ? (
        /*title_style*/
        m[13](!1)
      ) : (
        /*name_style*/
        m[12](!1)
      )) && P(u, "style", c), p & /*name_uppercase*/
      16 && Ee(
        u,
        "uppercase",
        /*name_uppercase*/
        m[4]
      );
    },
    d(m) {
      m && W(e);
    }
  };
}
function Vs(o) {
  let e, t = (
    /*item*/
    o[26].section_title + ""
  ), n, l;
  return {
    c() {
      e = de("div"), n = Vt(t), l = Ke(), this.h();
    },
    l(i) {
      e = ce(i, "DIV", { class: !0, style: !0 });
      var a = me(e);
      n = Nt(a, t), a.forEach(W), l = We(i), this.h();
    },
    h() {
      P(e, "class", "section-title svelte-1hia40q"), P(
        e,
        "style",
        /*section_title_style*/
        o[11]
      ), Ee(
        e,
        "uppercase",
        /*section_title_uppercase*/
        o[5]
      );
    },
    m(i, a) {
      st(i, e, a), Z(e, n), st(i, l, a);
    },
    p(i, a) {
      a & /*display_items*/
      1024 && t !== (t = /*item*/
      i[26].section_title + "") && jt(n, t), a & /*section_title_style*/
      2048 && P(
        e,
        "style",
        /*section_title_style*/
        i[11]
      ), a & /*section_title_uppercase*/
      32 && Ee(
        e,
        "uppercase",
        /*section_title_uppercase*/
        i[5]
      );
    },
    d(i) {
      i && (W(e), W(l));
    }
  };
}
function Ji(o) {
  let e, t = (
    /*item*/
    o[26].name + ""
  ), n, l;
  return {
    c() {
      e = de("p"), n = Vt(t), this.h();
    },
    l(i) {
      e = ce(i, "P", { style: !0, class: !0 });
      var a = me(e);
      n = Nt(a, t), a.forEach(W), this.h();
    },
    h() {
      P(e, "style", l = /*name_style*/
      o[12](
        /*item*/
        o[26].is_intro
      )), P(e, "class", "svelte-1hia40q"), Ee(
        e,
        "uppercase",
        /*name_uppercase*/
        o[4] && !/*item*/
        o[26].is_intro
      );
    },
    m(i, a) {
      st(i, e, a), Z(e, n);
    },
    p(i, a) {
      a & /*display_items*/
      1024 && t !== (t = /*item*/
      i[26].name + "") && jt(n, t), a & /*name_style, display_items*/
      5120 && l !== (l = /*name_style*/
      i[12](
        /*item*/
        i[26].is_intro
      )) && P(e, "style", l), a & /*name_uppercase, display_items*/
      1040 && Ee(
        e,
        "uppercase",
        /*name_uppercase*/
        i[4] && !/*item*/
        i[26].is_intro
      );
    },
    d(i) {
      i && W(e);
    }
  };
}
function el(o) {
  let e;
  function t(i, a) {
    return (
      /*item*/
      i[26].section_title ? Vs : (
        /*layout_style*/
        i[2] === "two-column" && !/*item*/
        i[26].is_intro ? js : Ns
      )
    );
  }
  let n = t(o), l = n(o);
  return {
    c() {
      l.c(), e = xi();
    },
    l(i) {
      l.l(i), e = xi();
    },
    m(i, a) {
      l.m(i, a), st(i, e, a);
    },
    p(i, a) {
      n === (n = t(i)) && l ? l.p(i, a) : (l.d(1), l = n(i), l && (l.c(), l.m(e.parentNode, e)));
    },
    d(i) {
      i && W(e), l.d(i);
    }
  };
}
function Hs(o) {
  var h;
  let e, t, n, l, i, a, s, r, u, _ = (
    /*scroll_logo_path*/
    ((h = o[7]) == null ? void 0 : h.url) && Qi(o)
  ), d = Xi(
    /*display_items*/
    o[10]
  ), c = [];
  for (let m = 0; m < d.length; m += 1)
    c[m] = el(Ki(o, d, m));
  return {
    c() {
      e = de("div"), t = de("div"), n = Ke(), l = de("div"), i = Ke(), a = de("div"), s = Ke(), r = de("div"), _ && _.c(), u = Ke();
      for (let m = 0; m < c.length; m += 1)
        c[m].c();
      this.h();
    },
    l(m) {
      e = ce(m, "DIV", { class: !0 });
      var p = me(e);
      t = ce(p, "DIV", { class: !0, style: !0 }), me(t).forEach(W), n = We(p), l = ce(p, "DIV", { class: !0, style: !0 }), me(l).forEach(W), i = We(p), a = ce(p, "DIV", { class: !0, style: !0 }), me(a).forEach(W), s = We(p), r = ce(p, "DIV", { class: !0, style: !0 });
      var b = me(r);
      _ && _.l(b), u = We(b);
      for (let k = 0; k < c.length; k += 1)
        c[k].l(b);
      b.forEach(W), p.forEach(W), this.h();
    },
    h() {
      P(t, "class", "stars small svelte-1hia40q"), et(
        t,
        "box-shadow",
        /*small_stars*/
        o[14]
      ), P(l, "class", "stars medium svelte-1hia40q"), et(
        l,
        "box-shadow",
        /*medium_stars*/
        o[15]
      ), P(a, "class", "stars large svelte-1hia40q"), et(
        a,
        "box-shadow",
        /*large_stars*/
        o[16]
      ), P(r, "class", "crawl svelte-1hia40q"), et(
        r,
        "--animation-duration",
        /*speed*/
        o[0] + "s"
      ), P(e, "class", "viewport svelte-1hia40q"), et(
        e,
        "background",
        /*background_color*/
        o[1] || "black"
      );
    },
    m(m, p) {
      st(m, e, p), Z(e, t), Z(e, n), Z(e, l), Z(e, i), Z(e, a), Z(e, s), Z(e, r), _ && _.m(r, null), Z(r, u);
      for (let b = 0; b < c.length; b += 1)
        c[b] && c[b].m(r, null);
      o[23](r);
    },
    p(m, [p]) {
      var b;
      if (/*scroll_logo_path*/
      (b = m[7]) != null && b.url ? _ ? _.p(m, p) : (_ = Qi(m), _.c(), _.m(r, u)) : _ && (_.d(1), _ = null), p & /*section_title_style, section_title_uppercase, display_items, swap_font_sizes_on_two_column, title_style, name_style, name_uppercase, title_uppercase, layout_style*/
      15484) {
        d = Xi(
          /*display_items*/
          m[10]
        );
        let k;
        for (k = 0; k < d.length; k += 1) {
          const g = Ki(m, d, k);
          c[k] ? c[k].p(g, p) : (c[k] = el(g), c[k].c(), c[k].m(r, null));
        }
        for (; k < c.length; k += 1)
          c[k].d(1);
        c.length = d.length;
      }
      p & /*speed*/
      1 && et(
        r,
        "--animation-duration",
        /*speed*/
        m[0] + "s"
      ), p & /*background_color*/
      2 && et(
        e,
        "background",
        /*background_color*/
        m[1] || "black"
      );
    },
    i: Yi,
    o: Yi,
    d(m) {
      m && W(e), _ && _.d(), Rs(c, m), o[23](null);
    }
  };
}
function Gs(o, e, t) {
  let n, l, i, a, { credits: s } = e, { speed: r = 40 } = e, { base_font_size: u = 1.5 } = e, { background_color: _ = null } = e, { title_color: d = null } = e, { name_color: c = null } = e, { intro_title: h = null } = e, { intro_subtitle: m = null } = e, { layout_style: p = "stacked" } = e, { title_uppercase: b = !1 } = e, { name_uppercase: k = !1 } = e, { section_title_uppercase: g = !0 } = e, { swap_font_sizes_on_two_column: f = !1 } = e, { scroll_logo_path: v = null } = e, { scroll_logo_height: D = "120px" } = e, w;
  function F() {
    w && (t(9, w.style.animation = "none", w), w.offsetHeight, t(9, w.style.animation = "", w));
  }
  Ps(F), Ms(() => {
    t(9, w = null);
  });
  const A = (B, $) => Array.from({ length: B }, () => `${Math.random() * 2e3}px ${Math.random() * 2e3}px ${$} white`).join(", "), y = A(200, "1px"), T = A(100, "2px"), E = A(50, "3px");
  function L(B) {
    Is[B ? "unshift" : "push"](() => {
      w = B, t(9, w);
    });
  }
  return o.$$set = (B) => {
    "credits" in B && t(17, s = B.credits), "speed" in B && t(0, r = B.speed), "base_font_size" in B && t(18, u = B.base_font_size), "background_color" in B && t(1, _ = B.background_color), "title_color" in B && t(19, d = B.title_color), "name_color" in B && t(20, c = B.name_color), "intro_title" in B && t(21, h = B.intro_title), "intro_subtitle" in B && t(22, m = B.intro_subtitle), "layout_style" in B && t(2, p = B.layout_style), "title_uppercase" in B && t(3, b = B.title_uppercase), "name_uppercase" in B && t(4, k = B.name_uppercase), "section_title_uppercase" in B && t(5, g = B.section_title_uppercase), "swap_font_sizes_on_two_column" in B && t(6, f = B.swap_font_sizes_on_two_column), "scroll_logo_path" in B && t(7, v = B.scroll_logo_path), "scroll_logo_height" in B && t(8, D = B.scroll_logo_height);
  }, o.$$.update = () => {
    o.$$.dirty & /*title_color, base_font_size*/
    786432 && t(13, n = (B) => `color: ${d || "#feda4a"}; font-size: ${B ? u * 1.5 : u}rem;`), o.$$.dirty & /*name_color, base_font_size*/
    1310720 && t(12, l = (B) => `color: ${c || "#feda4a"}; font-size: ${B ? u * 0.9 : u * 0.7}rem;`), o.$$.dirty & /*title_color, base_font_size*/
    786432 && t(11, i = `color: ${d || "#feda4a"}; font-size: ${u * 1.2}rem;`), o.$$.dirty & /*intro_title, intro_subtitle, credits*/
    6422528 && t(10, a = (() => {
      const B = [];
      return (h || m) && B.push({
        title: h || "",
        name: m || "",
        is_intro: !0
      }), [
        ...B,
        ...s.map(($) => Object.assign(Object.assign({}, $), { is_intro: !1 }))
      ];
    })()), o.$$.dirty & /*credits, speed, layout_style*/
    131077 && F();
  }, [
    r,
    _,
    p,
    b,
    k,
    g,
    f,
    v,
    D,
    w,
    a,
    i,
    l,
    n,
    y,
    T,
    E,
    s,
    u,
    d,
    c,
    h,
    m,
    L
  ];
}
class Us extends zs {
  constructor(e) {
    super(), Ls(this, e, Gs, Hs, Os, {
      credits: 17,
      speed: 0,
      base_font_size: 18,
      background_color: 1,
      title_color: 19,
      name_color: 20,
      intro_title: 21,
      intro_subtitle: 22,
      layout_style: 2,
      title_uppercase: 3,
      name_uppercase: 4,
      section_title_uppercase: 5,
      swap_font_sizes_on_two_column: 6,
      scroll_logo_path: 7,
      scroll_logo_height: 8
    });
  }
}
const {
  SvelteComponent: Zs,
  append_hydration: te,
  attr: j,
  binding_callbacks: tl,
  children: Ae,
  claim_element: De,
  claim_space: ht,
  claim_text: Ht,
  destroy_each: xs,
  detach: Q,
  element: ye,
  empty: nl,
  ensure_array_like: il,
  init: Xs,
  insert_hydration: rt,
  noop: ll,
  safe_not_equal: Ys,
  set_data: Gt,
  set_style: hn,
  space: pt,
  src_url_equal: ol,
  text: Ut,
  toggle_class: Se
} = window.__gradio__svelte__internal, { onMount: Ws, onDestroy: Ks } = window.__gradio__svelte__internal;
function al(o, e, t) {
  const n = o.slice();
  return n[27] = e[t], n;
}
function sl(o) {
  let e, t, n;
  return {
    c() {
      e = ye("div"), t = ye("img"), this.h();
    },
    l(l) {
      e = De(l, "DIV", { class: !0 });
      var i = Ae(e);
      t = De(i, "IMG", { src: !0, alt: !0, class: !0 }), i.forEach(Q), this.h();
    },
    h() {
      ol(t.src, n = /*scroll_logo_path*/
      o[6].url) || j(t, "src", n), j(t, "alt", "Scrolling Logo"), j(t, "class", "svelte-1bt5wt2"), hn(
        t,
        "height",
        /*scroll_logo_height*/
        o[7]
      ), j(e, "class", "scroll-logo-container svelte-1bt5wt2");
    },
    m(l, i) {
      rt(l, e, i), te(e, t);
    },
    p(l, i) {
      i & /*scroll_logo_path*/
      64 && !ol(t.src, n = /*scroll_logo_path*/
      l[6].url) && j(t, "src", n), i & /*scroll_logo_height*/
      128 && hn(
        t,
        "height",
        /*scroll_logo_height*/
        l[7]
      );
    },
    d(l) {
      l && Q(e);
    }
  };
}
function Qs(o) {
  let e, t, n = (
    /*item*/
    o[27].title + ""
  ), l, i, a, s, r = (
    /*item*/
    o[27].name && rl(o)
  );
  return {
    c() {
      e = ye("div"), t = ye("div"), l = Ut(n), a = pt(), r && r.c(), s = pt(), this.h();
    },
    l(u) {
      e = De(u, "DIV", { class: !0 });
      var _ = Ae(e);
      t = De(_, "DIV", { style: !0, class: !0 });
      var d = Ae(t);
      l = Ht(d, n), d.forEach(Q), a = ht(_), r && r.l(_), s = ht(_), _.forEach(Q), this.h();
    },
    h() {
      j(t, "style", i = /*title_style*/
      o[12](
        /*item*/
        o[27].is_intro
      )), j(t, "class", "title svelte-1bt5wt2"), Se(
        t,
        "uppercase",
        /*title_uppercase*/
        o[2] && !/*item*/
        o[27].is_intro
      ), j(e, "class", "credit-block svelte-1bt5wt2"), Se(
        e,
        "intro-block",
        /*item*/
        o[27].is_intro
      );
    },
    m(u, _) {
      rt(u, e, _), te(e, t), te(t, l), te(e, a), r && r.m(e, null), te(e, s);
    },
    p(u, _) {
      _ & /*display_items*/
      8192 && n !== (n = /*item*/
      u[27].title + "") && Gt(l, n), _ & /*title_style, display_items*/
      12288 && i !== (i = /*title_style*/
      u[12](
        /*item*/
        u[27].is_intro
      )) && j(t, "style", i), _ & /*title_uppercase, display_items*/
      8196 && Se(
        t,
        "uppercase",
        /*title_uppercase*/
        u[2] && !/*item*/
        u[27].is_intro
      ), /*item*/
      u[27].name ? r ? r.p(u, _) : (r = rl(u), r.c(), r.m(e, s)) : r && (r.d(1), r = null), _ & /*display_items*/
      8192 && Se(
        e,
        "intro-block",
        /*item*/
        u[27].is_intro
      );
    },
    d(u) {
      u && Q(e), r && r.d();
    }
  };
}
function Js(o) {
  let e, t, n = (
    /*item*/
    o[27].title + ""
  ), l, i, a, s, r = (
    /*item*/
    o[27].name + ""
  ), u, _, d;
  return {
    c() {
      e = ye("div"), t = ye("div"), l = Ut(n), a = pt(), s = ye("div"), u = Ut(r), d = pt(), this.h();
    },
    l(c) {
      e = De(c, "DIV", { class: !0 });
      var h = Ae(e);
      t = De(h, "DIV", { class: !0, style: !0 });
      var m = Ae(t);
      l = Ht(m, n), m.forEach(Q), a = ht(h), s = De(h, "DIV", { class: !0, style: !0 });
      var p = Ae(s);
      u = Ht(p, r), p.forEach(Q), d = ht(h), h.forEach(Q), this.h();
    },
    h() {
      j(t, "class", "title svelte-1bt5wt2"), j(t, "style", i = /*swap_font_sizes_on_two_column*/
      o[5] ? (
        /*name_style*/
        o[11](!1)
      ) : (
        /*title_style*/
        o[12](!1)
      )), Se(
        t,
        "uppercase",
        /*title_uppercase*/
        o[2]
      ), j(s, "class", "name svelte-1bt5wt2"), j(s, "style", _ = /*swap_font_sizes_on_two_column*/
      o[5] ? (
        /*title_style*/
        o[12](!1)
      ) : (
        /*name_style*/
        o[11](!1)
      )), Se(
        s,
        "uppercase",
        /*name_uppercase*/
        o[3]
      ), j(e, "class", "credit-two-column svelte-1bt5wt2");
    },
    m(c, h) {
      rt(c, e, h), te(e, t), te(t, l), te(e, a), te(e, s), te(s, u), te(e, d);
    },
    p(c, h) {
      h & /*display_items*/
      8192 && n !== (n = /*item*/
      c[27].title + "") && Gt(l, n), h & /*swap_font_sizes_on_two_column, name_style, title_style*/
      6176 && i !== (i = /*swap_font_sizes_on_two_column*/
      c[5] ? (
        /*name_style*/
        c[11](!1)
      ) : (
        /*title_style*/
        c[12](!1)
      )) && j(t, "style", i), h & /*title_uppercase*/
      4 && Se(
        t,
        "uppercase",
        /*title_uppercase*/
        c[2]
      ), h & /*display_items*/
      8192 && r !== (r = /*item*/
      c[27].name + "") && Gt(u, r), h & /*swap_font_sizes_on_two_column, title_style, name_style*/
      6176 && _ !== (_ = /*swap_font_sizes_on_two_column*/
      c[5] ? (
        /*title_style*/
        c[12](!1)
      ) : (
        /*name_style*/
        c[11](!1)
      )) && j(s, "style", _), h & /*name_uppercase*/
      8 && Se(
        s,
        "uppercase",
        /*name_uppercase*/
        c[3]
      );
    },
    d(c) {
      c && Q(e);
    }
  };
}
function er(o) {
  let e, t = (
    /*item*/
    o[27].section_title + ""
  ), n, l;
  return {
    c() {
      e = ye("div"), n = Ut(t), l = pt(), this.h();
    },
    l(i) {
      e = De(i, "DIV", { class: !0, style: !0 });
      var a = Ae(e);
      n = Ht(a, t), a.forEach(Q), l = ht(i), this.h();
    },
    h() {
      j(e, "class", "section-title svelte-1bt5wt2"), j(
        e,
        "style",
        /*section_title_style*/
        o[10]
      ), Se(
        e,
        "uppercase",
        /*section_title_uppercase*/
        o[4]
      );
    },
    m(i, a) {
      rt(i, e, a), te(e, n), rt(i, l, a);
    },
    p(i, a) {
      a & /*display_items*/
      8192 && t !== (t = /*item*/
      i[27].section_title + "") && Gt(n, t), a & /*section_title_style*/
      1024 && j(
        e,
        "style",
        /*section_title_style*/
        i[10]
      ), a & /*section_title_uppercase*/
      16 && Se(
        e,
        "uppercase",
        /*section_title_uppercase*/
        i[4]
      );
    },
    d(i) {
      i && (Q(e), Q(l));
    }
  };
}
function rl(o) {
  let e, t = (
    /*item*/
    o[27].name + ""
  ), n, l;
  return {
    c() {
      e = ye("div"), n = Ut(t), this.h();
    },
    l(i) {
      e = De(i, "DIV", { style: !0, class: !0 });
      var a = Ae(e);
      n = Ht(a, t), a.forEach(Q), this.h();
    },
    h() {
      j(e, "style", l = /*name_style*/
      o[11](
        /*item*/
        o[27].is_intro
      )), j(e, "class", "name svelte-1bt5wt2"), Se(
        e,
        "uppercase",
        /*name_uppercase*/
        o[3] && !/*item*/
        o[27].is_intro
      );
    },
    m(i, a) {
      rt(i, e, a), te(e, n);
    },
    p(i, a) {
      a & /*display_items*/
      8192 && t !== (t = /*item*/
      i[27].name + "") && Gt(n, t), a & /*name_style, display_items*/
      10240 && l !== (l = /*name_style*/
      i[11](
        /*item*/
        i[27].is_intro
      )) && j(e, "style", l), a & /*name_uppercase, display_items*/
      8200 && Se(
        e,
        "uppercase",
        /*name_uppercase*/
        i[3] && !/*item*/
        i[27].is_intro
      );
    },
    d(i) {
      i && Q(e);
    }
  };
}
function ul(o) {
  let e;
  function t(i, a) {
    return (
      /*item*/
      i[27].section_title ? er : (
        /*layout_style*/
        i[1] === "two-column" && !/*item*/
        i[27].is_intro ? Js : Qs
      )
    );
  }
  let n = t(o), l = n(o);
  return {
    c() {
      l.c(), e = nl();
    },
    l(i) {
      l.l(i), e = nl();
    },
    m(i, a) {
      l.m(i, a), rt(i, e, a);
    },
    p(i, a) {
      n === (n = t(i)) && l ? l.p(i, a) : (l.d(1), l = n(i), l && (l.c(), l.m(e.parentNode, e)));
    },
    d(i) {
      i && Q(e), l.d(i);
    }
  };
}
function tr(o) {
  var _;
  let e, t, n, l, i, a, s = (
    /*scroll_logo_path*/
    ((_ = o[6]) == null ? void 0 : _.url) && sl(o)
  ), r = il(
    /*display_items*/
    o[13]
  ), u = [];
  for (let d = 0; d < r.length; d += 1)
    u[d] = ul(al(o, r, d));
  return {
    c() {
      e = ye("div"), t = ye("canvas"), n = pt(), l = ye("div"), i = ye("div"), s && s.c(), a = pt();
      for (let d = 0; d < u.length; d += 1)
        u[d].c();
      this.h();
    },
    l(d) {
      e = De(d, "DIV", { class: !0 });
      var c = Ae(e);
      t = De(c, "CANVAS", { class: !0 }), Ae(t).forEach(Q), n = ht(c), l = De(c, "DIV", { class: !0 });
      var h = Ae(l);
      i = De(h, "DIV", { class: !0, style: !0 });
      var m = Ae(i);
      s && s.l(m), a = ht(m);
      for (let p = 0; p < u.length; p += 1)
        u[p].l(m);
      m.forEach(Q), h.forEach(Q), c.forEach(Q), this.h();
    },
    h() {
      j(t, "class", "svelte-1bt5wt2"), j(i, "class", "credits-content svelte-1bt5wt2"), hn(
        i,
        "--animation-duration",
        /*speed*/
        o[0] + "s"
      ), j(l, "class", "credits-scroll-overlay svelte-1bt5wt2"), j(e, "class", "matrix-container svelte-1bt5wt2");
    },
    m(d, c) {
      rt(d, e, c), te(e, t), o[18](t), te(e, n), te(e, l), te(l, i), s && s.m(i, null), te(i, a);
      for (let h = 0; h < u.length; h += 1)
        u[h] && u[h].m(i, null);
      o[19](i);
    },
    p(d, [c]) {
      var h;
      if (/*scroll_logo_path*/
      (h = d[6]) != null && h.url ? s ? s.p(d, c) : (s = sl(d), s.c(), s.m(i, a)) : s && (s.d(1), s = null), c & /*section_title_style, section_title_uppercase, display_items, swap_font_sizes_on_two_column, title_style, name_style, name_uppercase, title_uppercase, layout_style*/
      15422) {
        r = il(
          /*display_items*/
          d[13]
        );
        let m;
        for (m = 0; m < r.length; m += 1) {
          const p = al(d, r, m);
          u[m] ? u[m].p(p, c) : (u[m] = ul(p), u[m].c(), u[m].m(i, null));
        }
        for (; m < u.length; m += 1)
          u[m].d(1);
        u.length = r.length;
      }
      c & /*speed*/
      1 && hn(
        i,
        "--animation-duration",
        /*speed*/
        d[0] + "s"
      );
    },
    i: ll,
    o: ll,
    d(d) {
      d && Q(e), o[18](null), s && s.d(), xs(u, d), o[19](null);
    }
  };
}
const Bt = 16, _l = "アァカサタナハマヤャラワガザダバパイィキシチニヒミリヰギジヂビピウゥクスツヌフムユュルグズブヅプエェケセテネヘメレヱゲゼデベペオォコソトノホモヨョロヲゴゾドボポヴッン01";
function nr(o, e, t) {
  let n, l, i, a, { credits: s } = e, { speed: r = 20 } = e, { base_font_size: u = 1 } = e, { intro_title: _ = null } = e, { intro_subtitle: d = null } = e, { layout_style: c = "stacked" } = e, { title_uppercase: h = !1 } = e, { name_uppercase: m = !1 } = e, { section_title_uppercase: p = !0 } = e, { swap_font_sizes_on_two_column: b = !1 } = e, { scroll_logo_path: k = null } = e, { scroll_logo_height: g = "120px" } = e, f, v, D, w, F = [], A;
  function y() {
    if (!f) return;
    const $ = f.parentElement;
    $ && (t(8, f.width = $.clientWidth, f), t(8, f.height = $.clientHeight, f)), v = f.getContext("2d"), w = Math.floor(f.width / Bt), F = Array(w).fill(1);
  }
  function T() {
    if (v) {
      v.fillStyle = "rgba(0, 0, 0, 0.05)", v.fillRect(0, 0, f.width, f.height), v.fillStyle = "#0F0", v.font = `${Bt}px monospace`;
      for (let $ = 0; $ < F.length; $++) {
        const ue = _l.charAt(Math.floor(Math.random() * _l.length));
        v.fillText(ue, $ * Bt, F[$] * Bt), F[$] * Bt > f.height && Math.random() > 0.975 && (F[$] = 0), F[$]++;
      }
      A = requestAnimationFrame(T);
    }
  }
  function E() {
    D && (t(9, D.style.animation = "none", D), D.offsetHeight, t(9, D.style.animation = "", D));
  }
  Ws(() => {
    y(), T(), E();
    const $ = new ResizeObserver(() => {
      cancelAnimationFrame(A), y(), T();
    });
    return f.parentElement && $.observe(f.parentElement), () => {
      cancelAnimationFrame(A), f.parentElement && $.unobserve(f.parentElement);
    };
  }), Ks(() => {
    t(9, D = null);
  });
  function L($) {
    tl[$ ? "unshift" : "push"](() => {
      f = $, t(8, f);
    });
  }
  function B($) {
    tl[$ ? "unshift" : "push"](() => {
      D = $, t(9, D);
    });
  }
  return o.$$set = ($) => {
    "credits" in $ && t(14, s = $.credits), "speed" in $ && t(0, r = $.speed), "base_font_size" in $ && t(15, u = $.base_font_size), "intro_title" in $ && t(16, _ = $.intro_title), "intro_subtitle" in $ && t(17, d = $.intro_subtitle), "layout_style" in $ && t(1, c = $.layout_style), "title_uppercase" in $ && t(2, h = $.title_uppercase), "name_uppercase" in $ && t(3, m = $.name_uppercase), "section_title_uppercase" in $ && t(4, p = $.section_title_uppercase), "swap_font_sizes_on_two_column" in $ && t(5, b = $.swap_font_sizes_on_two_column), "scroll_logo_path" in $ && t(6, k = $.scroll_logo_path), "scroll_logo_height" in $ && t(7, g = $.scroll_logo_height);
  }, o.$$.update = () => {
    o.$$.dirty & /*intro_title, intro_subtitle, credits*/
    212992 && t(13, n = (() => {
      const $ = [];
      return (_ || d) && $.push({
        title: _ || "",
        name: d || "",
        is_intro: !0
      }), [
        ...$,
        ...s.map((ue) => Object.assign(Object.assign({}, ue), { is_intro: !1 }))
      ];
    })()), o.$$.dirty & /*base_font_size*/
    32768 && t(12, l = ($) => `font-size: ${$ ? u * 1.5 : u}em;`), o.$$.dirty & /*base_font_size*/
    32768 && t(11, i = ($) => `font-size: ${$ ? u * 0.9 : u * 0.8}em;`), o.$$.dirty & /*base_font_size*/
    32768 && t(10, a = `font-size: ${u * 1.2}em;`), o.$$.dirty & /*credits, speed, intro_title, intro_subtitle, layout_style*/
    212995 && E();
  }, [
    r,
    c,
    h,
    m,
    p,
    b,
    k,
    g,
    f,
    D,
    a,
    i,
    l,
    n,
    s,
    u,
    _,
    d,
    L,
    B
  ];
}
class ir extends Zs {
  constructor(e) {
    super(), Xs(this, e, nr, tr, Ys, {
      credits: 14,
      speed: 0,
      base_font_size: 15,
      intro_title: 16,
      intro_subtitle: 17,
      layout_style: 1,
      title_uppercase: 2,
      name_uppercase: 3,
      section_title_uppercase: 4,
      swap_font_sizes_on_two_column: 5,
      scroll_logo_path: 6,
      scroll_logo_height: 7
    });
  }
}
const { setContext: M3, getContext: lr } = window.__gradio__svelte__internal, or = "WORKER_PROXY_CONTEXT_KEY";
function ar() {
  return lr(or);
}
const sr = "lite.local";
function rr(o) {
  return o.host === window.location.host || o.host === "localhost:7860" || o.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  o.host === sr;
}
function ur(o, e) {
  const t = e.toLowerCase();
  for (const [n, l] of Object.entries(o))
    if (n.toLowerCase() === t)
      return l;
}
function _r(o) {
  const e = typeof window < "u";
  if (o == null || !e)
    return !1;
  const t = new URL(o, window.location.href);
  return !(!rr(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
let sn;
async function cr(o) {
  const e = typeof window < "u";
  if (o == null || !e || !_r(o))
    return o;
  if (sn == null)
    try {
      sn = ar();
    } catch {
      return o;
    }
  if (sn == null)
    return o;
  const n = new URL(o, window.location.href).pathname;
  return sn.httpRequest({
    method: "GET",
    path: n,
    headers: {},
    query_string: ""
  }).then((l) => {
    if (l.status !== 200)
      throw new Error(`Failed to get file ${n} from the Wasm worker.`);
    const i = new Blob([l.body], {
      type: ur(l.headers, "content-type")
    });
    return URL.createObjectURL(i);
  });
}
const {
  SvelteComponent: N3,
  assign: j3,
  check_outros: V3,
  children: H3,
  claim_element: G3,
  compute_rest_props: U3,
  create_slot: Z3,
  detach: x3,
  element: X3,
  empty: Y3,
  exclude_internal_props: W3,
  get_all_dirty_from_scope: K3,
  get_slot_changes: Q3,
  get_spread_update: J3,
  group_outros: e4,
  init: t4,
  insert_hydration: n4,
  listen: i4,
  prevent_default: l4,
  safe_not_equal: o4,
  set_attributes: a4,
  set_style: s4,
  toggle_class: r4,
  transition_in: u4,
  transition_out: _4,
  update_slot_base: c4
} = window.__gradio__svelte__internal, { createEventDispatcher: d4, onMount: f4 } = window.__gradio__svelte__internal, {
  SvelteComponent: dr,
  assign: On,
  bubble: fr,
  claim_element: hr,
  compute_rest_props: cl,
  detach: pr,
  element: mr,
  exclude_internal_props: gr,
  get_spread_update: vr,
  init: br,
  insert_hydration: Dr,
  listen: yr,
  noop: dl,
  safe_not_equal: wr,
  set_attributes: fl,
  src_url_equal: kr,
  toggle_class: hl
} = window.__gradio__svelte__internal;
function Fr(o) {
  let e, t, n, l, i = [
    {
      src: t = /*resolved_src*/
      o[0]
    },
    /*$$restProps*/
    o[1]
  ], a = {};
  for (let s = 0; s < i.length; s += 1)
    a = On(a, i[s]);
  return {
    c() {
      e = mr("img"), this.h();
    },
    l(s) {
      e = hr(s, "IMG", { src: !0 }), this.h();
    },
    h() {
      fl(e, a), hl(e, "svelte-kxeri3", !0);
    },
    m(s, r) {
      Dr(s, e, r), n || (l = yr(
        e,
        "load",
        /*load_handler*/
        o[4]
      ), n = !0);
    },
    p(s, [r]) {
      fl(e, a = vr(i, [
        r & /*resolved_src*/
        1 && !kr(e.src, t = /*resolved_src*/
        s[0]) && { src: t },
        r & /*$$restProps*/
        2 && /*$$restProps*/
        s[1]
      ])), hl(e, "svelte-kxeri3", !0);
    },
    i: dl,
    o: dl,
    d(s) {
      s && pr(e), n = !1, l();
    }
  };
}
function $r(o, e, t) {
  const n = ["src"];
  let l = cl(e, n), { src: i = void 0 } = e, a, s;
  function r(u) {
    fr.call(this, o, u);
  }
  return o.$$set = (u) => {
    e = On(On({}, e), gr(u)), t(1, l = cl(e, n)), "src" in u && t(2, i = u.src);
  }, o.$$.update = () => {
    if (o.$$.dirty & /*src, latest_src*/
    12) {
      t(0, a = i), t(3, s = i);
      const u = i;
      cr(u).then((_) => {
        s === u && t(0, a = _);
      });
    }
  }, [a, l, i, s, r];
}
class Cr extends dr {
  constructor(e) {
    super(), br(this, e, $r, Fr, wr, { src: 2 });
  }
}
const {
  SvelteComponent: h4,
  append_hydration: p4,
  attr: m4,
  binding_callbacks: g4,
  bubble: v4,
  check_outros: b4,
  children: D4,
  claim_component: y4,
  claim_element: w4,
  claim_space: k4,
  create_component: F4,
  destroy_component: $4,
  detach: C4,
  element: E4,
  empty: A4,
  group_outros: S4,
  init: q4,
  insert_hydration: B4,
  listen: T4,
  mount_component: z4,
  safe_not_equal: I4,
  space: R4,
  toggle_class: L4,
  transition_in: O4,
  transition_out: P4
} = window.__gradio__svelte__internal, { createEventDispatcher: M4, onMount: N4 } = window.__gradio__svelte__internal, {
  SvelteComponent: Er,
  append_hydration: fe,
  attr: ae,
  check_outros: ut,
  children: qe,
  claim_component: $t,
  claim_element: se,
  claim_space: tt,
  claim_text: Pn,
  create_component: Ct,
  create_slot: Ar,
  destroy_block: Sr,
  destroy_component: Et,
  detach: R,
  element: re,
  empty: _t,
  ensure_array_like: pl,
  get_all_dirty_from_scope: qr,
  get_slot_changes: Br,
  get_svelte_dataset: Xn,
  group_outros: ct,
  head_selector: Tr,
  init: zr,
  insert_hydration: ne,
  listen: Ir,
  mount_component: At,
  noop: Zt,
  safe_not_equal: mn,
  set_data: Mn,
  set_style: G,
  space: nt,
  src_url_equal: ml,
  text: Nn,
  toggle_class: gl,
  transition_in: V,
  transition_out: x,
  update_keyed_each: Rr,
  update_slot_base: Lr
} = window.__gradio__svelte__internal;
function vl(o, e, t) {
  const n = o.slice();
  return n[24] = e[t][0], n[25] = e[t][1], n;
}
function bl(o) {
  let e, t, n, l;
  const i = [Pr, Or], a = [];
  function s(r, u) {
    return (
      /*gradio*/
      r[7] ? 0 : 1
    );
  }
  return t = s(o), n = a[t] = i[t](o), {
    c() {
      e = re("div"), n.c(), this.h();
    },
    l(r) {
      e = se(r, "DIV", { class: !0 });
      var u = qe(e);
      n.l(u), u.forEach(R), this.h();
    },
    h() {
      ae(e, "class", "logo-panel svelte-1hawtr7"), G(
        e,
        "height",
        /*logo_panel_height*/
        o[12]
      ), G(e, "display", "flex"), G(
        e,
        "justify-content",
        /*logo_justify*/
        o[10]
      );
    },
    m(r, u) {
      ne(r, e, u), a[t].m(e, null), l = !0;
    },
    p(r, u) {
      let _ = t;
      t = s(r), t === _ ? a[t].p(r, u) : (ct(), x(a[_], 1, 1, () => {
        a[_] = null;
      }), ut(), n = a[t], n ? n.p(r, u) : (n = a[t] = i[t](r), n.c()), V(n, 1), n.m(e, null)), u & /*logo_panel_height*/
      4096 && G(
        e,
        "height",
        /*logo_panel_height*/
        r[12]
      ), u & /*logo_justify*/
      1024 && G(
        e,
        "justify-content",
        /*logo_justify*/
        r[10]
      );
    },
    i(r) {
      l || (V(n), l = !0);
    },
    o(r) {
      x(n), l = !1;
    },
    d(r) {
      r && R(e), a[t].d();
    }
  };
}
function Or(o) {
  let e, t;
  return {
    c() {
      e = re("img"), this.h();
    },
    l(n) {
      e = se(n, "IMG", { src: !0, alt: !0, style: !0 }), this.h();
    },
    h() {
      ml(e.src, t = /*effectiveValue*/
      o[8].logo_path.url) || ae(e, "src", t), ae(e, "alt", "Logo"), G(
        e,
        "width",
        /*logo_width_style*/
        o[14]
      ), G(
        e,
        "height",
        /*logo_height_style*/
        o[13]
      ), G(
        e,
        "object-fit",
        /*object_fit*/
        o[11]
      );
    },
    m(n, l) {
      ne(n, e, l);
    },
    p(n, l) {
      l & /*effectiveValue*/
      256 && !ml(e.src, t = /*effectiveValue*/
      n[8].logo_path.url) && ae(e, "src", t), l & /*logo_width_style*/
      16384 && G(
        e,
        "width",
        /*logo_width_style*/
        n[14]
      ), l & /*logo_height_style*/
      8192 && G(
        e,
        "height",
        /*logo_height_style*/
        n[13]
      ), l & /*object_fit*/
      2048 && G(
        e,
        "object-fit",
        /*object_fit*/
        n[11]
      );
    },
    i: Zt,
    o: Zt,
    d(n) {
      n && R(e);
    }
  };
}
function Pr(o) {
  let e, t;
  return e = new Cr({
    props: {
      src: (
        /*effectiveValue*/
        o[8].logo_path.url
      ),
      alt: "Logo",
      loading: "lazy",
      gradio: (
        /*gradio*/
        o[7]
      ),
      style: "width: " + /*logo_width_style*/
      o[14] + "; height: " + /*logo_height_style*/
      o[13] + "; object-fit: " + /*object_fit*/
      o[11] + ";"
    }
  }), {
    c() {
      Ct(e.$$.fragment);
    },
    l(n) {
      $t(e.$$.fragment, n);
    },
    m(n, l) {
      At(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l & /*effectiveValue*/
      256 && (i.src = /*effectiveValue*/
      n[8].logo_path.url), l & /*gradio*/
      128 && (i.gradio = /*gradio*/
      n[7]), l & /*logo_width_style, logo_height_style, object_fit*/
      26624 && (i.style = "width: " + /*logo_width_style*/
      n[14] + "; height: " + /*logo_height_style*/
      n[13] + "; object-fit: " + /*object_fit*/
      n[11] + ";"), e.$set(i);
    },
    i(n) {
      t || (V(e.$$.fragment, n), t = !0);
    },
    o(n) {
      x(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Et(e, n);
    }
  };
}
function Dl(o) {
  var l;
  let e, t, n = (
    /*effectiveValue*/
    o[8].show_logo && /*effectiveValue*/
    ((l = o[8].logo_path) == null ? void 0 : l.url) && bl(o)
  );
  return {
    c() {
      e = re("div"), n && n.c(), this.h();
    },
    l(i) {
      e = se(i, "DIV", { class: !0 });
      var a = qe(e);
      n && n.l(a), a.forEach(R), this.h();
    },
    h() {
      ae(e, "class", "outer-logo-wrapper svelte-1hawtr7"), G(
        e,
        "width",
        /*width_style*/
        o[15]
      );
    },
    m(i, a) {
      ne(i, e, a), n && n.m(e, null), t = !0;
    },
    p(i, a) {
      var s;
      /*effectiveValue*/
      i[8].show_logo && /*effectiveValue*/
      ((s = i[8].logo_path) != null && s.url) ? n ? (n.p(i, a), a & /*effectiveValue*/
      256 && V(n, 1)) : (n = bl(i), n.c(), V(n, 1), n.m(e, null)) : n && (ct(), x(n, 1, 1, () => {
        n = null;
      }), ut()), a & /*width_style*/
      32768 && G(
        e,
        "width",
        /*width_style*/
        i[15]
      );
    },
    i(i) {
      t || (V(n), t = !0);
    },
    o(i) {
      x(n), t = !1;
    },
    d(i) {
      i && R(e), n && n.d();
    }
  };
}
function yl(o) {
  let e = (
    /*effectiveValue*/
    o[8].sidebar_position
  ), t, n, l = El(o);
  return {
    c() {
      l.c(), t = _t();
    },
    l(i) {
      l.l(i), t = _t();
    },
    m(i, a) {
      l.m(i, a), ne(i, t, a), n = !0;
    },
    p(i, a) {
      a & /*effectiveValue*/
      256 && mn(e, e = /*effectiveValue*/
      i[8].sidebar_position) ? (ct(), x(l, 1, 1, Zt), ut(), l = El(i), l.c(), V(l, 1), l.m(t.parentNode, t)) : l.p(i, a);
    },
    i(i) {
      n || (V(l), n = !0);
    },
    o(i) {
      x(l), n = !1;
    },
    d(i) {
      i && R(t), l.d(i);
    }
  };
}
function wl(o) {
  let e = {
    effect: (
      /*effectiveValue*/
      o[8].effect
    ),
    speed: (
      /*effectiveValue*/
      o[8].speed
    )
  }, t, n, l = kl(o);
  return {
    c() {
      l.c(), t = _t();
    },
    l(i) {
      l.l(i), t = _t();
    },
    m(i, a) {
      l.m(i, a), ne(i, t, a), n = !0;
    },
    p(i, a) {
      a & /*effectiveValue*/
      256 && mn(e, e = {
        effect: (
          /*effectiveValue*/
          i[8].effect
        ),
        speed: (
          /*effectiveValue*/
          i[8].speed
        )
      }) ? (ct(), x(l, 1, 1, Zt), ut(), l = kl(i), l.c(), V(l, 1), l.m(t.parentNode, t)) : l.p(i, a);
    },
    i(i) {
      n || (V(l), n = !0);
    },
    o(i) {
      x(l), n = !1;
    },
    d(i) {
      i && R(t), l.d(i);
    }
  };
}
function Mr(o) {
  let e, t;
  return e = new ir({
    props: {
      credits: (
        /*effectiveValue*/
        o[8].credits
      ),
      speed: (
        /*effectiveValue*/
        o[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        o[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        o[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        o[8].intro_subtitle
      ),
      layout_style: (
        /*effectiveValue*/
        o[8].layout_style
      ),
      title_uppercase: (
        /*effectiveValue*/
        o[8].title_uppercase
      ),
      name_uppercase: (
        /*effectiveValue*/
        o[8].name_uppercase
      ),
      section_title_uppercase: (
        /*effectiveValue*/
        o[8].section_title_uppercase
      ),
      swap_font_sizes_on_two_column: (
        /*effectiveValue*/
        o[8].swap_font_sizes_on_two_column
      ),
      scroll_logo_path: (
        /*effectiveValue*/
        o[8].scroll_logo_path
      ),
      scroll_logo_height: (
        /*effectiveValue*/
        o[8].scroll_logo_height
      )
    }
  }), {
    c() {
      Ct(e.$$.fragment);
    },
    l(n) {
      $t(e.$$.fragment, n);
    },
    m(n, l) {
      At(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l & /*effectiveValue*/
      256 && (i.credits = /*effectiveValue*/
      n[8].credits), l & /*effectiveValue*/
      256 && (i.speed = /*effectiveValue*/
      n[8].speed), l & /*effectiveValue*/
      256 && (i.base_font_size = /*effectiveValue*/
      n[8].base_font_size), l & /*effectiveValue*/
      256 && (i.intro_title = /*effectiveValue*/
      n[8].intro_title), l & /*effectiveValue*/
      256 && (i.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), l & /*effectiveValue*/
      256 && (i.layout_style = /*effectiveValue*/
      n[8].layout_style), l & /*effectiveValue*/
      256 && (i.title_uppercase = /*effectiveValue*/
      n[8].title_uppercase), l & /*effectiveValue*/
      256 && (i.name_uppercase = /*effectiveValue*/
      n[8].name_uppercase), l & /*effectiveValue*/
      256 && (i.section_title_uppercase = /*effectiveValue*/
      n[8].section_title_uppercase), l & /*effectiveValue*/
      256 && (i.swap_font_sizes_on_two_column = /*effectiveValue*/
      n[8].swap_font_sizes_on_two_column), l & /*effectiveValue*/
      256 && (i.scroll_logo_path = /*effectiveValue*/
      n[8].scroll_logo_path), l & /*effectiveValue*/
      256 && (i.scroll_logo_height = /*effectiveValue*/
      n[8].scroll_logo_height), e.$set(i);
    },
    i(n) {
      t || (V(e.$$.fragment, n), t = !0);
    },
    o(n) {
      x(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Et(e, n);
    }
  };
}
function Nr(o) {
  let e, t;
  return e = new Us({
    props: {
      credits: (
        /*effectiveValue*/
        o[8].credits
      ),
      speed: (
        /*effectiveValue*/
        o[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        o[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        o[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        o[8].intro_subtitle
      ),
      layout_style: (
        /*effectiveValue*/
        o[8].layout_style
      ),
      title_uppercase: (
        /*effectiveValue*/
        o[8].title_uppercase
      ),
      name_uppercase: (
        /*effectiveValue*/
        o[8].name_uppercase
      ),
      section_title_uppercase: (
        /*effectiveValue*/
        o[8].section_title_uppercase
      ),
      swap_font_sizes_on_two_column: (
        /*effectiveValue*/
        o[8].swap_font_sizes_on_two_column
      ),
      scroll_logo_path: (
        /*effectiveValue*/
        o[8].scroll_logo_path
      ),
      scroll_logo_height: (
        /*effectiveValue*/
        o[8].scroll_logo_height
      )
    }
  }), {
    c() {
      Ct(e.$$.fragment);
    },
    l(n) {
      $t(e.$$.fragment, n);
    },
    m(n, l) {
      At(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l & /*effectiveValue*/
      256 && (i.credits = /*effectiveValue*/
      n[8].credits), l & /*effectiveValue*/
      256 && (i.speed = /*effectiveValue*/
      n[8].speed), l & /*effectiveValue*/
      256 && (i.base_font_size = /*effectiveValue*/
      n[8].base_font_size), l & /*effectiveValue*/
      256 && (i.intro_title = /*effectiveValue*/
      n[8].intro_title), l & /*effectiveValue*/
      256 && (i.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), l & /*effectiveValue*/
      256 && (i.layout_style = /*effectiveValue*/
      n[8].layout_style), l & /*effectiveValue*/
      256 && (i.title_uppercase = /*effectiveValue*/
      n[8].title_uppercase), l & /*effectiveValue*/
      256 && (i.name_uppercase = /*effectiveValue*/
      n[8].name_uppercase), l & /*effectiveValue*/
      256 && (i.section_title_uppercase = /*effectiveValue*/
      n[8].section_title_uppercase), l & /*effectiveValue*/
      256 && (i.swap_font_sizes_on_two_column = /*effectiveValue*/
      n[8].swap_font_sizes_on_two_column), l & /*effectiveValue*/
      256 && (i.scroll_logo_path = /*effectiveValue*/
      n[8].scroll_logo_path), l & /*effectiveValue*/
      256 && (i.scroll_logo_height = /*effectiveValue*/
      n[8].scroll_logo_height), e.$set(i);
    },
    i(n) {
      t || (V(e.$$.fragment, n), t = !0);
    },
    o(n) {
      x(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Et(e, n);
    }
  };
}
function jr(o) {
  let e, t;
  return e = new Ts({
    props: {
      credits: (
        /*effectiveValue*/
        o[8].credits
      ),
      speed: (
        /*effectiveValue*/
        o[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        o[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        o[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        o[8].intro_subtitle
      ),
      background_color: (
        /*effectiveValue*/
        o[8].scroll_background_color
      ),
      title_color: (
        /*effectiveValue*/
        o[8].scroll_title_color
      ),
      name_color: (
        /*effectiveValue*/
        o[8].scroll_name_color
      ),
      layout_style: (
        /*effectiveValue*/
        o[8].layout_style
      ),
      title_uppercase: (
        /*effectiveValue*/
        o[8].title_uppercase
      ),
      scroll_section_title_color: (
        /*effectiveValue*/
        o[8].scroll_section_title_color
      ),
      name_uppercase: (
        /*effectiveValue*/
        o[8].name_uppercase
      ),
      section_title_uppercase: (
        /*effectiveValue*/
        o[8].section_title_uppercase
      ),
      swap_font_sizes_on_two_column: (
        /*effectiveValue*/
        o[8].swap_font_sizes_on_two_column
      ),
      scroll_logo_path: (
        /*effectiveValue*/
        o[8].scroll_logo_path
      ),
      scroll_logo_height: (
        /*effectiveValue*/
        o[8].scroll_logo_height
      )
    }
  }), {
    c() {
      Ct(e.$$.fragment);
    },
    l(n) {
      $t(e.$$.fragment, n);
    },
    m(n, l) {
      At(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l & /*effectiveValue*/
      256 && (i.credits = /*effectiveValue*/
      n[8].credits), l & /*effectiveValue*/
      256 && (i.speed = /*effectiveValue*/
      n[8].speed), l & /*effectiveValue*/
      256 && (i.base_font_size = /*effectiveValue*/
      n[8].base_font_size), l & /*effectiveValue*/
      256 && (i.intro_title = /*effectiveValue*/
      n[8].intro_title), l & /*effectiveValue*/
      256 && (i.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), l & /*effectiveValue*/
      256 && (i.background_color = /*effectiveValue*/
      n[8].scroll_background_color), l & /*effectiveValue*/
      256 && (i.title_color = /*effectiveValue*/
      n[8].scroll_title_color), l & /*effectiveValue*/
      256 && (i.name_color = /*effectiveValue*/
      n[8].scroll_name_color), l & /*effectiveValue*/
      256 && (i.layout_style = /*effectiveValue*/
      n[8].layout_style), l & /*effectiveValue*/
      256 && (i.title_uppercase = /*effectiveValue*/
      n[8].title_uppercase), l & /*effectiveValue*/
      256 && (i.scroll_section_title_color = /*effectiveValue*/
      n[8].scroll_section_title_color), l & /*effectiveValue*/
      256 && (i.name_uppercase = /*effectiveValue*/
      n[8].name_uppercase), l & /*effectiveValue*/
      256 && (i.section_title_uppercase = /*effectiveValue*/
      n[8].section_title_uppercase), l & /*effectiveValue*/
      256 && (i.swap_font_sizes_on_two_column = /*effectiveValue*/
      n[8].swap_font_sizes_on_two_column), l & /*effectiveValue*/
      256 && (i.scroll_logo_path = /*effectiveValue*/
      n[8].scroll_logo_path), l & /*effectiveValue*/
      256 && (i.scroll_logo_height = /*effectiveValue*/
      n[8].scroll_logo_height), e.$set(i);
    },
    i(n) {
      t || (V(e.$$.fragment, n), t = !0);
    },
    o(n) {
      x(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Et(e, n);
    }
  };
}
function kl(o) {
  let e, t, n, l;
  const i = [jr, Nr, Mr], a = [];
  function s(r, u) {
    return (
      /*effectiveValue*/
      r[8].effect === "scroll" ? 0 : (
        /*effectiveValue*/
        r[8].effect === "starwars" ? 1 : (
          /*effectiveValue*/
          r[8].effect === "matrix" ? 2 : -1
        )
      )
    );
  }
  return ~(t = s(o)) && (n = a[t] = i[t](o)), {
    c() {
      e = re("div"), n && n.c(), this.h();
    },
    l(r) {
      e = se(r, "DIV", { class: !0 });
      var u = qe(e);
      n && n.l(u), u.forEach(R), this.h();
    },
    h() {
      ae(e, "class", "main-credits-panel svelte-1hawtr7"), G(
        e,
        "height",
        /*height_style*/
        o[16]
      ), G(
        e,
        "width",
        /*effectiveValue*/
        o[8].sidebar_position === "right" && /*effectiveValue*/
        o[8].show_licenses ? "calc(100% - var(--sidebar-width, 400px))" : (
          /*width_style*/
          o[15]
        )
      );
    },
    m(r, u) {
      ne(r, e, u), ~t && a[t].m(e, null), l = !0;
    },
    p(r, u) {
      let _ = t;
      t = s(r), t === _ ? ~t && a[t].p(r, u) : (n && (ct(), x(a[_], 1, 1, () => {
        a[_] = null;
      }), ut()), ~t ? (n = a[t], n ? n.p(r, u) : (n = a[t] = i[t](r), n.c()), V(n, 1), n.m(e, null)) : n = null), u & /*height_style*/
      65536 && G(
        e,
        "height",
        /*height_style*/
        r[16]
      ), u & /*effectiveValue, width_style*/
      33024 && G(
        e,
        "width",
        /*effectiveValue*/
        r[8].sidebar_position === "right" && /*effectiveValue*/
        r[8].show_licenses ? "calc(100% - var(--sidebar-width, 400px))" : (
          /*width_style*/
          r[15]
        )
      );
    },
    i(r) {
      l || (V(n), l = !0);
    },
    o(r) {
      x(n), l = !1;
    },
    d(r) {
      r && R(e), ~t && a[t].d();
    }
  };
}
function Fl(o) {
  let e, t, n = "Licenses", l, i, a = [], s = /* @__PURE__ */ new Map(), r, u = pl(Object.entries(
    /*effectiveValue*/
    o[8].licenses
  ));
  const _ = (c) => (
    /*name*/
    c[24]
  );
  for (let c = 0; c < u.length; c += 1) {
    let h = vl(o, u, c), m = _(h);
    s.set(m, a[c] = $l(m, h));
  }
  let d = (
    /*selected_license_name*/
    o[9] && Cl(o)
  );
  return {
    c() {
      e = re("div"), t = re("h3"), t.textContent = n, l = nt(), i = re("ul");
      for (let c = 0; c < a.length; c += 1)
        a[c].c();
      r = nt(), d && d.c(), this.h();
    },
    l(c) {
      e = se(c, "DIV", { class: !0 });
      var h = qe(e);
      t = se(h, "H3", { class: !0, "data-svelte-h": !0 }), Xn(t) !== "svelte-1txs4lo" && (t.textContent = n), l = tt(h), i = se(h, "UL", {});
      var m = qe(i);
      for (let p = 0; p < a.length; p += 1)
        a[p].l(m);
      m.forEach(R), r = tt(h), d && d.l(h), h.forEach(R), this.h();
    },
    h() {
      ae(t, "class", "svelte-1hawtr7"), ae(e, "class", "licenses-sidebar svelte-1hawtr7");
    },
    m(c, h) {
      ne(c, e, h), fe(e, t), fe(e, l), fe(e, i);
      for (let m = 0; m < a.length; m += 1)
        a[m] && a[m].m(i, null);
      fe(e, r), d && d.m(e, null);
    },
    p(c, h) {
      h & /*selected_license_name, Object, effectiveValue, show_license*/
      131840 && (u = pl(Object.entries(
        /*effectiveValue*/
        c[8].licenses
      )), a = Rr(a, h, _, 1, c, u, s, i, Sr, $l, null, vl)), /*selected_license_name*/
      c[9] ? d ? d.p(c, h) : (d = Cl(c), d.c(), d.m(e, null)) : d && (d.d(1), d = null);
    },
    d(c) {
      c && R(e);
      for (let h = 0; h < a.length; h += 1)
        a[h].d();
      d && d.d();
    }
  };
}
function $l(o, e) {
  let t, n, l = (
    /*name*/
    e[24] + ""
  ), i, a, s, r;
  function u() {
    return (
      /*click_handler*/
      e[22](
        /*name*/
        e[24]
      )
    );
  }
  return {
    key: o,
    first: null,
    c() {
      t = re("li"), n = re("button"), i = Nn(l), a = nt(), this.h();
    },
    l(_) {
      t = se(_, "LI", { class: !0 });
      var d = qe(t);
      n = se(d, "BUTTON", { type: !0, class: !0 });
      var c = qe(n);
      i = Pn(c, l), c.forEach(R), a = tt(d), d.forEach(R), this.h();
    },
    h() {
      ae(n, "type", "button"), ae(n, "class", "svelte-1hawtr7"), gl(
        n,
        "selected",
        /*selected_license_name*/
        e[9] === /*name*/
        e[24]
      ), ae(t, "class", "svelte-1hawtr7"), this.first = t;
    },
    m(_, d) {
      ne(_, t, d), fe(t, n), fe(n, i), fe(t, a), s || (r = Ir(n, "click", u), s = !0);
    },
    p(_, d) {
      e = _, d & /*effectiveValue*/
      256 && l !== (l = /*name*/
      e[24] + "") && Mn(i, l), d & /*selected_license_name, Object, effectiveValue*/
      768 && gl(
        n,
        "selected",
        /*selected_license_name*/
        e[9] === /*name*/
        e[24]
      );
    },
    d(_) {
      _ && R(t), s = !1, r();
    }
  };
}
function Cl(o) {
  let e, t, n, l, i, a = (
    /*effectiveValue*/
    o[8].licenses[
      /*selected_license_name*/
      o[9]
    ] + ""
  ), s;
  return {
    c() {
      e = re("div"), t = re("h4"), n = Nn(
        /*selected_license_name*/
        o[9]
      ), l = nt(), i = re("pre"), s = Nn(a), this.h();
    },
    l(r) {
      e = se(r, "DIV", { class: !0 });
      var u = qe(e);
      t = se(u, "H4", { class: !0 });
      var _ = qe(t);
      n = Pn(
        _,
        /*selected_license_name*/
        o[9]
      ), _.forEach(R), l = tt(u), i = se(u, "PRE", { class: !0 });
      var d = qe(i);
      s = Pn(d, a), d.forEach(R), u.forEach(R), this.h();
    },
    h() {
      ae(t, "class", "svelte-1hawtr7"), ae(i, "class", "svelte-1hawtr7"), ae(e, "class", "license-display svelte-1hawtr7");
    },
    m(r, u) {
      ne(r, e, u), fe(e, t), fe(t, n), fe(e, l), fe(e, i), fe(i, s);
    },
    p(r, u) {
      u & /*selected_license_name*/
      512 && Mn(
        n,
        /*selected_license_name*/
        r[9]
      ), u & /*effectiveValue, selected_license_name*/
      768 && a !== (a = /*effectiveValue*/
      r[8].licenses[
        /*selected_license_name*/
        r[9]
      ] + "") && Mn(s, a);
    },
    d(r) {
      r && R(e);
    }
  };
}
function El(o) {
  let e, t, n, l = (
    /*effectiveValue*/
    o[8].show_licenses && Object.keys(
      /*effectiveValue*/
      o[8].licenses
    ).length > 0
  ), i, a = (
    /*effectiveValue*/
    o[8].show_credits && wl(o)
  ), s = l && Fl(o);
  return {
    c() {
      e = re("div"), t = re("div"), a && a.c(), n = nt(), s && s.c(), this.h();
    },
    l(r) {
      e = se(r, "DIV", { class: !0 });
      var u = qe(e);
      t = se(u, "DIV", { class: !0 });
      var _ = qe(t);
      a && a.l(_), n = tt(_), s && s.l(_), _.forEach(R), u.forEach(R), this.h();
    },
    h() {
      ae(t, "class", "credits-panel-wrapper svelte-1hawtr7"), G(
        t,
        "width",
        /*width_style*/
        o[15]
      ), G(
        t,
        "height",
        /*effectiveValue*/
        o[8].sidebar_position === "right" ? (
          /*height_style*/
          o[16]
        ) : void 0
      ), G(t, "--main-panel-width", !/*effectiveValue*/
      o[8].show_credits && /*effectiveValue*/
      o[8].show_licenses ? "0px" : "auto"), ae(e, "class", "outer-credits-wrapper svelte-1hawtr7"), G(
        e,
        "width",
        /*width_style*/
        o[15]
      );
    },
    m(r, u) {
      ne(r, e, u), fe(e, t), a && a.m(t, null), fe(t, n), s && s.m(t, null), i = !0;
    },
    p(r, u) {
      /*effectiveValue*/
      r[8].show_credits ? a ? (a.p(r, u), u & /*effectiveValue*/
      256 && V(a, 1)) : (a = wl(r), a.c(), V(a, 1), a.m(t, n)) : a && (ct(), x(a, 1, 1, () => {
        a = null;
      }), ut()), u & /*effectiveValue*/
      256 && (l = /*effectiveValue*/
      r[8].show_licenses && Object.keys(
        /*effectiveValue*/
        r[8].licenses
      ).length > 0), l ? s ? s.p(r, u) : (s = Fl(r), s.c(), s.m(t, null)) : s && (s.d(1), s = null), u & /*width_style*/
      32768 && G(
        t,
        "width",
        /*width_style*/
        r[15]
      ), u & /*effectiveValue, height_style*/
      65792 && G(
        t,
        "height",
        /*effectiveValue*/
        r[8].sidebar_position === "right" ? (
          /*height_style*/
          r[16]
        ) : void 0
      ), u & /*effectiveValue*/
      256 && G(t, "--main-panel-width", !/*effectiveValue*/
      r[8].show_credits && /*effectiveValue*/
      r[8].show_licenses ? "0px" : "auto"), u & /*width_style*/
      32768 && G(
        e,
        "width",
        /*width_style*/
        r[15]
      );
    },
    i(r) {
      i || (V(a), i = !0);
    },
    o(r) {
      x(a), i = !1;
    },
    d(r) {
      r && R(e), a && a.d(), s && s.d();
    }
  };
}
function Vr(o) {
  var c, h, m;
  let e, t, n, l = (
    /*effectiveValue*/
    o[8].logo_position
  ), i, a, s;
  e = new ws({
    props: {
      autoscroll: (
        /*gradio*/
        o[7].autoscroll
      ),
      i18n: (
        /*gradio*/
        o[7].i18n
      ),
      queue_position: (
        /*loading_status*/
        ((c = o[6]) == null ? void 0 : c.queue_position) ?? -1
      ),
      queue_size: (
        /*loading_status*/
        ((h = o[6]) == null ? void 0 : h.queue_size) ?? 0
      ),
      status: (
        /*loading_status*/
        ((m = o[6]) == null ? void 0 : m.status) ?? "complete"
      )
    }
  });
  const r = (
    /*#slots*/
    o[21].default
  ), u = Ar(
    r,
    o,
    /*$$scope*/
    o[23],
    null
  );
  let _ = Dl(o), d = (
    /*effectiveValue*/
    (o[8].show_licenses || /*effectiveValue*/
    o[8].show_credits) && yl(o)
  );
  return {
    c() {
      Ct(e.$$.fragment), t = nt(), u && u.c(), n = nt(), _.c(), i = nt(), d && d.c(), a = _t();
    },
    l(p) {
      $t(e.$$.fragment, p), t = tt(p), u && u.l(p), n = tt(p), _.l(p), i = tt(p), d && d.l(p), a = _t();
    },
    m(p, b) {
      At(e, p, b), ne(p, t, b), u && u.m(p, b), ne(p, n, b), _.m(p, b), ne(p, i, b), d && d.m(p, b), ne(p, a, b), s = !0;
    },
    p(p, b) {
      var g, f, v;
      const k = {};
      b & /*gradio*/
      128 && (k.autoscroll = /*gradio*/
      p[7].autoscroll), b & /*gradio*/
      128 && (k.i18n = /*gradio*/
      p[7].i18n), b & /*loading_status*/
      64 && (k.queue_position = /*loading_status*/
      ((g = p[6]) == null ? void 0 : g.queue_position) ?? -1), b & /*loading_status*/
      64 && (k.queue_size = /*loading_status*/
      ((f = p[6]) == null ? void 0 : f.queue_size) ?? 0), b & /*loading_status*/
      64 && (k.status = /*loading_status*/
      ((v = p[6]) == null ? void 0 : v.status) ?? "complete"), e.$set(k), u && u.p && (!s || b & /*$$scope*/
      8388608) && Lr(
        u,
        r,
        p,
        /*$$scope*/
        p[23],
        s ? Br(
          r,
          /*$$scope*/
          p[23],
          b,
          null
        ) : qr(
          /*$$scope*/
          p[23]
        ),
        null
      ), b & /*effectiveValue*/
      256 && mn(l, l = /*effectiveValue*/
      p[8].logo_position) ? (ct(), x(_, 1, 1, Zt), ut(), _ = Dl(p), _.c(), V(_, 1), _.m(i.parentNode, i)) : _.p(p, b), /*effectiveValue*/
      p[8].show_licenses || /*effectiveValue*/
      p[8].show_credits ? d ? (d.p(p, b), b & /*effectiveValue*/
      256 && V(d, 1)) : (d = yl(p), d.c(), V(d, 1), d.m(a.parentNode, a)) : d && (ct(), x(d, 1, 1, () => {
        d = null;
      }), ut());
    },
    i(p) {
      s || (V(e.$$.fragment, p), V(u, p), V(_), V(d), s = !0);
    },
    o(p) {
      x(e.$$.fragment, p), x(u, p), x(_), x(d), s = !1;
    },
    d(p) {
      p && (R(t), R(n), R(i), R(a)), Et(e, p), u && u.d(p), _.d(p), d && d.d(p);
    }
  };
}
function Hr(o) {
  let e, t = `.credits-panel-wrapper { 
              flex-direction: row !important; 
              --panel-direction: row; 
              --sidebar-width: 400px; 
              --border-left: 1px solid var(--border-color-primary); 
              --border-top: none; 
              --border: none;
              --sidebar-max-height: {height_style}; 
            }
            .licenses-sidebar { width: var(--sidebar-width, 400px) !important; border-left: 1px solid var(--border-color-primary) !important; border-top: none !important; }
            .main-credits-panel { width: calc(100% - var(--sidebar-width, 400px)) !important; }`;
  return {
    c() {
      e = re("style"), e.textContent = t;
    },
    l(n) {
      e = se(n, "STYLE", { "data-svelte-h": !0 }), Xn(e) !== "svelte-1hbm6cs" && (e.textContent = t);
    },
    m(n, l) {
      ne(n, e, l);
    },
    d(n) {
      n && R(e);
    }
  };
}
function Gr(o) {
  let e, t = `.credits-panel-wrapper {
        flex-direction: column !important;
        --panel-direction: column;
        --sidebar-width: 100%;
        --border-left: none;
        --border-top: 1px solid var(--border-color-primary);
        --sidebar-max-height: 400px;
        --border: none;
      }
      .licenses-sidebar {
        width: 100% !important;
        border-left: none !important;
        border-top: 1px solid var(--border-color-primary) !important;
      }
      .main-credits-panel {
        width: 100% !important;
      }`;
  return {
    c() {
      e = re("style"), e.textContent = t;
    },
    l(n) {
      e = se(n, "STYLE", { "data-svelte-h": !0 }), Xn(e) !== "svelte-gyscx4" && (e.textContent = t);
    },
    m(n, l) {
      ne(n, e, l);
    },
    d(n) {
      n && R(e);
    }
  };
}
function Ur(o) {
  let e, t, n, l;
  e = new Co({
    props: {
      visible: (
        /*visible*/
        o[2]
      ),
      elem_id: (
        /*elem_id*/
        o[0]
      ),
      elem_classes: (
        /*elem_classes*/
        o[1]
      ),
      container: (
        /*container*/
        o[3]
      ),
      scale: (
        /*scale*/
        o[4]
      ),
      min_width: (
        /*min_width*/
        o[5]
      ),
      padding: !1,
      $$slots: { default: [Vr] },
      $$scope: { ctx: o }
    }
  });
  function i(r, u) {
    return (
      /*effectiveValue*/
      r[8].sidebar_position === "bottom" ? Gr : Hr
    );
  }
  let a = i(o), s = a(o);
  return {
    c() {
      Ct(e.$$.fragment), t = nt(), s.c(), n = _t();
    },
    l(r) {
      $t(e.$$.fragment, r), t = tt(r);
      const u = Tr("svelte-1lsh18a", document.head);
      s.l(u), n = _t(), u.forEach(R);
    },
    m(r, u) {
      At(e, r, u), ne(r, t, u), s.m(document.head, null), fe(document.head, n), l = !0;
    },
    p(r, [u]) {
      const _ = {};
      u & /*visible*/
      4 && (_.visible = /*visible*/
      r[2]), u & /*elem_id*/
      1 && (_.elem_id = /*elem_id*/
      r[0]), u & /*elem_classes*/
      2 && (_.elem_classes = /*elem_classes*/
      r[1]), u & /*container*/
      8 && (_.container = /*container*/
      r[3]), u & /*scale*/
      16 && (_.scale = /*scale*/
      r[4]), u & /*min_width*/
      32 && (_.min_width = /*min_width*/
      r[5]), u & /*$$scope, effectiveValue, width_style, height_style, selected_license_name, logo_panel_height, logo_justify, gradio, logo_width_style, logo_height_style, object_fit, loading_status*/
      8519616 && (_.$$scope = { dirty: u, ctx: r }), e.$set(_), a !== (a = i(r)) && (s.d(1), s = a(r), s && (s.c(), s.m(n.parentNode, n)));
    },
    i(r) {
      l || (V(e.$$.fragment, r), l = !0);
    },
    o(r) {
      x(e.$$.fragment, r), l = !1;
    },
    d(r) {
      r && R(t), Et(e, r), s.d(r), R(n);
    }
  };
}
function Zr(o, e, t) {
  let n, l, i, a, s, r, u, _, { $$slots: d = {}, $$scope: c } = e, { value: h = null } = e, { elem_id: m = "" } = e, { elem_classes: p = [] } = e, { visible: b = !0 } = e, { container: k = !0 } = e, { scale: g = null } = e, { min_width: f = void 0 } = e, { height: v = void 0 } = e, { width: D = void 0 } = e, { loading_status: w } = e, { gradio: F } = e, A = null;
  function y(E) {
    t(9, A = A === E ? null : E);
  }
  const T = (E) => y(E);
  return o.$$set = (E) => {
    "value" in E && t(18, h = E.value), "elem_id" in E && t(0, m = E.elem_id), "elem_classes" in E && t(1, p = E.elem_classes), "visible" in E && t(2, b = E.visible), "container" in E && t(3, k = E.container), "scale" in E && t(4, g = E.scale), "min_width" in E && t(5, f = E.min_width), "height" in E && t(19, v = E.height), "width" in E && t(20, D = E.width), "loading_status" in E && t(6, w = E.loading_status), "gradio" in E && t(7, F = E.gradio), "$$scope" in E && t(23, c = E.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty & /*value*/
    262144 && t(8, n = h || {
      credits: [
        { section_title: "Default Team" },
        {
          title: "Lead Developer",
          name: "John Doe"
        },
        {
          title: "UI/UX Design",
          name: "Jane Smith"
        }
      ],
      licenses: {
        "Gradio Framework": "Apache License placeholder",
        "This Component": "MIT License placeholder"
      },
      effect: "scroll",
      speed: 40,
      base_font_size: 1.5,
      intro_title: "",
      intro_subtitle: "",
      sidebar_position: "right",
      logo_path: null,
      show_logo: !0,
      show_licenses: !0,
      show_credits: !0,
      logo_position: "center",
      logo_sizing: "resize",
      logo_width: null,
      logo_height: null,
      scroll_background_color: null,
      scroll_title_color: null,
      scroll_section_title_color: null,
      scroll_name_color: null,
      layout_style: "stacked",
      title_uppercase: !1,
      name_uppercase: !1,
      section_title_uppercase: !0,
      swap_font_sizes_on_two_column: !1,
      scroll_logo_path: null,
      scroll_logo_height: "120px"
    }), o.$$.dirty & /*height*/
    524288 && t(16, l = typeof v == "number" ? `${v}px` : v || "500px"), o.$$.dirty & /*width*/
    1048576 && t(15, i = typeof D == "number" ? `${D}px` : D || "100%"), o.$$.dirty & /*effectiveValue*/
    256 && t(14, a = n.logo_width ? typeof n.logo_width == "number" ? `${n.logo_width}px` : n.logo_width : "auto"), o.$$.dirty & /*effectiveValue*/
    256 && t(13, s = n.logo_height ? typeof n.logo_height == "number" ? `${n.logo_height}px` : n.logo_height : "100px"), o.$$.dirty & /*effectiveValue*/
    256 && t(12, r = n.logo_height ? typeof n.logo_height == "number" ? `${n.logo_height}px` : n.logo_height : "100px"), o.$$.dirty & /*effectiveValue*/
    256 && t(11, u = n.logo_sizing === "stretch" ? "fill" : n.logo_sizing === "crop" ? "cover" : "contain"), o.$$.dirty & /*effectiveValue*/
    256 && t(10, _ = n.logo_position === "center" ? "center" : n.logo_position === "left" ? "flex-start" : "flex-end");
  }, [
    m,
    p,
    b,
    k,
    g,
    f,
    w,
    F,
    n,
    A,
    _,
    u,
    r,
    s,
    a,
    i,
    l,
    y,
    h,
    v,
    D,
    d,
    T,
    c
  ];
}
class j4 extends Er {
  constructor(e) {
    super(), zr(this, e, Zr, Ur, mn, {
      value: 18,
      elem_id: 0,
      elem_classes: 1,
      visible: 2,
      container: 3,
      scale: 4,
      min_width: 5,
      height: 19,
      width: 20,
      loading_status: 6,
      gradio: 7
    });
  }
}
export {
  j4 as default
};
