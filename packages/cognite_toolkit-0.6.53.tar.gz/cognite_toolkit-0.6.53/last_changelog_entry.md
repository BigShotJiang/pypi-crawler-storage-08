## cdf 

### Fixed

- Invalid Capabilities error on running `cdf auth init` on DM only
projects.

## templates

No changes.