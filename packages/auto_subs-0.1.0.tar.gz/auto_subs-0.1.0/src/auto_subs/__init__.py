"""Auto-Subs: A powerful, local-first library for video transcription and subtitle generation."""

__version__ = "0.1.0"
