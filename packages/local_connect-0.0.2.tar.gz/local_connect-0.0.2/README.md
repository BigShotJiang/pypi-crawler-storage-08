# Local-Connect-Python
Stores scripts to connect to between laptops that have pip install
The handle for error isnt good, so you will receive quite error messages, eventhought it doesnt do any harm