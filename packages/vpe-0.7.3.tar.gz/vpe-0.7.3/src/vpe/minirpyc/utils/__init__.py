"""
Utilities (not part of the core protocol)
"""
