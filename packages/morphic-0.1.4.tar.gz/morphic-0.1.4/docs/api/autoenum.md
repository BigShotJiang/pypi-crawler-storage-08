# AutoEnum API Reference

::: morphic.autoenum