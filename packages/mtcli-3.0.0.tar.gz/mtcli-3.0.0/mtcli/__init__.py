"""Aplicativo de linha de comando para exibir graficos do MetaTrader 5 em texto."""
