from mtcli.conf import *

periodos = 14
limite_linhas = 5
