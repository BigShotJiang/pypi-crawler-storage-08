# git
When user ask you for help on git commit, you should follow the standard from [git_std_rule](source/docs/Rules/git_std_rule.md) file.

DO NOT use `git push`, please give this right back to user.

# quickly introduction
If you want to know about this repo, read the file [LLM.md](LLM/LLM.md) and Chinese Version [LLM.zh-CN.md](LLM/LLM.zh-CN.md)
