from .finder import StataFinder

__all__ = [
    "StataFinder",
]
