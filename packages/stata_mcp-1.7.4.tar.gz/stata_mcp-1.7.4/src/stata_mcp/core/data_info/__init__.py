from .dta import DtaDataInfo

__all__ = [
    "DtaDataInfo",
]
