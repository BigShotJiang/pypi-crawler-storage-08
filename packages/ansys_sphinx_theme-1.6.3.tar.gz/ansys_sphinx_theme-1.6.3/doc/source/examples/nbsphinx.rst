.. _nbsphinx:

Jupyter notebook - nbsphinx
===========================

This example shows how the Ansys Sphinx Theme renders a Jupyter notebook using the ``nbspinx`` extension.

.. nbgallery::

   nbsphinx/jupyter-notebook.ipynb