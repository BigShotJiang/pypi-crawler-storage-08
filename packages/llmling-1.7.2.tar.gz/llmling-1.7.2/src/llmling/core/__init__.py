"""Module for LLMling core classes."""
