# OpenBB OECD Provider

This extension integrates the [OECD](https://stats.oecd.org) data provider into the OpenBB Platform.

## Installation

To install the extension:

```bash
pip install openbb-oecd
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
