def test_import_package() -> None:
    import blazeserve  # noqa: F401
    import blazeserve.cli  # noqa: F401
    import blazeserve.server  # noqa: F401
    import blazeserve.utils  # noqa: F401
