"""Supertape audio player/recorder software for legacy computers."""

__version__ = "1.0.0.dev1"
