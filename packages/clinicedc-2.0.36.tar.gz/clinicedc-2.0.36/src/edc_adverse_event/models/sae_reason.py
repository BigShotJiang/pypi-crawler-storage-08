from edc_list_data.model_mixins import ListUuidModelMixin


class SaeReason(ListUuidModelMixin):
    class Meta(ListUuidModelMixin.Meta):
        pass
