# -*- coding: utf-8 -*-
"""
主入口文件 - 支持 python -m fh2_drc_mcp_server 运行
"""
from .server import run

if __name__ == '__main__':
    run()


