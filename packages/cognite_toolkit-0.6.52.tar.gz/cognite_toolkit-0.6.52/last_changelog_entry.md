## cdf 

### Fixed

- Empty warnings are no longer being displayed, for example when
metadata dictionary warnings are suppressed.

## templates

No changes.