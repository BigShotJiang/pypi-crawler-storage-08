## v0.1.1rc54 (October 09, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v0.1.1rc53...v0.1.1rc54

### Bug Fixes

- Add file converter to sdk for QI app Json Support (#778) (by @OnkarVO7 in [177aa06](https://github.com/atlanhq/application-sdk/commit/177aa06))
