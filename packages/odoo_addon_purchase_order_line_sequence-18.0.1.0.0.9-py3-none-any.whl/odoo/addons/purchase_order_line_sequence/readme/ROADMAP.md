In standard odoo is possible to sort the purchase order lines and those
are propagated to the invoice lines
