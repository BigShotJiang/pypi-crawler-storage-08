from langgraph.graph.state import StateGraph, CompiledStateGraph


SubGraph = StateGraph | CompiledStateGraph
