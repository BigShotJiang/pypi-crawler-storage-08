DEFAULT_RESP_HEADERS = {"Content-Type": "application/json; charset=utf-8"}
