# Changelog

All notable changes to this project  be documented in this file.

<!--

## [Unreleased] - yyyy-month-dd

### Added

- nothing so far

### Fixed

- nothing so far

### Changed

- nothing so far

-->

## [1.1.1] - 2025-10-09

### Changed

External changes:

- Removed support for Python 3.7. 
    * unable to easily test on 3.7

Internal changes:

- Added changelog.md
- Changed build backend from flit to hatchling
- Add GH workflow

## [1.0.3] - 2021-8-26

- Initial publish to GitHub / PyPI
