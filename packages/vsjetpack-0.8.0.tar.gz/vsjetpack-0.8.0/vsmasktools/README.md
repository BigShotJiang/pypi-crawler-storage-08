# vs-masktools

vs-masktools aims to provide tools and functions to manage, create, and manipulate masks in VapourSynth.
