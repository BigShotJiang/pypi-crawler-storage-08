# vs-deinterlace

### VapourSynth deinterlacing and interlaced/telecined content helper functions
