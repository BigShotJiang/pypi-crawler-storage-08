"""
Created on Wed Dec 21 19:00:00 2022

@author: Anna Grim
@email: anna.grim@alleninstitute.org

"""

from setuptools import setup

if __name__ == "__main__":

    setup()
