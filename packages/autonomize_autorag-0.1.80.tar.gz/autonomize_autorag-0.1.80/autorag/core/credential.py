"""ModelhubCredential Implementation"""

from autonomize.core.credential import ModelhubCredential  # pragma: no cover

__all__ = ["ModelhubCredential"]  # pragma: no cover
