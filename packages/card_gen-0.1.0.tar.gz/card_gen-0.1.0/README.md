# abc

A simple Python package to generate annotated images with text and logo.

## Installation

```bash
pip install card_gen
