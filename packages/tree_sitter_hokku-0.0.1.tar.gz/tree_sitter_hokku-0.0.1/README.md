# tree-sitter-hokku

[![PyPI - Version](https://img.shields.io/pypi/v/tree-sitter-hokku.svg)](https://pypi.org/project/tree-sitter-hokku)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/tree-sitter-hokku.svg)](https://pypi.org/project/tree-sitter-hokku)

---

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install tree-sitter-hokku
```

## License

`tree-sitter-hokku` is distributed under the terms of the [Apache-2.0](https://spdx.org/licenses/Apache-2.0.html) license.
