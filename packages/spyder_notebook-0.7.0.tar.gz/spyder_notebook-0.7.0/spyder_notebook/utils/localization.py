# -*- coding: utf-8 -*-
#
# Copyright (c) Spyder Project Contributors
# Licensed under the terms of the MIT License

"""Localization utility function."""

from spyder.config.base import get_translation
_ = get_translation('spyder_notebook')
