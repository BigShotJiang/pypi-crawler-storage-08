"""Version File."""
VERSION_INFO = (0, 7, 0)
__version__ = '.'.join(map(str, VERSION_INFO))
