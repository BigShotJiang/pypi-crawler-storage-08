Declare orderpoint on a location allowing to replenish any product with
the same criteria. This is for an internal warehouse replenishment
currently not compatible with the purchase buy route.
