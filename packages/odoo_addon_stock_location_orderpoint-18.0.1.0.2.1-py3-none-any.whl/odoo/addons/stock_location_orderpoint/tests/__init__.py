from . import test_location_orderpoint
from . import test_location_domain
