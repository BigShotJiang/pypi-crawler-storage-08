"""

Classes to parse and transform PRC server API response data.

"""
