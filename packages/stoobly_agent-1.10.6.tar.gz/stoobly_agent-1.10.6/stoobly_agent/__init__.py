COMMAND = 'stoobly-agent'
VERSION = '1.10.6'
