

class ScaffoldValidateException(Exception):
  pass

