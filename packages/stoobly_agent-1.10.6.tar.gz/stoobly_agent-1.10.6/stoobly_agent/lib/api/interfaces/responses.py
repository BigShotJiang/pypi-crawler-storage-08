from typing import TypedDict

class ResponseShowResponse(TypedDict):
  project_id: str
  text: str