ALL = 'all'
NONE = 'none'