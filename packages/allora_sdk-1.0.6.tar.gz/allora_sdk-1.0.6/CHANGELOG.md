

# CHANGELOG

## v1.1.0

- `AlloraWorker`
    - Minor changes to initialization syntax
    - New events added for submission window opening/closing
    - Polling interval slowed
    - Will re-request from faucet when ALLO balance is low
- Added `allora-export-txs` CLI tool
- Added `allora-topic-lifecycle-visualizer` CLI tool

## v1.0.0

- `AlloraWorker` inference worker
- gRPC client
- REST client