# Napari plugin

`multiview-stitcher` has an associated napari plugin, [napari-stitcher](https://github.com/multiview-stitcher/napari-stitcher).

A space we're watching closely is the advancement of napari towards multi-scale 3D rendering and improved 3D interactivity.

![](images/20230929_screenshot.png)
