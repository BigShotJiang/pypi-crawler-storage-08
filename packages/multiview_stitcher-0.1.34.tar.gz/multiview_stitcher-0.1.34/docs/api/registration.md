::: multiview_stitcher.registration
    options:
      members:
        - register
