Composite keys Example
----------------------

Simple application showing the product-type relationship.

Create an Admin user::

    $ fabmanager create-admin

Run it::

    $ fabmanager run
