from flask_babel import lazy_gettext as _

"""
This Module is not used.
Just use it to automate Babel extraction
"""

auto_translations_import = [
    _("Search"),
    _("Back"),
    _("Save"),
    _("This field is required."),
    _("Not a valid date value"),
    _("No records found"),
]
