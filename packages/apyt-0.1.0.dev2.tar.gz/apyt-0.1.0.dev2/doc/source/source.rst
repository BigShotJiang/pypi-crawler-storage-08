Source code
===========

The source code of the APyT package is available in the official |apyt_repo|.


.. |apyt_repo| raw:: html

    <a href="https://github.com/sebi-85/apyt" target="_blank">
    GitHub repository</a>


.. sectionauthor:: Sebastian M. Eich <Sebastian.Eich@imw.uni-stuttgart.de>
