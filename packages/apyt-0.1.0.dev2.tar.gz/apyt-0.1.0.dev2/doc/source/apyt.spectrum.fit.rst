.. automodule:: apyt.spectrum.fit
   :members:
   :undoc-members:
   :show-inheritance:
