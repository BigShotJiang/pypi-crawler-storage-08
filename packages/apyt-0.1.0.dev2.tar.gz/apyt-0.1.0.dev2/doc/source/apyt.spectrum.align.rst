.. automodule:: apyt.spectrum.align
   :members:
   :undoc-members:
   :show-inheritance:
