.. automodule:: apyt.gui.forms
   :members:
   :undoc-members:
   :show-inheritance:
