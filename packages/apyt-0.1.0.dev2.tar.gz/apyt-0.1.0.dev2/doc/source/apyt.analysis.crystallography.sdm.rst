.. automodule:: apyt.analysis.crystallography.sdm
   :members:
   :undoc-members:
   :show-inheritance:
