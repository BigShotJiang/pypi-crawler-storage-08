.. automodule:: apyt.analysis.chemistry.locomp
   :members:
   :undoc-members:
   :show-inheritance:
