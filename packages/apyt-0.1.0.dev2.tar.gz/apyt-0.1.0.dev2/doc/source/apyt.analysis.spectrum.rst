.. automodule:: apyt.analysis.spectrum
   :members:
   :undoc-members:
   :show-inheritance:
