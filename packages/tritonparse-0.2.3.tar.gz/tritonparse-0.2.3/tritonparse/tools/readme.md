The tool scripts in this folder are used separately. They are not part of the main tritonparse functionality.
