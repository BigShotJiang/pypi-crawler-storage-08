"""RLKit - A reinforcement learning toolkit."""

__version__ = "0.1.0"
