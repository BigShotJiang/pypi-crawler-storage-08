# ThinkingKey Package

Minimal Python package with:

- Project info (name, version, author)
- Greet function

## Usage

```python
from thinkingkey import greet, get_author

print(get_author())
print(greet("Victor"))
