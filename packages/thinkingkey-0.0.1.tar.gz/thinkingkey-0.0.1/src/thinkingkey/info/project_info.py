def get_project_name() -> str:
    return "ThinkingKey"

def get_version() -> str:
    return "0.1.0"

def get_author() -> str:
    return "Victor Amit"
