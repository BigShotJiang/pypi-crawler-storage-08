"""Assonant Mirror component data class."""
from .component import Component


class Mirror(Component):
    """Data class to handle all data required to define a mirror."""
