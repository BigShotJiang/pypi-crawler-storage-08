"""Assonant Slit component data class."""
from .component import Component


class Slit(Component):
    """Data class to handle all data required to define a slit."""
