from enum import Enum


class ConfigFileFormat(Enum):
    """Supported config file formats."""

    CSV = "csv"
