# Felyx – Video coder in Python for Experimental Psychology

[![PyPI Version](https://img.shields.io/pypi/v/felyx)](https://pypi.org/project/felyx/)
[![License](https://img.shields.io/pypi/l/felyx?color=lightblue)](https://www.gnu.org/licenses/gpl-3.0.en.html)

Felyx is a Python-based application for video coding, primarily intended for use in experimental psychology. Although Felyx resembles a video editor, it is not possible to alter the video file loaded into it. However, it is possible to add temporal occurrences and save them as CSV (comma-separated values)  files.

## Screenshot

![figure](https://gricad-gitlab.univ-grenoble-alpes.fr/babylab-lpnc/video-coder/-/raw/main/screenshot.png)

## Installation

The application is [available at PyPI][] and can be installed via:

    python -m pip install felyx

[available at PyPI]: https://pypi.org/project/felyx/

On Linux, In order to avoid the following warning at startup:
```
qt.multimedia.ffmpeg.libsymbolsresolver: Couldn't load VAAPI library
```
please install the `libav-dev` package (in Debian derivatives).

The application was developed primary on Linux and Windows, but should also work on MacOS.

Felyx is known to function properly with Python versions between 3.8 and 3.13, and with PySide6 versions 6.9 and 6.10.

## Usage

### Loading the video file

After launching the application (`felyx.exe` on Windows, `felyx` on Linux and MacOS), a video file can be loaded via the menu entry `File⇒Open…`. Almost all popular video formats are supported. It is also possible to load a “project” file, in the [ZIP][] format. This file contains a video file, as well as the configuration and data files, all bundled together. Current work can then be saved to the project file, allowing the work to be resumed later. For the technical details about the project file, see the [FORMAT specification](FORMAT.md) file.

[ZIP]: https://en.wikipedia.org/wiki/ZIP

It has been reported that MP4 video files cause Felyx to slow down on Windows systems.

### Playing/stopping the video and moving around it

Once the video has loaded, it can be played or stopped using the space bar. The left and right arrow keys can be used to go backward and forward by one frame at a time, respectively. Positioning the cursor (a black triangle) with the mouse is also possible by clicking and dragging the cursor on the time pane.

### The time pane and its timelines

### Events

### Event occurrences

Event occurrences can be defined by pressing the enter key. This marks one of the borders of the occurrence. The other border can be defined by using the arrow keys or by clicking and dragging the cursor. Once the cursor is in the desired position, press Enter again. This will open a dialog window for choosing the label and the color of the occurrence. New labels can be defined in the dialog window by simply typing them. The new created labels will appear in the list of proposed labels when new occurrences are subsequently created.

Once an occurrence is created, it is possible to change its borders by double-clicking on it. Two handles will then appear, one on the left border of the occurrence and the other on the right border. Click on a border handle and use the left and right arrow keys to move it.

The creation of an occurrence can be aborted, once it has been started by either pressing the Escape key or by clicking on the Abort button in the pop-up window.

The timeline can be zoomed in and out by using the mouse's scroll wheel.

Occurrences can be saved as a CSV file via the menu item `File⇒Export CSV…`.

## Configuration

(more to come later)

## Contributing

The source code is available in a public [repository][] at the Gitlab instance of the Université Grenoble Alpes, France.

[repository]: https://gricad-gitlab.univ-grenoble-alpes.fr/babylab-lpnc/felyx

## The name of the game

Felyx is named after the grandson of one of the authors. The letter *_y_* is reminiscent of the  *_y_* in Python.

## Authors

Copyright (C) 2024  Esteban Milleret (<esteban.milleret@etu.univ-grenoble-alpes.fr>)

Copyright (C) 2024, 2025  Rafael Laboissière (<rafael.laboissiere@cnrs.fr>)


## License

This project is licensed under the terms of the GPL 3.0 or later.

<!--  LocalWords:  Felyx CSV PyPI Alpes Milleret Laboissière GPL MacOS Felyx
      LocalWords:  Université
-->
