User's Manual
==============

**sphinx-theme-shiratama** is a simple theme for sphinx-documentation. 

..  toctree::
    :maxdepth: 2
    :titlesonly:
    
    setup.md
    customize.md
    usage.md