"""This package creates frequency tables from microdata, and applies cell key perturbation to alter the final values""" 

__version__ = "2.0.1"
