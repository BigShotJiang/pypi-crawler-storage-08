# -*- coding: utf-8 -*-
def get_schems(schema_context):
    ...
    return []
