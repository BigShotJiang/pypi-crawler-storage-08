"""Optional DLC integrations for Glitchlings."""

from .huggingface import install as install_huggingface

__all__ = ["install_huggingface"]
