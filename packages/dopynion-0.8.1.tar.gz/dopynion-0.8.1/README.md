# dopynion

The README is short because discovery of rules is part of the game.

There is a referee in another private repository, talking to HTTP API of teams AI (see https://dopynion-template.lecalamar.fr/ as an example of how to start a new AI).
