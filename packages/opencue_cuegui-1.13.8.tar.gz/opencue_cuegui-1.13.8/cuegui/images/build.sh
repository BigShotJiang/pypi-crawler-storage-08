cd bluecurve
/usr/bin/pyrcc4 icons.qrc > icons_rcc.py
cd ..

cd crystal
/usr/bin/pyrcc4 icons.qrc > icons_rcc.py
cd ..

