"""
Search tools for web searching
"""

from react_agent_framework.tools.search.duckduckgo import DuckDuckGoSearch

__all__ = ["DuckDuckGoSearch"]
