"""
CLI do ReAct Agent Framework
"""

from react_agent_framework.cli.app import app

__all__ = ["app"]
