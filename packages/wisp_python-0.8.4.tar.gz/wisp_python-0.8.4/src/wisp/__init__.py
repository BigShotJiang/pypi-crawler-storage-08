from wisp import server
from wisp import util

version = util.get_version()