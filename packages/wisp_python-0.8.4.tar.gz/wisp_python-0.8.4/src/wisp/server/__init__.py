from wisp.server.connection import WispConnection
from wisp.server.connection import WSProxyConnection