"""Retrieval components for semantic code search."""


