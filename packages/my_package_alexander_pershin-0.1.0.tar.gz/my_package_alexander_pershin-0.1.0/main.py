def main():
    print("Hello from my-package!")


if __name__ == "__main__":
    main()
