"""Assembly topic module."""
