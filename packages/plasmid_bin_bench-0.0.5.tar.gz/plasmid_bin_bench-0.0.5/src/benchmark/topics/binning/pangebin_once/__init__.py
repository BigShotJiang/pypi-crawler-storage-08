"""Pangebin-once binning tool."""
