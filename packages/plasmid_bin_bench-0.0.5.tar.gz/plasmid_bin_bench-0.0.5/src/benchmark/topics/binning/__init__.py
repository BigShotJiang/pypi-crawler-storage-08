"""Binning topic module."""
