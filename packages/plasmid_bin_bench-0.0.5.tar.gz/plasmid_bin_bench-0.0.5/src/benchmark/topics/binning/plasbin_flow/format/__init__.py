"""PlasBin-flow formatting module."""
