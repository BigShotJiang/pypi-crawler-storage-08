from .client import SlashingClient

__all__ = ['SlashingClient']
