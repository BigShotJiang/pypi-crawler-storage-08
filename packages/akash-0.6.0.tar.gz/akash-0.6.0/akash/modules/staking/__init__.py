from .client import StakingClient

__all__ = ['StakingClient']
