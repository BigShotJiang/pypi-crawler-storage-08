from .client import InventoryClient

__all__ = ['InventoryClient']
