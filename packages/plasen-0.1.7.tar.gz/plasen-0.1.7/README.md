# Pre-process & Analysis Module for PLASEN

This is Pre-process and Analysis Module for PLASEN (tentative name)

SATLAS (https://woutergins.github.io/satlas/) is modified and packed as part of this module.
