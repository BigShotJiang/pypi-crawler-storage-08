"""Allow running vidserve as a module with python -m vidserve."""

from vidserve.cli import main

if __name__ == "__main__":
    main()
