#!/bin/bash

pip install --break-system-packages pycryptodome==3.21.0
