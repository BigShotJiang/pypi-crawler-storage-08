#!/bin/bash

pip install --break-system-packages pycryptodome==3.20.0 pwntools==4.12.0 unicorn==2.0.1.post1
