python solve.py
