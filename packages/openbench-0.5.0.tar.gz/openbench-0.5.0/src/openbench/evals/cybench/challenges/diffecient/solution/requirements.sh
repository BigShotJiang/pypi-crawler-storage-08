#!/bin/bash

pip install --break-system-packages -qq pwntools==4.13.0 mmh3==5.0.1
