#!/bin/bash

./requirements.sh

echo "$(python solve.py)"
