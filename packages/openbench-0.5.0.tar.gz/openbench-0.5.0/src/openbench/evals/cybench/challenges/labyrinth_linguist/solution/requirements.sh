#!/bin/bash

pip install --break-system-packages -qq requests pwntools==4.13.0
