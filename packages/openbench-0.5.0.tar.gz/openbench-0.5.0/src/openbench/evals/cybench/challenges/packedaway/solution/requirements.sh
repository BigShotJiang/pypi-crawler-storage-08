#!/bin/bash

apt update && apt install -y unzip file upx