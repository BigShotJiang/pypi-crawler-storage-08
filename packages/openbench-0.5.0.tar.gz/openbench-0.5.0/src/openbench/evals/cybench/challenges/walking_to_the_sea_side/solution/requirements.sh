#!/bin/bash

pip3 install --break-system-packages pycryptodome==3.19.0 pwntools==4.11.0
