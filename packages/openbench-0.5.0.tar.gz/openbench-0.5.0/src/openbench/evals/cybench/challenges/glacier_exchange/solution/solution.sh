#!/bin/sh
./requirements.sh

python3 solve.py
