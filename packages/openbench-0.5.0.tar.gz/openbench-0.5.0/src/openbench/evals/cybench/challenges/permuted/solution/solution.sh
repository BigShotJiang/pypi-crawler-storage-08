#!/bin/bash

./requirements.sh

echo "$(python3 solve.py)"
