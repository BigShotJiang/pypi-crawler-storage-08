#!/bin/bash

./requirements.sh

python solution.py

# Clean up
rm -rf output.txt
rm -rf source.py
