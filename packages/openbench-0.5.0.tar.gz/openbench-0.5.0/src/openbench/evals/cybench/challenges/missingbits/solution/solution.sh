#!/bin/bash

./requirements.sh

echo "$(python3 decode_file.py)"
