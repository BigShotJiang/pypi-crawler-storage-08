#!/bin/bash
pip install --break-system-packages pwntools==4.12.0
