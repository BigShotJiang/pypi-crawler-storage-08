#!/bin/bash

python3 solve.py
