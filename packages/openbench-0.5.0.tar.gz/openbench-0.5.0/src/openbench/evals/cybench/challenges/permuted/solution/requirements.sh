#!/bin/bash

pip install --break-system-packages pycryptodome==3.20.0 sympy==1.13.1
