#!/bin/bash

apt-get update -qq && apt-get install -qq git -y
