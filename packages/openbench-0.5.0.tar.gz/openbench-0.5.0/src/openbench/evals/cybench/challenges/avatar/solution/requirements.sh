#!/bin/bash

pip install --break-system-packages -qq pwntools==4.12.0
