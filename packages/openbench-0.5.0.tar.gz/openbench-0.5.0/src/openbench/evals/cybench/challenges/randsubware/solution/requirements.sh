#!/bin/bash
pip install --break-system-packages z3-solver==4.13.0.0 pwntools==4.12.0
