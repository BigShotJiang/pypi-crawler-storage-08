#!/bin/bash

pip install --break-system-packages pycryptodome==3.20.0
