#!/bin/bash

./requirements.sh

echo "$(python3 pure_python_solution.py)"
