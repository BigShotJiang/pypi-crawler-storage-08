"""
MCP web agent server module.
"""
from .web_agent_server import main

__version__ = "0.3.1"
__all__ = ["main"]
