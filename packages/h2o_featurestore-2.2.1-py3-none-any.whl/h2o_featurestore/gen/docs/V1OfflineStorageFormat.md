# V1OfflineStorageFormat


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "OFFLINE_STORAGE_FORMAT_DELTA",  must be one of ["OFFLINE_STORAGE_FORMAT_DELTA", "OFFLINE_STORAGE_FORMAT_SNOWFLAKE", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


