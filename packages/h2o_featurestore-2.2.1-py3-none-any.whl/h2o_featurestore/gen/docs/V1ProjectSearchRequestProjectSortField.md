# V1ProjectSearchRequestProjectSortField


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "PROJECT_SORT_FIELD_UNDEFINED",  must be one of ["PROJECT_SORT_FIELD_UNDEFINED", "PROJECT_SORT_FIELD_NAME", "PROJECT_SORT_FIELD_DESCRIPTION", "PROJECT_SORT_FIELD_ACCESS_MODIFIER", "PROJECT_SORT_FIELD_AUTHOR", "PROJECT_SORT_FIELD_LAST_UPDATE", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


