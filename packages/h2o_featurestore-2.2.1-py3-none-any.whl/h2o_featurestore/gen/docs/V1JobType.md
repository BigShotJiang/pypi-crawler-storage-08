# V1JobType


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "Unknown",  must be one of ["Unknown", "Ingest", "Retrieve", "ExtractSchema", "ComputeStatistics", "Revert", "MaterializationOnline", "ComputeRecommendationClassifiers", "Backfill", "OptimizeStorage", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


