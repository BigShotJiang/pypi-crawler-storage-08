# FeatureSetSearchRequestFeatureSetSortField


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "FEATURE_SET_SORT_FIELD_UNDEFINED",  must be one of ["FEATURE_SET_SORT_FIELD_UNDEFINED", "FEATURE_SET_SORT_FIELD_NAME", "FEATURE_SET_SORT_FIELD_DESCRIPTION", "FEATURE_SET_SORT_FIELD_AUTHOR", "FEATURE_SET_SORT_FIELD_LAST_UPDATE", "FEATURE_SET_SORT_FIELD_PROJECT_NAME", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


