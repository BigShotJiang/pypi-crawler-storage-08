# V1ArtifactUploadStatus


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "ARTIFACT_UPLOAD_STATUS_NOT_APPLICABLE",  must be one of ["ARTIFACT_UPLOAD_STATUS_NOT_APPLICABLE", "ARTIFACT_UPLOAD_STATUS_IN_PROGRESS", "ARTIFACT_UPLOAD_STATUS_DONE", "ARTIFACT_UPLOAD_STATUS_FAILED", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


