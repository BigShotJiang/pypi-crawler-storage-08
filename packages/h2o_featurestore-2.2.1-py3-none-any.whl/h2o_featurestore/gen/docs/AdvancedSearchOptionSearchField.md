# AdvancedSearchOptionSearchField


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "SEARCH_FIELD_UNSPECIFIED",  must be one of ["SEARCH_FIELD_UNSPECIFIED", "SEARCH_FIELD_FEATURE_NAME", "SEARCH_FIELD_FEATURE_DESCRIPTION", "SEARCH_FIELD_FEATURE_TAG", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


