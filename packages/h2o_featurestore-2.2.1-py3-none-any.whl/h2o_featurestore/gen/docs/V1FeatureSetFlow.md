# V1FeatureSetFlow


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "OFFLINE_ONLINE_AUTOMATIC",  must be one of ["OFFLINE_ONLINE_AUTOMATIC", "OFFLINE_ONLINE_MANUAL", "OFFLINE_ONLY", "ONLINE_ONLY", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


