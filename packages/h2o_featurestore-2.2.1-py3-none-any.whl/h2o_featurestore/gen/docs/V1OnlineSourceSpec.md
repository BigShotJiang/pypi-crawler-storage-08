# V1OnlineSourceSpec


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**absolute_json_folder_path** | **str** |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


