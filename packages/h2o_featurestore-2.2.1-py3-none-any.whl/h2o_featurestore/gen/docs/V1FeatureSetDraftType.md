# V1FeatureSetDraftType


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "FEATURE_SET_DRAFT_TYPE_UNSPECIFIED",  must be one of ["FEATURE_SET_DRAFT_TYPE_UNSPECIFIED", "FEATURE_SET_DRAFT_TYPE_CREATE_NEW", "FEATURE_SET_DRAFT_TYPE_CREATE_MAJOR_VERSION", "FEATURE_SET_DRAFT_TYPE_CREATE_NEW_DERIVED", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


