# FeatureSearchRequestFeatureSortField


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "FEATURE_SORT_FIELD_UNDEFINED",  must be one of ["FEATURE_SORT_FIELD_UNDEFINED", "FEATURE_SORT_FIELD_NAME", "FEATURE_SORT_FIELD_DESCRIPTION", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


