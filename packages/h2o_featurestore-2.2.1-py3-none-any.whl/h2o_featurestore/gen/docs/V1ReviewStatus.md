# V1ReviewStatus


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "REVIEW_STATUS_UNSPECIFIED",  must be one of ["REVIEW_STATUS_UNSPECIFIED", "REVIEW_STATUS_TO_REVIEW", "REVIEW_STATUS_APPROVED", "REVIEW_STATUS_REJECTED", "REVIEW_STATUS_CREATED", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


