# V1JoinType


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "JOIN_TYPE_INNER",  must be one of ["JOIN_TYPE_INNER", "JOIN_TYPE_LEFT", "JOIN_TYPE_RIGHT", "JOIN_TYPE_FULL", "JOIN_TYPE_CROSS", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


