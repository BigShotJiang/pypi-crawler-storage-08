# IngestResponseIngestMeta


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cache_location** | **str** |  | [optional] 
**raw_cache_location** | **str** |  | [optional] 
**ingestion_timestamp** | **datetime** |  | [optional] 
**ingest_scope** | [**V1Scope**](V1Scope.md) |  | [optional] 
**message** | **str** |  | [optional] 
**ingest_id** | **str** |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


