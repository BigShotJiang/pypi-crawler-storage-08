# h2o_featurestore.gen.CoreServiceApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**core_service_add_feature_set_permission**](CoreServiceApi.md#core_service_add_feature_set_permission) | **POST** /api/v1/permissions/feature-sets/add/permission/{featureSetId} | 
[**core_service_add_project_permission**](CoreServiceApi.md#core_service_add_project_permission) | **POST** /api/v1/permissions/projects/add/permission/{projectId} | 
[**core_service_admin_search_projects**](CoreServiceApi.md#core_service_admin_search_projects) | **GET** /api/v1/admin/search/projects | Admin Search API
[**core_service_approve_pending_permission**](CoreServiceApi.md#core_service_approve_pending_permission) | **POST** /api/v1/permissions/approval | 
[**core_service_approve_review**](CoreServiceApi.md#core_service_approve_review) | **POST** /api/v1/reviews/{reviewId}/approval | 
[**core_service_cancel_job**](CoreServiceApi.md#core_service_cancel_job) | **DELETE** /api/v1/jobs/{jobId} | 
[**core_service_create_draft_feature_set**](CoreServiceApi.md#core_service_create_draft_feature_set) | **POST** /api/v1/feature-sets/draft | Draft Feature Set
[**core_service_create_feature_set_from_draft**](CoreServiceApi.md#core_service_create_feature_set_from_draft) | **POST** /api/v1/feature-sets/draft/publish | 
[**core_service_create_feature_set_version_from_major_version_draft**](CoreServiceApi.md#core_service_create_feature_set_version_from_major_version_draft) | **POST** /api/v1/feature-sets/draft-major-version/publish | 
[**core_service_create_gpt_chat_session**](CoreServiceApi.md#core_service_create_gpt_chat_session) | **POST** /api/v1/gpte/collections/{collectionId}/session/create | 
[**core_service_create_major_version_draft_feature_set**](CoreServiceApi.md#core_service_create_major_version_draft_feature_set) | **POST** /api/v1/feature-sets/draft-major-version | 
[**core_service_create_new_feature_set_version**](CoreServiceApi.md#core_service_create_new_feature_set_version) | **POST** /api/v1/feature-sets/{featureSetId}/version | 
[**core_service_create_project**](CoreServiceApi.md#core_service_create_project) | **POST** /api/v1/projects | 
[**core_service_create_recommendation_classifier**](CoreServiceApi.md#core_service_create_recommendation_classifier) | **POST** /api/v1/classifiers | 
[**core_service_delete_artifact**](CoreServiceApi.md#core_service_delete_artifact) | **DELETE** /api/v1/artifacts/{artifactId} | 
[**core_service_delete_feature_set**](CoreServiceApi.md#core_service_delete_feature_set) | **DELETE** /api/v1/feature-sets/{featureSetId} | 
[**core_service_delete_feature_set_draft**](CoreServiceApi.md#core_service_delete_feature_set_draft) | **DELETE** /api/v1/feature-sets/draft/{featureSetDraftId} | 
[**core_service_delete_feature_set_version**](CoreServiceApi.md#core_service_delete_feature_set_version) | **DELETE** /api/v1/feature-sets/{featureSetId}/versions/{featureSetMajorVersion} | 
[**core_service_delete_feature_set_version_in_review**](CoreServiceApi.md#core_service_delete_feature_set_version_in_review) | **DELETE** /api/v1/reviews/my-reviews/{reviewId}/feature-set | 
[**core_service_delete_project**](CoreServiceApi.md#core_service_delete_project) | **DELETE** /api/v1/projects/{projectId} | 
[**core_service_delete_recommendation_classifier**](CoreServiceApi.md#core_service_delete_recommendation_classifier) | **DELETE** /api/v1/classifiers/{classifierName} | 
[**core_service_delete_scheduled_task**](CoreServiceApi.md#core_service_delete_scheduled_task) | **DELETE** /api/v1/schedules/{scheduledTaskId} | 
[**core_service_discard_feature_as_target**](CoreServiceApi.md#core_service_discard_feature_as_target) | **DELETE** /api/v1/feature-sets/{featureSetId}/target-variables/{featureId} | 
[**core_service_feature_set_exists**](CoreServiceApi.md#core_service_feature_set_exists) | **GET** /api/v1/feature-sets/exists/{featureSetId} | 
[**core_service_feature_set_schema_patch**](CoreServiceApi.md#core_service_feature_set_schema_patch) | **POST** /api/v1/feature-sets/features/schema-patch | 
[**core_service_generate_ingest_token**](CoreServiceApi.md#core_service_generate_ingest_token) | **GET** /api/v1/feature-sets/{featureSetId}/{featureSetVersion}/online/token | Online API
[**core_service_generate_online_retrieval_token**](CoreServiceApi.md#core_service_generate_online_retrieval_token) | **GET** /api/v1/feature-sets/{featureSetId}/{featureSetVersion}/online/retrieval/token | 
[**core_service_generate_temporary_upload**](CoreServiceApi.md#core_service_generate_temporary_upload) | **POST** /api/v1/upload/temporary | 
[**core_service_generate_token**](CoreServiceApi.md#core_service_generate_token) | **POST** /api/v1/auth/tokens | 
[**core_service_generate_transformation_upload**](CoreServiceApi.md#core_service_generate_transformation_upload) | **POST** /api/v1/upload/transformations | Upload API
[**core_service_get_active_feature_set_permission**](CoreServiceApi.md#core_service_get_active_feature_set_permission) | **GET** /api/v1/permissions/feature-sets/{resourceId}/active | 
[**core_service_get_active_project_permission**](CoreServiceApi.md#core_service_get_active_project_permission) | **GET** /api/v1/permissions/projects/{resourceId}/active | 
[**core_service_get_active_user**](CoreServiceApi.md#core_service_get_active_user) | **GET** /api/v1/auth/users | 
[**core_service_get_api_config**](CoreServiceApi.md#core_service_get_api_config) | **GET** /api/v1/api-config | 
[**core_service_get_backfill_job_output**](CoreServiceApi.md#core_service_get_backfill_job_output) | **GET** /api/v1/jobs/{jobId}/output/backfill | Backfill
[**core_service_get_code_snipped_id**](CoreServiceApi.md#core_service_get_code_snipped_id) | **GET** /api/v1/artifacts/{featureSetId}/{featureSetMajorVersion}/code-snipped-id | 
[**core_service_get_compute_recommendation_classifiers_job_output**](CoreServiceApi.md#core_service_get_compute_recommendation_classifiers_job_output) | **GET** /api/v1/jobs/{jobId}/output/recommendation-classifiers-computation | ComputeRecommendationClassifier API
[**core_service_get_compute_statistics_job_output**](CoreServiceApi.md#core_service_get_compute_statistics_job_output) | **GET** /api/v1/jobs/{jobId}/output/compute-statistics | ComputeStatistics API
[**core_service_get_dashboard**](CoreServiceApi.md#core_service_get_dashboard) | **GET** /api/v1/dashboard | Dashboard API
[**core_service_get_extract_schema_job_output**](CoreServiceApi.md#core_service_get_extract_schema_job_output) | **GET** /api/v1/jobs/{jobId}/output/extract-schema | 
[**core_service_get_feature**](CoreServiceApi.md#core_service_get_feature) | **GET** /api/v1/feature-sets/{featureSetId}/features/{featureId} | Feature API
[**core_service_get_feature_set**](CoreServiceApi.md#core_service_get_feature_set) | **GET** /api/v1/projects/{projectId}/feature-sets/{featureSetName} | 
[**core_service_get_feature_set_by_id**](CoreServiceApi.md#core_service_get_feature_set_by_id) | **GET** /api/v1/feature-sets/{featureSetId} | 
[**core_service_get_feature_set_draft**](CoreServiceApi.md#core_service_get_feature_set_draft) | **GET** /api/v1/feature-sets/draft/{featureSetDraftId} | 
[**core_service_get_feature_set_in_review**](CoreServiceApi.md#core_service_get_feature_set_in_review) | **GET** /api/v1/reviews/my-reviews/{reviewId}/feature-set | 
[**core_service_get_feature_set_preview**](CoreServiceApi.md#core_service_get_feature_set_preview) | **GET** /api/v1/feature-sets/{featureSetId}/preview | 
[**core_service_get_feature_set_preview_in_review**](CoreServiceApi.md#core_service_get_feature_set_preview_in_review) | **GET** /api/v1/reviews/my-reviews/{reviewId}/feature-set/preview | 
[**core_service_get_feature_set_preview_to_review**](CoreServiceApi.md#core_service_get_feature_set_preview_to_review) | **GET** /api/v1/reviews/{reviewId}/feature-set/preview | 
[**core_service_get_feature_set_to_review**](CoreServiceApi.md#core_service_get_feature_set_to_review) | **GET** /api/v1/reviews/{reviewId}/feature-set | 
[**core_service_get_feature_sets_derived_from**](CoreServiceApi.md#core_service_get_feature_sets_derived_from) | **GET** /api/v1/feature-sets/{featureSetId}/derived-from | 
[**core_service_get_feature_sets_last_minor_for_current_major**](CoreServiceApi.md#core_service_get_feature_sets_last_minor_for_current_major) | **GET** /api/v1/feature-sets/{featureSetId}/last | 
[**core_service_get_feature_sets_popularity**](CoreServiceApi.md#core_service_get_feature_sets_popularity) | **GET** /api/v1/dashboard/popular-feature-sets | 
[**core_service_get_h2_o_gpte_config**](CoreServiceApi.md#core_service_get_h2_o_gpte_config) | **GET** /api/v1/h2o-gpte-config | 
[**core_service_get_ingest_history**](CoreServiceApi.md#core_service_get_ingest_history) | **GET** /api/v1/ingest/{featureSetId}/{featureSetVersion}/history | 
[**core_service_get_ingest_job_output**](CoreServiceApi.md#core_service_get_ingest_job_output) | **GET** /api/v1/jobs/{jobId}/output/ingestion | 
[**core_service_get_job**](CoreServiceApi.md#core_service_get_job) | **GET** /api/v1/jobs/{jobId} | 
[**core_service_get_job_progress**](CoreServiceApi.md#core_service_get_job_progress) | **GET** /api/v1/jobs/{jobId}/progress/{nextIndex} | 
[**core_service_get_jobs_with_status_count**](CoreServiceApi.md#core_service_get_jobs_with_status_count) | **GET** /api/v1/jobs/count-by-status | 
[**core_service_get_last_minor_feature_set_for_major_in_project**](CoreServiceApi.md#core_service_get_last_minor_feature_set_for_major_in_project) | **GET** /api/v1/projects/{projectId}/feature-sets/{featureSetName}/{featureSetMajorVersion}/last | 
[**core_service_get_lazy_ingest_task**](CoreServiceApi.md#core_service_get_lazy_ingest_task) | **GET** /api/v1/schedules/lazy/ingestion/{featureSetId}/{featureSetVersion} | 
[**core_service_get_listable_feature_set**](CoreServiceApi.md#core_service_get_listable_feature_set) | **GET** /api/v1/feature-sets/{featureSetId}/listable | Listable FeatureSet API (in future will be moved to new file)
[**core_service_get_listable_feature_set_in_review**](CoreServiceApi.md#core_service_get_listable_feature_set_in_review) | **GET** /api/v1/reviews/my-reviews/{reviewId}/listable/feature-set | 
[**core_service_get_listable_feature_set_to_review**](CoreServiceApi.md#core_service_get_listable_feature_set_to_review) | **GET** /api/v1/reviews/{reviewId}/listable/feature-set | 
[**core_service_get_materialization_online_job_output**](CoreServiceApi.md#core_service_get_materialization_online_job_output) | **GET** /api/v1/jobs/{jobId}/output/online-materialization | 
[**core_service_get_online_retrieve_meta**](CoreServiceApi.md#core_service_get_online_retrieve_meta) | **GET** /api/v1/online-retrieve | 
[**core_service_get_optimize_storage_job_output**](CoreServiceApi.md#core_service_get_optimize_storage_job_output) | **GET** /api/v1/jobs/{jobId}/output/optimize-storage | 
[**core_service_get_project_by_id**](CoreServiceApi.md#core_service_get_project_by_id) | **GET** /api/v1/projects/{projectId} | 
[**core_service_get_recently_used_feature_sets**](CoreServiceApi.md#core_service_get_recently_used_feature_sets) | **GET** /api/v1/dashboard/recently-used-feature-sets | 
[**core_service_get_recently_used_projects**](CoreServiceApi.md#core_service_get_recently_used_projects) | **GET** /api/v1/dashboard/recently-used-projects | 
[**core_service_get_recommendations**](CoreServiceApi.md#core_service_get_recommendations) | **GET** /api/v1/feature-sets/{featureSetId}/recommendations | 
[**core_service_get_retrieve_as_links_job_output**](CoreServiceApi.md#core_service_get_retrieve_as_links_job_output) | **GET** /api/v1/feature-sets/retrieve/{jobId} | 
[**core_service_get_revert_ingest_job_output**](CoreServiceApi.md#core_service_get_revert_ingest_job_output) | **GET** /api/v1/jobs/{jobId}/output/revert | 
[**core_service_get_scheduled_task**](CoreServiceApi.md#core_service_get_scheduled_task) | **GET** /api/v1/schedules/{scheduledTaskId} | 
[**core_service_get_token**](CoreServiceApi.md#core_service_get_token) | **GET** /api/v1/auth/tokens/{tokenId} | 
[**core_service_get_tokens_config**](CoreServiceApi.md#core_service_get_tokens_config) | **GET** /api/v1/auth/tokens/config | 
[**core_service_get_user_active_feature_set_permissions**](CoreServiceApi.md#core_service_get_user_active_feature_set_permissions) | **GET** /api/v1/permissions/feature-sets/active/{resourceId} | 
[**core_service_get_user_active_project_permissions**](CoreServiceApi.md#core_service_get_user_active_project_permissions) | **GET** /api/v1/permissions/projects/active/{resourceId} | 
[**core_service_get_user_feature_set_permissions**](CoreServiceApi.md#core_service_get_user_feature_set_permissions) | **GET** /api/v1/permissions/feature-sets/{resourceId} | 
[**core_service_get_user_project_permissions**](CoreServiceApi.md#core_service_get_user_project_permissions) | **GET** /api/v1/permissions/projects/{resourceId} | 
[**core_service_get_users_without_feature_set_permissions**](CoreServiceApi.md#core_service_get_users_without_feature_set_permissions) | **GET** /api/v1/permissions/feature-sets/{resourceId}/user/permission/none | 
[**core_service_get_users_without_project_permissions**](CoreServiceApi.md#core_service_get_users_without_project_permissions) | **GET** /api/v1/permissions/projects/{resourceId}/user/permission/none | 
[**core_service_get_version**](CoreServiceApi.md#core_service_get_version) | **GET** /api/v1/version | 
[**core_service_get_web_config**](CoreServiceApi.md#core_service_get_web_config) | **GET** /api/v1/config | Config API
[**core_service_has_permission_to_retrieve**](CoreServiceApi.md#core_service_has_permission_to_retrieve) | **GET** /api/v1/feature-sets/retrieve/permission/{projectName}/{featureSetName} | 
[**core_service_is_feature_set_pinned**](CoreServiceApi.md#core_service_is_feature_set_pinned) | **GET** /api/v1/dashboard/pinned-feature-sets/exists/{featureSetId} | 
[**core_service_is_feature_set_schema_compatible**](CoreServiceApi.md#core_service_is_feature_set_schema_compatible) | **POST** /api/v1/feature-sets/features/schema-compatible | 
[**core_service_list_artifacts**](CoreServiceApi.md#core_service_list_artifacts) | **GET** /api/v1/artifacts/{featureSetId}/{featureSetMajorVersion} | 
[**core_service_list_feature_set_drafts**](CoreServiceApi.md#core_service_list_feature_set_drafts) | **GET** /api/v1/feature-sets/draft | 
[**core_service_list_feature_set_versions**](CoreServiceApi.md#core_service_list_feature_set_versions) | **GET** /api/v1/feature-sets/{featureSetId}/versions | 
[**core_service_list_feature_sets_page**](CoreServiceApi.md#core_service_list_feature_sets_page) | **GET** /api/v1/feature-sets | 
[**core_service_list_feature_sets_permissions_page**](CoreServiceApi.md#core_service_list_feature_sets_permissions_page) | **GET** /api/v1/permissions/feature-sets | 
[**core_service_list_feature_sets_reviews_page**](CoreServiceApi.md#core_service_list_feature_sets_reviews_page) | **GET** /api/v1/reviews/my-reviews | 
[**core_service_list_feature_sets_to_review**](CoreServiceApi.md#core_service_list_feature_sets_to_review) | **GET** /api/v1/reviews | Feature Set Review
[**core_service_list_features**](CoreServiceApi.md#core_service_list_features) | **GET** /api/v1/feature-sets/{featureSetId}/features | 
[**core_service_list_features_in_review**](CoreServiceApi.md#core_service_list_features_in_review) | **GET** /api/v1/reviews/my-reviews/{reviewId}/listable/feature-set/features | 
[**core_service_list_features_to_review**](CoreServiceApi.md#core_service_list_features_to_review) | **GET** /api/v1/reviews/{reviewId}/listable/feature-set/features | 
[**core_service_list_jobs**](CoreServiceApi.md#core_service_list_jobs) | **GET** /api/v1/jobs | Jobs API
[**core_service_list_jobs_page_by_feature_set_id**](CoreServiceApi.md#core_service_list_jobs_page_by_feature_set_id) | **GET** /api/v1/jobs/feature-set/id | 
[**core_service_list_jobs_page_by_feature_set_name**](CoreServiceApi.md#core_service_list_jobs_page_by_feature_set_name) | **GET** /api/v1/jobs/feature-set/name | 
[**core_service_list_manageable_feature_sets_permissions_page**](CoreServiceApi.md#core_service_list_manageable_feature_sets_permissions_page) | **GET** /api/v1/permissions/manageable-feature-sets | 
[**core_service_list_manageable_project_permissions_page**](CoreServiceApi.md#core_service_list_manageable_project_permissions_page) | **GET** /api/v1/permissions/manageable-projects | 
[**core_service_list_personal_access_tokens**](CoreServiceApi.md#core_service_list_personal_access_tokens) | **GET** /api/v1/auth/tokens | 
[**core_service_list_pinned_feature_sets**](CoreServiceApi.md#core_service_list_pinned_feature_sets) | **GET** /api/v1/dashboard/pinned-feature-sets | 
[**core_service_list_project_history_page**](CoreServiceApi.md#core_service_list_project_history_page) | **GET** /api/v1/projects/{projectId}/history | 
[**core_service_list_project_permissions_page**](CoreServiceApi.md#core_service_list_project_permissions_page) | **GET** /api/v1/permissions/projects | 
[**core_service_list_projects_page**](CoreServiceApi.md#core_service_list_projects_page) | **GET** /api/v1/projects | Project API
[**core_service_list_recent_gpt_collections**](CoreServiceApi.md#core_service_list_recent_gpt_collections) | **GET** /api/v1/gpte/collections | H2O GPT
[**core_service_list_recommendation_classifiers**](CoreServiceApi.md#core_service_list_recommendation_classifiers) | **GET** /api/v1/classifiers | Recommendation API
[**core_service_list_scheduled_task_execution_history**](CoreServiceApi.md#core_service_list_scheduled_task_execution_history) | **GET** /api/v1/schedules/{scheduledTaskId}/execution-history | 
[**core_service_list_scheduled_tasks**](CoreServiceApi.md#core_service_list_scheduled_tasks) | **GET** /api/v1/feature-sets/{featureSetId}/schedules | 
[**core_service_list_target_features**](CoreServiceApi.md#core_service_list_target_features) | **GET** /api/v1/feature-sets/{featureSetId}/target-variables | 
[**core_service_mark_feature_as_target**](CoreServiceApi.md#core_service_mark_feature_as_target) | **PUT** /api/v1/feature-sets/{featureSetId}/target-variables/{featureId} | 
[**core_service_pause_scheduled_task**](CoreServiceApi.md#core_service_pause_scheduled_task) | **PUT** /api/v1/schedules/{scheduledTaskId}/pause | 
[**core_service_pin_feature_set**](CoreServiceApi.md#core_service_pin_feature_set) | **PUT** /api/v1/dashboard/pinned-feature-sets/{featureSetId} | 
[**core_service_project_exists**](CoreServiceApi.md#core_service_project_exists) | **GET** /api/v1/projects/{projectId}/exists | 
[**core_service_register_feature_set**](CoreServiceApi.md#core_service_register_feature_set) | **POST** /api/v1/feature-sets | 
[**core_service_reject_pending_permission**](CoreServiceApi.md#core_service_reject_pending_permission) | **POST** /api/v1/permissions/rejection | 
[**core_service_reject_review**](CoreServiceApi.md#core_service_reject_review) | **POST** /api/v1/reviews/{reviewId}/rejection | 
[**core_service_remove_feature_set_permission**](CoreServiceApi.md#core_service_remove_feature_set_permission) | **POST** /api/v1/permissions/feature-sets/remove/permission/{featureSetId} | 
[**core_service_remove_project_permission**](CoreServiceApi.md#core_service_remove_project_permission) | **POST** /api/v1/permissions/projects/remove/permission/{projectId} | 
[**core_service_resume_scheduled_task**](CoreServiceApi.md#core_service_resume_scheduled_task) | **PUT** /api/v1/schedules/{scheduledTaskId}/resume | 
[**core_service_retrieve_artifact**](CoreServiceApi.md#core_service_retrieve_artifact) | **GET** /api/v1/artifacts/{artifactId} | 
[**core_service_retrieve_as_spark**](CoreServiceApi.md#core_service_retrieve_as_spark) | **POST** /api/v1/feature-sets/retrieve/as-spark | 
[**core_service_revoke_permission**](CoreServiceApi.md#core_service_revoke_permission) | **POST** /api/v1/permissions/revoke | 
[**core_service_revoke_token**](CoreServiceApi.md#core_service_revoke_token) | **DELETE** /api/v1/auth/tokens/{tokenId} | PAT API
[**core_service_schedule_ingest_job**](CoreServiceApi.md#core_service_schedule_ingest_job) | **POST** /api/v1/schedules/ingestion | Schedule API
[**core_service_schedule_lazy_ingest_task**](CoreServiceApi.md#core_service_schedule_lazy_ingest_task) | **POST** /api/v1/schedules/lazy/ingestion | 
[**core_service_search_feature_sets**](CoreServiceApi.md#core_service_search_feature_sets) | **POST** /api/v1/search/feature-sets | Must be a post request since you can&#39;t use repeated fields
[**core_service_search_features**](CoreServiceApi.md#core_service_search_features) | **GET** /api/v1/search/features | 
[**core_service_search_projects**](CoreServiceApi.md#core_service_search_projects) | **GET** /api/v1/search/projects | Search API
[**core_service_start_extract_schema_job**](CoreServiceApi.md#core_service_start_extract_schema_job) | **POST** /api/v1/jobs/extract-schema | Extract Schema API
[**core_service_start_ingest_job**](CoreServiceApi.md#core_service_start_ingest_job) | **POST** /api/v1/ingest/start | Feature Set API
[**core_service_start_lazy_ingest_task**](CoreServiceApi.md#core_service_start_lazy_ingest_task) | **POST** /api/v1/schedules/lazy/ingestion/start | 
[**core_service_start_materialization_online_job**](CoreServiceApi.md#core_service_start_materialization_online_job) | **POST** /api/v1/feature-sets/{featureSetId}/{featureSetVersion}/online-materialization | 
[**core_service_start_online_offline_ingestion_job**](CoreServiceApi.md#core_service_start_online_offline_ingestion_job) | **POST** /api/v1/feature-sets/{featureSetId}/{featureSetVersion}/online-offline-ingestion | 
[**core_service_start_optimize_storage_job**](CoreServiceApi.md#core_service_start_optimize_storage_job) | **POST** /api/v1/jobs/optimize-storage/start | 
[**core_service_start_retrieve_as_links_job**](CoreServiceApi.md#core_service_start_retrieve_as_links_job) | **POST** /api/v1/feature-sets/retrieve | 
[**core_service_start_revert_ingest_job**](CoreServiceApi.md#core_service_start_revert_ingest_job) | **POST** /api/v1/ingest/revert | 
[**core_service_store_file_artifact**](CoreServiceApi.md#core_service_store_file_artifact) | **POST** /api/v1/artifacts/files | Artifact
[**core_service_store_link**](CoreServiceApi.md#core_service_store_link) | **POST** /api/v1/artifacts/links | 
[**core_service_submit_pending_feature_set_permission**](CoreServiceApi.md#core_service_submit_pending_feature_set_permission) | **POST** /api/v1/permissions/feature-sets/{resourceId} | 
[**core_service_submit_pending_project_permission**](CoreServiceApi.md#core_service_submit_pending_project_permission) | **POST** /api/v1/permissions/projects/{resourceId} | 
[**core_service_unpin_feature_set**](CoreServiceApi.md#core_service_unpin_feature_set) | **DELETE** /api/v1/dashboard/pinned-feature-sets/{featureSetId} | 
[**core_service_update_feature**](CoreServiceApi.md#core_service_update_feature) | **PUT** /api/v1/feature-sets/{featureSetId}/features/{featureId} | 
[**core_service_update_feature_set**](CoreServiceApi.md#core_service_update_feature_set) | **PUT** /api/v1/feature-sets/{featureSetId} | 
[**core_service_update_project**](CoreServiceApi.md#core_service_update_project) | **PUT** /api/v1/projects/{projectId} | 
[**core_service_update_recommendation_classifier**](CoreServiceApi.md#core_service_update_recommendation_classifier) | **PUT** /api/v1/classifiers/{classifier.name} | Updates a classifier
[**core_service_update_scheduled_task**](CoreServiceApi.md#core_service_update_scheduled_task) | **PUT** /api/v1/schedules/{scheduledTaskId} | 
[**core_service_update_upload_status**](CoreServiceApi.md#core_service_update_upload_status) | **PUT** /api/v1/artifacts/{artifactId}/status | 
[**core_service_withdraw_pending_permission**](CoreServiceApi.md#core_service_withdraw_pending_permission) | **POST** /api/v1/permissions/withdraw | 


# **core_service_add_feature_set_permission**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_add_feature_set_permission(feature_set_id, body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.core_service_add_feature_set_permission_body import CoreServiceAddFeatureSetPermissionBody
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    body = CoreServiceAddFeatureSetPermissionBody(
        user_emails=[
            "user_emails_example",
        ],
        permission=V1PermissionType("Owner"),
    ) # CoreServiceAddFeatureSetPermissionBody | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_add_feature_set_permission(feature_set_id, body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_add_feature_set_permission: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **body** | [**CoreServiceAddFeatureSetPermissionBody**](CoreServiceAddFeatureSetPermissionBody.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_add_project_permission**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_add_project_permission(project_id, body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from h2o_featurestore.gen.model.core_service_add_project_permission_body import CoreServiceAddProjectPermissionBody
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    project_id = "projectId_example" # str | 
    body = CoreServiceAddProjectPermissionBody(
        user_emails=[
            "user_emails_example",
        ],
        permission=V1PermissionType("Owner"),
    ) # CoreServiceAddProjectPermissionBody | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_add_project_permission(project_id, body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_add_project_permission: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**|  |
 **body** | [**CoreServiceAddProjectPermissionBody**](CoreServiceAddProjectPermissionBody.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_admin_search_projects**
> V1ProjectSearchResults core_service_admin_search_projects()

Admin Search API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_project_search_results import V1ProjectSearchResults
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    query = "query_example" # str |  (optional)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    required_permission = "ACTIVE_PERMISSION_NONE" # str |  (optional) if omitted the server will use the default value of "ACTIVE_PERMISSION_NONE"
    project_ids = [
        "projectIds_example",
    ] # [str] |  (optional)
    sort_field = "PROJECT_SORT_FIELD_UNDEFINED" # str |  (optional) if omitted the server will use the default value of "PROJECT_SORT_FIELD_UNDEFINED"
    sort_direction = "SORT_ASC" # str |  (optional) if omitted the server will use the default value of "SORT_ASC"
    user_email = "userEmail_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        # Admin Search API
        api_response = api_instance.core_service_admin_search_projects(query=query, page_size=page_size, page_token=page_token, required_permission=required_permission, project_ids=project_ids, sort_field=sort_field, sort_direction=sort_direction, user_email=user_email)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_admin_search_projects: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**|  | [optional]
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **required_permission** | **str**|  | [optional] if omitted the server will use the default value of "ACTIVE_PERMISSION_NONE"
 **project_ids** | **[str]**|  | [optional]
 **sort_field** | **str**|  | [optional] if omitted the server will use the default value of "PROJECT_SORT_FIELD_UNDEFINED"
 **sort_direction** | **str**|  | [optional] if omitted the server will use the default value of "SORT_ASC"
 **user_email** | **str**|  | [optional]

### Return type

[**V1ProjectSearchResults**](V1ProjectSearchResults.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_approve_pending_permission**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_approve_pending_permission(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_approve_pending_permission_request import V1ApprovePendingPermissionRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1ApprovePendingPermissionRequest(
        permission_id="permission_id_example",
        reason="reason_example",
    ) # V1ApprovePendingPermissionRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_approve_pending_permission(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_approve_pending_permission: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1ApprovePendingPermissionRequest**](V1ApprovePendingPermissionRequest.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_approve_review**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_approve_review(review_id, reason)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    review_id = "reviewId_example" # str | 
    reason = "reason_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_approve_review(review_id, reason)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_approve_review: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **review_id** | **str**|  |
 **reason** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_cancel_job**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_cancel_job(job_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    job_id = "jobId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_cancel_job(job_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_cancel_job: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **job_id** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_create_draft_feature_set**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_create_draft_feature_set(body)

Draft Feature Set

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_set_draft_request import V1FeatureSetDraftRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1FeatureSetDraftRequest(
        project_id="project_id_example",
        name="name_example",
        description="description_example",
        tags=[
            "tags_example",
        ],
        cred=V1Credentials(
            aws=V1AWSCredentials(
                access_token="access_token_example",
                secret_token="secret_token_example",
                region="region_example",
                endpoint="endpoint_example",
                role_arn="role_arn_example",
                session_token="session_token_example",
            ),
            azure=V1AzureCredentials(
                account_name="account_name_example",
                account_key="account_key_example",
                sas_token="sas_token_example",
                sas_container="sas_container_example",
                sp_client_id="sp_client_id_example",
                sp_tenant_id="sp_tenant_id_example",
                sp_secret="sp_secret_example",
            ),
            snowflake=V1SnowflakeCredentials(
                user="user_example",
                password="password_example",
                pem_private_key="pem_private_key_example",
                passphrase="passphrase_example",
            ),
            jdbc_database=V1JDBCCredentials(
                user="user_example",
                password="password_example",
            ),
            mongo_db=V1MongoDbCredentials(
                user="user_example",
                password="password_example",
            ),
            drive={},
            gcp=V1GcpCredentials(
                credentials_file_content="credentials_file_content_example",
            ),
        ),
        data_source=V1RawDataLocation(
            csv=V1CSVFileSpec(
                path="path_example",
                delimiter="delimiter_example",
            ),
            parquet=V1ParquetFileSpec(
                path="path_example",
            ),
            snowflake=V1SnowflakeTableSpec(
                table="table_example",
                database="database_example",
                url="url_example",
                query="query_example",
                warehouse="warehouse_example",
                schema="schema_example",
                insecure=True,
                proxy=V1Proxy(
                    host="host_example",
                    port=1,
                    user="user_example",
                    password="password_example",
                ),
                role="role_example",
                account="account_example",
            ),
            jdbc=V1JDBCTableSpec(
                table="table_example",
                query="query_example",
                connection_url="connection_url_example",
                num_partitions=1,
                partition_column="partition_column_example",
                lower_bound="lower_bound_example",
                upper_bound="upper_bound_example",
                fetch_size=1,
            ),
            json=V1JSONFileSpec(
                path="path_example",
                multiline=True,
            ),
            delta_table=V1DeltaTableSpec(
                path="path_example",
                version=1,
                timestamp="timestamp_example",
                filter=V1Filter(
                    text=V1TextualFilter(
                        field="field_example",
                        value=[
                            "value_example",
                        ],
                        operator="operator_example",
                    ),
                    numeric=V1NumericalFilter(
                        field="field_example",
                        value=3.14,
                        operator="operator_example",
                    ),
                    boolean=V1BooleanFilter(
                        field="field_example",
                        value=True,
                        operator="operator_example",
                    ),
                ),
            ),
            csv_folder=V1CSVFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
                delimiter="delimiter_example",
            ),
            parquet_folder=V1ParquetFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
            ),
            json_folder=V1JSONFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
                multiline=True,
            ),
            online_source=V1OnlineSourceSpec(
                absolute_json_folder_path="absolute_json_folder_path_example",
            ),
            mongo_db=V1MongoDbCollectionSpec(
                connection_uri="connection_uri_example",
                database="database_example",
                collection="collection_example",
            ),
            google_big_query=V1BigQueryTableSpec(
                table="table_example",
                parent_project="parent_project_example",
                query="query_example",
                materialization_dataset="materialization_dataset_example",
            ),
        ),
        derived_from=V1DerivedInformation(
            feature_set_ids=[
                V1VersionedId(
                    id="id_example",
                    major_version=1,
                ),
            ],
            transformation=V1Transformation(
                mojo=V1MojoTransformation(
                    filename="filename_example",
                ),
                spark_pipeline=V1SparkPipelineTransformation(
                    filename="filename_example",
                ),
                join=V1JoinTransformation(
                    left_key="left_key_example",
                    right_key="right_key_example",
                    join_type=V1JoinType("JOIN_TYPE_INNER"),
                ),
            ),
        ),
    ) # V1FeatureSetDraftRequest | 

    # example passing only required values which don't have defaults set
    try:
        # Draft Feature Set
        api_response = api_instance.core_service_create_draft_feature_set(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_create_draft_feature_set: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1FeatureSetDraftRequest**](V1FeatureSetDraftRequest.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_create_feature_set_from_draft**
> V1DraftToFeatureSetResponse core_service_create_feature_set_from_draft(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_draft_to_feature_set_request import V1DraftToFeatureSetRequest
from h2o_featurestore.gen.model.v1_draft_to_feature_set_response import V1DraftToFeatureSetResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1DraftToFeatureSetRequest(
        id="id_example",
        project_id="project_id_example",
        name="name_example",
        description="description_example",
        schema=[
            V1FeatureSchemaDraft(
                name="name_example",
                data_type="data_type_example",
                nested=[],
                special_data=V1FeatureSchemaDraftSpecialData(
                    spi=True,
                    pci=True,
                    rpi=True,
                    demographic=True,
                    sensitive=True,
                ),
                feature_type=V1FeatureType("AUTOMATIC_DISCOVERY"),
                description="description_example",
                anomaly_detection=True,
                is_primary_key=True,
                is_partition_column=True,
            ),
        ],
        time_travel_column=DraftToFeatureSetRequestTimeTravelColumn(
            time_travel_column_name="time_travel_column_name_example",
            time_travel_column_format="time_travel_column_format_example",
            is_partition_column=True,
        ),
        tags=[
            "tags_example",
        ],
    ) # V1DraftToFeatureSetRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_create_feature_set_from_draft(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_create_feature_set_from_draft: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1DraftToFeatureSetRequest**](V1DraftToFeatureSetRequest.md)|  |

### Return type

[**V1DraftToFeatureSetResponse**](V1DraftToFeatureSetResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_create_feature_set_version_from_major_version_draft**
> V1MajorVersionDraftToFeatureSetVersionResponse core_service_create_feature_set_version_from_major_version_draft(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_major_version_draft_to_feature_set_version_request import V1MajorVersionDraftToFeatureSetVersionRequest
from h2o_featurestore.gen.model.v1_major_version_draft_to_feature_set_version_response import V1MajorVersionDraftToFeatureSetVersionResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1MajorVersionDraftToFeatureSetVersionRequest(
        id="id_example",
        project_id="project_id_example",
        schema=[
            V1FeatureSchemaDraft(
                name="name_example",
                data_type="data_type_example",
                nested=[],
                special_data=V1FeatureSchemaDraftSpecialData(
                    spi=True,
                    pci=True,
                    rpi=True,
                    demographic=True,
                    sensitive=True,
                ),
                feature_type=V1FeatureType("AUTOMATIC_DISCOVERY"),
                description="description_example",
                anomaly_detection=True,
                is_primary_key=True,
                is_partition_column=True,
            ),
        ],
        reason="reason_example",
        backfill_options=V1BackfillOptions(
            from_date=dateutil_parser('1970-01-01T00:00:00.00Z'),
            to_date=dateutil_parser('1970-01-01T00:00:00.00Z'),
            from_version="from_version_example",
            spark_pipeline=V1SparkPipelineTransformation(
                filename="filename_example",
            ),
            feature_mapping={
                "key": "key_example",
            },
        ),
        use_time_travel_column_as_partition=True,
        feature_set_id="feature_set_id_example",
        feature_set_version="feature_set_version_example",
        new_time_travel_column="new_time_travel_column_example",
        new_time_travel_column_format="new_time_travel_column_format_example",
    ) # V1MajorVersionDraftToFeatureSetVersionRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_create_feature_set_version_from_major_version_draft(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_create_feature_set_version_from_major_version_draft: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1MajorVersionDraftToFeatureSetVersionRequest**](V1MajorVersionDraftToFeatureSetVersionRequest.md)|  |

### Return type

[**V1MajorVersionDraftToFeatureSetVersionResponse**](V1MajorVersionDraftToFeatureSetVersionResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_create_gpt_chat_session**
> V1CreateGptChatSessionResponse core_service_create_gpt_chat_session(collection_id, body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_create_gpt_chat_session_response import V1CreateGptChatSessionResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    collection_id = "collectionId_example" # str | 
    body = {} # bool, date, datetime, dict, float, int, list, str, none_type | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_create_gpt_chat_session(collection_id, body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_create_gpt_chat_session: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **str**|  |
 **body** | **bool, date, datetime, dict, float, int, list, str, none_type**|  |

### Return type

[**V1CreateGptChatSessionResponse**](V1CreateGptChatSessionResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_create_major_version_draft_feature_set**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_create_major_version_draft_feature_set(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_set_major_version_draft_request import V1FeatureSetMajorVersionDraftRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1FeatureSetMajorVersionDraftRequest(
        project_id="project_id_example",
        name="name_example",
        feature_set_id="feature_set_id_example",
        feature_set_version="feature_set_version_example",
        reason="reason_example",
        cred=V1Credentials(
            aws=V1AWSCredentials(
                access_token="access_token_example",
                secret_token="secret_token_example",
                region="region_example",
                endpoint="endpoint_example",
                role_arn="role_arn_example",
                session_token="session_token_example",
            ),
            azure=V1AzureCredentials(
                account_name="account_name_example",
                account_key="account_key_example",
                sas_token="sas_token_example",
                sas_container="sas_container_example",
                sp_client_id="sp_client_id_example",
                sp_tenant_id="sp_tenant_id_example",
                sp_secret="sp_secret_example",
            ),
            snowflake=V1SnowflakeCredentials(
                user="user_example",
                password="password_example",
                pem_private_key="pem_private_key_example",
                passphrase="passphrase_example",
            ),
            jdbc_database=V1JDBCCredentials(
                user="user_example",
                password="password_example",
            ),
            mongo_db=V1MongoDbCredentials(
                user="user_example",
                password="password_example",
            ),
            drive={},
            gcp=V1GcpCredentials(
                credentials_file_content="credentials_file_content_example",
            ),
        ),
        data_source=V1RawDataLocation(
            csv=V1CSVFileSpec(
                path="path_example",
                delimiter="delimiter_example",
            ),
            parquet=V1ParquetFileSpec(
                path="path_example",
            ),
            snowflake=V1SnowflakeTableSpec(
                table="table_example",
                database="database_example",
                url="url_example",
                query="query_example",
                warehouse="warehouse_example",
                schema="schema_example",
                insecure=True,
                proxy=V1Proxy(
                    host="host_example",
                    port=1,
                    user="user_example",
                    password="password_example",
                ),
                role="role_example",
                account="account_example",
            ),
            jdbc=V1JDBCTableSpec(
                table="table_example",
                query="query_example",
                connection_url="connection_url_example",
                num_partitions=1,
                partition_column="partition_column_example",
                lower_bound="lower_bound_example",
                upper_bound="upper_bound_example",
                fetch_size=1,
            ),
            json=V1JSONFileSpec(
                path="path_example",
                multiline=True,
            ),
            delta_table=V1DeltaTableSpec(
                path="path_example",
                version=1,
                timestamp="timestamp_example",
                filter=V1Filter(
                    text=V1TextualFilter(
                        field="field_example",
                        value=[
                            "value_example",
                        ],
                        operator="operator_example",
                    ),
                    numeric=V1NumericalFilter(
                        field="field_example",
                        value=3.14,
                        operator="operator_example",
                    ),
                    boolean=V1BooleanFilter(
                        field="field_example",
                        value=True,
                        operator="operator_example",
                    ),
                ),
            ),
            csv_folder=V1CSVFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
                delimiter="delimiter_example",
            ),
            parquet_folder=V1ParquetFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
            ),
            json_folder=V1JSONFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
                multiline=True,
            ),
            online_source=V1OnlineSourceSpec(
                absolute_json_folder_path="absolute_json_folder_path_example",
            ),
            mongo_db=V1MongoDbCollectionSpec(
                connection_uri="connection_uri_example",
                database="database_example",
                collection="collection_example",
            ),
            google_big_query=V1BigQueryTableSpec(
                table="table_example",
                parent_project="parent_project_example",
                query="query_example",
                materialization_dataset="materialization_dataset_example",
            ),
        ),
    ) # V1FeatureSetMajorVersionDraftRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_create_major_version_draft_feature_set(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_create_major_version_draft_feature_set: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1FeatureSetMajorVersionDraftRequest**](V1FeatureSetMajorVersionDraftRequest.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_create_new_feature_set_version**
> V1FeatureSetResponse core_service_create_new_feature_set_version(feature_set_id, body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_set_response import V1FeatureSetResponse
from h2o_featurestore.gen.model.core_service_create_new_feature_set_version_body import CoreServiceCreateNewFeatureSetVersionBody
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    body = CoreServiceCreateNewFeatureSetVersionBody(
        schema=[
            V1FeatureSchema(
                name="name_example",
                data_type="data_type_example",
                nested=[],
                special_data=V1FeatureSchemaSpecialData(
                    spi=True,
                    pci=True,
                    rpi=True,
                    demographic=True,
                    sensitive=True,
                ),
                feature_type=V1FeatureType("AUTOMATIC_DISCOVERY"),
                description="description_example",
                classifiers=[
                    "classifiers_example",
                ],
                custom_data={},
                monitoring=V1FeatureSchemaMonitoring(
                    anomaly_detection=True,
                ),
            ),
        ],
        affected_features=[
            "affected_features_example",
        ],
        reason="reason_example",
        derived_from=V1DerivedInformation(
            feature_set_ids=[
                V1VersionedId(
                    id="id_example",
                    major_version=1,
                ),
            ],
            transformation=V1Transformation(
                mojo=V1MojoTransformation(
                    filename="filename_example",
                ),
                spark_pipeline=V1SparkPipelineTransformation(
                    filename="filename_example",
                ),
                join=V1JoinTransformation(
                    left_key="left_key_example",
                    right_key="right_key_example",
                    join_type=V1JoinType("JOIN_TYPE_INNER"),
                ),
            ),
        ),
        primary_key=[
            "primary_key_example",
        ],
        use_primary_key_from_previous_version=True,
        backfill_options=V1BackfillOptions(
            from_date=dateutil_parser('1970-01-01T00:00:00.00Z'),
            to_date=dateutil_parser('1970-01-01T00:00:00.00Z'),
            from_version="from_version_example",
            spark_pipeline=V1SparkPipelineTransformation(
                filename="filename_example",
            ),
            feature_mapping={
                "key": "key_example",
            },
        ),
        partition_by=[
            "partition_by_example",
        ],
        use_partition_by_from_previous_version=True,
        use_time_travel_column_as_partition=True,
        feature_set_version="feature_set_version_example",
        time_travel_column="time_travel_column_example",
        time_travel_column_format="time_travel_column_format_example",
        use_time_travel_column_from_previous_version=True,
        use_time_travel_column_format_from_previous_version=True,
    ) # CoreServiceCreateNewFeatureSetVersionBody | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_create_new_feature_set_version(feature_set_id, body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_create_new_feature_set_version: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **body** | [**CoreServiceCreateNewFeatureSetVersionBody**](CoreServiceCreateNewFeatureSetVersionBody.md)|  |

### Return type

[**V1FeatureSetResponse**](V1FeatureSetResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_create_project**
> V1CreateProjectResponse core_service_create_project(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_create_project_request import V1CreateProjectRequest
from h2o_featurestore.gen.model.v1_create_project_response import V1CreateProjectResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1CreateProjectRequest(
        project_name="project_name_example",
        description="description_example",
        custom_data={},
        access_modifier=V1AccessModifier("ACCESS_MODIFIER_UNSPECIFIED"),
    ) # V1CreateProjectRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_create_project(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_create_project: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1CreateProjectRequest**](V1CreateProjectRequest.md)|  |

### Return type

[**V1CreateProjectResponse**](V1CreateProjectResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_create_recommendation_classifier**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_create_recommendation_classifier(classifier)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_recommendation_classifier import V1RecommendationClassifier
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    classifier = V1RecommendationClassifier(
        name="name_example",
        regex=V1RecommendationRegexMatchingPolicy(
            regex="regex_example",
            percentage_match=1,
        ),
        sample=V1RecommendationSampleMatchingPolicy(
            feature_set_id="feature_set_id_example",
            feature_set_major_version=1,
            column_name="column_name_example",
            sample_fraction=3.14,
            fuzzy_distance=1,
            percentage_match=1,
        ),
    ) # V1RecommendationClassifier | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_create_recommendation_classifier(classifier)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_create_recommendation_classifier: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **classifier** | [**V1RecommendationClassifier**](V1RecommendationClassifier.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_delete_artifact**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_delete_artifact(artifact_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    artifact_id = "artifactId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_delete_artifact(artifact_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_delete_artifact: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artifact_id** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_delete_feature_set**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_delete_feature_set(feature_set_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_delete_feature_set(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_delete_feature_set: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_delete_feature_set_draft**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_delete_feature_set_draft(feature_set_draft_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_draft_id = "featureSetDraftId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_delete_feature_set_draft(feature_set_draft_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_delete_feature_set_draft: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_draft_id** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_delete_feature_set_version**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_delete_feature_set_version(feature_set_id, feature_set_major_version)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_major_version = 1 # int | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_delete_feature_set_version(feature_set_id, feature_set_major_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_delete_feature_set_version: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_major_version** | **int**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_delete_feature_set_version_in_review**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_delete_feature_set_version_in_review(review_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    review_id = "reviewId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_delete_feature_set_version_in_review(review_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_delete_feature_set_version_in_review: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **review_id** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_delete_project**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_delete_project(project_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    project_id = "projectId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_delete_project(project_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_delete_project: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_delete_recommendation_classifier**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_delete_recommendation_classifier(classifier_name)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    classifier_name = "classifierName_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_delete_recommendation_classifier(classifier_name)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_delete_recommendation_classifier: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **classifier_name** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_delete_scheduled_task**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_delete_scheduled_task(scheduled_task_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    scheduled_task_id = "scheduledTaskId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_delete_scheduled_task(scheduled_task_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_delete_scheduled_task: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scheduled_task_id** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_discard_feature_as_target**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_discard_feature_as_target(feature_set_id, feature_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_id = "featureId_example" # str | 
    feature_set_version = "featureSetVersion_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_discard_feature_as_target(feature_set_id, feature_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_discard_feature_as_target: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_discard_feature_as_target(feature_set_id, feature_id, feature_set_version=feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_discard_feature_as_target: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_id** | **str**|  |
 **feature_set_version** | **str**|  | [optional]

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_feature_set_exists**
> V1ExistsResponse core_service_feature_set_exists(feature_set_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_exists_response import V1ExistsResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    exclude_deleted = True # bool |  (optional)
    feature_set_major_version = 1 # int |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_feature_set_exists(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_feature_set_exists: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_feature_set_exists(feature_set_id, exclude_deleted=exclude_deleted, feature_set_major_version=feature_set_major_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_feature_set_exists: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **exclude_deleted** | **bool**|  | [optional]
 **feature_set_major_version** | **int**|  | [optional]

### Return type

[**V1ExistsResponse**](V1ExistsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_feature_set_schema_patch**
> V1FeatureSetSchemaPatchResponse core_service_feature_set_schema_patch(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_set_schema_patch_request import V1FeatureSetSchemaPatchRequest
from h2o_featurestore.gen.model.v1_feature_set_schema_patch_response import V1FeatureSetSchemaPatchResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1FeatureSetSchemaPatchRequest(
        original_schema=[
            V1FeatureSchema(
                name="name_example",
                data_type="data_type_example",
                nested=[],
                special_data=V1FeatureSchemaSpecialData(
                    spi=True,
                    pci=True,
                    rpi=True,
                    demographic=True,
                    sensitive=True,
                ),
                feature_type=V1FeatureType("AUTOMATIC_DISCOVERY"),
                description="description_example",
                classifiers=[
                    "classifiers_example",
                ],
                custom_data={},
                monitoring=V1FeatureSchemaMonitoring(
                    anomaly_detection=True,
                ),
            ),
        ],
        new_schema=[
            V1FeatureSchema(
                name="name_example",
                data_type="data_type_example",
                nested=[],
                special_data=V1FeatureSchemaSpecialData(
                    spi=True,
                    pci=True,
                    rpi=True,
                    demographic=True,
                    sensitive=True,
                ),
                feature_type=V1FeatureType("AUTOMATIC_DISCOVERY"),
                description="description_example",
                classifiers=[
                    "classifiers_example",
                ],
                custom_data={},
                monitoring=V1FeatureSchemaMonitoring(
                    anomaly_detection=True,
                ),
            ),
        ],
        compare_data_types=True,
    ) # V1FeatureSetSchemaPatchRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_feature_set_schema_patch(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_feature_set_schema_patch: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1FeatureSetSchemaPatchRequest**](V1FeatureSetSchemaPatchRequest.md)|  |

### Return type

[**V1FeatureSetSchemaPatchResponse**](V1FeatureSetSchemaPatchResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_generate_ingest_token**
> V1OnlineIngestionTokenResponse core_service_generate_ingest_token(feature_set_id, feature_set_version)

Online API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_online_ingestion_token_response import V1OnlineIngestionTokenResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_version = "featureSetVersion_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        # Online API
        api_response = api_instance.core_service_generate_ingest_token(feature_set_id, feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_generate_ingest_token: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_version** | **str**|  |

### Return type

[**V1OnlineIngestionTokenResponse**](V1OnlineIngestionTokenResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_generate_online_retrieval_token**
> V1OnlineRetrieveTokenResponse core_service_generate_online_retrieval_token(feature_set_id, feature_set_version)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_online_retrieve_token_response import V1OnlineRetrieveTokenResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_version = "featureSetVersion_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_generate_online_retrieval_token(feature_set_id, feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_generate_online_retrieval_token: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_version** | **str**|  |

### Return type

[**V1OnlineRetrieveTokenResponse**](V1OnlineRetrieveTokenResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_generate_temporary_upload**
> V1GenerateTemporaryUploadResponse core_service_generate_temporary_upload(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_generate_temporary_upload_request import V1GenerateTemporaryUploadRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from h2o_featurestore.gen.model.v1_generate_temporary_upload_response import V1GenerateTemporaryUploadResponse
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1GenerateTemporaryUploadRequest(
        files_with_md5_checksum={
            "key": "key_example",
        },
    ) # V1GenerateTemporaryUploadRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_generate_temporary_upload(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_generate_temporary_upload: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1GenerateTemporaryUploadRequest**](V1GenerateTemporaryUploadRequest.md)|  |

### Return type

[**V1GenerateTemporaryUploadResponse**](V1GenerateTemporaryUploadResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_generate_token**
> V1RawTokenResponse core_service_generate_token(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_raw_token_response import V1RawTokenResponse
from h2o_featurestore.gen.model.v1_generate_token_request import V1GenerateTokenRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1GenerateTokenRequest(
        name="name_example",
        description="description_example",
        expiry_date=dateutil_parser('1970-01-01T00:00:00.00Z'),
    ) # V1GenerateTokenRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_generate_token(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_generate_token: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1GenerateTokenRequest**](V1GenerateTokenRequest.md)|  |

### Return type

[**V1RawTokenResponse**](V1RawTokenResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_generate_transformation_upload**
> V1GenerateTransformationUploadResponse core_service_generate_transformation_upload(body)

Upload API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_generate_transformation_upload_response import V1GenerateTransformationUploadResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from h2o_featurestore.gen.model.v1_generate_transformation_upload_request import V1GenerateTransformationUploadRequest
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1GenerateTransformationUploadRequest(
        transformation_type=V1TransformationType("TransformationUnknown"),
        md5_checksum="md5_checksum_example",
    ) # V1GenerateTransformationUploadRequest | 

    # example passing only required values which don't have defaults set
    try:
        # Upload API
        api_response = api_instance.core_service_generate_transformation_upload(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_generate_transformation_upload: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1GenerateTransformationUploadRequest**](V1GenerateTransformationUploadRequest.md)|  |

### Return type

[**V1GenerateTransformationUploadResponse**](V1GenerateTransformationUploadResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_active_feature_set_permission**
> V1GetActivePermissionResponse core_service_get_active_feature_set_permission(resource_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_active_permission_response import V1GetActivePermissionResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    resource_id = "resourceId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_active_feature_set_permission(resource_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_active_feature_set_permission: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resource_id** | **str**|  |

### Return type

[**V1GetActivePermissionResponse**](V1GetActivePermissionResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_active_project_permission**
> V1GetActivePermissionResponse core_service_get_active_project_permission(resource_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_active_permission_response import V1GetActivePermissionResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    resource_id = "resourceId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_active_project_permission(resource_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_active_project_permission: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resource_id** | **str**|  |

### Return type

[**V1GetActivePermissionResponse**](V1GetActivePermissionResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_active_user**
> V1GetActiveUserResponse core_service_get_active_user()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_active_user_response import V1GetActiveUserResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)

    # example, this endpoint has no required or optional parameters
    try:
        api_response = api_instance.core_service_get_active_user()
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_active_user: %s\n" % e)
```


### Parameters
This endpoint does not need any parameter.

### Return type

[**V1GetActiveUserResponse**](V1GetActiveUserResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_api_config**
> V1GetApiConfigResponse core_service_get_api_config()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_api_config_response import V1GetApiConfigResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)

    # example, this endpoint has no required or optional parameters
    try:
        api_response = api_instance.core_service_get_api_config()
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_api_config: %s\n" % e)
```


### Parameters
This endpoint does not need any parameter.

### Return type

[**V1GetApiConfigResponse**](V1GetApiConfigResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_backfill_job_output**
> V1BackfillResponse core_service_get_backfill_job_output(job_id)

Backfill

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_backfill_response import V1BackfillResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    job_id = "jobId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        # Backfill
        api_response = api_instance.core_service_get_backfill_job_output(job_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_backfill_job_output: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **job_id** | **str**|  |

### Return type

[**V1BackfillResponse**](V1BackfillResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_code_snipped_id**
> V1CodeSnippedIdResponse core_service_get_code_snipped_id(feature_set_id, feature_set_major_version)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_code_snipped_id_response import V1CodeSnippedIdResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_major_version = 1 # int | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_code_snipped_id(feature_set_id, feature_set_major_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_code_snipped_id: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_major_version** | **int**|  |

### Return type

[**V1CodeSnippedIdResponse**](V1CodeSnippedIdResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_compute_recommendation_classifiers_job_output**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_get_compute_recommendation_classifiers_job_output(job_id)

ComputeRecommendationClassifier API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    job_id = "jobId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        # ComputeRecommendationClassifier API
        api_response = api_instance.core_service_get_compute_recommendation_classifiers_job_output(job_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_compute_recommendation_classifiers_job_output: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **job_id** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_compute_statistics_job_output**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_get_compute_statistics_job_output(job_id)

ComputeStatistics API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    job_id = "jobId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        # ComputeStatistics API
        api_response = api_instance.core_service_get_compute_statistics_job_output(job_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_compute_statistics_job_output: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **job_id** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_dashboard**
> V1DashboardResponse core_service_get_dashboard()

Dashboard API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_dashboard_response import V1DashboardResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)

    # example, this endpoint has no required or optional parameters
    try:
        # Dashboard API
        api_response = api_instance.core_service_get_dashboard()
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_dashboard: %s\n" % e)
```


### Parameters
This endpoint does not need any parameter.

### Return type

[**V1DashboardResponse**](V1DashboardResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_extract_schema_job_output**
> V1ExtractSchemaResponse core_service_get_extract_schema_job_output(job_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_extract_schema_response import V1ExtractSchemaResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    job_id = "jobId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_extract_schema_job_output(job_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_extract_schema_job_output: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **job_id** | **str**|  |

### Return type

[**V1ExtractSchemaResponse**](V1ExtractSchemaResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_feature**
> V1FeatureResponse core_service_get_feature(feature_set_id, feature_id)

Feature API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_response import V1FeatureResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_id = "featureId_example" # str | 
    feature_set_version = "featureSetVersion_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        # Feature API
        api_response = api_instance.core_service_get_feature(feature_set_id, feature_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        # Feature API
        api_response = api_instance.core_service_get_feature(feature_set_id, feature_id, feature_set_version=feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_id** | **str**|  |
 **feature_set_version** | **str**|  | [optional]

### Return type

[**V1FeatureResponse**](V1FeatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_feature_set**
> V1FeatureSetResponse core_service_get_feature_set(project_id, feature_set_name)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_set_response import V1FeatureSetResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    project_id = "projectId_example" # str | 
    feature_set_name = "featureSetName_example" # str | 
    version = "version_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_feature_set(project_id, feature_set_name)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_set: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_get_feature_set(project_id, feature_set_name, version=version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_set: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**|  |
 **feature_set_name** | **str**|  |
 **version** | **str**|  | [optional]

### Return type

[**V1FeatureSetResponse**](V1FeatureSetResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_feature_set_by_id**
> V1FeatureSetResponse core_service_get_feature_set_by_id(feature_set_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_set_response import V1FeatureSetResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_version = "featureSetVersion_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_feature_set_by_id(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_set_by_id: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_get_feature_set_by_id(feature_set_id, feature_set_version=feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_set_by_id: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_version** | **str**|  | [optional]

### Return type

[**V1FeatureSetResponse**](V1FeatureSetResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_feature_set_draft**
> V1FeatureSetDraftResponse core_service_get_feature_set_draft(feature_set_draft_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_set_draft_response import V1FeatureSetDraftResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_draft_id = "featureSetDraftId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_feature_set_draft(feature_set_draft_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_set_draft: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_draft_id** | **str**|  |

### Return type

[**V1FeatureSetDraftResponse**](V1FeatureSetDraftResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_feature_set_in_review**
> V1GetFeatureSetInReviewResponse core_service_get_feature_set_in_review(review_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_feature_set_in_review_response import V1GetFeatureSetInReviewResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    review_id = "reviewId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_feature_set_in_review(review_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_set_in_review: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **review_id** | **str**|  |

### Return type

[**V1GetFeatureSetInReviewResponse**](V1GetFeatureSetInReviewResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_feature_set_preview**
> V1GetFeatureSetPreviewResponse core_service_get_feature_set_preview(feature_set_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_feature_set_preview_response import V1GetFeatureSetPreviewResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_version = "featureSetVersion_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_feature_set_preview(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_set_preview: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_get_feature_set_preview(feature_set_id, feature_set_version=feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_set_preview: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_version** | **str**|  | [optional]

### Return type

[**V1GetFeatureSetPreviewResponse**](V1GetFeatureSetPreviewResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_feature_set_preview_in_review**
> V1GetFeatureSetPreviewInReviewResponse core_service_get_feature_set_preview_in_review(review_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_feature_set_preview_in_review_response import V1GetFeatureSetPreviewInReviewResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    review_id = "reviewId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_feature_set_preview_in_review(review_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_set_preview_in_review: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **review_id** | **str**|  |

### Return type

[**V1GetFeatureSetPreviewInReviewResponse**](V1GetFeatureSetPreviewInReviewResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_feature_set_preview_to_review**
> V1GetFeatureSetPreviewToReviewResponse core_service_get_feature_set_preview_to_review(review_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_feature_set_preview_to_review_response import V1GetFeatureSetPreviewToReviewResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    review_id = "reviewId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_feature_set_preview_to_review(review_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_set_preview_to_review: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **review_id** | **str**|  |

### Return type

[**V1GetFeatureSetPreviewToReviewResponse**](V1GetFeatureSetPreviewToReviewResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_feature_set_to_review**
> V1GetFeatureSetToReviewResponse core_service_get_feature_set_to_review(review_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_feature_set_to_review_response import V1GetFeatureSetToReviewResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    review_id = "reviewId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_feature_set_to_review(review_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_set_to_review: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **review_id** | **str**|  |

### Return type

[**V1GetFeatureSetToReviewResponse**](V1GetFeatureSetToReviewResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_feature_sets_derived_from**
> V1FeatureSetsDerivedFromResponse core_service_get_feature_sets_derived_from(feature_set_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_sets_derived_from_response import V1FeatureSetsDerivedFromResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_major_version = "featureSetMajorVersion_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_feature_sets_derived_from(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_sets_derived_from: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_get_feature_sets_derived_from(feature_set_id, feature_set_major_version=feature_set_major_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_sets_derived_from: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_major_version** | **str**|  | [optional]

### Return type

[**V1FeatureSetsDerivedFromResponse**](V1FeatureSetsDerivedFromResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_feature_sets_last_minor_for_current_major**
> V1FeatureSetResponse core_service_get_feature_sets_last_minor_for_current_major(feature_set_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_set_response import V1FeatureSetResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_version = "featureSetVersion_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_feature_sets_last_minor_for_current_major(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_sets_last_minor_for_current_major: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_get_feature_sets_last_minor_for_current_major(feature_set_id, feature_set_version=feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_sets_last_minor_for_current_major: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_version** | **str**|  | [optional]

### Return type

[**V1FeatureSetResponse**](V1FeatureSetResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_feature_sets_popularity**
> V1FeatureSetsPopularityResponse core_service_get_feature_sets_popularity()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_sets_popularity_response import V1FeatureSetsPopularityResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)

    # example, this endpoint has no required or optional parameters
    try:
        api_response = api_instance.core_service_get_feature_sets_popularity()
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_feature_sets_popularity: %s\n" % e)
```


### Parameters
This endpoint does not need any parameter.

### Return type

[**V1FeatureSetsPopularityResponse**](V1FeatureSetsPopularityResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_h2_o_gpte_config**
> V1GetGpteConfigResponse core_service_get_h2_o_gpte_config()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_gpte_config_response import V1GetGpteConfigResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)

    # example, this endpoint has no required or optional parameters
    try:
        api_response = api_instance.core_service_get_h2_o_gpte_config()
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_h2_o_gpte_config: %s\n" % e)
```


### Parameters
This endpoint does not need any parameter.

### Return type

[**V1GetGpteConfigResponse**](V1GetGpteConfigResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_ingest_history**
> V1GetIngestHistoryResponse core_service_get_ingest_history(feature_set_id, feature_set_version)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from h2o_featurestore.gen.model.v1_get_ingest_history_response import V1GetIngestHistoryResponse
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_version = "featureSetVersion_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_ingest_history(feature_set_id, feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_ingest_history: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_version** | **str**|  |

### Return type

[**V1GetIngestHistoryResponse**](V1GetIngestHistoryResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_ingest_job_output**
> V1IngestResponse core_service_get_ingest_job_output(job_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_ingest_response import V1IngestResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    job_id = "jobId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_ingest_job_output(job_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_ingest_job_output: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **job_id** | **str**|  |

### Return type

[**V1IngestResponse**](V1IngestResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_job**
> V1Job core_service_get_job(job_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_job import V1Job
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    job_id = "jobId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_job(job_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_job: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **job_id** | **str**|  |

### Return type

[**V1Job**](V1Job.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_job_progress**
> V1JobProgressOutput core_service_get_job_progress(job_id, next_index)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_job_progress_output import V1JobProgressOutput
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    job_id = "jobId_example" # str | 
    next_index = 1 # int | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_job_progress(job_id, next_index)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_job_progress: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **job_id** | **str**|  |
 **next_index** | **int**|  |

### Return type

[**V1JobProgressOutput**](V1JobProgressOutput.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_jobs_with_status_count**
> V1GetJobsWithStatusCountResponse core_service_get_jobs_with_status_count()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_jobs_with_status_count_response import V1GetJobsWithStatusCountResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    status_filter = "Created" # str |  (optional) if omitted the server will use the default value of "Created"

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_get_jobs_with_status_count(status_filter=status_filter)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_jobs_with_status_count: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **status_filter** | **str**|  | [optional] if omitted the server will use the default value of "Created"

### Return type

[**V1GetJobsWithStatusCountResponse**](V1GetJobsWithStatusCountResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_last_minor_feature_set_for_major_in_project**
> V1FeatureSetResponse core_service_get_last_minor_feature_set_for_major_in_project(project_id, feature_set_name, feature_set_major_version)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_set_response import V1FeatureSetResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    project_id = "projectId_example" # str | 
    feature_set_name = "featureSetName_example" # str | 
    feature_set_major_version = 1 # int | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_last_minor_feature_set_for_major_in_project(project_id, feature_set_name, feature_set_major_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_last_minor_feature_set_for_major_in_project: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**|  |
 **feature_set_name** | **str**|  |
 **feature_set_major_version** | **int**|  |

### Return type

[**V1FeatureSetResponse**](V1FeatureSetResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_lazy_ingest_task**
> V1ScheduledTaskResponse core_service_get_lazy_ingest_task(feature_set_id, feature_set_version)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_scheduled_task_response import V1ScheduledTaskResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_version = "featureSetVersion_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_lazy_ingest_task(feature_set_id, feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_lazy_ingest_task: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_version** | **str**|  |

### Return type

[**V1ScheduledTaskResponse**](V1ScheduledTaskResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_listable_feature_set**
> V1ListableFeatureSetResponse core_service_get_listable_feature_set(feature_set_id)

Listable FeatureSet API (in future will be moved to new file)

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_listable_feature_set_response import V1ListableFeatureSetResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_version = "featureSetVersion_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        # Listable FeatureSet API (in future will be moved to new file)
        api_response = api_instance.core_service_get_listable_feature_set(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_listable_feature_set: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        # Listable FeatureSet API (in future will be moved to new file)
        api_response = api_instance.core_service_get_listable_feature_set(feature_set_id, feature_set_version=feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_listable_feature_set: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_version** | **str**|  | [optional]

### Return type

[**V1ListableFeatureSetResponse**](V1ListableFeatureSetResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_listable_feature_set_in_review**
> V1GetListableFeatureSetInReviewResponse core_service_get_listable_feature_set_in_review(review_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_listable_feature_set_in_review_response import V1GetListableFeatureSetInReviewResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    review_id = "reviewId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_listable_feature_set_in_review(review_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_listable_feature_set_in_review: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **review_id** | **str**|  |

### Return type

[**V1GetListableFeatureSetInReviewResponse**](V1GetListableFeatureSetInReviewResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_listable_feature_set_to_review**
> V1GetListableFeatureSetToReviewResponse core_service_get_listable_feature_set_to_review(review_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_listable_feature_set_to_review_response import V1GetListableFeatureSetToReviewResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    review_id = "reviewId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_listable_feature_set_to_review(review_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_listable_feature_set_to_review: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **review_id** | **str**|  |

### Return type

[**V1GetListableFeatureSetToReviewResponse**](V1GetListableFeatureSetToReviewResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_materialization_online_job_output**
> V1MaterializationOnlineResponse core_service_get_materialization_online_job_output(job_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_materialization_online_response import V1MaterializationOnlineResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    job_id = "jobId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_materialization_online_job_output(job_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_materialization_online_job_output: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **job_id** | **str**|  |

### Return type

[**V1MaterializationOnlineResponse**](V1MaterializationOnlineResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_online_retrieve_meta**
> V1OnlineRetrieveMeta core_service_get_online_retrieve_meta()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_online_retrieve_meta import V1OnlineRetrieveMeta
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)

    # example, this endpoint has no required or optional parameters
    try:
        api_response = api_instance.core_service_get_online_retrieve_meta()
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_online_retrieve_meta: %s\n" % e)
```


### Parameters
This endpoint does not need any parameter.

### Return type

[**V1OnlineRetrieveMeta**](V1OnlineRetrieveMeta.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_optimize_storage_job_output**
> V1OptimizeStorageResponse core_service_get_optimize_storage_job_output(job_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_optimize_storage_response import V1OptimizeStorageResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    job_id = "jobId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_optimize_storage_job_output(job_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_optimize_storage_job_output: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **job_id** | **str**|  |

### Return type

[**V1OptimizeStorageResponse**](V1OptimizeStorageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_project_by_id**
> V1ProjectResponse core_service_get_project_by_id(project_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_project_response import V1ProjectResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    project_id = "projectId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_project_by_id(project_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_project_by_id: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**|  |

### Return type

[**V1ProjectResponse**](V1ProjectResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_recently_used_feature_sets**
> V1RecentlyUsedFeatureSetsResponse core_service_get_recently_used_feature_sets()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from h2o_featurestore.gen.model.v1_recently_used_feature_sets_response import V1RecentlyUsedFeatureSetsResponse
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)

    # example, this endpoint has no required or optional parameters
    try:
        api_response = api_instance.core_service_get_recently_used_feature_sets()
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_recently_used_feature_sets: %s\n" % e)
```


### Parameters
This endpoint does not need any parameter.

### Return type

[**V1RecentlyUsedFeatureSetsResponse**](V1RecentlyUsedFeatureSetsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_recently_used_projects**
> V1RecentlyUsedProjectsResponse core_service_get_recently_used_projects()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_recently_used_projects_response import V1RecentlyUsedProjectsResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)

    # example, this endpoint has no required or optional parameters
    try:
        api_response = api_instance.core_service_get_recently_used_projects()
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_recently_used_projects: %s\n" % e)
```


### Parameters
This endpoint does not need any parameter.

### Return type

[**V1RecentlyUsedProjectsResponse**](V1RecentlyUsedProjectsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_recommendations**
> V1GetRecommendationResponse core_service_get_recommendations(feature_set_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_recommendation_response import V1GetRecommendationResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_recommendations(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_recommendations: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |

### Return type

[**V1GetRecommendationResponse**](V1GetRecommendationResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_retrieve_as_links_job_output**
> V1RetrieveAsLinksResponse core_service_get_retrieve_as_links_job_output(job_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_retrieve_as_links_response import V1RetrieveAsLinksResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    job_id = "jobId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_retrieve_as_links_job_output(job_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_retrieve_as_links_job_output: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **job_id** | **str**|  |

### Return type

[**V1RetrieveAsLinksResponse**](V1RetrieveAsLinksResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_revert_ingest_job_output**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_get_revert_ingest_job_output(job_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    job_id = "jobId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_revert_ingest_job_output(job_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_revert_ingest_job_output: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **job_id** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_scheduled_task**
> V1ScheduledTaskResponse core_service_get_scheduled_task(scheduled_task_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_scheduled_task_response import V1ScheduledTaskResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    scheduled_task_id = "scheduledTaskId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_scheduled_task(scheduled_task_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_scheduled_task: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scheduled_task_id** | **str**|  |

### Return type

[**V1ScheduledTaskResponse**](V1ScheduledTaskResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_token**
> V1TokenResponse core_service_get_token(token_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_token_response import V1TokenResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    token_id = "tokenId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_token(token_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_token: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **token_id** | **str**|  |

### Return type

[**V1TokenResponse**](V1TokenResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_tokens_config**
> V1TokensConfigResponse core_service_get_tokens_config()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_tokens_config_response import V1TokensConfigResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)

    # example, this endpoint has no required or optional parameters
    try:
        api_response = api_instance.core_service_get_tokens_config()
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_tokens_config: %s\n" % e)
```


### Parameters
This endpoint does not need any parameter.

### Return type

[**V1TokensConfigResponse**](V1TokensConfigResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_user_active_feature_set_permissions**
> V1GetUserPermissionsResponse core_service_get_user_active_feature_set_permissions(resource_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_user_permissions_response import V1GetUserPermissionsResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    resource_id = "resourceId_example" # str | 
    permission_filters = [
        "Owner",
    ] # [str] |  (optional)
    query = "query_example" # str |  (optional)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_user_active_feature_set_permissions(resource_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_user_active_feature_set_permissions: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_get_user_active_feature_set_permissions(resource_id, permission_filters=permission_filters, query=query, page_size=page_size, page_token=page_token)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_user_active_feature_set_permissions: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resource_id** | **str**|  |
 **permission_filters** | **[str]**|  | [optional]
 **query** | **str**|  | [optional]
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]

### Return type

[**V1GetUserPermissionsResponse**](V1GetUserPermissionsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_user_active_project_permissions**
> V1GetUserPermissionsResponse core_service_get_user_active_project_permissions(resource_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_user_permissions_response import V1GetUserPermissionsResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    resource_id = "resourceId_example" # str | 
    permission_filters = [
        "Owner",
    ] # [str] |  (optional)
    query = "query_example" # str |  (optional)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_user_active_project_permissions(resource_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_user_active_project_permissions: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_get_user_active_project_permissions(resource_id, permission_filters=permission_filters, query=query, page_size=page_size, page_token=page_token)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_user_active_project_permissions: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resource_id** | **str**|  |
 **permission_filters** | **[str]**|  | [optional]
 **query** | **str**|  | [optional]
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]

### Return type

[**V1GetUserPermissionsResponse**](V1GetUserPermissionsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_user_feature_set_permissions**
> V1GetUserPermissionsResponse core_service_get_user_feature_set_permissions(resource_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_user_permissions_response import V1GetUserPermissionsResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    resource_id = "resourceId_example" # str | 
    permission_filter = "Owner" # str |  (optional) if omitted the server will use the default value of "Owner"
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_user_feature_set_permissions(resource_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_user_feature_set_permissions: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_get_user_feature_set_permissions(resource_id, permission_filter=permission_filter, page_size=page_size, page_token=page_token)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_user_feature_set_permissions: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resource_id** | **str**|  |
 **permission_filter** | **str**|  | [optional] if omitted the server will use the default value of "Owner"
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]

### Return type

[**V1GetUserPermissionsResponse**](V1GetUserPermissionsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_user_project_permissions**
> V1GetUserPermissionsResponse core_service_get_user_project_permissions(resource_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_user_permissions_response import V1GetUserPermissionsResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    resource_id = "resourceId_example" # str | 
    permission_filter = "Owner" # str |  (optional) if omitted the server will use the default value of "Owner"
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_user_project_permissions(resource_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_user_project_permissions: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_get_user_project_permissions(resource_id, permission_filter=permission_filter, page_size=page_size, page_token=page_token)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_user_project_permissions: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resource_id** | **str**|  |
 **permission_filter** | **str**|  | [optional] if omitted the server will use the default value of "Owner"
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]

### Return type

[**V1GetUserPermissionsResponse**](V1GetUserPermissionsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_users_without_feature_set_permissions**
> V1GetUsersWithoutPermissionResponse core_service_get_users_without_feature_set_permissions(resource_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_users_without_permission_response import V1GetUsersWithoutPermissionResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    resource_id = "resourceId_example" # str | 
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_users_without_feature_set_permissions(resource_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_users_without_feature_set_permissions: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_get_users_without_feature_set_permissions(resource_id, page_size=page_size, page_token=page_token)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_users_without_feature_set_permissions: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resource_id** | **str**|  |
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]

### Return type

[**V1GetUsersWithoutPermissionResponse**](V1GetUsersWithoutPermissionResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_users_without_project_permissions**
> V1GetUsersWithoutPermissionResponse core_service_get_users_without_project_permissions(resource_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_users_without_permission_response import V1GetUsersWithoutPermissionResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    resource_id = "resourceId_example" # str | 
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_get_users_without_project_permissions(resource_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_users_without_project_permissions: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_get_users_without_project_permissions(resource_id, page_size=page_size, page_token=page_token)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_users_without_project_permissions: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resource_id** | **str**|  |
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]

### Return type

[**V1GetUsersWithoutPermissionResponse**](V1GetUsersWithoutPermissionResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_version**
> V1GetVersionResponse core_service_get_version()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_version_response import V1GetVersionResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)

    # example, this endpoint has no required or optional parameters
    try:
        api_response = api_instance.core_service_get_version()
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_version: %s\n" % e)
```


### Parameters
This endpoint does not need any parameter.

### Return type

[**V1GetVersionResponse**](V1GetVersionResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_get_web_config**
> V1GetWebConfigResponse core_service_get_web_config()

Config API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_get_web_config_response import V1GetWebConfigResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)

    # example, this endpoint has no required or optional parameters
    try:
        # Config API
        api_response = api_instance.core_service_get_web_config()
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_get_web_config: %s\n" % e)
```


### Parameters
This endpoint does not need any parameter.

### Return type

[**V1GetWebConfigResponse**](V1GetWebConfigResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_has_permission_to_retrieve**
> V1HasPermissionToRetrieveResponse core_service_has_permission_to_retrieve(project_name, feature_set_name)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_has_permission_to_retrieve_response import V1HasPermissionToRetrieveResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    project_name = "projectName_example" # str | 
    feature_set_name = "featureSetName_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_has_permission_to_retrieve(project_name, feature_set_name)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_has_permission_to_retrieve: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_name** | **str**|  |
 **feature_set_name** | **str**|  |

### Return type

[**V1HasPermissionToRetrieveResponse**](V1HasPermissionToRetrieveResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_is_feature_set_pinned**
> V1IsFeatureSetPinnedResponse core_service_is_feature_set_pinned(feature_set_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_is_feature_set_pinned_response import V1IsFeatureSetPinnedResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_is_feature_set_pinned(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_is_feature_set_pinned: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |

### Return type

[**V1IsFeatureSetPinnedResponse**](V1IsFeatureSetPinnedResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_is_feature_set_schema_compatible**
> V1FeatureSetSchemaCompatibilityResponse core_service_is_feature_set_schema_compatible(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_set_schema_compatibility_request import V1FeatureSetSchemaCompatibilityRequest
from h2o_featurestore.gen.model.v1_feature_set_schema_compatibility_response import V1FeatureSetSchemaCompatibilityResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1FeatureSetSchemaCompatibilityRequest(
        original_schema=[
            V1FeatureSchema(
                name="name_example",
                data_type="data_type_example",
                nested=[],
                special_data=V1FeatureSchemaSpecialData(
                    spi=True,
                    pci=True,
                    rpi=True,
                    demographic=True,
                    sensitive=True,
                ),
                feature_type=V1FeatureType("AUTOMATIC_DISCOVERY"),
                description="description_example",
                classifiers=[
                    "classifiers_example",
                ],
                custom_data={},
                monitoring=V1FeatureSchemaMonitoring(
                    anomaly_detection=True,
                ),
            ),
        ],
        new_schema=[
            V1FeatureSchema(
                name="name_example",
                data_type="data_type_example",
                nested=[],
                special_data=V1FeatureSchemaSpecialData(
                    spi=True,
                    pci=True,
                    rpi=True,
                    demographic=True,
                    sensitive=True,
                ),
                feature_type=V1FeatureType("AUTOMATIC_DISCOVERY"),
                description="description_example",
                classifiers=[
                    "classifiers_example",
                ],
                custom_data={},
                monitoring=V1FeatureSchemaMonitoring(
                    anomaly_detection=True,
                ),
            ),
        ],
        compare_data_types=True,
    ) # V1FeatureSetSchemaCompatibilityRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_is_feature_set_schema_compatible(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_is_feature_set_schema_compatible: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1FeatureSetSchemaCompatibilityRequest**](V1FeatureSetSchemaCompatibilityRequest.md)|  |

### Return type

[**V1FeatureSetSchemaCompatibilityResponse**](V1FeatureSetSchemaCompatibilityResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_artifacts**
> V1ListArtifactsResponse core_service_list_artifacts(feature_set_id, feature_set_major_version)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_artifacts_response import V1ListArtifactsResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_major_version = 1 # int | 
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_list_artifacts(feature_set_id, feature_set_major_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_artifacts: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_artifacts(feature_set_id, feature_set_major_version, page_size=page_size, page_token=page_token)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_artifacts: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_major_version** | **int**|  |
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]

### Return type

[**V1ListArtifactsResponse**](V1ListArtifactsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_feature_set_drafts**
> V1ListFeatureSetDraftsResponse core_service_list_feature_set_drafts()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_feature_set_drafts_response import V1ListFeatureSetDraftsResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_feature_set_drafts(page_size=page_size, page_token=page_token)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_feature_set_drafts: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]

### Return type

[**V1ListFeatureSetDraftsResponse**](V1ListFeatureSetDraftsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_feature_set_versions**
> V1ListFeatureSetVersionsResponse core_service_list_feature_set_versions(feature_set_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_feature_set_versions_response import V1ListFeatureSetVersionsResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_list_feature_set_versions(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_feature_set_versions: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |

### Return type

[**V1ListFeatureSetVersionsResponse**](V1ListFeatureSetVersionsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_feature_sets_page**
> V1ListFeatureSetsPageResponse core_service_list_feature_sets_page()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from h2o_featurestore.gen.model.v1_list_feature_sets_page_response import V1ListFeatureSetsPageResponse
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    project_names = [
        "projectNames_example",
    ] # [str] |  (optional)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_feature_sets_page(project_names=project_names, page_size=page_size, page_token=page_token)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_feature_sets_page: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_names** | **[str]**|  | [optional]
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]

### Return type

[**V1ListFeatureSetsPageResponse**](V1ListFeatureSetsPageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_feature_sets_permissions_page**
> V1ListFeatureSetsPermissionsPageResponse core_service_list_feature_sets_permissions_page()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_feature_sets_permissions_page_response import V1ListFeatureSetsPermissionsPageResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    filters = [
        "PENDING",
    ] # [str] |  (optional)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    resource_id = "resourceId_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_feature_sets_permissions_page(filters=filters, page_size=page_size, page_token=page_token, resource_id=resource_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_feature_sets_permissions_page: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **filters** | **[str]**|  | [optional]
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **resource_id** | **str**|  | [optional]

### Return type

[**V1ListFeatureSetsPermissionsPageResponse**](V1ListFeatureSetsPermissionsPageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_feature_sets_reviews_page**
> V1ListFeatureSetReviewsPageResponse core_service_list_feature_sets_reviews_page()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_feature_set_reviews_page_response import V1ListFeatureSetReviewsPageResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    filters = [
        "REVIEW_STATUS_UNSPECIFIED",
    ] # [str] |  (optional)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    project_id = "projectId_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_feature_sets_reviews_page(filters=filters, page_size=page_size, page_token=page_token, project_id=project_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_feature_sets_reviews_page: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **filters** | **[str]**|  | [optional]
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **project_id** | **str**|  | [optional]

### Return type

[**V1ListFeatureSetReviewsPageResponse**](V1ListFeatureSetReviewsPageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_feature_sets_to_review**
> V1ListFeatureSetsToReviewResponse core_service_list_feature_sets_to_review()

Feature Set Review

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_feature_sets_to_review_response import V1ListFeatureSetsToReviewResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    filters = [
        "REVIEW_STATUS_UNSPECIFIED",
    ] # [str] |  (optional)
    project_id = "projectId_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        # Feature Set Review
        api_response = api_instance.core_service_list_feature_sets_to_review(page_size=page_size, page_token=page_token, filters=filters, project_id=project_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_feature_sets_to_review: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **filters** | **[str]**|  | [optional]
 **project_id** | **str**|  | [optional]

### Return type

[**V1ListFeatureSetsToReviewResponse**](V1ListFeatureSetsToReviewResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_features**
> V1ListFeaturesResponse core_service_list_features(feature_set_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_features_response import V1ListFeaturesResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    query = "query_example" # str |  (optional)
    feature_set_version = "featureSetVersion_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_list_features(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_features: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_features(feature_set_id, page_size=page_size, page_token=page_token, query=query, feature_set_version=feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_features: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **query** | **str**|  | [optional]
 **feature_set_version** | **str**|  | [optional]

### Return type

[**V1ListFeaturesResponse**](V1ListFeaturesResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_features_in_review**
> V1ListFeaturesInReviewResponse core_service_list_features_in_review(review_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_features_in_review_response import V1ListFeaturesInReviewResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    review_id = "reviewId_example" # str | 
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    query = "query_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_list_features_in_review(review_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_features_in_review: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_features_in_review(review_id, page_size=page_size, page_token=page_token, query=query)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_features_in_review: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **review_id** | **str**|  |
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **query** | **str**|  | [optional]

### Return type

[**V1ListFeaturesInReviewResponse**](V1ListFeaturesInReviewResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_features_to_review**
> V1ListFeaturesToReviewResponse core_service_list_features_to_review(review_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_features_to_review_response import V1ListFeaturesToReviewResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    review_id = "reviewId_example" # str | 
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    query = "query_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_list_features_to_review(review_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_features_to_review: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_features_to_review(review_id, page_size=page_size, page_token=page_token, query=query)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_features_to_review: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **review_id** | **str**|  |
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **query** | **str**|  | [optional]

### Return type

[**V1ListFeaturesToReviewResponse**](V1ListFeaturesToReviewResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_jobs**
> V1ListJobsResponse core_service_list_jobs()

Jobs API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_jobs_response import V1ListJobsResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    active = True # bool |  (optional)
    job_type = "Unknown" # str |  - Unknown: default (optional) if omitted the server will use the default value of "Unknown"
    feature_set_id = "featureSetId_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        # Jobs API
        api_response = api_instance.core_service_list_jobs(active=active, job_type=job_type, feature_set_id=feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_jobs: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **active** | **bool**|  | [optional]
 **job_type** | **str**|  - Unknown: default | [optional] if omitted the server will use the default value of "Unknown"
 **feature_set_id** | **str**|  | [optional]

### Return type

[**V1ListJobsResponse**](V1ListJobsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_jobs_page_by_feature_set_id**
> V1ListJobsPageResponse core_service_list_jobs_page_by_feature_set_id()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_jobs_page_response import V1ListJobsPageResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    status_filter = "Created" # str |  (optional) if omitted the server will use the default value of "Created"
    feature_set_id = "featureSetId_example" # str |  (optional)
    job_type_filters = [
        "Unknown",
    ] # [str] |  - Unknown: default (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_jobs_page_by_feature_set_id(page_size=page_size, page_token=page_token, status_filter=status_filter, feature_set_id=feature_set_id, job_type_filters=job_type_filters)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_jobs_page_by_feature_set_id: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **status_filter** | **str**|  | [optional] if omitted the server will use the default value of "Created"
 **feature_set_id** | **str**|  | [optional]
 **job_type_filters** | **[str]**|  - Unknown: default | [optional]

### Return type

[**V1ListJobsPageResponse**](V1ListJobsPageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_jobs_page_by_feature_set_name**
> V1ListJobsPageResponse core_service_list_jobs_page_by_feature_set_name()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_jobs_page_response import V1ListJobsPageResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    status_filter = "Created" # str |  (optional) if omitted the server will use the default value of "Created"
    feature_set_name_query = "featureSetNameQuery_example" # str |  (optional)
    job_type_filters = [
        "Unknown",
    ] # [str] |  - Unknown: default (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_jobs_page_by_feature_set_name(page_size=page_size, page_token=page_token, status_filter=status_filter, feature_set_name_query=feature_set_name_query, job_type_filters=job_type_filters)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_jobs_page_by_feature_set_name: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **status_filter** | **str**|  | [optional] if omitted the server will use the default value of "Created"
 **feature_set_name_query** | **str**|  | [optional]
 **job_type_filters** | **[str]**|  - Unknown: default | [optional]

### Return type

[**V1ListJobsPageResponse**](V1ListJobsPageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_manageable_feature_sets_permissions_page**
> V1ListFeatureSetsPermissionsPageResponse core_service_list_manageable_feature_sets_permissions_page()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_feature_sets_permissions_page_response import V1ListFeatureSetsPermissionsPageResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    filters = [
        "PENDING",
    ] # [str] |  (optional)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    resource_id = "resourceId_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_manageable_feature_sets_permissions_page(filters=filters, page_size=page_size, page_token=page_token, resource_id=resource_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_manageable_feature_sets_permissions_page: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **filters** | **[str]**|  | [optional]
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **resource_id** | **str**|  | [optional]

### Return type

[**V1ListFeatureSetsPermissionsPageResponse**](V1ListFeatureSetsPermissionsPageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_manageable_project_permissions_page**
> V1ListProjectsPermissionsPageResponse core_service_list_manageable_project_permissions_page()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_projects_permissions_page_response import V1ListProjectsPermissionsPageResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    filters = [
        "PENDING",
    ] # [str] |  (optional)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    resource_id = "resourceId_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_manageable_project_permissions_page(filters=filters, page_size=page_size, page_token=page_token, resource_id=resource_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_manageable_project_permissions_page: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **filters** | **[str]**|  | [optional]
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **resource_id** | **str**|  | [optional]

### Return type

[**V1ListProjectsPermissionsPageResponse**](V1ListProjectsPermissionsPageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_personal_access_tokens**
> V1ListPersonalAccessTokensResponse core_service_list_personal_access_tokens()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_personal_access_tokens_response import V1ListPersonalAccessTokensResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    query = "query_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_personal_access_tokens(page_size=page_size, page_token=page_token, query=query)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_personal_access_tokens: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **query** | **str**|  | [optional]

### Return type

[**V1ListPersonalAccessTokensResponse**](V1ListPersonalAccessTokensResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_pinned_feature_sets**
> V1PinnedFeatureSetsResponse core_service_list_pinned_feature_sets()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_pinned_feature_sets_response import V1PinnedFeatureSetsResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_pinned_feature_sets(page_size=page_size, page_token=page_token)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_pinned_feature_sets: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]

### Return type

[**V1PinnedFeatureSetsResponse**](V1PinnedFeatureSetsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_project_history_page**
> V1ListProjectHistoryPageResponse core_service_list_project_history_page(project_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_project_history_page_response import V1ListProjectHistoryPageResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    project_id = "projectId_example" # str | 
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_list_project_history_page(project_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_project_history_page: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_project_history_page(project_id, page_size=page_size, page_token=page_token)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_project_history_page: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**|  |
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]

### Return type

[**V1ListProjectHistoryPageResponse**](V1ListProjectHistoryPageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_project_permissions_page**
> V1ListProjectsPermissionsPageResponse core_service_list_project_permissions_page()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_projects_permissions_page_response import V1ListProjectsPermissionsPageResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    filters = [
        "PENDING",
    ] # [str] |  (optional)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    resource_id = "resourceId_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_project_permissions_page(filters=filters, page_size=page_size, page_token=page_token, resource_id=resource_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_project_permissions_page: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **filters** | **[str]**|  | [optional]
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **resource_id** | **str**|  | [optional]

### Return type

[**V1ListProjectsPermissionsPageResponse**](V1ListProjectsPermissionsPageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_projects_page**
> V1ListProjectsPageResponse core_service_list_projects_page()

Project API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_projects_page_response import V1ListProjectsPageResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        # Project API
        api_response = api_instance.core_service_list_projects_page(page_size=page_size, page_token=page_token)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_projects_page: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]

### Return type

[**V1ListProjectsPageResponse**](V1ListProjectsPageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_recent_gpt_collections**
> V1ListRecentGptCollectionsResponse core_service_list_recent_gpt_collections()

H2O GPT

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from h2o_featurestore.gen.model.v1_list_recent_gpt_collections_response import V1ListRecentGptCollectionsResponse
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    offset = 1 # int |  (optional)
    limit = 1 # int |  (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        # H2O GPT
        api_response = api_instance.core_service_list_recent_gpt_collections(offset=offset, limit=limit)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_recent_gpt_collections: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **int**|  | [optional]
 **limit** | **int**|  | [optional]

### Return type

[**V1ListRecentGptCollectionsResponse**](V1ListRecentGptCollectionsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_recommendation_classifiers**
> V1ListRecommendationClassifierResponse core_service_list_recommendation_classifiers()

Recommendation API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_recommendation_classifier_response import V1ListRecommendationClassifierResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)

    # example, this endpoint has no required or optional parameters
    try:
        # Recommendation API
        api_response = api_instance.core_service_list_recommendation_classifiers()
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_recommendation_classifiers: %s\n" % e)
```


### Parameters
This endpoint does not need any parameter.

### Return type

[**V1ListRecommendationClassifierResponse**](V1ListRecommendationClassifierResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_scheduled_task_execution_history**
> V1ListScheduledTaskExecutionsResponse core_service_list_scheduled_task_execution_history(scheduled_task_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_scheduled_task_executions_response import V1ListScheduledTaskExecutionsResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    scheduled_task_id = "scheduledTaskId_example" # str | 
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_list_scheduled_task_execution_history(scheduled_task_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_scheduled_task_execution_history: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_scheduled_task_execution_history(scheduled_task_id, page_size=page_size, page_token=page_token)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_scheduled_task_execution_history: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scheduled_task_id** | **str**|  |
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]

### Return type

[**V1ListScheduledTaskExecutionsResponse**](V1ListScheduledTaskExecutionsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_scheduled_tasks**
> V1ListScheduledTasksResponse core_service_list_scheduled_tasks(feature_set_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_scheduled_tasks_response import V1ListScheduledTasksResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_list_scheduled_tasks(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_scheduled_tasks: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_scheduled_tasks(feature_set_id, page_size=page_size, page_token=page_token)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_scheduled_tasks: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]

### Return type

[**V1ListScheduledTasksResponse**](V1ListScheduledTasksResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_list_target_features**
> V1ListTargetFeaturesResponse core_service_list_target_features(feature_set_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_list_target_features_response import V1ListTargetFeaturesResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_version = "featureSetVersion_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_list_target_features(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_target_features: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_list_target_features(feature_set_id, feature_set_version=feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_list_target_features: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_version** | **str**|  | [optional]

### Return type

[**V1ListTargetFeaturesResponse**](V1ListTargetFeaturesResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_mark_feature_as_target**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_mark_feature_as_target(feature_set_id, feature_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_id = "featureId_example" # str | 
    feature_set_version = "featureSetVersion_example" # str |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_mark_feature_as_target(feature_set_id, feature_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_mark_feature_as_target: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_mark_feature_as_target(feature_set_id, feature_id, feature_set_version=feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_mark_feature_as_target: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_id** | **str**|  |
 **feature_set_version** | **str**|  | [optional]

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_pause_scheduled_task**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_pause_scheduled_task(scheduled_task_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    scheduled_task_id = "scheduledTaskId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_pause_scheduled_task(scheduled_task_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_pause_scheduled_task: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scheduled_task_id** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_pin_feature_set**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_pin_feature_set(feature_set_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_pin_feature_set(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_pin_feature_set: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_project_exists**
> V1ExistsResponse core_service_project_exists(project_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_exists_response import V1ExistsResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    project_id = "projectId_example" # str | 
    exclude_deleted = True # bool |  (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_project_exists(project_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_project_exists: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_project_exists(project_id, exclude_deleted=exclude_deleted)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_project_exists: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**|  |
 **exclude_deleted** | **bool**|  | [optional]

### Return type

[**V1ExistsResponse**](V1ExistsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_register_feature_set**
> V1FeatureSetResponse core_service_register_feature_set(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_set_response import V1FeatureSetResponse
from h2o_featurestore.gen.model.v1_register_feature_set_request import V1RegisterFeatureSetRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1RegisterFeatureSetRequest(
        feature_set_name="feature_set_name_example",
        project=V1Project(
            name="name_example",
            description="description_example",
            author=V1UserBasicInfo(
                id="id_example",
                name="name_example",
                email="email_example",
                preferred_name="preferred_name_example",
            ),
            created_date_time=dateutil_parser('1970-01-01T00:00:00.00Z'),
            last_update_date_time=dateutil_parser('1970-01-01T00:00:00.00Z'),
            id="id_example",
            custom_data={},
            feature_sets_count="feature_sets_count_example",
            last_updated_by=V1UserBasicInfo(
                id="id_example",
                name="name_example",
                email="email_example",
                preferred_name="preferred_name_example",
            ),
            access_modifier=V1AccessModifier("ACCESS_MODIFIER_UNSPECIFIED"),
        ),
        time_travel_column="time_travel_column_example",
        time_travel_column_format="time_travel_column_format_example",
        primary_key=[
            "primary_key_example",
        ],
        schema=[
            V1FeatureSchema(
                name="name_example",
                data_type="data_type_example",
                nested=[],
                special_data=V1FeatureSchemaSpecialData(
                    spi=True,
                    pci=True,
                    rpi=True,
                    demographic=True,
                    sensitive=True,
                ),
                feature_type=V1FeatureType("AUTOMATIC_DISCOVERY"),
                description="description_example",
                classifiers=[
                    "classifiers_example",
                ],
                custom_data={},
                monitoring=V1FeatureSchemaMonitoring(
                    anomaly_detection=True,
                ),
            ),
        ],
        description="description_example",
        partition_by=[
            "partition_by_example",
        ],
        time_travel_column_as_partition=True,
        feature_set_type=V1FeatureSetType("RAW"),
        feature_set_state="feature_set_state_example",
        application_name="application_name_example",
        application_id="application_id_example",
        online=V1FeatureSetOnline(
            online_namespace="online_namespace_example",
            connection_type="connection_type_example",
            topic="topic_example",
        ),
        data_source_domains=[
            "data_source_domains_example",
        ],
        tags=[
            "tags_example",
        ],
        process_interval=1,
        process_interval_unit=V1ProcessIntervalUnit("UNDEFINED"),
        flow="flow_example",
        special_data=V1FeatureSetSpecialData(
            spi=True,
            pci=True,
            rpi=True,
            demographic=True,
            sensitive=True,
            legal=SpecialDataLegal(
                approved=True,
                approved_date=dateutil_parser('1970-01-01T00:00:00.00Z'),
                notes="notes_example",
            ),
        ),
        custom_data={},
        time_to_live=V1TimeToLive(
            ttl_offline=1,
            ttl_offline_interval=V1OfflineTimeToLiveInterval("YEARS"),
            ttl_online=1,
            ttl_online_interval=V1OnlineTimeToLiveInterval("DAYS"),
        ),
        derived_from=V1DerivedInformation(
            feature_set_ids=[
                V1VersionedId(
                    id="id_example",
                    major_version=1,
                ),
            ],
            transformation=V1Transformation(
                mojo=V1MojoTransformation(
                    filename="filename_example",
                ),
                spark_pipeline=V1SparkPipelineTransformation(
                    filename="filename_example",
                ),
                join=V1JoinTransformation(
                    left_key="left_key_example",
                    right_key="right_key_example",
                    join_type=V1JoinType("JOIN_TYPE_INNER"),
                ),
            ),
        ),
    ) # V1RegisterFeatureSetRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_register_feature_set(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_register_feature_set: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1RegisterFeatureSetRequest**](V1RegisterFeatureSetRequest.md)|  |

### Return type

[**V1FeatureSetResponse**](V1FeatureSetResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_reject_pending_permission**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_reject_pending_permission(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_reject_pending_permission_request import V1RejectPendingPermissionRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1RejectPendingPermissionRequest(
        permission_id="permission_id_example",
        reason="reason_example",
    ) # V1RejectPendingPermissionRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_reject_pending_permission(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_reject_pending_permission: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1RejectPendingPermissionRequest**](V1RejectPendingPermissionRequest.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_reject_review**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_reject_review(review_id, reason)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    review_id = "reviewId_example" # str | 
    reason = "reason_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_reject_review(review_id, reason)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_reject_review: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **review_id** | **str**|  |
 **reason** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_remove_feature_set_permission**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_remove_feature_set_permission(feature_set_id, body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.core_service_remove_feature_set_permission_body import CoreServiceRemoveFeatureSetPermissionBody
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    body = CoreServiceRemoveFeatureSetPermissionBody(
        user_emails=[
            "user_emails_example",
        ],
        permission=V1PermissionType("Owner"),
    ) # CoreServiceRemoveFeatureSetPermissionBody | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_remove_feature_set_permission(feature_set_id, body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_remove_feature_set_permission: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **body** | [**CoreServiceRemoveFeatureSetPermissionBody**](CoreServiceRemoveFeatureSetPermissionBody.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_remove_project_permission**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_remove_project_permission(project_id, body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.core_service_remove_project_permission_body import CoreServiceRemoveProjectPermissionBody
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    project_id = "projectId_example" # str | 
    body = CoreServiceRemoveProjectPermissionBody(
        user_emails=[
            "user_emails_example",
        ],
        permission=V1PermissionType("Owner"),
    ) # CoreServiceRemoveProjectPermissionBody | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_remove_project_permission(project_id, body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_remove_project_permission: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**|  |
 **body** | [**CoreServiceRemoveProjectPermissionBody**](CoreServiceRemoveProjectPermissionBody.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_resume_scheduled_task**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_resume_scheduled_task(scheduled_task_id, body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from h2o_featurestore.gen.model.core_service_resume_scheduled_task_body import CoreServiceResumeScheduledTaskBody
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    scheduled_task_id = "scheduledTaskId_example" # str | 
    body = CoreServiceResumeScheduledTaskBody(
        setup_failures=True,
        allowed_failures=1,
    ) # CoreServiceResumeScheduledTaskBody | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_resume_scheduled_task(scheduled_task_id, body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_resume_scheduled_task: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scheduled_task_id** | **str**|  |
 **body** | [**CoreServiceResumeScheduledTaskBody**](CoreServiceResumeScheduledTaskBody.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_retrieve_artifact**
> V1RetrieveArtifactResponse core_service_retrieve_artifact(artifact_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from h2o_featurestore.gen.model.v1_retrieve_artifact_response import V1RetrieveArtifactResponse
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    artifact_id = "artifactId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_retrieve_artifact(artifact_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_retrieve_artifact: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artifact_id** | **str**|  |

### Return type

[**V1RetrieveArtifactResponse**](V1RetrieveArtifactResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_retrieve_as_spark**
> V1RetrieveAsSparkResponse core_service_retrieve_as_spark(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_retrieve_request import V1RetrieveRequest
from h2o_featurestore.gen.model.v1_retrieve_as_spark_response import V1RetrieveAsSparkResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1RetrieveRequest(
        start_date_time="start_date_time_example",
        end_date_time="end_date_time_example",
        ingest_id="ingest_id_example",
        session_id="session_id_example",
        feature_set_id="feature_set_id_example",
        feature_set_version="feature_set_version_example",
    ) # V1RetrieveRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_retrieve_as_spark(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_retrieve_as_spark: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1RetrieveRequest**](V1RetrieveRequest.md)|  |

### Return type

[**V1RetrieveAsSparkResponse**](V1RetrieveAsSparkResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_revoke_permission**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_revoke_permission(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_revoke_permission_request import V1RevokePermissionRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1RevokePermissionRequest(
        permission_id="permission_id_example",
        reason="reason_example",
    ) # V1RevokePermissionRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_revoke_permission(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_revoke_permission: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1RevokePermissionRequest**](V1RevokePermissionRequest.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_revoke_token**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_revoke_token(token_id)

PAT API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    token_id = "tokenId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        # PAT API
        api_response = api_instance.core_service_revoke_token(token_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_revoke_token: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **token_id** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_schedule_ingest_job**
> V1ScheduledTaskResponse core_service_schedule_ingest_job(body)

Schedule API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_scheduled_task_response import V1ScheduledTaskResponse
from h2o_featurestore.gen.model.v1_schedule_task_request import V1ScheduleTaskRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1ScheduleTaskRequest(
        feature_set_id="feature_set_id_example",
        name="name_example",
        description="description_example",
        project_id="project_id_example",
        cred=V1Credentials(
            aws=V1AWSCredentials(
                access_token="access_token_example",
                secret_token="secret_token_example",
                region="region_example",
                endpoint="endpoint_example",
                role_arn="role_arn_example",
                session_token="session_token_example",
            ),
            azure=V1AzureCredentials(
                account_name="account_name_example",
                account_key="account_key_example",
                sas_token="sas_token_example",
                sas_container="sas_container_example",
                sp_client_id="sp_client_id_example",
                sp_tenant_id="sp_tenant_id_example",
                sp_secret="sp_secret_example",
            ),
            snowflake=V1SnowflakeCredentials(
                user="user_example",
                password="password_example",
                pem_private_key="pem_private_key_example",
                passphrase="passphrase_example",
            ),
            jdbc_database=V1JDBCCredentials(
                user="user_example",
                password="password_example",
            ),
            mongo_db=V1MongoDbCredentials(
                user="user_example",
                password="password_example",
            ),
            drive={},
            gcp=V1GcpCredentials(
                credentials_file_content="credentials_file_content_example",
            ),
        ),
        source=V1RawDataLocation(
            csv=V1CSVFileSpec(
                path="path_example",
                delimiter="delimiter_example",
            ),
            parquet=V1ParquetFileSpec(
                path="path_example",
            ),
            snowflake=V1SnowflakeTableSpec(
                table="table_example",
                database="database_example",
                url="url_example",
                query="query_example",
                warehouse="warehouse_example",
                schema="schema_example",
                insecure=True,
                proxy=V1Proxy(
                    host="host_example",
                    port=1,
                    user="user_example",
                    password="password_example",
                ),
                role="role_example",
                account="account_example",
            ),
            jdbc=V1JDBCTableSpec(
                table="table_example",
                query="query_example",
                connection_url="connection_url_example",
                num_partitions=1,
                partition_column="partition_column_example",
                lower_bound="lower_bound_example",
                upper_bound="upper_bound_example",
                fetch_size=1,
            ),
            json=V1JSONFileSpec(
                path="path_example",
                multiline=True,
            ),
            delta_table=V1DeltaTableSpec(
                path="path_example",
                version=1,
                timestamp="timestamp_example",
                filter=V1Filter(
                    text=V1TextualFilter(
                        field="field_example",
                        value=[
                            "value_example",
                        ],
                        operator="operator_example",
                    ),
                    numeric=V1NumericalFilter(
                        field="field_example",
                        value=3.14,
                        operator="operator_example",
                    ),
                    boolean=V1BooleanFilter(
                        field="field_example",
                        value=True,
                        operator="operator_example",
                    ),
                ),
            ),
            csv_folder=V1CSVFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
                delimiter="delimiter_example",
            ),
            parquet_folder=V1ParquetFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
            ),
            json_folder=V1JSONFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
                multiline=True,
            ),
            online_source=V1OnlineSourceSpec(
                absolute_json_folder_path="absolute_json_folder_path_example",
            ),
            mongo_db=V1MongoDbCollectionSpec(
                connection_uri="connection_uri_example",
                database="database_example",
                collection="collection_example",
            ),
            google_big_query=V1BigQueryTableSpec(
                table="table_example",
                parent_project="parent_project_example",
                query="query_example",
                materialization_dataset="materialization_dataset_example",
            ),
        ),
        schedule="schedule_example",
        feature_set_version="feature_set_version_example",
        cron_time_zone="cron_time_zone_example",
        allowed_failures=1,
    ) # V1ScheduleTaskRequest | 

    # example passing only required values which don't have defaults set
    try:
        # Schedule API
        api_response = api_instance.core_service_schedule_ingest_job(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_schedule_ingest_job: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1ScheduleTaskRequest**](V1ScheduleTaskRequest.md)|  |

### Return type

[**V1ScheduledTaskResponse**](V1ScheduledTaskResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_schedule_lazy_ingest_task**
> V1ScheduledTaskResponse core_service_schedule_lazy_ingest_task(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_scheduled_task_response import V1ScheduledTaskResponse
from h2o_featurestore.gen.model.v1_schedule_task_request import V1ScheduleTaskRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1ScheduleTaskRequest(
        feature_set_id="feature_set_id_example",
        name="name_example",
        description="description_example",
        project_id="project_id_example",
        cred=V1Credentials(
            aws=V1AWSCredentials(
                access_token="access_token_example",
                secret_token="secret_token_example",
                region="region_example",
                endpoint="endpoint_example",
                role_arn="role_arn_example",
                session_token="session_token_example",
            ),
            azure=V1AzureCredentials(
                account_name="account_name_example",
                account_key="account_key_example",
                sas_token="sas_token_example",
                sas_container="sas_container_example",
                sp_client_id="sp_client_id_example",
                sp_tenant_id="sp_tenant_id_example",
                sp_secret="sp_secret_example",
            ),
            snowflake=V1SnowflakeCredentials(
                user="user_example",
                password="password_example",
                pem_private_key="pem_private_key_example",
                passphrase="passphrase_example",
            ),
            jdbc_database=V1JDBCCredentials(
                user="user_example",
                password="password_example",
            ),
            mongo_db=V1MongoDbCredentials(
                user="user_example",
                password="password_example",
            ),
            drive={},
            gcp=V1GcpCredentials(
                credentials_file_content="credentials_file_content_example",
            ),
        ),
        source=V1RawDataLocation(
            csv=V1CSVFileSpec(
                path="path_example",
                delimiter="delimiter_example",
            ),
            parquet=V1ParquetFileSpec(
                path="path_example",
            ),
            snowflake=V1SnowflakeTableSpec(
                table="table_example",
                database="database_example",
                url="url_example",
                query="query_example",
                warehouse="warehouse_example",
                schema="schema_example",
                insecure=True,
                proxy=V1Proxy(
                    host="host_example",
                    port=1,
                    user="user_example",
                    password="password_example",
                ),
                role="role_example",
                account="account_example",
            ),
            jdbc=V1JDBCTableSpec(
                table="table_example",
                query="query_example",
                connection_url="connection_url_example",
                num_partitions=1,
                partition_column="partition_column_example",
                lower_bound="lower_bound_example",
                upper_bound="upper_bound_example",
                fetch_size=1,
            ),
            json=V1JSONFileSpec(
                path="path_example",
                multiline=True,
            ),
            delta_table=V1DeltaTableSpec(
                path="path_example",
                version=1,
                timestamp="timestamp_example",
                filter=V1Filter(
                    text=V1TextualFilter(
                        field="field_example",
                        value=[
                            "value_example",
                        ],
                        operator="operator_example",
                    ),
                    numeric=V1NumericalFilter(
                        field="field_example",
                        value=3.14,
                        operator="operator_example",
                    ),
                    boolean=V1BooleanFilter(
                        field="field_example",
                        value=True,
                        operator="operator_example",
                    ),
                ),
            ),
            csv_folder=V1CSVFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
                delimiter="delimiter_example",
            ),
            parquet_folder=V1ParquetFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
            ),
            json_folder=V1JSONFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
                multiline=True,
            ),
            online_source=V1OnlineSourceSpec(
                absolute_json_folder_path="absolute_json_folder_path_example",
            ),
            mongo_db=V1MongoDbCollectionSpec(
                connection_uri="connection_uri_example",
                database="database_example",
                collection="collection_example",
            ),
            google_big_query=V1BigQueryTableSpec(
                table="table_example",
                parent_project="parent_project_example",
                query="query_example",
                materialization_dataset="materialization_dataset_example",
            ),
        ),
        schedule="schedule_example",
        feature_set_version="feature_set_version_example",
        cron_time_zone="cron_time_zone_example",
        allowed_failures=1,
    ) # V1ScheduleTaskRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_schedule_lazy_ingest_task(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_schedule_lazy_ingest_task: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1ScheduleTaskRequest**](V1ScheduleTaskRequest.md)|  |

### Return type

[**V1ScheduledTaskResponse**](V1ScheduledTaskResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_search_feature_sets**
> V1FeatureSetSearchResults core_service_search_feature_sets(body)

Must be a post request since you can't use repeated fields

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_set_search_request import V1FeatureSetSearchRequest
from h2o_featurestore.gen.model.v1_feature_set_search_results import V1FeatureSetSearchResults
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1FeatureSetSearchRequest(
        query="query_example",
        page_size=1,
        page_token="page_token_example",
        owned_only=True,
        project_ids=[
            "project_ids_example",
        ],
        sort_field=FeatureSetSearchRequestFeatureSetSortField("FEATURE_SET_SORT_FIELD_UNDEFINED"),
        sort_direction=V1SortDirection("SORT_ASC"),
        options=[
            V1AdvancedSearchOption(
                search_operator=AdvancedSearchOptionSearchOperator("SEARCH_OPERATOR_UNSPECIFIED"),
                search_field=AdvancedSearchOptionSearchField("SEARCH_FIELD_UNSPECIFIED"),
                search_value="search_value_example",
            ),
        ],
    ) # V1FeatureSetSearchRequest | 

    # example passing only required values which don't have defaults set
    try:
        # Must be a post request since you can't use repeated fields
        api_response = api_instance.core_service_search_feature_sets(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_search_feature_sets: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1FeatureSetSearchRequest**](V1FeatureSetSearchRequest.md)|  |

### Return type

[**V1FeatureSetSearchResults**](V1FeatureSetSearchResults.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_search_features**
> V1FeatureSearchResults core_service_search_features()



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_feature_search_results import V1FeatureSearchResults
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    query = "query_example" # str |  (optional)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    owned_only = True # bool |  (optional)
    project_ids = [
        "projectIds_example",
    ] # [str] |  (optional)
    sort_field = "FEATURE_SORT_FIELD_UNDEFINED" # str |  (optional) if omitted the server will use the default value of "FEATURE_SORT_FIELD_UNDEFINED"
    sort_direction = "SORT_ASC" # str |  (optional) if omitted the server will use the default value of "SORT_ASC"

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.core_service_search_features(query=query, page_size=page_size, page_token=page_token, owned_only=owned_only, project_ids=project_ids, sort_field=sort_field, sort_direction=sort_direction)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_search_features: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**|  | [optional]
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **owned_only** | **bool**|  | [optional]
 **project_ids** | **[str]**|  | [optional]
 **sort_field** | **str**|  | [optional] if omitted the server will use the default value of "FEATURE_SORT_FIELD_UNDEFINED"
 **sort_direction** | **str**|  | [optional] if omitted the server will use the default value of "SORT_ASC"

### Return type

[**V1FeatureSearchResults**](V1FeatureSearchResults.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_search_projects**
> V1ProjectSearchResults core_service_search_projects()

Search API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_project_search_results import V1ProjectSearchResults
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    query = "query_example" # str |  (optional)
    page_size = 1 # int |  (optional)
    page_token = "pageToken_example" # str |  (optional)
    required_permission = "ACTIVE_PERMISSION_NONE" # str |  (optional) if omitted the server will use the default value of "ACTIVE_PERMISSION_NONE"
    project_ids = [
        "projectIds_example",
    ] # [str] |  (optional)
    sort_field = "PROJECT_SORT_FIELD_UNDEFINED" # str |  (optional) if omitted the server will use the default value of "PROJECT_SORT_FIELD_UNDEFINED"
    sort_direction = "SORT_ASC" # str |  (optional) if omitted the server will use the default value of "SORT_ASC"

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        # Search API
        api_response = api_instance.core_service_search_projects(query=query, page_size=page_size, page_token=page_token, required_permission=required_permission, project_ids=project_ids, sort_field=sort_field, sort_direction=sort_direction)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_search_projects: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**|  | [optional]
 **page_size** | **int**|  | [optional]
 **page_token** | **str**|  | [optional]
 **required_permission** | **str**|  | [optional] if omitted the server will use the default value of "ACTIVE_PERMISSION_NONE"
 **project_ids** | **[str]**|  | [optional]
 **sort_field** | **str**|  | [optional] if omitted the server will use the default value of "PROJECT_SORT_FIELD_UNDEFINED"
 **sort_direction** | **str**|  | [optional] if omitted the server will use the default value of "SORT_ASC"

### Return type

[**V1ProjectSearchResults**](V1ProjectSearchResults.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_start_extract_schema_job**
> V1JobId core_service_start_extract_schema_job(body)

Extract Schema API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_job_id import V1JobId
from h2o_featurestore.gen.model.v1_start_extract_schema_job_request import V1StartExtractSchemaJobRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1StartExtractSchemaJobRequest(
        raw_data=V1RawDataLocation(
            csv=V1CSVFileSpec(
                path="path_example",
                delimiter="delimiter_example",
            ),
            parquet=V1ParquetFileSpec(
                path="path_example",
            ),
            snowflake=V1SnowflakeTableSpec(
                table="table_example",
                database="database_example",
                url="url_example",
                query="query_example",
                warehouse="warehouse_example",
                schema="schema_example",
                insecure=True,
                proxy=V1Proxy(
                    host="host_example",
                    port=1,
                    user="user_example",
                    password="password_example",
                ),
                role="role_example",
                account="account_example",
            ),
            jdbc=V1JDBCTableSpec(
                table="table_example",
                query="query_example",
                connection_url="connection_url_example",
                num_partitions=1,
                partition_column="partition_column_example",
                lower_bound="lower_bound_example",
                upper_bound="upper_bound_example",
                fetch_size=1,
            ),
            json=V1JSONFileSpec(
                path="path_example",
                multiline=True,
            ),
            delta_table=V1DeltaTableSpec(
                path="path_example",
                version=1,
                timestamp="timestamp_example",
                filter=V1Filter(
                    text=V1TextualFilter(
                        field="field_example",
                        value=[
                            "value_example",
                        ],
                        operator="operator_example",
                    ),
                    numeric=V1NumericalFilter(
                        field="field_example",
                        value=3.14,
                        operator="operator_example",
                    ),
                    boolean=V1BooleanFilter(
                        field="field_example",
                        value=True,
                        operator="operator_example",
                    ),
                ),
            ),
            csv_folder=V1CSVFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
                delimiter="delimiter_example",
            ),
            parquet_folder=V1ParquetFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
            ),
            json_folder=V1JSONFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
                multiline=True,
            ),
            online_source=V1OnlineSourceSpec(
                absolute_json_folder_path="absolute_json_folder_path_example",
            ),
            mongo_db=V1MongoDbCollectionSpec(
                connection_uri="connection_uri_example",
                database="database_example",
                collection="collection_example",
            ),
            google_big_query=V1BigQueryTableSpec(
                table="table_example",
                parent_project="parent_project_example",
                query="query_example",
                materialization_dataset="materialization_dataset_example",
            ),
        ),
        derived_from=V1DerivedInformation(
            feature_set_ids=[
                V1VersionedId(
                    id="id_example",
                    major_version=1,
                ),
            ],
            transformation=V1Transformation(
                mojo=V1MojoTransformation(
                    filename="filename_example",
                ),
                spark_pipeline=V1SparkPipelineTransformation(
                    filename="filename_example",
                ),
                join=V1JoinTransformation(
                    left_key="left_key_example",
                    right_key="right_key_example",
                    join_type=V1JoinType("JOIN_TYPE_INNER"),
                ),
            ),
        ),
        cred=V1Credentials(
            aws=V1AWSCredentials(
                access_token="access_token_example",
                secret_token="secret_token_example",
                region="region_example",
                endpoint="endpoint_example",
                role_arn="role_arn_example",
                session_token="session_token_example",
            ),
            azure=V1AzureCredentials(
                account_name="account_name_example",
                account_key="account_key_example",
                sas_token="sas_token_example",
                sas_container="sas_container_example",
                sp_client_id="sp_client_id_example",
                sp_tenant_id="sp_tenant_id_example",
                sp_secret="sp_secret_example",
            ),
            snowflake=V1SnowflakeCredentials(
                user="user_example",
                password="password_example",
                pem_private_key="pem_private_key_example",
                passphrase="passphrase_example",
            ),
            jdbc_database=V1JDBCCredentials(
                user="user_example",
                password="password_example",
            ),
            mongo_db=V1MongoDbCredentials(
                user="user_example",
                password="password_example",
            ),
            drive={},
            gcp=V1GcpCredentials(
                credentials_file_content="credentials_file_content_example",
            ),
        ),
    ) # V1StartExtractSchemaJobRequest | 

    # example passing only required values which don't have defaults set
    try:
        # Extract Schema API
        api_response = api_instance.core_service_start_extract_schema_job(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_start_extract_schema_job: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1StartExtractSchemaJobRequest**](V1StartExtractSchemaJobRequest.md)|  |

### Return type

[**V1JobId**](V1JobId.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_start_ingest_job**
> V1JobId core_service_start_ingest_job(body)

Feature Set API

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_job_id import V1JobId
from h2o_featurestore.gen.model.v1_start_ingest_job_request import V1StartIngestJobRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1StartIngestJobRequest(
        cred=V1Credentials(
            aws=V1AWSCredentials(
                access_token="access_token_example",
                secret_token="secret_token_example",
                region="region_example",
                endpoint="endpoint_example",
                role_arn="role_arn_example",
                session_token="session_token_example",
            ),
            azure=V1AzureCredentials(
                account_name="account_name_example",
                account_key="account_key_example",
                sas_token="sas_token_example",
                sas_container="sas_container_example",
                sp_client_id="sp_client_id_example",
                sp_tenant_id="sp_tenant_id_example",
                sp_secret="sp_secret_example",
            ),
            snowflake=V1SnowflakeCredentials(
                user="user_example",
                password="password_example",
                pem_private_key="pem_private_key_example",
                passphrase="passphrase_example",
            ),
            jdbc_database=V1JDBCCredentials(
                user="user_example",
                password="password_example",
            ),
            mongo_db=V1MongoDbCredentials(
                user="user_example",
                password="password_example",
            ),
            drive={},
            gcp=V1GcpCredentials(
                credentials_file_content="credentials_file_content_example",
            ),
        ),
        data_source=V1RawDataLocation(
            csv=V1CSVFileSpec(
                path="path_example",
                delimiter="delimiter_example",
            ),
            parquet=V1ParquetFileSpec(
                path="path_example",
            ),
            snowflake=V1SnowflakeTableSpec(
                table="table_example",
                database="database_example",
                url="url_example",
                query="query_example",
                warehouse="warehouse_example",
                schema="schema_example",
                insecure=True,
                proxy=V1Proxy(
                    host="host_example",
                    port=1,
                    user="user_example",
                    password="password_example",
                ),
                role="role_example",
                account="account_example",
            ),
            jdbc=V1JDBCTableSpec(
                table="table_example",
                query="query_example",
                connection_url="connection_url_example",
                num_partitions=1,
                partition_column="partition_column_example",
                lower_bound="lower_bound_example",
                upper_bound="upper_bound_example",
                fetch_size=1,
            ),
            json=V1JSONFileSpec(
                path="path_example",
                multiline=True,
            ),
            delta_table=V1DeltaTableSpec(
                path="path_example",
                version=1,
                timestamp="timestamp_example",
                filter=V1Filter(
                    text=V1TextualFilter(
                        field="field_example",
                        value=[
                            "value_example",
                        ],
                        operator="operator_example",
                    ),
                    numeric=V1NumericalFilter(
                        field="field_example",
                        value=3.14,
                        operator="operator_example",
                    ),
                    boolean=V1BooleanFilter(
                        field="field_example",
                        value=True,
                        operator="operator_example",
                    ),
                ),
            ),
            csv_folder=V1CSVFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
                delimiter="delimiter_example",
            ),
            parquet_folder=V1ParquetFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
            ),
            json_folder=V1JSONFolderSpec(
                root_folder="root_folder_example",
                filter_pattern="filter_pattern_example",
                multiline=True,
            ),
            online_source=V1OnlineSourceSpec(
                absolute_json_folder_path="absolute_json_folder_path_example",
            ),
            mongo_db=V1MongoDbCollectionSpec(
                connection_uri="connection_uri_example",
                database="database_example",
                collection="collection_example",
            ),
            google_big_query=V1BigQueryTableSpec(
                table="table_example",
                parent_project="parent_project_example",
                query="query_example",
                materialization_dataset="materialization_dataset_example",
            ),
        ),
        feature_set_id="feature_set_id_example",
        feature_set_version="feature_set_version_example",
    ) # V1StartIngestJobRequest | 

    # example passing only required values which don't have defaults set
    try:
        # Feature Set API
        api_response = api_instance.core_service_start_ingest_job(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_start_ingest_job: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1StartIngestJobRequest**](V1StartIngestJobRequest.md)|  |

### Return type

[**V1JobId**](V1JobId.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_start_lazy_ingest_task**
> V1LazyIngestResponse core_service_start_lazy_ingest_task(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_lazy_ingest_request import V1LazyIngestRequest
from h2o_featurestore.gen.model.v1_lazy_ingest_response import V1LazyIngestResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1LazyIngestRequest(
        feature_set_id="feature_set_id_example",
        feature_set_version="feature_set_version_example",
    ) # V1LazyIngestRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_start_lazy_ingest_task(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_start_lazy_ingest_task: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1LazyIngestRequest**](V1LazyIngestRequest.md)|  |

### Return type

[**V1LazyIngestResponse**](V1LazyIngestResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_start_materialization_online_job**
> V1JobId core_service_start_materialization_online_job(feature_set_id, feature_set_version)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_job_id import V1JobId
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_version = "featureSetVersion_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_start_materialization_online_job(feature_set_id, feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_start_materialization_online_job: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_version** | **str**|  |

### Return type

[**V1JobId**](V1JobId.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_start_online_offline_ingestion_job**
> V1JobId core_service_start_online_offline_ingestion_job(feature_set_id, feature_set_version)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_job_id import V1JobId
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_set_version = "featureSetVersion_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_start_online_offline_ingestion_job(feature_set_id, feature_set_version)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_start_online_offline_ingestion_job: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_set_version** | **str**|  |

### Return type

[**V1JobId**](V1JobId.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_start_optimize_storage_job**
> V1JobId core_service_start_optimize_storage_job(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_job_id import V1JobId
from h2o_featurestore.gen.model.v1_start_optimize_storage_job_request import V1StartOptimizeStorageJobRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1StartOptimizeStorageJobRequest(
        feature_set_id="feature_set_id_example",
        feature_set_version="feature_set_version_example",
        optimization=V1StorageOptimization(
            z_order_by=V1OptimizeStorageZOrderBySpec(
                columns=[
                    "columns_example",
                ],
            ),
            compact={},
        ),
    ) # V1StartOptimizeStorageJobRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_start_optimize_storage_job(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_start_optimize_storage_job: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1StartOptimizeStorageJobRequest**](V1StartOptimizeStorageJobRequest.md)|  |

### Return type

[**V1JobId**](V1JobId.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_start_retrieve_as_links_job**
> V1JobId core_service_start_retrieve_as_links_job(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_retrieve_request import V1RetrieveRequest
from h2o_featurestore.gen.model.v1_job_id import V1JobId
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1RetrieveRequest(
        start_date_time="start_date_time_example",
        end_date_time="end_date_time_example",
        ingest_id="ingest_id_example",
        session_id="session_id_example",
        feature_set_id="feature_set_id_example",
        feature_set_version="feature_set_version_example",
    ) # V1RetrieveRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_start_retrieve_as_links_job(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_start_retrieve_as_links_job: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1RetrieveRequest**](V1RetrieveRequest.md)|  |

### Return type

[**V1JobId**](V1JobId.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_start_revert_ingest_job**
> V1JobId core_service_start_revert_ingest_job(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_job_id import V1JobId
from h2o_featurestore.gen.model.v1_start_revert_ingest_job_request import V1StartRevertIngestJobRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1StartRevertIngestJobRequest(
        ingest_id="ingest_id_example",
        feature_set_id="feature_set_id_example",
        feature_set_version="feature_set_version_example",
    ) # V1StartRevertIngestJobRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_start_revert_ingest_job(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_start_revert_ingest_job: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1StartRevertIngestJobRequest**](V1StartRevertIngestJobRequest.md)|  |

### Return type

[**V1JobId**](V1JobId.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_store_file_artifact**
> V1StoreFileArtifactResponse core_service_store_file_artifact(body)

Artifact

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_store_file_artifact_response import V1StoreFileArtifactResponse
from h2o_featurestore.gen.model.v1_store_file_artifact_request import V1StoreFileArtifactRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1StoreFileArtifactRequest(
        title="title_example",
        description="description_example",
        url="url_example",
        filename="filename_example",
        feature_set_id="feature_set_id_example",
        feature_set_major_version=1,
        md5_checksum="md5_checksum_example",
    ) # V1StoreFileArtifactRequest | 

    # example passing only required values which don't have defaults set
    try:
        # Artifact
        api_response = api_instance.core_service_store_file_artifact(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_store_file_artifact: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1StoreFileArtifactRequest**](V1StoreFileArtifactRequest.md)|  |

### Return type

[**V1StoreFileArtifactResponse**](V1StoreFileArtifactResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_store_link**
> V1StoreLinkResponse core_service_store_link(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_store_link_response import V1StoreLinkResponse
from h2o_featurestore.gen.model.v1_store_link_request import V1StoreLinkRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1StoreLinkRequest(
        title="title_example",
        description="description_example",
        url="url_example",
        feature_set_id="feature_set_id_example",
        feature_set_major_version=1,
    ) # V1StoreLinkRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_store_link(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_store_link: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1StoreLinkRequest**](V1StoreLinkRequest.md)|  |

### Return type

[**V1StoreLinkResponse**](V1StoreLinkResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_submit_pending_feature_set_permission**
> V1SubmitPendingPermissionResponse core_service_submit_pending_feature_set_permission(resource_id, body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.core_service_submit_pending_feature_set_permission_body import CoreServiceSubmitPendingFeatureSetPermissionBody
from h2o_featurestore.gen.model.v1_submit_pending_permission_response import V1SubmitPendingPermissionResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    resource_id = "resourceId_example" # str | 
    body = CoreServiceSubmitPendingFeatureSetPermissionBody(
        permission=V1PermissionType("Owner"),
        reason="reason_example",
    ) # CoreServiceSubmitPendingFeatureSetPermissionBody | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_submit_pending_feature_set_permission(resource_id, body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_submit_pending_feature_set_permission: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resource_id** | **str**|  |
 **body** | [**CoreServiceSubmitPendingFeatureSetPermissionBody**](CoreServiceSubmitPendingFeatureSetPermissionBody.md)|  |

### Return type

[**V1SubmitPendingPermissionResponse**](V1SubmitPendingPermissionResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_submit_pending_project_permission**
> V1SubmitPendingPermissionResponse core_service_submit_pending_project_permission(resource_id, body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_submit_pending_permission_response import V1SubmitPendingPermissionResponse
from h2o_featurestore.gen.model.core_service_submit_pending_project_permission_body import CoreServiceSubmitPendingProjectPermissionBody
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    resource_id = "resourceId_example" # str | 
    body = CoreServiceSubmitPendingProjectPermissionBody(
        permission=V1PermissionType("Owner"),
        reason="reason_example",
    ) # CoreServiceSubmitPendingProjectPermissionBody | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_submit_pending_project_permission(resource_id, body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_submit_pending_project_permission: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resource_id** | **str**|  |
 **body** | [**CoreServiceSubmitPendingProjectPermissionBody**](CoreServiceSubmitPendingProjectPermissionBody.md)|  |

### Return type

[**V1SubmitPendingPermissionResponse**](V1SubmitPendingPermissionResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_unpin_feature_set**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_unpin_feature_set(feature_set_id)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_unpin_feature_set(feature_set_id)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_unpin_feature_set: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_update_feature**
> V1UpdateFeatureResponse core_service_update_feature(feature_set_id, feature_id, body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_update_feature_response import V1UpdateFeatureResponse
from h2o_featurestore.gen.model.core_service_update_feature_body import CoreServiceUpdateFeatureBody
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    feature_id = "featureId_example" # str | 
    body = CoreServiceUpdateFeatureBody(
        feature_set_version="feature_set_version_example",
        status="status_example",
        type=V1FeatureType("AUTOMATIC_DISCOVERY"),
        importance=3.14,
        custom_data={},
        description="description_example",
        special="special_example",
        anomaly_detection=True,
        classifiers=[
            "classifiers_example",
        ],
        fields_to_update=[
            V1UpdatableFeatureField("FEATURE_UNSPECIFIED"),
        ],
    ) # CoreServiceUpdateFeatureBody | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_update_feature(feature_set_id, feature_id, body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_update_feature: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **feature_id** | **str**|  |
 **body** | [**CoreServiceUpdateFeatureBody**](CoreServiceUpdateFeatureBody.md)|  |

### Return type

[**V1UpdateFeatureResponse**](V1UpdateFeatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_update_feature_set**
> V1UpdateFeatureSetResponse core_service_update_feature_set(feature_set_id, body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.core_service_update_feature_set_body import CoreServiceUpdateFeatureSetBody
from h2o_featurestore.gen.model.v1_update_feature_set_response import V1UpdateFeatureSetResponse
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    feature_set_id = "featureSetId_example" # str | 
    body = CoreServiceUpdateFeatureSetBody(
        feature_set_version="feature_set_version_example",
        tags=[
            "tags_example",
        ],
        data_source_domains=[
            "data_source_domains_example",
        ],
        description="description_example",
        type=V1FeatureSetType("RAW"),
        deprecated=True,
        process_interval=1,
        process_interval_unit=V1ProcessIntervalUnit("UNDEFINED"),
        time_to_live_offline_interval=1,
        time_to_live_offline_interval_unit=V1OfflineTimeToLiveInterval("YEARS"),
        time_to_live_online_interval=1,
        time_to_live_online_interval_unit=V1OnlineTimeToLiveInterval("DAYS"),
        legal_approved=True,
        legal_approved_notes="legal_approved_notes_example",
        state="state_example",
        flow="flow_example",
        application_name="application_name_example",
        application_id="application_id_example",
        custom_data={},
        online_namespace="online_namespace_example",
        online_topic="online_topic_example",
        online_connection_type="online_connection_type_example",
        fields_to_update=[
            V1UpdatableFeatureSetField("FEATURE_SET_UNSPECIFIED"),
        ],
    ) # CoreServiceUpdateFeatureSetBody | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_update_feature_set(feature_set_id, body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_update_feature_set: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_set_id** | **str**|  |
 **body** | [**CoreServiceUpdateFeatureSetBody**](CoreServiceUpdateFeatureSetBody.md)|  |

### Return type

[**V1UpdateFeatureSetResponse**](V1UpdateFeatureSetResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_update_project**
> V1UpdateProjectResponse core_service_update_project(project_id, body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_update_project_response import V1UpdateProjectResponse
from h2o_featurestore.gen.model.core_service_update_project_body import CoreServiceUpdateProjectBody
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    project_id = "projectId_example" # str | 
    body = CoreServiceUpdateProjectBody(
        description="description_example",
        custom_data={},
        fields_to_update=[
            V1UpdatableProjectField("PROJECT_UNSPECIFIED"),
        ],
        access_modifier=V1AccessModifier("ACCESS_MODIFIER_UNSPECIFIED"),
    ) # CoreServiceUpdateProjectBody | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_update_project(project_id, body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_update_project: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**|  |
 **body** | [**CoreServiceUpdateProjectBody**](CoreServiceUpdateProjectBody.md)|  |

### Return type

[**V1UpdateProjectResponse**](V1UpdateProjectResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_update_recommendation_classifier**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_update_recommendation_classifier(classifier_name, classifier)

Updates a classifier

### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.core_service_update_recommendation_classifier_request import CoreServiceUpdateRecommendationClassifierRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    classifier_name = "classifier.name_example" # str | 
    classifier = CoreServiceUpdateRecommendationClassifierRequest(
        regex=V1RecommendationRegexMatchingPolicy(
            regex="regex_example",
            percentage_match=1,
        ),
        sample=V1RecommendationSampleMatchingPolicy(
            feature_set_id="feature_set_id_example",
            feature_set_major_version=1,
            column_name="column_name_example",
            sample_fraction=3.14,
            fuzzy_distance=1,
            percentage_match=1,
        ),
    ) # CoreServiceUpdateRecommendationClassifierRequest | 

    # example passing only required values which don't have defaults set
    try:
        # Updates a classifier
        api_response = api_instance.core_service_update_recommendation_classifier(classifier_name, classifier)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_update_recommendation_classifier: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **classifier_name** | **str**|  |
 **classifier** | [**CoreServiceUpdateRecommendationClassifierRequest**](CoreServiceUpdateRecommendationClassifierRequest.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_update_scheduled_task**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_update_scheduled_task(scheduled_task_id, body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.core_service_update_scheduled_task_body import CoreServiceUpdateScheduledTaskBody
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    scheduled_task_id = "scheduledTaskId_example" # str | 
    body = CoreServiceUpdateScheduledTaskBody(
        description="description_example",
        schedule="schedule_example",
        updated_fields=[
            "updated_fields_example",
        ],
    ) # CoreServiceUpdateScheduledTaskBody | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_update_scheduled_task(scheduled_task_id, body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_update_scheduled_task: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scheduled_task_id** | **str**|  |
 **body** | [**CoreServiceUpdateScheduledTaskBody**](CoreServiceUpdateScheduledTaskBody.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_update_upload_status**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_update_upload_status(artifact_id, body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.core_service_update_upload_status_body import CoreServiceUpdateUploadStatusBody
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    artifact_id = "artifactId_example" # str | 
    body = CoreServiceUpdateUploadStatusBody(
        upload_status=V1ArtifactUploadStatus("ARTIFACT_UPLOAD_STATUS_NOT_APPLICABLE"),
    ) # CoreServiceUpdateUploadStatusBody | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_update_upload_status(artifact_id, body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_update_upload_status: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artifact_id** | **str**|  |
 **body** | [**CoreServiceUpdateUploadStatusBody**](CoreServiceUpdateUploadStatusBody.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **core_service_withdraw_pending_permission**
> bool, date, datetime, dict, float, int, list, str, none_type core_service_withdraw_pending_permission(body)



### Example


```python
import time
import h2o_featurestore.gen
from h2o_featurestore.gen.api import core_service_api
from h2o_featurestore.gen.model.v1_withdraw_pending_permission_request import V1WithdrawPendingPermissionRequest
from h2o_featurestore.gen.model.rpc_status import RpcStatus
from pprint import pprint
# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = h2o_featurestore.gen.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with h2o_featurestore.gen.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = core_service_api.CoreServiceApi(api_client)
    body = V1WithdrawPendingPermissionRequest(
        permission_id="permission_id_example",
    ) # V1WithdrawPendingPermissionRequest | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.core_service_withdraw_pending_permission(body)
        pprint(api_response)
    except h2o_featurestore.gen.ApiException as e:
        print("Exception when calling CoreServiceApi->core_service_withdraw_pending_permission: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**V1WithdrawPendingPermissionRequest**](V1WithdrawPendingPermissionRequest.md)|  |

### Return type

**bool, date, datetime, dict, float, int, list, str, none_type**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | A successful response. |  -  |
**0** | An unexpected error response. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

