# V1PermissionState


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "PENDING",  must be one of ["PENDING", "GRANTED", "REJECTED", "REVOKED", "PROMOTED", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


