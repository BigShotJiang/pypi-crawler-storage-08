# V1FeatureType


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "AUTOMATIC_DISCOVERY",  must be one of ["AUTOMATIC_DISCOVERY", "COMPOSITE", "NUMERICAL", "CATEGORICAL", "TEMPORAL", "TEXT", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


