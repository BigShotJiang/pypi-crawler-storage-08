# V1JobStatus


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "Created",  must be one of ["Created", "Submitted", "Running", "SubmissionFailed", "Failed", "Success", "Pending", "PendingRerun", "Failing", "Cancelling", "Cancelled", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


