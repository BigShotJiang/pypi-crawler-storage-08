# V1TimeToLive


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ttl_offline** | **int** |  | [optional] 
**ttl_offline_interval** | [**V1OfflineTimeToLiveInterval**](V1OfflineTimeToLiveInterval.md) |  | [optional] 
**ttl_online** | **int** |  | [optional] 
**ttl_online_interval** | [**V1OnlineTimeToLiveInterval**](V1OnlineTimeToLiveInterval.md) |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


