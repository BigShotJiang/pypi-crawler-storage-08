# V1ActivePermission


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "ACTIVE_PERMISSION_NONE",  must be one of ["ACTIVE_PERMISSION_NONE", "ACTIVE_PERMISSION_OWNER", "ACTIVE_PERMISSION_EDITOR", "ACTIVE_PERMISSION_CONSUMER", "ACTIVE_PERMISSION_SENSITIVE_CONSUMER", "ACTIVE_PERMISSION_VIEWER", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


