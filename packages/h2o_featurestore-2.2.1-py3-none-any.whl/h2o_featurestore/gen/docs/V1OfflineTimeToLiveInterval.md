# V1OfflineTimeToLiveInterval


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "YEARS",  must be one of ["YEARS", "DAYS", "MONTHS", "HOURS", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


