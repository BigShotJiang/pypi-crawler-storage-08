# AdvancedSearchOptionSearchOperator


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "SEARCH_OPERATOR_UNSPECIFIED",  must be one of ["SEARCH_OPERATOR_UNSPECIFIED", "SEARCH_OPERATOR_LIKE", "SEARCH_OPERATOR_EQ", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


