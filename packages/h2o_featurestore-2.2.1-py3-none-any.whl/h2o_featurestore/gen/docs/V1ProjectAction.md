# V1ProjectAction


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "PROJECT_CREATED",  must be one of ["PROJECT_CREATED", "PROJECT_UPDATED", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


