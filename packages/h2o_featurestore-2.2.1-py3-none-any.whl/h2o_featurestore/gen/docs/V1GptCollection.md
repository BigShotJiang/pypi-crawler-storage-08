# V1GptCollection


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**document_count** | **int** |  | [optional] 
**document_size** | **str** |  | [optional] 
**updated_at** | **datetime** |  | [optional] 
**user_count** | **int** |  | [optional] 
**is_public** | **bool** |  | [optional] 
**username** | **str** |  | [optional] 
**sessions_count** | **int** |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


