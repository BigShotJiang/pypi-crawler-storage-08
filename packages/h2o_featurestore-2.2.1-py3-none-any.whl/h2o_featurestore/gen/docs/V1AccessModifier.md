# V1AccessModifier


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "ACCESS_MODIFIER_UNSPECIFIED",  must be one of ["ACCESS_MODIFIER_UNSPECIFIED", "ACCESS_MODIFIER_PUBLIC", "ACCESS_MODIFIER_PROJECT_ONLY", "ACCESS_MODIFIER_PRIVATE", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


