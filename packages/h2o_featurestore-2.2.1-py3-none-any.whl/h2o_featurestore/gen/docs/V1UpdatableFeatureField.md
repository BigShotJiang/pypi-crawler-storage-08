# V1UpdatableFeatureField


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "FEATURE_UNSPECIFIED",  must be one of ["FEATURE_UNSPECIFIED", "FEATURE_STATUS", "FEATURE_TYPE", "FEATURE_IMPORTANCE", "FEATURE_CUSTOM_DATA", "FEATURE_DESCRIPTION", "FEATURE_SPECIAL", "FEATURE_ANOMALY_DETECTION", "FEATURE_CLASSIFIERS", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


