# V1ArtifactType


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "ARTIFACT_TYPE_UNSPECIFIED",  must be one of ["ARTIFACT_TYPE_UNSPECIFIED", "ARTIFACT_TYPE_LINK", "ARTIFACT_TYPE_FILE", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


