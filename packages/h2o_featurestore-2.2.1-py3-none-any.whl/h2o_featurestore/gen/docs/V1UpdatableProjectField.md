# V1UpdatableProjectField


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "PROJECT_UNSPECIFIED",  must be one of ["PROJECT_UNSPECIFIED", "PROJECT_DESCRIPTION", "PROJECT_CUSTOM_DATA", "PROJECT_ACCESS_MODIFIER", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


