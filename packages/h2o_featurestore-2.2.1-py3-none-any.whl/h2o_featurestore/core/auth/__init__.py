from h2o_featurestore.core.auth.auth import AuthWrapper
