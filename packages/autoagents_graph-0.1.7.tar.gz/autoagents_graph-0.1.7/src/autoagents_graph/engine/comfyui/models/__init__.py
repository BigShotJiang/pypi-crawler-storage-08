"""
Models module for comfyui.

This module contains data models for ComfyUI platform.
"""

# TODO: Implement ComfyUI data models
# Example: ComfyUINode, ComfyUIEdge, ComfyUIWorkflow, ComfyUIConfig, etc.

__all__ = []

