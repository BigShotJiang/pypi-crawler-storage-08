from key_value.aio.adapters.pydantic.adapter import PydanticAdapter

__all__ = ["PydanticAdapter"]
