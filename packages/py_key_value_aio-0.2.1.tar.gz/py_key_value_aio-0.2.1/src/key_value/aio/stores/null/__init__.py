from key_value.aio.stores.null.store import NullStore

__all__ = ["NullStore"]
