from key_value.aio.stores.memcached.store import MemcachedStore

__all__ = ["MemcachedStore"]
