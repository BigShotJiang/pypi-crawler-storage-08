from key_value.aio.stores.simple.store import SimpleStore

__all__ = ["SimpleStore"]
