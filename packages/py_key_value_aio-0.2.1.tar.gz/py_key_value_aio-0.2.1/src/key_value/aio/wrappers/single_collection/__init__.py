from key_value.aio.wrappers.single_collection.wrapper import SingleCollectionWrapper

__all__ = ["SingleCollectionWrapper"]
