from key_value.aio.wrappers.statistics.wrapper import StatisticsWrapper

__all__ = ["StatisticsWrapper"]
