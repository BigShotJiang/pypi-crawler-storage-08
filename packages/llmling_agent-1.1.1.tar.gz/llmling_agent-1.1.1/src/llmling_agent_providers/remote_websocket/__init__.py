"""Remote websocket provider."""
