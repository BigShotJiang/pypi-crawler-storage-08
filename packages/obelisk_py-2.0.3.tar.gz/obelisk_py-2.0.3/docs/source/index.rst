Obelisk-py documentation
===========================================

Obelisk-py is a fresh client for the Obelisk platform.
It brings retry strategies and optional async support

Please find the changelog on `GitHub <https://github.com/predict-idlab/obelisk-python/blob/main/CHANGELOG.rst>`__.


.. autosummary::
   :toctree: _autosummary
   :recursive:

   obelisk
