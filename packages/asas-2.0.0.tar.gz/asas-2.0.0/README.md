# The access library in Python prints the text written inside it, like the print function.  

# Telegram  :  @LAEGER_MO
# The installation method is like this 
pip install asas
#After installation, how to use it 

python```
asas("Hello world ")
```