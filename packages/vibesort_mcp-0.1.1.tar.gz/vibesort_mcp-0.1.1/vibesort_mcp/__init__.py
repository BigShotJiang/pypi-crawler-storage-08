"""VibeSort MCP - A O(1) sorting method MCP leveraging the Vibesort Algorithm"""

__version__ = "0.1.1"
