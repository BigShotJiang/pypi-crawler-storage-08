# Copyright Nova Code (http://www.novacode.nl)
# See LICENSE file for full licensing details.

from .grid_base import baseGridComponent


class datagridComponent(baseGridComponent):
    # XXX should we move the initEmpty from base
    pass
