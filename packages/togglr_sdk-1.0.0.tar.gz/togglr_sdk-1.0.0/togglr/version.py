"""Version information for togglr-sdk-python."""

__version__ = "1.0.0"
