from magic_i18n.text import Text


Text(ru='asd проверка % & тест?')
Text(en='hello wolrd', ru='asd превед')
Text('asd', ru='фыв ${a}')
Text(en='asd ${a}', ru='фыв ${a}')
Text(en='asd ${a}', ru='фыв ${b}')
