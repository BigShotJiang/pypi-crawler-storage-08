from magic_i18n.text import Text


Text(en='Test ${a}', ru='Тест ${a}')
