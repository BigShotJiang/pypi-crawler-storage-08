aioworldline
============

Unofficial Worldline portal data retrieving client
