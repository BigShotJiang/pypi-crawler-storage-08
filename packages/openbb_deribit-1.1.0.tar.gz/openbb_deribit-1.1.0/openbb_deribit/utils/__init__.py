"""Deribit Utility Functions."""
