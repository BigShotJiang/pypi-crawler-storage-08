"""Deribit Data Models."""
