"""AIBooster integration module for zenith-tune."""

from .client import AIBoosterClient

__all__ = ["AIBoosterClient"]
