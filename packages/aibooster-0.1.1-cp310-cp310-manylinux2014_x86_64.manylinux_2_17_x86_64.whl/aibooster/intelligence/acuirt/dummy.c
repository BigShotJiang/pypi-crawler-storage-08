// Empty C source file to create host-native wheel binaries.
// This ensures the wheel is tagged as platform-specific (e.g., x86_64, aarch64).
