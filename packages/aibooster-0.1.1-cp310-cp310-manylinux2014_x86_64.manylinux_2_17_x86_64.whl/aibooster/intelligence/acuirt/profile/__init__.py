from .profile import profile_recursive_module

__all__ = ["profile_recursive_module"]
