from .base import Predictor

__all__ = ['Predictor']
