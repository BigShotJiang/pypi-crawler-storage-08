from .base import Deleter

__all__ = ['Deleter']
