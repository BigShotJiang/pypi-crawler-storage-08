from ..base import Base


class MixtureReducer(Base):
    """Mixture Reducer base class"""
