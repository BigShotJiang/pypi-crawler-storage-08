from ..base import Base


class Regulariser(Base):
    """Regulariser base class"""
