from .base import Detector

__all__ = ['Detector']
