from ..base import Base


class Resampler(Base):
    """Resampler base class"""
