from .base import Proposal

__all__ = ['Proposal']
