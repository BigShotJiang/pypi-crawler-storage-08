from ..base import Base


class Type(Base):
    """Base type"""
