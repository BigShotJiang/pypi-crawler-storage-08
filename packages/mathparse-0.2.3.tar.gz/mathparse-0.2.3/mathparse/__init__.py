"""
mathparse is a library for solving mathematical equations contained in strings
"""

__version__ = '0.2.3'
