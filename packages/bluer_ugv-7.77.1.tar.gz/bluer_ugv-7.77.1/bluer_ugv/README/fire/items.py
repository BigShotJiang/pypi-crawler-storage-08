from bluer_objects.README.items import ImageItems

items = ImageItems({})
