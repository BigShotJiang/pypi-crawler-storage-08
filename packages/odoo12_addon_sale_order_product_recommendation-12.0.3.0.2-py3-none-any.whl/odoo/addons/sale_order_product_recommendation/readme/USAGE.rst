To use this module, you need to:

#. Create a new sale order.
#. Assign its customer.
#. Press *Recommended Products* button.
#. Add products into the opened wizard.
#. Press *Accept*.
