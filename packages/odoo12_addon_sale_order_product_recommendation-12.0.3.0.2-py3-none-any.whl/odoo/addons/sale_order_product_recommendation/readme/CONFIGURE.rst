To configure this module you need to:

In sale order product recommendation you can display the product price unit
from list price or from last sale order price. To set the default value follow
the next steps

#. Go to *Sales > Configuration > Settings > Quotations & Orders*.
#. Assign the desired value to *Product recommendation price origin* field.
#. Press *Save* button to store the change.
