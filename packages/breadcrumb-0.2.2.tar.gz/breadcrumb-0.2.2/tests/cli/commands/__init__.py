"""
Tests for CLI commands.
"""
