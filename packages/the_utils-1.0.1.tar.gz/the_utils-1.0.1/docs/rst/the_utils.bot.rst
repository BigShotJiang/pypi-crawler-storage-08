Bot
----------------------------------------------------------

.. automodule:: the_utils.bot
   :members:
   :no-undoc-members:
   :show-inheritance:
