#!/bin/bash

pytest test