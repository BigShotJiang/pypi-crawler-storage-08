# Web Search Tool

Web Search Tool to search the latest information on the internet.