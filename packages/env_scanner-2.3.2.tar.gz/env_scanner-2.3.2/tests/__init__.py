"""
Tests for env_scanner.
"""

