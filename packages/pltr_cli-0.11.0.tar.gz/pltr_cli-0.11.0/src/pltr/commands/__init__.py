"""CLI commands for pltr."""
