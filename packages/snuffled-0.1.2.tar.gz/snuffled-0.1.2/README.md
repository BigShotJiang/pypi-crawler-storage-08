<!--START_SECTION:images-->
![shields.io-python-versions](https://img.shields.io/badge/python-3.10%20%7C%203.11%20%7C%203.12%20%7C%203.13-blue)
![genbadge-test-count](https://bertpl.github.io/snuffled/version_artifacts/v0.1.2/badge-test-count.svg)
![genbadge-test-coverage](https://bertpl.github.io/snuffled/version_artifacts/v0.1.2/badge-coverage.svg)
![snuffled logo](https://bertpl.github.io/snuffled/version_artifacts/v0.1.2/splash.webp)
<!--END_SECTION:images-->

# SNUFFLED
**S**ystematic **N**umerical **U**nivariate **F**ull-**F**unction ana**L**ysis for **E**stablishing **D**ifficulty of root-finding.