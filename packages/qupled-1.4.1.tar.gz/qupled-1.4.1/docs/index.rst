Welcome to qupled's documentation!
==================================
     
.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   qupled
   examples
   contribute
   
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
