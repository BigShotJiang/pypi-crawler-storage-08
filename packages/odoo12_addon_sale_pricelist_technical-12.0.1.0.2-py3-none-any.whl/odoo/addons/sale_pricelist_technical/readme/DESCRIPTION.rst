This module extends the functionality of the Pricelist module to make it
possible to create "technical pricelists" that can only be used
to compute another pricelists.

These technical pricelists are hidden in the rest of the Odoo interface,
preventing users from using them on sale order forms, customer forms, etc..
