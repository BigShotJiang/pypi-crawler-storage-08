To use this module, you need to go to Sale / Configuration / Pricelists

* Check the box "Is Technical" on your desired pricelist

.. figure:: ../static/description/product_pricelist_form.png
