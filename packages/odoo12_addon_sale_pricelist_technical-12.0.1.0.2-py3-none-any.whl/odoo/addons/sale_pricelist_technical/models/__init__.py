from . import product_pricelist
from . import res_partner
from . import sale_order
