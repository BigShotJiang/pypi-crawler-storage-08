![PyPI - License](https://img.shields.io/pypi/l/toolkit-brazil)
![PyPI - Version](https://img.shields.io/pypi/v/toolkit-brazil)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/toolkit-brazil)
![](https://img.shields.io/badge/Latest%20Release-Oct%2015,%202025-blue)
[![Github](https://img.shields.io/badge/github-toolkit--brazil-blue)](https://github.com/coloric/toolkit-brazil)
<br>
![Pepy Total Downloads](https://img.shields.io/pepy/dt/toolkit-brazil)
![PyPI - Downloads](https://img.shields.io/pypi/dd/toolkit-brazil)
![PyPI - Downloads](https://img.shields.io/pypi/dw/toolkit-brazil)
![PyPI - Downloads](https://img.shields.io/pypi/dm/toolkit-brazil)


# Introduction

A Python module with a collection of useful tools for Brazilians (and anyone else who wants to use it). <br>
Take a look at [CHANGELOG.md](https://github.com/coloric/toolkit-brazil/CHANGELOG.md) for the changes.


# Brief History
I started studying Python recently and wanted to do something that would be useful. Enjoy `toolkit-brazil`.


# Overview

Here's a quick overview of what the library has at the moment:

- Random generation of CPF and CNPJ numbers
- CPF and CNPJ validation
- Check which state a DDD belongs to
- Returns the capital of a state


## Authors

Ricardo Colombani - [@coloric](https://www.github.com/coloric)


## How to install

$ pip install toolkit-brazil


## License

[MIT](https://choosealicense.com/licenses/mit/)