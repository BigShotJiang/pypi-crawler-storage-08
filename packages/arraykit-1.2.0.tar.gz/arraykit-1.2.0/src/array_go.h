# ifndef ARRAYKIT_SRC_ARRAY_GO_H_
# define ARRAYKIT_SRC_ARRAY_GO_H_

# include "Python.h"

extern PyTypeObject ArrayGOType;

# endif /* ARRAYKIT_SRC_ARRAY_GO_H_ */
