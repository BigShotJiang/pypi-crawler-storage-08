# ifndef ARRAYKIT_SRC_AUTO_MAP_H_
# define ARRAYKIT_SRC_AUTO_MAP_H_

# include "Python.h"

// extern PyTypeObject TriMapType;
extern PyTypeObject AMType;
extern PyTypeObject FAMIType;
extern PyTypeObject FAMVType;
extern PyTypeObject FAMType;
extern PyObject *NonUniqueError;


# endif /* ARRAYKIT_SRC_AUTO_MAP_H_ */
