# ifndef ARRAYKIT_SRC_TRI_MAP_H_
# define ARRAYKIT_SRC_TRI_MAP_H_

# include "Python.h"

extern PyTypeObject TriMapType;

# endif /* ARRAYKIT_SRC_TRI_MAP_H_ */
