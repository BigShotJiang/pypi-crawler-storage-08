# hatch-gradle-version
Hatch plugin to manage versioning for a Python project within a Java project.
