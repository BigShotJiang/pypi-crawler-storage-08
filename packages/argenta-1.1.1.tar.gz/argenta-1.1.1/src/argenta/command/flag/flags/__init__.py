__all__ = [
    "Flags",
    "InputFlags"
]


from argenta.command.flag.flags.models import (
    Flags,
    InputFlags
)
