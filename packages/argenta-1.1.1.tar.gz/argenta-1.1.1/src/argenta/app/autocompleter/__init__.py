__all__ = ["AutoCompleter"]


from argenta.app.autocompleter.entity import AutoCompleter
