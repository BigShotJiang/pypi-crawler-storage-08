from argenta.router import Router


system_router = Router(title="System points:")
