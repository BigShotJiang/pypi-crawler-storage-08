from argenta.router.entity import Router


__all__ = ["Router"]
