"""Services module for check_bitdefender."""
