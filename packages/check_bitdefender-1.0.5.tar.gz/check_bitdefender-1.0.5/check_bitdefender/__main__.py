"""Support for python -m check_bitdefender."""

from check_bitdefender.cli import main

if __name__ == "__main__":
    main()
