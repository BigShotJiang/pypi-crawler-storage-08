"""Finviz Provider models."""
