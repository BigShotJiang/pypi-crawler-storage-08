"""Finviz Screener Presets."""
