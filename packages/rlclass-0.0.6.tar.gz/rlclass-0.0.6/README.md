# RLClass Practical sessions
This repository contains utility functions for the practical sessions of the RL class given at ENSAE.
