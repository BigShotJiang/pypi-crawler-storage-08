from setuptools import setup

setup(
    name="rlclass",
    version="0.0.6",
    author="Hugo RICHARD",
    author_email="research.hugo.richard@gmail.com",
    description="",
    license="BSD",
    keywords="RL",
    packages=['rlclass'],
)
