from django.apps import AppConfig


class WildewidgetsConfig(AppConfig):  # noqa: D101
    name: str = "wildewidgets"
