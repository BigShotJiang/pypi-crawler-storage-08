from __future__ import annotations

pytest_plugins = ["pytester"]
