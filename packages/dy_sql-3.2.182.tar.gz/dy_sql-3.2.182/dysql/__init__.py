"""
Copyright 2021 Adobe
All Rights Reserved.

NOTICE: Adobe permits you to use, modify, and distribute this file in accordance
with the terms of the Adobe license agreement accompanying it.
"""

# Public imports
from .mappers import (
    BaseMapper,
    DbMapResult,
    RecordCombiningMapper,
    SingleRowMapper,
    SingleColumnMapper,
    SingleRowAndColumnMapper,
    CountMapper,
    KeyValueMapper,
)
from .query_utils import QueryData, QueryDataError, TemplateGenerators
from .connections import (
    sqlexists,
    sqlquery,
    sqlupdate,
)
from .databases import (
    is_set_current_database_supported,
    reset_current_database,
    set_current_database,
    set_database_init_hook,
    set_default_connection_parameters,
)
from .multitenancy import use_database_tenant, tenant_database_manager
from .exceptions import DBNotPreparedError


__all__ = [
    "BaseMapper",
    "DbMapResult",
    "RecordCombiningMapper",
    "SingleRowMapper",
    "SingleColumnMapper",
    "SingleRowAndColumnMapper",
    "CountMapper",
    "KeyValueMapper",
    "QueryData",
    "QueryDataError",
    "TemplateGenerators",
    "sqlexists",
    "sqlquery",
    "sqlupdate",
    "is_set_current_database_supported",
    "reset_current_database",
    "set_current_database",
    "set_database_init_hook",
    "set_default_connection_parameters",
    "use_database_tenant",
    "tenant_database_manager",
    "DBNotPreparedError",
]
