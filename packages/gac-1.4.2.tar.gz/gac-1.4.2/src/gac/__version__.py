"""Version information for gac package."""

__version__ = "1.4.2"
