# --- GENERAL ---
PING_PATH = "/ping"
