"""Helper function tests"""
