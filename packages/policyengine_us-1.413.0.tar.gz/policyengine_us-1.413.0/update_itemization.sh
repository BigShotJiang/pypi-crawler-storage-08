#!/bin/bash
sed -i 's/0000-01-01: true/0000-01-01: false/' policyengine_us/parameters/gov/simulation/branch_to_determine_itemization.yaml