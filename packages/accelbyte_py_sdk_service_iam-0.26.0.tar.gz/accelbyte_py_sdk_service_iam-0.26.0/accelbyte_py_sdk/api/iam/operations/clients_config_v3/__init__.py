# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Iam Service."""

__version__ = "7.35.0"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .admin_delete_config_per_4d40c6 import AdminDeleteConfigPermissionsByGroup
from .admin_list_client_avail_561e53 import AdminListClientAvailablePermissions
from .admin_list_client_templates import AdminListClientTemplates
from .admin_update_available__50a681 import AdminUpdateAvailablePermissionsByModule
