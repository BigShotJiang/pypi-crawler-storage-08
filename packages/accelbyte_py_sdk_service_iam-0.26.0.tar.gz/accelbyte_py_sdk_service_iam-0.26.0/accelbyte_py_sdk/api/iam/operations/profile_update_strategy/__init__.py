# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Iam Service."""

__version__ = "7.35.0"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .admin_get_profile_updat_5f84fb import AdminGetProfileUpdateStrategyV3
from .admin_get_profile_updat_5f84fb import (
    FieldEnum as AdminGetProfileUpdateStrategyV3FieldEnum,
)
from .admin_update_profile_up_038023 import AdminUpdateProfileUpdateStrategyV3
from .admin_update_profile_up_038023 import (
    FieldEnum as AdminUpdateProfileUpdateStrategyV3FieldEnum,
)
from .public_get_profile_upda_626804 import PublicGetProfileUpdateStrategyV3
from .public_get_profile_upda_626804 import (
    FieldEnum as PublicGetProfileUpdateStrategyV3FieldEnum,
)
