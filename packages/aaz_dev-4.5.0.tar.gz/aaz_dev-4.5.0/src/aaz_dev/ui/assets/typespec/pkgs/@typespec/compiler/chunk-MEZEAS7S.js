// src/typespec/core/packages/compiler/dist/src/casing/index.js
function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

export {
  capitalize
};
