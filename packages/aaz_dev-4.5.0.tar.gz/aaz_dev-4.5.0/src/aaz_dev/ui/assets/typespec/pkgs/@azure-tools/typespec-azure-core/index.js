var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/typespec/packages/typespec-azure-core/dist/src/index.js
var src_exports = {};
__export(src_exports, {
  $addTraitProperties: () => $addTraitProperties,
  $applyTraitOverride: () => $applyTraitOverride,
  $armResourceIdentifierConfig: () => $armResourceIdentifierConfig,
  $decorators: () => $decorators2,
  $defaultFinalStateVia: () => $defaultFinalStateVia,
  $embeddingVector: () => $embeddingVector,
  $ensureAllHeaderParams: () => $ensureAllHeaderParams,
  $ensureAllQueryParams: () => $ensureAllQueryParams,
  $ensureResourceType: () => $ensureResourceType,
  $ensureTraitsPresent: () => $ensureTraitsPresent,
  $ensureVerb: () => $ensureVerb,
  $finalLocation: () => $finalLocation,
  $finalOperation: () => $finalOperation,
  $fixed: () => $fixed,
  $items: () => $items,
  $lib: () => $lib,
  $linter: () => $linter,
  $lroCanceled: () => $lroCanceled,
  $lroErrorResult: () => $lroErrorResult,
  $lroFailed: () => $lroFailed,
  $lroResult: () => $lroResult,
  $lroStatus: () => $lroStatus,
  $lroSucceeded: () => $lroSucceeded,
  $needsRoute: () => $needsRoute,
  $nextPageOperation: () => $nextPageOperation,
  $omitKeyProperties: () => $omitKeyProperties,
  $operationLink: () => $operationLink,
  $pagedResult: () => $pagedResult,
  $pollingLocation: () => $pollingLocation,
  $pollingOperation: () => $pollingOperation,
  $pollingOperationParameter: () => $pollingOperationParameter,
  $requestParameter: () => $requestParameter,
  $responseProperty: () => $responseProperty,
  $spreadCustomParameters: () => $spreadCustomParameters,
  $spreadCustomResponseProperties: () => $spreadCustomResponseProperties,
  $trait: () => $trait,
  $traitAdded: () => $traitAdded,
  $traitContext: () => $traitContext,
  $traitLocation: () => $traitLocation,
  $traitSource: () => $traitSource,
  $useFinalStateVia: () => $useFinalStateVia,
  FinalOperationKey: () => FinalOperationKey,
  FinalStateValue: () => FinalStateValue,
  PollingOperationKey: () => PollingOperationKey,
  checkEnsureVerb: () => checkEnsureVerb,
  checkRpcRoutes: () => checkRpcRoutes,
  extractLroStates: () => extractLroStates,
  filterModelProperties: () => filterModelProperties,
  filterResponseModels: () => filterResponseModels,
  getAllProperties: () => getAllProperties,
  getArmResourceIdentifierConfig: () => getArmResourceIdentifierConfig,
  getAsEmbeddingVector: () => getAsEmbeddingVector,
  getFinalLocationValue: () => getFinalLocationValue,
  getFinalStateOverride: () => getFinalStateOverride,
  getHttpMetadata: () => getHttpMetadata,
  getItems: () => getItems,
  getLongRunningStates: () => getLongRunningStates,
  getLroErrorResult: () => getLroErrorResult,
  getLroMetadata: () => getLroMetadata,
  getLroResult: () => getLroResult,
  getLroStatusProperty: () => getLroStatusProperty2,
  getNextLink: () => getNextLink,
  getOperationLink: () => getOperationLink,
  getOperationLinks: () => getOperationLinks,
  getOperationResponse: () => getOperationResponse,
  getPagedResult: () => getPagedResult,
  getParameterizedNextLinkArguments: () => getParameterizedNextLinkArguments,
  getPollingLocationInfo: () => getPollingLocationInfo,
  getPollingOperationParameter: () => getPollingOperationParameter,
  getRequestParameter: () => getRequestParameter,
  getResponseProperty: () => getResponseProperty,
  getResultModelWithProperty: () => getResultModelWithProperty,
  getSourceTraitName: () => getSourceTraitName,
  getSuccessResponse: () => getSuccessResponse,
  getTraitContexts: () => getTraitContexts,
  getTraitLocation: () => getTraitLocation,
  getTraitName: () => getTraitName,
  getUnionAsEnum: () => getUnionAsEnum,
  isFinalLocation: () => isFinalLocation,
  isFixed: () => isFixed,
  isLroCanceledState: () => isLroCanceledState,
  isLroFailedState: () => isLroFailedState,
  isLroSucceededState: () => isLroSucceededState,
  isPollingLocation: () => isPollingLocation,
  isResourceOperation: () => isResourceOperation,
  isTraitModel: () => isTraitModel,
  namespace: () => namespace,
  parameterizedNextLinkConfigDecorator: () => parameterizedNextLinkConfigDecorator,
  pollingOptionsKind: () => pollingOptionsKind,
  preventRestLibraryInterfaces: () => preventRestLibraryInterfaces,
  useStandardOperations: () => useStandardOperations
});

// src/typespec/packages/typespec-azure-core/dist/src/lib.js
import { createTypeSpecLibrary, paramMessage } from "@typespec/compiler";
var $lib = createTypeSpecLibrary({
  name: "@azure-tools/typespec-azure-core",
  diagnostics: {
    "lro-status-union-non-string": {
      severity: "error",
      messages: {
        default: paramMessage`Union contains non-string value type ${"type"}.`
      }
    },
    "lro-status-property-invalid-type": {
      severity: "error",
      messages: {
        default: "Property type must be a union of strings or an enum."
      }
    },
    "lro-status-missing": {
      severity: "error",
      messages: {
        default: paramMessage`Terminal long-running operation states are missing: ${"states"}.`
      }
    },
    "lro-status-monitor-invalid-result-property": {
      severity: "warning",
      messages: {
        default: paramMessage`StatusMonitor has more than one ${"resultType"} property marked with '${"decorator"}'.  Ensure that only one property in the model is marked with this decorator.`
      }
    },
    "invalid-final-state": {
      severity: "warning",
      messages: {
        badValue: paramMessage`Specified final state value '${"finalStateValue"}' is not valid. It must be one of ("operation-location", "original-uri", "location", "azure-async-operation")`,
        notPut: "The final state value 'original-uri' can only be used in http PUT operations",
        noHeader: paramMessage`There was no header corresponding to the desired final-state-via value '${"finalStateValue"}'.`
      }
    },
    "bad-record-type": {
      severity: "warning",
      messages: {
        extendUnknown: paramMessage`${"name"} should not use '${"keyword"} Record<${"typeName"}>'. Use '${"keyword"} Record<string>' instead.`,
        recordWithProperties: paramMessage`${"name"} that uses '${"keyword"} Record<${"typeName"}>' should not have properties.`
      }
    },
    "request-parameter-invalid": {
      severity: "error",
      messages: {
        default: paramMessage`Request parameter '${"name"}' not found on request body model.`
      }
    },
    "response-property-invalid": {
      severity: "error",
      messages: {
        default: paramMessage`Response property '${"name"}' not found on success response model.`
      }
    },
    "operation-link-parameter-invalid": {
      severity: "error",
      messages: {
        default: "Parameters must be of template type RequestParameter<T> or ResponseProperty<T>."
      }
    },
    "operation-link-parameter-invalid-target": {
      severity: "error",
      messages: {
        default: paramMessage`Request parameter '${"name"}' not found in linked operation.`
      }
    },
    "invalid-resource-type": {
      severity: "error",
      messages: {
        missingKey: paramMessage`Model type '${"name"}' is not a valid resource type.  It must contain a property decorated with '@key'.`,
        missingSegment: paramMessage`Model type '${"name"}' is not a valid resource type.  It must be decorated with the '@resource' decorator.`
      }
    },
    "polling-operation-return-model": {
      severity: "error",
      messages: {
        default: "An operation annotated with @pollingOperation must return a model or union of model."
      }
    },
    "polling-operation-no-status-monitor": {
      severity: "warning",
      messages: {
        default: "The operation linked in  @pollingOperation must return a valid status monitor.  The status monitor model must contain a 'status' property, or a property decorated with  '@lroStatus'.  The status field must be of Enum or Union type and contain terminal status values for success and failure."
      }
    },
    "polling-operation-no-lro-success": {
      severity: "warning",
      messages: {
        default: "The status monitor returned from the polling operation must have a status property, with a known status value the indicates successful completion. This known value may be named 'Succeeded' or marked with the '@lroSucceeded' decorator."
      }
    },
    "polling-operation-no-lro-failure": {
      severity: "warning",
      messages: {
        default: "The status monitor returned from the polling operation must have a status property, with a known status value the indicates failure. This known value may be named 'Failed' or marked with the '@lroFailed' decorator."
      }
    },
    "polling-operation-no-ref-or-link": {
      severity: "warning",
      messages: {
        default: "An operation decorated with '@pollingOperation' must either return a response with an 'Operation-Location' header that will contain a runtime link to the polling operation, or specify parameters and return type properties to map into the polling operation parameters.  A map into polling operation parameters can be created using the '@pollingOperationParameter' decorator"
      }
    },
    "invalid-final-operation": {
      severity: "warning",
      messages: {
        default: "The operation linked in the '@finalOperation' decorator must have a 200 response that includes a model."
      }
    },
    "invalid-trait-property-count": {
      severity: "error",
      messages: {
        default: paramMessage`Trait type '${"modelName"}' is not a valid trait type.  It must contain exactly one property that maps to a model type.`
      }
    },
    "invalid-trait-property-type": {
      severity: "error",
      messages: {
        default: paramMessage`Trait type '${"modelName"}' has an invalid envelope property type.  The property '${"propertyName"}' must be a model type.`
      }
    },
    "invalid-trait-context": {
      severity: "error",
      messages: {
        default: "The trait context can only be an enum member, union of enum members, or `unknown`."
      }
    },
    "trait-property-without-location": {
      severity: "error",
      messages: {
        default: paramMessage`Trait type '${"modelName"}' contains property '${"propertyName"}' which does not have a @traitLocation decorator.`
      }
    },
    "expected-trait-missing": {
      severity: "error",
      messages: {
        default: paramMessage`Expected trait '${"trait"}' is missing. ${"message"}`
      }
    },
    "client-request-id-trait-missing": {
      severity: "warning",
      messages: {
        default: paramMessage`The ClientRequestId trait is required for the ResourceOperations interface.  Include either SupportsClientRequestId or NoClientRequestId in the traits model for your interface declaration.`
      }
    },
    "repeatable-requests-trait-missing": {
      severity: "warning",
      messages: {
        default: paramMessage`The RepeatableRequests trait is required for the ResourceOperations interface.  Include either SupportsRepeatableRequests or NoRepeatableRequests in the traits model for your interface declaration.`
      }
    },
    "conditional-requests-trait-missing": {
      severity: "warning",
      messages: {
        default: paramMessage`The ConditionalRequests trait is required for the ResourceOperations interface.  Include either SupportsConditionalRequests or NoConditionalRequests in the traits model for your interface declaration.`
      }
    },
    "expected-trait-diagnostic-missing": {
      severity: "error",
      messages: {
        default: `Expected trait entries must have a "diagnostic" field with a valid diagnostic code for the missing trait.`
      }
    },
    "invalid-parameter": {
      severity: "error",
      messages: {
        default: paramMessage`Expected property '${"propertyName"}' to be a ${"kind"} parameter.`
      }
    },
    "expected-success-response": {
      severity: "error",
      messages: {
        default: "The operation must have a success response"
      }
    },
    "lro-polling-data-missing-from-operation-response": {
      severity: "error",
      messages: {
        default: "At least one operation response must contain a field marked with `@lroStatus`"
      }
    },
    "no-object": {
      severity: "warning",
      messages: {
        default: "Don't use 'object'.\n - If you want an object with any properties, use `Record<unknown>`\n - If you meant anything, use `unknown`."
      }
    },
    "verb-conflict": {
      severity: "warning",
      messages: {
        default: paramMessage`Operation template '${"templateName"}' requires HTTP verb '${"requiredVerb"}' but found '${"verb"}'.`
      }
    },
    "rpc-operation-needs-route": {
      severity: "warning",
      messages: {
        default: "The operation needs a @route"
      }
    },
    "union-enums-multiple-kind": {
      severity: "warning",
      messages: {
        default: paramMessage`Couldn't resolve the kind of the union as it has multiple types: ${"kinds"}`
      }
    },
    "union-enums-invalid-kind": {
      severity: "warning",
      messages: {
        default: paramMessage`Kind ${"kind"} prevents this union from being resolved as an enum.`
      }
    },
    "union-enums-circular": {
      severity: "warning",
      messages: {
        default: `Union is referencing itself and cannot be resolved as an enum.`
      }
    }
  },
  state: {
    fixed: { description: "Data for `@fixed` decorator" },
    pagedResult: { description: "Data for `@pagedResult` decorator" },
    items: { description: "Data for `@items` decorator" },
    lroStatus: { description: "Data for `@lroStatus` decorator" },
    lroSucceeded: { description: "Data for `@lroSucceeded` decorator" },
    lroCanceled: { description: "Data for `@lroCanceled` decorator" },
    lroFailed: { description: "Data for `@lroFailed` decorator" },
    lroResult: { description: "Data for `@lroResult` decorator" },
    lroErrorResult: { description: "Data for `@lroErrorResult` decorator" },
    pollingOperationParameter: { description: "Data for `@pollingOperationParameter` decorator" },
    pollingLocationInfo: { description: "Data for `@pollingLocationInfo` decorator" },
    finalLocations: { description: "Data for `@finalLocations` decorator" },
    finalLocationResults: { description: "Data for `@finalLocationResults` decorator" },
    finalStateOverride: { description: "Data for `@finalStateOverride` decorator" },
    needsRoute: { description: "Data for `@needsRoute` decorator" },
    ensureVerb: { description: "Data for `@ensureVerb` decorator" },
    embeddingVector: { description: "Data for `@embeddingVector` decorator" },
    armResourceIdentifierConfig: {
      description: "Data for `@armResourceIdentifierConfig` decorator"
    },
    operationLink: { description: "Data for `@operationLink` decorator" },
    requestParameter: { description: "Data for `@requestParameter` decorator" },
    responseParameter: { description: "Data for `@responseParameter` decorator" },
    resourceOperation: { description: "Data for `@resourceOperation` decorator" },
    traitSource: { description: "Data for `@traitSource` decorator" },
    trait: { description: "Data for `@trait` decorator" },
    traitContext: { description: "Data for `@traitContext` decorator" },
    traitLocation: { description: "Data for `@traitLocation` decorator" },
    parameterizedNextLinkConfig: {
      description: "Data for `@parameterizedNextLinkConfig` decorator"
    }
  }
  // AzureCoreStateKeys.traitLocation
});
var { reportDiagnostic, createDiagnostic, stateKeys: AzureCoreStateKeys } = $lib;

// src/typespec/packages/typespec-azure-core/dist/src/linter.js
import { defineLinter } from "@typespec/compiler";

// src/typespec/packages/typespec-azure-core/dist/src/rules/auth-required.js
import { createRule, getService } from "@typespec/compiler";
import { getAuthentication } from "@typespec/http";
var authRequiredRule = createRule({
  name: "auth-required",
  description: "Enforce service authentication.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/auth-required",
  messages: {
    default: "Provide an authentication scheme using the `@useAuth` decorator. See: https://azure.github.io/typespec-azure/docs/reference/azure-style-guide#security-definitions"
  },
  create(context) {
    return {
      namespace: (namespace2) => {
        const service = getService(context.program, namespace2);
        if (!service)
          return;
        const auth = getAuthentication(context.program, namespace2);
        if (!auth) {
          context.reportDiagnostic({
            target: namespace2
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/bad-record-type.js
import { createRule as createRule2, paramMessage as paramMessage2 } from "@typespec/compiler";
function validateIsRecordType(context, type, target) {
  if (type.kind === "Intrinsic" && type.name === "unknown") {
    context.reportDiagnostic({
      messageId: "extendUnknown",
      target,
      format: { name: target.name, typeName: type.name, keyword: "is" }
    });
  } else if (type.kind === "Scalar" && target.properties.size > 0) {
    context.reportDiagnostic({
      messageId: "recordWithProperties",
      target,
      format: { name: target.name, typeName: type.name, keyword: "is" }
    });
  }
}
function validateExtendsRecordType(context, baseModel, target) {
  if (!baseModel.indexer) {
    return;
  }
  const indexerVal = baseModel.indexer.value;
  if (indexerVal.kind === "Intrinsic" && indexerVal.name === "unknown") {
    context.reportDiagnostic({
      messageId: "extendUnknown",
      target,
      format: { name: target.name, typeName: indexerVal.name, keyword: "extends" }
    });
  } else if (indexerVal.kind === "Scalar" && target.properties.size > 0) {
    context.reportDiagnostic({
      messageId: "recordWithProperties",
      target,
      format: { name: target.name, typeName: indexerVal.name, keyword: "extends" }
    });
  }
}
function validatePropertyRecordType(context, type, target) {
  if (type.kind === "Model" && type.indexer) {
    const indexerVal = type.indexer.value;
    if (indexerVal.kind === "Intrinsic" && indexerVal.name === "unknown") {
      const displayName = target.model ? `${target.model.name}.${target.name}` : target.name;
      context.reportDiagnostic({
        messageId: "extendUnknown",
        target,
        format: {
          name: displayName,
          typeName: indexerVal.name,
          keyword: ":"
        }
      });
    }
  }
}
var badRecordTypeRule = createRule2({
  name: "bad-record-type",
  description: "Identify bad record definitions.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/bad-record-type",
  messages: {
    extendUnknown: paramMessage2`${"name"} should not use '${"keyword"} Record<${"typeName"}>'. Use '${"keyword"} Record<string>' instead.`,
    recordWithProperties: paramMessage2`${"name"} that uses '${"keyword"} Record<${"typeName"}>' should not have properties.`
  },
  create(context) {
    return {
      model: (model) => {
        if (model.indexer && model.name !== "Record") {
          validateIsRecordType(context, model.indexer.value, model);
        } else if (model.baseModel) {
          validateExtendsRecordType(context, model.baseModel, model);
        }
      },
      modelProperty: (prop) => {
        if (prop.type.kind === "Model" && prop.type.indexer) {
          validatePropertyRecordType(context, prop.type, prop);
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/byos.js
import { createRule as createRule3, ignoreDiagnostics, isTemplateInstance, paramMessage as paramMessage3 } from "@typespec/compiler";
import { getHttpOperation } from "@typespec/http";
var binaryContentTypes = /* @__PURE__ */ new Set(["application/octet-stream", "multipart/form-data"]);
var byosRule = createRule3({
  name: "byos",
  description: "Use the BYOS pattern recommended for Azure Services.",
  severity: "warning",
  messages: {
    default: paramMessage3`The content type "${"contentType"}" indicates this operation is storing or retrieving binary data. It is recommended to use the BYOS pattern for Azure Services. https://github.com/microsoft/api-guidelines/blob/vNext/azure/Guidelines.md#bring-your-own-storage-byos`
  },
  create(context) {
    return {
      operation: (operation) => {
        if (isTemplateInstance(operation)) {
          return;
        }
        const httpOperation = ignoreDiagnostics(getHttpOperation(context.program, operation));
        if (httpOperation.parameters.body !== void 0) {
          for (const contentType of httpOperation.parameters.body.contentTypes) {
            if (binaryContentTypes.has(contentType)) {
              context.reportDiagnostic({
                format: { contentType },
                target: operation
              });
            }
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/casing-style.js
import { createRule as createRule4, isTemplateDeclarationOrInstance, paramMessage as paramMessage4 } from "@typespec/compiler";

// src/typespec/packages/typespec-azure-core/dist/src/rules/utils.js
import { getLocationContext, getNamespaceFullName, getTypeName, isTemplateDeclaration } from "@typespec/compiler";
import { SyntaxKind } from "@typespec/compiler/ast";
function getNamespaceName(program, type) {
  if (type === void 0)
    return "";
  if (type.kind === "ModelProperty")
    return type.model ? getNamespaceName(program, type.model) : "";
  if (type.kind === "EnumMember")
    return type.enum ? getNamespaceName(program, type.enum) : "";
  if (type.kind === "UnionVariant")
    return type.union ? getNamespaceName(program, type.union) : "";
  if (type.kind !== "Namespace")
    type = type.namespace;
  if (type === void 0) {
    return "";
  }
  return getNamespaceFullName(type);
}
function isExcludedCoreType(program, type) {
  const nsName = getNamespaceName(program, type);
  const allowedNamespaces = ["TypeSpec", "Azure.Core", "Azure.ResourceManager", "OpenAPI"];
  return allowedNamespaces.find((allowed) => nsName.startsWith(allowed)) !== void 0;
}
function isAzureSubNamespace(program, ns) {
  if (!ns)
    return false;
  const nsName = getNamespaceName(program, ns);
  return nsName.startsWith("Azure.");
}
function isInlineModel(target) {
  return !target.name;
}
function isTemplateDeclarationType(target) {
  return target.node?.kind === SyntaxKind.ModelStatement && target.node.templateParameters.length;
}
function isTemplatedInterfaceOperation(target) {
  return target.node?.kind === SyntaxKind.OperationStatement && target.interface && isTemplateDeclaration(target.interface);
}
function isTemplatedOperationSignature(target) {
  return target.node?.kind === SyntaxKind.OperationStatement && isTemplateDeclaration(target);
}
function isPascalCaseNoAcronyms(name) {
  if (name === void 0 || name === null || name === "")
    return true;
  return /^([A-Z][a-z0-9]+)*[A-Z]?$/.test(name);
}
function isPascalCaseWithAcceptedAcronyms(name, acceptedAcronyms) {
  if (isPascalCaseNoAcronyms(name)) {
    return true;
  }
  const acceptedAcronymsRegex = new RegExp(`^([A-Z][a-z0-9]*)*(${acceptedAcronyms.join("|")})([A-Z][a-z0-9]*)?$`);
  return acceptedAcronymsRegex.test(name);
}
function isCamelCaseNoAcronyms(name) {
  if (name === void 0 || name === null || name === "")
    return true;
  return /^[^a-zA-Z0-9]?[a-z][a-z0-9]*([A-Z][a-z0-9]+)*[A-Z]?$/.test(name);
}
function findLineStartAndIndent(location) {
  const text = location.file.text;
  let pos = location.pos;
  let indent = 0;
  while (pos > 0 && text[pos - 1] !== "\n") {
    if ([" ", "	", "\n"].includes(text[pos - 1])) {
      indent++;
    } else {
      indent = 0;
    }
    pos--;
  }
  return { lineStart: pos, indent: location.file.text.slice(pos, pos + indent) };
}
function checkReferenceInDisallowedNamespace(context, origin, type, target, disallowedNamespace) {
  if (getLocationContext(context.program, origin).type !== "project") {
    return;
  }
  if (getLocationContext(context.program, type).type === "project") {
    return;
  }
  if (isInDisallowedNamespace(type, disallowedNamespace)) {
    context.reportDiagnostic({
      target,
      format: { ns: getTypeName(type.namespace) }
    });
  }
}
function checkDecoratorsInDisallowedNamespace(context, type, disallowedNamespace) {
  if (getLocationContext(context.program, type).type !== "project") {
    return;
  }
  for (const decorator of type.decorators) {
    if (decorator.definition && isInDisallowedNamespace(decorator.definition, disallowedNamespace) && getLocationContext(context.program, decorator.definition).type !== "project") {
      context.reportDiagnostic({
        target: decorator.node ?? type,
        format: { ns: getTypeName(decorator.definition.namespace) }
      });
    }
  }
}
function isInDisallowedNamespace(type, disallowedNamespace) {
  if (!("namespace" in type)) {
    return false;
  }
  let current = type;
  while (current.namespace) {
    if (current.namespace?.name === disallowedNamespace) {
      return true;
    }
    current = current.namespace;
  }
  return false;
}

// src/typespec/packages/typespec-azure-core/dist/src/rules/casing-style.js
var acceptedAzureAcronyms = ["AI", "VM", "OS", "IP", "CPU", "GPU", "LRO"];
var casingRule = createRule4({
  name: "casing-style",
  description: "Ensure proper casing style.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/casing-style",
  messages: {
    default: paramMessage4`The names of ${"type"} types must use ${"casing"}`
  },
  create(context) {
    return {
      model: (model) => {
        if (!isPascalCaseWithAcceptedAcronyms(model.name, acceptedAzureAcronyms)) {
          context.reportDiagnostic({
            format: { type: "Model", casing: "PascalCase" },
            target: model
          });
        }
      },
      modelProperty: (property) => {
        if (property.name === "_")
          return;
        if (!isCamelCaseNoAcronyms(property.name)) {
          context.reportDiagnostic({
            format: { type: "Property", casing: "camelCase" },
            target: property
          });
        }
      },
      operation: (operation) => {
        if (isTemplateDeclarationOrInstance(operation)) {
          if (!isPascalCaseWithAcceptedAcronyms(operation.name, acceptedAzureAcronyms)) {
            context.reportDiagnostic({
              format: { type: "Operation Template", casing: "PascalCase" },
              target: operation
            });
          }
        } else if (!isCamelCaseNoAcronyms(operation.name)) {
          context.reportDiagnostic({
            format: { type: "Operation", casing: "camelCase" },
            target: operation
          });
        }
      },
      interface: (operationGroup) => {
        if (!isPascalCaseWithAcceptedAcronyms(operationGroup.name, acceptedAzureAcronyms)) {
          context.reportDiagnostic({
            format: { type: "Interface", casing: "PascalCase" },
            target: operationGroup
          });
        }
      },
      namespace: (namespace2) => {
        if (!isPascalCaseWithAcceptedAcronyms(namespace2.name, acceptedAzureAcronyms)) {
          context.reportDiagnostic({
            format: { type: "Namespace", casing: "PascalCase" },
            target: namespace2
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/composition-over-inheritance.js
import { createRule as createRule5, getDiscriminator, getTypeName as getTypeName2, isTemplateInstance as isTemplateInstance2, paramMessage as paramMessage5 } from "@typespec/compiler";
import { SyntaxKind as SyntaxKind2 } from "@typespec/compiler/ast";
var compositionOverInheritanceRule = createRule5({
  name: "composition-over-inheritance",
  description: "Check that if a model is used in an operation and has derived models that it has a discriminator or recommend to use composition via spread or `is`.",
  severity: "warning",
  messages: {
    default: paramMessage5`Model '${"name"}' is extending '${"baseModel"}' that doesn't define a discriminator. If '${"baseModel"}' is meant to be used:
 - For composition consider using spread \`...\` or \`model is\` instead.
 - As a polymorphic relation, add the \`@discriminator\` decorator on the base model.`,
    instance: paramMessage5`Model '${"name"}' is extending a template '${"baseModel"}'. Consider using composition with spread \`...\` or \`model is\` instead.`
  },
  create(context) {
    return {
      model: (model) => {
        if (model.baseModel && model.node?.kind === SyntaxKind2.ModelStatement && model.node.extends && getDiscriminator(context.program, model.baseModel) === void 0) {
          context.reportDiagnostic({
            messageId: isTemplateInstance2(model.baseModel) ? "instance" : "default",
            format: {
              name: model.name,
              baseModel: getTypeName2(model.baseModel)
            },
            target: model.node.extends
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/friendly-name.js
import { createRule as createRule6, isTemplateInstance as isTemplateInstance3, paramMessage as paramMessage6 } from "@typespec/compiler";
import { SyntaxKind as SyntaxKind3 } from "@typespec/compiler/ast";
var friendlyNameRule = createRule6({
  name: "friendly-name",
  description: "Ensures that @friendlyName is used as intended.",
  severity: "warning",
  messages: {
    scope: paramMessage6`@friendlyName should not decorate ${"kind"}.`,
    template: paramMessage6`@friendlyName should decorate template and use template parameter's properties in friendly name.`
  },
  create(context) {
    return {
      model: (entity) => {
        checkFriendlyName(context, entity);
      },
      modelProperty: (entity) => {
        checkFriendlyName(context, entity);
      },
      scalar: (entity) => {
        checkFriendlyName(context, entity);
      },
      interface: (entity) => {
        checkFriendlyName(context, entity);
      },
      enum: (entity) => {
        checkFriendlyName(context, entity);
      },
      enumMember: (entity) => {
        checkFriendlyName(context, entity);
      },
      namespace: (entity) => {
        checkFriendlyName(context, entity);
      },
      operation: (entity) => {
        checkFriendlyName(context, entity);
      },
      union: (entity) => {
        checkFriendlyName(context, entity);
      },
      unionVariant: (entity) => {
        checkFriendlyName(context, entity);
      }
    };
  }
});
function checkFriendlyName(context, type) {
  const decorator = getFriendlyNameDecoratorOnType(type);
  if (decorator) {
    if (["Model", "Operation", "Interface", "Union"].includes(type.kind)) {
      if (!isTemplateInstance3(type) || decorator.args.length !== 2) {
        context.reportDiagnostic({
          messageId: "template",
          target: type,
          format: {}
        });
      }
    } else {
      context.reportDiagnostic({
        messageId: "scope",
        target: type,
        format: { kind: type.kind }
      });
    }
  }
}
function getFriendlyNameDecoratorOnType(type) {
  const decorators = type.decorators.filter((x) => x.decorator.name === "$friendlyName" && x.node?.kind === SyntaxKind3.DecoratorExpression && x.node?.parent === type.node);
  return decorators[0];
}

// src/typespec/packages/typespec-azure-core/dist/src/rules/known-encoding.js
import { createRule as createRule7, getEncode, paramMessage as paramMessage7 } from "@typespec/compiler";
var knownEncodings = /* @__PURE__ */ new Set([
  // utcDateTime and offsetDateTime
  "rfc3339",
  "rfc7231",
  "unixTimestamp",
  // duration
  "ISO8601",
  "seconds",
  // bytes
  "base64",
  "base64url"
]);
var knownEncodingRule = createRule7({
  name: "known-encoding",
  description: "Check for supported encodings.",
  severity: "warning",
  messages: {
    default: paramMessage7`Encoding "${"encoding"}" is not supported for Azure Services. Known encodings are: ${"knownEncodings"}`
  },
  create(context) {
    function checkEncoding(type) {
      const encode = getEncode(context.program, type);
      if (encode && encode.encoding) {
        if (!knownEncodings.has(encode.encoding)) {
          context.reportDiagnostic({
            format: {
              encoding: encode.encoding,
              knownEncodings: [...knownEncodings].join(",")
            },
            target: type
          });
        }
      }
    }
    return {
      modelProperty: (property) => checkEncoding(property),
      scalar: (scalar) => checkEncoding(scalar)
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/lro-polling-operation.js
import { createRule as createRule8 } from "@typespec/compiler";
import { getHeaderFieldName as getHeaderFieldName3, isHeader as isHeader3 } from "@typespec/http";

// src/typespec/packages/typespec-azure-core/dist/src/utils.js
import { isErrorModel } from "@typespec/compiler";
import { getHttpOperation as getHttpOperation2, isStatusCode } from "@typespec/http";
function filterModelProperties(model, predicate) {
  return [...getAllProperties(model).values()].filter(predicate);
}
function filterResponseModels(operation, predicate) {
  const models = [];
  for (const response of operation.responses) {
    switch (response.type.kind) {
      case "Model":
        if (predicate(response.type))
          models.push(response.type);
        break;
      case "Union":
        for (const variant of response.type.variants.values()) {
          if (variant.type.kind === "Model" && predicate(variant.type))
            models.push(variant.type);
        }
        break;
      case "Tuple":
        for (const type of response.type.values) {
          if (type.kind === "Model" && predicate(type))
            models.push(type);
        }
    }
  }
  return models.length > 0 ? models : void 0;
}
function getHttpMetadata(program, operation) {
  const [httpOperation, diagnostics] = getHttpOperation2(program, operation);
  if (diagnostics && diagnostics.length > 0) {
    program.reportDiagnostics(diagnostics);
  }
  return httpOperation;
}
function getOperationResponse(program, operation) {
  const response = getSuccessResponse(program, getHttpMetadata(program, operation));
  if (response === void 0) {
    reportDiagnostic(program, { code: "expected-success-response", target: operation });
  }
  return response;
}
function getResultModelWithProperty(program, operation, predicate) {
  const httpOperation = getHttpMetadata(program, operation);
  const models = filterResponseModels(httpOperation, (model) => filterModelProperties(model, predicate).length > 0);
  if (models === void 0 || models.length < 1)
    return void 0;
  const properties = [...models[0].properties.values()].filter(predicate);
  if (properties.length < 1)
    return void 0;
  return [models[0], properties[0]];
}
function getSuccessResponse(program, operation) {
  const candidates = filterResponseModels(operation, (response) => !isErrorModel(program, response))?.filter((m) => {
    const prop = getStatusCodeProperty(program, m);
    return prop === void 0 || prop.type?.kind === "String" && prop.type.value?.startsWith("2") || prop.type?.kind === "Number" && prop.type.value >= 200 && prop.type.value < 300;
  });
  if (candidates === void 0 || candidates.length < 1)
    return void 0;
  return candidates[0];
}
function getStatusCodeProperty(program, model) {
  const properties = filterModelProperties(model, (prop) => isStatusCode(program, prop));
  return properties.length > 0 ? properties[0] : void 0;
}
function getAllProperties(model, collection) {
  const outCollection = collection ?? /* @__PURE__ */ new Map();
  for (const [name, value] of model.properties.entries()) {
    outCollection.set(name, value);
  }
  if (model.baseModel)
    return getAllProperties(model.baseModel, outCollection);
  return outCollection;
}

// src/typespec/packages/typespec-azure-core/dist/src/decorators.js
import { compilerAssert as compilerAssert2, createDiagnosticCollector as createDiagnosticCollector2, getNamespaceFullName as getNamespaceFullName2, getTypeName as getTypeName3, ignoreDiagnostics as ignoreDiagnostics4, isKey, isNeverType as isNeverType2, isTemplateDeclarationOrInstance as isTemplateDeclarationOrInstance2, isVoidType, setTypeSpecNamespace, typespecTypeToJson, walkPropertiesInherited } from "@typespec/compiler";
import { $ as $3 } from "@typespec/compiler/typekit";
import { getHttpOperation as getHttpOperation5, getRoutePath } from "@typespec/http";
import { getResourceTypeKey, getSegment, isAutoRoute } from "@typespec/rest";

// src/typespec/packages/typespec-azure-core/dist/src/lro-helpers.js
import { getEffectiveModelType, ignoreDiagnostics as ignoreDiagnostics2, isNeverType } from "@typespec/compiler";
import { $ } from "@typespec/compiler/typekit";
import { getHeaderFieldName, getHttpOperation as getHttpOperation3, getOperationVerb, isBody, isBodyRoot, isHeader } from "@typespec/http";
import { getActionDetails, getResourceLocationType, getResourceOperation } from "@typespec/rest";
var FinalStateValue;
(function(FinalStateValue2) {
  FinalStateValue2["azureAsyncOperation"] = "azure-async-operation";
  FinalStateValue2["location"] = "location";
  FinalStateValue2["operationLocation"] = "operation-location";
  FinalStateValue2["originalUri"] = "original-uri";
  FinalStateValue2["customLink"] = "custom-link";
  FinalStateValue2["customOperationReference"] = "custom-operation-reference";
})(FinalStateValue || (FinalStateValue = {}));
function getLroMetadata(program, operation) {
  const context = ensureContext(program, operation, void 0);
  if (context === void 0)
    return void 0;
  processFinalReference(program, operation, context);
  processFinalLink(program, operation, context);
  const nextReference = processStatusMonitorReference(program, operation, context);
  if (nextReference !== void 0 && nextReference.responseModel.kind === "Model") {
    context.statusMonitorStep = nextReference;
    const linkedOperation = nextReference.kind === "nextOperationLink" ? nextReference.operation : nextReference.target.operation;
    processFinalReference(program, linkedOperation, context);
    processFinalLink(program, linkedOperation, context);
    context.pollingStep = getPollingStep(program, nextReference.responseModel, context);
    return createLroMetadata(program, operation, context);
  }
  if (processStatusMonitorLink(program, operation, context)) {
    return createLroMetadata(program, operation, context);
  }
  return void 0;
}
function createFinalOperationLink(program, model, property) {
  let resourceType;
  if (property.type.kind === "Scalar" && property.type.name === "ResourceLocation") {
    resourceType = property.type.templateMapper?.args[0];
  }
  const override = getFinalLocationValue(program, property);
  return {
    kind: "finalOperationLink",
    responseModel: override ?? resourceType ?? model,
    target: {
      kind: "link",
      location: isHeader(program, property) ? "ResponseHeader" : "ResponseBody",
      property
    }
  };
}
function createLroMetadata(program, operation, context) {
  const [finalState, model] = getFinalStateVia(program, operation, context);
  if (finalState === void 0 || model === void 0 || context.pollingStep === void 0)
    return void 0;
  const logicalPathName = context.finalStep?.kind === "pollingSuccessProperty" ? context.finalStep.target.name : void 0;
  let finalResult = model.kind === "Model" ? model : "void";
  let finalEnvelopeResult = model.kind === "Model" ? model : "void";
  if (context.finalStep && context.finalStep.kind === "pollingSuccessProperty") {
    finalEnvelopeResult = context.pollingStep.responseModel;
  } else if (context.finalStep && context.finalStep.kind === "noPollingResult") {
    finalResult = "void";
    finalEnvelopeResult = "void";
  }
  return {
    operation,
    logicalResult: model.kind === "Intrinsic" ? context.pollingStep.responseModel : model,
    finalStateVia: finalState,
    statusMonitorStep: context.statusMonitorStep,
    pollingInfo: context.pollingStep,
    finalStep: context.finalStep,
    envelopeResult: context.pollingStep.responseModel,
    logicalPath: logicalPathName,
    finalResult,
    finalEnvelopeResult,
    finalResultPath: logicalPathName
  };
}
function createOperationLink(program, modelProperty) {
  let location = "ResponseBody";
  if (isHeader(program, modelProperty))
    location = "ResponseHeader";
  if (isBody(program, modelProperty) || isBodyRoot(program, modelProperty))
    location = "Self";
  return {
    kind: "link",
    location,
    property: modelProperty
  };
}
function createOperationReferenceOrLink(metadata) {
  if (!metadata.parameterMap && !metadata.link)
    return void 0;
  const map = /* @__PURE__ */ new Map();
  if (metadata.parameterMap) {
    for (const [name, parameters] of metadata.parameterMap) {
      switch (parameters.sourceKind) {
        case "RequestBody":
          map.set(name, { location: "RequestBody", parameter: parameters.source.name });
          break;
        case "RequestParameter":
          map.set(name, { location: "OperationParameters", parameter: parameters.source.name });
          break;
        case "ResponseBody":
          map.set(name, { location: "Response", parameter: parameters.source.name });
          break;
      }
    }
    return {
      kind: "reference",
      operation: metadata.linkedOperation,
      parameterMap: map,
      parameters: metadata.parameterMap
    };
  }
  if (metadata.link) {
    return {
      kind: "link",
      location: metadata.link.location,
      property: metadata.link.property
    };
  }
  return void 0;
}
function createPollingStep(pollingData) {
  return {
    kind: "pollingOperationStep",
    responseModel: pollingData.monitorType,
    resultProperty: pollingData.successProperty,
    errorProperty: pollingData.errorProperty,
    terminationStatus: {
      kind: "model-property",
      canceledState: pollingData.lroStates.canceledState,
      failedState: pollingData.lroStates.failedState,
      succeededState: pollingData.lroStates.succeededState,
      property: pollingData.statusProperty
    }
  };
}
function ensureContext(program, operation, context) {
  if (context)
    return context;
  const [httpOperation, diagnostics] = getHttpOperation3(program, operation);
  if (diagnostics !== void 0 && diagnostics.length > 0) {
    program.reportDiagnostics(diagnostics);
  }
  const candidate = getSuccessResponse(program, httpOperation);
  if (candidate === void 0)
    return void 0;
  return {
    visitedModels: /* @__PURE__ */ new Set(),
    visitedOperations: /* @__PURE__ */ new Set(),
    httpOperation,
    originalModel: candidate
  };
}
function getBodyType(program, model) {
  const bodyProps = filterModelProperties(model, (p) => isBody(program, p) || isBodyRoot(program, p));
  if (bodyProps.length === 1 && bodyProps[0].type.kind === "Model")
    return bodyProps[0].type;
  return void 0;
}
function getLogicalResourceOperation(program, operation, model) {
  const resOp = getResourceOperation(program, operation);
  if (resOp !== void 0)
    return resOp;
  if (model === void 0)
    return void 0;
  const bodyModel = getBodyType(program, model);
  if (bodyModel !== void 0)
    model = bodyModel;
  model = getEffectiveModelType(program, model);
  let resultOp;
  const verb = getOperationVerb(program, operation);
  switch (verb) {
    case "delete":
      resultOp = "delete";
      break;
    default:
      return void 0;
  }
  return { operation: resultOp, resourceType: model };
}
function getFinalStateVia(program, operation, context) {
  const operationAction = getActionDetails(program, operation);
  let model = context.originalModel?.name !== void 0 ? context.originalModel : void 0;
  let finalState = FinalStateValue.originalUri;
  const finalStateOverride = getFinalStateOverride(program, operation);
  const resOp = getLogicalResourceOperation(program, operation, model);
  if (operationAction !== void 0 || resOp?.operation === "delete") {
    finalState = FinalStateValue.operationLocation;
    model = context.pollingStep?.responseModel ?? context.originalModel;
  }
  if (context.finalStep && context.finalStep.kind !== "noPollingResult" && (context.finalStep.kind !== "pollingSuccessProperty" || resOp?.operation === void 0 || resOp.operation !== "createOrReplace")) {
    model = context.finalStep.responseModel;
    if (context.finalStep.kind === "pollingSuccessProperty" && context.statusMonitorStep !== void 0) {
      switch (context.statusMonitorStep.kind) {
        case "nextOperationLink":
          finalState = getLroStatusFromHeaderProperty(program, context.statusMonitorStep.target.property);
          break;
        case "nextOperationReference":
          finalState = FinalStateValue.customOperationReference;
          if (context.statusMonitorStep.target.link?.location === "ResponseHeader") {
            finalState = getLroStatusFromHeaderProperty(program, context.statusMonitorStep.target.link.property);
          }
      }
    } else {
      finalState = getStatusFromLinkOrReference(program, operation, context.finalStep.target);
    }
    return [finalStateOverride || finalState, model];
  }
  if (resOp !== void 0 && resOp.operation !== void 0 && resOp.operation === "createOrReplace" && resOp.resourceType !== void 0) {
    model = resOp.resourceType;
    return [finalStateOverride || FinalStateValue.originalUri, model];
  }
  if (operationAction !== void 0 && operationAction !== null && context.statusMonitorStep !== void 0 || resOp?.operation === "delete" && context.pollingStep !== void 0 && context.statusMonitorStep !== void 0 || operationAction === void 0 && resOp === void 0 && context.pollingStep !== void 0 && context.statusMonitorStep !== void 0) {
    const info = getStatusMonitorInfo(program, context.statusMonitorStep.responseModel);
    if (info !== void 0) {
      model = info.successType ?? $(program).intrinsic.void;
      finalState = getStatusFromLinkOrReference(program, operation, context.statusMonitorStep?.target);
      if (context.finalStep === void 0 && info.successProperty === void 0) {
        context.finalStep = { kind: "noPollingResult", responseModel: $(program).intrinsic.void };
      }
    }
  }
  return [finalStateOverride || finalState, model];
}
function getLroStatusFromHeaderProperty(program, property) {
  let finalState;
  if (property === void 0 || !isHeader(program, property))
    return FinalStateValue.customLink;
  const name = getHeaderFieldName(program, property);
  if (name === void 0)
    return FinalStateValue.customLink;
  switch (name.toLowerCase()) {
    case "operation-location":
      finalState = FinalStateValue.operationLocation;
      break;
    case "azure-asyncoperation":
    case "azureasyncoperation":
      finalState = FinalStateValue.azureAsyncOperation;
      break;
    case "location":
      finalState = FinalStateValue.location;
      break;
    default:
      finalState = FinalStateValue.customLink;
  }
  return finalState;
}
function getLroStatusProperty(program, model) {
  const properties = filterModelProperties(model, (prop) => ignoreDiagnostics2(extractLroStates(program, prop)) !== void 0);
  return properties.length > 0 ? properties[0] : void 0;
}
function getPollingStep(program, modelOrOperation, context) {
  function getModel(property) {
    return property?.type.kind === "Model" ? property.type : void 0;
  }
  let info;
  if (!context.pollingOperationLink) {
    context.pollingOperationLink = getOperationLink(program, context.httpOperation.operation, PollingOperationKey);
  }
  const statusMonitorOverride = context.pollingOperationLink?.result?.statusMonitor;
  if (statusMonitorOverride !== void 0 && statusMonitorOverride.monitorType !== void 0) {
    info = {
      lroStates: statusMonitorOverride.lroStates,
      monitorType: statusMonitorOverride.monitorType,
      statusProperty: statusMonitorOverride.statusProperty,
      errorProperty: statusMonitorOverride.errorProperty,
      errorType: getModel(statusMonitorOverride.errorProperty),
      successProperty: statusMonitorOverride.successProperty,
      successType: getModel(statusMonitorOverride.successProperty)
    };
    return createPollingStep(info);
  }
  switch (modelOrOperation.kind) {
    case "Operation":
      const httpOperation = getHttpMetadata(program, modelOrOperation);
      info = GetStatusMonitorInfoFromOperation(program, httpOperation);
      break;
    case "Model":
      info = getStatusMonitorInfo(program, modelOrOperation);
      break;
  }
  if (info === void 0)
    return void 0;
  return createPollingStep(info);
}
function getStatusFromLinkOrReference(program, sourceOperation, target) {
  let finalState = FinalStateValue.originalUri;
  switch (target.kind) {
    case "link":
      {
        switch (target.location) {
          case "ResponseBody":
            finalState = FinalStateValue.customLink;
            break;
          case "ResponseHeader":
            finalState = getLroStatusFromHeaderProperty(program, target.property);
            break;
        }
      }
      break;
    case "reference":
      {
        finalState = FinalStateValue.customOperationReference;
        if (isMatchingGetOperation(program, sourceOperation, target.operation)) {
          finalState = FinalStateValue.originalUri;
        } else if (target.link !== void 0 && target.link.location === "ResponseHeader") {
          finalState = getLroStatusFromHeaderProperty(program, target.link.property);
        }
      }
      break;
  }
  return finalState;
}
function getStatusMonitorInfo(program, modelOrLink, pollingOverride) {
  if (pollingOverride?.kind === pollingOptionsKind.StatusMonitor) {
    return {
      ...pollingOverride.info
    };
  }
  if (modelOrLink.kind === "link") {
    if (modelOrLink.property === void 0)
      return void 0;
    const statusMonitorType = resolveOperationLocation(program, modelOrLink.property);
    if (statusMonitorType === void 0 || statusMonitorType.kind === "Intrinsic")
      return void 0;
    modelOrLink = statusMonitorType;
  }
  const statusProperty = getLroStatusProperty(program, modelOrLink);
  if (statusProperty === void 0)
    return void 0;
  const successInfo = getTargetModelInformation(program, modelOrLink);
  const lroStates = ignoreDiagnostics2(extractLroStates(program, statusProperty));
  if (lroStates === void 0)
    return void 0;
  return {
    monitorType: modelOrLink,
    successType: successInfo !== void 0 ? successInfo[0] : void 0,
    successProperty: successInfo !== void 0 ? successInfo[1] : void 0,
    statusProperty,
    lroStates
  };
}
function GetStatusMonitorInfoFromOperation(program, operation) {
  if (operation.verb === "get" || operation.verb === "head")
    return void 0;
  const models = filterResponseModels(operation, (model) => filterModelProperties(model, (prop) => ignoreDiagnostics2(extractLroStates(program, prop)) !== void 0).length > 0);
  if (models === void 0 || models.length < 1)
    return void 0;
  return getStatusMonitorInfo(program, models[0]);
}
function getStatusMonitorLinks(program, operation) {
  const models = filterResponseModels(operation, (model) => filterModelProperties(model, (prop) => isPollingLocation(program, prop) || isFinalLocation(program, prop)).length > 0);
  if (models === void 0 || models.length < 1)
    return void 0;
  return getStatusMonitorLinksFromModel(program, models[0]);
}
function getStatusMonitorLinksFromModel(program, model) {
  let pollingData = void 0;
  let pollingLinks = filterModelProperties(model, (prop) => isPollingLocation(program, prop));
  if (pollingLinks === void 0)
    return void 0;
  if (pollingLinks.length > 1) {
    pollingLinks = pollingLinks.filter((p) => !isBody(program, p) && !isBodyRoot(program, p));
  }
  const pollingProperty = pollingLinks[0];
  pollingData = getPollingLocationInfo(program, pollingProperty);
  const pollingLink = createOperationLink(program, pollingProperty);
  const monitorInfo = getStatusMonitorInfo(program, pollingLink, pollingData);
  if (monitorInfo === void 0)
    return void 0;
  let finalLinks = filterModelProperties(model, (prop) => isFinalLocation(program, prop));
  if ((finalLinks === void 0 || finalLinks.length !== 1) && monitorInfo.monitorType) {
    finalLinks = filterModelProperties(monitorInfo.monitorType, (prop) => isFinalLocation(program, prop));
  }
  const finalLink = finalLinks === void 0 || finalLinks.length !== 1 ? void 0 : createOperationLink(program, finalLinks[0]);
  let finalTarget;
  if (finalLink !== void 0 && finalLink.property !== void 0) {
    finalTarget = resolveOperationLocation(program, finalLink.property);
  }
  return {
    model: monitorInfo.monitorType,
    statusMonitor: pollingLink,
    pollingData: monitorInfo,
    final: finalLink,
    finalModel: finalTarget
  };
}
function getTargetModelInformation(program, modelOrLink) {
  if (modelOrLink.kind === "Intrinsic")
    return void 0;
  if (modelOrLink.kind === "link") {
    if (modelOrLink.property === void 0)
      return void 0;
    const linkModel = resolveOperationLocation(program, modelOrLink.property);
    if (linkModel === void 0 || linkModel.kind === "Intrinsic")
      return void 0;
    modelOrLink = linkModel;
  }
  const finalLinkProps = filterModelProperties(modelOrLink, (prop) => isFinalLocation(program, prop));
  const resultProps = filterModelProperties(modelOrLink, (prop) => isResultProperty(program, prop));
  if (finalLinkProps.length === 1) {
    const result = resolveOperationLocation(program, finalLinkProps[0]);
    if (result !== void 0)
      return [result, finalLinkProps[0]];
  }
  if (resultProps.length === 1 && !isNeverType(resultProps[0].type) && resultProps[0].type.kind === "Model") {
    return [resultProps[0].type, resultProps[0]];
  }
  return void 0;
}
function isMatchingGetOperation(program, sourceOperation, targetOperation) {
  const sourceHttp = getHttpMetadata(program, sourceOperation);
  const targetHttp = getHttpMetadata(program, targetOperation);
  return sourceHttp.path === targetHttp.path && targetHttp.verb === "get";
}
function isResultProperty(program, property) {
  if (property.model !== void 0) {
    const [lroResult, _] = getLroResult(program, property.model);
    if (lroResult !== void 0) {
      return lroResult.name === property.name;
    }
  }
  return property.name === "result";
}
function processFinalLink(program, modelOrOperation, context) {
  const overrideModel = context.finalOperationLink?.result?.type;
  if (context.finalStep !== void 0)
    return;
  switch (modelOrOperation.kind) {
    case "Operation":
      {
        const result = getResultModelWithProperty(program, modelOrOperation, (prop) => isFinalLocation(program, prop));
        if (result === void 0)
          return;
        const [model, property] = result;
        context.finalStep = createFinalOperationLink(program, overrideModel ?? model, property);
      }
      break;
    case "Model":
      {
        const outProperties = filterModelProperties(modelOrOperation, (prop) => isFinalLocation(program, prop));
        if (outProperties === void 0 || outProperties.length !== 1)
          return;
        context.finalStep = createFinalOperationLink(program, overrideModel ?? modelOrOperation, outProperties[0]);
      }
      break;
  }
}
function processFinalReference(program, operation, context) {
  if (context.finalStep !== void 0)
    return;
  const link = getOperationLink(program, operation, "final");
  if (link === void 0 || link.result?.type === void 0 || link.link === void 0 && link.parameterMap === void 0)
    return;
  context.finalOperationLink = link;
  const reference = createOperationReferenceOrLink(link);
  if (reference === void 0)
    return;
  switch (reference.kind) {
    case "reference":
      context.finalStep = {
        kind: "finalOperationReference",
        responseModel: link.result?.type,
        target: reference
      };
      break;
    case "link":
      context.finalStep = {
        kind: "finalOperationLink",
        responseModel: link.result?.type,
        target: reference
      };
      break;
  }
}
function createStatusMonitorPollingData(data) {
  function getModel(property) {
    return property?.type.kind === "Model" ? property.type : void 0;
  }
  return {
    lroStates: data.lroStates,
    monitorType: data.monitorType,
    statusProperty: data.statusProperty,
    errorProperty: data.errorProperty,
    errorType: getModel(data.errorProperty),
    successProperty: data.successProperty,
    successType: getModel(data.successProperty)
  };
}
function processStatusMonitorLink(program, modelOrOperation, context) {
  let lroData;
  if (context.pollingOperationLink?.result?.statusMonitor && context.pollingOperationLink?.link) {
    const polling = createStatusMonitorPollingData(context.pollingOperationLink.result.statusMonitor);
    lroData = {
      model: context.pollingOperationLink.result.statusMonitor.monitorType,
      pollingData: polling,
      statusMonitor: context.pollingOperationLink.link
    };
  } else {
    switch (modelOrOperation.kind) {
      case "Operation":
        lroData = getStatusMonitorLinks(program, context.httpOperation);
        break;
      case "Model":
        lroData = getStatusMonitorLinksFromModel(program, modelOrOperation);
        break;
    }
  }
  if (lroData === void 0 || lroData.statusMonitor === void 0) {
    return false;
  }
  context.pollingStep = createPollingStep(lroData.pollingData);
  if (context.finalStep === void 0) {
    if (lroData.final !== void 0 && lroData.finalModel !== void 0) {
      context.finalStep = {
        kind: "finalOperationLink",
        responseModel: lroData.finalModel,
        target: lroData.final
      };
    } else if (lroData.pollingData.successProperty !== void 0 && lroData.pollingData.successType !== void 0 && lroData.pollingData.successType.kind !== "Intrinsic") {
      const final = {
        kind: "pollingSuccessProperty",
        target: lroData.pollingData.successProperty,
        responseModel: lroData.pollingData.successType,
        sourceProperty: lroData.statusMonitor.property
      };
      context.finalStep = final;
    }
  }
  context.statusMonitorStep = {
    kind: "nextOperationLink",
    responseModel: lroData.model,
    target: lroData.statusMonitor
  };
  return true;
}
function processStatusMonitorReference(program, referencedOperation, context) {
  const references = getOperationLinks(program, referencedOperation);
  if (references === void 0)
    return void 0;
  const pollingData = references.get(PollingOperationKey);
  if (pollingData === void 0)
    return void 0;
  context.pollingOperationLink = pollingData;
  const pollingReference = createOperationReferenceOrLink(pollingData);
  if (pollingReference === void 0)
    return void 0;
  context.statusMonitorInfo = pollingData.result?.statusMonitor;
  const finalData = references.get(FinalOperationKey);
  if (context.finalStep === void 0 && finalData !== void 0) {
    const finalReference = createOperationReferenceOrLink(finalData);
    const finalModel = finalData?.result?.type;
    if (finalReference !== void 0 && finalModel !== void 0) {
      switch (finalReference.kind) {
        case "reference":
          context.finalStep = {
            kind: "finalOperationReference",
            responseModel: finalModel,
            target: finalReference
          };
          break;
        case "link":
          context.finalStep = {
            kind: "finalOperationLink",
            responseModel: finalModel,
            target: finalReference
          };
      }
    }
  }
  if (context.finalStep === void 0 && pollingData.result?.statusMonitor?.successProperty !== void 0 && pollingData.result.statusMonitor.successProperty.type.kind === "Model") {
    context.finalStep = {
      kind: "pollingSuccessProperty",
      target: pollingData.result.statusMonitor.successProperty,
      responseModel: pollingData.result.statusMonitor.successProperty.type,
      sourceProperty: pollingData.result.statusMonitor.successProperty
    };
  }
  const responseModel = pollingData.result?.type;
  if (responseModel === void 0)
    return void 0;
  switch (pollingReference.kind) {
    case "reference":
      return {
        kind: "nextOperationReference",
        responseModel,
        target: pollingReference
      };
    case "link":
      return {
        kind: "nextOperationLink",
        responseModel,
        target: pollingReference,
        operation: pollingData.linkedOperation
      };
  }
}
function resolveOperationLocation(program, property) {
  const override = getFinalLocationValue(program, property);
  if (override)
    return override;
  const resolvedScalar = resolveToScalarType(program, property.type);
  if (resolvedScalar === void 0)
    return void 0;
  return getResourceLocationType(program, resolvedScalar);
}
function resolveToScalarType(program, type) {
  switch (type.kind) {
    case "Scalar":
      return type;
  }
  return void 0;
}

// src/typespec/packages/typespec-azure-core/dist/src/lro-info.js
import { compilerAssert, createDiagnosticCollector, getEffectiveModelType as getEffectiveModelType2, ignoreDiagnostics as ignoreDiagnostics3, isErrorType, isType } from "@typespec/compiler";
import { $ as $2 } from "@typespec/compiler/typekit";
import { getHeaderFieldName as getHeaderFieldName2, getHttpOperation as getHttpOperation4, getResponsesForOperation, isBody as isBody2, isBodyRoot as isBodyRoot2, isHeader as isHeader2, isMetadata } from "@typespec/http";
function extractStatusMonitorInfo(program, model, statusProperty) {
  const diagnosticsToToss = createDiagnosticCollector();
  const diagnosticsToKeep = createDiagnosticCollector();
  const lroResult = diagnosticsToKeep.pipe(getLroResult(program, model, true));
  const successProperty = lroResult?.kind === "ModelProperty" ? lroResult : void 0;
  const errorProperty = diagnosticsToKeep.pipe(getLroErrorResult(program, model, true));
  const states = getLongRunningStates(program, statusProperty) ?? diagnosticsToToss.pipe(extractLroStates(program, statusProperty));
  if (!states || !statusProperty)
    return diagnosticsToKeep.wrap(void 0);
  return diagnosticsToKeep.wrap({
    monitorType: getEffectiveModelType2(program, model, (p) => !isMetadata(program, p)) ?? model,
    successProperty,
    errorProperty,
    statusProperty,
    lroStates: states,
    errorType: errorProperty?.type.kind === "Model" ? errorProperty.type : void 0,
    successType: successProperty?.type?.kind === "Intrinsic" || successProperty?.type?.kind === "Model" ? successProperty.type : $2(program).intrinsic.void,
    terminationInfo: {
      kind: "model-property",
      property: statusProperty,
      canceledState: states.canceledState,
      failedState: states.failedState,
      succeededState: states.succeededState
    }
  });
}
function getBodyModel(program, model) {
  const bodyProps = [...getAllProperties(model).values()].filter((p) => isBody2(program, p) || isBodyRoot2(program, p));
  if (bodyProps.length !== 1)
    return void 0;
  const outType = bodyProps[0].type;
  if (outType.kind !== "Model")
    return void 0;
  return outType;
}
function getLroOperationInfo(program, sourceOperation, targetOperation, parameters) {
  const diagnostics = createDiagnosticCollector();
  const targetResponses = diagnostics.pipe(getResponsesForOperation(program, targetOperation));
  const targetParameters = ignoreDiagnostics3(getHttpOperation4(program, targetOperation)).parameters;
  const targetProperties = /* @__PURE__ */ new Map();
  const parameterMap = /* @__PURE__ */ new Map();
  const unmatchedParameters = new Set(targetParameters.parameters.flatMap((p) => p.name));
  for (const parameter of targetParameters.parameters) {
    targetProperties.set(parameter.name, parameter.param);
  }
  if (targetParameters.body) {
    const body = targetParameters.body;
    if (body.bodyKind === "single" && body.property) {
      targetProperties.set(body.property.name, body.property);
    } else if (body.type.kind === "Model") {
      for (const [name, param] of getAllProperties(body.type)) {
        targetProperties.set(name, param);
      }
    }
  }
  const sourceResponses = diagnostics.pipe(getResponsesForOperation(program, sourceOperation));
  const sourceParameters = ignoreDiagnostics3(getHttpOperation4(program, sourceOperation)).parameters;
  const sourceBodyProperties = /* @__PURE__ */ new Map();
  if (sourceParameters.body && sourceParameters.body.type.kind === "Model") {
    for (const [sourceName, sourceProp] of getAllProperties(sourceParameters.body.type)) {
      sourceBodyProperties.set(sourceName, sourceProp);
      handleExplicitParameterMap(sourceProp, "RequestBody");
    }
  }
  const sourceParamProperties = /* @__PURE__ */ new Map();
  for (const parameter of sourceParameters.parameters) {
    sourceParamProperties.set(parameter.name, parameter.param);
    handleExplicitParameterMap(parameter.param, "RequestParameter");
  }
  const sourceResponseProperties = /* @__PURE__ */ new Map();
  let pollingLink = void 0;
  let resultModel;
  for (const response of targetResponses) {
    visitResponse(program, response, (model) => {
      if (!isErrorType(model) && resultModel === void 0) {
        if (resultModel === void 0) {
          resultModel = getBodyModel(program, model);
          if (resultModel === void 0) {
            resultModel = getEffectiveModelType2(program, model, (p) => !isMetadata(program, p));
          }
        }
      }
    });
  }
  let statusMonitor = void 0;
  for (const response of sourceResponses) {
    visitResponse(program, response, void 0, (name, prop) => {
      sourceResponseProperties.set(name, prop);
      handleExplicitParameterMap(prop, "ResponseBody");
      const link = extractPollinglink(prop);
      if (link && !pollingLink) {
        pollingLink = link;
      }
    });
  }
  gatherLroParameters();
  diagnostics.pipe(getStatusMonitorInfo2());
  function gatherLroParameters() {
    if (unmatchedParameters.size > 0) {
      for (const [targetName, targetProperty] of targetProperties) {
        getLroParameterFromProperty(targetName, targetProperty, sourceParamProperties, "RequestParameter");
        sourceBodyProperties.size > 0 && getLroParameterFromProperty(targetName, targetProperty, sourceBodyProperties, "RequestBody");
        sourceResponseProperties.size > 0 && getLroParameterFromProperty(targetName, targetProperty, sourceResponseProperties, "ResponseBody");
      }
    }
    if (parameters === void 0)
      return;
    for (const [_, parameter] of getAllProperties(parameters)) {
      processModelPropertyFromParameterMap(parameter);
    }
  }
  function getStatusMonitorInfo2() {
    let result = void 0;
    const diagnostics2 = createDiagnosticCollector();
    for (const response of targetResponses) {
      visitResponse(program, response, (m) => {
        const status = getLroStatusProperty2(program, m);
        if (status !== void 0) {
          result = diagnostics2.pipe(extractStatusMonitorInfo(program, m, status));
        }
      });
      if (result) {
        break;
      }
    }
    statusMonitor = result;
    return diagnostics2.wrap(result);
  }
  function handleExplicitParameterMap(source, kind) {
    const directMapping = getPollingOperationParameter(program, source);
    if (directMapping === void 0)
      return;
    let targetName = directMapping;
    let targetProperty = directMapping;
    if (targetName.length > 0 && targetProperties.has(targetName)) {
      targetProperty = targetProperties.get(targetName);
    }
    targetName = targetProperty.name;
    parameterMap.set(targetName, { source, target: targetProperty, sourceKind: kind });
    unmatchedParameters.delete(targetName);
  }
  function getLroParameterFromProperty(targetName, targetProperty, sourceProperties, sourceKind) {
    const sourceProperty = sourceProperties.get(targetName);
    if (sourceProperty !== void 0) {
      parameterMap.set(targetName, {
        sourceKind,
        source: sourceProperty,
        target: targetProperty
      });
      unmatchedParameters.delete(targetName);
    }
  }
  function visitResponse(program2, response, modelAction, modelPropertyAction) {
    function visitModel(model) {
      modelAction && modelAction(model);
      if (modelPropertyAction) {
        for (const [name, prop] of getAllProperties(model)) {
          modelPropertyAction(name, prop);
        }
      }
    }
    function visitUnion(union) {
      for (const [_, prop] of union.variants) {
        visitVariant(prop);
      }
    }
    function visitVariant(variant) {
      switch (variant.type.kind) {
        case "Model":
          visitModel(variant.type);
          break;
        case "Union":
          visitUnion(variant.type);
          break;
        default:
          break;
      }
    }
    if (isErrorType(response.type))
      return;
    switch (response.type.kind) {
      case "Model":
        visitModel(response.type);
        break;
      case "Union":
        visitUnion(response.type);
        break;
      default:
    }
  }
  function processModelPropertyFromParameterMap(property) {
    if (property.type.kind !== "Model") {
      diagnostics.add(createDiagnostic({
        code: "operation-link-parameter-invalid",
        target: sourceOperation,
        format: {}
      }));
      return;
    }
    const propMap = property.type;
    const typeName = propMap.name;
    const namespace2 = propMap.namespace?.name;
    if (namespace2 !== "Core" || typeName !== "RequestParameter" && typeName !== "ResponseProperty") {
      diagnostics.add(createDiagnostic({
        code: "operation-link-parameter-invalid",
        target: sourceOperation,
        format: {}
      }));
      return;
    }
    const targetProperty = targetProperties.get(property.name);
    if (targetProperty === void 0) {
      diagnostics.add(createDiagnostic({
        code: "operation-link-parameter-invalid-target",
        target: targetOperation,
        format: { name: property.name }
      }));
      return;
    }
    let sourceProperty = propMap.templateMapper.args[0];
    if (sourceProperty.entityKind === "Indeterminate") {
      sourceProperty = sourceProperty.type;
    } else if (!isType(sourceProperty)) {
      compilerAssert(false, "Lro Template Arg should be a Type", propMap);
    }
    switch (sourceProperty.kind) {
      case "String":
        const sourcePropertyName = sourceProperty.value;
        if (typeName === "RequestParameter") {
          let sourceParam = sourceParamProperties.get(sourcePropertyName);
          if (sourceParam !== void 0) {
            unmatchedParameters.delete(property.name);
            parameterMap.set(property.name, {
              sourceKind: "RequestParameter",
              source: sourceParam,
              target: targetProperty
            });
            return;
          }
          sourceParam = sourceBodyProperties.get(sourcePropertyName);
          if (sourceParam !== void 0) {
            unmatchedParameters.delete(property.name);
            parameterMap.set(property.name, {
              sourceKind: "RequestBody",
              source: sourceParam,
              target: targetProperty
            });
            return;
          }
          diagnostics.add(createDiagnostic({
            code: "request-parameter-invalid",
            target: sourceOperation,
            format: { name: sourcePropertyName }
          }));
          return;
        } else if (typeName === "ResponseProperty") {
          const sourceParam = sourceResponseProperties.get(sourcePropertyName);
          if (sourceParam === void 0) {
            diagnostics.add(createDiagnostic({
              code: "response-property-invalid",
              target: sourceOperation,
              format: { name: sourcePropertyName }
            }));
            return;
          }
          unmatchedParameters.delete(property.name);
          parameterMap.set(property.name, {
            source: sourceParam,
            target: targetProperty,
            sourceKind: "ResponseBody"
          });
        }
    }
  }
  function extractPollinglink(property) {
    let isKnownLinkHeader = false;
    if (isHeader2(program, property)) {
      const headerName = getHeaderFieldName2(program, property).toLowerCase();
      isKnownLinkHeader = headerName === "operation-location";
    }
    if (isPollingLocation(program, property) || isKnownLinkHeader) {
      return {
        kind: "link",
        property,
        location: isHeader2(program, property) ? "ResponseHeader" : "ResponseBody"
      };
    }
    return void 0;
  }
  function ValidateInfo() {
    return resultModel !== void 0;
  }
  function getInvocationInfo() {
    return {
      operation: targetOperation,
      parameterMap: unmatchedParameters.size < 1 ? parameterMap : void 0
    };
  }
  function getOperationLink2() {
    return pollingLink;
  }
  function getResultInfo() {
    return {
      type: resultModel,
      statusMonitor
    };
  }
  return diagnostics.wrap(ValidateInfo() ? { getInvocationInfo, getOperationLink: getOperationLink2, getResultInfo } : void 0);
}

// src/typespec/packages/typespec-azure-core/dist/src/decorators.js
var PollingOperationKey = "polling";
var FinalOperationKey = "final";
var $fixed = (context, target) => {
  context.program.stateMap(AzureCoreStateKeys.fixed).set(target, true);
};
function isFixed(program, target) {
  return program.stateMap(AzureCoreStateKeys.fixed).get(target) !== void 0;
}
var $pagedResult = (context, entity) => {
  context.program.stateMap(AzureCoreStateKeys.pagedResult).set(entity, true);
};
function findPathToProperty(program, entity, condition, current = []) {
  for (const prop of entity.properties.values()) {
    const match = condition(prop);
    if (match) {
      const segments = [...current, prop.name];
      return {
        property: prop,
        path: segments.join("."),
        segments
      };
    } else {
      if (prop.type.kind === "Model") {
        const items = findPathToProperty(program, prop.type, condition, [...current, prop.name]);
        if (items !== void 0) {
          return items;
        }
      }
    }
  }
  return void 0;
}
function _getItems(program, entity) {
  return findPathToProperty(program, entity, (prop) => getItems(program, prop) !== void 0);
}
function _getNextLink(program, entity) {
  return findPathToProperty(program, entity, (prop) => getNextLink(program, prop) === true);
}
function getNamedSourceModels(property) {
  if (!property.sourceProperty) {
    return void 0;
  }
  const set = /* @__PURE__ */ new Set();
  for (let p = property; p; p = p.sourceProperty) {
    if (p.model?.name) {
      set.add(p.model);
    }
  }
  return set;
}
function getPagedResult(program, entity) {
  let metadata = void 0;
  switch (entity.kind) {
    case "Model":
      if (program.stateMap(AzureCoreStateKeys.pagedResult).get(entity)) {
        metadata = { modelType: entity };
        const items = _getItems(program, entity);
        if (items !== void 0) {
          metadata.itemsProperty = items.property;
          metadata.itemsPath = items.path;
          metadata.itemsSegments = items.segments;
        }
        const nextLink = _getNextLink(program, entity);
        if (nextLink !== void 0) {
          metadata.nextLinkProperty = nextLink.property;
          metadata.nextLinkPath = nextLink.path;
          metadata.nextLinkSegments = nextLink.segments;
        }
        return metadata;
      } else if (entity.templateMapper) {
        for (const arg of entity.templateMapper.args) {
          metadata = getPagedResult(program, arg);
          if (metadata !== void 0) {
            break;
          }
        }
        break;
      } else if (entity.name === "") {
        for (const property of entity.properties.values()) {
          const sources = getNamedSourceModels(property);
          if (sources) {
            for (const source of sources) {
              const sourceMetadata = getPagedResult(program, source);
              if (sourceMetadata) {
                return sourceMetadata;
              }
            }
          }
        }
      }
      if (entity.baseModel) {
        const parentMetadata = getPagedResult(program, entity.baseModel);
        if (parentMetadata) {
          parentMetadata.modelType = entity;
          return parentMetadata;
        }
      }
      break;
    case "Operation":
      switch (entity.returnType.kind) {
        case "Union":
          for (const variant of entity.returnType.variants.values()) {
            metadata = getPagedResult(program, variant.type);
            if (metadata !== void 0) {
              break;
            }
          }
          break;
        case "Model":
          metadata = getPagedResult(program, entity.returnType);
          break;
      }
      if (metadata !== void 0) {
        const nextLinkOperation = getOperationLink(program, entity, "nextPage");
        if (nextLinkOperation !== void 0) {
          metadata.nextLinkOperation = nextLinkOperation.linkedOperation;
        }
      }
  }
  return metadata;
}
var $items = (context, entity) => {
  context.program.stateMap(AzureCoreStateKeys.items).set(entity, true);
};
function getItems(program, entity) {
  return program.stateMap(AzureCoreStateKeys.items).get(entity);
}
function getNextLink(program, entity) {
  return program.stateSet(Symbol.for(`TypeSpec.nextLink`)).has(entity);
}
var $lroStatus = (context, entity) => {
  const [states, diagnostics] = extractLroStates(context.program, entity);
  if (diagnostics.length > 0)
    context.program.reportDiagnostics(diagnostics);
  context.program.stateMap(AzureCoreStateKeys.lroStatus).set(entity, states);
};
function storeLroState(program, states, name, member) {
  const expectedStates = [
    ["Succeeded", isLroSucceededState, () => states.succeededState.push(name)],
    ["Failed", isLroFailedState, () => states.failedState.push(name)],
    ["Canceled", isLroCanceledState, () => states.canceledState.push(name)]
  ];
  states.states.push(name);
  for (const [knownState, stateTest, setter] of expectedStates) {
    if (name === knownState || member && stateTest(program, member)) {
      setter();
      break;
    }
  }
}
function extractLroStatesFromUnion(program, entity, lroStateResult, diagnostics) {
  if (entity.kind === "Union") {
    for (const variant of entity.variants.values()) {
      const option = variant.type;
      if (option.kind === "Enum") {
        for (const member of option.members.values()) {
          storeLroState(program, lroStateResult, member.name, member);
        }
      } else if (option.kind === "Union") {
        extractLroStatesFromUnion(program, option, lroStateResult, diagnostics);
      } else if (option.kind === "Scalar" && option.name === "string") {
        continue;
      } else if (option.kind !== "String") {
        diagnostics.add(createDiagnostic({
          code: "lro-status-union-non-string",
          target: option,
          format: {
            type: option.kind
          }
        }));
        return diagnostics.wrap(void 0);
      } else {
        storeLroState(program, lroStateResult, typeof variant.name === "string" ? variant.name : option.value, variant);
      }
    }
  }
  return;
}
function extractLroStates(program, entity) {
  const result = {
    states: [],
    succeededState: [],
    failedState: [],
    canceledState: []
  };
  const diagnostics = createDiagnosticCollector2();
  if (entity.kind === "ModelProperty") {
    return extractLroStates(program, entity.type);
  } else if (entity.kind === "Enum") {
    for (const member of entity.members.values()) {
      storeLroState(program, result, member.name, member);
    }
  } else if (entity.kind === "Union") {
    extractLroStatesFromUnion(program, entity, result, diagnostics);
  } else {
    diagnostics.add(createDiagnostic({
      code: "lro-status-property-invalid-type",
      target: entity,
      format: {
        type: entity.kind
      }
    }));
    return diagnostics.wrap(void 0);
  }
  const missingStates = [];
  if (result.succeededState.length < 1) {
    missingStates.push("Succeeded");
  }
  if (result.failedState.length < 1) {
    missingStates.push("Failed");
  }
  if (missingStates.length > 0) {
    diagnostics.add(createDiagnostic({
      code: "lro-status-missing",
      target: entity,
      format: {
        states: missingStates.join(", ")
      }
    }));
    return diagnostics.wrap(void 0);
  }
  return diagnostics.wrap(result);
}
function getLongRunningStates(program, entity) {
  return program.stateMap(AzureCoreStateKeys.lroStatus).get(entity);
}
function getLroStatusProperty2(program, target) {
  function getProvisioningState(props2) {
    let innerProps = void 0;
    let result = void 0;
    const innerProperty = props2.get("properties");
    result = props2.get("provisioningState");
    if (result === void 0 && innerProperty !== void 0 && innerProperty.type?.kind === "Model") {
      innerProps = getAllProperties(innerProperty.type);
      result = innerProps.get("provisioningState");
    }
    return result;
  }
  const props = getAllProperties(target);
  for (const [_, prop] of props.entries()) {
    let values = program.stateMap(AzureCoreStateKeys.lroStatus).get(prop);
    if (values !== void 0)
      return prop;
    if (prop.type.kind === "Enum" || prop.type.kind === "Union") {
      values = program.stateMap(AzureCoreStateKeys.lroStatus).get(prop.type);
      if (values !== void 0)
        return prop;
    }
  }
  const statusProp = props.get("status") ?? getProvisioningState(props);
  if (statusProp) {
    const [states, _] = extractLroStates(program, statusProp);
    if (states !== void 0)
      return statusProp;
  }
  return void 0;
}
var $lroResult = (context, entity) => {
  context.program.stateMap(AzureCoreStateKeys.lroResult).set(entity, entity);
};
function getLroResult(program, entity, useDefault = true) {
  const diagnostics = createDiagnosticCollector2();
  let count = 0;
  let resultProperty = void 0;
  let defaultProperty = void 0;
  for (const prop of walkPropertiesInherited(entity)) {
    const candidateProperty = program.stateMap(AzureCoreStateKeys.lroResult).get(prop);
    if (candidateProperty !== void 0) {
      resultProperty = candidateProperty;
      count++;
    }
    if (prop.name.toLowerCase() === "result")
      defaultProperty = prop;
  }
  if (count > 1) {
    diagnostics.add(createDiagnostic({
      code: "lro-status-monitor-invalid-result-property",
      target: entity,
      format: { resultType: "result", decorator: "@lroResult" }
    }));
  }
  if (resultProperty === void 0 && useDefault)
    resultProperty = defaultProperty;
  if (resultProperty && isNeverType2(resultProperty.type))
    resultProperty = void 0;
  return diagnostics.wrap(resultProperty);
}
var $lroErrorResult = (context, entity) => {
  const { program } = context;
  program.stateMap(AzureCoreStateKeys.lroErrorResult).set(entity, entity);
};
function getLroErrorResult(program, entity, useDefault = true) {
  const diagnostics = createDiagnosticCollector2();
  let count = 0;
  let resultProperty = void 0;
  let defaultProperty = void 0;
  for (const prop of walkPropertiesInherited(entity)) {
    const candidateProperty = program.stateMap(AzureCoreStateKeys.lroErrorResult).get(prop);
    if (candidateProperty !== void 0) {
      resultProperty = candidateProperty;
      count++;
    }
    if (prop.name.toLowerCase() === "error")
      defaultProperty = prop;
  }
  if (count > 1) {
    diagnostics.add(createDiagnostic({
      code: "lro-status-monitor-invalid-result-property",
      target: entity,
      format: { resultType: "error", decorator: "@lroErrorResult" }
    }));
  }
  if (resultProperty === void 0 && useDefault)
    resultProperty = defaultProperty;
  return diagnostics.wrap(resultProperty);
}
var $pollingOperationParameter = (context, entity, target) => {
  const { program } = context;
  let storedValue;
  switch (target?.kind) {
    case "ModelProperty":
      storedValue = target;
      break;
    case "String":
      storedValue = target.value;
      break;
    default:
      storedValue = void 0;
  }
  program.stateMap(AzureCoreStateKeys.pollingOperationParameter).set(entity, storedValue ?? entity.name);
};
function getPollingOperationParameter(program, entity) {
  return program.stateMap(AzureCoreStateKeys.pollingOperationParameter).get(entity);
}
var $lroSucceeded = (context, entity) => {
  context.program.stateSet(AzureCoreStateKeys.lroSucceeded).add(entity);
};
function isLroSucceededState(program, entity) {
  return program.stateSet(AzureCoreStateKeys.lroSucceeded).has(entity);
}
var $lroCanceled = (context, entity) => {
  context.program.stateSet(AzureCoreStateKeys.lroCanceled).add(entity);
};
function isLroCanceledState(program, entity) {
  return program.stateSet(AzureCoreStateKeys.lroCanceled).has(entity);
}
var $lroFailed = (context, entity) => {
  context.program.stateSet(AzureCoreStateKeys.lroFailed).add(entity);
};
function isLroFailedState(program, entity) {
  return program.stateSet(AzureCoreStateKeys.lroFailed).has(entity);
}
var optionsKindKey = "kind";
var finalPropertyKey = "finalProperty";
var pollingModelKey = "pollingModel";
var finalResultKey = "finalResult";
var pollingOptionsKind;
(function(pollingOptionsKind2) {
  pollingOptionsKind2["StatusMonitor"] = "statusMonitor";
})(pollingOptionsKind || (pollingOptionsKind = {}));
var $pollingLocation = (context, entity, options) => {
  const { program } = context;
  if (options) {
    if (isNeverType2(options))
      return;
    const info = extractPollingLocationInfo(program, entity, options);
    if (info) {
      program.stateMap(AzureCoreStateKeys.pollingLocationInfo).set(entity, info);
    }
  }
  program.stateSet(AzureCoreStateKeys.pollingOperationParameter).add(entity);
};
function getPollingLocationInfo(program, target) {
  return program.stateMap(AzureCoreStateKeys.pollingLocationInfo).get(target);
}
function extractUnionVariantValue(type) {
  if (type.kind === "UnionVariant" && type.type.kind === "String")
    return type.type.value;
  return void 0;
}
function extractPollingLocationInfo(program, target, options) {
  if (options.kind !== "Model")
    return void 0;
  const kind = options.properties.get(optionsKindKey);
  if (kind === void 0)
    return void 0;
  const kindValue = extractUnionVariantValue(kind.type);
  if (kindValue === void 0)
    return void 0;
  const pollingInfo = { target };
  const pollingModel = options.properties.get(pollingModelKey)?.type;
  if (pollingModel && pollingModel.kind === "Model")
    pollingInfo.pollingModel = pollingModel;
  if (pollingModel && isVoidType(pollingModel))
    pollingInfo.pollingModel = $3(program).intrinsic.void;
  const finalResult = options.properties.get(finalResultKey)?.type;
  if (finalResult && finalResult.kind === "Model")
    pollingInfo.finalResult = finalResult;
  if (finalResult && isVoidType(finalResult))
    pollingInfo.finalResult = $3(program).intrinsic.void;
  switch (kindValue) {
    case pollingOptionsKind.StatusMonitor:
      return extractStatusMonitorLocationInfo(program, options, pollingInfo);
    default:
      return void 0;
  }
}
function extractStatusMonitorLocationInfo(program, options, baseInfo) {
  const kind = options.properties.get(optionsKindKey);
  if (kind === void 0 || extractUnionVariantValue(kind.type) !== "statusMonitor")
    return void 0;
  if (baseInfo.pollingModel === void 0 || baseInfo.pollingModel.kind === "Intrinsic")
    return void 0;
  const finalProperty = options.properties.get(finalPropertyKey)?.type;
  let finalPropertyValue = void 0;
  if (finalProperty && finalProperty.kind === "ModelProperty")
    finalPropertyValue = finalProperty;
  if (finalProperty && finalProperty.kind === "String" && baseInfo.pollingModel.properties.has(finalProperty.value)) {
    finalPropertyValue = baseInfo.pollingModel.properties.get(finalProperty.value);
  }
  if (finalPropertyValue === void 0)
    finalPropertyValue = ignoreDiagnostics4(getLroResult(program, baseInfo.pollingModel, true));
  const statusProperty = getLroStatusProperty2(program, baseInfo.pollingModel);
  if (statusProperty === void 0)
    return void 0;
  const statusMonitor = ignoreDiagnostics4(extractStatusMonitorInfo(program, baseInfo.pollingModel, statusProperty));
  if (statusMonitor === void 0)
    return void 0;
  statusMonitor.successProperty = finalPropertyValue;
  baseInfo.finalResult = finalPropertyValue?.type?.kind === "Model" ? finalPropertyValue.type : $3(program).intrinsic.void;
  return {
    kind: pollingOptionsKind.StatusMonitor,
    info: statusMonitor,
    ...baseInfo
  };
}
function isPollingLocation(program, entity) {
  return program.stateSet(AzureCoreStateKeys.pollingOperationParameter).has(entity);
}
var $finalLocation = (context, entity, finalResult) => {
  const { program } = context;
  if (finalResult !== void 0 && isNeverType2(finalResult))
    return;
  program.stateSet(AzureCoreStateKeys.finalLocations).add(entity);
  switch (finalResult?.kind) {
    case "Model":
      program.stateMap(AzureCoreStateKeys.finalLocationResults).set(entity, finalResult);
      break;
    case "Intrinsic":
      if (isVoidType(finalResult)) {
        program.stateMap(AzureCoreStateKeys.finalLocationResults).set(entity, finalResult);
      }
  }
};
function isFinalLocation(program, entity) {
  return program.stateSet(AzureCoreStateKeys.finalLocations).has(entity);
}
function getFinalLocationValue(program, entity) {
  return program.stateMap(AzureCoreStateKeys.finalLocationResults).get(entity);
}
var $useFinalStateVia = (context, entity, finalState) => {
  const { program } = context;
  let finalStateVia;
  switch (finalState?.toLowerCase()) {
    case "original-uri":
      finalStateVia = FinalStateValue.originalUri;
      break;
    case "operation-location":
      finalStateVia = FinalStateValue.operationLocation;
      break;
    case "location":
      finalStateVia = FinalStateValue.location;
      break;
    case "azure-async-operation":
      finalStateVia = FinalStateValue.azureAsyncOperation;
      break;
    default:
      reportDiagnostic(program, {
        code: "invalid-final-state",
        target: entity,
        messageId: "badValue",
        format: { finalStateValue: finalState }
      });
      return;
  }
  const operation = ignoreDiagnostics4(getHttpOperation5(program, entity));
  const storedValue = validateFinalState(program, operation, finalStateVia);
  if (storedValue !== void 0 || operation.verb === "put") {
    program.stateMap(AzureCoreStateKeys.finalStateOverride).set(entity, finalStateVia);
  }
  if (storedValue === void 0 && [
    FinalStateValue.operationLocation,
    FinalStateValue.location,
    FinalStateValue.azureAsyncOperation
  ].includes(finalStateVia)) {
    reportDiagnostic(program, {
      code: "invalid-final-state",
      target: entity,
      messageId: "noHeader",
      format: { finalStateValue: finalStateVia }
    });
  }
};
function getLroHeaderName(finalState) {
  switch (finalState) {
    case FinalStateValue.azureAsyncOperation:
      return "azure-asyncoperation";
    case FinalStateValue.location:
      return "location";
    case FinalStateValue.operationLocation:
      return "operation-location";
    default:
      return void 0;
  }
}
function getLroHeader(propertyName) {
  const name = propertyName.toLowerCase();
  switch (name) {
    case "azure-asyncoperation":
    case "location":
    case "operation-location":
      return name;
    default:
      return void 0;
  }
}
function getLroHeaders(response) {
  const result = /* @__PURE__ */ new Set();
  for (const content of response.responses) {
    if (content.headers) {
      for (const candidate of Object.keys(content.headers)) {
        const headerName = getLroHeader(candidate);
        if (headerName !== void 0) {
          result.add(headerName);
        }
      }
    }
  }
  return result;
}
function validateFinalState(program, operation, finalState) {
  if (finalState === FinalStateValue.originalUri) {
    if (operation.verb !== "put") {
      reportDiagnostic(program, {
        code: "invalid-final-state",
        target: operation.operation,
        messageId: "notPut"
      });
      return void 0;
    }
    return FinalStateValue.originalUri;
  }
  const header = getLroHeaderName(finalState);
  if (header === void 0) {
    reportDiagnostic(program, {
      code: "invalid-final-state",
      target: operation.operation,
      messageId: "badValue",
      format: { finalStateValue: finalState }
    });
    return void 0;
  }
  for (const response of operation.responses) {
    const lroHeaders = getLroHeaders(response);
    if (lroHeaders?.has(header)) {
      return finalState;
    }
  }
  return void 0;
}
function validateFinalStates(program, operation, finalStates) {
  const httpOp = ignoreDiagnostics4(getHttpOperation5(program, operation));
  for (const state of finalStates) {
    if (validateFinalState(program, httpOp, state))
      return state;
  }
  return void 0;
}
function getFinalStateOverride(program, operation) {
  return program.stateMap(AzureCoreStateKeys.finalStateOverride).get(operation);
}
var $omitKeyProperties = (context, entity) => {
  for (const [key, prop] of entity.properties) {
    if (isKey(context.program, prop)) {
      entity.properties.delete(key);
    }
  }
};
var $operationLink = (context, entity, linkedOperation, linkType, parameters) => {
  if (parameters && parameters.kind !== "Model") {
    return;
  }
  const { program } = context;
  const [operationInfo, diagnostics] = getLroOperationInfo(program, entity, linkedOperation, parameters);
  if (diagnostics.length > 0) {
    program.reportDiagnostics(diagnostics);
  }
  let items = context.program.stateMap(AzureCoreStateKeys.operationLink).get(entity);
  if (items === void 0) {
    items = /* @__PURE__ */ new Map();
  }
  items.set(linkType, {
    parameters,
    linkedOperation,
    linkType,
    link: operationInfo?.getOperationLink(),
    parameterMap: operationInfo?.getInvocationInfo()?.parameterMap,
    result: operationInfo?.getResultInfo()
  });
  context.program.stateMap(AzureCoreStateKeys.operationLink).set(entity, items);
};
function getOperationLink(program, entity, linkType) {
  const items = program.stateMap(AzureCoreStateKeys.operationLink).get(entity);
  if (items !== void 0) {
    return items.get(linkType);
  }
  return items;
}
function getOperationLinks(program, entity) {
  return program.stateMap(AzureCoreStateKeys.operationLink).get(entity);
}
var $pollingOperation = (context, target, linkedOperation, parameters) => {
  const { program } = context;
  const isValidReturnType = target.returnType.kind === "Model" || target.returnType.kind === "Union" && [...target.returnType.variants.values()].every((x) => x.type.kind === "Model");
  if (!isValidReturnType) {
    reportDiagnostic(context.program, {
      code: "polling-operation-return-model",
      target
    });
    return;
  }
  context.call($operationLink, target, linkedOperation, PollingOperationKey, parameters);
  const operationDetails = getOperationLink(program, target, PollingOperationKey);
  if (operationDetails === void 0 || operationDetails.result === void 0) {
    reportDiagnostic(context.program, {
      code: "polling-operation-return-model",
      target
    });
    return;
  }
  if (operationDetails.result.statusMonitor === void 0) {
    reportDiagnostic(context.program, {
      code: "polling-operation-no-status-monitor",
      target: linkedOperation
    });
    return;
  }
  if (operationDetails.result.statusMonitor.terminationInfo.succeededState.length < 1) {
    reportDiagnostic(context.program, {
      code: "polling-operation-no-lro-success",
      target: operationDetails.result.statusMonitor.monitorType
    });
  }
  if (operationDetails.result.statusMonitor.terminationInfo.failedState.length < 1) {
    reportDiagnostic(context.program, {
      code: "polling-operation-no-lro-failure",
      target: operationDetails.result.statusMonitor.monitorType
    });
  }
  if (operationDetails.parameterMap === void 0 && operationDetails.link === void 0) {
    reportDiagnostic(context.program, {
      code: "polling-operation-no-ref-or-link",
      target
    });
  }
};
var $finalOperation = (context, entity, linkedOperation, parameters) => {
  const { program } = context;
  context.call($operationLink, entity, linkedOperation, FinalOperationKey, parameters);
  const operationDetails = getOperationLink(program, entity, FinalOperationKey);
  if (operationDetails === void 0 || operationDetails.result === void 0) {
    reportDiagnostic(context.program, {
      code: "invalid-final-operation",
      target: entity
    });
  }
};
var $nextPageOperation = (context, entity, linkedOperation, parameters) => {
  context.call($operationLink, entity, linkedOperation, "nextPage", parameters);
};
var $requestParameter = (context, entity, name) => {
  context.program.stateMap(AzureCoreStateKeys.requestParameter).set(entity, name);
};
function getRequestParameter(program, entity) {
  if (entity.type.kind !== "Model")
    return void 0;
  const parameterName = program.stateMap(AzureCoreStateKeys.requestParameter).get(entity.type);
  return parameterName;
}
var $responseProperty = (context, entity, name) => {
  context.program.stateMap(AzureCoreStateKeys.responseParameter).set(entity, name);
};
function getResponseProperty(program, entity) {
  if (entity.type.kind !== "Model")
    return void 0;
  const parameterName = program.stateMap(AzureCoreStateKeys.responseParameter).get(entity.type);
  return parameterName;
}
var $spreadCustomParameters = (context, entity, customizations) => {
  const customParameters = customizations.properties.get("parameters")?.type;
  if (customParameters) {
    if (customParameters.kind !== "Model") {
      return;
    }
    for (const [key, value] of customParameters.properties) {
      entity.properties.set(key, context.program.checker.cloneType(value, {
        sourceProperty: value,
        model: entity
      }));
    }
  }
};
var $spreadCustomResponseProperties = (context, entity, customizations) => {
  const customResponseProperties = customizations.properties.get("response")?.type;
  if (customResponseProperties) {
    if (customResponseProperties.kind !== "Model") {
      return;
    }
    for (const [key, value] of customResponseProperties.properties) {
      entity.properties.set(key, context.program.checker.cloneType(value, {
        sourceProperty: value,
        model: entity
      }));
    }
  }
};
var $ensureResourceType = (context, entity, resourceType) => {
  if (resourceType.kind === "TemplateParameter") {
    return;
  }
  context.program.stateSet(AzureCoreStateKeys.resourceOperation).add(entity);
  if (resourceType.kind !== "Model") {
    context.program.reportDiagnostic({
      code: "invalid-argument",
      message: `This operation expects a Model for its TResource parameter.`,
      severity: "error",
      target: entity
    });
    return;
  }
  if (entity.namespace && getNamespaceFullName2(entity.namespace).startsWith("Azure.Core")) {
    return;
  }
  const key = getResourceTypeKey(context.program, resourceType);
  if (!key) {
    reportDiagnostic(context.program, {
      code: "invalid-resource-type",
      target: entity,
      messageId: "missingKey",
      format: {
        name: getTypeName3(resourceType)
      }
    });
    return;
  }
  if (!getSegment(context.program, key.keyProperty)) {
    reportDiagnostic(context.program, {
      code: "invalid-resource-type",
      target: entity,
      messageId: "missingSegment",
      format: {
        name: getTypeName3(resourceType)
      }
    });
  }
};
function isResourceOperation(program, operation) {
  return program.stateSet(AzureCoreStateKeys.resourceOperation).has(operation);
}
var $needsRoute = (context, entity) => {
  if (entity.node === void 0 || entity.node.templateParameters.length === 0) {
    context.program.stateSet(AzureCoreStateKeys.needsRoute).add(entity);
  }
};
function checkRpcRoutes(program) {
  program.stateSet(AzureCoreStateKeys.needsRoute).forEach((op) => {
    if (op.node === void 0 || op.node.templateParameters.length === 0 && !isAutoRoute(program, op) && !getRoutePath(program, op)) {
      reportDiagnostic(program, {
        code: "rpc-operation-needs-route",
        target: op
      });
    }
  });
}
var $ensureVerb = (context, entity, templateName, verb) => {
  context.program.stateMap(AzureCoreStateKeys.ensureVerb).set(entity, [templateName, verb]);
};
function checkEnsureVerb(program) {
  const opMap = program.stateMap(AzureCoreStateKeys.ensureVerb);
  for (const [operation, [templateName, requiredVerb]] of opMap.entries()) {
    if (isTemplateDeclarationOrInstance2(operation))
      continue;
    const verb = getHttpOperation5(program, operation)[0].verb.toString().toLowerCase();
    const reqVerb = requiredVerb.toLowerCase();
    if (verb !== reqVerb) {
      reportDiagnostic(program, {
        code: "verb-conflict",
        target: operation,
        format: {
          templateName,
          verb: verb.toUpperCase(),
          requiredVerb: reqVerb.toUpperCase()
        }
      });
    }
  }
}
var $embeddingVector = (context, entity, elementType) => {
  const metadata = {
    elementType
  };
  context.program.stateMap(AzureCoreStateKeys.embeddingVector).set(entity, metadata);
};
function getAsEmbeddingVector(program, model) {
  return program.stateMap(AzureCoreStateKeys.embeddingVector).get(model);
}
var $armResourceIdentifierConfig = (context, entity, config) => {
  if (config.kind !== "Model")
    return;
  const prop = config.properties.get("allowedResources");
  if (prop === void 0 || prop.type.kind !== "Tuple")
    return;
  const [data, diagnostics] = typespecTypeToJson(prop.type, context.getArgumentTarget(0));
  context.program.reportDiagnostics(diagnostics);
  if (data) {
    context.program.stateMap(AzureCoreStateKeys.armResourceIdentifierConfig).set(entity, { allowedResources: data });
  }
};
function getArmResourceIdentifierConfig(program, entity) {
  return program.stateMap(AzureCoreStateKeys.armResourceIdentifierConfig).get(entity);
}
var $defaultFinalStateVia = (context, target, states) => {
  const { program } = context;
  const finalStateValues = [];
  for (const finalState of states) {
    switch (finalState?.toLowerCase()) {
      case "operation-location":
        finalStateValues.push(FinalStateValue.operationLocation);
        break;
      case "location":
        finalStateValues.push(FinalStateValue.location);
        break;
      case "azure-async-operation":
        finalStateValues.push(FinalStateValue.azureAsyncOperation);
        break;
      default:
        reportDiagnostic(program, {
          code: "invalid-final-state",
          target,
          messageId: "badValue",
          format: { finalStateValue: finalState }
        });
        return;
    }
  }
  const storedValue = validateFinalStates(program, target, finalStateValues);
  if (storedValue !== void 0) {
    program.stateMap(AzureCoreStateKeys.finalStateOverride).set(target, storedValue);
  }
};
function createMarkerDecorator(validate) {
  const getParameterizedNextLinkArguments2 = (program, target) => program.stateMap(AzureCoreStateKeys.parameterizedNextLinkConfig).get(target);
  const markParameterizedNextLinkConfigTemplate = (program, target) => {
    compilerAssert2(target.templateArguments[0].kind === "Tuple" || target.templateArguments[0].kind === "Model", "Using the defined internal scalar parameterizedNextLink will result in a Tuple template argument type");
    program.stateMap(AzureCoreStateKeys.parameterizedNextLinkConfig).set(target, target.templateArguments[0].values);
  };
  const decorator = (...args) => {
    if (validate && !validate(...args)) {
      return;
    }
    const [context, target] = args;
    markParameterizedNextLinkConfigTemplate(context.program, target);
  };
  return [
    getParameterizedNextLinkArguments2,
    markParameterizedNextLinkConfigTemplate,
    decorator
  ];
}
var [
  getParameterizedNextLinkArguments,
  _markParameterizedNextLinkConfigTemplate,
  /** {@inheritDoc ParameterizedNextLinkConfigDecorator} */
  parameterizedNextLinkConfigDecorator
] = createMarkerDecorator();
setTypeSpecNamespace("Foundations", $omitKeyProperties, $requestParameter, $responseProperty);
setTypeSpecNamespace("Foundations.Private", $spreadCustomResponseProperties, $spreadCustomParameters, $ensureResourceType, $needsRoute, $ensureVerb, $embeddingVector, $armResourceIdentifierConfig, $defaultFinalStateVia, parameterizedNextLinkConfigDecorator);

// src/typespec/packages/typespec-azure-core/dist/src/rules/lro-polling-operation.js
function hasOperationLocation(program, entity) {
  if (entity.kind === "Model") {
    for (const [_, prop] of entity.properties) {
      if (isHeader3(program, prop)) {
        const header = getHeaderFieldName3(program, prop);
        return header.toLowerCase() === "operation-location";
      }
    }
  }
  return false;
}
var longRunningOperationsRequirePollingOperation = createRule8({
  name: "long-running-polling-operation-required",
  description: "Long-running operations should have a linked polling operation.",
  severity: "warning",
  messages: {
    default: "This operation has an 'Operation-Location' header but no polling operation. Use the '@pollingOperation' decorator to link a status polling operation."
  },
  create(context) {
    return {
      operation: (op) => {
        if (!isTemplatedInterfaceOperation(op) && !isTemplatedOperationSignature(op) && !isExcludedCoreType(context.program, op)) {
          if (op.returnType.kind === "Union" && Array.from(op.returnType.variants.values()).find((v) => hasOperationLocation(context.program, v.type)) || hasOperationLocation(context.program, op.returnType)) {
            if (!getOperationLink(context.program, op, "polling")) {
              context.reportDiagnostic({
                target: op
              });
            }
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-closed-literal-union.js
import { createRule as createRule9, ignoreDiagnostics as ignoreDiagnostics5 } from "@typespec/compiler";

// src/typespec/packages/typespec-azure-core/dist/src/helpers/union-enums.js
import { createDiagnosticCollector as createDiagnosticCollector3, isNullType } from "@typespec/compiler";
function getUnionAsEnum(union) {
  return getUnionAsEnumInternal(union, /* @__PURE__ */ new Set());
}
function getUnionAsEnumInternal(union, visited) {
  if (visited.has(union)) {
    return [void 0, [createDiagnostic({ code: "union-enums-circular", target: union })]];
  }
  visited.add(union);
  const diagnostics = createDiagnosticCollector3();
  function reportInvalidKind(type) {
    diagnostics.add(createDiagnostic({
      code: "union-enums-invalid-kind",
      format: { kind: type.kind },
      target: union
    }));
  }
  const kinds = /* @__PURE__ */ new Set();
  const members = /* @__PURE__ */ new Map();
  const flattenedMembers = /* @__PURE__ */ new Map();
  let open = false;
  let nullable = false;
  for (const variant of union.variants.values()) {
    switch (variant.type.kind) {
      case "Intrinsic":
        if (isNullType(variant.type)) {
          nullable = true;
        } else {
          reportInvalidKind(variant.type);
        }
        break;
      case "String":
        kinds.add("string");
        members.set(variant.name, { value: variant.type.value, type: variant });
        break;
      case "Number":
        kinds.add("number");
        members.set(variant.name, { value: variant.type.value, type: variant });
        break;
      case "Union":
        const parentUnion = diagnostics.pipe(getUnionAsEnumInternal(variant.type, visited));
        if (parentUnion !== void 0) {
          kinds.add(parentUnion.kind);
          if (parentUnion.open) {
            open = true;
          }
          if (parentUnion.nullable) {
            nullable = true;
          }
          for (const [key, value] of parentUnion.flattenedMembers) {
            flattenedMembers.set(key, value);
          }
        }
        break;
      case "Enum":
        for (const member of variant.type.members.values()) {
          kinds.add(typeof member.value === "number" ? "number" : "string");
          flattenedMembers.set(member.name, { value: member.value ?? member.name, type: member });
        }
        break;
      case "Scalar":
        const scalar = variant.type;
        switch (scalar.name) {
          case "string":
            kinds.add("string");
            open = true;
            break;
          case "float":
          case "float32":
          case "float64":
          case "integer":
          case "int8":
          case "int16":
          case "int32":
          case "int64":
          case "uint8":
          case "uint16":
          case "uint32":
          case "uint64":
            kinds.add("number");
            open = true;
            break;
          default:
            reportInvalidKind(variant.type);
        }
        break;
      default:
        reportInvalidKind(variant.type);
    }
  }
  for (const [key, value] of members) {
    flattenedMembers.set(key, value);
  }
  if (kinds.size > 1) {
    diagnostics.add(createDiagnostic({
      code: "union-enums-multiple-kind",
      format: { kinds: [...kinds].join(", ") },
      target: union
    }));
  }
  if (diagnostics.diagnostics.length > 0) {
    return diagnostics.wrap(void 0);
  }
  if (flattenedMembers.size === 0) {
    return [void 0, []];
  }
  return [
    {
      kind: [...kinds][0],
      union,
      members,
      flattenedMembers,
      open,
      nullable
    },
    []
  ];
}

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-closed-literal-union.js
var noClosedLiteralUnionRule = createRule9({
  name: "no-closed-literal-union",
  description: "Unions of literals should include the base scalar type to mark them as open enum.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/no-closed-literal-union",
  messages: {
    default: `Union of literals should include the base scalar as a variant to make it an open enum. (ex: \`union Choice { Yes: "yes", No: "no", string };\`).`
  },
  create(context) {
    return {
      union: (union) => {
        const e = ignoreDiagnostics5(getUnionAsEnum(union));
        if (e === void 0) {
          return;
        }
        if (!e.open) {
          context.reportDiagnostic({
            target: union
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-enum.js
import { createRule as createRule10, getPositionBeforeTrivia, getSourceLocation as getSourceLocation2, paramMessage as paramMessage9 } from "@typespec/compiler";
import { SyntaxKind as SyntaxKind4 } from "@typespec/compiler/ast";

// src/typespec/core/packages/versioning/dist/src/lib.js
import { createTypeSpecLibrary as createTypeSpecLibrary2, paramMessage as paramMessage8 } from "@typespec/compiler";
var $lib2 = createTypeSpecLibrary2({
  name: "@typespec/versioning",
  diagnostics: {
    "versioned-dependency-tuple": {
      severity: "error",
      messages: {
        default: `Versioned dependency mapping must be a tuple [SourceVersion, TargetVersion].`
      }
    },
    "versioned-dependency-tuple-enum-member": {
      severity: "error",
      messages: {
        default: `Versioned dependency mapping must be between enum members.`
      }
    },
    "versioned-dependency-same-namespace": {
      severity: "error",
      messages: {
        default: `Versioned dependency mapping must all point to the same namespace but 2 versions have different namespaces '${"namespace1"}' and '${"namespace2"}'.`
      }
    },
    "versioned-dependency-record-not-mapping": {
      severity: "error",
      messages: {
        default: paramMessage8`The versionedDependency decorator must provide a model mapping local versions to dependency '${"dependency"}' versions`
      }
    },
    "versioned-dependency-not-picked": {
      severity: "error",
      messages: {
        default: paramMessage8`The versionedDependency decorator must provide a version of the dependency '${"dependency"}'.`
      }
    },
    "version-not-found": {
      severity: "error",
      messages: {
        default: paramMessage8`The provided version '${"version"}' from '${"enumName"}' is not declared as a version enum. Use '@versioned(${"enumName"})' on the containing namespace.`
      }
    },
    "version-duplicate": {
      severity: "error",
      messages: {
        default: paramMessage8`Multiple versions from '${"name"}' resolve to the same value. Version enums must resolve to unique values.`
      }
    },
    "using-versioned-library": {
      severity: "error",
      messages: {
        default: paramMessage8`Namespace '${"sourceNs"}' is referencing types from versioned namespace '${"targetNs"}' but didn't specify which versions with @useDependency.`
      }
    },
    "invalid-renamed-from-value": {
      severity: "error",
      messages: {
        default: "@renamedFrom.oldName cannot be empty string."
      }
    },
    "incompatible-versioned-reference": {
      severity: "error",
      messages: {
        default: paramMessage8`'${"sourceName"}' is referencing versioned type '${"targetName"}' but is not versioned itself.`,
        addedAfter: paramMessage8`'${"sourceName"}' was added in version '${"sourceAddedOn"}' but referencing type '${"targetName"}' added in version '${"targetAddedOn"}'.`,
        dependentAddedAfter: paramMessage8`'${"sourceName"}' was added in version '${"sourceAddedOn"}' but contains type '${"targetName"}' added in version '${"targetAddedOn"}'.`,
        removedBefore: paramMessage8`'${"sourceName"}' was removed in version '${"sourceRemovedOn"}' but referencing type '${"targetName"}' removed in version '${"targetRemovedOn"}'.`,
        dependentRemovedBefore: paramMessage8`'${"sourceName"}' was removed in version '${"sourceRemovedOn"}' but contains type '${"targetName"}' removed in version '${"targetRemovedOn"}'.`,
        versionedDependencyAddedAfter: paramMessage8`'${"sourceName"}' is referencing type '${"targetName"}' added in version '${"targetAddedOn"}' but version used is '${"dependencyVersion"}'.`,
        versionedDependencyRemovedBefore: paramMessage8`'${"sourceName"}' is referencing type '${"targetName"}' removed in version '${"targetAddedOn"}' but version used is '${"dependencyVersion"}'.`,
        doesNotExist: paramMessage8`'${"sourceName"}' is referencing type '${"targetName"}' which does not exist in version '${"version"}'.`
      }
    },
    "incompatible-versioned-namespace-use-dependency": {
      severity: "error",
      messages: {
        default: "The useDependency decorator can only be used on a Namespace if the namespace is unversioned. For versioned namespaces, put the useDependency decorator on the version enum members."
      }
    },
    "made-optional-not-optional": {
      severity: "error",
      messages: {
        default: paramMessage8`Property '${"name"}' marked with @madeOptional but is required. Should be '${"name"}?'`
      }
    },
    "made-required-optional": {
      severity: "error",
      messages: {
        default: paramMessage8`Property '${"name"}?' marked with @madeRequired but is optional. Should be '${"name"}'`
      }
    },
    "renamed-duplicate-property": {
      severity: "error",
      messages: {
        default: paramMessage8`Property '${"name"}' marked with '@renamedFrom' conflicts with existing property in version ${"version"}.`
      }
    }
  },
  state: {
    versionIndex: { description: "Version index" },
    addedOn: { description: "State for @addedOn decorator" },
    removedOn: { description: "State for @removedOn decorator" },
    versions: { description: "State for @versioned decorator" },
    useDependencyNamespace: { description: "State for @useDependency decorator on Namespaces" },
    useDependencyEnum: { description: "State for @useDependency decorator on Enums" },
    renamedFrom: { description: "State for @renamedFrom decorator" },
    madeOptional: { description: "State for @madeOptional decorator" },
    madeRequired: { description: "State for @madeRequired decorator" },
    typeChangedFrom: { description: "State for @typeChangedFrom decorator" },
    returnTypeChangedFrom: { description: "State for @returnTypeChangedFrom decorator" }
  }
});
var { reportDiagnostic: reportDiagnostic2, createStateSymbol, stateKeys: VersioningStateKeys } = $lib2;

// src/typespec/core/packages/versioning/dist/src/versioning.js
import { getNamespaceFullName as getNamespaceFullName3 } from "@typespec/compiler";

// src/typespec/core/packages/versioning/dist/src/versioning-timeline.js
import { compilerAssert as compilerAssert3, getTypeName as getTypeName4 } from "@typespec/compiler";

// src/typespec/core/packages/versioning/dist/src/versioning.js
var versionCache = /* @__PURE__ */ new WeakMap();
function cacheVersion(key, versions) {
  versionCache.set(key, versions);
  return versions;
}
function getVersionsForEnum(program, en) {
  const namespace2 = en.namespace;
  if (namespace2 === void 0) {
    return [];
  }
  const nsVersion = getVersion(program, namespace2);
  if (nsVersion === void 0) {
    return [];
  }
  return [namespace2, nsVersion];
}
function getVersions(p, t) {
  const existing = versionCache.get(t);
  if (existing) {
    return existing;
  }
  switch (t.kind) {
    case "Namespace":
      return resolveVersionsForNamespace(p, t);
    case "Operation":
    case "Interface":
    case "Model":
    case "Union":
    case "Scalar":
    case "Enum":
      if (t.namespace) {
        return cacheVersion(t, getVersions(p, t.namespace) || []);
      } else if (t.kind === "Operation" && t.interface) {
        return cacheVersion(t, getVersions(p, t.interface) || []);
      } else {
        return cacheVersion(t, []);
      }
    case "ModelProperty":
      if (t.sourceProperty) {
        return getVersions(p, t.sourceProperty);
      } else if (t.model) {
        return getVersions(p, t.model);
      } else {
        return cacheVersion(t, []);
      }
    case "EnumMember":
      return cacheVersion(t, getVersions(p, t.enum) || []);
    case "UnionVariant":
      return cacheVersion(t, getVersions(p, t.union) || []);
    default:
      return cacheVersion(t, []);
  }
}
function resolveVersionsForNamespace(program, namespace2) {
  const nsVersion = getVersion(program, namespace2);
  if (nsVersion !== void 0) {
    return cacheVersion(namespace2, [namespace2, nsVersion]);
  }
  const parentNamespaceVersion = namespace2.namespace && getVersions(program, namespace2.namespace)[1];
  const hasDependencies = getUseDependencies(program, namespace2);
  if (parentNamespaceVersion || hasDependencies) {
    return cacheVersion(namespace2, [namespace2, parentNamespaceVersion]);
  } else {
    return cacheVersion(namespace2, [namespace2, void 0]);
  }
}
var Availability;
(function(Availability2) {
  Availability2["Unavailable"] = "Unavailable";
  Availability2["Added"] = "Added";
  Availability2["Available"] = "Available";
  Availability2["Removed"] = "Removed";
})(Availability || (Availability = {}));
function getVersionForEnumMember(program, member) {
  const parentEnum = member.enum;
  const [, versions] = getVersionsForEnum(program, parentEnum);
  return versions?.getVersionForEnumMember(member);
}

// src/typespec/core/packages/versioning/dist/src/decorators.js
function checkIsVersion(program, enumMember, diagnosticTarget) {
  const version = getVersionForEnumMember(program, enumMember);
  if (!version) {
    reportDiagnostic2(program, {
      code: "version-not-found",
      target: diagnosticTarget,
      format: { version: enumMember.name, enumName: enumMember.enum.name }
    });
  }
  return version;
}
var $added = (context, t, v) => {
  const { program } = context;
  const version = checkIsVersion(context.program, v, context.getArgumentTarget(0));
  if (!version) {
    return;
  }
  const record = program.stateMap(VersioningStateKeys.addedOn).get(t) ?? new Array();
  record.push(version);
  record.sort((a, b) => a.index - b.index);
  program.stateMap(VersioningStateKeys.addedOn).set(t, record);
};
function getRenamedFrom(p, t) {
  return p.stateMap(VersioningStateKeys.renamedFrom).get(t);
}
function getRenamedFromVersions(p, t) {
  return getRenamedFrom(p, t)?.map((x) => x.version);
}
function getAddedOnVersions(p, t) {
  return p.stateMap(VersioningStateKeys.addedOn).get(t);
}
function getRemovedOnVersions(p, t) {
  return p.stateMap(VersioningStateKeys.removedOn).get(t);
}
function getMadeOptionalOn(p, t) {
  return p.stateMap(VersioningStateKeys.madeOptional).get(t);
}
function getVersion(program, namespace2) {
  return program.stateMap(VersioningStateKeys.versions).get(namespace2);
}
function getNamespaceUseDependencyState(program, target) {
  return program.stateMap(VersioningStateKeys.useDependencyNamespace).get(target);
}
function getUseDependencies(program, target, searchEnum = true) {
  const result = /* @__PURE__ */ new Map();
  if (target.kind === "Namespace") {
    let current = target;
    while (current) {
      const data = getNamespaceUseDependencyState(program, current);
      if (!data) {
        if (searchEnum) {
          const versions = getVersion(program, current)?.getVersions();
          if (versions?.length) {
            const enumDeps = getUseDependencies(program, versions[0].enumMember.enum);
            if (enumDeps) {
              return enumDeps;
            }
          }
        }
        current = current.namespace;
      } else {
        for (const v of data) {
          result.set(v.namespace, v);
        }
        return result;
      }
    }
    return void 0;
  } else if (target.kind === "Enum") {
    const data = program.stateMap(VersioningStateKeys.useDependencyEnum).get(target);
    if (!data) {
      return void 0;
    }
    const resolved = resolveVersionDependency(program, data);
    if (resolved instanceof Map) {
      for (const [enumVer, value] of resolved) {
        for (const val of value) {
          const targetNamespace = val.enumMember.enum.namespace;
          if (!targetNamespace) {
            reportDiagnostic2(program, {
              code: "version-not-found",
              target: val.enumMember.enum,
              format: { version: val.enumMember.name, enumName: val.enumMember.enum.name }
            });
            return void 0;
          }
          let subMap = result.get(targetNamespace);
          if (subMap) {
            subMap.set(enumVer, val);
          } else {
            subMap = /* @__PURE__ */ new Map([[enumVer, val]]);
          }
          result.set(targetNamespace, subMap);
        }
      }
    }
  }
  return result;
}
function resolveVersionDependency(program, data) {
  if (!(data instanceof Map)) {
    return data;
  }
  const mapping = /* @__PURE__ */ new Map();
  for (const [key, value] of data) {
    const sourceVersion = getVersionForEnumMember(program, key);
    if (sourceVersion !== void 0) {
      mapping.set(sourceVersion, value);
    }
  }
  return mapping;
}

// src/typespec/core/packages/versioning/dist/src/validate.js
import { NoTarget, getNamespaceFullName as getNamespaceFullName4, getTypeName as getTypeName6, isTemplateInstance as isTemplateInstance4, isType as isType2, navigateProgram } from "@typespec/compiler";

// src/typespec/core/packages/versioning/dist/src/validate.codefix.js
import { getSourceLocation, getTypeName as getTypeName5 } from "@typespec/compiler";

// src/typespec/core/packages/versioning/dist/src/mutator.js
import {} from "@typespec/compiler/experimental";

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-enum.js
var noEnumRule = createRule10({
  name: "no-enum",
  description: "Azure services should not use enums.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/no-enum",
  messages: {
    default: paramMessage9`Azure services should not use the enum keyword. Extensible enums should be defined as unions with "string" as an accepted variant (ex: \`union Choice { Yes: "yes", No: "no", string };\`).`
  },
  create(context) {
    return {
      enum: (en) => {
        const [_, versions] = getVersionsForEnum(context.program, en);
        if (versions !== void 0 && versions.getVersions()[0].enumMember.enum === en) {
          return;
        }
        if (en.node === void 0) {
          return;
        }
        context.reportDiagnostic({
          format: { enumName: en.name },
          target: en,
          codefixes: [createEnumToExtensibleUnionCodeFix(en)]
        });
      }
    };
  }
});
function createEnumToExtensibleUnionCodeFix(en) {
  function convertEnumMemberToUnionVariant(node) {
    switch (node.kind) {
      case SyntaxKind4.EnumSpreadMember:
        return getSourceLocation2(node.target).file.text.slice(node.target.pos, node.target.end);
      case SyntaxKind4.EnumMember:
        return node.value ? `${node.id.sv}: ${node.value.kind === SyntaxKind4.NumericLiteral ? node.value.value : `"${node.value.value}"`}` : `${node.id.sv}: "${node.id.sv}"`;
    }
  }
  return {
    id: "enum-to-extensible-union",
    label: "Convert to extensible union",
    fix(context) {
      const type = typeof [...en.members.values()][0].value === "number" ? "number" : "string";
      const indent = getIndent(en.node);
      const script = getTypeSpecScript(en.node);
      if (script === void 0) {
        return [];
      }
      return [
        context.replaceText(getSourceLocation2(en.node), [
          getNodeAnnotations(en.node),
          `union ${en.name} {
`,
          `${indent}  `,
          `${type},
`,
          ...en.node.members.map((member) => {
            return `${getNodeTrivia(script, member)}${getNodeAnnotations(member)}${convertEnumMemberToUnionVariant(member)},`;
          }),
          getNodeTrivia(script, en.node.end - 1),
          "}"
        ].join(""))
      ];
    }
  };
}
function getIndent(node) {
  const source = getSourceLocation2(node).file.text;
  const start = source.lastIndexOf("\n", node.pos);
  return source.slice(start + 1, node.pos);
}
function getTypeSpecScript(node) {
  let root = node;
  while (root.parent !== void 0) {
    root = root.parent;
  }
  if (root.kind !== SyntaxKind4.TypeSpecScript) {
    return void 0;
  }
  return root;
}
function getNodeTrivia(root, node) {
  const end = typeof node === "number" ? node : node.pos;
  const pos = getPositionBeforeTrivia(root, end);
  return root.file.text.slice(pos, end);
}
function getNodeAnnotations(node) {
  const source = getSourceLocation2(node).file.text;
  let endOfTrivia = node.pos;
  for (const directive of node.directives ?? []) {
    if (directive.end > endOfTrivia) {
      endOfTrivia = directive.end;
    }
  }
  for (const doc of node.docs ?? []) {
    if (doc.end > endOfTrivia) {
      endOfTrivia = doc.end;
    }
  }
  if ("decorators" in node) {
    for (const dec of node.decorators ?? []) {
      if (dec.end > endOfTrivia) {
        endOfTrivia = dec.end;
      }
    }
  }
  for (let i = endOfTrivia; i < node.end; i++) {
    if (source[i] === " " || source[i] === "\n") {
      endOfTrivia = i + 1;
    } else {
      break;
    }
  }
  return getSourceLocation2(node).file.text.slice(node.pos, endOfTrivia);
}

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-error-status-codes.js
import { createRule as createRule11, ignoreDiagnostics as ignoreDiagnostics6 } from "@typespec/compiler";
import { getHttpOperation as getHttpOperation6 } from "@typespec/http";
var noErrorStatusCodesRule = createRule11({
  name: "no-error-status-codes",
  description: "Recommend using the error response defined by Azure REST API guidelines.",
  severity: "warning",
  messages: {
    default: "Azure REST API guidelines recommend using 'default' error response for all error cases. Avoid defining custom 4xx or 5xx error cases."
  },
  create(context) {
    return {
      operation: (operation) => {
        if (isExcludedCoreType(context.program, operation))
          return;
        if (!isAzureSubNamespace(context.program, operation.namespace))
          return;
        const httpOperation = ignoreDiagnostics6(getHttpOperation6(context.program, operation));
        if (httpOperation.responses !== void 0) {
          for (const response of httpOperation.responses) {
            const statusCode = response.statusCodes;
            if (typeof statusCode === "number" && statusCode >= 400 && statusCode < 600) {
              context.reportDiagnostic({
                target: operation
              });
            }
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-explicit-routes-resource-ops.js
import { createRule as createRule12 } from "@typespec/compiler";
import { getRoutePath as getRoutePath2 } from "@typespec/http";
var noExplicitRoutesResourceOps = createRule12({
  name: "no-explicit-routes-resource-ops",
  description: "The @route decorator should not be used on standard resource operation signatures.",
  severity: "warning",
  messages: {
    default: "The @route decorator should not be used on standard resource operation signatures. If you are trying to add a route prefix to an operation use the @route decorator on an interface or namespace instead."
  },
  create(context) {
    return {
      operation: (operation) => {
        if (isExcludedCoreType(context.program, operation) || !isResourceOperation(context.program, operation)) {
          return;
        }
        if (getRoutePath2(context.program, operation)) {
          context.reportDiagnostic({
            target: operation
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-generic-numeric.js
import { createRule as createRule13, paramMessage as paramMessage10 } from "@typespec/compiler";
var disallowList = /* @__PURE__ */ new Set(["integer", "numeric", "float", "decimal"]);
var alternatives = /* @__PURE__ */ new Map([
  ["integer", "int32"],
  ["numeric", "int32"],
  ["float", "float32"],
  ["decimal", "float32"]
]);
var noGenericNumericRule = createRule13({
  name: "no-generic-numeric",
  description: "Don't use generic types. Use more specific types instead.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/no-generic-numeric",
  messages: {
    default: paramMessage10`Don't use generic type '${"name"}'. Use a more specific type that specifies the bit size, such as '${"alternative"}' instead.`,
    extend: paramMessage10`Don't extend generic type '${"name"}'. Use a more specific type that specifies the bit size, such as '${"alternative"}' instead.`
  },
  create(context) {
    return {
      model: (model) => {
        for (const [_, prop] of model.properties) {
          if (prop.type.kind === "Scalar") {
            if (disallowList.has(prop.type.name)) {
              context.reportDiagnostic({
                target: prop,
                format: {
                  name: prop.type.name,
                  alternative: alternatives.get(prop.type.name)
                }
              });
            }
          }
        }
      },
      scalar: (scalar) => {
        if (disallowList.has(scalar.name)) {
          return;
        }
        let baseScalar = void 0;
        while (scalar.baseScalar !== void 0) {
          baseScalar = scalar.baseScalar;
          break;
        }
        if (baseScalar === void 0) {
          return;
        }
        if (disallowList.has(baseScalar.name)) {
          context.reportDiagnostic({
            target: scalar,
            messageId: "extend",
            format: {
              name: baseScalar.name,
              alternative: alternatives.get(baseScalar.name)
            }
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-header-explode.js
import { createRule as createRule14, ignoreDiagnostics as ignoreDiagnostics7 } from "@typespec/compiler";
import { getHttpOperation as getHttpOperation7 } from "@typespec/http";
var noHeaderExplodeRule = createRule14({
  name: "no-header-explode",
  description: "It is recommended to serialize header parameter without explode: true",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/no-header-explode",
  messages: {
    default: `It is preferred to not use explode: true for header parameters`
  },
  create(context) {
    return {
      operation: (operation) => {
        const httpOperation = ignoreDiagnostics7(getHttpOperation7(context.program, operation));
        for (const prop of httpOperation.parameters.properties.filter((x) => x.kind === "header")) {
          if (prop.options.explode === true) {
            context.reportDiagnostic({
              target: prop.property
            });
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-legacy-usage.js
import { createRule as createRule15, paramMessage as paramMessage11 } from "@typespec/compiler";
var noLegacyUsage = createRule15({
  name: "no-legacy-usage",
  description: "Linter warning against using elements from the Legacy namespace",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/no-legacy-usage",
  messages: {
    default: paramMessage11`Referencing elements inside Legacy namespace "${"ns"}" is not allowed.`
  },
  create(context) {
    function checkDecorators(type) {
      return checkDecoratorsInDisallowedNamespace(context, type, "Legacy");
    }
    function checkReference(origin, type, target) {
      return checkReferenceInDisallowedNamespace(context, origin, type, target, "Legacy");
    }
    return {
      model: (model) => {
        checkDecorators(model);
        model.baseModel && checkReference(model, model.baseModel, model);
      },
      modelProperty: (prop) => {
        checkDecorators(prop);
        checkReference(prop, prop.type, prop);
      },
      unionVariant: (variant) => {
        checkDecorators(variant);
        checkReference(variant, variant.type, variant);
      },
      operation: (type) => {
        checkDecorators(type);
      },
      interface: (type) => {
        checkDecorators(type);
      },
      enum: (type) => {
        checkDecorators(type);
      },
      union: (type) => {
        checkDecorators(type);
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-multiple-discriminator.js
import { createRule as createRule16, getDiscriminator as getDiscriminator2, paramMessage as paramMessage12 } from "@typespec/compiler";
var noMultipleDiscriminatorRule = createRule16({
  name: "no-multiple-discriminator",
  description: "Classes should have at most one discriminator.",
  severity: "warning",
  messages: {
    default: paramMessage12`Class hierarchy for '${"name"}' should only have, at most, one discriminator, but found: ${"values"}.`
  },
  create(context) {
    return {
      model: (model) => {
        const discriminators = new Array();
        let current = model;
        while (current) {
          const discriminator = getDiscriminator2(context.program, current);
          if (discriminator) {
            discriminators.push(discriminator);
          }
          current = current.baseModel;
        }
        if (discriminators.length > 1) {
          context.reportDiagnostic({
            target: model,
            format: {
              name: model.name,
              values: discriminators.flatMap((x) => x.propertyName).join(", ")
            }
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-nullable.js
import { createRule as createRule17, isNullType as isNullType2 } from "@typespec/compiler";
var noNullableRule = createRule17({
  name: "no-nullable",
  description: "Use `?` for optional properties.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/no-nullable",
  messages: {
    default: "Don't use `| null`. If you meant to have an optional property, use `?`. (e.g. `myProp?: string`)"
  },
  create(context) {
    return {
      modelProperty: (property) => {
        if (property.type.kind !== "Union") {
          return;
        }
        if ([...property.type.variants.values()].some((x) => isNullType2(x.type))) {
          context.reportDiagnostic({
            target: property
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-offsetdatetime.js
import { createRule as createRule18 } from "@typespec/compiler";
var noOffsetDateTimeRule = createRule18({
  name: "no-offsetdatetime",
  description: "Prefer using `utcDateTime` when representing a datetime unless an offset is necessary.",
  severity: "warning",
  messages: {
    default: "Prefer using `utcDateTime` when representing a datetime unless an offset is necessary."
  },
  create(context) {
    const [offsetDateTime] = context.program.resolveTypeReference("TypeSpec.offsetDateTime");
    const reportIfOffset = (program, type, target) => {
      if (type === offsetDateTime) {
        context.reportDiagnostic({
          target
        });
      }
    };
    return {
      scalar: (model) => {
        if (isExcludedCoreType(context.program, model))
          return;
        if (model.baseScalar) {
          reportIfOffset(context.program, model.baseScalar, model);
        }
      },
      modelProperty: (property) => {
        if (isExcludedCoreType(context.program, property))
          return;
        reportIfOffset(context.program, property.type, property);
      },
      unionVariant: (variant) => {
        if (isExcludedCoreType(context.program, variant))
          return;
        reportIfOffset(context.program, variant.type, variant);
      },
      operation: (operation) => {
        if (isExcludedCoreType(context.program, operation))
          return;
        reportIfOffset(context.program, operation.returnType, operation);
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-openapi.js
import { createRule as createRule19, getTypeName as getTypeName7, paramMessage as paramMessage13 } from "@typespec/compiler";
var noOpenAPIRule = createRule19({
  name: "no-openapi",
  description: "Azure specs should not be using decorators from @typespec/openapi or @azure-tools/typespec-autorest",
  severity: "warning",
  messages: {
    default: paramMessage13`Azure specs should not be using decorator "${"name"}" from @typespec/openapi or @azure-tools/typespec-autorest. They will not apply to other emitter.`,
    operationId: "Operation ID is automatically generated by the OpenAPI emitters and should not normally be specified.",
    useRef: "Using @useRef should never be used in Azure specs.",
    example: "Using @example decorator explicitly is not allowed. See https://azure.github.io/typespec-azure/docs/next/migrate-swagger/faq/x-ms-examples"
  },
  create(context) {
    function checkDecorators(type) {
      for (const dec of type.decorators) {
        if (dec.definition) {
          const id = getTypeName7(dec.definition.namespace);
          if ((id === "TypeSpec.OpenAPI" || id === "Autorest") && !isException(dec.definition, dec)) {
            context.reportDiagnostic({
              target: dec.node ?? type,
              format: { name: dec.decorator.name },
              messageId: getMessageId(dec.definition)
            });
          }
        }
      }
    }
    return {
      model: checkDecorators,
      modelProperty: checkDecorators,
      enum: checkDecorators,
      union: checkDecorators,
      operation: checkDecorators,
      enumMember: checkDecorators,
      unionVariant: checkDecorators,
      interface: checkDecorators,
      namespace: checkDecorators
    };
  }
});
function isException(dec, application) {
  return dec.name === "@extension" && application.args[0].jsValue === "x-ms-identifiers";
}
function getMessageId(dec) {
  switch (dec.name) {
    case "@operationId":
      return "operationId";
    case "@useRef":
      return "useRef";
    case "@example":
      return "example";
    default:
      return "default";
  }
}

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-private-usage.js
import { createRule as createRule20, paramMessage as paramMessage14 } from "@typespec/compiler";
var noPrivateUsage = createRule20({
  name: "no-private-usage",
  description: "Verify that elements inside Private namespace are not referenced.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/no-private-usage",
  messages: {
    default: paramMessage14`Referencing elements inside Private namespace "${"ns"}" is not allowed.`
  },
  create(context) {
    function checkReference(origin, type, target) {
      return checkReferenceInDisallowedNamespace(context, origin, type, target, "Private");
    }
    function checkDecorators(type) {
      return checkDecoratorsInDisallowedNamespace(context, type, "Private");
    }
    return {
      model: (model) => {
        checkDecorators(model);
        model.baseModel && checkReference(model, model.baseModel, model);
      },
      modelProperty: (prop) => {
        checkDecorators(prop);
        checkReference(prop, prop.type, prop);
      },
      unionVariant: (variant) => {
        checkDecorators(variant);
        checkReference(variant, variant.type, variant);
      },
      operation: (type) => {
        checkDecorators(type);
      },
      interface: (type) => {
        checkDecorators(type);
      },
      enum: (type) => {
        checkDecorators(type);
      },
      union: (type) => {
        checkDecorators(type);
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-query-explode.js
import { createRule as createRule21, ignoreDiagnostics as ignoreDiagnostics8 } from "@typespec/compiler";
import { getHttpOperation as getHttpOperation8 } from "@typespec/http";
var noQueryExplodeRule = createRule21({
  name: "no-query-explode",
  description: "It is recommended to serialize query parameter without explode: true",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/no-query-explode",
  messages: {
    default: `It is preferred to not use explode: true for query parameters`
  },
  create(context) {
    return {
      operation: (operation) => {
        const httpOperation = ignoreDiagnostics8(getHttpOperation8(context.program, operation));
        for (const prop of httpOperation.parameters.properties.filter((x) => x.kind === "query")) {
          if (prop.options.explode === true) {
            context.reportDiagnostic({
              target: prop.property
            });
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-response-body.js
import { createRule as createRule22 } from "@typespec/compiler";
import { getResponsesForOperation as getResponsesForOperation2 } from "@typespec/http";
var noResponseBodyRule = createRule22({
  name: "no-response-body",
  description: "Ensure that the body is set correctly for the response type.",
  severity: "warning",
  messages: {
    default: `The body of non-204 responses should not be empty.`,
    response204: `The body of 204 response should be empty.`
  },
  create(context) {
    return {
      operation: (op) => {
        if (isTemplatedInterfaceOperation(op))
          return;
        if (!isAzureSubNamespace(context.program, op.namespace))
          return;
        const responses = getResponsesForOperation2(context.program, op)[0].find((v) => v.statusCodes !== 204);
        if (responses && !responses.responses.every((v) => v.body)) {
          context.reportDiagnostic({
            target: op
          });
        }
        const responses204 = getResponsesForOperation2(context.program, op)[0].find((v) => v.statusCodes === 204);
        if (responses204 && responses204.responses.some((v) => v.body)) {
          context.reportDiagnostic({
            target: op,
            messageId: "response204"
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-rpc-path-params.js
import { createRule as createRule23 } from "@typespec/compiler";
import { isPathParam } from "@typespec/http";
var noRpcPathParamsRule = createRule23({
  name: "no-rpc-path-params",
  description: "Operations defined using RpcOperation should not have path parameters.",
  severity: "warning",
  messages: {
    default: "Operations defined using RpcOperation should not have path parameters. Consider using ResourceAction or ResourceCollectionAction instead."
  },
  create(context) {
    return {
      operation: (operation) => {
        if (isExcludedCoreType(context.program, operation) || operation.node?.templateParameters.length !== 0) {
          return;
        }
        const originalOperation = operation;
        while (operation.sourceOperation) {
          operation = operation.sourceOperation;
          if (operation.name.endsWith("RpcOperation") && operation.namespace?.name === "Core" && operation.namespace?.namespace?.name === "Azure") {
            for (const [_, param] of originalOperation.parameters.properties) {
              if (isPathParam(context.program, param)) {
                context.reportDiagnostic({
                  target: originalOperation
                });
                return;
              }
            }
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/no-string-discriminator.js
import { createRule as createRule24, getDiscriminator as getDiscriminator3, paramMessage as paramMessage15 } from "@typespec/compiler";
var noStringDiscriminatorRule = createRule24({
  name: "no-string-discriminator",
  description: "Azure services discriminated models should define the discriminated property as an extensible union.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/no-string-discriminator",
  messages: {
    default: `Use an extensible union instead of a plain string (ex: \`union PetKind { cat: "cat", dog: "dog", string };\`)`,
    noProp: paramMessage15`Discriminated model should define an the discriminator property ${"propName"} with an extensible union as type.`
  },
  create(context) {
    return {
      model: (model) => {
        const discriminator = getDiscriminator3(context.program, model);
        if (discriminator === void 0) {
          return;
        }
        const prop = model.properties.get(discriminator.propertyName);
        if (prop === void 0) {
          context.reportDiagnostic({
            format: { propName: discriminator.propertyName },
            target: model
          });
        } else {
          if (prop.type.kind !== "Union") {
            context.reportDiagnostic({
              format: { propName: discriminator.propertyName },
              target: prop
            });
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/non-breaking-versioning.js
import { createRule as createRule25, paramMessage as paramMessage16 } from "@typespec/compiler";
var nonBreakingVersioningRule = createRule25({
  name: "non-breaking-versioning",
  description: "Check that only backward compatible versioning change are done to a service.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/non-breaking-versioning",
  messages: {
    default: paramMessage16`Using ${"action"} is not backward compatible.`,
    addedRequired: "Adding required property is a breaking change.",
    optionalNoDefault: "Property made optional should have a default value."
  },
  create(context) {
    return {
      model: checkBadVersioningPattern,
      modelProperty: checkBadVersioningPatternForProperty,
      operation: checkBadVersioningPattern
    };
    function checkBadVersioningPattern(type) {
      if (getRemovedOnVersions(context.program, type) !== void 0) {
        reportBreakingVersioning("@removed", type);
      }
      if (getRenamedFromVersions(context.program, type) !== void 0) {
        reportBreakingVersioning("@renamedFrom", type);
      }
    }
    function checkBadVersioningPatternForProperty(modelProperty) {
      checkBadVersioningPattern(modelProperty);
      if (getAddedOnVersions(context.program, modelProperty) !== void 0 && !modelProperty.optional) {
        context.reportDiagnostic({
          messageId: "addedRequired",
          target: modelProperty
        });
      }
      if (getMadeOptionalOn(context.program, modelProperty) !== void 0 && modelProperty.defaultValue === void 0) {
        context.reportDiagnostic({
          messageId: "optionalNoDefault",
          target: modelProperty
        });
      }
    }
    function reportBreakingVersioning(action, target) {
      context.reportDiagnostic({
        format: { action },
        target
      });
    }
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/operation-missing-api-version.js
import { createRule as createRule26 } from "@typespec/compiler";
function isApiVersionParam(prop) {
  return prop.name === "apiVersion" && prop.type.kind === "Scalar" && prop.type.name === "string";
}
var apiVersionRule = createRule26({
  name: "operation-missing-api-version",
  description: "Operations need an api version parameter.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/operation-missing-api-version",
  messages: {
    default: `Operation is missing an api version parameter.`
  },
  create(context) {
    return {
      operation: (op) => {
        if (getVersions(context.program, op)[1] === void 0)
          return;
        for (const param of op.parameters.properties.values()) {
          if (isApiVersionParam(param))
            return;
        }
        context.reportDiagnostic({
          target: op
        });
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/prevent-format.js
import { createRule as createRule27 } from "@typespec/compiler";
var preventFormatRule = createRule27({
  name: "no-format",
  description: "Azure services should not use the `@format` decorator.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/prevent-format",
  messages: {
    default: "Azure services should not use the `@format` decorator."
  },
  create(context) {
    return {
      scalar: (scalar) => {
        for (const dec of scalar.decorators) {
          if (dec.decorator.name === "$format") {
            context.reportDiagnostic({
              target: dec.node ? dec.node : scalar
            });
          }
        }
      },
      modelProperty: (model) => {
        for (const dec of model.decorators) {
          if (dec.decorator.name === "$format") {
            context.reportDiagnostic({
              target: dec.node ? dec.node : model
            });
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/prevent-rest-library.js
import { createRule as createRule28, getNamespaceFullName as getNamespaceFullName5 } from "@typespec/compiler";
function getTypeReferenceNamespace(program, ref) {
  const baseOperation = program.checker.getTypeForNode(ref);
  return baseOperation.namespace ? getNamespaceFullName5(baseOperation.namespace) : "";
}
var preventRestLibraryInterfaces = createRule28({
  name: "no-rest-library-interfaces",
  description: "Resource interfaces from the TypeSpec.Rest.Resource library are incompatible with Azure.Core.",
  severity: "warning",
  messages: {
    default: `Resource interfaces from the TypeSpec.Rest.Resource library are incompatible with Azure.Core.`
  },
  create(context) {
    return {
      interface: (interfaceContext) => {
        if (isExcludedCoreType(context.program, interfaceContext)) {
          return;
        }
        const restInterface = interfaceContext.node?.extends.find((i) => getTypeReferenceNamespace(context.program, i) === "TypeSpec.Rest.Resource");
        if (restInterface) {
          context.reportDiagnostic({
            target: interfaceContext
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/prevent-unknown.js
import { createRule as createRule29, isUnknownType } from "@typespec/compiler";
var preventUnknownType = createRule29({
  name: "no-unknown",
  description: "Azure services must not have properties of type `unknown`.",
  severity: "warning",
  messages: {
    default: "Azure services must not have properties of type `unknown`."
  },
  create(context) {
    return {
      modelProperty: (modelContext) => {
        if (isUnknownType(modelContext.type)) {
          context.reportDiagnostic({
            target: modelContext
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/request-body-array.js
import { createRule as createRule30 } from "@typespec/compiler";
import { isBody as isBody3, isBodyRoot as isBodyRoot3 } from "@typespec/http";
var bodyArrayRule = createRule30({
  name: "request-body-problem",
  description: "Request body should not be of raw array type.",
  severity: "warning",
  messages: {
    array: "Request body should not be of raw array type. Consider creating a container model that can add properties over time to avoid introducing breaking changes."
  },
  create(context) {
    return {
      operation: (op) => {
        for (const prop of op.parameters.properties.values()) {
          if ((isBody3(context.program, prop) || isBodyRoot3(context.program, prop)) && prop.type.kind === "Model" && prop.type.name === "Array") {
            context.reportDiagnostic({
              target: prop,
              messageId: "array"
            });
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/require-docs.js
import { createRule as createRule31, getDiscriminatedTypes, getDiscriminator as getDiscriminator4, getDoc, paramMessage as paramMessage17 } from "@typespec/compiler";
function isExcludedVersionEnum(program, enumObj) {
  const versions = getVersionsForEnum(program, enumObj);
  if (versions !== void 0 && versions.length > 0) {
    return true;
  }
  return false;
}
function findDiscriminator(program, model) {
  if (!model)
    return void 0;
  const disc = getDiscriminator4(program, model);
  if (disc) {
    return disc;
  }
  return findDiscriminator(program, model.baseModel);
}
function isExcludedDiscriminator(program, type, discTypes) {
  if (type.kind === "ModelProperty") {
    const disc = findDiscriminator(program, type.model);
    if (disc && disc.propertyName === type.name) {
      return true;
    }
  } else if (type.kind === "Enum" || type.kind === "Union") {
    for (const [discType, discName] of discTypes) {
      if (discType.kind === "Model") {
        const discObj = discType.properties.get(discName.propertyName);
        if (discObj?.type === type) {
          return true;
        }
      }
    }
  }
  return false;
}
function getUnionName(union) {
  if (union.name !== void 0) {
    return union.name;
  }
  return void 0;
}
function getVariantName(variant) {
  if (variant.name !== void 0 && typeof variant.name === "string") {
    return variant.name;
  }
  if (variant.type.kind === "String") {
    return variant.type.value;
  }
  return void 0;
}
var requireDocumentation = createRule31({
  name: "documentation-required",
  description: "Require documentation over enums, models, and operations.",
  severity: "warning",
  messages: {
    default: paramMessage17`The ${"kind"} named '${"name"}' should have a documentation or description, use doc comment /** */ to provide it.`
  },
  create(context) {
    const discTypes = getDiscriminatedTypes(context.program);
    return {
      enum: (enumObj) => {
        if (isExcludedVersionEnum(context.program, enumObj)) {
          return;
        }
        if (isExcludedDiscriminator(context.program, enumObj, discTypes)) {
          return;
        }
        if (!getDoc(context.program, enumObj) && !isExcludedCoreType(context.program, enumObj)) {
          context.reportDiagnostic({
            target: enumObj,
            format: { kind: enumObj.kind, name: enumObj.name }
          });
        }
        for (const member of enumObj.members.values()) {
          if (!getDoc(context.program, member)) {
            context.reportDiagnostic({
              target: member,
              format: { kind: member.kind, name: member.name }
            });
          }
        }
      },
      operation: (operation) => {
        if (!isTemplatedInterfaceOperation(operation) && !isTemplatedOperationSignature(operation) && !isExcludedCoreType(context.program, operation)) {
          if (!getDoc(context.program, operation)) {
            context.reportDiagnostic({
              target: operation,
              format: { kind: operation.kind, name: operation.name }
            });
          }
          for (const param of operation.parameters.properties.values()) {
            if (!getDoc(context.program, param)) {
              context.reportDiagnostic({
                target: param,
                format: { kind: param.kind, name: param.name }
              });
            }
          }
        }
      },
      model: (model) => {
        if (!isTemplateDeclarationType(model) && !isInlineModel(model) && !isExcludedCoreType(context.program, model) && model.name !== "object") {
          if (!getDoc(context.program, model)) {
            context.reportDiagnostic({
              target: model,
              format: { kind: model.kind, name: model.name }
            });
          }
          for (const prop of model.properties.values()) {
            if (isExcludedDiscriminator(context.program, prop, discTypes)) {
              return;
            }
            if (!getDoc(context.program, prop)) {
              context.reportDiagnostic({
                target: prop,
                format: { kind: prop.kind, name: prop.name }
              });
            }
          }
        }
      },
      union: (union) => {
        if (isExcludedDiscriminator(context.program, union, discTypes)) {
          return;
        }
        if (!getDoc(context.program, union) && !isExcludedCoreType(context.program, union)) {
          const name = getUnionName(union);
          if (name !== void 0) {
            context.reportDiagnostic({
              target: union,
              format: { kind: union.kind, name }
            });
          }
        }
        for (const variant of union.variants.values()) {
          if (!getDoc(context.program, variant)) {
            const variantName = getVariantName(variant);
            if (variantName !== void 0) {
              context.reportDiagnostic({
                target: variant,
                format: { kind: variant.kind, name: variantName }
              });
            }
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/require-key-visibility.js
import { createRule as createRule32, getLifecycleVisibilityEnum, getVisibilityForClass, isKey as isKey2, paramMessage as paramMessage18 } from "@typespec/compiler";
var requireKeyVisibility = createRule32({
  name: "key-visibility-required",
  description: "Key properties need to have a Lifecycle visibility setting.",
  severity: "warning",
  messages: {
    default: paramMessage18`The key property '${"name"}' has default Lifecycle visibility, please use the @visibility decorator to change it.`
  },
  create(context) {
    const Lifecycle = getLifecycleVisibilityEnum(context.program);
    return {
      model: (model) => {
        if (!isTemplateDeclarationType(model) && !isInlineModel(model) && !isExcludedCoreType(context.program, model) && model.name !== "object") {
          for (const [name, prop] of model.properties) {
            const hasExplicitVisibility = getVisibilityForClass(context.program, prop, Lifecycle).size !== Lifecycle.members.size;
            if (isKey2(context.program, prop) && !hasExplicitVisibility) {
              context.reportDiagnostic({
                target: prop,
                format: { name }
              });
            }
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/require-versioned.js
import { createRule as createRule33, getSourceLocation as getSourceLocation3, listServices, paramMessage as paramMessage19 } from "@typespec/compiler";
var requireVersionedRule = createRule33({
  name: "require-versioned",
  description: "Azure services should use the versioning library.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/require-versioned",
  messages: {
    default: paramMessage19`Azure services should use the versioning library to define versions for their services. Add the '@versioned' decorator to the service namespace.`
  },
  create(context) {
    return {
      root: (program) => {
        const services = listServices(program);
        for (const service of services) {
          if (getVersion(program, service.type) === void 0) {
            context.reportDiagnostic({
              format: { serviceName: service.type },
              target: service.type,
              codefixes: [createAddVersionedCodeFix(service.type)]
            });
          }
        }
      }
    };
  }
});
function createAddVersionedCodeFix(namespace2) {
  return {
    id: "add-versioned",
    label: "Add @versioned",
    fix(context) {
      const location = getSourceLocation3(namespace2);
      const { lineStart, indent } = findLineStartAndIndent(location);
      const updatedLocation = { ...location, pos: lineStart };
      return context.prependText(updatedLocation, `${indent}@versioned(Versions /* create an enum called Versions with your service version */)
`);
    }
  };
}

// src/typespec/packages/typespec-azure-core/dist/src/rules/response-schema-multi-status-code.js
import { createRule as createRule34, ignoreDiagnostics as ignoreDiagnostics9, isErrorModel as isErrorModel2, paramMessage as paramMessage20 } from "@typespec/compiler";
import { Visibility, createMetadataInfo, getHttpOperation as getHttpOperation9 } from "@typespec/http";
var responseSchemaMultiStatusCodeRule = createRule34({
  name: "response-schema-problem",
  description: "Warn about operations having multiple non-error response schemas.",
  severity: "warning",
  messages: {
    multipleSuccessSchemas: paramMessage20`Operation '${"name"}' has multiple non-error response schemas. Did you forget to add '@error' to one of them?`
  },
  create(context) {
    return {
      operation: (op) => {
        const httpOp = ignoreDiagnostics9(getHttpOperation9(context.program, op));
        const responses = httpOp.responses.flatMap((x) => x.responses);
        const metadataInfo = createMetadataInfo(context.program, {
          canonicalVisibility: Visibility.Read
        });
        let firstResponse = void 0;
        for (const resp of responses) {
          const body = resp.body;
          if (body === void 0)
            continue;
          const bodyType = body.type;
          let currResponse = void 0;
          switch (bodyType.kind) {
            case "Model":
              const effModel = metadataInfo.getEffectivePayloadType(bodyType, Visibility.Read);
              if (isErrorModel2(context.program, effModel))
                continue;
              currResponse = effModel;
              break;
            default:
              currResponse = bodyType;
              break;
          }
          if (firstResponse === void 0) {
            firstResponse = currResponse;
          } else if (firstResponse !== currResponse) {
            context.reportDiagnostic({
              target: op,
              messageId: "multipleSuccessSchemas",
              format: {
                name: op.name
              }
            });
            return;
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/rpc-operation-request-body.js
import { createRule as createRule35, paramMessage as paramMessage21 } from "@typespec/compiler";
import { getHttpOperation as getHttpOperation10 } from "@typespec/http";
var rpcOperationRequestBodyRule = createRule35({
  name: "rpc-operation-request-body",
  description: "Warning for RPC body problems.",
  severity: "warning",
  messages: {
    default: `There is an issue with the RPCOperation request body.`,
    noBodyAllowed: paramMessage21`RPCOperation with '@${"verb"}' cannot have a body.`
  },
  create(context) {
    return {
      operation: (operation) => {
        if (isExcludedCoreType(context.program, operation))
          return;
        if (operation.node?.templateParameters.length !== 0)
          return;
        if (!isAzureSubNamespace(context.program, operation.namespace))
          return;
        const originalOperation = operation;
        while (operation.sourceOperation) {
          operation = operation.sourceOperation;
          if (operation.name === "RpcOperation" && operation.namespace?.name === "Core" && operation.namespace?.namespace?.name === "Azure") {
            const httpOperation = getHttpOperation10(context.program, originalOperation)[0];
            const bodyParam = httpOperation.parameters.body;
            const verb = httpOperation.verb.toLowerCase();
            if ((verb === "get" || verb === "delete") && bodyParam !== void 0) {
              context.reportDiagnostic({
                target: originalOperation,
                messageId: "noBodyAllowed",
                format: { verb }
              });
            }
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/spread-discriminated-model.js
import { createRule as createRule36, getDiscriminator as getDiscriminator5, paramMessage as paramMessage22 } from "@typespec/compiler";
import { SyntaxKind as SyntaxKind5 } from "@typespec/compiler/ast";
var spreadDiscriminatedModelRule = createRule36({
  name: "spread-discriminated-model",
  description: "Check a model with a discriminator has not been used in composition.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/spread-discriminated-model",
  messages: {
    default: paramMessage22`Model '${"name"}' is being spread but has a discriminator. The relation between those 2 models will be lost and defeat the purpose of \`@discriminator\` Consider using \`extends\` instead.`
  },
  create(context) {
    const visited = /* @__PURE__ */ new Set();
    return {
      modelProperty: (property) => {
        const model = property.model;
        if (model && model.node?.kind === SyntaxKind5.ModelStatement && property.sourceProperty && property.sourceProperty.model) {
          const targetModel = property.sourceProperty.model;
          if (visited.has(targetModel)) {
            return;
          }
          visited.add(targetModel);
          if (model.sourceModel === targetModel) {
            return;
          }
          if (getDiscriminator5(context.program, targetModel) !== void 0) {
            const diagnosticTarget = model.node.properties.find((x) => x.kind === SyntaxKind5.ModelSpreadProperty && context.program.checker.getTypeForNode(x.target) === targetModel) ?? model;
            context.reportDiagnostic({
              format: {
                name: targetModel.name
              },
              target: diagnosticTarget
            });
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/use-standard-names.js
import { createRule as createRule37, ignoreDiagnostics as ignoreDiagnostics10, isTemplateDeclarationOrInstance as isTemplateDeclarationOrInstance3 } from "@typespec/compiler";
import { getHttpOperation as getHttpOperation11 } from "@typespec/http";
import { isListOperation } from "@typespec/rest";
var useStandardNames = createRule37({
  name: "use-standard-names",
  description: "Use recommended names for operations.",
  severity: "warning",
  messages: {
    get: "GET operations that return single objects should start with 'get'",
    list: "GET operations that return lists should start with 'list'",
    createOrReplace: "PUT operations that return both 201 and 200 should start with 'createOrReplace'",
    putCreate: "PUT operations that return 201 should start with 'create' or 'createOrReplace'",
    putReplace: "PUT operations that return 200 should start with 'replace' or 'createOrReplace'",
    patch: "PATCH operations that return 201 should start with 'create', 'update', or 'createOrUpdate'",
    delete: "DELETE operations should start with 'delete'"
  },
  create(context) {
    return {
      operation: (op) => {
        if (isTemplateDeclarationOrInstance3(op))
          return;
        const httpOp = ignoreDiagnostics10(getHttpOperation11(context.program, op));
        const verb = httpOp.verb;
        const name = op.name;
        const statusCodes = httpOp.responses.map((x) => x.statusCodes.toString());
        const isList = isListOperation(context.program, op) || getPagedResult(context.program, op) !== void 0;
        let errorMessage;
        switch (verb) {
          case "get":
            if (isList && !name.startsWith("list")) {
              errorMessage = "list";
            } else if (!isList && !name.startsWith("get")) {
              errorMessage = "get";
            }
            break;
          case "put":
            const is201 = statusCodes.includes("201");
            const is200 = statusCodes.includes("200");
            if (is201 && is200 && !name.startsWith("createOrReplace")) {
              errorMessage = "createOrReplace";
            } else if (is201 && !is200 && !["create", "createOrReplace"].some((x) => name.startsWith(x))) {
              errorMessage = "putCreate";
            } else if (is200 && !is201 && !["replace", "createOrReplace"].some((x) => name.startsWith(x))) {
              errorMessage = "putReplace";
            }
            break;
          case "patch":
            const allowed = ["create", "update", "createOrUpdate".toLocaleLowerCase()];
            if (statusCodes.includes("201") && !allowed.some((x) => name.startsWith(x))) {
              errorMessage = "patch";
            }
            break;
          case "delete":
            if (!name.startsWith("delete")) {
              errorMessage = "delete";
            }
            break;
        }
        if (errorMessage !== void 0) {
          context.reportDiagnostic({
            messageId: errorMessage,
            target: op
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/rules/use-standard-operations.js
import { createRule as createRule38, getNamespaceFullName as getNamespaceFullName6, isTemplateDeclarationOrInstance as isTemplateDeclarationOrInstance4, paramMessage as paramMessage23 } from "@typespec/compiler";
function derivesFromAzureCoreOperation(operation) {
  while (operation.sourceOperation) {
    if (operation.sourceOperation.namespace && getNamespaceFullName6(operation.sourceOperation.namespace) === "Azure.Core") {
      return true;
    }
    operation = operation.sourceOperation;
  }
  return false;
}
var useStandardOperations = createRule38({
  name: "use-standard-operations",
  description: "Operations should be defined using a signature from the Azure.Core namespace.",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-core/rules/use-standard-operations",
  messages: {
    default: paramMessage23`Operation '${"name"}' should be defined using a signature from the Azure.Core namespace.`
  },
  create(context) {
    return {
      operation: (operationContext) => {
        if (isTemplateDeclarationOrInstance4(operationContext)) {
          return;
        }
        if (operationContext.interface && operationContext.namespace && getNamespaceFullName6(operationContext.namespace) === "TypeSpec.Rest.Resource") {
          return;
        }
        if (!derivesFromAzureCoreOperation(operationContext)) {
          context.reportDiagnostic({
            // If the namespace where the operation's interface is defined is
            // different than the namespace we're in, mark the operation's
            // interface instead so that the diagnostic doesn't end up on a
            // library operation
            target: operationContext.interface && operationContext.interface.namespace !== operationContext.namespace ? operationContext.interface : operationContext,
            format: {
              name: operationContext.name
            }
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/linter.js
var rules = [
  apiVersionRule,
  authRequiredRule,
  bodyArrayRule,
  byosRule,
  casingRule,
  compositionOverInheritanceRule,
  knownEncodingRule,
  longRunningOperationsRequirePollingOperation,
  noClosedLiteralUnionRule,
  noEnumRule,
  noErrorStatusCodesRule,
  noExplicitRoutesResourceOps,
  nonBreakingVersioningRule,
  noGenericNumericRule,
  noNullableRule,
  noOffsetDateTimeRule,
  noResponseBodyRule,
  noRpcPathParamsRule,
  noOpenAPIRule,
  noHeaderExplodeRule,
  preventFormatRule,
  noMultipleDiscriminatorRule,
  preventRestLibraryInterfaces,
  preventUnknownType,
  badRecordTypeRule,
  requireDocumentation,
  requireKeyVisibility,
  responseSchemaMultiStatusCodeRule,
  rpcOperationRequestBodyRule,
  spreadDiscriminatedModelRule,
  useStandardNames,
  useStandardOperations,
  noStringDiscriminatorRule,
  requireVersionedRule,
  friendlyNameRule,
  noPrivateUsage,
  noLegacyUsage,
  noQueryExplodeRule
];
var $linter = defineLinter({
  rules,
  ruleSets: {
    "canonical-versioning": {
      enable: {
        [`@azure-tools/typespec-azure-core/${nonBreakingVersioningRule.name}`]: true
      }
    }
  }
});

// src/typespec/packages/typespec-azure-core/dist/src/traits.js
import { getTypeName as getTypeName8, setTypeSpecNamespace as setTypeSpecNamespace2 } from "@typespec/compiler";
import { isHeader as isHeader4, isQueryParam } from "@typespec/http";
var $traitSource = (context, target, traitName) => {
  context.program.stateMap(AzureCoreStateKeys.traitSource).set(target, traitName);
};
function getSourceTraitName(program, property) {
  return program.stateMap(AzureCoreStateKeys.traitSource).get(property);
}
setTypeSpecNamespace2("Traits.Private", $traitSource);
var $trait = (context, target, traitName) => {
  if (target.properties.size !== 1) {
    reportDiagnostic(context.program, {
      code: "invalid-trait-property-count",
      target,
      format: {
        modelName: target.name
      }
    });
    return;
  }
  traitName = traitName ?? getTypeName8(target, { namespaceFilter: (ns) => false });
  const [envelopeName] = target.properties.keys();
  const envelopeProperty = target.properties.get(envelopeName);
  if (envelopeProperty.type.kind !== "Model") {
    reportDiagnostic(context.program, {
      code: "invalid-trait-property-type",
      target,
      format: {
        modelName: target.name,
        propertyName: envelopeName
      }
    });
    return;
  }
  for (const [_, traitProperty] of envelopeProperty.type.properties) {
    if (!getTraitLocation(context.program, traitProperty)) {
      reportDiagnostic(context.program, {
        code: "trait-property-without-location",
        target,
        format: {
          modelName: target.name,
          propertyName: traitProperty.name
        }
      });
    }
  }
  context.call($traitSource, envelopeProperty, traitName);
  envelopeProperty.decorators.push({
    decorator: $traitSource,
    args: [{ value: context.program.checker.createLiteralType(traitName), jsValue: traitName }]
  });
  context.program.stateMap(AzureCoreStateKeys.trait).set(target, traitName);
};
setTypeSpecNamespace2("Traits", $trait);
function isTraitModel(program, model) {
  return program.stateMap(AzureCoreStateKeys.trait).has(model) !== void 0;
}
function getTraitName(program, model) {
  return program.stateMap(AzureCoreStateKeys.trait).get(model);
}
var $traitContext = (context, target, traitContext) => {
  context.program.stateMap(AzureCoreStateKeys.traitContext).set(target, normalizeTraitContexts(context.program, traitContext));
};
setTypeSpecNamespace2("Traits", $traitContext);
function normalizeTraitContexts(program, contexts) {
  if (contexts.kind === "EnumMember") {
    return [contexts];
  } else if (contexts.kind === "Union") {
    const members = [];
    for (const variant of contexts.variants.values()) {
      if (variant.type.kind === "EnumMember") {
        members.push(variant.type);
      } else {
        reportDiagnostic(program, {
          code: "invalid-trait-context",
          target: variant
        });
      }
    }
    return members;
  } else if (contexts.kind === "Intrinsic") {
    if (contexts.name !== "unknown") {
      reportDiagnostic(program, {
        code: "invalid-trait-context",
        target: contexts
      });
    }
  }
  return [];
}
function getTraitContextsOrUndefined(program, property) {
  return program.stateMap(AzureCoreStateKeys.traitContext).get(property);
}
function getTraitContexts(program, property) {
  return program.stateMap(AzureCoreStateKeys.traitContext).get(property) || [];
}
var $traitLocation = (context, target, traitLocation) => {
  context.program.stateMap(AzureCoreStateKeys.traitLocation).set(target, traitLocation);
};
setTypeSpecNamespace2("Traits", $traitLocation);
function getTraitLocation(program, property) {
  return program.stateMap(AzureCoreStateKeys.traitLocation).get(property);
}
var traitAddedKey = Symbol("traitLocation");
var $traitAdded = (context, target, addedVersion) => {
  if (addedVersion.kind !== "EnumMember") {
    return;
  }
  if (target.kind === "Model") {
    if (target.properties.size !== 1) {
      return;
    }
    const envelopeProperty = target.properties.values().next().value;
    context.call($traitAdded, envelopeProperty, addedVersion);
    envelopeProperty.decorators.push({
      decorator: $traitAdded,
      args: [{ value: addedVersion, jsValue: addedVersion }]
    });
  }
  context.program.stateMap(traitAddedKey).set(target, addedVersion);
};
function getTraitAddedVersion(program, envelopeProperty) {
  return program.stateMap(traitAddedKey).get(envelopeProperty);
}
setTypeSpecNamespace2("Traits", $traitAdded);
var $addTraitProperties = (context, target, traitModel, traitLocation, traitContexts) => {
  const appliedTraits = /* @__PURE__ */ new Set();
  const { program } = context;
  for (const [_, traitEnvelope] of traitModel.properties) {
    const addedVersion = getTraitAddedVersion(context.program, traitEnvelope);
    const traitName = getSourceTraitName(program, traitEnvelope);
    if (traitName && !appliedTraits.has(traitName)) {
      const contexts = getTraitContexts(context.program, traitEnvelope);
      if (traitEnvelope.type.kind !== "Model") {
        return;
      }
      for (const [_2, traitProperty] of traitEnvelope.type.properties) {
        const contextsOverride = getTraitContextsOrUndefined(context.program, traitProperty);
        if (checkTraitPropertyCriteria(program, traitProperty, contextsOverride ?? contexts, traitLocation, normalizeTraitContexts(program, traitContexts))) {
          if (traitProperty.type.kind !== "Model") {
            return;
          }
          for (const [name, property] of traitProperty.type.properties) {
            target.properties.set(name, context.program.checker.cloneType(property, {
              sourceProperty: property,
              model: target,
              decorators: [
                ...property.decorators,
                ...addedVersion ? [
                  {
                    decorator: $added,
                    args: [{ value: addedVersion, jsValue: addedVersion }]
                  }
                ] : []
              ]
            }));
            appliedTraits.add(traitName);
          }
        }
      }
    }
  }
};
function checkTraitPropertyCriteria(program, property, traitContexts, expectedLocation, expectedContexts) {
  const location = getTraitLocation(program, property);
  if (!location) {
    return false;
  }
  return location === expectedLocation && (traitContexts.length === 0 || !!traitContexts.find((c) => expectedContexts.indexOf(c) > -1));
}
setTypeSpecNamespace2("Traits.Private", $addTraitProperties);
var traitOverrideCounter = 1;
var $applyTraitOverride = (context, target, traitModel) => {
  if (traitModel.properties.size !== 1) {
    return;
  }
  if (target.properties.size > 0) {
    return;
  }
  traitOverrideCounter++;
  const [envelopeName] = traitModel.properties.keys();
  const overrideName = `${envelopeName}Override${traitOverrideCounter}`;
  const envelopeProperty = traitModel.properties.get(envelopeName);
  target.properties.set(overrideName, context.program.checker.cloneType(envelopeProperty, {
    name: overrideName,
    model: target,
    sourceProperty: envelopeProperty
  }));
};
setTypeSpecNamespace2("Traits.Private", $applyTraitOverride);
var $ensureTraitsPresent = (context, target, traitModel, expectedTraits) => {
  if (expectedTraits.kind !== "Tuple") {
    return;
  }
  const traitsPresent = /* @__PURE__ */ new Set();
  for (const [_, envelopeProperty] of traitModel.properties) {
    const traitName = getSourceTraitName(context.program, envelopeProperty);
    if (traitName) {
      traitsPresent.add(traitName);
    }
  }
  function getPropertyString(model, propertyName) {
    const val = model.properties.get(propertyName);
    return val && val.type.kind === "String" ? val.type.value : void 0;
  }
  for (const expected of expectedTraits.values) {
    if (expected.kind === "Model") {
      const trait = getPropertyString(expected, "trait");
      if (trait && !traitsPresent.has(trait)) {
        const diagnosticName = getPropertyString(expected, "diagnostic");
        if (!diagnosticName) {
          reportDiagnostic(context.program, {
            code: "expected-trait-diagnostic-missing",
            target: expected
          });
        } else {
          reportDiagnostic(context.program, {
            code: diagnosticName,
            target
          });
        }
      }
    }
  }
};
setTypeSpecNamespace2("Traits.Private", $ensureTraitsPresent);
var $ensureAllQueryParams = (context, target, paramModel) => {
  for (const [_, param] of paramModel.properties) {
    if (!isQueryParam(context.program, param)) {
      reportDiagnostic(context.program, {
        code: "invalid-parameter",
        target,
        format: {
          propertyName: param.name,
          kind: "query"
        }
      });
    }
  }
};
setTypeSpecNamespace2("Traits.Private", $ensureAllQueryParams);
var $ensureAllHeaderParams = (context, target, paramModel) => {
  for (const [_, param] of paramModel.properties) {
    if (!isHeader4(context.program, param)) {
      reportDiagnostic(context.program, {
        code: "invalid-parameter",
        target,
        format: {
          propertyName: param.name,
          kind: "header"
        }
      });
    }
  }
};
setTypeSpecNamespace2("Traits.Private", $ensureAllHeaderParams);

// src/typespec/packages/typespec-azure-core/dist/src/tsp-index.js
var tsp_index_exports = {};
__export(tsp_index_exports, {
  $decorators: () => $decorators2,
  $lib: () => $lib,
  $onValidate: () => $onValidate
});

// src/typespec/packages/typespec-azure-core/dist/src/validate.js
function $onValidate(program) {
  checkRpcRoutes(program);
  checkEnsureVerb(program);
}

// src/typespec/packages/typespec-azure-core/dist/src/tsp-index.js
var $decorators2 = {
  "Azure.Core": {
    lroStatus: $lroStatus,
    finalLocation: $finalLocation,
    pollingLocation: $pollingLocation,
    pagedResult: $pagedResult,
    items: $items,
    fixed: $fixed,
    lroSucceeded: $lroSucceeded,
    lroCanceled: $lroCanceled,
    lroFailed: $lroFailed,
    lroResult: $lroResult,
    lroErrorResult: $lroErrorResult,
    operationLink: $operationLink,
    pollingOperationParameter: $pollingOperationParameter,
    pollingOperation: $pollingOperation,
    finalOperation: $finalOperation,
    useFinalStateVia: $useFinalStateVia,
    nextPageOperation: $nextPageOperation
  },
  "Azure.Core.Foundations": {
    omitKeyProperties: $omitKeyProperties,
    requestParameter: $requestParameter,
    responseProperty: $responseProperty
  },
  "Azure.Core.Foundations.Private": {
    spreadCustomParameters: $spreadCustomParameters,
    spreadCustomResponseProperties: $spreadCustomResponseProperties,
    ensureResourceType: $ensureResourceType,
    embeddingVector: $embeddingVector,
    armResourceIdentifierConfig: $armResourceIdentifierConfig,
    needsRoute: $needsRoute,
    ensureVerb: $ensureVerb,
    defaultFinalStateVia: $defaultFinalStateVia,
    parameterizedNextLinkConfig: parameterizedNextLinkConfigDecorator
  },
  "Azure.Core.Traits": {
    trait: $trait,
    traitAdded: $traitAdded,
    traitContext: $traitContext,
    traitLocation: $traitLocation
  },
  "Azure.Core.Traits.Private": {
    applyTraitOverride: $applyTraitOverride,
    ensureAllQueryParams: $ensureAllQueryParams,
    ensureAllHeaderParams: $ensureAllHeaderParams,
    addTraitProperties: $addTraitProperties,
    traitSource: $traitSource,
    ensureTraitsPresent: $ensureTraitsPresent
  }
};

// src/typespec/packages/typespec-azure-core/dist/src/index.js
var namespace = "Azure.Core";

// virtual:virtual:entry.js
var TypeSpecJSSources = {
  "dist/src/index.js": src_exports,
  "dist/src/tsp-index.js": tsp_index_exports
};
var TypeSpecSources = {
  "package.json": '{"name":"@azure-tools/typespec-azure-core","version":"0.56.0","author":"Microsoft Corporation","description":"TypeSpec Azure Core library","homepage":"https://azure.github.io/typespec-azure","docusaurusWebsite":"https://azure.github.io/typespec-azure/docs","readme":"https://github.com/Azure/typespec-azure/blob/main/packages/typespec-azure-core/README.md","license":"MIT","repository":{"type":"git","url":"git+https://github.com/Azure/typespec-azure.git"},"bugs":{"url":"https://github.com/Azure/typespec-azure/issues"},"keywords":["typespec"],"main":"dist/src/index.js","tspMain":"lib/azure-core.tsp","exports":{".":{"typespec":"./lib/azure-core.tsp","types":"./dist/src/index.d.ts","default":"./dist/src/index.js"},"./testing":{"types":"./dist/src/testing/index.d.ts","default":"./dist/src/testing/index.js"}},"type":"module","engines":{"node":">=20.0.0"},"scripts":{"clean":"rimraf ./dist ./temp","build":"npm run gen-extern-signature && tsc -p . && npm run lint-typespec-library","watch":"tsc -p . --watch","gen-extern-signature":"tspd --enable-experimental gen-extern-signature .","lint-typespec-library":"tsp compile . --warn-as-error --import @typespec/library-linter --no-emit","test":"vitest run","test:watch":"vitest -w","test:ui":"vitest --ui","test:ci":"vitest run --coverage  --reporter=junit --reporter=default","lint":"eslint .  --max-warnings=0","lint:fix":"eslint . --fix ","regen-docs":"tspd doc .  --enable-experimental  --output-dir ../../website/src/content/docs/docs/libraries/azure-core/reference"},"files":["lib/*.tsp","dist/**","!dist/test/**"],"peerDependencies":{"@typespec/compiler":"workspace:^","@typespec/http":"workspace:^","@typespec/rest":"workspace:^"},"devDependencies":{"@types/node":"~22.13.11","@typespec/compiler":"workspace:^","@typespec/http":"workspace:^","@typespec/library-linter":"workspace:^","@typespec/openapi":"workspace:^","@typespec/rest":"workspace:^","@typespec/tspd":"workspace:^","@typespec/versioning":"workspace:^","@vitest/coverage-v8":"^3.1.2","@vitest/ui":"^3.1.2","c8":"^10.1.3","rimraf":"~6.0.1","typescript":"~5.8.2","vitest":"^3.1.2"}}',
  "../../core/packages/compiler/lib/intrinsics.tsp": 'import "../dist/src/lib/intrinsic/tsp-index.js";\nimport "./prototypes.tsp";\n\n// This file contains all the intrinsic types of typespec. Everything here will always be loaded\nnamespace TypeSpec;\n\n/**\n * Represent a byte array\n */\nscalar bytes;\n\n/**\n * A numeric type\n */\nscalar numeric;\n\n/**\n * A whole number. This represent any `integer` value possible.\n * It is commonly represented as `BigInteger` in some languages.\n */\nscalar integer extends numeric;\n\n/**\n * A number with decimal value\n */\nscalar float extends numeric;\n\n/**\n * A 64-bit integer. (`-9,223,372,036,854,775,808` to `9,223,372,036,854,775,807`)\n */\nscalar int64 extends integer;\n\n/**\n * A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)\n */\nscalar int32 extends int64;\n\n/**\n * A 16-bit integer. (`-32,768` to `32,767`)\n */\nscalar int16 extends int32;\n\n/**\n * A 8-bit integer. (`-128` to `127`)\n */\nscalar int8 extends int16;\n\n/**\n * A 64-bit unsigned integer (`0` to `18,446,744,073,709,551,615`)\n */\nscalar uint64 extends integer;\n\n/**\n * A 32-bit unsigned integer (`0` to `4,294,967,295`)\n */\nscalar uint32 extends uint64;\n\n/**\n * A 16-bit unsigned integer (`0` to `65,535`)\n */\nscalar uint16 extends uint32;\n\n/**\n * A 8-bit unsigned integer (`0` to `255`)\n */\nscalar uint8 extends uint16;\n\n/**\n * An integer that can be serialized to JSON (`\u22129007199254740991 (\u2212(2^53 \u2212 1))` to `9007199254740991 (2^53 \u2212 1)` )\n */\nscalar safeint extends int64;\n\n/**\n * A 64 bit floating point number. (`\xB15.0 \xD7 10^\u2212324` to `\xB11.7 \xD7 10^308`)\n */\nscalar float64 extends float;\n\n/**\n * A 32 bit floating point number. (`\xB11.5 x 10^\u221245` to `\xB13.4 x 10^38`)\n */\nscalar float32 extends float64;\n\n/**\n * A decimal number with any length and precision. This represent any `decimal` value possible.\n * It is commonly represented as `BigDecimal` in some languages.\n */\nscalar decimal extends numeric;\n\n/**\n * A 128-bit decimal number.\n */\nscalar decimal128 extends decimal;\n\n/**\n * A sequence of textual characters.\n */\nscalar string;\n\n/**\n * A date on a calendar without a time zone, e.g. "April 10th"\n */\nscalar plainDate {\n  /**\n   * Create a plain date from an ISO 8601 string.\n   * @example\n   *\n   * ```tsp\n   * const time = plainTime.fromISO("2024-05-06");\n   * ```\n   */\n  init fromISO(value: string);\n}\n\n/**\n * A time on a clock without a time zone, e.g. "3:00 am"\n */\nscalar plainTime {\n  /**\n   * Create a plain time from an ISO 8601 string.\n   * @example\n   *\n   * ```tsp\n   * const time = plainTime.fromISO("12:34");\n   * ```\n   */\n  init fromISO(value: string);\n}\n\n/**\n * An instant in coordinated universal time (UTC)"\n */\nscalar utcDateTime {\n  /**\n   * Create a date from an ISO 8601 string.\n   * @example\n   *\n   * ```tsp\n   * const time = utcDateTime.fromISO("2024-05-06T12:20-12Z");\n   * ```\n   */\n  init fromISO(value: string);\n}\n\n/**\n * A date and time in a particular time zone, e.g. "April 10th at 3:00am in PST"\n */\nscalar offsetDateTime {\n  /**\n   * Create a date from an ISO 8601 string.\n   * @example\n   *\n   * ```tsp\n   * const time = offsetDateTime.fromISO("2024-05-06T12:20-12-0700");\n   * ```\n   */\n  init fromISO(value: string);\n}\n\n/**\n * A duration/time period. e.g 5s, 10h\n */\nscalar duration {\n  /**\n   * Create a duration from an ISO 8601 string.\n   * @example\n   *\n   * ```tsp\n   * const time = duration.fromISO("P1Y1D");\n   * ```\n   */\n  init fromISO(value: string);\n}\n\n/**\n * Boolean with `true` and `false` values.\n */\nscalar boolean;\n\n/**\n * @dev Array model type, equivalent to `Element[]`\n * @template Element The type of the array elements\n */\n@indexer(integer, Element)\nmodel Array<Element> {}\n\n/**\n * @dev Model with string properties where all the properties have type `Property`\n * @template Element The type of the properties\n */\n@indexer(string, Element)\nmodel Record<Element> {}\n',
  "../../core/packages/compiler/lib/prototypes.tsp": "namespace TypeSpec.Prototypes;\n\nextern dec getter(target: unknown);\n\nnamespace Types {\n  interface ModelProperty {\n    @getter type(): unknown;\n  }\n\n  interface Operation {\n    @getter returnType(): unknown;\n    @getter parameters(): unknown;\n  }\n\n  interface Array<TElementType> {\n    @getter elementType(): TElementType;\n  }\n}\n",
  "../../core/packages/compiler/lib/std/main.tsp": '// TypeSpec standard library. Everything in here can be omitted by using `--nostdlib` cli flag or `nostdlib` in the config.\nimport "./types.tsp";\nimport "./decorators.tsp";\nimport "./reflection.tsp";\nimport "./visibility.tsp";\n',
  "../../core/packages/compiler/lib/std/types.tsp": 'namespace TypeSpec;\n\n/**\n * Represent a 32-bit unix timestamp datetime with 1s of granularity.\n * It measures time by the number of seconds that have elapsed since 00:00:00 UTC on 1 January 1970.\n */\n@encode("unixTimestamp", int32)\nscalar unixTimestamp32 extends utcDateTime;\n\n/**\n * Represent a URL string as described by https://url.spec.whatwg.org/\n */\nscalar url extends string;\n\n/**\n * Represents a collection of optional properties.\n *\n * @template Source An object whose spread properties are all optional.\n */\n@doc("The template for adding optional properties.")\n@withOptionalProperties\nmodel OptionalProperties<Source> {\n  ...Source;\n}\n\n/**\n * Represents a collection of updateable properties.\n *\n * @template Source An object whose spread properties are all updateable.\n */\n@doc("The template for adding updateable properties.")\n@withUpdateableProperties\nmodel UpdateableProperties<Source> {\n  ...Source;\n}\n\n/**\n * Represents a collection of omitted properties.\n *\n * @template Source An object whose properties are spread.\n * @template Keys The property keys to omit.\n */\n@doc("The template for omitting properties.")\n@withoutOmittedProperties(Keys)\nmodel OmitProperties<Source, Keys extends string> {\n  ...Source;\n}\n\n/**\n * Represents a collection of properties with only the specified keys included.\n *\n * @template Source An object whose properties are spread.\n * @template Keys The property keys to include.\n */\n@doc("The template for picking properties.")\n@withPickedProperties(Keys)\nmodel PickProperties<Source, Keys extends string> {\n  ...Source;\n}\n\n/**\n * Represents a collection of properties with default values omitted.\n *\n * @template Source An object whose spread property defaults are all omitted.\n */\n@withoutDefaultValues\nmodel OmitDefaults<Source> {\n  ...Source;\n}\n\n/**\n * Applies a visibility setting to a collection of properties.\n *\n * @template Source An object whose properties are spread.\n * @template Visibility The visibility to apply to all properties.\n */\n@doc("The template for setting the default visibility of key properties.")\n@withDefaultKeyVisibility(Visibility)\nmodel DefaultKeyVisibility<Source, Visibility extends valueof Reflection.EnumMember> {\n  ...Source;\n}\n',
  "../../core/packages/compiler/lib/std/decorators.tsp": 'import "../../dist/src/lib/tsp-index.js";\n\nusing TypeSpec.Reflection;\n\nnamespace TypeSpec;\n\n/**\n * Typically a short, single-line description.\n * @param summary Summary string.\n *\n * @example\n * ```typespec\n * @summary("This is a pet")\n * model Pet {}\n * ```\n */\nextern dec summary(target: unknown, summary: valueof string);\n\n/**\n * Attach a documentation string. Content support CommonMark markdown formatting.\n * @param doc Documentation string\n * @param formatArgs Record with key value pair that can be interpolated in the doc.\n *\n * @example\n * ```typespec\n * @doc("Represent a Pet available in the PetStore")\n * model Pet {}\n * ```\n */\nextern dec doc(target: unknown, doc: valueof string, formatArgs?: {});\n\n/**\n * Attach a documentation string to describe the successful return types of an operation.\n * If an operation returns a union of success and errors it only describes the success. See `@errorsDoc` for error documentation.\n * @param doc Documentation string\n *\n * @example\n * ```typespec\n * @returnsDoc("Returns doc")\n * op get(): Pet | NotFound;\n * ```\n */\nextern dec returnsDoc(target: Operation, doc: valueof string);\n\n/**\n * Attach a documentation string to describe the error return types of an operation.\n * If an operation returns a union of success and errors it only describes the errors. See `@returnsDoc` for success documentation.\n * @param doc Documentation string\n *\n * @example\n * ```typespec\n * @errorsDoc("Errors doc")\n * op get(): Pet | NotFound;\n * ```\n */\nextern dec errorsDoc(target: Operation, doc: valueof string);\n\n/**\n * Service options.\n */\nmodel ServiceOptions {\n  /**\n   * Title of the service.\n   */\n  title?: string;\n}\n\n/**\n * Mark this namespace as describing a service and configure service properties.\n * @param options Optional configuration for the service.\n *\n * @example\n * ```typespec\n * @service\n * namespace PetStore;\n * ```\n *\n * @example Setting service title\n * ```typespec\n * @service(#{title: "Pet store"})\n * namespace PetStore;\n * ```\n *\n * @example Setting service version\n * ```typespec\n * @service(#{version: "1.0"})\n * namespace PetStore;\n * ```\n */\nextern dec service(target: Namespace, options?: valueof ServiceOptions);\n\n/**\n * Specify that this model is an error type. Operations return error types when the operation has failed.\n *\n * @example\n * ```typespec\n * @error\n * model PetStoreError {\n *   code: string;\n *   message: string;\n * }\n * ```\n */\nextern dec error(target: Model);\n\n/**\n * Applies a media type hint to a TypeSpec type. Emitters and libraries may choose to use this hint to determine how a\n * type should be serialized. For example, the `@typespec/http` library will use the media type hint of the response\n * body type as a default `Content-Type` if one is not explicitly specified in the operation.\n *\n * Media types (also known as MIME types) are defined by RFC 6838. The media type hint should be a valid media type\n * string as defined by the RFC, but the decorator does not enforce or validate this constraint.\n *\n * Notes: the applied media type is _only_ a hint. It may be overridden or not used at all. Media type hints are\n * inherited by subtypes. If a media type hint is applied to a model, it will be inherited by all other models that\n * `extend` it unless they delcare their own media type hint.\n *\n * @param mediaType The media type hint to apply to the target type.\n *\n * @example create a model that serializes as XML by default\n *\n * ```tsp\n * @mediaTypeHint("application/xml")\n * model Example {\n *   @visibility(Lifecycle.Read)\n *   id: string;\n *\n *   name: string;\n * }\n * ```\n */\nextern dec mediaTypeHint(target: Model | Scalar | Enum | Union, mediaType: valueof string);\n\n// Cannot apply this to the scalar itself. Needs to be applied here so that we don\'t crash nostdlib scenarios\n@@mediaTypeHint(TypeSpec.bytes, "application/octet-stream");\n\n// @@mediaTypeHint(TypeSpec.string "text/plain") -- This is hardcoded in the compiler to avoid circularity\n// between the initialization of the string scalar and the `valueof string` required to call the\n// `mediaTypeHint` decorator.\n\n/**\n * Specify a known data format hint for this string type. For example `uuid`, `uri`, etc.\n * This differs from the `@pattern` decorator which is meant to specify a regular expression while `@format` accepts a known format name.\n * The format names are open ended and are left to emitter to interpret.\n *\n * @param format format name.\n *\n * @example\n * ```typespec\n * @format("uuid")\n * scalar uuid extends string;\n * ```\n */\nextern dec format(target: string | ModelProperty, format: valueof string);\n\n/**\n * Specify the the pattern this string should respect using simple regular expression syntax.\n * The following syntax is allowed: alternations (`|`), quantifiers (`?`, `*`, `+`, and `{ }`), wildcard (`.`), and grouping parentheses.\n * Advanced features like look-around, capture groups, and references are not supported.\n *\n * This decorator may optionally provide a custom validation _message_. Emitters may choose to use the message to provide\n * context when pattern validation fails. For the sake of consistency, the message should be a phrase that describes in\n * plain language what sort of content the pattern attempts to validate. For example, a complex regular expression that\n * validates a GUID string might have a message like "Must be a valid GUID."\n *\n * @param pattern Regular expression.\n * @param validationMessage Optional validation message that may provide context when validation fails.\n *\n * @example\n * ```typespec\n * @pattern("[a-z]+", "Must be a string consisting of only lower case letters and of at least one character.")\n * scalar LowerAlpha extends string;\n * ```\n */\nextern dec pattern(\n  target: string | bytes | ModelProperty,\n  pattern: valueof string,\n  validationMessage?: valueof string\n);\n\n/**\n * Specify the minimum length this string type should be.\n * @param value Minimum length\n *\n * @example\n * ```typespec\n * @minLength(2)\n * scalar Username extends string;\n * ```\n */\nextern dec minLength(target: string | ModelProperty, value: valueof integer);\n\n/**\n * Specify the maximum length this string type should be.\n * @param value Maximum length\n *\n * @example\n * ```typespec\n * @maxLength(20)\n * scalar Username extends string;\n * ```\n */\nextern dec maxLength(target: string | ModelProperty, value: valueof integer);\n\n/**\n * Specify the minimum number of items this array should have.\n * @param value Minimum number\n *\n * @example\n * ```typespec\n * @minItems(1)\n * model Endpoints is string[];\n * ```\n */\nextern dec minItems(target: unknown[] | ModelProperty, value: valueof integer);\n\n/**\n * Specify the maximum number of items this array should have.\n * @param value Maximum number\n *\n * @example\n * ```typespec\n * @maxItems(5)\n * model Endpoints is string[];\n * ```\n */\nextern dec maxItems(target: unknown[] | ModelProperty, value: valueof integer);\n\n/**\n * Specify the minimum value this numeric type should be.\n * @param value Minimum value\n *\n * @example\n * ```typespec\n * @minValue(18)\n * scalar Age is int32;\n * ```\n */\nextern dec minValue(target: numeric | ModelProperty, value: valueof numeric);\n\n/**\n * Specify the maximum value this numeric type should be.\n * @param value Maximum value\n *\n * @example\n * ```typespec\n * @maxValue(200)\n * scalar Age is int32;\n * ```\n */\nextern dec maxValue(target: numeric | ModelProperty, value: valueof numeric);\n\n/**\n * Specify the minimum value this numeric type should be, exclusive of the given\n * value.\n * @param value Minimum value\n *\n * @example\n * ```typespec\n * @minValueExclusive(0)\n * scalar distance is float64;\n * ```\n */\nextern dec minValueExclusive(target: numeric | ModelProperty, value: valueof numeric);\n\n/**\n * Specify the maximum value this numeric type should be, exclusive of the given\n * value.\n * @param value Maximum value\n *\n * @example\n * ```typespec\n * @maxValueExclusive(50)\n * scalar distance is float64;\n * ```\n */\nextern dec maxValueExclusive(target: numeric | ModelProperty, value: valueof numeric);\n\n/**\n * Mark this string as a secret value that should be treated carefully to avoid exposure\n *\n * @example\n * ```typespec\n * @secret\n * scalar Password is string;\n * ```\n */\nextern dec secret(target: string | ModelProperty);\n\n/**\n * Attaches a tag to an operation, interface, or namespace. Multiple `@tag` decorators can be specified to attach multiple tags to a TypeSpec element.\n * @param tag Tag value\n */\nextern dec tag(target: Namespace | Interface | Operation, tag: valueof string);\n\n/**\n * Specifies how a templated type should name their instances.\n * @param name name the template instance should take\n * @param formatArgs Model with key value used to interpolate the name\n *\n * @example\n * ```typespec\n * @friendlyName("{name}List", T)\n * model List<Item> {\n *   value: Item[];\n *   nextLink: string;\n * }\n * ```\n */\nextern dec friendlyName(target: unknown, name: valueof string, formatArgs?: unknown);\n\n/**\n * Mark a model property as the key to identify instances of that type\n * @param altName Name of the property. If not specified, the decorated property name is used.\n *\n * @example\n * ```typespec\n * model Pet {\n *   @key id: string;\n * }\n * ```\n */\nextern dec key(target: ModelProperty, altName?: valueof string);\n\n/**\n * Specify this operation is an overload of the given operation.\n * @param overloadbase Base operation that should be a union of all overloads\n *\n * @example\n * ```typespec\n * op upload(data: string | bytes, @header contentType: "text/plain" | "application/octet-stream"): void;\n * @overload(upload)\n * op uploadString(data: string, @header contentType: "text/plain" ): void;\n * @overload(upload)\n * op uploadBytes(data: bytes, @header contentType: "application/octet-stream"): void;\n * ```\n */\nextern dec overload(target: Operation, overloadbase: Operation);\n\n/**\n * Provide an alternative name for this type when serialized to the given mime type.\n * @param mimeType Mime type this should apply to. The mime type should be a known mime type as described here https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types without any suffix (e.g. `+json`)\n * @param name Alternative name\n *\n * @example\n *\n * ```typespec\n * model Certificate {\n *   @encodedName("application/json", "exp")\n *   @encodedName("application/xml", "expiry")\n *   expireAt: int32;\n * }\n * ```\n *\n * @example Invalid values\n *\n * ```typespec\n * @encodedName("application/merge-patch+json", "exp")\n *              ^ error cannot use subtype\n * ```\n */\nextern dec encodedName(target: unknown, mimeType: valueof string, name: valueof string);\n\n/**\n * Options for `@discriminated` decorator.\n */\nmodel DiscriminatedOptions {\n  /**\n   * How is the discriminated union serialized.\n   * @default object\n   */\n  envelope?: "object" | "none";\n\n  /** Name of the discriminator property */\n  discriminatorPropertyName?: string;\n\n  /** Name of the property envelopping the data */\n  envelopePropertyName?: string;\n}\n\n/**\n * Specify that this union is discriminated.\n * @param options Options to configure the serialization of the discriminated union.\n *\n * @example\n *\n * ```typespec\n * @discriminated\n * union Pet{ cat: Cat, dog: Dog }\n *\n * model Cat { name: string, meow: boolean }\n * model Dog { name: string, bark: boolean }\n * ```\n * Serialized as:\n * ```json\n * {\n *   "kind": "cat",\n *   "value": {\n *     "name": "Whiskers",\n *     "meow": true\n *   }\n * },\n * {\n *   "kind": "dog",\n *   "value": {\n *     "name": "Rex",\n *     "bark": false\n *   }\n * }\n * ```\n *\n * @example Custom property names\n *\n * ```typespec\n * @discriminated(#{discriminatorPropertyName: "dataKind", envelopePropertyName: "data"})\n * union Pet{ cat: Cat, dog: Dog }\n *\n * model Cat { name: string, meow: boolean }\n * model Dog { name: string, bark: boolean }\n * ```\n * Serialized as:\n * ```json\n * {\n *   "dataKind": "cat",\n *   "data": {\n *     "name": "Whiskers",\n *     "meow": true\n *   }\n * },\n * {\n *   "dataKind": "dog",\n *   "data": {\n *     "name": "Rex",\n *     "bark": false\n *   }\n * }\n * ```\n */\nextern dec discriminated(target: Union, options?: valueof DiscriminatedOptions);\n\n/**\n * Specify the property to be used to discriminate this type.\n * @param propertyName The property name to use for discrimination\n *\n * @example\n *\n * ```typespec\n * @discriminator("kind")\n * model Pet{ kind: string }\n *\n * model Cat extends Pet {kind: "cat", meow: boolean}\n * model Dog extends Pet  {kind: "dog", bark: boolean}\n * ```\n */\nextern dec discriminator(target: Model, propertyName: valueof string);\n\n/**\n * Known encoding to use on utcDateTime or offsetDateTime\n */\nenum DateTimeKnownEncoding {\n  /**\n   * RFC 3339 standard. https://www.ietf.org/rfc/rfc3339.txt\n   * Encode to string.\n   */\n  rfc3339: "rfc3339",\n\n  /**\n   * RFC 7231 standard. https://www.ietf.org/rfc/rfc7231.txt\n   * Encode to string.\n   */\n  rfc7231: "rfc7231",\n\n  /**\n   * Encode a datetime to a unix timestamp.\n   * Unix timestamps are represented as an integer number of seconds since the Unix epoch and usually encoded as an int32.\n   */\n  unixTimestamp: "unixTimestamp",\n}\n\n/**\n * Known encoding to use on duration\n */\nenum DurationKnownEncoding {\n  /**\n   * ISO8601 duration\n   */\n  ISO8601: "ISO8601",\n\n  /**\n   * Encode to integer or float\n   */\n  seconds: "seconds",\n}\n\n/**\n * Known encoding to use on bytes\n */\nenum BytesKnownEncoding {\n  /**\n   * Encode to Base64\n   */\n  base64: "base64",\n\n  /**\n   * Encode to Base64 Url\n   */\n  base64url: "base64url",\n}\n\n/**\n * Encoding for serializing arrays\n */\nenum ArrayEncoding {\n  /** Each values of the array is separated by a | */\n  pipeDelimited,\n\n  /** Each values of the array is separated by a <space> */\n  spaceDelimited,\n}\n\n/**\n * Specify how to encode the target type.\n * @param encodingOrEncodeAs Known name of an encoding or a scalar type to encode as(Only for numeric types to encode as string).\n * @param encodedAs What target type is this being encoded as. Default to string.\n *\n * @example offsetDateTime encoded with rfc7231\n *\n * ```tsp\n * @encode("rfc7231")\n * scalar myDateTime extends offsetDateTime;\n * ```\n *\n * @example utcDateTime encoded with unixTimestamp\n *\n * ```tsp\n * @encode("unixTimestamp", int32)\n * scalar myDateTime extends unixTimestamp;\n * ```\n *\n * @example encode numeric type to string\n *\n * ```tsp\n * model Pet {\n *   @encode(string) id: int64;\n * }\n * ```\n */\nextern dec encode(\n  target: Scalar | ModelProperty,\n  encodingOrEncodeAs: (valueof string | EnumMember) | Scalar,\n  encodedAs?: Scalar\n);\n\n/** Options for example decorators */\nmodel ExampleOptions {\n  /** The title of the example */\n  title?: string;\n\n  /** Description of the example */\n  description?: string;\n}\n\n/**\n * Provide an example value for a data type.\n *\n * @param example Example value.\n * @param options Optional metadata for the example.\n *\n * @example\n *\n * ```tsp\n * @example(#{name: "Fluffy", age: 2})\n * model Pet {\n *  name: string;\n *  age: int32;\n * }\n * ```\n */\nextern dec example(\n  target: Model | Enum | Scalar | Union | ModelProperty | UnionVariant,\n  example: valueof unknown,\n  options?: valueof ExampleOptions\n);\n\n/**\n * Operation example configuration.\n */\nmodel OperationExample {\n  /** Example request body. */\n  parameters?: unknown;\n\n  /** Example response body. */\n  returnType?: unknown;\n}\n\n/**\n * Provide example values for an operation\'s parameters and corresponding return type.\n *\n * @param example Example value.\n * @param options Optional metadata for the example.\n *\n * @example\n *\n * ```tsp\n * @opExample(#{parameters: #{name: "Fluffy", age: 2}, returnType: #{name: "Fluffy", age: 2, id: "abc"})\n * op createPet(pet: Pet): Pet;\n * ```\n */\nextern dec opExample(\n  target: Operation,\n  example: valueof OperationExample,\n  options?: valueof ExampleOptions\n);\n\n/**\n * Returns the model with required properties removed.\n */\nextern dec withOptionalProperties(target: Model);\n\n/**\n * Returns the model with any default values removed.\n */\nextern dec withoutDefaultValues(target: Model);\n\n/**\n * Returns the model with the given properties omitted.\n * @param omit List of properties to omit\n */\nextern dec withoutOmittedProperties(target: Model, omit: string | Union);\n\n/**\n * Returns the model with only the given properties included.\n * @param pick List of properties to include\n */\nextern dec withPickedProperties(target: Model, pick: string | Union);\n\n//---------------------------------------------------------------------------\n// Paging\n//---------------------------------------------------------------------------\n\n/**\n * Mark this operation as a `list` operation that returns a paginated list of items.\n */\nextern dec list(target: Operation);\n\n/**\n * Pagination property defining the number of items to skip.\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n * }\n * @list op listPets(@offset skip: int32, @pageSize pageSize: int8): Page<Pet>;\n * ```\n */\nextern dec offset(target: ModelProperty);\n\n/**\n * Pagination property defining the page index.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n * }\n * @list op listPets(@pageIndex page: int32, @pageSize pageSize: int8): Page<Pet>;\n * ```\n */\nextern dec pageIndex(target: ModelProperty);\n\n/**\n * Specify the pagination parameter that controls the maximum number of items to include in a page.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n * }\n * @list op listPets(@pageIndex page: int32, @pageSize pageSize: int8): Page<Pet>;\n * ```\n */\nextern dec pageSize(target: ModelProperty);\n\n/**\n * Specify the the property that contains the array of page items.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n * }\n * @list op listPets(@pageIndex page: int32, @pageSize pageSize: int8): Page<Pet>;\n * ```\n */\nextern dec pageItems(target: ModelProperty);\n\n/**\n * Pagination property defining the token to get to the next page.\n * It MUST be specified both on the request parameter and the response.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n *   @continuationToken continuationToken: string;\n * }\n * @list op listPets(@continuationToken continuationToken: string): Page<Pet>;\n * ```\n */\nextern dec continuationToken(target: ModelProperty);\n\n/**\n * Pagination property defining a link to the next page.\n *\n * It is expected that navigating to the link will return the same set of responses as the operation that returned the current page.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n *   @nextLink next: url;\n *   @prevLink prev: url;\n *   @firstLink first: url;\n *   @lastLink last: url;\n * }\n * @list op listPets(): Page<Pet>;\n * ```\n */\nextern dec nextLink(target: ModelProperty);\n\n/**\n * Pagination property defining a link to the previous page.\n *\n * It is expected that navigating to the link will return the same set of responses as the operation that returned the current page.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n *   @nextLink next: url;\n *   @prevLink prev: url;\n *   @firstLink first: url;\n *   @lastLink last: url;\n * }\n * @list op listPets(): Page<Pet>;\n * ```\n */\nextern dec prevLink(target: ModelProperty);\n\n/**\n * Pagination property defining a link to the first page.\n *\n * It is expected that navigating to the link will return the same set of responses as the operation that returned the current page.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n *   @nextLink next: url;\n *   @prevLink prev: url;\n *   @firstLink first: url;\n *   @lastLink last: url;\n * }\n * @list op listPets(): Page<Pet>;\n * ```\n */\nextern dec firstLink(target: ModelProperty);\n\n/**\n * Pagination property defining a link to the last page.\n *\n * It is expected that navigating to the link will return the same set of responses as the operation that returned the current page.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n *   @nextLink next: url;\n *   @prevLink prev: url;\n *   @firstLink first: url;\n *   @lastLink last: url;\n * }\n * @list op listPets(): Page<Pet>;\n * ```\n */\nextern dec lastLink(target: ModelProperty);\n\n//---------------------------------------------------------------------------\n// Debugging\n//---------------------------------------------------------------------------\n\n/**\n * A debugging decorator used to inspect a type.\n * @param text Custom text to log\n */\nextern dec inspectType(target: unknown, text: valueof string);\n\n/**\n * A debugging decorator used to inspect a type name.\n * @param text Custom text to log\n */\nextern dec inspectTypeName(target: unknown, text: valueof string);\n',
  "../../core/packages/compiler/lib/std/reflection.tsp": "namespace TypeSpec.Reflection;\n\nmodel Enum {}\nmodel EnumMember {}\nmodel Interface {}\nmodel Model {}\nmodel ModelProperty {}\nmodel Namespace {}\nmodel Operation {}\nmodel Scalar {}\nmodel Union {}\nmodel UnionVariant {}\nmodel StringTemplate {}\n",
  "../../core/packages/compiler/lib/std/visibility.tsp": '// Copyright (c) Microsoft Corporation\n// Licensed under the MIT license.\n\nimport "../../dist/src/lib/tsp-index.js";\n\nusing TypeSpec.Reflection;\n\nnamespace TypeSpec;\n\n/**\n * Sets the visibility modifiers that are active on a property, indicating that it is only considered to be present\n * (or "visible") in contexts that select for the given modifiers.\n *\n * A property without any visibility settings applied for any visibility class (e.g. `Lifecycle`) is considered to have\n * the default visibility settings for that class.\n *\n * If visibility for the property has already been set for a visibility class (for example, using `@invisible` or\n * `@removeVisibility`), this decorator will **add** the specified visibility modifiers to the property.\n *\n * See: [Visibility](https://typespec.io/docs/language-basics/visibility)\n *\n * The `@typespec/http` library uses `Lifecycle` visibility to determine which properties are included in the request or\n * response bodies of HTTP operations. By default, it uses the following visibility settings:\n *\n * - For the return type of operations, properties are included if they have `Lifecycle.Read` visibility.\n * - For POST operation parameters, properties are included if they have `Lifecycle.Create` visibility.\n * - For PUT operation parameters, properties are included if they have `Lifecycle.Create` or `Lifecycle.Update` visibility.\n * - For PATCH operation parameters, properties are included if they have `Lifecycle.Update` visibility.\n * - For DELETE operation parameters, properties are included if they have `Lifecycle.Delete` visibility.\n * - For GET or HEAD operation parameters, properties are included if they have `Lifecycle.Query` visibility.\n *\n * By default, properties have all five Lifecycle visibility modifiers enabled, so a property is visible in all contexts\n * by default.\n *\n * The default settings may be overridden using the `@returnTypeVisibility` and `@parameterVisibility` decorators.\n *\n * See also: [Automatic visibility](https://typespec.io/docs/libraries/http/operations#automatic-visibility)\n *\n * @param visibilities List of visibilities which apply to this property.\n *\n * @example\n *\n * ```typespec\n * model Dog {\n *   // The service will generate an ID, so you don\'t need to send it.\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   // The service will store this secret name, but won\'t ever return it.\n *   @visibility(Lifecycle.Create, Lifecycle.Update)\n *   secretName: string;\n *\n *   // The regular name has all vi\n *   name: string;\n * }\n * ```\n */\nextern dec visibility(target: ModelProperty, ...visibilities: valueof EnumMember[]);\n\n/**\n * Indicates that a property is not visible in the given visibility class.\n *\n * This decorator removes all active visibility modifiers from the property within\n * the given visibility class, making it invisible to any context that selects for\n * visibility modifiers within that class.\n *\n * @param visibilityClass The visibility class to make the property invisible within.\n *\n * @example\n * ```typespec\n * model Example {\n *   @invisible(Lifecycle)\n *   hidden_property: string;\n * }\n * ```\n */\nextern dec invisible(target: ModelProperty, visibilityClass: Enum);\n\n/**\n * Removes visibility modifiers from a property.\n *\n * If the visibility modifiers for a visibility class have not been initialized,\n * this decorator will use the default visibility modifiers for the visibility\n * class as the default modifier set.\n *\n * @param target The property to remove visibility from.\n * @param visibilities The visibility modifiers to remove from the target property.\n *\n * @example\n * ```typespec\n * model Example {\n *   // This property will have all Lifecycle visibilities except the Read\n *   // visibility, since it is removed.\n *   @removeVisibility(Lifecycle.Read)\n *   secret_property: string;\n * }\n * ```\n */\nextern dec removeVisibility(target: ModelProperty, ...visibilities: valueof EnumMember[]);\n\n/**\n * Removes properties that do not have at least one of the given visibility modifiers\n * active.\n *\n * If no visibility modifiers are supplied, this decorator has no effect.\n *\n * See also: [Automatic visibility](https://typespec.io/docs/libraries/http/operations#automatic-visibility)\n *\n * When using an emitter that applies visibility automatically, it is generally\n * not necessary to use this decorator.\n *\n * @param visibilities List of visibilities that apply to this property.\n *\n * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   @visibility(Lifecycle.Create, Lifecycle.Update)\n *   secretName: string;\n *\n *   name: string;\n * }\n *\n * // The spread operator will copy all the properties of Dog into DogRead,\n * // and @withVisibility will then remove those that are not visible with\n * // create or update visibility.\n * //\n * // In this case, the id property is removed, and the name and secretName\n * // properties are kept.\n * @withVisibility(Lifecycle.Create, Lifecycle.Update)\n * model DogCreateOrUpdate {\n *   ...Dog;\n * }\n *\n * // In this case the id and name properties are kept and the secretName property\n * // is removed.\n * @withVisibility(Lifecycle.Read)\n * model DogRead {\n *   ...Dog;\n * }\n * ```\n */\nextern dec withVisibility(target: Model, ...visibilities: valueof EnumMember[]);\n\n/**\n * Set the visibility of key properties in a model if not already set.\n *\n * This will set the visibility modifiers of all key properties in the model if the visibility is not already _explicitly_ set,\n * but will not change the visibility of any properties that have visibility set _explicitly_, even if the visibility\n * is the same as the default visibility.\n *\n * Visibility may be set explicitly using any of the following decorators:\n *\n * - `@visibility`\n * - `@removeVisibility`\n * - `@invisible`\n *\n * @param visibility The desired default visibility value. If a key property already has visibility set, it will not be changed.\n */\nextern dec withDefaultKeyVisibility(target: Model, visibility: valueof EnumMember);\n\n/**\n * Declares the visibility constraint of the parameters of a given operation.\n *\n * A parameter or property nested within a parameter will be visible if it has _any_ of the visibilities\n * in the list.\n *\n * It is invalid to call this decorator with no visibility modifiers.\n *\n * @param visibilities List of visibility modifiers that apply to the parameters of this operation.\n */\nextern dec parameterVisibility(target: Operation, ...visibilities: valueof EnumMember[]);\n\n/**\n * Declares the visibility constraint of the return type of a given operation.\n *\n * A property within the return type of the operation will be visible if it has _any_ of the visibilities\n * in the list.\n *\n * It is invalid to call this decorator with no visibility modifiers.\n *\n * @param visibilities List of visibility modifiers that apply to the return type of this operation.\n */\nextern dec returnTypeVisibility(target: Operation, ...visibilities: valueof EnumMember[]);\n\n/**\n * Returns the model with non-updateable properties removed.\n */\nextern dec withUpdateableProperties(target: Model);\n\n/**\n * Declares the default visibility modifiers for a visibility class.\n *\n * The default modifiers are used when a property does not have any visibility decorators\n * applied to it.\n *\n * The modifiers passed to this decorator _MUST_ be members of the target Enum.\n *\n * @param visibilities the list of modifiers to use as the default visibility modifiers.\n */\nextern dec defaultVisibility(target: Enum, ...visibilities: valueof EnumMember[]);\n\n/**\n * A visibility class for resource lifecycle phases.\n *\n * These visibilities control whether a property is visible during the various phases of a resource\'s lifecycle.\n *\n * @example\n * ```typespec\n * model Dog {\n *  @visibility(Lifecycle.Read)\n *  id: int32;\n *\n *  @visibility(Lifecycle.Create, Lifecycle.Update)\n *  secretName: string;\n *\n *  name: string;\n * }\n * ```\n *\n * In this example, the `id` property is only visible during the read phase, and the `secretName` property is only visible\n * during the create and update phases. This means that the server will return the `id` property when returning a `Dog`,\n * but the client will not be able to set or update it. In contrast, the `secretName` property can be set when creating\n * or updating a `Dog`, but the server will never return it. The `name` property has no visibility modifiers and is\n * therefore visible in all phases.\n */\nenum Lifecycle {\n  /**\n   * The property is visible when a resource is being created.\n   */\n  Create,\n\n  /**\n   * The property is visible when a resource is being read.\n   */\n  Read,\n\n  /**\n   * The property is visible when a resource is being updated.\n   */\n  Update,\n\n  /**\n   * The property is visible when a resource is being deleted.\n   */\n  Delete,\n\n  /**\n   * The property is visible when a resource is being queried.\n   *\n   * In HTTP APIs, this visibility applies to parameters of GET or HEAD operations.\n   */\n  Query,\n}\n\n/**\n * A visibility filter, used to specify which properties should be included when\n * using the `withVisibilityFilter` decorator.\n *\n * The filter matches any property with ALL of the following:\n * - If the `any` key is present, the property must have at least one of the specified visibilities.\n * - If the `all` key is present, the property must have all of the specified visibilities.\n * - If the `none` key is present, the property must have none of the specified visibilities.\n */\nmodel VisibilityFilter {\n  any?: EnumMember[];\n  all?: EnumMember[];\n  none?: EnumMember[];\n}\n\n/**\n * Applies the given visibility filter to the properties of the target model.\n *\n * This transformation is recursive, so it will also apply the filter to any nested\n * or referenced models that are the types of any properties in the `target`.\n *\n * If a `nameTemplate` is provided, newly-created type instances will be named according\n * to the template. See the `@friendlyName` decorator for more information on the template\n * syntax. The transformed type is provided as the argument to the template.\n *\n * @param target The model to apply the visibility filter to.\n * @param filter The visibility filter to apply to the properties of the target model.\n * @param nameTemplate The name template to use when renaming new model instances.\n *\n * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   name: string;\n * }\n *\n * @withVisibilityFilter(#{ all: #[Lifecycle.Read] })\n * model DogRead {\n *  ...Dog\n * }\n * ```\n */\nextern dec withVisibilityFilter(\n  target: Model,\n  filter: valueof VisibilityFilter,\n  nameTemplate?: valueof string\n);\n\n/**\n * Transforms the `target` model to include only properties that are visible during the\n * "Update" lifecycle phase.\n *\n * Any nested models of optional properties will be transformed into the "CreateOrUpdate"\n * lifecycle phase instead of the "Update" lifecycle phase, so that nested models may be\n * fully updated.\n *\n * If a `nameTemplate` is provided, newly-created type instances will be named according\n * to the template. See the `@friendlyName` decorator for more information on the template\n * syntax. The transformed type is provided as the argument to the template.\n *\n * @param target The model to apply the transformation to.\n * @param nameTemplate The name template to use when renaming new model instances.\n *\n * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   @visibility(Lifecycle.Create, Lifecycle.Update)\n *   secretName: string;\n *\n *   name: string;\n * }\n *\n * @withLifecycleUpdate\n * model DogUpdate {\n *   ...Dog\n * }\n * ```\n */\nextern dec withLifecycleUpdate(target: Model, nameTemplate?: valueof string);\n\n/**\n * A copy of the input model `T` with only the properties that are visible during the\n * "Create" resource lifecycle phase.\n *\n * This transformation is recursive, and will include only properties that have the\n * `Lifecycle.Create` visibility modifier.\n *\n * If a `NameTemplate` is provided, the new model will be named according to the template.\n * The template uses the same syntax as the `@friendlyName` decorator.\n *\n * @template T The model to transform.\n * @template NameTemplate The name template to use for the new model.\n *\n *  * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   name: string;\n * }\n *\n * // This model has only the `name` field.\n * model CreateDog is Create<Dog>;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@withVisibilityFilter(#{ all: #[Lifecycle.Create] }, NameTemplate)\nmodel Create<T extends Reflection.Model, NameTemplate extends valueof string = "Create{name}"> {\n  ...T;\n}\n\n/**\n * A copy of the input model `T` with only the properties that are visible during the\n * "Read" resource lifecycle phase.\n *\n * The "Read" lifecycle phase is used for properties returned by operations that read data, like\n * HTTP GET operations.\n *\n * This transformation is recursive, and will include only properties that have the\n * `Lifecycle.Read` visibility modifier.\n *\n * If a `NameTemplate` is provided, the new model will be named according to the template.\n * The template uses the same syntax as the `@friendlyName` decorator.\n *\n * @template T The model to transform.\n * @template NameTemplate The name template to use for the new model.\n *\n *  * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   @visibility(Lifecycle.Create, Lifecycle.Update)\n *   secretName: string;\n *\n *   name: string;\n * }\n *\n * // This model has the `id` and `name` fields, but not `secretName`.\n * model ReadDog is Read<Dog>;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@withVisibilityFilter(#{ all: #[Lifecycle.Read] }, NameTemplate)\nmodel Read<T extends Reflection.Model, NameTemplate extends valueof string = "Read{name}"> {\n  ...T;\n}\n\n/**\n * A copy of the input model `T` with only the properties that are visible during the\n * "Update" resource lifecycle phase.\n *\n * The "Update" lifecycle phase is used for properties passed as parameters to operations\n * that update data, like HTTP PATCH operations.\n *\n * This transformation will include only the properties that have the `Lifecycle.Update`\n * visibility modifier, and the types of all properties will be replaced with the\n * equivalent `CreateOrUpdate` transformation.\n *\n * If a `NameTemplate` is provided, the new model will be named according to the template.\n * The template uses the same syntax as the `@friendlyName` decorator.\n *\n * @template T The model to transform.\n * @template NameTemplate The name template to use for the new model.\n *\n *  * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   @visibility(Lifecycle.Create, Lifecycle.Update)\n *   secretName: string;\n *\n *   name: string;\n * }\n *\n * // This model will have the `secretName` and `name` fields, but not the `id` field.\n * model UpdateDog is Update<Dog>;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@withLifecycleUpdate(NameTemplate)\nmodel Update<T extends Reflection.Model, NameTemplate extends valueof string = "Update{name}"> {\n  ...T;\n}\n\n/**\n * A copy of the input model `T` with only the properties that are visible during the\n * "Create" or "Update" resource lifecycle phases.\n *\n * The "CreateOrUpdate" lifecycle phase is used by default for properties passed as parameters to operations\n * that can create _or_ update data, like HTTP PUT operations.\n *\n * This transformation is recursive, and will include only properties that have the\n * `Lifecycle.Create` or `Lifecycle.Update` visibility modifier.\n *\n * If a `NameTemplate` is provided, the new model will be named according to the template.\n * The template uses the same syntax as the `@friendlyName` decorator.\n *\n * @template T The model to transform.\n * @template NameTemplate The name template to use for the new model.\n *\n *  * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   @visibility(Lifecycle.Create)\n *   immutableSecret: string;\n *\n *   @visibility(Lifecycle.Create, Lifecycle.Update)\n *   secretName: string;\n *\n *   name: string;\n * }\n *\n * // This model will have the `immutableSecret`, `secretName`, and `name` fields, but not the `id` field.\n * model CreateOrUpdateDog is CreateOrUpdate<Dog>;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@withVisibilityFilter(#{ any: #[Lifecycle.Create, Lifecycle.Update] }, NameTemplate)\nmodel CreateOrUpdate<\n  T extends Reflection.Model,\n  NameTemplate extends valueof string = "CreateOrUpdate{name}"\n> {\n  ...T;\n}\n\n/**\n * A copy of the input model `T` with only the properties that are visible during the\n * "Delete" resource lifecycle phase.\n *\n * The "Delete" lifecycle phase is used for properties passed as parameters to operations\n * that delete data, like HTTP DELETE operations.\n *\n * This transformation is recursive, and will include only properties that have the\n * `Lifecycle.Delete` visibility modifier.\n *\n * If a `NameTemplate` is provided, the new model will be named according to the template.\n * The template uses the same syntax as the `@friendlyName` decorator.\n *\n * @template T The model to transform.\n * @template NameTemplate The name template to use for the new model.\n *\n *  * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   // Set when the Dog is removed from our data store. This happens when the\n *   // Dog is re-homed to a new owner.\n *   @visibility(Lifecycle.Delete)\n *   nextOwner: string;\n *\n *   name: string;\n * }\n *\n * // This model will have the `nextOwner` and `name` fields, but not the `id` field.\n * model DeleteDog is Delete<Dog>;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@withVisibilityFilter(#{ all: #[Lifecycle.Delete] }, NameTemplate)\nmodel Delete<T extends Reflection.Model, NameTemplate extends valueof string = "Delete{name}"> {\n  ...T;\n}\n\n/**\n * A copy of the input model `T` with only the properties that are visible during the\n * "Query" resource lifecycle phase.\n *\n * The "Query" lifecycle phase is used for properties passed as parameters to operations\n * that read data, like HTTP GET or HEAD operations. This should not be confused for\n * the `@query` decorator, which specifies that the property is transmitted in the\n * query string of an HTTP request.\n *\n * This transformation is recursive, and will include only properties that have the\n * `Lifecycle.Query` visibility modifier.\n *\n * If a `NameTemplate` is provided, the new model will be named according to the template.\n * The template uses the same syntax as the `@friendlyName` decorator.\n *\n * @template T The model to transform.\n * @template NameTemplate The name template to use for the new model.\n *\n *  * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   // When getting information for a Dog, you can set this field to true to include\n *   // some extra information about the Dog\'s pedigree that is normally not returned.\n *   // Alternatively, you could just use a separate option parameter to get this\n *   // information.\n *   @visibility(Lifecycle.Query)\n *   includePedigree?: boolean;\n *\n *   name: string;\n *\n *   // Only included if `includePedigree` is set to true in the request.\n *   @visibility(Lifecycle.Read)\n *   pedigree?: string;\n * }\n *\n * // This model will have the `includePedigree` and `name` fields, but not `id` or `pedigree`.\n * model QueryDog is Query<Dog>;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@withVisibilityFilter(#{ all: #[Lifecycle.Query] }, NameTemplate)\nmodel Query<T extends Reflection.Model, NameTemplate extends valueof string = "Query{name}"> {\n  ...T;\n}\n',
  "lib/azure-core.tsp": 'import "@typespec/http";\nimport "@typespec/rest";\nimport "@typespec/versioning";\n\nimport "./auth.tsp";\nimport "./traits.tsp";\nimport "./foundations.tsp";\nimport "./models.tsp";\nimport "./operations.tsp";\nimport "./obsolete.tsp";\nimport "./decorators.tsp";\nimport "./legacy.tsp";\nimport "../dist/src/tsp-index.js";\n\nusing Versioning;\n\n@versioned(Versions)\nnamespace Azure.Core;\n\n/**\n * Supported versions of Azure.Core TypeSpec building blocks.\n */\nenum Versions {\n  @doc("Version 1.0-preview.1")\n  v1_0_Preview_1: "1.0-preview.1",\n\n  @doc("Version 1.0-preview.2")\n  v1_0_Preview_2: "1.0-preview.2",\n}\n',
  "../../core/packages/http/lib/main.tsp": 'import "../dist/src/tsp-index.js";\nimport "./decorators.tsp";\nimport "./private.decorators.tsp";\nimport "./auth.tsp";\n\nnamespace TypeSpec.Http;\n\nusing Private;\n\n/**\n * Describes an HTTP response.\n *\n * @template Status The status code of the response.\n */\n@doc("")\nmodel Response<Status> {\n  @doc("The status code.")\n  @statusCode\n  statusCode: Status;\n}\n\n/**\n * Defines a model with a single property of the given type, marked with `@body`.\n *\n * This can be useful in situations where you cannot use a bare type as the body\n * and it is awkward to add a property.\n *\n * @template Type The type of the model\'s `body` property.\n */\n@doc("")\nmodel Body<Type> {\n  @body\n  @doc("The body type of the operation request or response.")\n  body: Type;\n}\n\n/**\n * The Location header contains the URL where the status of the long running operation can be checked.\n */\nmodel LocationHeader {\n  @doc("The Location header contains the URL where the status of the long running operation can be checked.")\n  @header\n  location: string;\n}\n\n// Don\'t put @doc on these, change `getStatusCodeDescription` implementation\n// to update the default descriptions for these status codes. This ensures\n// that we get consistent emit between different ways to spell the same\n// responses in TypeSpec.\n\n/**\n * The request has succeeded.\n */\nmodel OkResponse is Response<200>;\n/**\n * The request has succeeded and a new resource has been created as a result.\n */\nmodel CreatedResponse is Response<201>;\n/**\n * The request has been accepted for processing, but processing has not yet completed.\n */\nmodel AcceptedResponse is Response<202>;\n/**\n * There is no content to send for this request, but the headers may be useful.\n */\nmodel NoContentResponse is Response<204>;\n/**\n * The URL of the requested resource has been changed permanently. The new URL is given in the response.\n */\nmodel MovedResponse is Response<301> {\n  ...LocationHeader;\n}\n/**\n * The client has made a conditional request and the resource has not been modified.\n */\nmodel NotModifiedResponse is Response<304>;\n/**\n * The server could not understand the request due to invalid syntax.\n */\nmodel BadRequestResponse is Response<400>;\n/**\n * Access is unauthorized.\n */\nmodel UnauthorizedResponse is Response<401>;\n/**\n * Access is forbidden.\n */\nmodel ForbiddenResponse is Response<403>;\n/**\n * The server cannot find the requested resource.\n */\nmodel NotFoundResponse is Response<404>;\n/**\n * The request conflicts with the current state of the server.\n */\nmodel ConflictResponse is Response<409>;\n\n/**\n * Produces a new model with the same properties as T, but with `@query`,\n * `@header`, `@body`, and `@path` decorators removed from all properties.\n *\n * @template Data The model to spread as the plain data.\n */\n@plainData\nmodel PlainData<Data> {\n  ...Data;\n}\n\n/**\n * A file in an HTTP request, response, or multipart payload.\n *\n * Files have a special meaning that the HTTP library understands. When the body of an HTTP request, response,\n * or multipart payload is _effectively_ an instance of `TypeSpec.Http.File` or any type that extends it, the\n * operation is treated as a file upload or download.\n *\n * When using file bodies, the fields of the file model are defined to come from particular locations by default:\n *\n * - `contentType`: The `Content-Type` header of the request, response, or multipart payload (CANNOT be overridden or changed).\n * - `contents`: The body of the request, response, or multipart payload (CANNOT be overridden or changed).\n * - `filename`: The `filename` parameter value of the `Content-Disposition` header of the response or multipart payload\n *   (MAY be overridden or changed).\n *\n * A File may be used as a normal structured JSON object in a request or response, if the request specifies an explicit\n * `Content-Type` header. In this case, the entire File model is serialized as if it were any other model. In a JSON payload,\n * it will have a structure like:\n *\n * ```\n * {\n *   "contentType": <string?>,\n *   "filename": <string?>,\n *   "contents": <string, base64>\n * }\n * ```\n *\n * The `contentType` _within_ the file defines what media types the data inside the file can be, but if the specification\n * defines a `Content-Type` for the payload as HTTP metadata, that `Content-Type` metadata defines _how the file is\n * serialized_. See the examples below for more information.\n *\n * NOTE: The `filename` and `contentType` fields are optional. Furthermore, the default location of `filename`\n * (`Content-Disposition: <disposition>; filename=<filename>`) is only valid in HTTP responses and multipart payloads. If\n * you wish to send the `filename` in a request, you must use HTTP metadata decorators to describe the location of the\n * `filename` field. You can combine the metadata decorators with `@visibility` to control when the `filename` location\n * is overridden, as shown in the examples below.\n *\n * @template ContentType The allowed media (MIME) types of the file contents.\n * @template Contents The type of the file contents. This can be `string`, `bytes`, or any scalar that extends them.\n *\n * @example\n * ```tsp\n * // Download a file\n * @get op download(): File;\n *\n * // Upload a file\n * @post op upload(@bodyRoot file: File): void;\n * ```\n *\n * @example\n * ```tsp\n * // Upload and download files in a multipart payload\n * op multipartFormDataUpload(\n *   @multipartBody fields: {\n *     files: HttpPart<File>[];\n *   },\n * ): void;\n *\n * op multipartFormDataDownload(): {\n *   @multipartBody formFields: {\n *     files: HttpPart<File>[];\n *   }\n * };\n * ```\n *\n * @example\n * ```tsp\n * // Declare a custom type of text file, where the filename goes in the path\n * // in requests.\n * model SpecFile extends File<"application/json" | "application/yaml", string> {\n *   // Provide a header that contains the name of the file when created or updated\n *   @header("x-filename")\n *   @path filename: string;\n * }\n *\n * @get op downloadSpec(@path name: string): SpecFile;\n *\n * @post op uploadSpec(@bodyRoot spec: SpecFile): void;\n * ```\n *\n * @example\n * ```tsp\n * // Declare a custom type of binary file\n * model ImageFile extends File {\n *   contentType: "image/png" | "image/jpeg";\n *   @path filename: string;\n * }\n *\n * @get op downloadImage(@path name: string): ImageFile;\n *\n * @post op uploadImage(@bodyRoot image: ImageFile): void;\n * ```\n *\n * @example\n * ```tsp\n * // Use a File as a structured JSON object. The HTTP library will warn you that the File will be serialized as JSON,\n * // so you should suppress the warning if it\'s really what you want instead of a binary file upload/download.\n *\n * // The response body is a JSON object like `{"contentType":<string?>,"filename":<string?>,"contents":<string>}`\n * @get op downloadTextFileJson(): {\n *   @header contentType: "application/json",\n *   @body file: File<"text/plain", string>,\n * };\n *\n * // The request body is a JSON object like `{"contentType":<string?>,"filename":<string?>,"contents":<base64>}`\n * @post op uploadBinaryFileJson(\n *   @header contentType: "application/json",\n *   @body file: File<"image/png", bytes>,\n * ): void;\n *\n */\n@summary("A file in an HTTP request, response, or multipart payload.")\n@Private.httpFile\nmodel File<ContentType extends string = string, Contents extends bytes | string = bytes> {\n  /**\n   * The allowed media (MIME) types of the file contents.\n   *\n   * In file bodies, this value comes from the `Content-Type` header of the request or response. In JSON bodies,\n   * this value is serialized as a field in the response.\n   *\n   * NOTE: this is not _necessarily_ the same as the `Content-Type` header of the request or response, but\n   * it will be for file bodies. It may be different if the file is serialized as a JSON object. It always refers to the\n   * _contents_ of the file, and not necessarily the way the file itself is transmitted or serialized.\n   */\n  @summary("The allowed media (MIME) types of the file contents.")\n  contentType?: ContentType;\n\n  /**\n   * The name of the file, if any.\n   *\n   * In file bodies, this value comes from the `filename` parameter of the `Content-Disposition` header of the response\n   * or multipart payload. In JSON bodies, this value is serialized as a field in the response.\n   *\n   * NOTE: By default, `filename` cannot be sent in request payloads and can only be sent in responses and multipart\n   * payloads, as the `Content-Disposition` header is not valid in requests. If you want to send the `filename` in a request,\n   * you must extend the `File` model and override the `filename` property with a different location defined by HTTP metadata\n   * decorators.\n   */\n  @summary("The name of the file, if any.")\n  filename?: string;\n\n  /**\n   * The contents of the file.\n   *\n   * In file bodies, this value comes from the body of the request, response, or multipart payload. In JSON bodies,\n   * this value is serialized as a field in the response.\n   */\n  @summary("The contents of the file.")\n  contents: Contents;\n}\n\nmodel HttpPartOptions {\n  /** Name of the part when using the array form. */\n  name?: string;\n}\n\n@Private.httpPart(Type, Options)\nmodel HttpPart<Type, Options extends valueof HttpPartOptions = #{}> {}\n\nmodel Link {\n  target: url;\n  rel: string;\n  attributes?: Record<unknown>;\n}\n\nscalar LinkHeader<T extends Record<url> | Link[]> extends string;\n\n/**\n * Create a MergePatch Request body for updating the given resource Model.\n * The MergePatch request created by this template provides a TypeSpec description of a\n * JSON MergePatch request that can successfully update the given resource.\n * The transformation follows the definition of JSON MergePatch requests in\n * rfc 7396: https://www.rfc-editor.org/rfc/rfc7396,\n * applying the merge-patch transform recursively to keyed types in the resource Model.\n *\n * Using this template in a PATCH request body overrides the `implicitOptionality`\n * setting for PATCH operations and sets `application/merge-patch+json` as the request\n * content-type.\n *\n * @template T The type of the resource to create a MergePatch update request body for.\n * @template NameTemplate A StringTemplate used to name any models created by applying\n * the merge-patch transform to the resource. The default name template is `{name}MergePatchUpdate`,\n * for example, the merge patch transform of model `Widget` is named `WidgetMergePatchUpdate`.\n *\n * @example\n * ```tsp\n * // An operation updating a \'Widget\' using merge-patch\n * @patch op update(@body request: MergePatchUpdate<Widget>): Widget;\n * ```\n *\n * @example\n * ```tsp\n * // An operation updating a \'Widget\' using merge-patch\n * @patch op update(@bodyRoot request: MergePatchUpdate<Widget>): Widget;\n * ```\n *\n * @example\n * ```tsp\n * // An operation updating a \'Widget\' using merge-patch\n * @patch op update(...MergePatchUpdate<Widget>): Widget;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@mediaTypeHint("application/merge-patch+json")\n@applyMergePatch(T, NameTemplate, #{ visibilityMode: Private.MergePatchVisibilityMode.Update })\nmodel MergePatchUpdate<\n  T extends Reflection.Model,\n  NameTemplate extends valueof string = "{name}MergePatchUpdate"\n> {}\n\n/**\n * Create a MergePatch Request body for creating or updating the given resource Model.\n * The MergePatch request created by this template provides a TypeSpec description of a\n * JSON MergePatch request that can successfully create or update the given resource.\n * The transformation follows the definition of JSON MergePatch requests in\n * rfc 7396: https://www.rfc-editor.org/rfc/rfc7396,\n * applying the merge-patch transform recursively to keyed types in the resource Model.\n *\n * Using this template in a PATCH request body overrides the `implicitOptionality`\n * setting for PATCH operations and sets `application/merge-patch+json` as the request\n * content-type.\n *\n * @template T The type of the resource to create a MergePatch update request body for.\n * @template NameTemplate A StringTemplate used to name any models created by applying\n * the merge-patch transform to the resource. The default name template is `{name}MergePatchCreateOrUpdate`,\n * for example, the merge patch transform of model `Widget` is named `WidgetMergePatchCreateOrUpdate`.\n *\n * @example\n * ```tsp\n * // An operation updating a \'Widget\' using merge-patch\n * @patch op update(@body request: MergePatchCreateOrUpdate<Widget>): Widget;\n * ```\n *\n * @example\n * ```tsp\n * // An operation updating a \'Widget\' using merge-patch\n * @patch op update(@bodyRoot request: MergePatchCreateOrUpdate<Widget>): Widget;\n * ```\n *\n * @example\n * ```tsp\n * // An operation updating a \'Widget\' using merge-patch\n * @patch op update(...MergePatchCreateOrUpdate<Widget>): Widget;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@mediaTypeHint("application/merge-patch+json")\n@applyMergePatch(\n  T,\n  NameTemplate,\n  #{ visibilityMode: Private.MergePatchVisibilityMode.CreateOrUpdate }\n)\nmodel MergePatchCreateOrUpdate<\n  T extends Reflection.Model,\n  NameTemplate extends valueof string = "{name}MergePatchCreateOrUpdate"\n> {}\n',
  "../../core/packages/http/lib/decorators.tsp": 'namespace TypeSpec.Http;\n\nusing TypeSpec.Reflection;\n\n/**\n * Header options.\n */\nmodel HeaderOptions {\n  /**\n   * Name of the header when sent over HTTP.\n   */\n  name?: string;\n\n  /**\n   * Equivalent of adding `*` in the path parameter as per [RFC-6570](https://datatracker.ietf.org/doc/html/rfc6570#section-3.2.3)\n   *\n   *  | Style  | Explode | Primitive value = 5 | Array = [3, 4, 5] | Object = {"role": "admin", "firstName": "Alex"} |\n   *  | ------ | ------- | ------------------- | ----------------- | ----------------------------------------------- |\n   *  | simple | false   | `5   `              | `3,4,5`           | `role,admin,firstName,Alex`                     |\n   *  | simple | true    | `5`                 | `3,4,5`           | `role=admin,firstName=Alex`                     |\n   *\n   */\n  explode?: boolean;\n}\n\n/**\n * Specify this property is to be sent or received as an HTTP header.\n *\n * @param headerNameOrOptions Optional name of the header when sent over HTTP or header options.\n *  By default the header name will be the property name converted from camelCase to kebab-case. (e.g. `contentType` -> `content-type`)\n *\n * @example\n *\n * ```typespec\n * op read(@header accept: string): {@header("ETag") eTag: string};\n * op create(@header({name: "X-Color", format: "csv"}) colors: string[]): void;\n * ```\n *\n * @example Implicit header name\n *\n * ```typespec\n * op read(): {@header contentType: string}; // headerName: content-type\n * op update(@header ifMatch: string): void; // headerName: if-match\n * ```\n */\nextern dec header(target: ModelProperty, headerNameOrOptions?: valueof string | HeaderOptions);\n\n/**\n * Cookie Options.\n */\nmodel CookieOptions {\n  /**\n   * Name in the cookie.\n   */\n  name?: string;\n}\n\n/**\n * Specify this property is to be sent or received in the cookie.\n *\n * @param cookieNameOrOptions Optional name of the cookie in the cookie or cookie options.\n *  By default the cookie name will be the property name converted from camelCase to snake_case. (e.g. `authToken` -> `auth_token`)\n *\n * @example\n *\n * ```typespec\n * op read(@cookie token: string): {data: string[]};\n * op create(@cookie({name: "auth_token"}) data: string[]): void;\n * ```\n *\n * @example Implicit header name\n *\n * ```typespec\n * op read(): {@cookie authToken: string}; // headerName: auth_token\n * op update(@cookie AuthToken: string): void; // headerName: auth_token\n * ```\n */\nextern dec cookie(target: ModelProperty, cookieNameOrOptions?: valueof string | CookieOptions);\n\n/**\n * Query parameter options.\n */\nmodel QueryOptions {\n  /**\n   * Name of the query when included in the url.\n   */\n  name?: string;\n\n  /**\n   * If true send each value in the array/object as a separate query parameter.\n   * Equivalent of adding `*` in the path parameter as per [RFC-6570](https://datatracker.ietf.org/doc/html/rfc6570#section-3.2.3)\n   *\n   *  | Style  | Explode | Uri Template   | Primitive value id = 5 | Array id = [3, 4, 5]    | Object id = {"role": "admin", "firstName": "Alex"} |\n   *  | ------ | ------- | -------------- | ---------------------- | ----------------------- | -------------------------------------------------- |\n   *  | simple | false   | `/users{?id}`  | `/users?id=5`          | `/users?id=3,4,5`       | `/users?id=role,admin,firstName,Alex`              |\n   *  | simple | true    | `/users{?id*}` | `/users?id=5`          | `/users?id=3&id=4&id=5` | `/users?role=admin&firstName=Alex`                 |\n   *\n   */\n  explode?: boolean;\n}\n\n/**\n * Specify this property is to be sent as a query parameter.\n *\n * @param queryNameOrOptions Optional name of the query when included in the url or query parameter options.\n *\n * @example\n *\n * ```typespec\n * op read(@query select: string, @query("order-by") orderBy: string): void;\n * op list(@query(#{name: "id", explode: true}) ids: string[]): void;\n * ```\n */\nextern dec query(target: ModelProperty, queryNameOrOptions?: valueof string | QueryOptions);\n\nmodel PathOptions {\n  /** Name of the parameter in the uri template. */\n  name?: string;\n\n  /**\n   * When interpolating this parameter in the case of array or object expand each value using the given style.\n   * Equivalent of adding `*` in the path parameter as per [RFC-6570](https://datatracker.ietf.org/doc/html/rfc6570#section-3.2.3)\n   */\n  explode?: boolean;\n\n  /**\n   * Different interpolating styles for the path parameter.\n   * - `simple`: No special encoding.\n   * - `label`: Using `.` separator.\n   * - `matrix`: `;` as separator.\n   * - `fragment`: `#` as separator.\n   * - `path`: `/` as separator.\n   */\n  style?: "simple" | "label" | "matrix" | "fragment" | "path";\n\n  /**\n   * When interpolating this parameter do not encode reserved characters.\n   * Equivalent of adding `+` in the path parameter as per [RFC-6570](https://datatracker.ietf.org/doc/html/rfc6570#section-3.2.3)\n   */\n  allowReserved?: boolean;\n}\n\n/**\n * Explicitly specify that this property is to be interpolated as a path parameter.\n *\n * @param paramNameOrOptions Optional name of the parameter in the uri template or options.\n *\n * @example\n *\n * ```typespec\n * @route("/read/{explicit}/things/{implicit}")\n * op read(@path explicit: string, implicit: string): void;\n * ```\n */\nextern dec path(target: ModelProperty, paramNameOrOptions?: valueof string | PathOptions);\n\n/**\n * Explicitly specify that this property type will be exactly the HTTP body.\n *\n * This means that any properties under `@body` cannot be marked as headers, query parameters, or path parameters.\n * If wanting to change the resolution of the body but still mix parameters, use `@bodyRoot`.\n *\n * @example\n *\n * ```typespec\n * op upload(@body image: bytes): void;\n * op download(): {@body image: bytes};\n * ```\n */\nextern dec body(target: ModelProperty);\n\n/**\n * Specify that the body resolution should be resolved from that property.\n * By default the body is resolved by including all properties in the operation request/response that are not metadata.\n * This allows to nest the body in a property while still allowing to use headers, query parameters, and path parameters in the same model.\n *\n * @example\n *\n * ```typespec\n * op upload(@bodyRoot user: {name: string, @header id: string}): void;\n * op download(): {@bodyRoot user: {name: string, @header id: string}};\n * ```\n */\nextern dec bodyRoot(target: ModelProperty);\n/**\n * Specify that this property shouldn\'t be included in the HTTP body.\n * This can be useful when bundling metadata together that would result in an empty property to be included in the body.\n *\n * @example\n *\n * ```typespec\n * op upload(name: string, @bodyIgnore headers: {@header id: string}): void;\n * ```\n */\nextern dec bodyIgnore(target: ModelProperty);\n\n/**\n * @example\n *\n * ```tsp\n * op upload(\n *   @header `content-type`: "multipart/form-data",\n *   @multipartBody body: {\n *     fullName: HttpPart<string>,\n *     headShots: HttpPart<Image>[]\n *   }\n * ): void;\n * ```\n */\nextern dec multipartBody(target: ModelProperty);\n\n/**\n * Specify the status code for this response. Property type must be a status code integer or a union of status code integer.\n *\n * @example\n *\n * ```typespec\n * op read(): {\n *   @statusCode _: 200;\n *   @body pet: Pet;\n * };\n * op create(): {\n *   @statusCode _: 201 | 202;\n * };\n * ```\n */\nextern dec statusCode(target: ModelProperty);\n\n/**\n * Specify the HTTP verb for the target operation to be `GET`.\n *\n * @example\n *\n * ```typespec\n * @get op read(): string\n * ```\n */\nextern dec get(target: Operation);\n\n/**\n * Specify the HTTP verb for the target operation to be `PUT`.\n *\n * @example\n *\n * ```typespec\n * @put op set(pet: Pet): void\n * ```\n */\nextern dec put(target: Operation);\n\n/**\n * Specify the HTTP verb for the target operation to be `POST`.\n *\n * @example\n *\n * ```typespec\n * @post op create(pet: Pet): void\n * ```\n */\nextern dec post(target: Operation);\n\n/**\n * Options for PATCH operations.\n */\nmodel PatchOptions {\n  /**\n   * If set to `false`, disables the implicit transform that makes the body of a\n   * PATCH operation deeply optional.\n   */\n  implicitOptionality?: boolean;\n}\n\n/**\n * Specify the HTTP verb for the target operation to be `PATCH`.\n *\n * @param options Options for the PATCH operation.\n *\n * @example\n *\n * ```typespec\n * @patch op update(pet: Pet): void;\n * ```\n *\n * @example\n * ```typespec\n * // Disable implicit optionality, making the body of the PATCH operation use the\n * // optionality as defined in the `Pet` model.\n * @patch(#{ implicitOptionality: false })\n * op update(pet: Pet): void;\n * ```\n */\nextern dec patch(target: Operation, options?: valueof PatchOptions);\n\n/**\n * Specify the HTTP verb for the target operation to be `DELETE`.\n *\n * @example\n *\n * ```typespec\n * @delete op set(petId: string): void\n * ```\n */\nextern dec delete(target: Operation);\n\n/**\n * Specify the HTTP verb for the target operation to be `HEAD`.\n * @example\n *\n * ```typespec\n * @head op ping(petId: string): void\n * ```\n */\nextern dec head(target: Operation);\n\n/**\n * Specify an endpoint for this service. Multiple `@server` decorators can be used to specify multiple endpoints.\n *\n *  @param url Server endpoint\n *  @param description Description of the endpoint\n *  @param parameters Optional set of parameters used to interpolate the url.\n *\n * @example\n *\n * ```typespec\n * @service\n * @server("https://example.com")\n * namespace PetStore;\n * ```\n *\n * @example With a description\n *\n * ```typespec\n * @service\n * @server("https://example.com", "Single server endpoint")\n * namespace PetStore;\n * ```\n *\n * @example Parameterized\n *\n * ```typespec\n * @server("https://{region}.foo.com", "Regional endpoint", {\n *   @doc("Region name")\n *   region?: string = "westus",\n * })\n * ```\n *\n * @example Multiple\n * ```typespec\n * @service\n * @server("https://example.com", "Standard endpoint")\n * @server("https://{project}.private.example.com", "Private project endpoint", {\n *   project: string;\n * })\n * namespace PetStore;\n * ```\n *\n */\nextern dec server(\n  target: Namespace,\n  url: valueof string,\n  description?: valueof string,\n  parameters?: Record<unknown>\n);\n\n/**\n * Specify authentication for a whole service or specific methods. See the [documentation in the Http library](https://typespec.io/docs/libraries/http/authentication) for full details.\n *\n * @param auth Authentication configuration. Can be a single security scheme, a union(either option is valid authentication) or a tuple (must use all authentication together)\n * @example\n *\n * ```typespec\n * @service\n * @useAuth(BasicAuth)\n * namespace PetStore;\n * ```\n */\nextern dec useAuth(target: Namespace | Interface | Operation, auth: {} | Union | {}[]);\n\n/**\n * Defines the relative route URI template for the target operation as defined by [RFC 6570](https://datatracker.ietf.org/doc/html/rfc6570#section-3.2.3)\n *\n * `@route` can only be applied to operations, namespaces, and interfaces.\n *\n * @param uriTemplate Uri template for this operation.\n *\n * @example Simple path parameter\n *\n * ```typespec\n * @route("/widgets/{id}") op getWidget(@path id: string): Widget;\n * ```\n *\n * @example Reserved characters\n * ```typespec\n * @route("/files{+path}") op getFile(@path path: string): bytes;\n * ```\n *\n * @example Query parameter\n * ```typespec\n * @route("/files") op list(select?: string, filter?: string): Files[];\n * @route("/files{?select,filter}") op listFullUriTemplate(select?: string, filter?: string): Files[];\n * ```\n */\nextern dec route(target: Namespace | Interface | Operation, path: valueof string);\n\n/**\n * `@sharedRoute` marks the operation as sharing a route path with other operations.\n *\n * When an operation is marked with `@sharedRoute`, it enables other operations to share the same\n * route path as long as those operations are also marked with `@sharedRoute`.\n *\n * `@sharedRoute` can only be applied directly to operations.\n *\n * ```typespec\n * @sharedRoute\n * @route("/widgets")\n * op getWidget(@path id: string): Widget;\n * ```\n */\nextern dec sharedRoute(target: Operation);\n',
  "../../core/packages/http/lib/private.decorators.tsp": "/**\n * Private decorators. Those are meant for internal use inside Http types only.\n */\nnamespace TypeSpec.Http.Private;\n\nextern dec plainData(target: TypeSpec.Reflection.Model);\nextern dec httpFile(target: TypeSpec.Reflection.Model);\nextern dec httpPart(\n  target: TypeSpec.Reflection.Model,\n  type: unknown,\n  options: valueof HttpPartOptions\n);\n\n/**\n * Specify if inapplicable metadata should be included in the payload for the given entity.\n * @param value If true, inapplicable metadata will be included in the payload.\n */\nextern dec includeInapplicableMetadataInPayload(target: unknown, value: valueof boolean);\n\n/**\n * The visibility mode for the merge patch transform.\n */\nenum MergePatchVisibilityMode {\n  /**\n   * The Update mode. This is used when a resource can be updated but must already exist.\n   */\n  Update,\n\n  /**\n   * The Create or Update mode. This is used when a resource can be created OR updated in a single operation.\n   */\n  CreateOrUpdate,\n}\n\n/**\n * Options for the `@applyMergePatch` decorator.\n */\nmodel ApplyMergePatchOptions {\n  /**\n   * The visibility mode to use.\n   */\n  visibilityMode: MergePatchVisibilityMode;\n}\n\n/**\n * Performs the canonical merge-patch transformation on the given model and injects its\n * transformed properties into the target.\n */\nextern dec applyMergePatch(\n  target: Reflection.Model,\n  source: Reflection.Model,\n  nameTemplate: valueof string,\n  options: valueof ApplyMergePatchOptions\n);\n\n/**\n * Marks a model that was generated by applying the MergePatch\n * transform and links to its source model\n */\nextern dec mergePatchModel(target: Reflection.Model, source: Reflection.Model);\n\n/**\n * Links a modelProperty mutated as part of a mergePatch transform to\n * its source property;\n */\nextern dec mergePatchProperty(target: Reflection.ModelProperty, source: Reflection.ModelProperty);\n",
  "../../core/packages/http/lib/auth.tsp": 'namespace TypeSpec.Http;\n\n@doc("Authentication type")\nenum AuthType {\n  @doc("HTTP")\n  http,\n\n  @doc("API key")\n  apiKey,\n\n  @doc("OAuth2")\n  oauth2,\n\n  @doc("OpenID connect")\n  openIdConnect,\n\n  @doc("Empty auth")\n  noAuth,\n}\n\n/**\n * Basic authentication is a simple authentication scheme built into the HTTP protocol.\n * The client sends HTTP requests with the Authorization header that contains the word Basic word followed by a space and a base64-encoded string username:password.\n * For example, to authorize as demo / `p@55w0rd` the client would send\n * ```\n * Authorization: Basic ZGVtbzpwQDU1dzByZA==\n * ```\n */\n@doc("")\nmodel BasicAuth {\n  @doc("Http authentication")\n  type: AuthType.http;\n\n  @doc("basic auth scheme")\n  scheme: "Basic";\n}\n\n/**\n * Bearer authentication (also called token authentication) is an HTTP authentication scheme that involves security tokens called bearer tokens.\n * The name \u201CBearer authentication\u201D can be understood as \u201Cgive access to the bearer of this token.\u201D The bearer token is a cryptic string, usually generated by the server in response to a login request.\n * The client must send this token in the Authorization header when making requests to protected resources:\n * ```\n * Authorization: Bearer <token>\n * ```\n */\n@doc("")\nmodel BearerAuth {\n  @doc("Http authentication")\n  type: AuthType.http;\n\n  @doc("bearer auth scheme")\n  scheme: "Bearer";\n}\n\n@doc("Describes the location of the API key")\nenum ApiKeyLocation {\n  @doc("API key is a header value")\n  header,\n\n  @doc("API key is a query parameter")\n  query,\n\n  @doc("API key is found in a cookie")\n  cookie,\n}\n\n/**\n * An API key is a token that a client provides when making API calls. The key can be sent in the query string:\n *\n * ```\n * GET /something?api_key=abcdef12345\n * ```\n *\n * or as a request header\n *\n * ```\n * GET /something HTTP/1.1\n * X-API-Key: abcdef12345\n * ```\n *\n * or as a cookie\n *\n * ```\n * GET /something HTTP/1.1\n * Cookie: X-API-KEY=abcdef12345\n * ```\n *\n * @template Location The location of the API key\n * @template Name The name of the API key\n */\n@doc("")\nmodel ApiKeyAuth<Location extends ApiKeyLocation, Name extends string> {\n  @doc("API key authentication")\n  type: AuthType.apiKey;\n\n  @doc("location of the API key")\n  in: Location;\n\n  @doc("name of the API key")\n  name: Name;\n}\n\n/**\n * OAuth 2.0 is an authorization protocol that gives an API client limited access to user data on a web server.\n *\n * OAuth relies on authentication scenarios called flows, which allow the resource owner (user) to share the protected content from the resource server without sharing their credentials.\n * For that purpose, an OAuth 2.0 server issues access tokens that the client applications can use to access protected resources on behalf of the resource owner.\n * For more information about OAuth 2.0, see oauth.net and RFC 6749.\n *\n * @template Flows The list of supported OAuth2 flows\n * @template Scopes The list of OAuth2 scopes, which are common for every flow from `Flows`. This list is combined with the scopes defined in specific OAuth2 flows.\n */\n@doc("")\nmodel OAuth2Auth<Flows extends OAuth2Flow[], Scopes extends string[] = []> {\n  @doc("OAuth2 authentication")\n  type: AuthType.oauth2;\n\n  @doc("Supported OAuth2 flows")\n  flows: Flows;\n\n  @doc("Oauth2 scopes of every flow. Overridden by scope definitions in specific flows")\n  defaultScopes: Scopes;\n}\n\n@doc("Describes the OAuth2 flow type")\nenum OAuth2FlowType {\n  @doc("authorization code flow")\n  authorizationCode,\n\n  @doc("implicit flow")\n  implicit,\n\n  @doc("password flow")\n  password,\n\n  @doc("client credential flow")\n  clientCredentials,\n}\n\nalias OAuth2Flow = AuthorizationCodeFlow | ImplicitFlow | PasswordFlow | ClientCredentialsFlow;\n\n@doc("Authorization Code flow")\nmodel AuthorizationCodeFlow {\n  @doc("authorization code flow")\n  type: OAuth2FlowType.authorizationCode;\n\n  @doc("the authorization URL")\n  authorizationUrl: string;\n\n  @doc("the token URL")\n  tokenUrl: string;\n\n  @doc("the refresh URL")\n  refreshUrl?: string;\n\n  @doc("list of scopes for the credential")\n  scopes?: string[];\n}\n\n@doc("Implicit flow")\nmodel ImplicitFlow {\n  @doc("implicit flow")\n  type: OAuth2FlowType.implicit;\n\n  @doc("the authorization URL")\n  authorizationUrl: string;\n\n  @doc("the refresh URL")\n  refreshUrl?: string;\n\n  @doc("list of scopes for the credential")\n  scopes?: string[];\n}\n\n@doc("Resource Owner Password flow")\nmodel PasswordFlow {\n  @doc("password flow")\n  type: OAuth2FlowType.password;\n\n  @doc("the token URL")\n  tokenUrl: string;\n\n  @doc("the refresh URL")\n  refreshUrl?: string;\n\n  @doc("list of scopes for the credential")\n  scopes?: string[];\n}\n\n@doc("Client credentials flow")\nmodel ClientCredentialsFlow {\n  @doc("client credential flow")\n  type: OAuth2FlowType.clientCredentials;\n\n  @doc("the token URL")\n  tokenUrl: string;\n\n  @doc("the refresh URL")\n  refreshUrl?: string;\n\n  @doc("list of scopes for the credential")\n  scopes?: string[];\n}\n\n/**\n * OpenID Connect (OIDC) is an identity layer built on top of the OAuth 2.0 protocol and supported by some OAuth 2.0 providers, such as Google and Azure Active Directory.\n * It defines a sign-in flow that enables a client application to authenticate a user, and to obtain information (or "claims") about that user, such as the user name, email, and so on.\n * User identity information is encoded in a secure JSON Web Token (JWT), called ID token.\n * OpenID Connect defines a discovery mechanism, called OpenID Connect Discovery, where an OpenID server publishes its metadata at a well-known URL, typically\n *\n * ```http\n * https://server.com/.well-known/openid-configuration\n * ```\n */\nmodel OpenIdConnectAuth<ConnectUrl extends string> {\n  /** Auth type */\n  type: AuthType.openIdConnect;\n\n  /** Connect url. It can be specified relative to the server URL */\n  openIdConnectUrl: ConnectUrl;\n}\n\n/**\n * This authentication option signifies that API is not secured at all.\n * It might be useful when overriding authentication on interface of operation level.\n */\n@doc("")\nmodel NoAuth {\n  type: AuthType.noAuth;\n}\n',
  "../../core/packages/rest/lib/rest.tsp": 'import "@typespec/http";\nimport "./rest-decorators.tsp";\nimport "./resource.tsp";\nimport "../dist/src/tsp-index.js";\n\nnamespace TypeSpec.Rest;\n\n/**\n * A URL that points to a resource.\n * @template Resource The type of resource that the URL points to.\n */\n@doc("The location of an instance of {name}", Resource)\n@Private.resourceLocation(Resource)\nscalar ResourceLocation<Resource extends {}> extends url;\n',
  "../../core/packages/rest/lib/rest-decorators.tsp": 'namespace TypeSpec.Rest;\n\nusing TypeSpec.Reflection;\n\n/**\n * This interface or operation should resolve its route automatically. To be used with resource types where the route segments area defined on the models.\n *\n * @example\n *\n * ```typespec\n * @autoRoute\n * interface Pets {\n *   get(@segment("pets") @path id: string): void; //-> route: /pets/{id}\n * }\n * ```\n */\nextern dec autoRoute(target: Interface | Operation);\n\n/**\n * Defines the preceding path segment for a @path parameter in auto-generated routes.\n *\n * @param name Segment that will be inserted into the operation route before the path parameter\'s name field.\n *\n * @example\n * @autoRoute\n * interface Pets {\n *   get(@segment("pets") @path id: string): void; //-> route: /pets/{id}\n * }\n */\nextern dec segment(target: Model | ModelProperty | Operation, name: valueof string);\n\n/**\n * Returns the URL segment of a given model if it has `@segment` and `@key` decorator.\n * @param type Target model\n */\nextern dec segmentOf(target: Operation, type: Model);\n\n/**\n * Defines the separator string that is inserted before the action name in auto-generated routes for actions.\n *\n * @param seperator Seperator seperating the action segment from the rest of the url\n */\nextern dec actionSeparator(\n  target: Model | ModelProperty | Operation,\n  seperator: valueof "/" | ":" | "/:"\n);\n\n/**\n * Mark this model as a resource type with a name.\n *\n * @param collectionName type\'s collection name\n */\nextern dec resource(target: Model, collectionName: valueof string);\n\n/**\n * Mark model as a child of the given parent resource.\n * @param parent Parent model.\n */\nextern dec parentResource(target: Model, parent: Model);\n\n/**\n * Specify that this is a Read operation for a given resource.\n *\n * @param resourceType Resource marked with @resource\n */\nextern dec readsResource(target: Operation, resourceType: Model);\n\n/**\n * Specify that this is a Create operation for a given resource.\n *\n * @param resourceType Resource marked with @resource\n */\nextern dec createsResource(target: Operation, resourceType: Model);\n\n/**\n * Specify that this is a CreateOrReplace operation for a given resource.\n *\n * @param resourceType Resource marked with @resource\n */\nextern dec createsOrReplacesResource(target: Operation, resourceType: Model);\n\n/**\n * Specify that this is a CreatesOrUpdate operation for a given resource.\n *\n * @param resourceType Resource marked with @resource\n */\nextern dec createsOrUpdatesResource(target: Operation, resourceType: Model);\n\n/**\n * Specify that this is a Update operation for a given resource.\n *\n * @param resourceType Resource marked with @resource\n */\nextern dec updatesResource(target: Operation, resourceType: Model);\n\n/**\n * Specify that this is a Delete operation for a given resource.\n *\n * @param resourceType Resource marked with @resource\n */\nextern dec deletesResource(target: Operation, resourceType: Model);\n\n/**\n * Specify that this is a List operation for a given resource.\n *\n * @param resourceType Resource marked with @resource\n */\nextern dec listsResource(target: Operation, resourceType: Model);\n\n/**\n * Specify this operation is an action. (Scoped to a resource item /pets/{petId}/my-action)\n * @param name Name of the action. If not specified, the name of the operation will be used.\n */\nextern dec action(target: Operation, name?: valueof string);\n\n/**\n * Specify this operation is a collection action. (Scopped to a resource, /pets/my-action)\n * @param resourceType Resource marked with @resource\n * @param name Name of the action. If not specified, the name of the operation will be used.\n */\nextern dec collectionAction(target: Operation, resourceType: Model, name?: valueof string);\n\n/**\n * Copy the resource key parameters on the model\n * @param filter Filter to exclude certain properties.\n */\nextern dec copyResourceKeyParameters(target: Model, filter?: valueof string);\n\nnamespace Private {\n  extern dec resourceLocation(target: string, resourceType: Model);\n  extern dec validateHasKey(target: unknown, value: unknown);\n  extern dec validateIsError(target: unknown, value: unknown);\n  extern dec actionSegment(target: Operation, value: valueof string);\n  extern dec resourceTypeForKeyParam(entity: ModelProperty, resourceType: Model);\n}\n',
  "../../core/packages/rest/lib/resource.tsp": 'import "@typespec/http";\nimport "../dist/src/internal-decorators.js";\n\nnamespace TypeSpec.Rest.Resource;\n\nusing Http;\n\n@doc("The default error response for resource operations.")\nmodel ResourceError {\n  @doc("The error code.")\n  code: int32;\n\n  @doc("The error message.")\n  message: string;\n}\n\n/**\n * Dynamically gathers keys of the model type `Resource`.\n *\n * @template Resource The target resource model.\n */\n@doc("Dynamically gathers keys of the model type Resource.")\n@copyResourceKeyParameters\n@friendlyName("{name}Key", Resource)\nmodel KeysOf<Resource> {}\n\n/**\n * Dynamically gathers parent keys of the model type `Resource`.\n *\n * @template Resource The target resource model.\n */\n@doc("Dynamically gathers parent keys of the model type Resource.")\n@copyResourceKeyParameters("parent")\n@friendlyName("{name}ParentKey", Resource)\nmodel ParentKeysOf<Resource> {}\n\n/**\n * Represents operation parameters for the resource of type `Resource`.\n *\n * @template Resource The resource model.\n */\n@doc("Represents operation parameters for resource Resource.")\nmodel ResourceParameters<Resource extends {}> {\n  ...KeysOf<Resource>;\n}\n\n/**\n * Represents collection operation parameters for the resource of type `Resource`.\n *\n * @template Resource The resource model.\n */\n@doc("Represents collection operation parameters for resource Resource.")\nmodel ResourceCollectionParameters<Resource extends {}> {\n  ...ParentKeysOf<Resource>;\n}\n\n/**\n * Represents the resource GET operation.\n *\n * @template Resource The resource model.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface ResourceRead<Resource extends {}, Error> {\n  /**\n   * Gets an instance of the resource.\n   *\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Gets an instance of the resource.")\n  @readsResource(Resource)\n  get(...ResourceParameters<Resource>): Resource | Error;\n}\n\n/**\n * Resource create operation completed successfully.\n *\n * @template Resource The resource model that was created.\n */\n@doc("Resource create operation completed successfully.")\nmodel ResourceCreatedResponse<Resource> {\n  ...CreatedResponse;\n  @bodyRoot body: Resource;\n}\n\n/**\n * Resource create or replace operation template.\n *\n * @template Resource The resource model to create or replace.\n * @template Error The error response.\n */\ninterface ResourceCreateOrReplace<Resource extends {}, Error> {\n  /**\n   * Creates or replaces a instance of the resource.\n   *\n   * @template Resource The resource model to create or replace.\n   * @template Error The error response.\n   */\n  @autoRoute\n  @doc("Creates or replaces an instance of the resource.")\n  @createsOrReplacesResource(Resource)\n  createOrReplace(\n    ...ResourceParameters<Resource>,\n    @bodyRoot resource: ResourceCreateModel<Resource>,\n  ): Resource | ResourceCreatedResponse<Resource> | Error;\n}\n\n/**\n * Resource create or update operation model.\n *\n * @template Resource The resource model to create or update.\n */\n@friendlyName("{name}Update", Resource)\nmodel ResourceCreateOrUpdateModel<Resource extends {}>\n  is OptionalProperties<UpdateableProperties<DefaultKeyVisibility<Resource, Lifecycle.Read>>>;\n\n/**\n * Resource create or update operation template.\n *\n * @template Resource The resource model to create or update.\n * @template Error The error response.\n */\ninterface ResourceCreateOrUpdate<Resource extends {}, Error> {\n  /**\n   * Creates or update an instance of the resource.\n   *\n   * @template Resource The resource model to create or update.\n   * @template Error The error response.\n   */\n  @autoRoute\n  @doc("Creates or update an instance of the resource.")\n  @createsOrUpdatesResource(Resource)\n  @patch(#{ implicitOptionality: true }) // for legacy behavior\n  createOrUpdate(\n    ...ResourceParameters<Resource>,\n    @bodyRoot resource: ResourceCreateOrUpdateModel<Resource>,\n  ): Resource | ResourceCreatedResponse<Resource> | Error;\n}\n\n/**\n * Resource create operation model.\n *\n * @template Resource The resource model to create.\n */\n@friendlyName("{name}Create", Resource)\n@withVisibility(Lifecycle.Create)\nmodel ResourceCreateModel<Resource extends {}> is DefaultKeyVisibility<Resource, Lifecycle.Read>;\n\n/**\n * Resource create operation template.\n *\n * @template Resource The resource model to create.\n * @template Error The error response.\n */\ninterface ResourceCreate<Resource extends {}, Error> {\n  /**\n   * Creates a new instance of the resource.\n   *\n   * @template Resource The resource model to create.\n   * @template Error The error response.\n   */\n  @autoRoute\n  @doc("Creates a new instance of the resource.")\n  @createsResource(Resource)\n  create(\n    ...ResourceCollectionParameters<Resource>,\n    @bodyRoot resource: ResourceCreateModel<Resource>,\n  ): Resource | ResourceCreatedResponse<Resource> | Error;\n}\n\n/**\n * Resource update operation template.\n *\n * @template Resource The resource model to update.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface ResourceUpdate<Resource extends {}, Error> {\n  /**\n   * Updates an existing instance of the resource.\n   *\n   * @template Resource The resource model to update.\n   * @template Error The error response.\n   */\n  @autoRoute\n  @doc("Updates an existing instance of the resource.")\n  @updatesResource(Resource)\n  @patch(#{ implicitOptionality: true }) // for legacy behavior\n  update(\n    ...ResourceParameters<Resource>,\n    @bodyRoot properties: ResourceCreateOrUpdateModel<Resource>,\n  ): Resource | Error;\n}\n\n@doc("Resource deleted successfully.")\nmodel ResourceDeletedResponse {\n  @doc("The status code.")\n  @statusCode\n  _: 200;\n}\n\n/**\n * Resource delete operation template.\n *\n * @template Resource The resource model to delete.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface ResourceDelete<Resource extends {}, Error> {\n  /**\n   * Deletes an existing instance of the resource.\n   *\n   * @template Resource The resource model to delete.\n   * @template Error The error response.\n   */\n  @autoRoute\n  @doc("Deletes an existing instance of the resource.")\n  @deletesResource(Resource)\n  delete(...ResourceParameters<Resource>): ResourceDeletedResponse | Error;\n}\n\n/**\n * Structure for a paging response using `value` and `nextLink` to represent pagination.\n *\n * @template Resource The resource type of the collection.\n */\n@doc("Paged response of {name} items", Resource)\n@friendlyName("{name}CollectionWithNextLink", Resource)\nmodel CollectionWithNextLink<Resource extends {}> {\n  @doc("The items on this page")\n  @pageItems\n  value: Resource[];\n\n  @doc("The link to the next page of items")\n  @nextLink\n  nextLink?: ResourceLocation<Resource>;\n}\n\n/**\n * Resource list operation template.\n *\n * @template Resource The resource model to list.\n * @template Error The error response.\n */\ninterface ResourceList<Resource extends {}, Error> {\n  /**\n   * Lists all instances of the resource.\n   *\n   * @template Resource The resource model to list.\n   * @template Error The error response.\n   */\n  @autoRoute\n  @doc("Lists all instances of the resource.")\n  @listsResource(Resource)\n  list(...ResourceCollectionParameters<Resource>): CollectionWithNextLink<Resource> | Error;\n}\n\n/**\n * Resource operation templates for resource instances.\n *\n * @template Resource The resource model.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface ResourceInstanceOperations<Resource extends {}, Error>\n  extends ResourceRead<Resource, Error>,\n    ResourceUpdate<Resource, Error>,\n    ResourceDelete<Resource, Error> {}\n\n/**\n * Resource operation templates for resource collections.\n *\n * @template Resource The resource model.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface ResourceCollectionOperations<Resource extends {}, Error>\n  extends ResourceCreate<Resource, Error>,\n    ResourceList<Resource, Error> {}\n\n/**\n * Resource operation templates for resources.\n *\n * @template Resource The resource model.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface ResourceOperations<Resource extends {}, Error>\n  extends ResourceInstanceOperations<Resource, Error>,\n    ResourceCollectionOperations<Resource, Error> {}\n\n/**\n * Singleton resource read operation template.\n *\n * @template Singleton The singleton resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface SingletonResourceRead<Singleton extends {}, Resource extends {}, Error> {\n  /**\n   * Gets the singleton resource.\n   *\n   * @template Singleton The singleton resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Gets the singleton resource.")\n  @segmentOf(Singleton)\n  @readsResource(Singleton)\n  get(...ResourceParameters<Resource>): Singleton | Error;\n}\n\n/**\n * Singleton resource update operation template.\n *\n * @template Singleton The singleton resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface SingletonResourceUpdate<Singleton extends {}, Resource extends {}, Error> {\n  /**\n   * Updates the singleton resource.\n   *\n   * @template Singleton The singleton resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Updates the singleton resource.")\n  @segmentOf(Singleton)\n  @updatesResource(Singleton)\n  @patch(#{ implicitOptionality: true }) // for legacy behavior\n  update(\n    ...ResourceParameters<Resource>,\n\n    @body\n    properties: ResourceCreateOrUpdateModel<Singleton>,\n  ): Singleton | Error;\n}\n\n/**\n * Singleton resource operation templates for singleton resource instances.\n *\n * @template Singleton The singleton resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface SingletonResourceOperations<Singleton extends {}, Resource extends {}, Error>\n  extends SingletonResourceRead<Singleton, Resource, Error>,\n    SingletonResourceUpdate<Singleton, Resource, Error> {}\n\n/**\n * Extension resource read operation template.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface ExtensionResourceRead<Extension extends {}, Resource extends {}, Error> {\n  /**\n   * Gets an instance of the extension resource.\n   *\n   * @template Extension The extension resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Gets an instance of the extension resource.")\n  @readsResource(Extension)\n  get(...ResourceParameters<Resource>, ...ResourceParameters<Extension>): Extension | Error;\n}\n\n/**\n * Extension resource create or update operation template.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceCreateOrUpdate<Extension extends {}, Resource extends {}, Error> {\n  /**\n   * Creates or update an instance of the extension resource.\n   *\n   * @template Extension The extension resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Creates or update an instance of the extension resource.")\n  @createsOrUpdatesResource(Extension)\n  @patch(#{ implicitOptionality: true }) // for legacy behavior\n  createOrUpdate(\n    ...ResourceParameters<Resource>,\n    ...ResourceParameters<Extension>,\n    @bodyRoot resource: ResourceCreateOrUpdateModel<Extension>,\n  ): Extension | ResourceCreatedResponse<Extension> | Error;\n}\n\n/**\n * Extension resource create operation template.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceCreate<Extension extends {}, Resource extends {}, Error> {\n  /**\n   * Creates a new instance of the extension resource.\n   *\n   * @template Extension The extension resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Creates a new instance of the extension resource.")\n  @createsResource(Extension)\n  create(\n    ...ResourceParameters<Resource>,\n    @bodyRoot resource: ResourceCreateModel<Extension>,\n  ): Extension | ResourceCreatedResponse<Extension> | Error;\n}\n\n/**\n * Extension resource update operation template.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceUpdate<Extension extends {}, Resource extends {}, Error> {\n  /**\n   * Updates an existing instance of the extension resource.\n   *\n   * @template Extension The extension resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Updates an existing instance of the extension resource.")\n  @updatesResource(Extension)\n  @patch(#{ implicitOptionality: true }) // for legacy behavior\n  update(\n    ...ResourceParameters<Resource>,\n    ...ResourceParameters<Extension>,\n\n    @body\n    properties: ResourceCreateOrUpdateModel<Extension>,\n  ): Extension | Error;\n}\n\n/**\n * Extension resource delete operation template.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceDelete<Extension extends {}, Resource extends {}, Error> {\n  /**\n   * Deletes an existing instance of the extension resource.\n   *\n   * @template Extension The extension resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Deletes an existing instance of the extension resource.")\n  @deletesResource(Extension)\n  delete(\n    ...ResourceParameters<Resource>,\n    ...ResourceParameters<Extension>,\n  ): ResourceDeletedResponse | Error;\n}\n\n/**\n * Extension resource list operation template.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceList<Extension extends {}, Resource extends {}, Error> {\n  /**\n   * Lists all instances of the extension resource.\n   *\n   * @template Extension The extension resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Lists all instances of the extension resource.")\n  @listsResource(Extension)\n  list(\n    ...ResourceParameters<Resource>,\n    ...ResourceCollectionParameters<Extension>,\n  ): CollectionWithNextLink<Extension> | Error;\n}\n\n/**\n * Extension resource operation templates for extension resource instances.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceInstanceOperations<Extension extends {}, Resource extends {}, Error>\n  extends ExtensionResourceRead<Extension, Resource, Error>,\n    ExtensionResourceUpdate<Extension, Resource, Error>,\n    ExtensionResourceDelete<Extension, Resource, Error> {}\n\n/**\n * Extension resource operation templates for extension resource collections.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceCollectionOperations<Extension extends {}, Resource extends {}, Error>\n  extends ExtensionResourceCreate<Extension, Resource, Error>,\n    ExtensionResourceList<Extension, Resource, Error> {}\n\n/**\n * Extension resource operation templates for extension resource instances and collections.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceOperations<Extension extends {}, Resource extends {}, Error>\n  extends ExtensionResourceInstanceOperations<Extension, Resource, Error>,\n    ExtensionResourceCollectionOperations<Extension, Resource, Error> {}\n',
  "../../core/packages/versioning/lib/main.tsp": 'import "./decorators.tsp";\nimport "../dist/src/validate.js";\n',
  "../../core/packages/versioning/lib/decorators.tsp": 'import "../dist/src/decorators.js";\n\nusing TypeSpec.Reflection;\n\nnamespace TypeSpec.Versioning;\n\n/**\n * Identifies that the decorated namespace is versioned by the provided enum.\n * @param versions The enum that describes the supported versions.\n *\n * @example\n *\n * ```tsp\n * @versioned(Versions)\n * namespace MyService;\n * enum Versions {\n *   v1,\n *   v2,\n *   v3,\n * }\n * ```\n */\nextern dec versioned(target: Namespace, versions: Enum);\n\n/**\n * Identifies that a namespace or a given versioning enum member relies upon a versioned package.\n * @param versionRecords The dependent library version(s) for the target namespace or version.\n *\n * @example Select a single version of `MyLib` to use\n *\n * ```tsp\n * @useDependency(MyLib.Versions.v1_1)\n * namespace NonVersionedService;\n * ```\n *\n * @example Select which version of the library match to which version of the service.\n *\n * ```tsp\n * @versioned(Versions)\n * namespace MyService1;\n * enum Version {\n *   @useDependency(MyLib.Versions.v1_1) // V1 use lib v1_1\n *   v1,\n *   @useDependency(MyLib.Versions.v1_1) // V2 use lib v1_1\n *   v2,\n *   @useDependency(MyLib.Versions.v2) // V3 use lib v2\n *   v3,\n * }\n * ```\n */\nextern dec useDependency(target: EnumMember | Namespace, ...versionRecords: EnumMember[]);\n\n/**\n * Identifies when the target was added.\n * @param version The version that the target was added in.\n *\n * @example\n *\n * ```tsp\n * @added(Versions.v2)\n * op addedInV2(): void;\n *\n * @added(Versions.v2)\n * model AlsoAddedInV2 {}\n *\n * model Foo {\n *   name: string;\n *\n *   @added(Versions.v3)\n *   addedInV3: string;\n * }\n * ```\n */\nextern dec added(\n  target:\n    | Model\n    | ModelProperty\n    | Operation\n    | Enum\n    | EnumMember\n    | Union\n    | UnionVariant\n    | Scalar\n    | Interface,\n  version: EnumMember\n);\n\n/**\n * Identifies when the target was removed.\n * @param version The version that the target was removed in.\n *\n * @example\n * ```tsp\n * @removed(Versions.v2)\n * op removedInV2(): void;\n *\n * @removed(Versions.v2)\n * model AlsoRemovedInV2 {}\n *\n * model Foo {\n *   name: string;\n *\n *   @removed(Versions.v3)\n *   removedInV3: string;\n * }\n * ```\n */\nextern dec removed(\n  target:\n    | Model\n    | ModelProperty\n    | Operation\n    | Enum\n    | EnumMember\n    | Union\n    | UnionVariant\n    | Scalar\n    | Interface,\n  version: EnumMember\n);\n\n/**\n * Identifies when the target has been renamed.\n * @param version The version that the target was renamed in.\n * @param oldName The previous name of the target.\n *\n * @example\n * ```tsp\n * @renamedFrom(Versions.v2, "oldName")\n * op newName(): void;\n * ```\n */\nextern dec renamedFrom(\n  target:\n    | Model\n    | ModelProperty\n    | Operation\n    | Enum\n    | EnumMember\n    | Union\n    | UnionVariant\n    | Scalar\n    | Interface,\n  version: EnumMember,\n  oldName: valueof string\n);\n\n/**\n * Identifies when a target was made optional.\n * @param version The version that the target was made optional in.\n *\n * @example\n *\n * ```tsp\n * model Foo {\n *   name: string;\n *   @madeOptional(Versions.v2)\n *   nickname?: string;\n * }\n * ```\n */\nextern dec madeOptional(target: ModelProperty, version: EnumMember);\n\n/**\n * Identifies when a target was made required.\n * @param version The version that the target was made required in.\n *\n * @example\n *\n * ```tsp\n * model Foo {\n *   name: string;\n *   @madeRequired(Versions.v2)\n *   nickname: string;\n * }\n * ```\n */\nextern dec madeRequired(target: ModelProperty, version: EnumMember);\n\n/**\n * Identifies when the target type changed.\n * @param version The version that the target type changed in.\n * @param oldType The previous type of the target.\n */\nextern dec typeChangedFrom(target: ModelProperty, version: EnumMember, oldType: unknown);\n\n/**\n * Identifies when the target type changed.\n * @param version The version that the target type changed in.\n * @param oldType The previous type of the target.\n */\nextern dec returnTypeChangedFrom(target: Operation, version: EnumMember, oldType: unknown);\n',
  "lib/auth.tsp": 'import "@typespec/http";\nimport "@typespec/rest";\nimport "@typespec/versioning";\nimport "./traits.tsp";\n\nusing Http;\nusing Rest;\nusing Versioning;\nusing Azure.Core.Traits;\nusing Azure.Core.Traits.Private;\n\nnamespace Azure.Core;\n\n/**\n * Azure Active Directory (AAD) Token Authentication Flow\n * @template AuthUrl The authorization URL.\n * @template TokenUrl The token URL.\n * @template Scopes A list of scopes the token applies to.\n */\nmodel AadTokenAuthFlow<Scopes extends string[], AuthUrl extends string, TokenUrl extends string>\n  extends TypeSpec.Http.AuthorizationCodeFlow {\n  type: OAuth2FlowType.authorizationCode;\n  authorizationUrl: AuthUrl;\n  tokenUrl: TokenUrl;\n  scopes: Scopes;\n}\n\n/**\n * Azure Active Directory OAuth2 Flow\n * @template AuthUrl The authorization URL.\n * @template TokenUrl The token URL.\n * @template Scopes A list of scopes the token applies to.\n */\n@doc("The Azure Active Directory OAuth2 Flow")\nmodel AadOauth2Auth<\n  Scopes extends string[],\n  AuthUrl extends string = "https://login.microsoftonline.com/common/oauth2/authorize",\n  TokenUrl extends string = "https://login.microsoftonline.com/common/oauth2/token"\n> is OAuth2Auth<[AadTokenAuthFlow<Scopes, AuthUrl, TokenUrl>]>;\n\n/**\n * Azure API Key Authentication using the "Ocp-Apim-Subscription-Key" hea\n */\n@doc("Azure API Key Authentication")\nmodel AzureApiKeyAuthentication\n  is TypeSpec.Http.ApiKeyAuth<ApiKeyLocation.header, "Ocp-Apim-Subscription-Key">;\n',
  "lib/traits.tsp": 'import "@typespec/versioning";\n\nnamespace Azure.Core.Traits;\n\nusing Reflection;\nusing Versioning;\n\n/**\n * Enumerates the standard trait locations for Azure.Core operations.\n */\n@added(Azure.Core.Versions.v1_0_Preview_2)\n@doc("Enumerates the standard trait locations for Azure.Core operations.")\nenum TraitLocation {\n  @doc("Identifies operation parameters as the trait target.")\n  Parameters,\n\n  @doc("Identifies operation response as the trait target.")\n  Response,\n\n  @doc("Identifies the API version parameter as the trait target.")\n  ApiVersionParameter,\n}\n\n/**\n * Enumerates the standard trait contexts for Azure.Core operations.\n */\n@added(Azure.Core.Versions.v1_0_Preview_2)\n@doc("")\nenum TraitContext {\n  @doc("Trait is applicable for resource \'read\' operations.")\n  Read,\n\n  @doc("Trait is applicable for resource \'create\' operations.")\n  Create,\n\n  @doc("Trait is applicable for resource \'update\' operations.")\n  Update,\n\n  @doc("Trait is applicable for resource \'delete\' operations.")\n  Delete,\n\n  @doc("Trait is applicable for resource \'list\' operations.")\n  List,\n\n  @doc("Trait is applicable for resource actions.")\n  Action,\n\n  @doc("Only traits that did not specify a trait context (and therefore always apply) will be exposed.")\n  Undefined,\n}\n\n/**\n * Used to override a trait.\n * @template Trait The trait to override.\n */\n@added(Azure.Core.Versions.v1_0_Preview_2)\n@Private.applyTraitOverride(Trait)\nmodel TraitOverride<Trait extends Model> {}\n\n/**\n * Declares a trait that is applied as a query parameter.\n * @template Parameters The name of the query parameter.\n * @template Contexts The contexts in which the trait is applicable.\n */\n@trait\n@added(Azure.Core.Versions.v1_0_Preview_2)\n@Private.ensureAllQueryParams(Parameters)\nmodel QueryParametersTrait<Parameters extends Model, Contexts = unknown> {\n  @traitContext(Contexts)\n  queryParams: {\n    @traitLocation(TraitLocation.Parameters)\n    parameters: Parameters;\n  };\n}\n\n/**\n * Declares a trait that is applied as a query parameter for list operations.\n * @template Parameters Object describing the query parameters.\n */\n@trait\n@added(Azure.Core.Versions.v1_0_Preview_2)\nmodel ListQueryParametersTrait<Parameters extends Model>\n  is QueryParametersTrait<Parameters, TraitContext.List>;\n\n/**\n * Declares a trait that is applied as a request header parameter.\n * @template Headers Object describing the request header parameters.\n * @template Contexts The contexts in which the trait is applicable.\n */\n@trait\n@added(Azure.Core.Versions.v1_0_Preview_2)\n@Private.ensureAllHeaderParams(Headers)\nmodel RequestHeadersTrait<Headers extends Model, Contexts = unknown> {\n  @traitContext(Contexts)\n  requestHeaders: {\n    @traitLocation(TraitLocation.Parameters)\n    parameters: Headers;\n  };\n}\n\n/**\n * Declares a trait that is applied as a response header parameter.\n * @template Headers Object describing the response header parameters.\n * @template Contexts The contexts in which the trait is applicable.\n */\n@trait\n@added(Azure.Core.Versions.v1_0_Preview_2)\n@Private.ensureAllHeaderParams(Headers)\nmodel ResponseHeadersTrait<Headers extends Model, Contexts = unknown> {\n  @traitContext(Contexts)\n  responseHeaders: {\n    @traitLocation(TraitLocation.Response)\n    parameters: Headers;\n  };\n}\n\n/**\n * Declares a version parameter trait.\n * @template VersionParameter The type of the version parameter.\n */\n@trait("VersionParameter")\n@added(Azure.Core.Versions.v1_0_Preview_2)\nmodel VersionParameterTrait<VersionParameter> {\n  versionParameter: {\n    @traitLocation(TraitLocation.ApiVersionParameter)\n    apiVersionParam: VersionParameter;\n  };\n}\n\n/**\n * Provides clientRequestId headers for requests and responses.\n * @template VersionAdded The version when the trait was added to the specification.\n *           Leave this empty if the trait is always supported.\n */\n@trait("ClientRequestId")\n@traitAdded(VersionAdded)\nmodel SupportsClientRequestId<VersionAdded extends EnumMember | null = null> {\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This inline model is never used directly in operations."\n  clientRequestId: {\n    @traitLocation(TraitLocation.Parameters)\n    parameters: ClientRequestIdHeader;\n\n    @traitLocation(TraitLocation.Response)\n    response: ClientRequestIdHeader;\n  };\n}\n\n/**\n * Indicates that the service or operation does not support clientRequestId headers.\n */\n@trait("ClientRequestId")\nmodel NoClientRequestId {\n  clientRequestId: {};\n}\n\n/**\n * Provides conditional request headers for requests and ETag headers for responses.\n * @template VersionAdded The version when the trait was added to the specification.\n *           Leave this empty if the trait is always supported.\n */\n@trait("ConditionalRequests")\n@traitAdded(VersionAdded)\nmodel SupportsConditionalRequests<VersionAdded extends EnumMember | null = null> {\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This inline model is never used directly in operations."\n  conditionalRequests: {\n    @traitContext(\n      TraitContext.Read | TraitContext.Update | TraitContext.Delete | TraitContext.Create\n    )\n    @traitLocation(TraitLocation.Parameters)\n    parameters: ConditionalRequestHeaders;\n\n    @traitContext(TraitContext.Read | TraitContext.Create | TraitContext.Update)\n    @traitLocation(TraitLocation.Response)\n    response: EtagResponseEnvelope;\n  };\n}\n\n/**\n * Indicates that the service or operation does not support conditional requests.\n */\n@trait("ConditionalRequests")\nmodel NoConditionalRequests {\n  conditionalRequests: {};\n}\n\n/**\n * Provides repeatable request headers for requests and responses.\n * @template VersionAdded The version when the trait was added to the specification.\n *           Leave this empty if the trait is always supported.\n */\n@trait("RepeatableRequests")\n@traitAdded(VersionAdded)\nmodel SupportsRepeatableRequests<VersionAdded extends EnumMember | null = null> {\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This inline model is never used directly in operations."\n  @traitContext(\n    TraitContext.Create | TraitContext.Update | TraitContext.Delete | TraitContext.Action\n  )\n  repeatableRequests: {\n    @traitLocation(TraitLocation.Parameters)\n    parameters: RepeatabilityRequestHeaders;\n\n    @traitLocation(TraitLocation.Response)\n    response: RepeatabilityResponseHeaders;\n  };\n}\n\n/**\n * Indicates that the service or operation does not support repeatable requests.\n */\n@trait("RepeatableRequests")\nmodel NoRepeatableRequests {\n  repeatableRequests: {};\n}\n\n/**\n * `@trait` marks a model type as representing a \'trait\' and performs basic validation\n * checks.\n *\n * @param target The model type to mark as a trait.\n * @param traitName An optional name to uniquely identify the trait.  If unspecified,\n *        the model type name is used.\n */\nextern dec `trait`(target: Model, traitName?: valueof string);\n\n/**\n * `@traitContext` sets the applicable context for a trait on its envelope property.\n *\n * @param target The trait envelope property where the context will be applied.\n * @param contexts An enum member or union of enum members representing the trait\'s\n *        applicable contexts.\n */\nextern dec traitContext(target: ModelProperty, contexts: EnumMember | Union | unknown);\n\n/**\n * `@traitLocation` sets the applicable location for a trait on its envelope property.\n *\n * @param target The trait envelope property where the context will be applied.\n * @param contexts An enum member or union of enum members representing the trait\'s\n *        applicable contexts.\n */\nextern dec traitLocation(target: ModelProperty, contexts: EnumMember);\n\n/**\n * Sets the version for when the trait was added to the specification.  Can be applied\n * to either a trait model type or its envelope property.\n * @param addedVersion The enum member representing the service version.\n */\nextern dec traitAdded(target: Model | ModelProperty, addedVersion: EnumMember | null);\n\nnamespace Private {\n  @added(Azure.Core.Versions.v1_0_Preview_2)\n  @Private.addTraitProperties(Traits, Location, Contexts)\n  model TraitProperties<\n    Traits extends Model,\n    Location extends TypeSpec.Reflection.EnumMember,\n    Contexts = unknown\n  > {}\n\n  @doc("Contains the details of a specific trait expected by an interface or operation.")\n  model ExpectedTrait {\n    @doc("The name of the expected trait.")\n    trait: string;\n\n    @doc("The diagnostic to be raised when the trait is not present.")\n    diagnostic: string;\n  }\n\n  /**\n   * `@traitSource` stores the `traitName` of its original trait on the envelope property.\n   *\n   * @param target The trait envelope property where `traitName` will be stored.\n   * @param traitName The name of the original trait to which this property belongs.\n   */\n  extern dec traitSource(target: ModelProperty, traitName: valueof string);\n\n  /**\n   * Copies trait properties from `traitModel` into `target` which conform to the\n   * specified location and contexts.\n   * @param traitModel The trait model type to be applied.\n   * @param traitLocation The trait location to use for selecting trait properties.\n   * @param traitContexts The trait contexts to use for selecting trait properties.\n   */\n  extern dec addTraitProperties(\n    target: Model,\n    traitModel: Model,\n    traitLocation: EnumMember,\n    traitContexts: EnumMember | Union | unknown\n  );\n\n  /**\n   * `@applyTraitOverride` copies the `traitModel` into `target` and renames its envelope\n   * property to enable the trait to override another trait sharing the same name.\n   *\n   * @param target The model into which the trait will be copied.\n   * @param traitModel The trait model type to be overridden.\n   */\n  extern dec applyTraitOverride(target: Model, traitModel: Model);\n\n  /**\n   * `@ensureTraitsPresent` checks the envelope properties of `traitModel` to ensure all\n   * of the `expectedTraits` are present as envelope properties.\n   *\n   * @param target The interface or operation where the `traitModel` should be checked.\n   * @param traitModel The trait model type to check.\n   * @param expectedTraits The array of `ExpectedTrait` models which describe each expected trait.\n   */\n  extern dec ensureTraitsPresent(\n    target: Interface | TypeSpec.Reflection.Operation,\n    traitModel: Model,\n    expectedTraits: ExpectedTrait[]\n  );\n\n  /**\n   * `@ensureAllQueryParams` checks the properties of `paramModel` to ensure they all are marked\n   * with the `@query` decorator.\n   *\n   * @param target The model type where this check will be established.\n   * @param paramModel The actual model type to check for query parameters.\n   */\n  extern dec ensureAllQueryParams(target: Model, paramModel: Model);\n\n  /**\n   * `@ensureAllHeaderParams` checks the properties of `paramModel` to ensure they all are marked\n   * with the `@header` decorator.\n   *\n   * @param target The model type where this check will be established.\n   * @param paramModel The actual model type to check for header properties.\n   */\n  extern dec ensureAllHeaderParams(target: Model, paramModel: Model);\n}\n',
  "lib/foundations.tsp": `import "@typespec/http";
import "@typespec/rest";
import "@typespec/versioning";
import "./traits.tsp";

using Http;
using Rest;
using Versioning;
using Azure.Core.Traits;
using Azure.Core.Traits.Private;

namespace Azure.Core.Foundations;

/**
 * Enum describing allowed operation states.
 */
@lroStatus
union OperationState {
  @doc("The operation has not started.")
  NotStarted: "NotStarted",

  @doc("The operation is in progress.")
  Running: "Running",

  @doc("The operation has completed successfully.")
  Succeeded: "Succeeded",

  @doc("The operation has failed.")
  Failed: "Failed",

  @doc("The operation has been canceled by the user.")
  Canceled: "Canceled",

  string,
}

/**
 * Provides status details for long running operations.
 * @template StatusResult The type of the operation status result.
 * @template StatusError The type of the operation status error. If not provided, the default error is used.
 */
@doc("Provides status details for long running operations.")
model OperationStatus<StatusResult = never, StatusError = Foundations.Error> {
  @key("operationId")
  @doc("The unique ID of the operation.")
  id: string;

  @doc("The status of the operation")
  status: OperationState;

  @doc("Error object that describes the error when status is \\"Failed\\".")
  error?: StatusError;

  @doc("The result of the operation.")
  result?: StatusResult;
}

/**
 * Conveys the resource instance to an operation as a request body.
 * @template Resource The type of the resource instance.
 */
@added(Azure.Core.Versions.v1_0_Preview_2)
@doc("Conveys the resource instance to an operation as a request body.")
model ResourceBody<Resource> {
  @doc("The resource instance.")
  @body
  resource: Resource;
}

// TODO: There is a ARM linter rule that verifies that
// there is no response body. However, long running
// operations are allowed to have it.
alias ResourceCreatedResponse<Resource extends TypeSpec.Reflection.Model> = TypeSpec.Http.Response<201> &
  Resource;

alias ResourceOkResponse<Resource> = TypeSpec.Http.Response<200> & Resource;

alias ResourceCreatedOrOkResponse<Resource extends TypeSpec.Reflection.Model> = ResourceCreatedResponse<Resource> | ResourceOkResponse<Resource>;

/**
 * Response describing the location of a created resource.
 * @template T The type of the created resource.
 */
model LocationOfCreatedResourceResponse<Resource extends TypeSpec.Reflection.Model>
  is TypeSpec.Http.CreatedResponse {
  @finalLocation
  @TypeSpec.Http.header("Location")
  location: ResourceLocation<Resource>;
}

/**
 * Response describing the location of a resource created with a service-provided name.
 * @template T The type of the created resource.
 */
model LocationOfCreatedResourceWithServiceProvidedNameResponse<Resource extends TypeSpec.Reflection.Model>
  is TypeSpec.Http.AcceptedResponse {
  @finalLocation
  @TypeSpec.Http.header("Location")
  location: ResourceLocation<Resource>;
}

/**
 * Metadata for long running operation status monitor locations.
 * @template StatusResult The type of the operation status result.
 */
@doc("Metadata for long running operation status monitor locations")
model LongRunningStatusLocation<StatusResult = never> {
  @pollingLocation
  @doc("The location for monitoring the operation state.")
  @TypeSpec.Http.header("Operation-Location")
  operationLocation: ResourceLocation<OperationStatus<StatusResult>>;
}

alias AcceptedResponse<Resource = {}> = TypeSpec.Http.AcceptedResponse & Resource;

/**
 * A response containing error details.
 * @template Error The type of the error object.
 */
@error
@doc("A response containing error details.")
model ErrorResponseBase<Error> {
  @doc("The error object.")
  error: Error;

  @header("x-ms-error-code")
  @doc("String error code indicating what went wrong.")
  errorCode?: string;
}

model ErrorResponse is ErrorResponseBase<Error>;

@doc("The ApiVersion query parameter.")
model ApiVersionParameter {
  @query("api-version")
  @minLength(1)
  @doc("The API version to use for this operation.")
  apiVersion: string;
}

@doc("The retry-after envelope.")
model RetryAfterHeader {
  @doc("The Retry-After header can indicate how long the client should wait before polling the operation status.")
  @header("Retry-After")
  retryAfter?: int32;
}

@doc("The error object.")
model Error {
  @doc("One of a server-defined set of error codes.")
  code: string;

  @doc("A human-readable representation of the error.")
  message: string;

  @doc("The target of the error.")
  target?: string;

  #suppress "@azure-tools/typespec-providerhub/no-identifier-property-in-array-item" "Error items have no unique identifier."
  @doc("An array of details about specific errors that led to this reported error.")
  details?: Error[];

  @doc("An object containing more specific information than the current object about the error.")
  innererror?: InnerError;
}

@doc("An object containing more specific information about the error. As per Microsoft One API guidelines - https://github.com/microsoft/api-guidelines/blob/vNext/azure/Guidelines.md#handling-errors.")
model InnerError {
  @doc("One of a server-defined set of error codes.")
  code?: string;

  @doc("Inner error.")
  innererror?: InnerError;
}

/**
 * Version of a model for a create or replace operation which only includes updateable properties.
 * @template Resource The type of the resource.
 */
@omitKeyProperties
model ResourceCreateOrReplaceModel<Resource extends TypeSpec.Reflection.Model>
  is UpdateableProperties<DefaultKeyVisibility<Resource, Lifecycle.Read>>;

/**
 * Collection of properties from a resource that are visible to create or update scopes.
 * @template Resource The type of the resource.
 */
@withVisibility(Lifecycle.Create, Lifecycle.Update)
model CreateableAndUpdateableProperties<Resource> {
  ...Resource;
}

/**
 * Version of a model for a create or update operation which only includes updateable properties.
 * @template Resource The type of the resource.
 */
@omitKeyProperties
model ResourceCreateOrUpdateModel<Resource>
  is OptionalProperties<CreateableAndUpdateableProperties<DefaultKeyVisibility<
    Resource,
    Lifecycle.Read
  >>>;

/**
 * Version of a model for an update operation which only includes updateable properties.
 * @template Resource The type of the resource.
 */
@omitKeyProperties
model ResourceUpdateModel<Resource>
  is OptionalProperties<UpdateableProperties<DefaultKeyVisibility<Resource, Lifecycle.Read>>>;

/**
 * A model containing the keys of the provided resource.
 * @template Resource The type of the resource.
 */
@copyResourceKeyParameters
model ItemKeysOf<Resource> {}

/**
 * A model containing the collection keys of the provided resource's parent resource.
 * @template Resource The type of the resource.
 */
@copyResourceKeyParameters("parent")
model CollectionKeysOf<Resource> {}

/**
 * A model describing a set of custom request parameters.
 * @template Custom An object describing custom request parameters.
 */
@Private.spreadCustomParameters(Custom)
model CustomParameters<Custom extends TypeSpec.Reflection.Model> {}

/**
 * A model describing a set of custom response properties.
 * @template Custom An object describing custom response properties.
 */
@Private.spreadCustomResponseProperties(Custom)
model CustomResponseFields<Custom extends TypeSpec.Reflection.Model> {}

/**
 * A model describing a customized page of resources.
 * @template Resource The type of the resource.
 * @template Traits Traits which apply to the page.
 */
@pagedResult
@friendlyName("Paged{name}", Resource)
@doc("Paged collection of {name} items", Resource)
model CustomPage<
  Resource extends TypeSpec.Reflection.Model,
  Traits extends TypeSpec.Reflection.Model = {}
> {
  @doc("The {name} items on this page", Resource)
  @items
  value: Resource[];

  @doc("The link to the next page of items")
  @nextLink
  nextLink?: ResourceLocation<Resource>;

  // Include custom response fields
  ...TraitProperties<Traits, TraitLocation.Response, TraitContext.List>;
}

/**
 * The expected shape of model types passed to the Custom parameter of operation signatures.
 */
@doc("The expected shape of model types passed to the Custom parameter of operation signatures.")
model CustomizationFields {
  @doc("An object containing custom parameters that will be included in the operation.")
  parameters?: {};

  @doc("An object containing custom properties that will be included in the response.")
  response?: {};
}

// Basic Operation Shapes

/**
 * The most basic operation.
 * @template Parameters Object describing the request parameters of the operation.
 * @template Response Object describing the response properties of the operation.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
op Operation<
  Parameters extends TypeSpec.Reflection.Model,
  Response,
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
>(
  ...TraitProperties<
    Traits & VersionParameterTrait<ApiVersionParameter>,
    TraitLocation.ApiVersionParameter
  >,
  ...Parameters,
): Response | ErrorResponse;

/**
 * Long-running operation.
 * @template Parameters Object describing the request parameters of the operation.
 * @template Response Object describing the response properties of the operation. If not provided, the AcceptedResponse type will be used.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
#suppress "@azure-tools/typespec-providerhub/no-inline-model" "This operation signature is not used in Azure Resource Manager operations (yet)"
op LongRunningOperation<
  Parameters extends TypeSpec.Reflection.Model,
  Response = AcceptedResponse,
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
> is Operation<Parameters, Response & Foundations.LongRunningStatusLocation, Traits, ErrorResponse>;

/**
 * Operation that returns the status of another operation.
 * @template Parameters Object describing the request parameters of the operation.
 * @template StatusResult The type of the operation status result.
 * @template StatusError The type of the operation status error.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
op GetOperationStatus<
  Parameters = {},
  StatusResult = never,
  StatusError = Error,
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
> is Foundations.Operation<
  Parameters & {
    @doc("The unique ID of the operation.")
    @path
    operationId: string;
  },
  OperationStatus<StatusResult, StatusError>,
  Traits,
  ErrorResponse
>;

// Fundamental Resource Operation Shapes

/**
 * The most basic operation that applies to a resource.
 * @template Resource The type of the resource.
 * @template Parameters Object describing the request parameters of the operation.
 * @template Response Object describing the response properties of the operation.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
#suppress "@azure-tools/typespec-azure-resource-manager/no-response-body" "This operation must return a status monitor in its response."
@autoRoute
@Private.ensureResourceType(Resource)
op ResourceOperation<
  Resource extends TypeSpec.Reflection.Model,
  Parameters extends TypeSpec.Reflection.Model,
  Response,  // No constraint here on purpose, some responses are unions
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
> is Operation<Foundations.ItemKeysOf<Resource> & Parameters, Response, Traits, ErrorResponse>;

/**
 * Operation that applies to a collection of resources.
 * @template Resource The type of the resource.
 * @template Parameters Object describing the request parameters of the operation.
 * @template Response Object describing the response properties of the operation.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
#suppress "@azure-tools/typespec-azure-resource-manager/no-response-body" "This operation must return a status monitor in its response."
@autoRoute
@Private.ensureResourceType(Resource)
op ResourceCollectionOperation<
  Resource extends TypeSpec.Reflection.Model,
  Parameters extends TypeSpec.Reflection.Model,
  Response extends TypeSpec.Reflection.Model,
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
> is Operation<
  Foundations.CollectionKeysOf<Resource> & Parameters,
  Response,
  Traits,
  ErrorResponse
>;

/**
 * Operation that lists resources in a paginated way.
 * @template Resource The type of the resource.
 * @template Parameters Object describing the request parameters of the operation.
 * @template Response Object describing the response properties of the operation.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
@listsResource(Resource)
@Private.ensureResourceType(Resource)
op ResourceList<
  Resource extends TypeSpec.Reflection.Model,
  Parameters extends TypeSpec.Reflection.Model,
  Response extends TypeSpec.Reflection.Model,
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
> is ResourceCollectionOperation<Resource, Parameters, Response, Traits, ErrorResponse>;

/**
 * Operation that lists resources in a non-paginated way.
 * @template Resource The type of the resource.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
#suppress "@azure-tools/typespec-providerhub/no-inline-model" "This operation signature is not used in Azure Resource Manager operations (yet)"
@autoRoute
op NonPagedResourceList<
  Resource extends TypeSpec.Reflection.Model,
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
> is Foundations.ResourceList<
  Resource,
  TraitProperties<Traits, TraitLocation.Parameters, TraitContext.List>,
  Body<Resource[]> & TraitProperties<Traits, TraitLocation.Response, TraitContext.List>,
  Traits,
  ErrorResponse
>;

/**
 * Long-running operation that updates a resource.
 * @template Resource The type of the resource.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
@updatesResource(Resource)
op LongRunningResourceUpdate<
  Resource extends TypeSpec.Reflection.Model,
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
> is Foundations.ResourceOperation<
  Resource,
  {
    @doc("This request has a JSON Merge Patch body.")
    @TypeSpec.Http.header("Content-Type")
    contentType: "application/merge-patch+json";

    ...Foundations.ResourceBody<Resource>;
    ...TraitProperties<Traits, TraitLocation.Parameters, TraitContext.Update>;
  },
  Foundations.ResourceOkResponse<Resource &
    TraitProperties<Traits, TraitLocation.Response, TraitContext.Update> &
    Foundations.LongRunningStatusLocation<Resource>>,
  Traits,
  ErrorResponse
>;
`,
  "lib/models.tsp": 'import "@typespec/http";\nimport "@typespec/rest";\nimport "./traits.tsp";\n\nusing Http;\nusing Rest;\n\nnamespace Azure.Core;\n\n/**\n * Describes a page of resource object.\n * @template Resource The resource type.\n */\n@pagedResult\n@friendlyName("Paged{name}", Resource)\n@doc("Paged collection of {name} items", Resource)\nmodel Page<Resource extends TypeSpec.Reflection.Model> {\n  @doc("The {name} items on this page", Resource)\n  @items\n  value: Resource[];\n\n  @doc("The link to the next page of items")\n  @nextLink\n  nextLink?: ResourceLocation<Resource>;\n}\n\n/**\n * Defines a property as a request parameter.\n * @template Name The parameter name.\n */\n@Foundations.requestParameter(Name)\nmodel RequestParameter<Name extends valueof string> {}\n\n/**\n * Defines a property as a response header.\n * @template Name The header name.\n */\n@Foundations.responseProperty(Name)\nmodel ResponseProperty<Name extends valueof string> {}\n\n/**\n * @dev Provides the status of a resource operation.\n * @template Resource The resource type.\n * @template StatusResult Model describing the status result object. If not specified, the default is the resource type.\n * @template StatusError Model describing the status error object. If not specified, the default is the Foundations.Error.\n */\n@resource("operations")\n@parentResource(Resource)\nmodel ResourceOperationStatus<\n  Resource extends TypeSpec.Reflection.Model,\n  StatusResult = Resource,\n  StatusError = Foundations.Error\n> is Azure.Core.Foundations.OperationStatus<StatusResult, StatusError>;\n\n#suppress "@azure-tools/typespec-providerhub/no-inline-model" "This is acceptable in Azure.Core."\nalias ResourceOperationStatusResponse<\n  Resource extends TypeSpec.Reflection.Model,\n  StatusResult,\n  StatusError\n> = ResourceOperationStatus<Resource, StatusResult, StatusError>;\n\n@doc("Provides the standard \'top\' query parameter for list operations.")\nmodel TopQueryParameter {\n  @query\n  @doc("The number of result items to return.")\n  top?: int32;\n}\n\n@doc("Provides the standard \'skip\' query parameter for list operations.")\nmodel SkipQueryParameter {\n  @query\n  @doc("The number of result items to skip.")\n  skip?: int32 = 0;\n}\n\n@doc("Provides the standard \'maxpagesize\' query parameter for list operations.")\nmodel MaxPageSizeQueryParameter {\n  @query\n  @doc("The maximum number of result items per page.")\n  maxpagesize?: int32;\n}\n\n@doc("Provides the standard \'filter\' query parameter for list operations")\nmodel FilterParameter {\n  @query\n  @doc("The maximum number of result items per page.")\n  filter?: string;\n}\n\n@doc("Provides the standard \'orderby\' query parameter for list operations.")\nmodel OrderByQueryParameter {\n  @query(#{ explode: true })\n  @doc("Expressions that specify the order of returned results.")\n  orderby?: string[];\n}\n\n@doc("Provides the standard \'filter\' query parameter for list operations.")\nmodel FilterQueryParameter {\n  @query\n  @doc("Filter the result list using the given expression.")\n  filter?: string;\n}\n\n@doc("Provides the standard \'select\' query parameter for list operations.")\nmodel SelectQueryParameter {\n  @query(#{ explode: true })\n  @doc("Select the specified fields to be included in the response.")\n  select?: string[];\n}\n\n@doc("Provides the standard \'expand\' query parameter for list operations.")\nmodel ExpandQueryParameter {\n  @query(#{ explode: true })\n  @doc("Expand the indicated resources into the response.")\n  expand?: string[];\n}\n\n@doc("Provides the most common query parameters for list operations.")\nmodel StandardListQueryParameters {\n  ...TopQueryParameter;\n  ...SkipQueryParameter;\n  ...MaxPageSizeQueryParameter;\n}\n\n// https://github.com/microsoft/api-guidelines/blob/vNext/azure/Guidelines.md#conditional-requests\n\n@doc("Provides the \'If-*\' headers to enable conditional (cached) responses")\nmodel ConditionalRequestHeaders {\n  @visibility(Lifecycle.Read, Lifecycle.Query, Lifecycle.Create, Lifecycle.Update, Lifecycle.Delete)\n  @header("If-Match")\n  @doc("The request should only proceed if an entity matches this string.")\n  ifMatch?: string;\n\n  @visibility(Lifecycle.Read, Lifecycle.Query, Lifecycle.Create, Lifecycle.Update, Lifecycle.Delete)\n  @header("If-None-Match")\n  @doc("The request should only proceed if no entity matches this string.")\n  ifNoneMatch?: string;\n\n  @visibility(Lifecycle.Read, Lifecycle.Query, Lifecycle.Create, Lifecycle.Update, Lifecycle.Delete)\n  @header("If-Unmodified-Since")\n  @doc("The request should only proceed if the entity was not modified after this time.")\n  ifUnmodifiedSince?: utcDateTime;\n\n  @visibility(Lifecycle.Read, Lifecycle.Query, Lifecycle.Create, Lifecycle.Update, Lifecycle.Delete)\n  @header("If-Modified-Since")\n  @doc("The request should only proceed if the entity was modified after this time.")\n  ifModifiedSince?: utcDateTime;\n}\n\n@doc("""\n  Provides the \'ETag\' field to enable conditional (cached) requests.  This model can be spread\n  into responses and item models to convey the ETag when it cannot simply conveyed in a header.\n  """)\nmodel EtagProperty {\n  @visibility(Lifecycle.Read)\n  @doc("The entity tag for this resource.")\n  etag: eTag;\n}\n\n@doc("Provides the \'ETag\' header to enable conditional (cached) requests")\nmodel EtagResponseEnvelope {\n  @header("ETag")\n  @visibility(Lifecycle.Read)\n  @doc("The entity tag for the response.")\n  etagHeader?: string;\n}\n\n// https://github.com/microsoft/api-guidelines/blob/vNext/azure/Guidelines.md#repeatability-of-requests\n\n@doc("Provides the \'Repeatability-*\' headers to enable repeatable requests.")\nmodel RepeatabilityRequestHeaders {\n  @visibility(Lifecycle.Create, Lifecycle.Update, Lifecycle.Delete)\n  @header("Repeatability-Request-ID")\n  @doc("An opaque, globally-unique, client-generated string identifier for the request.")\n  repeatabilityRequestId?: string;\n\n  @visibility(Lifecycle.Create, Lifecycle.Update, Lifecycle.Delete)\n  @doc("Specifies the date and time at which the request was first created.")\n  @header("Repeatability-First-Sent")\n  repeatabilityFirstSent?: utcDateTime;\n}\n\n@doc("Provides the \'Repeatability-*\' headers to enable repeatable requests.")\nmodel RepeatabilityResponseHeaders {\n  @visibility(Lifecycle.Read)\n  @header("Repeatability-Result")\n  @doc("Indicates whether the repeatable request was accepted or rejected.")\n  repeatabilityResult?: RepeatabilityResult;\n}\n\n/** Repeatability Result header options */\nunion RepeatabilityResult {\n  /** If the request was accepted and the server guarantees that the server state reflects a single execution of the operation. */\n  "accepted",\n\n  /**\n   * If the request was rejected because the combination of Repeatability-First-Sent and Repeatability-Request-ID were invalid\n   *  or because the Repeatability-First-Sent value was outside the range of values held by the server.\n   */\n  "rejected",\n}\n\n// https://github.com/microsoft/api-guidelines/blob/vNext/azure/Guidelines.md#distributed-tracing--telemetry\n\n@doc("Provides the \'x-ms-client-request-id\' header to enable request correlation in requests and responses.")\nmodel ClientRequestIdHeader {\n  @header("x-ms-client-request-id")\n  @doc("An opaque, globally-unique, client-generated string identifier for the request.")\n  clientRequestId?: uuid;\n}\n\n@doc("Provides the \'x-ms-request-id\' header to enable request correlation in responses.")\nmodel RequestIdResponseHeader {\n  @visibility(Lifecycle.Read)\n  @header("x-ms-request-id")\n  @doc("An opaque, globally-unique, server-generated string identifier for the request.")\n  requestId?: uuid;\n}\n\n/**\n * A vector embedding frequently used in similarity search.\n * @template Element The element type of the embedding vector.\n */\n@Foundations.Private.embeddingVector(Element)\nmodel EmbeddingVector<Element extends numeric = float32> is Array<Element>;\n\n/**\n * Options for overriding a polling endpoint that uses a StatusMonitor\n * @template PollingModel The model that is returned when polling should continue.\n * @template FinalResult The model that is returned when polling terminates successfully.\n * @template FinalProperty The property of the status monitor that contains results.\n */\nmodel StatusMonitorPollingOptions<\n  PollingModel extends TypeSpec.Reflection.Model | void = never,\n  FinalResult extends TypeSpec.Reflection.Model | void = never,\n  FinalProperty extends TypeSpec.Reflection.ModelProperty | string = never\n> extends StatusMonitorOptions {\n  /** The kind of polling options */\n  kind: PollingOptionKind.statusMonitor;\n\n  /** The model that is returned when polling should continue */\n  pollingModel: PollingModel;\n\n  /** The model that is returned when polling terminates successfully */\n  finalResult: FinalResult;\n\n  /** The property of the status monitor that contains results */\n  finalProperty: FinalProperty;\n}\n\n/** Options for Lro status monitors. */\nmodel StatusMonitorOptions extends PollingOptions {\n  /** The kind of polling options */\n  kind: PollingOptionKind.statusMonitor;\n\n  /** A reference to or name of the property of the status monitor that contains the response */\n  finalProperty?: TypeSpec.Reflection.ModelProperty | string;\n}\n\n/** Generic polling options for LRO operations. */\nmodel PollingOptions {\n  /** The kind of polling options */\n  kind: PollingOptionKind;\n\n  /** The model that is returned when polling should continue. */\n  pollingModel?: TypeSpec.Reflection.Model | void;\n\n  /** The type that is returned when polling terminates successfully. */\n  finalResult?: TypeSpec.Reflection.Model | void;\n}\n\n/** The available kinds of polling options */\nunion PollingOptionKind {\n  /** Polling options for a status monitor */\n  statusMonitor: "statusMonitor",\n\n  string,\n}\n\n/**\n * Universally Unique Identifier\n *\n * @example\n *\n * ```\n * 123e4567-e89b-12d3-a456-426614174000\n * ```\n */\n@format("uuid")\nscalar uuid extends string;\n\n/**\n * Represent an IP V4 address serialized as a string.\n *\n * It is formatted as four 8-bit fields separated by periods.\n *\n * @example\n *\n * ```\n * 129.144.50.56\n * ```\n */\n#suppress "@azure-tools/typespec-autorest/invalid-format" "Foundation."\n@format("ipV4Address")\nscalar ipV4Address extends string;\n\n/**\n * Represent an IP V6 address serialized as a string.\n *\n * It is formatted as eight hex decimal values(16-bit) between 0 and FFFF separated by colon. (i.e. `y:y:y:y:y:y:y:y`)\n *\n * @example\n *\n * ```\n * 2001:db8:3333:4444:CCCC:DDDD:EEEE:FFFF\n * ```\n */\n#suppress "@azure-tools/typespec-autorest/invalid-format" "Foundation."\n@format("ipV6Address")\nscalar ipV6Address extends string;\n\n/**\n * The ETag (or entity tag) HTTP response header is an identifier for a specific version of a resource.\n * It lets caches be more efficient and save bandwidth, as a web server does not need to resend a full response if the content was not changed.\n *\n * It is a string of ASCII characters placed between double quotes, like "675af34563dc-tr34".\n *\n * @example In `ETag` header\n *\n * ```\n * ETag: "675af34563dc-tr34"\n * ```\n */\n#suppress "@azure-tools/typespec-autorest/invalid-format" "Foundation."\n@format("eTag")\nscalar eTag extends string;\n\n/**\n * Represents an Azure geography region where supported resource providers live.\n *\n * @example\n *\n * ```\n * WestUS\n * ```\n */\nscalar azureLocation extends string;\n\n/**\n * Represents an Azure Resource Type.\n *\n * @example\n *\n * ```\n * Microsoft.Network/virtualNetworks/subnets\n * ```\n */\nscalar armResourceType extends string;\n\n/**\n * A type definition that refers the id to an Azure Resource Manager resource.\n *\n * @template AllowedResourceTypes An array of allowed resource types for the resource reference\n *\n * @example\n *\n * ```tsp\n * model MyModel {\n *   otherArmId: armResourceIdentifier;\n *   networkId: armResourceIdentifier<[{type:"Microsoft.Network/vnet"}]>\n *   vmIds: armResourceIdentifier<[{type:"Microsoft.Compute/vm", scopes: ["*"]}]>\n *   scoped: armResourceIdentifier<[{type:"Microsoft.Compute/vm", scopes: ["tenant", "resourceGroup"]}]>\n * }\n * ```\n */\n@doc("A type definition that refers the id to an Azure Resource Manager resource.")\n@format("arm-id")\n@Azure.Core.Foundations.Private.armResourceIdentifierConfig({\n  allowedResources: AllowedResourceTypes,\n})\nscalar armResourceIdentifier<AllowedResourceTypes extends ArmResourceIdentifierAllowedResource[] = never>\n  extends string;\n\n// Consider replacing `*`\nunion ArmResourceDeploymentScope {\n  "tenant",\n  "subscription",\n  "resourceGroup",\n  "managementGroup",\n  "extension",\n}\n\nalias AllArmResourceDeploymentScopes = [\n  "tenant",\n  "subscription",\n  "resourceGroup",\n  "managementGroup",\n  "extension"\n];\n\nmodel ArmResourceIdentifierAllowedResource {\n  /** The type of resource that is being referred to. For example Microsoft.Network/virtualNetworks or Microsoft.Network/virtualNetworks/subnets. See Example Types for more examples. */\n  type: armResourceType;\n\n  /**\n   * An array of scopes. If not specified, the default scope is ["ResourceGroup"].\n   * See [Allowed Scopes](https://github.com/Azure/autorest/tree/main/docs/extensions#allowed-scopes).\n   */\n  scopes?: ArmResourceDeploymentScope[];\n}\n',
  "lib/operations.tsp": 'import "@typespec/http";\nimport "@typespec/rest";\nimport "@typespec/versioning";\nimport "./models.tsp";\nimport "./traits.tsp";\n\nnamespace Azure.Core;\n\nusing Http;\nusing Rest;\nusing Versioning;\nusing Azure.Core.Traits;\nusing Azure.Core.Traits.Private;\n\n// RPC Operations\n\n/**\n * A remote procedure call (RPC) operation.\n * @template Parameters Object describing the parameters of the operation.\n * @template Response Object describing the response of the operation.\n * @template Traits Object describing the traits of the operation.\n * @template ErrorResponse Error response of the operation. If not specified, the default error response is used.\n * @template TraitContexts Trait contexts applicable to the operation. Defaults to `TraitContext.Undefined` which means that only traits that always apply will appear. Can specify multiple using the | operator.\n */\n@Foundations.Private.needsRoute\nop RpcOperation<\n  Parameters extends TypeSpec.Reflection.Model,\n  Response extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {},\n  ErrorResponse = Azure.Core.Foundations.ErrorResponse,\n  TraitContexts extends TraitContext = TraitContext.Undefined\n> is Foundations.Operation<\n  Parameters & TraitProperties<Traits, TraitLocation.Parameters>,\n  Response & TraitProperties<Traits, TraitLocation.Response, TraitContexts>,\n  Traits,\n  ErrorResponse\n>;\n\n/**\n * A long-running remote procedure call (RPC) operation.\n * @template Parameters Object describing the parameters of the operation.\n * @template Response Object describing the response of the operation.\n * @template StatusResult Object describing the status result of the operation.\n * @template StatusError Error response of the status operation. If not specified, the default error response is used.\n * @template Traits Object describing the traits of the operation.\n * @template ErrorResponse Error response of the operation. If not specified, the default error response is used.\n * @template TraitContexts Trait contexts applicable to the operation. Defaults to `TraitContext.Undefined` which means that only traits that always apply will appear. Can specify multiple using the | operator.\n */\n@Foundations.Private.needsRoute\n@post\nop LongRunningRpcOperation<\n  Parameters extends TypeSpec.Reflection.Model,\n  Response extends TypeSpec.Reflection.Model,\n  StatusResult extends TypeSpec.Reflection.Model,\n  StatusError = Foundations.Error,\n  Traits extends TypeSpec.Reflection.Model = {},\n  ErrorResponse = Azure.Core.Foundations.ErrorResponse,\n  TraitContexts extends TraitContext = TraitContext.Undefined\n> is Foundations.Operation<\n  Parameters & TraitProperties<Traits, TraitLocation.Parameters>,\n  AcceptedResponse &\n    ResourceOperationStatus<Response, StatusResult, StatusError> &\n    Foundations.LongRunningStatusLocation<StatusResult> &\n    TraitProperties<Traits, TraitLocation.Response, TraitContexts>,\n  Traits,\n  ErrorResponse\n>;\n\n// Standard Resource Lifecycle Operations\n\nalias ExpectedResourceOperationTraits = [\n  {\n    trait: "ConditionalRequests";\n    diagnostic: "conditional-requests-trait-missing";\n  },\n  {\n    trait: "RepeatableRequests";\n    diagnostic: "repeatable-requests-trait-missing";\n  },\n  {\n    trait: "ClientRequestId";\n    diagnostic: "client-request-id-trait-missing";\n  }\n];\n\n/**\n * Interface containing common resource operations.\n * @template InterfaceTraits Traits applicable to the operations.\n * @template ErrorResponse Error response of the operations. If not specified, the default error response is used.\n */\n@ensureTraitsPresent(InterfaceTraits, ExpectedResourceOperationTraits)\ninterface ResourceOperations<\n  InterfaceTraits extends TypeSpec.Reflection.Model,\n  ErrorResponse = Azure.Core.Foundations.ErrorResponse\n> {\n  /**\n   * Create or replace operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("ResourceCreateOrReplace", "PUT")\n  @createsOrReplacesResource(Resource)\n  ResourceCreateOrReplace<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    Foundations.ResourceBody<Resource> &\n      TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Parameters,\n        TraitContext.Create | TraitContext.Update\n      >,\n    Foundations.ResourceCreatedOrOkResponse<Resource &\n      TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Response,\n        TraitContext.Create | TraitContext.Update\n      >>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Long-running resource create or replace operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("LongRunningResourceCreateOrReplace", "PUT")\n  @createsOrReplacesResource(Resource)\n  LongRunningResourceCreateOrReplace<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    Foundations.ResourceBody<Resource> &\n      TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Parameters,\n        TraitContext.Create | TraitContext.Update\n      >,\n    Foundations.ResourceCreatedOrOkResponse<Resource &\n      TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Response,\n        TraitContext.Create | TraitContext.Update\n      > &\n      Foundations.LongRunningStatusLocation>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Create or update operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("ResourceCreateOrUpdate", "PATCH")\n  @createsOrUpdatesResource(Resource)\n  @parameterVisibility(Lifecycle.Create, Lifecycle.Update)\n  @patch(#{ implicitOptionality: true }) // For legacy reasons\n  ResourceCreateOrUpdate<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    {\n      @doc("This request has a JSON Merge Patch body.")\n      @TypeSpec.Http.header("Content-Type")\n      contentType: "application/merge-patch+json";\n\n      ...Foundations.ResourceBody<Resource>;\n      ...TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Parameters,\n        TraitContext.Create | TraitContext.Update\n      >;\n    },\n    Foundations.ResourceCreatedOrOkResponse<Resource &\n      TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Response,\n        TraitContext.Create | TraitContext.Update\n      >>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Long-running resource create or update operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("LongRunningResourceCreateOrUpdate", "PATCH")\n  @createsOrUpdatesResource(Resource)\n  @parameterVisibility(Lifecycle.Create, Lifecycle.Update)\n  @patch(#{ implicitOptionality: true }) // For legacy reasons\n  LongRunningResourceCreateOrUpdate<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    {\n      @doc("This request has a JSON Merge Patch body.")\n      @TypeSpec.Http.header("Content-Type")\n      contentType: "application/merge-patch+json";\n\n      ...Foundations.ResourceBody<Resource>;\n      ...TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Parameters,\n        TraitContext.Create | TraitContext.Update\n      >;\n    },\n    Foundations.ResourceCreatedOrOkResponse<Resource &\n      TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Response,\n        TraitContext.Create | TraitContext.Update\n      > &\n      Foundations.LongRunningStatusLocation<Resource>>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource update operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("ResourceUpdate", "PATCH")\n  @updatesResource(Resource)\n  @patch(#{ implicitOptionality: true }) // For legacy reasons\n  ResourceUpdate<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    {\n      @doc("This request has a JSON Merge Patch body.")\n      @TypeSpec.Http.header("Content-Type")\n      contentType: "application/merge-patch+json";\n\n      ...Foundations.ResourceBody<Resource>;\n      ...TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Update>;\n    },\n    Foundations.ResourceOkResponse<Resource &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Update>>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource create with service-provided name operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This operation signature is not used in Azure Resource Manager operations (yet)"\n  @Foundations.Private.ensureVerb("ResourceCreateWithServiceProvidedName", "POST")\n  @createsResource(Resource)\n  ResourceCreateWithServiceProvidedName<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceCollectionOperation<\n    Resource,\n    Foundations.ResourceBody<Resource> &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Create>,\n    Foundations.LocationOfCreatedResourceResponse<Resource> &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Create>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Long-running resource create with service-provided name operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This operation signature is not used in Azure Resource Manager operations (yet)"\n  @Foundations.Private.ensureVerb("LongRunningResourceCreateWithServiceProvidedName", "POST")\n  @createsResource(Resource)\n  LongRunningResourceCreateWithServiceProvidedName<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceCollectionOperation<\n    Resource,\n    Foundations.ResourceBody<Resource> &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Create>,\n    Foundations.LocationOfCreatedResourceWithServiceProvidedNameResponse<Resource> &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Create>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource read operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("ResourceRead", "GET")\n  @readsResource(Resource)\n  ResourceRead<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Read>,\n    Resource &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Read>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource delete operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This operation signature is not used in Azure Resource Manager operations (yet)"\n  @Foundations.Private.ensureVerb("ResourceDelete", "DELETE")\n  @deletesResource(Resource)\n  ResourceDelete<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Delete>,\n    TypeSpec.Http.NoContentResponse &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Delete>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Long-running resource delete operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  #suppress "@azure-tools/typespec-azure-resource-manager/no-response-body" "We do support bodies in data plane service APIs..."\n  @Foundations.Private.ensureVerb("LongRunningResourceDelete", "DELETE")\n  @deletesResource(Resource)\n  LongRunningResourceDelete<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Delete>,\n    Foundations.AcceptedResponse<Foundations.OperationStatus &\n      Foundations.LongRunningStatusLocation &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Delete>>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource list operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("ResourceList", "GET")\n  ResourceList<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceList<\n    Resource,\n    TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.List>,\n    Foundations.CustomPage<Resource, Traits & InterfaceTraits>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource action operation template.\n   * @template Resource Resource type.\n   * @template Parameters Object describing the parameters of the operation.\n   * @template Response Object describing the response of the operation.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("ResourceAction", "POST")\n  @action\n  @actionSeparator(":")\n  ResourceAction<\n    Resource extends TypeSpec.Reflection.Model,\n    Parameters extends TypeSpec.Reflection.Model,\n    Response extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    Parameters &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Action>,\n    Response &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Action>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource collection action operation template.\n   * @template Resource Resource type.\n   * @template Parameters Object describing the parameters of the operation.\n   * @template Response Object describing the response of the operation.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("ResourceCollectionAction", "POST")\n  @collectionAction(Resource)\n  @actionSeparator(":")\n  ResourceCollectionAction<\n    Resource extends TypeSpec.Reflection.Model,\n    Parameters extends TypeSpec.Reflection.Model,\n    Response extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceCollectionOperation<\n    Resource,\n    Parameters &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Action>,\n    Response &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Action>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Long-running resource action operation template.\n   * @template Resource Resource type.\n   * @template Parameters Object describing the parameters of the operation.\n   * @template StatusResult Object describing the status result of the operation.\n   * @template StatusError Object describing the status error of the operation.\n   * @template Traits Object describing the traits of the operation.\n   */\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This operation signature is not used in Azure Resource Manager operations (yet)"\n  #suppress "@azure-tools/typespec-azure-resource-manager/no-response-body" "This operation must return a status monitor in its response."\n  @Foundations.Private.ensureVerb("LongRunningResourceAction", "POST")\n  @action\n  @actionSeparator(":")\n  LongRunningResourceAction<\n    Resource extends TypeSpec.Reflection.Model,\n    Parameters extends TypeSpec.Reflection.Model,\n    StatusResult extends TypeSpec.Reflection.Model,\n    StatusError = Foundations.Error,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    Parameters &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Action>,\n    AcceptedResponse &\n      ResourceOperationStatus<Resource, StatusResult, StatusError> &\n      Foundations.LongRunningStatusLocation<StatusResult> &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Action>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Long-running resource collection action operation template.\n   * @template Resource Resource type.\n   * @template Parameters Object describing the parameters of the operation.\n   * @template StatusResult Object describing the status result of the operation.\n   * @template StatusError Object describing the status error of the operation.\n   * @template Traits Object describing the traits of the operation.\n   */\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This operation signature is not used in Azure Resource Manager operations (yet)"\n  #suppress "@azure-tools/typespec-azure-resource-manager/no-response-body" "This operation must return a status monitor in its response."\n  @Foundations.Private.ensureVerb("LongRunningResourceCollectionAction", "POST")\n  @autoRoute\n  @collectionAction(Resource)\n  @actionSeparator(":")\n  LongRunningResourceCollectionAction<\n    Resource extends TypeSpec.Reflection.Model,\n    Parameters extends TypeSpec.Reflection.Model,\n    StatusResult extends TypeSpec.Reflection.Model,\n    StatusError = Foundations.Error,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceCollectionOperation<\n    Resource,\n    Parameters &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Action>,\n    AcceptedResponse &\n      ResourceOperationStatus<Resource, StatusResult, StatusError> &\n      Foundations.LongRunningStatusLocation<StatusResult> &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Action>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource operation status operation template.\n   * @template Resource Resource type.\n   * @template StatusResult Object describing the status result of the operation.\n   * @template StatusError Object describing the status error of the operation.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("GetResourceOperationStatus", "GET")\n  @readsResource(ResourceOperationStatus<Resource>)\n  @Foundations.Private.ensureResourceType(Resource)\n  GetResourceOperationStatus<\n    Resource extends TypeSpec.Reflection.Model,\n    StatusResult = Resource,\n    StatusError = Foundations.Error,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    ResourceOperationStatus<Resource, StatusResult, StatusError>,\n    {},\n    ResourceOperationStatusResponse<Resource, StatusResult, StatusError>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n}\n\n// Resource Status Monitoring\n\n/**\n * Operation signature to retrieve a resource operation status.\n * @template Resource The type of the resource.\n * @template StatusResult Object describing the result of the status operation.\n * @template StatusError Object describing the error of the status operation. If not provided, the default error type is used.\n * @template Traits Traits to apply to the operation.\n */\n@readsResource(ResourceOperationStatus<Resource>)\n@Foundations.Private.ensureResourceType(Resource)\nop GetResourceOperationStatus<\n  Resource extends TypeSpec.Reflection.Model,\n  StatusResult = Resource,\n  StatusError = Foundations.Error,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is Foundations.ResourceOperation<\n  ResourceOperationStatus<Resource, StatusResult, StatusError>,\n  {},\n  ResourceOperationStatusResponse<Resource, StatusResult, StatusError>,\n  Traits\n>;\n',
  "lib/obsolete.tsp": '// This file contains operation template that are deprecated and shouldn\'t be used.\nimport "@typespec/http";\nimport "@typespec/rest";\nimport "@typespec/versioning";\nimport "./models.tsp";\nimport "./traits.tsp";\nimport "./operations.tsp";\n\nnamespace Azure.Core;\n\nusing Http;\nusing Rest;\nusing Versioning;\nusing Azure.Core.Traits;\nusing Azure.Core.Traits.Private;\n\nalias StandardResourceOperations = ResourceOperations<NoConditionalRequests &\n  NoRepeatableRequests &\n  NoClientRequestId>;\n\n/**\n * DEPRECATED: Use `ResourceCreateOrReplace` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature to create or replace a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\n#deprecated "Use `ResourceCreateOrReplace` from a `ResourceOperations` interface instance."\nop ResourceCreateOrReplace<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceCreateOrReplace<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `LongRunningResourceCreateOrReplace` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Long-running operation signature to create or replace a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\n#deprecated "Use `LongRunningResourceCreateOrReplace` from a `ResourceOperations` interface instance."\nop LongRunningResourceCreateOrReplace<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.LongRunningResourceCreateOrReplace<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceCreateOrUpdate` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature to create or update a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\n#deprecated "Use `LongRunningResourceCreateOrReplace` from a `ResourceOperations` interface instance."\nop ResourceCreateOrUpdate<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceCreateOrUpdate<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `LongRunningResourceCreateOrUpdate` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Long-running operation signature to create or update a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\n#deprecated "Use `LongRunningResourceCreateOrUpdate` from a `ResourceOperations` interface instance."\nop LongRunningResourceCreateOrUpdate<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.LongRunningResourceCreateOrUpdate<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceUpdate` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n * Operation signature to update a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\n#deprecated "Use `ResourceUpdate` from a `ResourceOperations` interface instance."\nop ResourceUpdate<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceUpdate<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceCreateWithServiceProvidedName` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature to synchronously create a resource with a service-provided name.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\n#deprecated "Use `ResourceCreateWithServiceProvidedName` from a `ResourceOperations` interface instance."\nop ResourceCreateWithServiceProvidedName<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceCreateWithServiceProvidedName<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `LongRunningResourceCreateWithServiceProvidedName` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Long-running operation signature to create a resource with a service-provided name.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\n#deprecated "Use `LongRunningResourceCreateWithServiceProvidedName` from a `ResourceOperations` interface instance."\nop LongRunningResourceCreateWithServiceProvidedName<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.LongRunningResourceCreateWithServiceProvidedName<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceRead` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature to retrieve a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\nop ResourceRead<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceRead<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceDelete` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature to delete a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\nop ResourceDelete<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceDelete<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `LongRunningResourceDelete` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Long-running operation signature to delete a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\nop LongRunningResourceDelete<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.LongRunningResourceDelete<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceList` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature to list resources in a paginated way.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\nop ResourceList<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceList<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceAction` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature for a resource action.\n * @template Resource The type of the resource.\n * @template Parameters Object describing the request parameters.\n * @template Response Object describing the response parameters.\n * @template Traits Traits to apply to the operation.\n */\nop ResourceAction<\n  Resource extends TypeSpec.Reflection.Model,\n  Parameters extends TypeSpec.Reflection.Model,\n  Response extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceAction<Resource, Parameters, Response, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceCollectionAction` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature for an action that applies to a collection of resources.\n * @template Resource The type of the resource.\n * @template Parameters Object describing the request parameters.\n * @template Response Object describing the response parameters.\n * @template Traits Traits to apply to the operation.\n */\nop ResourceCollectionAction<\n  Resource extends TypeSpec.Reflection.Model,\n  Parameters extends TypeSpec.Reflection.Model,\n  Response extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceCollectionAction<Resource, Parameters, Response, Traits>;\n\n/**\n * DEPRECATED: Use `LongRunningResourceAction` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Long-running operation signature for a resource action.\n * @template Resource The type of the resource.\n * @template Parameters Object describing the request parameters.\n * @template StatusResult Object describing the result of the status operation.\n * @template StatusError Object describing the error of the status operation. If not provided, the default error type is used.\n * @template Traits Traits to apply to the operation.\n */\nop LongRunningResourceAction<\n  Resource extends TypeSpec.Reflection.Model,\n  Parameters extends TypeSpec.Reflection.Model,\n  StatusResult extends TypeSpec.Reflection.Model,\n  StatusError = Foundations.Error,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.LongRunningResourceAction<\n  Resource,\n  Parameters,\n  StatusResult,\n  StatusError,\n  Traits\n>;\n\n/**\n * DEPRECATED: Use `LongRunningResourceCollectionAction` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Long-running operation signature for an action that applies to a collection of resources.\n * @template Resource The type of the resource.\n * @template Parameters Object describing the request parameters.\n * @template StatusResult Object describing the result of the status operation.\n * @template StatusError Object describing the error of the status operation. If not provided, the default error type is used.\n * @template Traits Traits to apply to the operation.\n */\nop LongRunningResourceCollectionAction<\n  Resource extends TypeSpec.Reflection.Model,\n  Parameters extends TypeSpec.Reflection.Model,\n  StatusResult extends TypeSpec.Reflection.Model,\n  StatusError = Foundations.Error,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.LongRunningResourceCollectionAction<\n  Resource,\n  Parameters,\n  StatusResult,\n  StatusError,\n  Traits\n>;\n',
  "lib/decorators.tsp": 'using Reflection;\n\nnamespace Azure.Core {\n  /**\n   * Marks an Enum as being fixed since enums in Azure are\n   * assumed to be extensible.\n   */\n  extern dec fixed(target: Enum);\n\n  /**\n   * Marks a Model as a paged collection.\n   */\n  extern dec pagedResult(entity: Model);\n\n  /**\n   * Identifies the ModelProperty that contains the paged items. Can only be used on a Model marked with `@pagedResult`.\n   */\n  extern dec items(entity: ModelProperty);\n\n  /**\n   * Used for custom StatusMonitor implementation.\n   * Identifies an Enum or ModelProperty as containing long-running operation\n   * status.\n   */\n  extern dec lroStatus(entity: Enum | Union | ModelProperty);\n\n  /**\n   * Used for custom StatusMonitor implementation.\n   * Identifies an EnumMember as a long-running "Succeeded" terminal state.\n   */\n  extern dec lroSucceeded(entity: EnumMember | UnionVariant);\n\n  /**\n   * Used for custom StatusMonitor implementation.\n   * Identifies an EnumMember as a long-running "Canceled" terminal state.\n   */\n  extern dec lroCanceled(entity: EnumMember | UnionVariant);\n\n  /**\n   * Used for custom StatusMonitor implementation.\n   * Identifies an enum member as a long-running "Failed" terminal state.\n   */\n  extern dec lroFailed(entity: EnumMember | UnionVariant);\n\n  /**\n   * Used for custom StatusMonitor implementation.\n   * Identifies a model property of a StatusMonitor as containing the result\n   * of a long-running operation that terminates successfully (Succeeded).\n   */\n  extern dec lroResult(entity: ModelProperty);\n\n  /**\n   * Used for custom StatusMonitor implementation.\n   * Identifies a model property of a StatusMonitor as containing the result\n   * of a long-running operation that terminates unsuccessfully (Failed).\n   */\n  extern dec lroErrorResult(entity: ModelProperty);\n\n  /**\n   * Identifies a model property as containing the location to poll for operation state.\n   * @param options PollingOptions for the poller pointed to by this link.  Overrides\n   * settings derived from property value it is decorating, if the value of the\n   * property is ResourceLocation<Resource>\n   */\n  extern dec pollingLocation(entity: ModelProperty, options?: PollingOptions);\n\n  /**\n   * Identifies a ModelProperty as containing the final location for the operation result.\n   * @param finalResult Sets the expected return value for the final result.  Overrides\n   * any value provided in the decorated property, if the property uses ResourceLocation<Resource>.\n   */\n  extern dec finalLocation(entity: ModelProperty, finalResult?: Model | void);\n\n  /**\n   * Identifies an operation that is linked to the target operation.\n   * @param linkedOperation The linked Operation\n   * @param linkType A string indicating the role of the linked operation\n   * @param parameters Map of `RequestParameter<Name>` and/or `ResponseProperty<Name>` that will\n   * be passed to the linked operation request.\n   */\n  extern dec operationLink(\n    entity: Operation,\n    linkedOperation: Operation,\n    linkType: valueof string,\n    parameters?: {}\n  );\n\n  /**\n   * Used to define how to call custom polling operations for long-running operations.\n   *\n   * @param targetParameter A reference to the polling operation parameter this parameter\n   * provides a value for, or the name of that parameter. The default value is the name of\n   * the decorated parameter or property.\n   */\n  extern dec pollingOperationParameter(\n    entity: ModelProperty,\n    targetParameter?: ModelProperty | string\n  );\n\n  /**\n   * Identifies that an operation is a polling operation for an LRO.\n   * @param linkedOperation The linked Operation\n   * @param parameters Map of `RequestParameter<Name>` and/or `ResponseProperty<Name>` that will\n   * be passed to the linked operation request.\n   */\n  extern dec pollingOperation(entity: Operation, linkedOperation: Operation, parameters?: {});\n\n  /**\n   * Identifies that an operation is the final operation for an LRO.\n   * @param linkedOperation The linked Operation\n   * @param parameters Map of `RequestParameter<Name>` and/or `ResponseProperty<Name>` that will\n   * be passed to the linked operation request.\n   */\n  extern dec finalOperation(entity: Operation, linkedOperation: Operation, parameters?: {});\n\n  /**\n   * Overrides the final state value for an operation\n   * @param finalState The desired final state value\n   */\n  extern dec useFinalStateVia(\n    entity: Operation,\n    finalState: valueof "original-uri" | "operation-location" | "location" | "azure-async-operation"\n  );\n\n  /**\n   * Identifies that an operation is used to retrieve the next page for paged operations.\n   * @param linkedOperation The linked Operation\n   * @param parameters Map of `RequestParameter<Name>` and/or `ResponseProperty<Name>` that will\n   * be passed to the linked operation request.\n   */\n  extern dec nextPageOperation(entity: Operation, linkedOperation: Operation, parameters?: {});\n}\n\nnamespace Azure.Core.Foundations {\n  /**\n   * Deletes any key properties from the model.\n   */\n  extern dec omitKeyProperties(entity: Model);\n\n  /**\n   * Identifies a property on a request model that serves as a linked operation parameter.\n   * @param name Property name on the target\n   */\n  extern dec requestParameter(entity: Model, name: valueof string);\n\n  /**\n   * Identifies a property on *all* non-error response models that serve as a linked operation parameter.\n   * @param name Property name on the target\n   */\n  extern dec responseProperty(entity: Model, name: valueof string);\n}\n\nnamespace Azure.Core.Foundations.Private {\n  /**\n   * Provides a Model describing parameter customizations to spread into the target.\n   * @param customizations Model describing the customization to spread\n   */\n  extern dec spreadCustomParameters(entity: Model, customizations: Model);\n\n  /**\n   * Provides a Model describing response property customizations to spread into the target.\n   * @param customizations Model describing the customization to spread\n   */\n  extern dec spreadCustomResponseProperties(entity: Model, customizations: Model);\n\n  /**\n   * Checks the Resource parameter of an operation signature to ensure it\'s a valid resource type.\n   * Also marks the operation as a resource operation.\n   * @param resourceType The possible resource Type to validate.\n   */\n  extern dec ensureResourceType(entity: TypeSpec.Reflection.Operation, resourceType: unknown);\n\n  /**\n   * Checks the Resource parameter of an operation signature to ensure it\'s a valid resource type.\n   */\n  extern dec needsRoute(entity: TypeSpec.Reflection.Operation);\n\n  /**\n   * Issues a warning if an operation which derives from an operation templated marked with `@ensureVerb`\n   * differs from the verb specified.\n   * @param templateName: Name of the template operation.\n   * @param verb The intended HTTP verb.\n   */\n  extern dec ensureVerb(\n    entity: TypeSpec.Reflection.Operation,\n    templateName: valueof string,\n    verb: valueof string\n  );\n\n  /**\n   * Identifies that a model should be treated as an embedding vector.\n   */\n  extern dec embeddingVector(entity: TypeSpec.Reflection.Model, type: TypeSpec.Reflection.Scalar);\n\n  model ArmResourceIdentifierConfigOptions {\n    allowedResources: ArmResourceIdentifierAllowedResource[];\n  }\n\n  /** Configuration for the armResourceIdentifier scalar */\n  extern dec armResourceIdentifierConfig(\n    target: Scalar,\n    options: ArmResourceIdentifierConfigOptions\n  );\n\n  /**\n   * Sets the priority order of default final-state-via options for an operation\n   * @param states: list of final-state-via options in priority order\n   */\n  extern dec defaultFinalStateVia(\n    target: TypeSpec.Reflection.Operation,\n    states: valueof ("operation-location" | "location" | "azure-async-operation")[]\n  );\n\n  /**\n   * Internal decorator marking a scalar as a next link that requires parameterization before use.\n   *\n   * You most likely don\'t need to use this decorator since next links that require parameterization are against\n   * guidelines.\n   */\n  extern dec parameterizedNextLinkConfig(target: Scalar, parameters: ModelProperty[]);\n}\n',
  "lib/legacy.tsp": "using TypeSpec.Reflection;\n\nnamespace Azure.Core.Legacy;\n\n/**\n * A scalar type representing a next link that requires formatting with parameters to be used.\n *\n * @example\n * ```typespec\n * model ListCertificateOptions {\n *   includePending?: string;\n * }\n * model Certificate {\n *   name: string;\n * }\n * model Page {\n *   @items items: Certificate[];\n *   @nextLink nextLink: Azure.Core.Legacy.parameterizedNextLink<[ListCertificateOptions.includePending]>;\n * }\n * ```\n */\n@Azure.Core.Foundations.Private.parameterizedNextLinkConfig(TypeSpec.Reflection.ModelProperty[])\nscalar parameterizedNextLink<ParameterizedParams extends TypeSpec.Reflection.ModelProperty[]>\n  extends url;\n"
};
var _TypeSpecLibrary_ = {
  jsSourceFiles: TypeSpecJSSources,
  typespecSourceFiles: TypeSpecSources
};
export {
  $addTraitProperties,
  $applyTraitOverride,
  $armResourceIdentifierConfig,
  $decorators2 as $decorators,
  $defaultFinalStateVia,
  $embeddingVector,
  $ensureAllHeaderParams,
  $ensureAllQueryParams,
  $ensureResourceType,
  $ensureTraitsPresent,
  $ensureVerb,
  $finalLocation,
  $finalOperation,
  $fixed,
  $items,
  $lib,
  $linter,
  $lroCanceled,
  $lroErrorResult,
  $lroFailed,
  $lroResult,
  $lroStatus,
  $lroSucceeded,
  $needsRoute,
  $nextPageOperation,
  $omitKeyProperties,
  $operationLink,
  $pagedResult,
  $pollingLocation,
  $pollingOperation,
  $pollingOperationParameter,
  $requestParameter,
  $responseProperty,
  $spreadCustomParameters,
  $spreadCustomResponseProperties,
  $trait,
  $traitAdded,
  $traitContext,
  $traitLocation,
  $traitSource,
  $useFinalStateVia,
  FinalOperationKey,
  FinalStateValue,
  PollingOperationKey,
  _TypeSpecLibrary_,
  checkEnsureVerb,
  checkRpcRoutes,
  extractLroStates,
  filterModelProperties,
  filterResponseModels,
  getAllProperties,
  getArmResourceIdentifierConfig,
  getAsEmbeddingVector,
  getFinalLocationValue,
  getFinalStateOverride,
  getHttpMetadata,
  getItems,
  getLongRunningStates,
  getLroErrorResult,
  getLroMetadata,
  getLroResult,
  getLroStatusProperty2 as getLroStatusProperty,
  getNextLink,
  getOperationLink,
  getOperationLinks,
  getOperationResponse,
  getPagedResult,
  getParameterizedNextLinkArguments,
  getPollingLocationInfo,
  getPollingOperationParameter,
  getRequestParameter,
  getResponseProperty,
  getResultModelWithProperty,
  getSourceTraitName,
  getSuccessResponse,
  getTraitContexts,
  getTraitLocation,
  getTraitName,
  getUnionAsEnum,
  isFinalLocation,
  isFixed,
  isLroCanceledState,
  isLroFailedState,
  isLroSucceededState,
  isPollingLocation,
  isResourceOperation,
  isTraitModel,
  namespace,
  parameterizedNextLinkConfigDecorator,
  pollingOptionsKind,
  preventRestLibraryInterfaces,
  useStandardOperations
};
