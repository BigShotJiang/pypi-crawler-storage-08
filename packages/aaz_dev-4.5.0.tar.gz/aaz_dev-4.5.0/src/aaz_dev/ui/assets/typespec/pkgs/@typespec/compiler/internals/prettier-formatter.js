import {
  formatter_exports
} from "../chunk-7INR3JZO.js";
import "../chunk-M66HWYAV.js";
import "../chunk-HK7BTPGC.js";
import "../chunk-3K4NAOXV.js";
import "../chunk-OV76USRJ.js";
import "../chunk-QRPWKJ4C.js";

// src/typespec/core/packages/compiler/dist/src/internals/prettier-formatter.js
var prettier_formatter_default = formatter_exports;
export {
  prettier_formatter_default as default
};
