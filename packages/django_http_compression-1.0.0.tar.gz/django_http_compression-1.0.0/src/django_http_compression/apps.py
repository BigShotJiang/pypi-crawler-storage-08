from __future__ import annotations

from django.apps import AppConfig


class DjangoHttpCompressionAppConfig(AppConfig):
    name = "django_http_compression"
    verbose_name = "django-http-compression"
