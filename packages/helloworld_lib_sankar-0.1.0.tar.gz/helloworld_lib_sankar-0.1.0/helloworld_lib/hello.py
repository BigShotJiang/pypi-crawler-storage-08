# helloworld-lib/hello.py

def say_hello(name="World"):
    """Return a friendly greeting."""
    return f"Hello, {name}!"

def say_bye(name="World"):
    """Return a friendly greeting."""
    return f"Bye, {name}!"
