# HelloWorld Lib

A simple example Python library.

## Installation

```bash
pip install helloworld-lib
