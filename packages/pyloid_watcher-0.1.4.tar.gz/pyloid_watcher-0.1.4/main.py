def main():
    print("Hello from pyloid-watcher!")


if __name__ == "__main__":
    main()
