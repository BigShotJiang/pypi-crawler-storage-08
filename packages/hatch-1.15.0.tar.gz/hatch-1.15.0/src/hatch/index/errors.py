class ArtifactMetadataError(Exception):
    pass
