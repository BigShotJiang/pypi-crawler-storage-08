from .swfunction import SwFunction

__all__ = [
    "SwFunction",
]
