internal_roles = ["attendant", "manager"]
url_google_sheets = "https://docs.google.com/spreadsheets/d/"
url_google_drive = "https://drive.google.com/drive/folders/"
url_wpp_me = "https://wa.me/"