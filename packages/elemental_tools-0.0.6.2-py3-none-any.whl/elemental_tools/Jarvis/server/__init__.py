
def RequestDev(request):
    return request



