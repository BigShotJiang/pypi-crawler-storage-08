# Plumbing

This is a general overview of how OpenAVMKit is organized and how data fundamentally flows through it.

(This article is still a work in progress -- more to come soon)

