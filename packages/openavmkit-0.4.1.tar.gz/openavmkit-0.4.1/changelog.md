# Changelog
All notable changes to this project will be documented in this file.

## [0.4.0] - 2025-10-06
### Changed
- Moved .env file loading out of cloud_sync() and into init_notebook()
- Removed need to manually specify location of .env file -- system finds it automatically
- Routine dependabot updates to libraries and automated actions

## [Unreleased]