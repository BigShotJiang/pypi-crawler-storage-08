from gooddata_api_client.paths.api_v1_entities_organization.get import ApiForget


class ApiV1EntitiesOrganization(
    ApiForget,
):
    pass
