from gooddata_api_client.paths.api_v1_layout_workspaces_workspace_id_permissions.get import ApiForget
from gooddata_api_client.paths.api_v1_layout_workspaces_workspace_id_permissions.put import ApiForput


class ApiV1LayoutWorkspacesWorkspaceIdPermissions(
    ApiForget,
    ApiForput,
):
    pass
