from gooddata_api_client.paths.api_v1_entities_data_sources.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_data_sources.post import ApiForpost


class ApiV1EntitiesDataSources(
    ApiForget,
    ApiForpost,
):
    pass
