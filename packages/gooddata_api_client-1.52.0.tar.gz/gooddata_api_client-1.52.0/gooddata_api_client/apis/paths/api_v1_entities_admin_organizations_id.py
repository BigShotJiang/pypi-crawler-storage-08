from gooddata_api_client.paths.api_v1_entities_admin_organizations_id.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_admin_organizations_id.put import ApiForput
from gooddata_api_client.paths.api_v1_entities_admin_organizations_id.patch import ApiForpatch


class ApiV1EntitiesAdminOrganizationsId(
    ApiForget,
    ApiForput,
    ApiForpatch,
):
    pass
