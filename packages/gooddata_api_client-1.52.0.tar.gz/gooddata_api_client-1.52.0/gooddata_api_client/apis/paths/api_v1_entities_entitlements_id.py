from gooddata_api_client.paths.api_v1_entities_entitlements_id.get import ApiForget


class ApiV1EntitiesEntitlementsId(
    ApiForget,
):
    pass
