from gooddata_api_client.paths.api_v1_layout_workspaces_workspace_id.get import ApiForget
from gooddata_api_client.paths.api_v1_layout_workspaces_workspace_id.put import ApiForput


class ApiV1LayoutWorkspacesWorkspaceId(
    ApiForget,
    ApiForput,
):
    pass
