from gooddata_api_client.paths.api_v1_layout_users_and_user_groups.get import ApiForget
from gooddata_api_client.paths.api_v1_layout_users_and_user_groups.put import ApiForput


class ApiV1LayoutUsersAndUserGroups(
    ApiForget,
    ApiForput,
):
    pass
