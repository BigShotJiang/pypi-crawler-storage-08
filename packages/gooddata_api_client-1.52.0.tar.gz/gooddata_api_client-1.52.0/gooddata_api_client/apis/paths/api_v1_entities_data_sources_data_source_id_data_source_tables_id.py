from gooddata_api_client.paths.api_v1_entities_data_sources_data_source_id_data_source_tables_id.get import ApiForget


class ApiV1EntitiesDataSourcesDataSourceIdDataSourceTablesId(
    ApiForget,
):
    pass
