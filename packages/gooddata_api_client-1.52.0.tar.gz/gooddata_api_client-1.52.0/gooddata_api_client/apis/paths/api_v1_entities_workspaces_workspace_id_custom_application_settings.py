from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_custom_application_settings.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_custom_application_settings.post import ApiForpost


class ApiV1EntitiesWorkspacesWorkspaceIdCustomApplicationSettings(
    ApiForget,
    ApiForpost,
):
    pass
