from gooddata_api_client.paths.api_v1_actions_workspaces_workspace_id_overridden_child_entities.get import ApiForget


class ApiV1ActionsWorkspacesWorkspaceIdOverriddenChildEntities(
    ApiForget,
):
    pass
