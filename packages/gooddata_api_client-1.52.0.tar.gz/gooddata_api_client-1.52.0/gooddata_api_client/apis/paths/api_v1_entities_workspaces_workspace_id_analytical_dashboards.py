from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_analytical_dashboards.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_analytical_dashboards.post import ApiForpost


class ApiV1EntitiesWorkspacesWorkspaceIdAnalyticalDashboards(
    ApiForget,
    ApiForpost,
):
    pass
