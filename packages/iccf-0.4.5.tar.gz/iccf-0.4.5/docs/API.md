---
title: API
summary: iCCF documentation page
order: 1000
---


::: iCCF.iCCF.Indicators
    options:
        show_source: false
        merge_init_into_class: true
        group_by_category: true
        heading_level: 3
        docstring_section_style: table
        members_order: source
        filters:
          - "!^_"
          - "!__repr__"