---
layout: default
title: Fits files over SSH
has_children: false
nav_order: 5
---

# Reading <i>.fits</i> files over SSH

It's common for the _.fits_ files containing the CCFs to be stored in some
server which can be accessed via the SSH protocol. **iCCF** tries to operate on
these remote files as seamlessly as on local files.

### Simple usage



### USER / HOST Configuration