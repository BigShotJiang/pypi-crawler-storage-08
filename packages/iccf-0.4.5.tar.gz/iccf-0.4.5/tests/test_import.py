def test_import():
    import iCCF
    from iCCF import bisector, gaussian, utils, meta, chromatic