from .AI2 import AuradineFluxAI2500
from .AI3 import AuradineFluxAI3680
