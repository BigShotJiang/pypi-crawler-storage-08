from pyasic.miners.backends.bitaxe import BitAxe
from pyasic.miners.device.models.bitaxe import Supra


class BitAxeSupra(BitAxe, Supra):
    pass
