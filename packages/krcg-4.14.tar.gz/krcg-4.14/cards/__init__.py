"""Static data - synced and saved on each version release."""
