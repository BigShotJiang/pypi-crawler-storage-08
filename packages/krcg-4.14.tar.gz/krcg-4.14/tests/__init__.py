"""Tests for the KRCG package."""
