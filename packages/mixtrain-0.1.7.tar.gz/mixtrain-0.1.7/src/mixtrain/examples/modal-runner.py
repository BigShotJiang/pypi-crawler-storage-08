from modal.volume import Volume


import modal
import uuid
import os
import shutil

app = modal.App.lookup("dk-app", create_if_missing=True)

from mixtrain.client import MixClient

API_KEY = "mix-c213cf62f7ad75e50e4abc03ccd5176356851c32fd091f482934716581fa03ce"
mix = MixClient(api_key=API_KEY)


secrets = {"MIXTRAIN_API_KEY": API_KEY}

for secret in mix.get_all_secrets():
    secrets[secret["name"]] = secret["value"]

uuid = str(uuid.uuid4())
print(uuid)
workdir = f"/workdir"
entrypoint = "/Users/dk/code/mixrepo/mixtrain/src/mixtrain/examples/compare_t2i.py"
files = [entrypoint]  # TODO add all files in the folder

local_folder = f"/tmp/mixtrain/{uuid}"
os.makedirs(local_folder, exist_ok=True)
for file in files:
    shutil.copy(file, local_folder)


with modal.Volume.ephemeral() as vol:
    with vol.batch_upload() as f:
        f.put_directory(local_folder, workdir)  # or dir

    sb = modal.Sandbox.create(
        app=app,
        image=modal.Image.debian_slim().uv_pip_install("mixtrain").env(secrets),
        volumes={workdir: vol},
    )

    p = sb.exec("pip", "install", "fal_client")
    for line in p.stdout:
        print(line, end="")
    for line in p.stderr:
        print(line, end="")

    p = sb.exec("python", "compare_t2i.py", workdir=workdir + workdir)
    # p = sb.exec("ls", "-lR", workdir=workdir + workdir)
    for line in p.stdout:
        # Avoid double newlines by using end="".
        print(line, end="")

    for line in p.stderr:
        print(line, end="")

    # p = sb.exec("python", "-c", "import fal_client; print(fal_client.__version__)")
    # for line in p.stdout:
    #     print(line, end="")
    # for line in p.stderr:
    #     print(line, end="")

    sb.terminate()
