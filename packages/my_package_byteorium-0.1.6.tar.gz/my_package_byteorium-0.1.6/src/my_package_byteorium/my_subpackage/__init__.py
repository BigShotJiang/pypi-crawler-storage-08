"""
project python_project_template_byteorium
file    __init__.py
brief   This is an example subpackage.
author  mab0189
"""
