{%
  include-markdown "../CHANGELOG.md"
%}
