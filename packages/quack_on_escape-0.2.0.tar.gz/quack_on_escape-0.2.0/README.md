# Quack !

Play "Quack" whenever you press escape button.

## Usage

```bash
pip install quack-on-escape
quack
```
