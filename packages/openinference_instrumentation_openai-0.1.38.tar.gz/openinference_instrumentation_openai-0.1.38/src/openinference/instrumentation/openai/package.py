_instruments = ("openai >= 1.69.0",)
_supports_metrics = False
