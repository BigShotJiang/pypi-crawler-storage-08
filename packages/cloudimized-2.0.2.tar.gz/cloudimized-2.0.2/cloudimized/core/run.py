from cloudimized.core.core import execute


def run():
    execute()


if __name__ == "__main__":
    run()
