﻿avatars.client.ApiClient
========================

.. currentmodule:: avatars.client

.. autoclass:: ApiClient


   .. automethod:: __init__


   .. rubric:: Methods

   .. autosummary::

      ~ApiClient.__init__
      ~ApiClient.authenticate
      ~ApiClient.check_auth
      ~ApiClient.context
      ~ApiClient.create
      ~ApiClient.forgotten_password
      ~ApiClient.make_content_builder
      ~ApiClient.on_auth_refresh
      ~ApiClient.prepare_files
      ~ApiClient.request
      ~ApiClient.reset_password
      ~ApiClient.send_request
      ~ApiClient.set_header
      ~ApiClient.wait_created
