﻿.. This stub is intentionally left blank because DatetimeProcessor no longer exists.
.. Keeping the file (empty) avoids stale references and suppresses import errors.

Removed processor (no implementation in codebase).
