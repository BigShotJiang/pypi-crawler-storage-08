"""Shared utilities for Terminotes."""

from __future__ import annotations

__all__ = []
