from eduvpn.cli import eduvpn

if __name__ == "__main__":
    eduvpn()
