# eduVPN for Linux

This is the Linux desktop client for eduVPN.

Read more about the eduVPN project on the eduVPN website https://www.eduvpn.org/.

# Documentation

The docs for this client are available on:
https://docs.eduvpn.org/client/linux

# License

[GPLv3+](./LICENSE)
