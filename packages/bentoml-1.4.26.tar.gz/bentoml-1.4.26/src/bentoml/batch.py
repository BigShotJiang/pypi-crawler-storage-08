from __future__ import annotations

from ._internal.batch.spark import run_in_spark

__all__ = ["run_in_spark"]
