from .testdata import (
    get_2d_scalar_cos_data, get_1d_scalar_cos_data, generate_2d_scalar_simple,
    two_1d_traces, two_compatible_noisy_2d_sets, three_compatible_3d_sets,
    three_incompatible_3d_sets, one_2d_set
)
