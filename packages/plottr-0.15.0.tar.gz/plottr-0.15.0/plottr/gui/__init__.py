from .widgets import PlotWindow, makeFlowchartWithPlotWindow
