# Weather MCP

A simple weather MCP for learning

## Features

- Fetches current weather data

## License

MIT License

## build
```bash
rm dist/*
python3 -m build
python3 -m twine upload dist/* --verbose
rm dist/*
```
