# birdeye-python

Python SDK for Birdeye.so API with built-in rate limiting.