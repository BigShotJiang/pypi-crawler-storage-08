config
======

.. automodule:: homer.config
