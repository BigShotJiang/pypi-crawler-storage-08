exceptions
==========

.. automodule:: homer.exceptions
