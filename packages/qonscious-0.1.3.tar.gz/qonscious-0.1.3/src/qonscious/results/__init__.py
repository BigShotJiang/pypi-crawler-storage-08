from qonscious.results.result_types import ExperimentResult, FigureOfMeritResult, QonsciousResult
