Obelisk-py documentation
===========================================

Obelisk-py is a fresh client for the Obelisk platform.
It brings retry strategies and optional async support


.. autosummary::
   :toctree: _autosummary
   :recursive:

   obelisk
