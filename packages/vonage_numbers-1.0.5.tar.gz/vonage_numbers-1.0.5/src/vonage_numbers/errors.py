from vonage_utils.errors import VonageError


class NumbersError(VonageError):
    """Indicates an error with the Numbers API package."""
