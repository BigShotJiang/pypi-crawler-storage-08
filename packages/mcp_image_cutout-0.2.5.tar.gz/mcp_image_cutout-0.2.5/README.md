# MCP 图像抠图服务器

这是一个基于Model Context Protocol (MCP)的服务器，专门提供火山引擎图像抠图功能。

## 功能特性

- **智能抠图**: 使用火山引擎的显著性分割技术，自动识别并抠出图像中的主要对象
- **批量处理**: 支持同时处理多张图像
- **自动上传**: 本地图片会先自动上传到服务器获取可访问链接，抠图结果也会自动上传并返回URL
- **本地保存**: 可选择保存抠图结果到本地文件
- **高精度**: 基于显著性检测的精确分割算法

## 安装

### 从 PyPI 安装

```bash
pip install mcp-image-cutout
```

### 从源码安装

```bash
git clone https://github.com/fengjinchao/mcp-image-cutout.git
cd mcp-image-cutout
pip install -e .
```

### 2. 配置API密钥

推荐使用环境变量设置API密钥：

```bash
export VOLC_ACCESS_KEY="your_access_key"
export VOLC_SECRET_KEY="your_secret_key"
```

或者在代码中直接设置（不推荐用于生产环境）。

### 3. 运行服务器

```bash
# 使用命令行工具
mcp-image-cutout

# 或直接运行模块
python -m mcp_image_cutout.server
```

## 在Claude Desktop中使用

在Claude Desktop的配置文件中添加以下配置：

**macOS/Linux**: `~/Library/Application Support/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "抠图工具": {
      "command": "mcp-image-cutout",
      "env": {
        "VOLC_ACCESS_KEY": "your_access_key",
        "VOLC_SECRET_KEY": "your_secret_key"
      }
    }
  }
}
```

## 可用工具

### image_cutout
智能图像抠图，使用显著性分割自动识别并抠出图像中的主要对象。支持直接提供本地图片路径，工具会先上传到服务器（https://www.mcpcn.cc）生成可访问URL，然后进行抠图，最终结果同样自动上传并返回图片URL。

**参数**:
- `image_paths`: 本地图片文件路径列表，会自动上传到服务器后再进行抠图
- `image_urls`: (可选) 已经可访问的图像URL列表，保留向后兼容

**返回**:
- 单张图片：直接返回图片URL
- 多张图片：返回所有图片URL的列表

**示例**:
```
请帮我抠出这张图片中的主要对象：/Users/me/Pictures/product.png
```

```
批量抠图这些图片：
- /Users/me/Pictures/product1.png
- /Users/me/Pictures/product2.jpg
- https://example.com/image1.jpg
- https://example.com/image2.jpg
```

## 抠图原理

使用的 `saliency_seg` 显著性分割算法：
- 基于视觉显著性检测图像中最重要的区域
- 精确分割显著对象的轮廓
- 生成高质量的抠图结果
- 适用于各种复杂背景的图像处理

## 上传功能

输入输出都会通过同一上传服务处理：
1. 当提供本地图片路径时，工具会先验证图片并上传到 `https://www.mcpcn.cc/api/fileUploadAndDownload/uploadMcpFile`，获取可公开访问的URL；
2. 使用这些URL调用火山引擎显著性分割接口完成抠图；
3. 将抠图结果保存为PNG后重新上传至同一服务器并返回最终URL；
4. 支持批量处理，多张图片会依次上传和处理。

**上传接口返回格式**：
```json
{
    "code": 0,
    "data": {
        "url": "https://juezhi.oss-cn-shanghai.aliyuncs.com/file/uploads/mcp/xxx.webp"
    },
    "msg": "成功"
}
```

## 注意事项

1. 确保图像URL可以公开访问
2. 处理结果会以base64格式返回，大图像可能需要较长处理时间
3. API调用有频率限制，请合理使用
4. 生产环境中请使用环境变量设置API密钥

## 故障排除

### 常见问题

1. **服务器无法启动**
   - 检查Python版本（需要3.10+）
   - 确认所有依赖已正确安装

2. **API调用失败**
   - 验证API密钥是否正确
   - 检查网络连接
   - 确认图像URL可访问

3. **Claude Desktop中看不到工具**
   - 检查配置文件语法
   - 确认路径是绝对路径
   - 重启Claude Desktop

### 日志查看

服务器日志会输出到stderr，可以通过以下方式查看：

```bash
# 查看Claude Desktop的MCP日志
tail -f ~/Library/Logs/Claude/mcp-server-图像编辑.log
```

## 开发

如需修改或扩展功能，请参考：
- [MCP官方文档](https://modelcontextprotocol.io/)
- [API文档](https://www.volcengine.com/docs/6791/65681)
