"""NextGen Practice Management Window Models package."""
