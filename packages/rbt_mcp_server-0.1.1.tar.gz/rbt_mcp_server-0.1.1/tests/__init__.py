"""
Tests for RBT MCP Server.

@REQ: REQ-rbt-mcp-tool
@BP: BP-rbt-mcp-tool
"""
