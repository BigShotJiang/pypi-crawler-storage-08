

class MutedException(Exception):
    pass
