# trulens-apps-langgraph

Refer to `otel_tru_graph_example.ipynb` notebook for examples.
