"""Evaluation interface - zero ceremony access."""

from .eval import latest, logs, run

__all__ = ["run", "latest", "logs"]
