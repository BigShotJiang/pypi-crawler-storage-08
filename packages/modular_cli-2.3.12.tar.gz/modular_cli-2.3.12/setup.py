# Copyright 2018 EPAM Systems, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# [http://www.apache.org/licenses/LICENSE-2.0]
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import os

from setuptools import setup

entrypoint = os.environ.get('MODULAR_CLI_ENTRY_POINT', 'modular-cli')

setup(
    entry_points={
        "console_scripts": [
            f"{entrypoint}=modular_cli.modular_cli:modular_cli"
        ]
    }
)
