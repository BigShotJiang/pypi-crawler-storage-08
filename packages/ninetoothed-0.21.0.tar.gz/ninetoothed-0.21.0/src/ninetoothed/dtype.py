int8 = "i8"
int16 = "i16"
int32 = "i32"
int64 = "i64"

uint8 = "u8"
uint16 = "u16"
uint32 = "u32"
uint64 = "u64"

float16 = "fp16"
bfloat16 = "bf16"
float32 = "fp32"
float64 = "fp64"
