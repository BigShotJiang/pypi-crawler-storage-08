Tensor
======

.. autoclass:: ninetoothed.Tensor

Meta-Operations
---------------

.. autosummary::
   :toctree: generated
   :nosignatures:

   ninetoothed.Tensor.tile
   ninetoothed.Tensor.expand
   ninetoothed.Tensor.squeeze
   ninetoothed.Tensor.permute
   ninetoothed.Tensor.flatten
   ninetoothed.Tensor.ravel

Evaluation
----------

.. autosummary::
   :toctree: generated
   :nosignatures:

   ninetoothed.Tensor.eval
