Debugging
=========

This module provides debugging tools.

Installation
------------

Since this module is optional, we need to install it before using it:

.. code-block::

    pip install ninetoothed[debugging]

Summary
-------

.. autosummary::
   :toctree: generated
   :nosignatures:

   ninetoothed.debugging.simulate_arrangement
