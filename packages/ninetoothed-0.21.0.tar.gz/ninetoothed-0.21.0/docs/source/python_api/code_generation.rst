Code Generation
===============

.. autosummary::
   :toctree: generated
   :nosignatures:

   ninetoothed.jit
   ninetoothed.make
