var dd = Object.defineProperty;
var sl = (n) => {
  throw TypeError(n);
};
var _d = (n, e, t) => e in n ? dd(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t;
var ue = (n, e, t) => _d(n, typeof e != "symbol" ? e + "" : e, t), Ma = (n, e, t) => e.has(n) || sl("Cannot " + t);
var Zn = (n, e, t) => (Ma(n, e, "read from private field"), t ? t.call(n) : e.get(n)), Na = (n, e, t) => e.has(n) ? sl("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(n) : e.set(n, t), ol = (n, e, t, i) => (Ma(n, e, "write to private field"), i ? i.call(n, t) : e.set(n, t), t), hr = (n, e, t) => (Ma(n, e, "access private method"), t);
const pd = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], ll = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
pd.reduce(
  (n, { color: e, primary: t, secondary: i }) => ({
    ...n,
    [e]: {
      primary: ll[e][t],
      secondary: ll[e][i]
    }
  }),
  {}
);
class Nr extends Error {
  constructor(e) {
    super(e), this.name = "ShareError";
  }
}
async function md(n, e) {
  var l;
  if (window.__gradio_space__ == null)
    throw new Nr("Must be on Spaces to share.");
  let t, i, r;
  {
    let c;
    if (typeof n == "object" && n.url)
      c = n.url;
    else if (typeof n == "string")
      c = n;
    else
      throw new Error("Invalid data format for URL type");
    const u = await fetch(c);
    t = await u.blob(), i = u.headers.get("content-type") || "", r = u.headers.get("content-disposition") || "";
  }
  const a = new File([t], r, { type: i }), s = await fetch("https://huggingface.co/uploads", {
    method: "POST",
    body: a,
    headers: {
      "Content-Type": a.type,
      "X-Requested-With": "XMLHttpRequest"
    }
  });
  if (!s.ok) {
    if ((l = s.headers.get("content-type")) != null && l.includes("application/json")) {
      const c = await s.json();
      throw new Nr(`Upload failed: ${c.error}`);
    }
    throw new Nr("Upload failed.");
  }
  return await s.text();
}
const {
  SvelteComponent: gd,
  append_hydration: Ps,
  assign: bd,
  attr: Le,
  binding_callbacks: vd,
  children: Mi,
  claim_element: Zc,
  claim_space: Kc,
  claim_svg_element: Ua,
  create_slot: yd,
  detach: Rt,
  element: Jc,
  empty: ul,
  get_all_dirty_from_scope: wd,
  get_slot_changes: Dd,
  get_spread_update: Ed,
  init: Cd,
  insert_hydration: zi,
  listen: Sd,
  noop: kd,
  safe_not_equal: Ad,
  set_dynamic_element_data: cl,
  set_style: te,
  space: Qc,
  svg_element: Ha,
  toggle_class: ke,
  transition_in: ef,
  transition_out: tf,
  update_slot_base: Fd
} = window.__gradio__svelte__internal;
function fl(n) {
  let e, t, i, r, a;
  return {
    c() {
      e = Ha("svg"), t = Ha("line"), i = Ha("line"), this.h();
    },
    l(s) {
      e = Ua(s, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var o = Mi(e);
      t = Ua(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Mi(t).forEach(Rt), i = Ua(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Mi(i).forEach(Rt), o.forEach(Rt), this.h();
    },
    h() {
      Le(t, "x1", "1"), Le(t, "y1", "9"), Le(t, "x2", "9"), Le(t, "y2", "1"), Le(t, "stroke", "gray"), Le(t, "stroke-width", "0.5"), Le(i, "x1", "5"), Le(i, "y1", "9"), Le(i, "x2", "9"), Le(i, "y2", "5"), Le(i, "stroke", "gray"), Le(i, "stroke-width", "0.5"), Le(e, "class", "resize-handle svelte-239wnu"), Le(e, "xmlns", "http://www.w3.org/2000/svg"), Le(e, "viewBox", "0 0 10 10");
    },
    m(s, o) {
      zi(s, e, o), Ps(e, t), Ps(e, i), r || (a = Sd(
        e,
        "mousedown",
        /*resize*/
        n[27]
      ), r = !0);
    },
    p: kd,
    d(s) {
      s && Rt(e), r = !1, a();
    }
  };
}
function Td(n) {
  var f;
  let e, t, i, r, a;
  const s = (
    /*#slots*/
    n[31].default
  ), o = yd(
    s,
    n,
    /*$$scope*/
    n[30],
    null
  );
  let l = (
    /*resizable*/
    n[19] && fl(n)
  ), c = [
    { "data-testid": (
      /*test_id*/
      n[11]
    ) },
    { id: (
      /*elem_id*/
      n[6]
    ) },
    {
      class: i = "block " + /*elem_classes*/
      (((f = n[7]) == null ? void 0 : f.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: r = /*rtl*/
      n[20] ? "rtl" : "ltr"
    }
  ], u = {};
  for (let h = 0; h < c.length; h += 1)
    u = bd(u, c[h]);
  return {
    c() {
      e = Jc(
        /*tag*/
        n[25]
      ), o && o.c(), t = Qc(), l && l.c(), this.h();
    },
    l(h) {
      e = Zc(
        h,
        /*tag*/
        (n[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var d = Mi(e);
      o && o.l(d), t = Kc(d), l && l.l(d), d.forEach(Rt), this.h();
    },
    h() {
      cl(
        /*tag*/
        n[25]
      )(e, u), ke(
        e,
        "hidden",
        /*visible*/
        n[14] === !1
      ), ke(
        e,
        "padded",
        /*padding*/
        n[10]
      ), ke(
        e,
        "flex",
        /*flex*/
        n[1]
      ), ke(
        e,
        "border_focus",
        /*border_mode*/
        n[9] === "focus"
      ), ke(
        e,
        "border_contrast",
        /*border_mode*/
        n[9] === "contrast"
      ), ke(e, "hide-container", !/*explicit_call*/
      n[12] && !/*container*/
      n[13]), ke(
        e,
        "fullscreen",
        /*fullscreen*/
        n[0]
      ), ke(
        e,
        "animating",
        /*fullscreen*/
        n[0] && /*preexpansionBoundingRect*/
        n[24] !== null
      ), ke(
        e,
        "auto-margin",
        /*scale*/
        n[17] === null
      ), te(
        e,
        "height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*height*/
            n[2]
          )
        )
      ), te(
        e,
        "min-height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*min_height*/
            n[3]
          )
        )
      ), te(
        e,
        "max-height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*max_height*/
            n[4]
          )
        )
      ), te(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].top}px` : "0px"
      ), te(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].left}px` : "0px"
      ), te(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].width}px` : "0px"
      ), te(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].height}px` : "0px"
      ), te(
        e,
        "width",
        /*fullscreen*/
        n[0] ? void 0 : typeof /*width*/
        n[5] == "number" ? `calc(min(${/*width*/
        n[5]}px, 100%))` : (
          /*get_dimension*/
          n[26](
            /*width*/
            n[5]
          )
        )
      ), te(
        e,
        "border-style",
        /*variant*/
        n[8]
      ), te(
        e,
        "overflow",
        /*allow_overflow*/
        n[15] ? (
          /*overflow_behavior*/
          n[16]
        ) : "hidden"
      ), te(
        e,
        "flex-grow",
        /*scale*/
        n[17]
      ), te(e, "min-width", `calc(min(${/*min_width*/
      n[18]}px, 100%))`), te(e, "border-width", "var(--block-border-width)");
    },
    m(h, d) {
      zi(h, e, d), o && o.m(e, null), Ps(e, t), l && l.m(e, null), n[32](e), a = !0;
    },
    p(h, d) {
      var p;
      o && o.p && (!a || d[0] & /*$$scope*/
      1073741824) && Fd(
        o,
        s,
        h,
        /*$$scope*/
        h[30],
        a ? Dd(
          s,
          /*$$scope*/
          h[30],
          d,
          null
        ) : wd(
          /*$$scope*/
          h[30]
        ),
        null
      ), /*resizable*/
      h[19] ? l ? l.p(h, d) : (l = fl(h), l.c(), l.m(e, null)) : l && (l.d(1), l = null), cl(
        /*tag*/
        h[25]
      )(e, u = Ed(c, [
        (!a || d[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          h[11]
        ) },
        (!a || d[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          h[6]
        ) },
        (!a || d[0] & /*elem_classes*/
        128 && i !== (i = "block " + /*elem_classes*/
        (((p = h[7]) == null ? void 0 : p.join(" ")) || "") + " svelte-239wnu")) && { class: i },
        (!a || d[0] & /*rtl*/
        1048576 && r !== (r = /*rtl*/
        h[20] ? "rtl" : "ltr")) && { dir: r }
      ])), ke(
        e,
        "hidden",
        /*visible*/
        h[14] === !1
      ), ke(
        e,
        "padded",
        /*padding*/
        h[10]
      ), ke(
        e,
        "flex",
        /*flex*/
        h[1]
      ), ke(
        e,
        "border_focus",
        /*border_mode*/
        h[9] === "focus"
      ), ke(
        e,
        "border_contrast",
        /*border_mode*/
        h[9] === "contrast"
      ), ke(e, "hide-container", !/*explicit_call*/
      h[12] && !/*container*/
      h[13]), ke(
        e,
        "fullscreen",
        /*fullscreen*/
        h[0]
      ), ke(
        e,
        "animating",
        /*fullscreen*/
        h[0] && /*preexpansionBoundingRect*/
        h[24] !== null
      ), ke(
        e,
        "auto-margin",
        /*scale*/
        h[17] === null
      ), d[0] & /*fullscreen, height*/
      5 && te(
        e,
        "height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*height*/
            h[2]
          )
        )
      ), d[0] & /*fullscreen, min_height*/
      9 && te(
        e,
        "min-height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*min_height*/
            h[3]
          )
        )
      ), d[0] & /*fullscreen, max_height*/
      17 && te(
        e,
        "max-height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*max_height*/
            h[4]
          )
        )
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && te(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].top}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && te(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].left}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && te(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].width}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && te(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].height}px` : "0px"
      ), d[0] & /*fullscreen, width*/
      33 && te(
        e,
        "width",
        /*fullscreen*/
        h[0] ? void 0 : typeof /*width*/
        h[5] == "number" ? `calc(min(${/*width*/
        h[5]}px, 100%))` : (
          /*get_dimension*/
          h[26](
            /*width*/
            h[5]
          )
        )
      ), d[0] & /*variant*/
      256 && te(
        e,
        "border-style",
        /*variant*/
        h[8]
      ), d[0] & /*allow_overflow, overflow_behavior*/
      98304 && te(
        e,
        "overflow",
        /*allow_overflow*/
        h[15] ? (
          /*overflow_behavior*/
          h[16]
        ) : "hidden"
      ), d[0] & /*scale*/
      131072 && te(
        e,
        "flex-grow",
        /*scale*/
        h[17]
      ), d[0] & /*min_width*/
      262144 && te(e, "min-width", `calc(min(${/*min_width*/
      h[18]}px, 100%))`);
    },
    i(h) {
      a || (ef(o, h), a = !0);
    },
    o(h) {
      tf(o, h), a = !1;
    },
    d(h) {
      h && Rt(e), o && o.d(h), l && l.d(), n[32](null);
    }
  };
}
function hl(n) {
  let e;
  return {
    c() {
      e = Jc("div"), this.h();
    },
    l(t) {
      e = Zc(t, "DIV", { class: !0 }), Mi(e).forEach(Rt), this.h();
    },
    h() {
      Le(e, "class", "placeholder svelte-239wnu"), te(
        e,
        "height",
        /*placeholder_height*/
        n[22] + "px"
      ), te(
        e,
        "width",
        /*placeholder_width*/
        n[23] + "px"
      );
    },
    m(t, i) {
      zi(t, e, i);
    },
    p(t, i) {
      i[0] & /*placeholder_height*/
      4194304 && te(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), i[0] & /*placeholder_width*/
      8388608 && te(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && Rt(e);
    }
  };
}
function Id(n) {
  let e, t, i, r = (
    /*tag*/
    n[25] && Td(n)
  ), a = (
    /*fullscreen*/
    n[0] && hl(n)
  );
  return {
    c() {
      r && r.c(), e = Qc(), a && a.c(), t = ul();
    },
    l(s) {
      r && r.l(s), e = Kc(s), a && a.l(s), t = ul();
    },
    m(s, o) {
      r && r.m(s, o), zi(s, e, o), a && a.m(s, o), zi(s, t, o), i = !0;
    },
    p(s, o) {
      /*tag*/
      s[25] && r.p(s, o), /*fullscreen*/
      s[0] ? a ? a.p(s, o) : (a = hl(s), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null);
    },
    i(s) {
      i || (ef(r, s), i = !0);
    },
    o(s) {
      tf(r, s), i = !1;
    },
    d(s) {
      s && (Rt(e), Rt(t)), r && r.d(s), a && a.d(s);
    }
  };
}
function $d(n, e, t) {
  let { $$slots: i = {}, $$scope: r } = e, { height: a = void 0 } = e, { min_height: s = void 0 } = e, { max_height: o = void 0 } = e, { width: l = void 0 } = e, { elem_id: c = "" } = e, { elem_classes: u = [] } = e, { variant: f = "solid" } = e, { border_mode: h = "base" } = e, { padding: d = !0 } = e, { type: p = "normal" } = e, { test_id: g = void 0 } = e, { explicit_call: E = !1 } = e, { container: w = !0 } = e, { visible: m = !0 } = e, { allow_overflow: _ = !0 } = e, { overflow_behavior: b = "auto" } = e, { scale: y = null } = e, { min_width: D = 0 } = e, { flex: F = !1 } = e, { resizable: x = !1 } = e, { rtl: T = !1 } = e, { fullscreen: R = !1 } = e, O = R, L, Z = p === "fieldset" ? "fieldset" : "div", z = 0, ge = 0, G = null;
  function ve(S) {
    R && S.key === "Escape" && t(0, R = !1);
  }
  const q = (S) => {
    if (S !== void 0) {
      if (typeof S == "number")
        return S + "px";
      if (typeof S == "string")
        return S;
    }
  }, P = (S) => {
    let ee = S.clientY;
    const K = (I) => {
      const Ce = I.clientY - ee;
      ee = I.clientY, t(21, L.style.height = `${L.offsetHeight + Ce}px`, L);
    }, de = () => {
      window.removeEventListener("mousemove", K), window.removeEventListener("mouseup", de);
    };
    window.addEventListener("mousemove", K), window.addEventListener("mouseup", de);
  };
  function le(S) {
    vd[S ? "unshift" : "push"](() => {
      L = S, t(21, L);
    });
  }
  return n.$$set = (S) => {
    "height" in S && t(2, a = S.height), "min_height" in S && t(3, s = S.min_height), "max_height" in S && t(4, o = S.max_height), "width" in S && t(5, l = S.width), "elem_id" in S && t(6, c = S.elem_id), "elem_classes" in S && t(7, u = S.elem_classes), "variant" in S && t(8, f = S.variant), "border_mode" in S && t(9, h = S.border_mode), "padding" in S && t(10, d = S.padding), "type" in S && t(28, p = S.type), "test_id" in S && t(11, g = S.test_id), "explicit_call" in S && t(12, E = S.explicit_call), "container" in S && t(13, w = S.container), "visible" in S && t(14, m = S.visible), "allow_overflow" in S && t(15, _ = S.allow_overflow), "overflow_behavior" in S && t(16, b = S.overflow_behavior), "scale" in S && t(17, y = S.scale), "min_width" in S && t(18, D = S.min_width), "flex" in S && t(1, F = S.flex), "resizable" in S && t(19, x = S.resizable), "rtl" in S && t(20, T = S.rtl), "fullscreen" in S && t(0, R = S.fullscreen), "$$scope" in S && t(30, r = S.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && R !== O && (t(29, O = R), R ? (t(24, G = L.getBoundingClientRect()), t(22, z = L.offsetHeight), t(23, ge = L.offsetWidth), window.addEventListener("keydown", ve)) : (t(24, G = null), window.removeEventListener("keydown", ve))), n.$$.dirty[0] & /*visible*/
    16384 && (m || t(1, F = !1));
  }, [
    R,
    F,
    a,
    s,
    o,
    l,
    c,
    u,
    f,
    h,
    d,
    g,
    E,
    w,
    m,
    _,
    b,
    y,
    D,
    x,
    T,
    L,
    z,
    ge,
    G,
    Z,
    q,
    P,
    p,
    O,
    r,
    i,
    le
  ];
}
class nf extends gd {
  constructor(e) {
    super(), Cd(
      this,
      e,
      $d,
      Id,
      Ad,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function vo() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Un = vo();
function rf(n) {
  Un = n;
}
const af = /[&<>"']/, Pd = new RegExp(af.source, "g"), sf = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, xd = new RegExp(sf.source, "g"), Bd = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, dl = (n) => Bd[n];
function at(n, e) {
  if (e) {
    if (af.test(n))
      return n.replace(Pd, dl);
  } else if (sf.test(n))
    return n.replace(xd, dl);
  return n;
}
const Od = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Rd(n) {
  return n.replace(Od, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const Ld = /(^|[^\[])\^/g;
function ae(n, e) {
  let t = typeof n == "string" ? n : n.source;
  e = e || "";
  const i = {
    replace: (r, a) => {
      let s = typeof a == "string" ? a : a.source;
      return s = s.replace(Ld, "$1"), t = t.replace(r, s), i;
    },
    getRegex: () => new RegExp(t, e)
  };
  return i;
}
function _l(n) {
  try {
    n = encodeURI(n).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return n;
}
const Ni = { exec: () => null };
function pl(n, e) {
  const t = n.replace(/\|/g, (a, s, o) => {
    let l = !1, c = s;
    for (; --c >= 0 && o[c] === "\\"; )
      l = !l;
    return l ? "|" : " |";
  }), i = t.split(/ \|/);
  let r = 0;
  if (i[0].trim() || i.shift(), i.length > 0 && !i[i.length - 1].trim() && i.pop(), e)
    if (i.length > e)
      i.splice(e);
    else
      for (; i.length < e; )
        i.push("");
  for (; r < i.length; r++)
    i[r] = i[r].trim().replace(/\\\|/g, "|");
  return i;
}
function dr(n, e, t) {
  const i = n.length;
  if (i === 0)
    return "";
  let r = 0;
  for (; r < i && n.charAt(i - r - 1) === e; )
    r++;
  return n.slice(0, i - r);
}
function Md(n, e) {
  if (n.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let i = 0; i < n.length; i++)
    if (n[i] === "\\")
      i++;
    else if (n[i] === e[0])
      t++;
    else if (n[i] === e[1] && (t--, t < 0))
      return i;
  return -1;
}
function ml(n, e, t, i) {
  const r = e.href, a = e.title ? at(e.title) : null, s = n[1].replace(/\\([\[\]])/g, "$1");
  if (n[0].charAt(0) !== "!") {
    i.state.inLink = !0;
    const o = {
      type: "link",
      raw: t,
      href: r,
      title: a,
      text: s,
      tokens: i.inlineTokens(s)
    };
    return i.state.inLink = !1, o;
  }
  return {
    type: "image",
    raw: t,
    href: r,
    title: a,
    text: at(s)
  };
}
function Nd(n, e) {
  const t = n.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const i = t[1];
  return e.split(`
`).map((r) => {
    const a = r.match(/^\s+/);
    if (a === null)
      return r;
    const [s] = a;
    return s.length >= i.length ? r.slice(i.length) : r;
  }).join(`
`);
}
class Wr {
  // set by the lexer
  constructor(e) {
    ue(this, "options");
    ue(this, "rules");
    // set by the lexer
    ue(this, "lexer");
    this.options = e || Un;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const i = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? i : dr(i, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const i = t[0], r = Nd(i, t[3] || "");
      return {
        type: "code",
        raw: i,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: r
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let i = t[2].trim();
      if (/#$/.test(i)) {
        const r = dr(i, "#");
        (this.options.pedantic || !r || / $/.test(r)) && (i = r.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: i,
        tokens: this.lexer.inline(i)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let i = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      i = dr(i.replace(/^ *>[ \t]?/gm, ""), `
`);
      const r = this.lexer.state.top;
      this.lexer.state.top = !0;
      const a = this.lexer.blockTokens(i);
      return this.lexer.state.top = r, {
        type: "blockquote",
        raw: t[0],
        tokens: a,
        text: i
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let i = t[1].trim();
      const r = i.length > 1, a = {
        type: "list",
        raw: "",
        ordered: r,
        start: r ? +i.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      i = r ? `\\d{1,9}\\${i.slice(-1)}` : `\\${i}`, this.options.pedantic && (i = r ? i : "[*+-]");
      const s = new RegExp(`^( {0,3}${i})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let o = "", l = "", c = !1;
      for (; e; ) {
        let u = !1;
        if (!(t = s.exec(e)) || this.rules.block.hr.test(e))
          break;
        o = t[0], e = e.substring(o.length);
        let f = t[2].split(`
`, 1)[0].replace(/^\t+/, (w) => " ".repeat(3 * w.length)), h = e.split(`
`, 1)[0], d = 0;
        this.options.pedantic ? (d = 2, l = f.trimStart()) : (d = t[2].search(/[^ ]/), d = d > 4 ? 1 : d, l = f.slice(d), d += t[1].length);
        let p = !1;
        if (!f && /^ *$/.test(h) && (o += h + `
`, e = e.substring(h.length + 1), u = !0), !u) {
          const w = new RegExp(`^ {0,${Math.min(3, d - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), m = new RegExp(`^ {0,${Math.min(3, d - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), _ = new RegExp(`^ {0,${Math.min(3, d - 1)}}(?:\`\`\`|~~~)`), b = new RegExp(`^ {0,${Math.min(3, d - 1)}}#`);
          for (; e; ) {
            const y = e.split(`
`, 1)[0];
            if (h = y, this.options.pedantic && (h = h.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), _.test(h) || b.test(h) || w.test(h) || m.test(e))
              break;
            if (h.search(/[^ ]/) >= d || !h.trim())
              l += `
` + h.slice(d);
            else {
              if (p || f.search(/[^ ]/) >= 4 || _.test(f) || b.test(f) || m.test(f))
                break;
              l += `
` + h;
            }
            !p && !h.trim() && (p = !0), o += y + `
`, e = e.substring(y.length + 1), f = h.slice(d);
          }
        }
        a.loose || (c ? a.loose = !0 : /\n *\n *$/.test(o) && (c = !0));
        let g = null, E;
        this.options.gfm && (g = /^\[[ xX]\] /.exec(l), g && (E = g[0] !== "[ ] ", l = l.replace(/^\[[ xX]\] +/, ""))), a.items.push({
          type: "list_item",
          raw: o,
          task: !!g,
          checked: E,
          loose: !1,
          text: l,
          tokens: []
        }), a.raw += o;
      }
      a.items[a.items.length - 1].raw = o.trimEnd(), a.items[a.items.length - 1].text = l.trimEnd(), a.raw = a.raw.trimEnd();
      for (let u = 0; u < a.items.length; u++)
        if (this.lexer.state.top = !1, a.items[u].tokens = this.lexer.blockTokens(a.items[u].text, []), !a.loose) {
          const f = a.items[u].tokens.filter((d) => d.type === "space"), h = f.length > 0 && f.some((d) => /\n.*\n/.test(d.raw));
          a.loose = h;
        }
      if (a.loose)
        for (let u = 0; u < a.items.length; u++)
          a.items[u].loose = !0;
      return a;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const i = t[1].toLowerCase().replace(/\s+/g, " "), r = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", a = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: i,
        raw: t[0],
        href: r,
        title: a
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const i = pl(t[1]), r = t[2].replace(/^\||\| *$/g, "").split("|"), a = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], s = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (i.length === r.length) {
      for (const o of r)
        /^ *-+: *$/.test(o) ? s.align.push("right") : /^ *:-+: *$/.test(o) ? s.align.push("center") : /^ *:-+ *$/.test(o) ? s.align.push("left") : s.align.push(null);
      for (const o of i)
        s.header.push({
          text: o,
          tokens: this.lexer.inline(o)
        });
      for (const o of a)
        s.rows.push(pl(o, s.header.length).map((l) => ({
          text: l,
          tokens: this.lexer.inline(l)
        })));
      return s;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const i = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: i,
        tokens: this.lexer.inline(i)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: at(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const i = t[2].trim();
      if (!this.options.pedantic && /^</.test(i)) {
        if (!/>$/.test(i))
          return;
        const s = dr(i.slice(0, -1), "\\");
        if ((i.length - s.length) % 2 === 0)
          return;
      } else {
        const s = Md(t[2], "()");
        if (s > -1) {
          const l = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + s;
          t[2] = t[2].substring(0, s), t[0] = t[0].substring(0, l).trim(), t[3] = "";
        }
      }
      let r = t[2], a = "";
      if (this.options.pedantic) {
        const s = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(r);
        s && (r = s[1], a = s[3]);
      } else
        a = t[3] ? t[3].slice(1, -1) : "";
      return r = r.trim(), /^</.test(r) && (this.options.pedantic && !/>$/.test(i) ? r = r.slice(1) : r = r.slice(1, -1)), ml(t, {
        href: r && r.replace(this.rules.inline.anyPunctuation, "$1"),
        title: a && a.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let i;
    if ((i = this.rules.inline.reflink.exec(e)) || (i = this.rules.inline.nolink.exec(e))) {
      const r = (i[2] || i[1]).replace(/\s+/g, " "), a = t[r.toLowerCase()];
      if (!a) {
        const s = i[0].charAt(0);
        return {
          type: "text",
          raw: s,
          text: s
        };
      }
      return ml(i, a, i[0], this.lexer);
    }
  }
  emStrong(e, t, i = "") {
    let r = this.rules.inline.emStrongLDelim.exec(e);
    if (!r || r[3] && i.match(/[\p{L}\p{N}]/u))
      return;
    if (!(r[1] || r[2] || "") || !i || this.rules.inline.punctuation.exec(i)) {
      const s = [...r[0]].length - 1;
      let o, l, c = s, u = 0;
      const f = r[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (f.lastIndex = 0, t = t.slice(-1 * e.length + s); (r = f.exec(t)) != null; ) {
        if (o = r[1] || r[2] || r[3] || r[4] || r[5] || r[6], !o)
          continue;
        if (l = [...o].length, r[3] || r[4]) {
          c += l;
          continue;
        } else if ((r[5] || r[6]) && s % 3 && !((s + l) % 3)) {
          u += l;
          continue;
        }
        if (c -= l, c > 0)
          continue;
        l = Math.min(l, l + c + u);
        const h = [...r[0]][0].length, d = e.slice(0, s + r.index + h + l);
        if (Math.min(s, l) % 2) {
          const g = d.slice(1, -1);
          return {
            type: "em",
            raw: d,
            text: g,
            tokens: this.lexer.inlineTokens(g)
          };
        }
        const p = d.slice(2, -2);
        return {
          type: "strong",
          raw: d,
          text: p,
          tokens: this.lexer.inlineTokens(p)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let i = t[2].replace(/\n/g, " ");
      const r = /[^ ]/.test(i), a = /^ /.test(i) && / $/.test(i);
      return r && a && (i = i.substring(1, i.length - 1)), i = at(i, !0), {
        type: "codespan",
        raw: t[0],
        text: i
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let i, r;
      return t[2] === "@" ? (i = at(t[1]), r = "mailto:" + i) : (i = at(t[1]), r = i), {
        type: "link",
        raw: t[0],
        text: i,
        href: r,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  url(e) {
    var i;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let r, a;
      if (t[2] === "@")
        r = at(t[0]), a = "mailto:" + r;
      else {
        let s;
        do
          s = t[0], t[0] = ((i = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : i[0]) ?? "";
        while (s !== t[0]);
        r = at(t[0]), t[1] === "www." ? a = "http://" + t[0] : a = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: r,
        href: a,
        tokens: [
          {
            type: "text",
            raw: r,
            text: r
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let i;
      return this.lexer.state.inRawBlock ? i = t[0] : i = at(t[0]), {
        type: "text",
        raw: t[0],
        text: i
      };
    }
  }
}
const Ud = /^(?: *(?:\n|$))+/, Hd = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Gd = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, tr = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, zd = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, of = /(?:[*+-]|\d{1,9}[.)])/, lf = ae(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, of).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), yo = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, qd = /^[^\n]+/, wo = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Vd = ae(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", wo).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), jd = ae(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, of).getRegex(), va = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Do = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Wd = ae("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Do).replace("tag", va).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), uf = ae(yo).replace("hr", tr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", va).getRegex(), Xd = ae(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", uf).getRegex(), Eo = {
  blockquote: Xd,
  code: Hd,
  def: Vd,
  fences: Gd,
  heading: zd,
  hr: tr,
  html: Wd,
  lheading: lf,
  list: jd,
  newline: Ud,
  paragraph: uf,
  table: Ni,
  text: qd
}, gl = ae("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", tr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", va).getRegex(), Yd = {
  ...Eo,
  table: gl,
  paragraph: ae(yo).replace("hr", tr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", gl).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", va).getRegex()
}, Zd = {
  ...Eo,
  html: ae(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Do).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Ni,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: ae(yo).replace("hr", tr).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", lf).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, cf = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Kd = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, ff = /^( {2,}|\\)\n(?!\s*$)/, Jd = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, nr = "\\p{P}\\p{S}", Qd = ae(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, nr).getRegex(), e_ = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, t_ = ae(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, nr).getRegex(), n_ = ae("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, nr).getRegex(), i_ = ae("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, nr).getRegex(), r_ = ae(/\\([punct])/, "gu").replace(/punct/g, nr).getRegex(), a_ = ae(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), s_ = ae(Do).replace("(?:-->|$)", "-->").getRegex(), o_ = ae("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", s_).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Xr = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, l_ = ae(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Xr).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), hf = ae(/^!?\[(label)\]\[(ref)\]/).replace("label", Xr).replace("ref", wo).getRegex(), df = ae(/^!?\[(ref)\](?:\[\])?/).replace("ref", wo).getRegex(), u_ = ae("reflink|nolink(?!\\()", "g").replace("reflink", hf).replace("nolink", df).getRegex(), Co = {
  _backpedal: Ni,
  // only used for GFM url
  anyPunctuation: r_,
  autolink: a_,
  blockSkip: e_,
  br: ff,
  code: Kd,
  del: Ni,
  emStrongLDelim: t_,
  emStrongRDelimAst: n_,
  emStrongRDelimUnd: i_,
  escape: cf,
  link: l_,
  nolink: df,
  punctuation: Qd,
  reflink: hf,
  reflinkSearch: u_,
  tag: o_,
  text: Jd,
  url: Ni
}, c_ = {
  ...Co,
  link: ae(/^!?\[(label)\]\((.*?)\)/).replace("label", Xr).getRegex(),
  reflink: ae(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Xr).getRegex()
}, xs = {
  ...Co,
  escape: ae(cf).replace("])", "~|])").getRegex(),
  url: ae(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, f_ = {
  ...xs,
  br: ae(ff).replace("{2,}", "*").getRegex(),
  text: ae(xs.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, _r = {
  normal: Eo,
  gfm: Yd,
  pedantic: Zd
}, Ei = {
  normal: Co,
  gfm: xs,
  breaks: f_,
  pedantic: c_
};
class Lt {
  constructor(e) {
    ue(this, "tokens");
    ue(this, "options");
    ue(this, "state");
    ue(this, "tokenizer");
    ue(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Un, this.options.tokenizer = this.options.tokenizer || new Wr(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: _r.normal,
      inline: Ei.normal
    };
    this.options.pedantic ? (t.block = _r.pedantic, t.inline = Ei.pedantic) : this.options.gfm && (t.block = _r.gfm, this.options.breaks ? t.inline = Ei.breaks : t.inline = Ei.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: _r,
      inline: Ei
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new Lt(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new Lt(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const i = this.inlineQueue[t];
      this.inlineTokens(i.src, i.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (o, l, c) => l + "    ".repeat(c.length));
    let i, r, a, s;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((o) => (i = o.call({ lexer: this }, e, t)) ? (e = e.substring(i.raw.length), t.push(i), !0) : !1))) {
        if (i = this.tokenizer.space(e)) {
          e = e.substring(i.raw.length), i.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(i);
          continue;
        }
        if (i = this.tokenizer.code(e)) {
          e = e.substring(i.raw.length), r = t[t.length - 1], r && (r.type === "paragraph" || r.type === "text") ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : t.push(i);
          continue;
        }
        if (i = this.tokenizer.fences(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.heading(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.hr(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.blockquote(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.list(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.html(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.def(e)) {
          e = e.substring(i.raw.length), r = t[t.length - 1], r && (r.type === "paragraph" || r.type === "text") ? (r.raw += `
` + i.raw, r.text += `
` + i.raw, this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : this.tokens.links[i.tag] || (this.tokens.links[i.tag] = {
            href: i.href,
            title: i.title
          });
          continue;
        }
        if (i = this.tokenizer.table(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.lheading(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startBlock) {
          let o = 1 / 0;
          const l = e.slice(1);
          let c;
          this.options.extensions.startBlock.forEach((u) => {
            c = u.call({ lexer: this }, l), typeof c == "number" && c >= 0 && (o = Math.min(o, c));
          }), o < 1 / 0 && o >= 0 && (a = e.substring(0, o + 1));
        }
        if (this.state.top && (i = this.tokenizer.paragraph(a))) {
          r = t[t.length - 1], s && r.type === "paragraph" ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : t.push(i), s = a.length !== e.length, e = e.substring(i.raw.length);
          continue;
        }
        if (i = this.tokenizer.text(e)) {
          e = e.substring(i.raw.length), r = t[t.length - 1], r && r.type === "text" ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : t.push(i);
          continue;
        }
        if (e) {
          const o = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(o);
            break;
          } else
            throw new Error(o);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let i, r, a, s = e, o, l, c;
    if (this.tokens.links) {
      const u = Object.keys(this.tokens.links);
      if (u.length > 0)
        for (; (o = this.tokenizer.rules.inline.reflinkSearch.exec(s)) != null; )
          u.includes(o[0].slice(o[0].lastIndexOf("[") + 1, -1)) && (s = s.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + s.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (o = this.tokenizer.rules.inline.blockSkip.exec(s)) != null; )
      s = s.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + s.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (o = this.tokenizer.rules.inline.anyPunctuation.exec(s)) != null; )
      s = s.slice(0, o.index) + "++" + s.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (l || (c = ""), l = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((u) => (i = u.call({ lexer: this }, e, t)) ? (e = e.substring(i.raw.length), t.push(i), !0) : !1))) {
        if (i = this.tokenizer.escape(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.tag(e)) {
          e = e.substring(i.raw.length), r = t[t.length - 1], r && i.type === "text" && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : t.push(i);
          continue;
        }
        if (i = this.tokenizer.link(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(i.raw.length), r = t[t.length - 1], r && i.type === "text" && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : t.push(i);
          continue;
        }
        if (i = this.tokenizer.emStrong(e, s, c)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.codespan(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.br(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.del(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.autolink(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (!this.state.inLink && (i = this.tokenizer.url(e))) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startInline) {
          let u = 1 / 0;
          const f = e.slice(1);
          let h;
          this.options.extensions.startInline.forEach((d) => {
            h = d.call({ lexer: this }, f), typeof h == "number" && h >= 0 && (u = Math.min(u, h));
          }), u < 1 / 0 && u >= 0 && (a = e.substring(0, u + 1));
        }
        if (i = this.tokenizer.inlineText(a)) {
          e = e.substring(i.raw.length), i.raw.slice(-1) !== "_" && (c = i.raw.slice(-1)), l = !0, r = t[t.length - 1], r && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : t.push(i);
          continue;
        }
        if (e) {
          const u = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(u);
            break;
          } else
            throw new Error(u);
        }
      }
    return t;
  }
}
class Yr {
  constructor(e) {
    ue(this, "options");
    this.options = e || Un;
  }
  code(e, t, i) {
    var a;
    const r = (a = (t || "").match(/^\S*/)) == null ? void 0 : a[0];
    return e = e.replace(/\n$/, "") + `
`, r ? '<pre><code class="language-' + at(r) + '">' + (i ? e : at(e, !0)) + `</code></pre>
` : "<pre><code>" + (i ? e : at(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, i) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, i) {
    const r = t ? "ol" : "ul", a = t && i !== 1 ? ' start="' + i + '"' : "";
    return "<" + r + a + `>
` + e + "</" + r + `>
`;
  }
  listitem(e, t, i) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const i = t.header ? "th" : "td";
    return (t.align ? `<${i} align="${t.align}">` : `<${i}>`) + e + `</${i}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, i) {
    const r = _l(e);
    if (r === null)
      return i;
    e = r;
    let a = '<a href="' + e + '"';
    return t && (a += ' title="' + t + '"'), a += ">" + i + "</a>", a;
  }
  image(e, t, i) {
    const r = _l(e);
    if (r === null)
      return i;
    e = r;
    let a = `<img src="${e}" alt="${i}"`;
    return t && (a += ` title="${t}"`), a += ">", a;
  }
  text(e) {
    return e;
  }
}
class So {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, i) {
    return "" + i;
  }
  image(e, t, i) {
    return "" + i;
  }
  br() {
    return "";
  }
}
class Mt {
  constructor(e) {
    ue(this, "options");
    ue(this, "renderer");
    ue(this, "textRenderer");
    this.options = e || Un, this.options.renderer = this.options.renderer || new Yr(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new So();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new Mt(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new Mt(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let i = "";
    for (let r = 0; r < e.length; r++) {
      const a = e[r];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const s = a, o = this.options.extensions.renderers[s.type].call({ parser: this }, s);
        if (o !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(s.type)) {
          i += o || "";
          continue;
        }
      }
      switch (a.type) {
        case "space":
          continue;
        case "hr": {
          i += this.renderer.hr();
          continue;
        }
        case "heading": {
          const s = a;
          i += this.renderer.heading(this.parseInline(s.tokens), s.depth, Rd(this.parseInline(s.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const s = a;
          i += this.renderer.code(s.text, s.lang, !!s.escaped);
          continue;
        }
        case "table": {
          const s = a;
          let o = "", l = "";
          for (let u = 0; u < s.header.length; u++)
            l += this.renderer.tablecell(this.parseInline(s.header[u].tokens), { header: !0, align: s.align[u] });
          o += this.renderer.tablerow(l);
          let c = "";
          for (let u = 0; u < s.rows.length; u++) {
            const f = s.rows[u];
            l = "";
            for (let h = 0; h < f.length; h++)
              l += this.renderer.tablecell(this.parseInline(f[h].tokens), { header: !1, align: s.align[h] });
            c += this.renderer.tablerow(l);
          }
          i += this.renderer.table(o, c);
          continue;
        }
        case "blockquote": {
          const s = a, o = this.parse(s.tokens);
          i += this.renderer.blockquote(o);
          continue;
        }
        case "list": {
          const s = a, o = s.ordered, l = s.start, c = s.loose;
          let u = "";
          for (let f = 0; f < s.items.length; f++) {
            const h = s.items[f], d = h.checked, p = h.task;
            let g = "";
            if (h.task) {
              const E = this.renderer.checkbox(!!d);
              c ? h.tokens.length > 0 && h.tokens[0].type === "paragraph" ? (h.tokens[0].text = E + " " + h.tokens[0].text, h.tokens[0].tokens && h.tokens[0].tokens.length > 0 && h.tokens[0].tokens[0].type === "text" && (h.tokens[0].tokens[0].text = E + " " + h.tokens[0].tokens[0].text)) : h.tokens.unshift({
                type: "text",
                text: E + " "
              }) : g += E + " ";
            }
            g += this.parse(h.tokens, c), u += this.renderer.listitem(g, p, !!d);
          }
          i += this.renderer.list(u, o, l);
          continue;
        }
        case "html": {
          const s = a;
          i += this.renderer.html(s.text, s.block);
          continue;
        }
        case "paragraph": {
          const s = a;
          i += this.renderer.paragraph(this.parseInline(s.tokens));
          continue;
        }
        case "text": {
          let s = a, o = s.tokens ? this.parseInline(s.tokens) : s.text;
          for (; r + 1 < e.length && e[r + 1].type === "text"; )
            s = e[++r], o += `
` + (s.tokens ? this.parseInline(s.tokens) : s.text);
          i += t ? this.renderer.paragraph(o) : o;
          continue;
        }
        default: {
          const s = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(s), "";
          throw new Error(s);
        }
      }
    }
    return i;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let i = "";
    for (let r = 0; r < e.length; r++) {
      const a = e[r];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const s = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (s !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(a.type)) {
          i += s || "";
          continue;
        }
      }
      switch (a.type) {
        case "escape": {
          const s = a;
          i += t.text(s.text);
          break;
        }
        case "html": {
          const s = a;
          i += t.html(s.text);
          break;
        }
        case "link": {
          const s = a;
          i += t.link(s.href, s.title, this.parseInline(s.tokens, t));
          break;
        }
        case "image": {
          const s = a;
          i += t.image(s.href, s.title, s.text);
          break;
        }
        case "strong": {
          const s = a;
          i += t.strong(this.parseInline(s.tokens, t));
          break;
        }
        case "em": {
          const s = a;
          i += t.em(this.parseInline(s.tokens, t));
          break;
        }
        case "codespan": {
          const s = a;
          i += t.codespan(s.text);
          break;
        }
        case "br": {
          i += t.br();
          break;
        }
        case "del": {
          const s = a;
          i += t.del(this.parseInline(s.tokens, t));
          break;
        }
        case "text": {
          const s = a;
          i += t.text(s.text);
          break;
        }
        default: {
          const s = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(s), "";
          throw new Error(s);
        }
      }
    }
    return i;
  }
}
class Ui {
  constructor(e) {
    ue(this, "options");
    this.options = e || Un;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
ue(Ui, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Nn, Bs, _f;
class h_ {
  constructor(...e) {
    Na(this, Nn);
    ue(this, "defaults", vo());
    ue(this, "options", this.setOptions);
    ue(this, "parse", hr(this, Nn, Bs).call(this, Lt.lex, Mt.parse));
    ue(this, "parseInline", hr(this, Nn, Bs).call(this, Lt.lexInline, Mt.parseInline));
    ue(this, "Parser", Mt);
    ue(this, "Renderer", Yr);
    ue(this, "TextRenderer", So);
    ue(this, "Lexer", Lt);
    ue(this, "Tokenizer", Wr);
    ue(this, "Hooks", Ui);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var r, a;
    let i = [];
    for (const s of e)
      switch (i = i.concat(t.call(this, s)), s.type) {
        case "table": {
          const o = s;
          for (const l of o.header)
            i = i.concat(this.walkTokens(l.tokens, t));
          for (const l of o.rows)
            for (const c of l)
              i = i.concat(this.walkTokens(c.tokens, t));
          break;
        }
        case "list": {
          const o = s;
          i = i.concat(this.walkTokens(o.items, t));
          break;
        }
        default: {
          const o = s;
          (a = (r = this.defaults.extensions) == null ? void 0 : r.childTokens) != null && a[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((l) => {
            const c = o[l].flat(1 / 0);
            i = i.concat(this.walkTokens(c, t));
          }) : o.tokens && (i = i.concat(this.walkTokens(o.tokens, t)));
        }
      }
    return i;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((i) => {
      const r = { ...i };
      if (r.async = this.defaults.async || r.async || !1, i.extensions && (i.extensions.forEach((a) => {
        if (!a.name)
          throw new Error("extension name required");
        if ("renderer" in a) {
          const s = t.renderers[a.name];
          s ? t.renderers[a.name] = function(...o) {
            let l = a.renderer.apply(this, o);
            return l === !1 && (l = s.apply(this, o)), l;
          } : t.renderers[a.name] = a.renderer;
        }
        if ("tokenizer" in a) {
          if (!a.level || a.level !== "block" && a.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const s = t[a.level];
          s ? s.unshift(a.tokenizer) : t[a.level] = [a.tokenizer], a.start && (a.level === "block" ? t.startBlock ? t.startBlock.push(a.start) : t.startBlock = [a.start] : a.level === "inline" && (t.startInline ? t.startInline.push(a.start) : t.startInline = [a.start]));
        }
        "childTokens" in a && a.childTokens && (t.childTokens[a.name] = a.childTokens);
      }), r.extensions = t), i.renderer) {
        const a = this.defaults.renderer || new Yr(this.defaults);
        for (const s in i.renderer) {
          if (!(s in a))
            throw new Error(`renderer '${s}' does not exist`);
          if (s === "options")
            continue;
          const o = s, l = i.renderer[o], c = a[o];
          a[o] = (...u) => {
            let f = l.apply(a, u);
            return f === !1 && (f = c.apply(a, u)), f || "";
          };
        }
        r.renderer = a;
      }
      if (i.tokenizer) {
        const a = this.defaults.tokenizer || new Wr(this.defaults);
        for (const s in i.tokenizer) {
          if (!(s in a))
            throw new Error(`tokenizer '${s}' does not exist`);
          if (["options", "rules", "lexer"].includes(s))
            continue;
          const o = s, l = i.tokenizer[o], c = a[o];
          a[o] = (...u) => {
            let f = l.apply(a, u);
            return f === !1 && (f = c.apply(a, u)), f;
          };
        }
        r.tokenizer = a;
      }
      if (i.hooks) {
        const a = this.defaults.hooks || new Ui();
        for (const s in i.hooks) {
          if (!(s in a))
            throw new Error(`hook '${s}' does not exist`);
          if (s === "options")
            continue;
          const o = s, l = i.hooks[o], c = a[o];
          Ui.passThroughHooks.has(s) ? a[o] = (u) => {
            if (this.defaults.async)
              return Promise.resolve(l.call(a, u)).then((h) => c.call(a, h));
            const f = l.call(a, u);
            return c.call(a, f);
          } : a[o] = (...u) => {
            let f = l.apply(a, u);
            return f === !1 && (f = c.apply(a, u)), f;
          };
        }
        r.hooks = a;
      }
      if (i.walkTokens) {
        const a = this.defaults.walkTokens, s = i.walkTokens;
        r.walkTokens = function(o) {
          let l = [];
          return l.push(s.call(this, o)), a && (l = l.concat(a.call(this, o))), l;
        };
      }
      this.defaults = { ...this.defaults, ...r };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return Lt.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Mt.parse(e, t ?? this.defaults);
  }
}
Nn = new WeakSet(), Bs = function(e, t) {
  return (i, r) => {
    const a = { ...r }, s = { ...this.defaults, ...a };
    this.defaults.async === !0 && a.async === !1 && (s.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), s.async = !0);
    const o = hr(this, Nn, _f).call(this, !!s.silent, !!s.async);
    if (typeof i > "u" || i === null)
      return o(new Error("marked(): input parameter is undefined or null"));
    if (typeof i != "string")
      return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(i) + ", string expected"));
    if (s.hooks && (s.hooks.options = s), s.async)
      return Promise.resolve(s.hooks ? s.hooks.preprocess(i) : i).then((l) => e(l, s)).then((l) => s.hooks ? s.hooks.processAllTokens(l) : l).then((l) => s.walkTokens ? Promise.all(this.walkTokens(l, s.walkTokens)).then(() => l) : l).then((l) => t(l, s)).then((l) => s.hooks ? s.hooks.postprocess(l) : l).catch(o);
    try {
      s.hooks && (i = s.hooks.preprocess(i));
      let l = e(i, s);
      s.hooks && (l = s.hooks.processAllTokens(l)), s.walkTokens && this.walkTokens(l, s.walkTokens);
      let c = t(l, s);
      return s.hooks && (c = s.hooks.postprocess(c)), c;
    } catch (l) {
      return o(l);
    }
  };
}, _f = function(e, t) {
  return (i) => {
    if (i.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const r = "<p>An error occurred:</p><pre>" + at(i.message + "", !0) + "</pre>";
      return t ? Promise.resolve(r) : r;
    }
    if (t)
      return Promise.reject(i);
    throw i;
  };
};
const $n = new h_();
function re(n, e) {
  return $n.parse(n, e);
}
re.options = re.setOptions = function(n) {
  return $n.setOptions(n), re.defaults = $n.defaults, rf(re.defaults), re;
};
re.getDefaults = vo;
re.defaults = Un;
re.use = function(...n) {
  return $n.use(...n), re.defaults = $n.defaults, rf(re.defaults), re;
};
re.walkTokens = function(n, e) {
  return $n.walkTokens(n, e);
};
re.parseInline = $n.parseInline;
re.Parser = Mt;
re.parser = Mt.parse;
re.Renderer = Yr;
re.TextRenderer = So;
re.Lexer = Lt;
re.lexer = Lt.lex;
re.Tokenizer = Wr;
re.Hooks = Ui;
re.parse = re;
re.options;
re.setOptions;
re.use;
re.walkTokens;
re.parseInline;
Mt.parse;
Lt.lex;
const d_ = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, __ = Object.hasOwnProperty;
class pf {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const i = this;
    let r = p_(e, t === !0);
    const a = r;
    for (; __.call(i.occurrences, r); )
      i.occurrences[a]++, r = a + "-" + i.occurrences[a];
    return i.occurrences[r] = 0, r;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function p_(n, e) {
  return typeof n != "string" ? "" : (e || (n = n.toLowerCase()), n.replace(d_, "").replace(/ /g, "-"));
}
new pf();
var bl = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, m_ = { exports: {} };
(function(n) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(i) {
    var r = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, a = 0, s = {}, o = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: i.Prism && i.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: i.Prism && i.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function m(_) {
          return _ instanceof l ? new l(_.type, m(_.content), _.alias) : Array.isArray(_) ? _.map(m) : _.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(m) {
          return Object.prototype.toString.call(m).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(m) {
          return m.__id || Object.defineProperty(m, "__id", { value: ++a }), m.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function m(_, b) {
          b = b || {};
          var y, D;
          switch (o.util.type(_)) {
            case "Object":
              if (D = o.util.objId(_), b[D])
                return b[D];
              y = /** @type {Record<string, any>} */
              {}, b[D] = y;
              for (var F in _)
                _.hasOwnProperty(F) && (y[F] = m(_[F], b));
              return (
                /** @type {any} */
                y
              );
            case "Array":
              return D = o.util.objId(_), b[D] ? b[D] : (y = [], b[D] = y, /** @type {Array} */
              /** @type {any} */
              _.forEach(function(x, T) {
                y[T] = m(x, b);
              }), /** @type {any} */
              y);
            default:
              return _;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(m) {
          for (; m; ) {
            var _ = r.exec(m.className);
            if (_)
              return _[1].toLowerCase();
            m = m.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(m, _) {
          m.className = m.className.replace(RegExp(r, "gi"), ""), m.classList.add("language-" + _);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (y) {
            var m = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(y.stack) || [])[1];
            if (m) {
              var _ = document.getElementsByTagName("script");
              for (var b in _)
                if (_[b].src == m)
                  return _[b];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(m, _, b) {
          for (var y = "no-" + _; m; ) {
            var D = m.classList;
            if (D.contains(_))
              return !0;
            if (D.contains(y))
              return !1;
            m = m.parentElement;
          }
          return !!b;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: s,
        plaintext: s,
        text: s,
        txt: s,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(m, _) {
          var b = o.util.clone(o.languages[m]);
          for (var y in _)
            b[y] = _[y];
          return b;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(m, _, b, y) {
          y = y || /** @type {any} */
          o.languages;
          var D = y[m], F = {};
          for (var x in D)
            if (D.hasOwnProperty(x)) {
              if (x == _)
                for (var T in b)
                  b.hasOwnProperty(T) && (F[T] = b[T]);
              b.hasOwnProperty(x) || (F[x] = D[x]);
            }
          var R = y[m];
          return y[m] = F, o.languages.DFS(o.languages, function(O, L) {
            L === R && O != m && (this[O] = F);
          }), F;
        },
        // Traverse a language definition with Depth First Search
        DFS: function m(_, b, y, D) {
          D = D || {};
          var F = o.util.objId;
          for (var x in _)
            if (_.hasOwnProperty(x)) {
              b.call(_, x, _[x], y || x);
              var T = _[x], R = o.util.type(T);
              R === "Object" && !D[F(T)] ? (D[F(T)] = !0, m(T, b, null, D)) : R === "Array" && !D[F(T)] && (D[F(T)] = !0, m(T, b, x, D));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(m, _) {
        o.highlightAllUnder(document, m, _);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(m, _, b) {
        var y = {
          callback: b,
          container: m,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        o.hooks.run("before-highlightall", y), y.elements = Array.prototype.slice.apply(y.container.querySelectorAll(y.selector)), o.hooks.run("before-all-elements-highlight", y);
        for (var D = 0, F; F = y.elements[D++]; )
          o.highlightElement(F, _ === !0, y.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(m, _, b) {
        var y = o.util.getLanguage(m), D = o.languages[y];
        o.util.setLanguage(m, y);
        var F = m.parentElement;
        F && F.nodeName.toLowerCase() === "pre" && o.util.setLanguage(F, y);
        var x = m.textContent, T = {
          element: m,
          language: y,
          grammar: D,
          code: x
        };
        function R(L) {
          T.highlightedCode = L, o.hooks.run("before-insert", T), T.element.innerHTML = T.highlightedCode, o.hooks.run("after-highlight", T), o.hooks.run("complete", T), b && b.call(T.element);
        }
        if (o.hooks.run("before-sanity-check", T), F = T.element.parentElement, F && F.nodeName.toLowerCase() === "pre" && !F.hasAttribute("tabindex") && F.setAttribute("tabindex", "0"), !T.code) {
          o.hooks.run("complete", T), b && b.call(T.element);
          return;
        }
        if (o.hooks.run("before-highlight", T), !T.grammar) {
          R(o.util.encode(T.code));
          return;
        }
        if (_ && i.Worker) {
          var O = new Worker(o.filename);
          O.onmessage = function(L) {
            R(L.data);
          }, O.postMessage(JSON.stringify({
            language: T.language,
            code: T.code,
            immediateClose: !0
          }));
        } else
          R(o.highlight(T.code, T.grammar, T.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(m, _, b) {
        var y = {
          code: m,
          grammar: _,
          language: b
        };
        if (o.hooks.run("before-tokenize", y), !y.grammar)
          throw new Error('The language "' + y.language + '" has no grammar.');
        return y.tokens = o.tokenize(y.code, y.grammar), o.hooks.run("after-tokenize", y), l.stringify(o.util.encode(y.tokens), y.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(m, _) {
        var b = _.rest;
        if (b) {
          for (var y in b)
            _[y] = b[y];
          delete _.rest;
        }
        var D = new f();
        return h(D, D.head, m), u(m, D, _, D.head, 0), p(D);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(m, _) {
          var b = o.hooks.all;
          b[m] = b[m] || [], b[m].push(_);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(m, _) {
          var b = o.hooks.all[m];
          if (!(!b || !b.length))
            for (var y = 0, D; D = b[y++]; )
              D(_);
        }
      },
      Token: l
    };
    i.Prism = o;
    function l(m, _, b, y) {
      this.type = m, this.content = _, this.alias = b, this.length = (y || "").length | 0;
    }
    l.stringify = function m(_, b) {
      if (typeof _ == "string")
        return _;
      if (Array.isArray(_)) {
        var y = "";
        return _.forEach(function(R) {
          y += m(R, b);
        }), y;
      }
      var D = {
        type: _.type,
        content: m(_.content, b),
        tag: "span",
        classes: ["token", _.type],
        attributes: {},
        language: b
      }, F = _.alias;
      F && (Array.isArray(F) ? Array.prototype.push.apply(D.classes, F) : D.classes.push(F)), o.hooks.run("wrap", D);
      var x = "";
      for (var T in D.attributes)
        x += " " + T + '="' + (D.attributes[T] || "").replace(/"/g, "&quot;") + '"';
      return "<" + D.tag + ' class="' + D.classes.join(" ") + '"' + x + ">" + D.content + "</" + D.tag + ">";
    };
    function c(m, _, b, y) {
      m.lastIndex = _;
      var D = m.exec(b);
      if (D && y && D[1]) {
        var F = D[1].length;
        D.index += F, D[0] = D[0].slice(F);
      }
      return D;
    }
    function u(m, _, b, y, D, F) {
      for (var x in b)
        if (!(!b.hasOwnProperty(x) || !b[x])) {
          var T = b[x];
          T = Array.isArray(T) ? T : [T];
          for (var R = 0; R < T.length; ++R) {
            if (F && F.cause == x + "," + R)
              return;
            var O = T[R], L = O.inside, Z = !!O.lookbehind, z = !!O.greedy, ge = O.alias;
            if (z && !O.pattern.global) {
              var G = O.pattern.toString().match(/[imsuy]*$/)[0];
              O.pattern = RegExp(O.pattern.source, G + "g");
            }
            for (var ve = O.pattern || O, q = y.next, P = D; q !== _.tail && !(F && P >= F.reach); P += q.value.length, q = q.next) {
              var le = q.value;
              if (_.length > m.length)
                return;
              if (!(le instanceof l)) {
                var S = 1, ee;
                if (z) {
                  if (ee = c(ve, P, m, Z), !ee || ee.index >= m.length)
                    break;
                  var Ce = ee.index, K = ee.index + ee[0].length, de = P;
                  for (de += q.value.length; Ce >= de; )
                    q = q.next, de += q.value.length;
                  if (de -= q.value.length, P = de, q.value instanceof l)
                    continue;
                  for (var I = q; I !== _.tail && (de < K || typeof I.value == "string"); I = I.next)
                    S++, de += I.value.length;
                  S--, le = m.slice(P, de), ee.index -= P;
                } else if (ee = c(ve, 0, le, Z), !ee)
                  continue;
                var Ce = ee.index, $ = ee[0], V = le.slice(0, Ce), J = le.slice(Ce + $.length), se = P + le.length;
                F && se > F.reach && (F.reach = se);
                var k = q.prev;
                V && (k = h(_, k, V), P += V.length), d(_, k, S);
                var nt = new l(x, L ? o.tokenize($, L) : $, ge, $);
                if (q = h(_, k, nt), J && h(_, q, J), S > 1) {
                  var Pt = {
                    cause: x + "," + R,
                    reach: se
                  };
                  u(m, _, b, q.prev, P, Pt), F && Pt.reach > F.reach && (F.reach = Pt.reach);
                }
              }
            }
          }
        }
    }
    function f() {
      var m = { value: null, prev: null, next: null }, _ = { value: null, prev: m, next: null };
      m.next = _, this.head = m, this.tail = _, this.length = 0;
    }
    function h(m, _, b) {
      var y = _.next, D = { value: b, prev: _, next: y };
      return _.next = D, y.prev = D, m.length++, D;
    }
    function d(m, _, b) {
      for (var y = _.next, D = 0; D < b && y !== m.tail; D++)
        y = y.next;
      _.next = y, y.prev = _, m.length -= D;
    }
    function p(m) {
      for (var _ = [], b = m.head.next; b !== m.tail; )
        _.push(b.value), b = b.next;
      return _;
    }
    if (!i.document)
      return i.addEventListener && (o.disableWorkerMessageHandler || i.addEventListener("message", function(m) {
        var _ = JSON.parse(m.data), b = _.language, y = _.code, D = _.immediateClose;
        i.postMessage(o.highlight(y, o.languages[b], b)), D && i.close();
      }, !1)), o;
    var g = o.util.currentScript();
    g && (o.filename = g.src, g.hasAttribute("data-manual") && (o.manual = !0));
    function E() {
      o.manual || o.highlightAll();
    }
    if (!o.manual) {
      var w = document.readyState;
      w === "loading" || w === "interactive" && g && g.defer ? document.addEventListener("DOMContentLoaded", E) : window.requestAnimationFrame ? window.requestAnimationFrame(E) : window.setTimeout(E, 16);
    }
    return o;
  }(e);
  n.exports && (n.exports = t), typeof bl < "u" && (bl.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(i) {
    i.type === "entity" && (i.attributes.title = i.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(r, a) {
      var s = {};
      s["language-" + a] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[a]
      }, s.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var o = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: s
        }
      };
      o["language-" + a] = {
        pattern: /[\s\S]+/,
        inside: t.languages[a]
      };
      var l = {};
      l[r] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return r;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: o
      }, t.languages.insertBefore("markup", "cdata", l);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(i, r) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + i + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [r, "language-" + r],
                inside: t.languages[r]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(i) {
    var r = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    i.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + r.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + r.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + r.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + r.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: r,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, i.languages.css.atrule.inside.rest = i.languages.css;
    var a = i.languages.markup;
    a && (a.tag.addInlined("style", "css"), a.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var i = "Loading…", r = function(g, E) {
      return "✖ Error " + g + " while fetching file: " + E;
    }, a = "✖ Error: File does not exist or is empty", s = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, o = "data-src-status", l = "loading", c = "loaded", u = "failed", f = "pre[data-src]:not([" + o + '="' + c + '"]):not([' + o + '="' + l + '"])';
    function h(g, E, w) {
      var m = new XMLHttpRequest();
      m.open("GET", g, !0), m.onreadystatechange = function() {
        m.readyState == 4 && (m.status < 400 && m.responseText ? E(m.responseText) : m.status >= 400 ? w(r(m.status, m.statusText)) : w(a));
      }, m.send(null);
    }
    function d(g) {
      var E = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(g || "");
      if (E) {
        var w = Number(E[1]), m = E[2], _ = E[3];
        return m ? _ ? [w, Number(_)] : [w, void 0] : [w, w];
      }
    }
    t.hooks.add("before-highlightall", function(g) {
      g.selector += ", " + f;
    }), t.hooks.add("before-sanity-check", function(g) {
      var E = (
        /** @type {HTMLPreElement} */
        g.element
      );
      if (E.matches(f)) {
        g.code = "", E.setAttribute(o, l);
        var w = E.appendChild(document.createElement("CODE"));
        w.textContent = i;
        var m = E.getAttribute("data-src"), _ = g.language;
        if (_ === "none") {
          var b = (/\.(\w+)$/.exec(m) || [, "none"])[1];
          _ = s[b] || b;
        }
        t.util.setLanguage(w, _), t.util.setLanguage(E, _);
        var y = t.plugins.autoloader;
        y && y.loadLanguages(_), h(
          m,
          function(D) {
            E.setAttribute(o, c);
            var F = d(E.getAttribute("data-range"));
            if (F) {
              var x = D.split(/\r\n?|\n/g), T = F[0], R = F[1] == null ? x.length : F[1];
              T < 0 && (T += x.length), T = Math.max(0, Math.min(T - 1, x.length)), R < 0 && (R += x.length), R = Math.max(0, Math.min(R, x.length)), D = x.slice(T, R).join(`
`), E.hasAttribute("data-start") || E.setAttribute("data-start", String(T + 1));
            }
            w.textContent = D, t.highlightElement(w);
          },
          function(D) {
            E.setAttribute(o, u), w.textContent = D;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(E) {
        for (var w = (E || document).querySelectorAll(f), m = 0, _; _ = w[m++]; )
          t.highlightElement(_);
      }
    };
    var p = !1;
    t.fileHighlight = function() {
      p || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), p = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(m_);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(n) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  n.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, n.languages.tex = n.languages.latex, n.languages.context = n.languages.latex;
})(Prism);
(function(n) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, i = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  n.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: i
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: i
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: i.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: i.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = n.languages.bash;
  for (var r = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], a = i.variable[1].inside, s = 0; s < r.length; s++)
    a[r[s]] = n.languages.bash[r[s]];
  n.languages.sh = n.languages.bash, n.languages.shell = n.languages.bash;
})(Prism);
new pf();
const g_ = (n) => {
  const e = {};
  for (let t = 0, i = n.length; t < i; t++) {
    const r = n[t];
    for (const a in r)
      e[a] ? e[a] = e[a].concat(r[a]) : e[a] = r[a];
  }
  return e;
}, b_ = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], v_ = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], y_ = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
g_([
  Object.fromEntries(b_.map((n) => [n, ["*"]])),
  Object.fromEntries(v_.map((n) => [n, ["svg:*"]])),
  Object.fromEntries(y_.map((n) => [n, ["math:*"]]))
]);
const {
  HtmlTagHydration: Yv,
  SvelteComponent: Zv,
  attr: Kv,
  binding_callbacks: Jv,
  children: Qv,
  claim_element: ey,
  claim_html_tag: ty,
  detach: ny,
  element: iy,
  init: ry,
  insert_hydration: ay,
  noop: sy,
  safe_not_equal: oy,
  toggle_class: ly
} = window.__gradio__svelte__internal, { afterUpdate: uy, tick: cy, onMount: fy } = window.__gradio__svelte__internal, {
  SvelteComponent: hy,
  attr: dy,
  children: _y,
  claim_component: py,
  claim_element: my,
  create_component: gy,
  destroy_component: by,
  detach: vy,
  element: yy,
  init: wy,
  insert_hydration: Dy,
  mount_component: Ey,
  safe_not_equal: Cy,
  transition_in: Sy,
  transition_out: ky
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ay,
  attr: Fy,
  check_outros: Ty,
  children: Iy,
  claim_component: $y,
  claim_element: Py,
  claim_space: xy,
  create_component: By,
  create_slot: Oy,
  destroy_component: Ry,
  detach: Ly,
  element: My,
  empty: Ny,
  get_all_dirty_from_scope: Uy,
  get_slot_changes: Hy,
  group_outros: Gy,
  init: zy,
  insert_hydration: qy,
  mount_component: Vy,
  safe_not_equal: jy,
  space: Wy,
  toggle_class: Xy,
  transition_in: Yy,
  transition_out: Zy,
  update_slot_base: Ky
} = window.__gradio__svelte__internal, {
  SvelteComponent: w_,
  append_hydration: Ga,
  attr: Kn,
  children: vl,
  claim_component: D_,
  claim_element: yl,
  claim_space: E_,
  claim_text: C_,
  create_component: S_,
  destroy_component: k_,
  detach: za,
  element: wl,
  init: A_,
  insert_hydration: F_,
  mount_component: T_,
  safe_not_equal: I_,
  set_data: $_,
  space: P_,
  text: x_,
  toggle_class: sn,
  transition_in: B_,
  transition_out: O_
} = window.__gradio__svelte__internal;
function R_(n) {
  let e, t, i, r, a, s, o;
  return i = new /*Icon*/
  n[1]({}), {
    c() {
      e = wl("label"), t = wl("span"), S_(i.$$.fragment), r = P_(), a = x_(
        /*label*/
        n[0]
      ), this.h();
    },
    l(l) {
      e = yl(l, "LABEL", {
        for: !0,
        "data-testid": !0,
        dir: !0,
        class: !0
      });
      var c = vl(e);
      t = yl(c, "SPAN", { class: !0 });
      var u = vl(t);
      D_(i.$$.fragment, u), u.forEach(za), r = E_(c), a = C_(
        c,
        /*label*/
        n[0]
      ), c.forEach(za), this.h();
    },
    h() {
      Kn(t, "class", "svelte-13ao5pu"), Kn(e, "for", ""), Kn(e, "data-testid", "block-label"), Kn(e, "dir", s = /*rtl*/
      n[5] ? "rtl" : "ltr"), Kn(e, "class", "svelte-13ao5pu"), sn(e, "hide", !/*show_label*/
      n[2]), sn(e, "sr-only", !/*show_label*/
      n[2]), sn(
        e,
        "float",
        /*float*/
        n[4]
      ), sn(
        e,
        "hide-label",
        /*disable*/
        n[3]
      );
    },
    m(l, c) {
      F_(l, e, c), Ga(e, t), T_(i, t, null), Ga(e, r), Ga(e, a), o = !0;
    },
    p(l, [c]) {
      (!o || c & /*label*/
      1) && $_(
        a,
        /*label*/
        l[0]
      ), (!o || c & /*rtl*/
      32 && s !== (s = /*rtl*/
      l[5] ? "rtl" : "ltr")) && Kn(e, "dir", s), (!o || c & /*show_label*/
      4) && sn(e, "hide", !/*show_label*/
      l[2]), (!o || c & /*show_label*/
      4) && sn(e, "sr-only", !/*show_label*/
      l[2]), (!o || c & /*float*/
      16) && sn(
        e,
        "float",
        /*float*/
        l[4]
      ), (!o || c & /*disable*/
      8) && sn(
        e,
        "hide-label",
        /*disable*/
        l[3]
      );
    },
    i(l) {
      o || (B_(i.$$.fragment, l), o = !0);
    },
    o(l) {
      O_(i.$$.fragment, l), o = !1;
    },
    d(l) {
      l && za(e), k_(i);
    }
  };
}
function L_(n, e, t) {
  let { label: i = null } = e, { Icon: r } = e, { show_label: a = !0 } = e, { disable: s = !1 } = e, { float: o = !0 } = e, { rtl: l = !1 } = e;
  return n.$$set = (c) => {
    "label" in c && t(0, i = c.label), "Icon" in c && t(1, r = c.Icon), "show_label" in c && t(2, a = c.show_label), "disable" in c && t(3, s = c.disable), "float" in c && t(4, o = c.float), "rtl" in c && t(5, l = c.rtl);
  }, [i, r, a, s, o, l];
}
class mf extends w_ {
  constructor(e) {
    super(), A_(this, e, L_, R_, I_, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4,
      rtl: 5
    });
  }
}
const {
  SvelteComponent: M_,
  append_hydration: Ur,
  attr: Jt,
  bubble: N_,
  check_outros: U_,
  children: Os,
  claim_component: H_,
  claim_element: Rs,
  claim_space: Dl,
  claim_text: G_,
  construct_svelte_component: El,
  create_component: Cl,
  create_slot: z_,
  destroy_component: Sl,
  detach: Hi,
  element: Ls,
  get_all_dirty_from_scope: q_,
  get_slot_changes: V_,
  group_outros: j_,
  init: W_,
  insert_hydration: gf,
  listen: X_,
  mount_component: kl,
  safe_not_equal: Y_,
  set_data: Z_,
  set_style: pr,
  space: Al,
  text: K_,
  toggle_class: Oe,
  transition_in: qa,
  transition_out: Va,
  update_slot_base: J_
} = window.__gradio__svelte__internal;
function Fl(n) {
  let e, t;
  return {
    c() {
      e = Ls("span"), t = K_(
        /*label*/
        n[1]
      ), this.h();
    },
    l(i) {
      e = Rs(i, "SPAN", { class: !0 });
      var r = Os(e);
      t = G_(
        r,
        /*label*/
        n[1]
      ), r.forEach(Hi), this.h();
    },
    h() {
      Jt(e, "class", "svelte-qgco6m");
    },
    m(i, r) {
      gf(i, e, r), Ur(e, t);
    },
    p(i, r) {
      r & /*label*/
      2 && Z_(
        t,
        /*label*/
        i[1]
      );
    },
    d(i) {
      i && Hi(e);
    }
  };
}
function Q_(n) {
  let e, t, i, r, a, s, o, l, c = (
    /*show_label*/
    n[2] && Fl(n)
  );
  var u = (
    /*Icon*/
    n[0]
  );
  function f(p, g) {
    return {};
  }
  u && (r = El(u, f()));
  const h = (
    /*#slots*/
    n[14].default
  ), d = z_(
    h,
    n,
    /*$$scope*/
    n[13],
    null
  );
  return {
    c() {
      e = Ls("button"), c && c.c(), t = Al(), i = Ls("div"), r && Cl(r.$$.fragment), a = Al(), d && d.c(), this.h();
    },
    l(p) {
      e = Rs(p, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var g = Os(e);
      c && c.l(g), t = Dl(g), i = Rs(g, "DIV", { class: !0 });
      var E = Os(i);
      r && H_(r.$$.fragment, E), a = Dl(E), d && d.l(E), E.forEach(Hi), g.forEach(Hi), this.h();
    },
    h() {
      Jt(i, "class", "svelte-qgco6m"), Oe(
        i,
        "x-small",
        /*size*/
        n[4] === "x-small"
      ), Oe(
        i,
        "small",
        /*size*/
        n[4] === "small"
      ), Oe(
        i,
        "large",
        /*size*/
        n[4] === "large"
      ), Oe(
        i,
        "medium",
        /*size*/
        n[4] === "medium"
      ), e.disabled = /*disabled*/
      n[7], Jt(
        e,
        "aria-label",
        /*label*/
        n[1]
      ), Jt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        n[8]
      ), Jt(
        e,
        "title",
        /*label*/
        n[1]
      ), Jt(e, "class", "svelte-qgco6m"), Oe(
        e,
        "pending",
        /*pending*/
        n[3]
      ), Oe(
        e,
        "padded",
        /*padded*/
        n[5]
      ), Oe(
        e,
        "highlight",
        /*highlight*/
        n[6]
      ), Oe(
        e,
        "transparent",
        /*transparent*/
        n[9]
      ), pr(e, "color", !/*disabled*/
      n[7] && /*_color*/
      n[11] ? (
        /*_color*/
        n[11]
      ) : "var(--block-label-text-color)"), pr(e, "--bg-color", /*disabled*/
      n[7] ? "auto" : (
        /*background*/
        n[10]
      ));
    },
    m(p, g) {
      gf(p, e, g), c && c.m(e, null), Ur(e, t), Ur(e, i), r && kl(r, i, null), Ur(i, a), d && d.m(i, null), s = !0, o || (l = X_(
        e,
        "click",
        /*click_handler*/
        n[15]
      ), o = !0);
    },
    p(p, [g]) {
      if (/*show_label*/
      p[2] ? c ? c.p(p, g) : (c = Fl(p), c.c(), c.m(e, t)) : c && (c.d(1), c = null), g & /*Icon*/
      1 && u !== (u = /*Icon*/
      p[0])) {
        if (r) {
          j_();
          const E = r;
          Va(E.$$.fragment, 1, 0, () => {
            Sl(E, 1);
          }), U_();
        }
        u ? (r = El(u, f()), Cl(r.$$.fragment), qa(r.$$.fragment, 1), kl(r, i, a)) : r = null;
      }
      d && d.p && (!s || g & /*$$scope*/
      8192) && J_(
        d,
        h,
        p,
        /*$$scope*/
        p[13],
        s ? V_(
          h,
          /*$$scope*/
          p[13],
          g,
          null
        ) : q_(
          /*$$scope*/
          p[13]
        ),
        null
      ), (!s || g & /*size*/
      16) && Oe(
        i,
        "x-small",
        /*size*/
        p[4] === "x-small"
      ), (!s || g & /*size*/
      16) && Oe(
        i,
        "small",
        /*size*/
        p[4] === "small"
      ), (!s || g & /*size*/
      16) && Oe(
        i,
        "large",
        /*size*/
        p[4] === "large"
      ), (!s || g & /*size*/
      16) && Oe(
        i,
        "medium",
        /*size*/
        p[4] === "medium"
      ), (!s || g & /*disabled*/
      128) && (e.disabled = /*disabled*/
      p[7]), (!s || g & /*label*/
      2) && Jt(
        e,
        "aria-label",
        /*label*/
        p[1]
      ), (!s || g & /*hasPopup*/
      256) && Jt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        p[8]
      ), (!s || g & /*label*/
      2) && Jt(
        e,
        "title",
        /*label*/
        p[1]
      ), (!s || g & /*pending*/
      8) && Oe(
        e,
        "pending",
        /*pending*/
        p[3]
      ), (!s || g & /*padded*/
      32) && Oe(
        e,
        "padded",
        /*padded*/
        p[5]
      ), (!s || g & /*highlight*/
      64) && Oe(
        e,
        "highlight",
        /*highlight*/
        p[6]
      ), (!s || g & /*transparent*/
      512) && Oe(
        e,
        "transparent",
        /*transparent*/
        p[9]
      ), g & /*disabled, _color*/
      2176 && pr(e, "color", !/*disabled*/
      p[7] && /*_color*/
      p[11] ? (
        /*_color*/
        p[11]
      ) : "var(--block-label-text-color)"), g & /*disabled, background*/
      1152 && pr(e, "--bg-color", /*disabled*/
      p[7] ? "auto" : (
        /*background*/
        p[10]
      ));
    },
    i(p) {
      s || (r && qa(r.$$.fragment, p), qa(d, p), s = !0);
    },
    o(p) {
      r && Va(r.$$.fragment, p), Va(d, p), s = !1;
    },
    d(p) {
      p && Hi(e), c && c.d(), r && Sl(r), d && d.d(p), o = !1, l();
    }
  };
}
function ep(n, e, t) {
  let i, { $$slots: r = {}, $$scope: a } = e, { Icon: s } = e, { label: o = "" } = e, { show_label: l = !1 } = e, { pending: c = !1 } = e, { size: u = "small" } = e, { padded: f = !0 } = e, { highlight: h = !1 } = e, { disabled: d = !1 } = e, { hasPopup: p = !1 } = e, { color: g = "var(--block-label-text-color)" } = e, { transparent: E = !1 } = e, { background: w = "var(--block-background-fill)" } = e;
  function m(_) {
    N_.call(this, n, _);
  }
  return n.$$set = (_) => {
    "Icon" in _ && t(0, s = _.Icon), "label" in _ && t(1, o = _.label), "show_label" in _ && t(2, l = _.show_label), "pending" in _ && t(3, c = _.pending), "size" in _ && t(4, u = _.size), "padded" in _ && t(5, f = _.padded), "highlight" in _ && t(6, h = _.highlight), "disabled" in _ && t(7, d = _.disabled), "hasPopup" in _ && t(8, p = _.hasPopup), "color" in _ && t(12, g = _.color), "transparent" in _ && t(9, E = _.transparent), "background" in _ && t(10, w = _.background), "$$scope" in _ && t(13, a = _.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*highlight, color*/
    4160 && t(11, i = h ? "var(--color-accent)" : g);
  }, [
    s,
    o,
    l,
    c,
    u,
    f,
    h,
    d,
    p,
    E,
    w,
    i,
    g,
    a,
    r,
    m
  ];
}
class _n extends M_ {
  constructor(e) {
    super(), W_(this, e, ep, Q_, Y_, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: tp,
  append_hydration: np,
  attr: ja,
  binding_callbacks: ip,
  children: Tl,
  claim_element: Il,
  create_slot: rp,
  detach: Wa,
  element: $l,
  get_all_dirty_from_scope: ap,
  get_slot_changes: sp,
  init: op,
  insert_hydration: lp,
  safe_not_equal: up,
  toggle_class: on,
  transition_in: cp,
  transition_out: fp,
  update_slot_base: hp
} = window.__gradio__svelte__internal;
function dp(n) {
  let e, t, i;
  const r = (
    /*#slots*/
    n[5].default
  ), a = rp(
    r,
    n,
    /*$$scope*/
    n[4],
    null
  );
  return {
    c() {
      e = $l("div"), t = $l("div"), a && a.c(), this.h();
    },
    l(s) {
      e = Il(s, "DIV", { class: !0, "aria-label": !0 });
      var o = Tl(e);
      t = Il(o, "DIV", { class: !0 });
      var l = Tl(t);
      a && a.l(l), l.forEach(Wa), o.forEach(Wa), this.h();
    },
    h() {
      ja(t, "class", "icon svelte-3w3rth"), ja(e, "class", "empty svelte-3w3rth"), ja(e, "aria-label", "Empty value"), on(
        e,
        "small",
        /*size*/
        n[0] === "small"
      ), on(
        e,
        "large",
        /*size*/
        n[0] === "large"
      ), on(
        e,
        "unpadded_box",
        /*unpadded_box*/
        n[1]
      ), on(
        e,
        "small_parent",
        /*parent_height*/
        n[3]
      );
    },
    m(s, o) {
      lp(s, e, o), np(e, t), a && a.m(t, null), n[6](e), i = !0;
    },
    p(s, [o]) {
      a && a.p && (!i || o & /*$$scope*/
      16) && hp(
        a,
        r,
        s,
        /*$$scope*/
        s[4],
        i ? sp(
          r,
          /*$$scope*/
          s[4],
          o,
          null
        ) : ap(
          /*$$scope*/
          s[4]
        ),
        null
      ), (!i || o & /*size*/
      1) && on(
        e,
        "small",
        /*size*/
        s[0] === "small"
      ), (!i || o & /*size*/
      1) && on(
        e,
        "large",
        /*size*/
        s[0] === "large"
      ), (!i || o & /*unpadded_box*/
      2) && on(
        e,
        "unpadded_box",
        /*unpadded_box*/
        s[1]
      ), (!i || o & /*parent_height*/
      8) && on(
        e,
        "small_parent",
        /*parent_height*/
        s[3]
      );
    },
    i(s) {
      i || (cp(a, s), i = !0);
    },
    o(s) {
      fp(a, s), i = !1;
    },
    d(s) {
      s && Wa(e), a && a.d(s), n[6](null);
    }
  };
}
function _p(n, e, t) {
  let i, { $$slots: r = {}, $$scope: a } = e, { size: s = "small" } = e, { unpadded_box: o = !1 } = e, l;
  function c(f) {
    var p;
    if (!f) return !1;
    const { height: h } = f.getBoundingClientRect(), { height: d } = ((p = f.parentElement) == null ? void 0 : p.getBoundingClientRect()) || { height: h };
    return h > d + 2;
  }
  function u(f) {
    ip[f ? "unshift" : "push"](() => {
      l = f, t(2, l);
    });
  }
  return n.$$set = (f) => {
    "size" in f && t(0, s = f.size), "unpadded_box" in f && t(1, o = f.unpadded_box), "$$scope" in f && t(4, a = f.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*el*/
    4 && t(3, i = c(l));
  }, [s, o, l, i, a, r, u];
}
class pp extends tp {
  constructor(e) {
    super(), op(this, e, _p, dp, up, { size: 0, unpadded_box: 1 });
  }
}
const {
  SvelteComponent: Jy,
  append_hydration: Qy,
  attr: ew,
  children: tw,
  claim_svg_element: nw,
  detach: iw,
  init: rw,
  insert_hydration: aw,
  noop: sw,
  safe_not_equal: ow,
  svg_element: lw
} = window.__gradio__svelte__internal, {
  SvelteComponent: uw,
  append_hydration: cw,
  attr: fw,
  children: hw,
  claim_svg_element: dw,
  detach: _w,
  init: pw,
  insert_hydration: mw,
  noop: gw,
  safe_not_equal: bw,
  svg_element: vw
} = window.__gradio__svelte__internal, {
  SvelteComponent: yw,
  append_hydration: ww,
  attr: Dw,
  children: Ew,
  claim_svg_element: Cw,
  detach: Sw,
  init: kw,
  insert_hydration: Aw,
  noop: Fw,
  safe_not_equal: Tw,
  svg_element: Iw
} = window.__gradio__svelte__internal, {
  SvelteComponent: $w,
  append_hydration: Pw,
  attr: xw,
  children: Bw,
  claim_svg_element: Ow,
  detach: Rw,
  init: Lw,
  insert_hydration: Mw,
  noop: Nw,
  safe_not_equal: Uw,
  svg_element: Hw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gw,
  append_hydration: zw,
  attr: qw,
  children: Vw,
  claim_svg_element: jw,
  detach: Ww,
  init: Xw,
  insert_hydration: Yw,
  noop: Zw,
  safe_not_equal: Kw,
  svg_element: Jw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qw,
  append_hydration: eD,
  attr: tD,
  children: nD,
  claim_svg_element: iD,
  detach: rD,
  init: aD,
  insert_hydration: sD,
  noop: oD,
  safe_not_equal: lD,
  svg_element: uD
} = window.__gradio__svelte__internal, {
  SvelteComponent: cD,
  append_hydration: fD,
  attr: hD,
  children: dD,
  claim_svg_element: _D,
  detach: pD,
  init: mD,
  insert_hydration: gD,
  noop: bD,
  safe_not_equal: vD,
  svg_element: yD
} = window.__gradio__svelte__internal, {
  SvelteComponent: wD,
  append_hydration: DD,
  attr: ED,
  children: CD,
  claim_svg_element: SD,
  detach: kD,
  init: AD,
  insert_hydration: FD,
  noop: TD,
  safe_not_equal: ID,
  svg_element: $D
} = window.__gradio__svelte__internal, {
  SvelteComponent: PD,
  append_hydration: xD,
  attr: BD,
  children: OD,
  claim_svg_element: RD,
  detach: LD,
  init: MD,
  insert_hydration: ND,
  noop: UD,
  safe_not_equal: HD,
  svg_element: GD
} = window.__gradio__svelte__internal, {
  SvelteComponent: zD,
  append_hydration: qD,
  attr: VD,
  children: jD,
  claim_svg_element: WD,
  detach: XD,
  init: YD,
  insert_hydration: ZD,
  noop: KD,
  safe_not_equal: JD,
  svg_element: QD
} = window.__gradio__svelte__internal, {
  SvelteComponent: e3,
  append_hydration: t3,
  attr: n3,
  children: i3,
  claim_svg_element: r3,
  detach: a3,
  init: s3,
  insert_hydration: o3,
  noop: l3,
  safe_not_equal: u3,
  svg_element: c3
} = window.__gradio__svelte__internal, {
  SvelteComponent: f3,
  append_hydration: h3,
  attr: d3,
  children: _3,
  claim_svg_element: p3,
  detach: m3,
  init: g3,
  insert_hydration: b3,
  noop: v3,
  safe_not_equal: y3,
  svg_element: w3
} = window.__gradio__svelte__internal, {
  SvelteComponent: mp,
  append_hydration: Xa,
  attr: mt,
  children: mr,
  claim_svg_element: gr,
  detach: Ci,
  init: gp,
  insert_hydration: bp,
  noop: Ya,
  safe_not_equal: vp,
  set_style: Bt,
  svg_element: br
} = window.__gradio__svelte__internal;
function yp(n) {
  let e, t, i, r;
  return {
    c() {
      e = br("svg"), t = br("g"), i = br("path"), r = br("path"), this.h();
    },
    l(a) {
      e = gr(a, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var s = mr(e);
      t = gr(s, "g", { transform: !0 });
      var o = mr(t);
      i = gr(o, "path", { d: !0, style: !0 }), mr(i).forEach(Ci), o.forEach(Ci), r = gr(s, "path", { d: !0, style: !0 }), mr(r).forEach(Ci), s.forEach(Ci), this.h();
    },
    h() {
      mt(i, "d", "M18,6L6.087,17.913"), Bt(i, "fill", "none"), Bt(i, "fill-rule", "nonzero"), Bt(i, "stroke-width", "2px"), mt(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), mt(r, "d", "M4.364,4.364L19.636,19.636"), Bt(r, "fill", "none"), Bt(r, "fill-rule", "nonzero"), Bt(r, "stroke-width", "2px"), mt(e, "width", "100%"), mt(e, "height", "100%"), mt(e, "viewBox", "0 0 24 24"), mt(e, "version", "1.1"), mt(e, "xmlns", "http://www.w3.org/2000/svg"), mt(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), mt(e, "xml:space", "preserve"), mt(e, "stroke", "currentColor"), Bt(e, "fill-rule", "evenodd"), Bt(e, "clip-rule", "evenodd"), Bt(e, "stroke-linecap", "round"), Bt(e, "stroke-linejoin", "round");
    },
    m(a, s) {
      bp(a, e, s), Xa(e, t), Xa(t, i), Xa(e, r);
    },
    p: Ya,
    i: Ya,
    o: Ya,
    d(a) {
      a && Ci(e);
    }
  };
}
class bf extends mp {
  constructor(e) {
    super(), gp(this, e, null, yp, vp, {});
  }
}
const {
  SvelteComponent: D3,
  append_hydration: E3,
  attr: C3,
  children: S3,
  claim_svg_element: k3,
  detach: A3,
  init: F3,
  insert_hydration: T3,
  noop: I3,
  safe_not_equal: $3,
  svg_element: P3
} = window.__gradio__svelte__internal, {
  SvelteComponent: x3,
  append_hydration: B3,
  attr: O3,
  children: R3,
  claim_svg_element: L3,
  detach: M3,
  init: N3,
  insert_hydration: U3,
  noop: H3,
  safe_not_equal: G3,
  svg_element: z3
} = window.__gradio__svelte__internal, {
  SvelteComponent: q3,
  append_hydration: V3,
  attr: j3,
  children: W3,
  claim_svg_element: X3,
  detach: Y3,
  init: Z3,
  insert_hydration: K3,
  noop: J3,
  safe_not_equal: Q3,
  svg_element: eE
} = window.__gradio__svelte__internal, {
  SvelteComponent: wp,
  append_hydration: Dp,
  attr: pn,
  children: Pl,
  claim_svg_element: xl,
  detach: Za,
  init: Ep,
  insert_hydration: Cp,
  noop: Ka,
  safe_not_equal: Sp,
  svg_element: Bl
} = window.__gradio__svelte__internal;
function kp(n) {
  let e, t;
  return {
    c() {
      e = Bl("svg"), t = Bl("path"), this.h();
    },
    l(i) {
      e = xl(i, "svg", {
        id: !0,
        xmlns: !0,
        viewBox: !0,
        width: !0,
        height: !0
      });
      var r = Pl(e);
      t = xl(r, "path", { d: !0, fill: !0 }), Pl(t).forEach(Za), r.forEach(Za), this.h();
    },
    h() {
      pn(t, "d", "M23,20a5,5,0,0,0-3.89,1.89L11.8,17.32a4.46,4.46,0,0,0,0-2.64l7.31-4.57A5,5,0,1,0,18,7a4.79,4.79,0,0,0,.2,1.32l-7.31,4.57a5,5,0,1,0,0,6.22l7.31,4.57A4.79,4.79,0,0,0,18,25a5,5,0,1,0,5-5ZM23,4a3,3,0,1,1-3,3A3,3,0,0,1,23,4ZM7,19a3,3,0,1,1,3-3A3,3,0,0,1,7,19Zm16,9a3,3,0,1,1,3-3A3,3,0,0,1,23,28Z"), pn(t, "fill", "currentColor"), pn(e, "id", "icon"), pn(e, "xmlns", "http://www.w3.org/2000/svg"), pn(e, "viewBox", "0 0 32 32"), pn(e, "width", "100%"), pn(e, "height", "100%");
    },
    m(i, r) {
      Cp(i, e, r), Dp(e, t);
    },
    p: Ka,
    i: Ka,
    o: Ka,
    d(i) {
      i && Za(e);
    }
  };
}
class Ap extends wp {
  constructor(e) {
    super(), Ep(this, e, null, kp, Sp, {});
  }
}
const {
  SvelteComponent: tE,
  append_hydration: nE,
  attr: iE,
  children: rE,
  claim_svg_element: aE,
  detach: sE,
  init: oE,
  insert_hydration: lE,
  noop: uE,
  safe_not_equal: cE,
  svg_element: fE
} = window.__gradio__svelte__internal, {
  SvelteComponent: hE,
  append_hydration: dE,
  attr: _E,
  children: pE,
  claim_svg_element: mE,
  detach: gE,
  init: bE,
  insert_hydration: vE,
  noop: yE,
  safe_not_equal: wE,
  svg_element: DE
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fp,
  append_hydration: Tp,
  attr: Jn,
  children: Ol,
  claim_svg_element: Rl,
  detach: Ja,
  init: Ip,
  insert_hydration: $p,
  noop: Qa,
  safe_not_equal: Pp,
  svg_element: Ll
} = window.__gradio__svelte__internal;
function xp(n) {
  let e, t;
  return {
    c() {
      e = Ll("svg"), t = Ll("path"), this.h();
    },
    l(i) {
      e = Rl(i, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var r = Ol(e);
      t = Rl(r, "path", { fill: !0, d: !0 }), Ol(t).forEach(Ja), r.forEach(Ja), this.h();
    },
    h() {
      Jn(t, "fill", "currentColor"), Jn(t, "d", "M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4zm0-10l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10l10-10z"), Jn(e, "xmlns", "http://www.w3.org/2000/svg"), Jn(e, "width", "100%"), Jn(e, "height", "100%"), Jn(e, "viewBox", "0 0 32 32");
    },
    m(i, r) {
      $p(i, e, r), Tp(e, t);
    },
    p: Qa,
    i: Qa,
    o: Qa,
    d(i) {
      i && Ja(e);
    }
  };
}
class Bp extends Fp {
  constructor(e) {
    super(), Ip(this, e, null, xp, Pp, {});
  }
}
const {
  SvelteComponent: EE,
  append_hydration: CE,
  attr: SE,
  children: kE,
  claim_svg_element: AE,
  detach: FE,
  init: TE,
  insert_hydration: IE,
  noop: $E,
  safe_not_equal: PE,
  svg_element: xE
} = window.__gradio__svelte__internal, {
  SvelteComponent: BE,
  append_hydration: OE,
  attr: RE,
  children: LE,
  claim_svg_element: ME,
  detach: NE,
  init: UE,
  insert_hydration: HE,
  noop: GE,
  safe_not_equal: zE,
  svg_element: qE
} = window.__gradio__svelte__internal, {
  SvelteComponent: VE,
  append_hydration: jE,
  attr: WE,
  children: XE,
  claim_svg_element: YE,
  detach: ZE,
  init: KE,
  insert_hydration: JE,
  noop: QE,
  safe_not_equal: eC,
  svg_element: tC
} = window.__gradio__svelte__internal, {
  SvelteComponent: nC,
  append_hydration: iC,
  attr: rC,
  children: aC,
  claim_svg_element: sC,
  detach: oC,
  init: lC,
  insert_hydration: uC,
  noop: cC,
  safe_not_equal: fC,
  svg_element: hC
} = window.__gradio__svelte__internal, {
  SvelteComponent: dC,
  append_hydration: _C,
  attr: pC,
  children: mC,
  claim_svg_element: gC,
  detach: bC,
  init: vC,
  insert_hydration: yC,
  noop: wC,
  safe_not_equal: DC,
  svg_element: EC
} = window.__gradio__svelte__internal, {
  SvelteComponent: CC,
  append_hydration: SC,
  attr: kC,
  children: AC,
  claim_svg_element: FC,
  detach: TC,
  init: IC,
  insert_hydration: $C,
  noop: PC,
  safe_not_equal: xC,
  svg_element: BC
} = window.__gradio__svelte__internal, {
  SvelteComponent: Op,
  append_hydration: Rp,
  attr: gt,
  children: Ml,
  claim_svg_element: Nl,
  detach: es,
  init: Lp,
  insert_hydration: Mp,
  noop: ts,
  safe_not_equal: Np,
  svg_element: Ul
} = window.__gradio__svelte__internal;
function Up(n) {
  let e, t;
  return {
    c() {
      e = Ul("svg"), t = Ul("path"), this.h();
    },
    l(i) {
      e = Nl(i, "svg", {
        xmlns: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0,
        width: !0,
        height: !0
      });
      var r = Ml(e);
      t = Nl(r, "path", { d: !0 });
      var a = Ml(t);
      a.forEach(es), r.forEach(es), this.h();
    },
    h() {
      gt(t, "d", "M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"), gt(e, "xmlns", "http://www.w3.org/2000/svg"), gt(e, "viewBox", "0 0 24 24"), gt(e, "fill", "none"), gt(e, "stroke", "currentColor"), gt(e, "stroke-width", "2"), gt(e, "stroke-linecap", "round"), gt(e, "stroke-linejoin", "round"), gt(e, "class", "feather feather-maximize"), gt(e, "width", "100%"), gt(e, "height", "100%");
    },
    m(i, r) {
      Mp(i, e, r), Rp(e, t);
    },
    p: ts,
    i: ts,
    o: ts,
    d(i) {
      i && es(e);
    }
  };
}
class Hp extends Op {
  constructor(e) {
    super(), Lp(this, e, null, Up, Np, {});
  }
}
const {
  SvelteComponent: OC,
  append_hydration: RC,
  attr: LC,
  children: MC,
  claim_svg_element: NC,
  detach: UC,
  init: HC,
  insert_hydration: GC,
  noop: zC,
  safe_not_equal: qC,
  svg_element: VC
} = window.__gradio__svelte__internal, {
  SvelteComponent: jC,
  append_hydration: WC,
  attr: XC,
  children: YC,
  claim_svg_element: ZC,
  detach: KC,
  init: JC,
  insert_hydration: QC,
  noop: eS,
  safe_not_equal: tS,
  svg_element: nS
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gp,
  append_hydration: zp,
  attr: it,
  children: Hl,
  claim_svg_element: Gl,
  detach: ns,
  init: qp,
  insert_hydration: Vp,
  noop: is,
  safe_not_equal: jp,
  svg_element: zl
} = window.__gradio__svelte__internal;
function Wp(n) {
  let e, t;
  return {
    c() {
      e = zl("svg"), t = zl("path"), this.h();
    },
    l(i) {
      e = Gl(i, "svg", {
        fill: !0,
        stroke: !0,
        viewBox: !0,
        width: !0,
        height: !0,
        xmlns: !0,
        "aria-hidden": !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      });
      var r = Hl(e);
      t = Gl(r, "path", {
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        d: !0
      }), Hl(t).forEach(ns), r.forEach(ns), this.h();
    },
    h() {
      it(t, "stroke-linecap", "round"), it(t, "stroke-linejoin", "round"), it(t, "d", "M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z"), it(e, "fill", "none"), it(e, "stroke", "currentColor"), it(e, "viewBox", "0 0 24 24"), it(e, "width", "100%"), it(e, "height", "100%"), it(e, "xmlns", "http://www.w3.org/2000/svg"), it(e, "aria-hidden", "true"), it(e, "stroke-width", "2"), it(e, "stroke-linecap", "round"), it(e, "stroke-linejoin", "round");
    },
    m(i, r) {
      Vp(i, e, r), zp(e, t);
    },
    p: is,
    i: is,
    o: is,
    d(i) {
      i && ns(e);
    }
  };
}
class vf extends Gp {
  constructor(e) {
    super(), qp(this, e, null, Wp, jp, {});
  }
}
const {
  SvelteComponent: iS,
  append_hydration: rS,
  attr: aS,
  children: sS,
  claim_svg_element: oS,
  detach: lS,
  init: uS,
  insert_hydration: cS,
  noop: fS,
  safe_not_equal: hS,
  svg_element: dS
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xp,
  append_hydration: rs,
  attr: ye,
  children: vr,
  claim_svg_element: yr,
  detach: Si,
  init: Yp,
  insert_hydration: Zp,
  noop: as,
  safe_not_equal: Kp,
  svg_element: wr
} = window.__gradio__svelte__internal;
function Jp(n) {
  let e, t, i, r;
  return {
    c() {
      e = wr("svg"), t = wr("rect"), i = wr("circle"), r = wr("polyline"), this.h();
    },
    l(a) {
      e = yr(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var s = vr(e);
      t = yr(s, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        ry: !0
      }), vr(t).forEach(Si), i = yr(s, "circle", { cx: !0, cy: !0, r: !0 }), vr(i).forEach(Si), r = yr(s, "polyline", { points: !0 }), vr(r).forEach(Si), s.forEach(Si), this.h();
    },
    h() {
      ye(t, "x", "3"), ye(t, "y", "3"), ye(t, "width", "18"), ye(t, "height", "18"), ye(t, "rx", "2"), ye(t, "ry", "2"), ye(i, "cx", "8.5"), ye(i, "cy", "8.5"), ye(i, "r", "1.5"), ye(r, "points", "21 15 16 10 5 21"), ye(e, "xmlns", "http://www.w3.org/2000/svg"), ye(e, "width", "100%"), ye(e, "height", "100%"), ye(e, "viewBox", "0 0 24 24"), ye(e, "fill", "none"), ye(e, "stroke", "currentColor"), ye(e, "stroke-width", "1.5"), ye(e, "stroke-linecap", "round"), ye(e, "stroke-linejoin", "round"), ye(e, "class", "feather feather-image");
    },
    m(a, s) {
      Zp(a, e, s), rs(e, t), rs(e, i), rs(e, r);
    },
    p: as,
    i: as,
    o: as,
    d(a) {
      a && Si(e);
    }
  };
}
let ko = class extends Xp {
  constructor(e) {
    super(), Yp(this, e, null, Jp, Kp, {});
  }
};
const {
  SvelteComponent: Qp,
  append_hydration: em,
  attr: Qn,
  children: ql,
  claim_svg_element: Vl,
  detach: ss,
  init: tm,
  insert_hydration: nm,
  noop: os,
  safe_not_equal: im,
  svg_element: jl
} = window.__gradio__svelte__internal;
function rm(n) {
  let e, t;
  return {
    c() {
      e = jl("svg"), t = jl("path"), this.h();
    },
    l(i) {
      e = Vl(i, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var r = ql(e);
      t = Vl(r, "path", { fill: !0, d: !0 }), ql(t).forEach(ss), r.forEach(ss), this.h();
    },
    h() {
      Qn(t, "fill", "currentColor"), Qn(t, "d", "M200 32h-36.26a47.92 47.92 0 0 0-71.48 0H56a16 16 0 0 0-16 16v168a16 16 0 0 0 16 16h144a16 16 0 0 0 16-16V48a16 16 0 0 0-16-16m-72 0a32 32 0 0 1 32 32H96a32 32 0 0 1 32-32m72 184H56V48h26.75A47.9 47.9 0 0 0 80 64v8a8 8 0 0 0 8 8h80a8 8 0 0 0 8-8v-8a47.9 47.9 0 0 0-2.75-16H200Z"), Qn(e, "xmlns", "http://www.w3.org/2000/svg"), Qn(e, "width", "100%"), Qn(e, "height", "100%"), Qn(e, "viewBox", "0 0 256 256");
    },
    m(i, r) {
      nm(i, e, r), em(e, t);
    },
    p: os,
    i: os,
    o: os,
    d(i) {
      i && ss(e);
    }
  };
}
class am extends Qp {
  constructor(e) {
    super(), tm(this, e, null, rm, im, {});
  }
}
const {
  SvelteComponent: pS,
  append_hydration: mS,
  attr: gS,
  children: bS,
  claim_svg_element: vS,
  detach: yS,
  init: wS,
  insert_hydration: DS,
  noop: ES,
  safe_not_equal: CS,
  svg_element: SS
} = window.__gradio__svelte__internal, {
  SvelteComponent: kS,
  append_hydration: AS,
  attr: FS,
  children: TS,
  claim_svg_element: IS,
  detach: $S,
  init: PS,
  insert_hydration: xS,
  noop: BS,
  safe_not_equal: OS,
  svg_element: RS
} = window.__gradio__svelte__internal, {
  SvelteComponent: LS,
  append_hydration: MS,
  attr: NS,
  children: US,
  claim_svg_element: HS,
  detach: GS,
  init: zS,
  insert_hydration: qS,
  noop: VS,
  safe_not_equal: jS,
  svg_element: WS
} = window.__gradio__svelte__internal, {
  SvelteComponent: XS,
  append_hydration: YS,
  attr: ZS,
  children: KS,
  claim_svg_element: JS,
  detach: QS,
  init: ek,
  insert_hydration: tk,
  noop: nk,
  safe_not_equal: ik,
  svg_element: rk
} = window.__gradio__svelte__internal, {
  SvelteComponent: ak,
  append_hydration: sk,
  attr: ok,
  children: lk,
  claim_svg_element: uk,
  detach: ck,
  init: fk,
  insert_hydration: hk,
  noop: dk,
  safe_not_equal: _k,
  svg_element: pk
} = window.__gradio__svelte__internal, {
  SvelteComponent: sm,
  append_hydration: om,
  attr: bt,
  children: Wl,
  claim_svg_element: Xl,
  detach: ls,
  init: lm,
  insert_hydration: um,
  noop: us,
  safe_not_equal: cm,
  svg_element: Yl
} = window.__gradio__svelte__internal;
function fm(n) {
  let e, t;
  return {
    c() {
      e = Yl("svg"), t = Yl("path"), this.h();
    },
    l(i) {
      e = Xl(i, "svg", {
        xmlns: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0,
        width: !0,
        height: !0
      });
      var r = Wl(e);
      t = Xl(r, "path", { d: !0 }), Wl(t).forEach(ls), r.forEach(ls), this.h();
    },
    h() {
      bt(t, "d", "M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"), bt(e, "xmlns", "http://www.w3.org/2000/svg"), bt(e, "viewBox", "0 0 24 24"), bt(e, "fill", "none"), bt(e, "stroke", "currentColor"), bt(e, "stroke-width", "2"), bt(e, "stroke-linecap", "round"), bt(e, "stroke-linejoin", "round"), bt(e, "class", "feather feather-minimize"), bt(e, "width", "100%"), bt(e, "height", "100%");
    },
    m(i, r) {
      um(i, e, r), om(e, t);
    },
    p: us,
    i: us,
    o: us,
    d(i) {
      i && ls(e);
    }
  };
}
class hm extends sm {
  constructor(e) {
    super(), lm(this, e, null, fm, cm, {});
  }
}
const {
  SvelteComponent: mk,
  append_hydration: gk,
  attr: bk,
  children: vk,
  claim_svg_element: yk,
  detach: wk,
  init: Dk,
  insert_hydration: Ek,
  noop: Ck,
  safe_not_equal: Sk,
  svg_element: kk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ak,
  append_hydration: Fk,
  attr: Tk,
  children: Ik,
  claim_svg_element: $k,
  detach: Pk,
  init: xk,
  insert_hydration: Bk,
  noop: Ok,
  safe_not_equal: Rk,
  svg_element: Lk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mk,
  append_hydration: Nk,
  attr: Uk,
  children: Hk,
  claim_svg_element: Gk,
  detach: zk,
  init: qk,
  insert_hydration: Vk,
  noop: jk,
  safe_not_equal: Wk,
  svg_element: Xk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yk,
  append_hydration: Zk,
  attr: Kk,
  children: Jk,
  claim_svg_element: Qk,
  detach: e4,
  init: t4,
  insert_hydration: n4,
  noop: i4,
  safe_not_equal: r4,
  svg_element: a4
} = window.__gradio__svelte__internal, {
  SvelteComponent: s4,
  append_hydration: o4,
  attr: l4,
  children: u4,
  claim_svg_element: c4,
  detach: f4,
  init: h4,
  insert_hydration: d4,
  noop: _4,
  safe_not_equal: p4,
  svg_element: m4
} = window.__gradio__svelte__internal, {
  SvelteComponent: g4,
  append_hydration: b4,
  attr: v4,
  children: y4,
  claim_svg_element: w4,
  detach: D4,
  init: E4,
  insert_hydration: C4,
  noop: S4,
  safe_not_equal: k4,
  svg_element: A4
} = window.__gradio__svelte__internal, {
  SvelteComponent: F4,
  append_hydration: T4,
  attr: I4,
  children: $4,
  claim_svg_element: P4,
  detach: x4,
  init: B4,
  insert_hydration: O4,
  noop: R4,
  safe_not_equal: L4,
  svg_element: M4
} = window.__gradio__svelte__internal, {
  SvelteComponent: N4,
  append_hydration: U4,
  attr: H4,
  children: G4,
  claim_svg_element: z4,
  detach: q4,
  init: V4,
  insert_hydration: j4,
  noop: W4,
  safe_not_equal: X4,
  svg_element: Y4
} = window.__gradio__svelte__internal, {
  SvelteComponent: Z4,
  append_hydration: K4,
  attr: J4,
  children: Q4,
  claim_svg_element: eA,
  detach: tA,
  init: nA,
  insert_hydration: iA,
  noop: rA,
  safe_not_equal: aA,
  set_style: sA,
  svg_element: oA
} = window.__gradio__svelte__internal, {
  SvelteComponent: lA,
  append_hydration: uA,
  attr: cA,
  children: fA,
  claim_svg_element: hA,
  detach: dA,
  init: _A,
  insert_hydration: pA,
  noop: mA,
  safe_not_equal: gA,
  svg_element: bA
} = window.__gradio__svelte__internal, {
  SvelteComponent: vA,
  append_hydration: yA,
  attr: wA,
  children: DA,
  claim_svg_element: EA,
  detach: CA,
  init: SA,
  insert_hydration: kA,
  noop: AA,
  safe_not_equal: FA,
  svg_element: TA
} = window.__gradio__svelte__internal, {
  SvelteComponent: IA,
  append_hydration: $A,
  attr: PA,
  children: xA,
  claim_svg_element: BA,
  detach: OA,
  init: RA,
  insert_hydration: LA,
  noop: MA,
  safe_not_equal: NA,
  svg_element: UA
} = window.__gradio__svelte__internal, {
  SvelteComponent: HA,
  append_hydration: GA,
  attr: zA,
  children: qA,
  claim_svg_element: VA,
  detach: jA,
  init: WA,
  insert_hydration: XA,
  noop: YA,
  safe_not_equal: ZA,
  svg_element: KA
} = window.__gradio__svelte__internal, {
  SvelteComponent: JA,
  append_hydration: QA,
  attr: eF,
  children: tF,
  claim_svg_element: nF,
  detach: iF,
  init: rF,
  insert_hydration: aF,
  noop: sF,
  safe_not_equal: oF,
  svg_element: lF
} = window.__gradio__svelte__internal, {
  SvelteComponent: uF,
  append_hydration: cF,
  attr: fF,
  children: hF,
  claim_svg_element: dF,
  detach: _F,
  init: pF,
  insert_hydration: mF,
  noop: gF,
  safe_not_equal: bF,
  svg_element: vF
} = window.__gradio__svelte__internal, {
  SvelteComponent: yF,
  append_hydration: wF,
  attr: DF,
  children: EF,
  claim_svg_element: CF,
  detach: SF,
  init: kF,
  insert_hydration: AF,
  noop: FF,
  safe_not_equal: TF,
  svg_element: IF
} = window.__gradio__svelte__internal, {
  SvelteComponent: $F,
  append_hydration: PF,
  attr: xF,
  children: BF,
  claim_svg_element: OF,
  detach: RF,
  init: LF,
  insert_hydration: MF,
  noop: NF,
  safe_not_equal: UF,
  svg_element: HF
} = window.__gradio__svelte__internal, {
  SvelteComponent: GF,
  append_hydration: zF,
  attr: qF,
  children: VF,
  claim_svg_element: jF,
  claim_text: WF,
  detach: XF,
  init: YF,
  insert_hydration: ZF,
  noop: KF,
  safe_not_equal: JF,
  svg_element: QF,
  text: eT
} = window.__gradio__svelte__internal, {
  SvelteComponent: tT,
  append_hydration: nT,
  attr: iT,
  children: rT,
  claim_svg_element: aT,
  detach: sT,
  init: oT,
  insert_hydration: lT,
  noop: uT,
  safe_not_equal: cT,
  svg_element: fT
} = window.__gradio__svelte__internal, {
  SvelteComponent: hT,
  append_hydration: dT,
  attr: _T,
  children: pT,
  claim_svg_element: mT,
  detach: gT,
  init: bT,
  insert_hydration: vT,
  noop: yT,
  safe_not_equal: wT,
  svg_element: DT
} = window.__gradio__svelte__internal, {
  SvelteComponent: ET,
  append_hydration: CT,
  attr: ST,
  children: kT,
  claim_svg_element: AT,
  detach: FT,
  init: TT,
  insert_hydration: IT,
  noop: $T,
  safe_not_equal: PT,
  svg_element: xT
} = window.__gradio__svelte__internal, {
  SvelteComponent: dm,
  append_hydration: cs,
  attr: Re,
  children: Dr,
  claim_svg_element: Er,
  detach: ki,
  init: _m,
  insert_hydration: pm,
  noop: fs,
  safe_not_equal: mm,
  svg_element: Cr
} = window.__gradio__svelte__internal;
function gm(n) {
  let e, t, i, r;
  return {
    c() {
      e = Cr("svg"), t = Cr("path"), i = Cr("polyline"), r = Cr("line"), this.h();
    },
    l(a) {
      e = Er(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var s = Dr(e);
      t = Er(s, "path", { d: !0 }), Dr(t).forEach(ki), i = Er(s, "polyline", { points: !0 }), Dr(i).forEach(ki), r = Er(s, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), Dr(r).forEach(ki), s.forEach(ki), this.h();
    },
    h() {
      Re(t, "d", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"), Re(i, "points", "17 8 12 3 7 8"), Re(r, "x1", "12"), Re(r, "y1", "3"), Re(r, "x2", "12"), Re(r, "y2", "15"), Re(e, "xmlns", "http://www.w3.org/2000/svg"), Re(e, "width", "90%"), Re(e, "height", "90%"), Re(e, "viewBox", "0 0 24 24"), Re(e, "fill", "none"), Re(e, "stroke", "currentColor"), Re(e, "stroke-width", "2"), Re(e, "stroke-linecap", "round"), Re(e, "stroke-linejoin", "round"), Re(e, "class", "feather feather-upload");
    },
    m(a, s) {
      pm(a, e, s), cs(e, t), cs(e, i), cs(e, r);
    },
    p: fs,
    i: fs,
    o: fs,
    d(a) {
      a && ki(e);
    }
  };
}
let bm = class extends dm {
  constructor(e) {
    super(), _m(this, e, null, gm, mm, {});
  }
};
const {
  SvelteComponent: OT,
  append_hydration: RT,
  attr: LT,
  children: MT,
  claim_svg_element: NT,
  detach: UT,
  init: HT,
  insert_hydration: GT,
  noop: zT,
  safe_not_equal: qT,
  svg_element: VT
} = window.__gradio__svelte__internal, {
  SvelteComponent: jT,
  append_hydration: WT,
  attr: XT,
  children: YT,
  claim_svg_element: ZT,
  detach: KT,
  init: JT,
  insert_hydration: QT,
  noop: e5,
  safe_not_equal: t5,
  svg_element: n5
} = window.__gradio__svelte__internal, {
  SvelteComponent: i5,
  append_hydration: r5,
  attr: a5,
  children: s5,
  claim_svg_element: o5,
  detach: l5,
  init: u5,
  insert_hydration: c5,
  noop: f5,
  safe_not_equal: h5,
  svg_element: d5
} = window.__gradio__svelte__internal, {
  SvelteComponent: _5,
  append_hydration: p5,
  attr: m5,
  children: g5,
  claim_svg_element: b5,
  claim_text: v5,
  detach: y5,
  init: w5,
  insert_hydration: D5,
  noop: E5,
  safe_not_equal: C5,
  svg_element: S5,
  text: k5
} = window.__gradio__svelte__internal, {
  SvelteComponent: A5,
  append_hydration: F5,
  attr: T5,
  children: I5,
  claim_svg_element: $5,
  claim_text: P5,
  detach: x5,
  init: B5,
  insert_hydration: O5,
  noop: R5,
  safe_not_equal: L5,
  svg_element: M5,
  text: N5
} = window.__gradio__svelte__internal, {
  SvelteComponent: U5,
  append_hydration: H5,
  attr: G5,
  children: z5,
  claim_svg_element: q5,
  claim_text: V5,
  detach: j5,
  init: W5,
  insert_hydration: X5,
  noop: Y5,
  safe_not_equal: Z5,
  svg_element: K5,
  text: J5
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q5,
  append_hydration: e8,
  attr: t8,
  children: n8,
  claim_svg_element: i8,
  detach: r8,
  init: a8,
  insert_hydration: s8,
  noop: o8,
  safe_not_equal: l8,
  svg_element: u8
} = window.__gradio__svelte__internal, {
  SvelteComponent: c8,
  append_hydration: f8,
  attr: h8,
  children: d8,
  claim_svg_element: _8,
  detach: p8,
  init: m8,
  insert_hydration: g8,
  noop: b8,
  safe_not_equal: v8,
  svg_element: y8
} = window.__gradio__svelte__internal, {
  SvelteComponent: w8,
  append_hydration: D8,
  attr: E8,
  children: C8,
  claim_svg_element: S8,
  detach: k8,
  init: A8,
  insert_hydration: F8,
  noop: T8,
  safe_not_equal: I8,
  svg_element: $8
} = window.__gradio__svelte__internal, {
  SvelteComponent: P8,
  append_hydration: x8,
  attr: B8,
  children: O8,
  claim_svg_element: R8,
  detach: L8,
  init: M8,
  insert_hydration: N8,
  noop: U8,
  safe_not_equal: H8,
  svg_element: G8
} = window.__gradio__svelte__internal, {
  SvelteComponent: z8,
  append_hydration: q8,
  attr: V8,
  children: j8,
  claim_svg_element: W8,
  detach: X8,
  init: Y8,
  insert_hydration: Z8,
  noop: K8,
  safe_not_equal: J8,
  svg_element: Q8
} = window.__gradio__svelte__internal, {
  SvelteComponent: e7,
  append_hydration: t7,
  attr: n7,
  children: i7,
  claim_svg_element: r7,
  detach: a7,
  init: s7,
  insert_hydration: o7,
  noop: l7,
  safe_not_equal: u7,
  svg_element: c7
} = window.__gradio__svelte__internal, {
  SvelteComponent: f7,
  append_hydration: h7,
  attr: d7,
  children: _7,
  claim_svg_element: p7,
  detach: m7,
  init: g7,
  insert_hydration: b7,
  noop: v7,
  safe_not_equal: y7,
  svg_element: w7
} = window.__gradio__svelte__internal, {
  SvelteComponent: D7,
  append_hydration: E7,
  attr: C7,
  children: S7,
  claim_svg_element: k7,
  detach: A7,
  init: F7,
  insert_hydration: T7,
  noop: I7,
  safe_not_equal: $7,
  svg_element: P7
} = window.__gradio__svelte__internal, {
  SvelteComponent: vm,
  claim_component: ym,
  create_component: wm,
  destroy_component: Dm,
  init: Em,
  mount_component: Cm,
  safe_not_equal: Sm,
  transition_in: km,
  transition_out: Am
} = window.__gradio__svelte__internal, { createEventDispatcher: Fm } = window.__gradio__svelte__internal;
function Tm(n) {
  let e, t;
  return e = new _n({
    props: {
      Icon: Ap,
      label: (
        /*i18n*/
        n[2]("common.share")
      ),
      pending: (
        /*pending*/
        n[3]
      )
    }
  }), e.$on(
    "click",
    /*click_handler*/
    n[5]
  ), {
    c() {
      wm(e.$$.fragment);
    },
    l(i) {
      ym(e.$$.fragment, i);
    },
    m(i, r) {
      Cm(e, i, r), t = !0;
    },
    p(i, [r]) {
      const a = {};
      r & /*i18n*/
      4 && (a.label = /*i18n*/
      i[2]("common.share")), r & /*pending*/
      8 && (a.pending = /*pending*/
      i[3]), e.$set(a);
    },
    i(i) {
      t || (km(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Am(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Dm(e, i);
    }
  };
}
function Im(n, e, t) {
  const i = Fm();
  let { formatter: r } = e, { value: a } = e, { i18n: s } = e, o = !1;
  const l = async () => {
    try {
      t(3, o = !0);
      const c = await r(a);
      i("share", { description: c });
    } catch (c) {
      console.error(c);
      let u = c instanceof Nr ? c.message : "Share failed.";
      i("error", u);
    } finally {
      t(3, o = !1);
    }
  };
  return n.$$set = (c) => {
    "formatter" in c && t(0, r = c.formatter), "value" in c && t(1, a = c.value), "i18n" in c && t(2, s = c.i18n);
  }, [r, a, s, o, i, l];
}
class $m extends vm {
  constructor(e) {
    super(), Em(this, e, Im, Tm, Sm, { formatter: 0, value: 1, i18n: 2 });
  }
}
const Pm = /^(#\s*)(.+)$/m;
function xm(n) {
  const e = n.trim(), t = e.match(Pm);
  if (!t)
    return [!1, e || !1];
  const [i, , r] = t, a = r.trim();
  if (e === i)
    return [a, !1];
  const s = t.index !== void 0 ? t.index + i.length : 0, l = e.substring(s).trim() || !1;
  return [a, l];
}
const {
  SvelteComponent: Bm,
  append_hydration: Sn,
  attr: qi,
  check_outros: Om,
  children: Vi,
  claim_component: yf,
  claim_element: ji,
  claim_space: ya,
  claim_text: yn,
  create_component: wf,
  destroy_component: Df,
  detach: Ne,
  element: Wi,
  empty: Zr,
  group_outros: Rm,
  init: Lm,
  insert_hydration: Tt,
  mount_component: Ef,
  safe_not_equal: Mm,
  set_data: Xi,
  space: wa,
  text: wn,
  toggle_class: Zl,
  transition_in: Kr,
  transition_out: Jr
} = window.__gradio__svelte__internal;
function Nm(n) {
  let e, t;
  return e = new bm({}), {
    c() {
      wf(e.$$.fragment);
    },
    l(i) {
      yf(e.$$.fragment, i);
    },
    m(i, r) {
      Ef(e, i, r), t = !0;
    },
    i(i) {
      t || (Kr(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Jr(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Df(e, i);
    }
  };
}
function Um(n) {
  let e, t;
  return e = new am({}), {
    c() {
      wf(e.$$.fragment);
    },
    l(i) {
      yf(e.$$.fragment, i);
    },
    m(i, r) {
      Ef(e, i, r), t = !0;
    },
    i(i) {
      t || (Kr(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Jr(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Df(e, i);
    }
  };
}
function Hm(n) {
  let e = (
    /*i18n*/
    n[1](
      /*defs*/
      n[7][
        /*type*/
        n[0]
      ] || /*defs*/
      n[7].file
    ) + ""
  ), t, i, r, a = (
    /*mode*/
    n[3] !== "short" && Kl(n)
  );
  return {
    c() {
      t = wn(e), i = wa(), a && a.c(), r = Zr();
    },
    l(s) {
      t = yn(s, e), i = ya(s), a && a.l(s), r = Zr();
    },
    m(s, o) {
      Tt(s, t, o), Tt(s, i, o), a && a.m(s, o), Tt(s, r, o);
    },
    p(s, o) {
      o & /*i18n, type*/
      3 && e !== (e = /*i18n*/
      s[1](
        /*defs*/
        s[7][
          /*type*/
          s[0]
        ] || /*defs*/
        s[7].file
      ) + "") && Xi(t, e), /*mode*/
      s[3] !== "short" ? a ? a.p(s, o) : (a = Kl(s), a.c(), a.m(r.parentNode, r)) : a && (a.d(1), a = null);
    },
    d(s) {
      s && (Ne(t), Ne(i), Ne(r)), a && a.d(s);
    }
  };
}
function Gm(n) {
  let e, t, i = (
    /*heading*/
    n[6] && Jl(n)
  ), r = (
    /*paragraph*/
    n[5] && Ql(n)
  );
  return {
    c() {
      i && i.c(), e = wa(), r && r.c(), t = Zr();
    },
    l(a) {
      i && i.l(a), e = ya(a), r && r.l(a), t = Zr();
    },
    m(a, s) {
      i && i.m(a, s), Tt(a, e, s), r && r.m(a, s), Tt(a, t, s);
    },
    p(a, s) {
      /*heading*/
      a[6] ? i ? i.p(a, s) : (i = Jl(a), i.c(), i.m(e.parentNode, e)) : i && (i.d(1), i = null), /*paragraph*/
      a[5] ? r ? r.p(a, s) : (r = Ql(a), r.c(), r.m(t.parentNode, t)) : r && (r.d(1), r = null);
    },
    d(a) {
      a && (Ne(e), Ne(t)), i && i.d(a), r && r.d(a);
    }
  };
}
function Kl(n) {
  let e, t, i = (
    /*i18n*/
    n[1]("common.or") + ""
  ), r, a, s, o = (
    /*message*/
    (n[2] || /*i18n*/
    n[1]("upload_text.click_to_upload")) + ""
  ), l;
  return {
    c() {
      e = Wi("span"), t = wn("- "), r = wn(i), a = wn(" -"), s = wa(), l = wn(o), this.h();
    },
    l(c) {
      e = ji(c, "SPAN", { class: !0 });
      var u = Vi(e);
      t = yn(u, "- "), r = yn(u, i), a = yn(u, " -"), u.forEach(Ne), s = ya(c), l = yn(c, o), this.h();
    },
    h() {
      qi(e, "class", "or svelte-1xg7h5n");
    },
    m(c, u) {
      Tt(c, e, u), Sn(e, t), Sn(e, r), Sn(e, a), Tt(c, s, u), Tt(c, l, u);
    },
    p(c, u) {
      u & /*i18n*/
      2 && i !== (i = /*i18n*/
      c[1]("common.or") + "") && Xi(r, i), u & /*message, i18n*/
      6 && o !== (o = /*message*/
      (c[2] || /*i18n*/
      c[1]("upload_text.click_to_upload")) + "") && Xi(l, o);
    },
    d(c) {
      c && (Ne(e), Ne(s), Ne(l));
    }
  };
}
function Jl(n) {
  let e, t;
  return {
    c() {
      e = Wi("h2"), t = wn(
        /*heading*/
        n[6]
      ), this.h();
    },
    l(i) {
      e = ji(i, "H2", { class: !0 });
      var r = Vi(e);
      t = yn(
        r,
        /*heading*/
        n[6]
      ), r.forEach(Ne), this.h();
    },
    h() {
      qi(e, "class", "svelte-1xg7h5n");
    },
    m(i, r) {
      Tt(i, e, r), Sn(e, t);
    },
    p(i, r) {
      r & /*heading*/
      64 && Xi(
        t,
        /*heading*/
        i[6]
      );
    },
    d(i) {
      i && Ne(e);
    }
  };
}
function Ql(n) {
  let e, t;
  return {
    c() {
      e = Wi("p"), t = wn(
        /*paragraph*/
        n[5]
      ), this.h();
    },
    l(i) {
      e = ji(i, "P", { class: !0 });
      var r = Vi(e);
      t = yn(
        r,
        /*paragraph*/
        n[5]
      ), r.forEach(Ne), this.h();
    },
    h() {
      qi(e, "class", "svelte-1xg7h5n");
    },
    m(i, r) {
      Tt(i, e, r), Sn(e, t);
    },
    p(i, r) {
      r & /*paragraph*/
      32 && Xi(
        t,
        /*paragraph*/
        i[5]
      );
    },
    d(i) {
      i && Ne(e);
    }
  };
}
function zm(n) {
  let e, t, i, r, a, s;
  const o = [Um, Nm], l = [];
  function c(d, p) {
    return (
      /*type*/
      d[0] === "clipboard" ? 0 : 1
    );
  }
  i = c(n), r = l[i] = o[i](n);
  function u(d, p) {
    return (
      /*heading*/
      d[6] || /*paragraph*/
      d[5] ? Gm : Hm
    );
  }
  let f = u(n), h = f(n);
  return {
    c() {
      e = Wi("div"), t = Wi("span"), r.c(), a = wa(), h.c(), this.h();
    },
    l(d) {
      e = ji(d, "DIV", { class: !0 });
      var p = Vi(e);
      t = ji(p, "SPAN", { class: !0 });
      var g = Vi(t);
      r.l(g), g.forEach(Ne), a = ya(p), h.l(p), p.forEach(Ne), this.h();
    },
    h() {
      qi(t, "class", "icon-wrap svelte-1xg7h5n"), Zl(
        t,
        "hovered",
        /*hovered*/
        n[4]
      ), qi(e, "class", "wrap svelte-1xg7h5n");
    },
    m(d, p) {
      Tt(d, e, p), Sn(e, t), l[i].m(t, null), Sn(e, a), h.m(e, null), s = !0;
    },
    p(d, [p]) {
      let g = i;
      i = c(d), i !== g && (Rm(), Jr(l[g], 1, 1, () => {
        l[g] = null;
      }), Om(), r = l[i], r || (r = l[i] = o[i](d), r.c()), Kr(r, 1), r.m(t, null)), (!s || p & /*hovered*/
      16) && Zl(
        t,
        "hovered",
        /*hovered*/
        d[4]
      ), f === (f = u(d)) && h ? h.p(d, p) : (h.d(1), h = f(d), h && (h.c(), h.m(e, null)));
    },
    i(d) {
      s || (Kr(r), s = !0);
    },
    o(d) {
      Jr(r), s = !1;
    },
    d(d) {
      d && Ne(e), l[i].d(), h.d();
    }
  };
}
function qm(n, e, t) {
  let i, r, { type: a = "file" } = e, { i18n: s } = e, { message: o = void 0 } = e, { mode: l = "full" } = e, { hovered: c = !1 } = e, { placeholder: u = void 0 } = e;
  const f = {
    image: "upload_text.drop_image",
    video: "upload_text.drop_video",
    audio: "upload_text.drop_audio",
    file: "upload_text.drop_file",
    csv: "upload_text.drop_csv",
    gallery: "upload_text.drop_gallery",
    clipboard: "upload_text.paste_clipboard"
  };
  return n.$$set = (h) => {
    "type" in h && t(0, a = h.type), "i18n" in h && t(1, s = h.i18n), "message" in h && t(2, o = h.message), "mode" in h && t(3, l = h.mode), "hovered" in h && t(4, c = h.hovered), "placeholder" in h && t(8, u = h.placeholder);
  }, n.$$.update = () => {
    n.$$.dirty & /*placeholder*/
    256 && t(6, [i, r] = u ? xm(u) : [!1, !1], i, (t(5, r), t(8, u)));
  }, [a, s, o, l, c, r, i, f, u];
}
class Vm extends Bm {
  constructor(e) {
    super(), Lm(this, e, qm, zm, Mm, {
      type: 0,
      i18n: 1,
      message: 2,
      mode: 3,
      hovered: 4,
      placeholder: 8
    });
  }
}
const {
  SvelteComponent: x7,
  attr: B7,
  children: O7,
  claim_element: R7,
  create_slot: L7,
  detach: M7,
  element: N7,
  get_all_dirty_from_scope: U7,
  get_slot_changes: H7,
  init: G7,
  insert_hydration: z7,
  safe_not_equal: q7,
  toggle_class: V7,
  transition_in: j7,
  transition_out: W7,
  update_slot_base: X7
} = window.__gradio__svelte__internal, {
  SvelteComponent: Y7,
  append_hydration: Z7,
  attr: K7,
  check_outros: J7,
  children: Q7,
  claim_component: e6,
  claim_element: t6,
  claim_space: n6,
  create_component: i6,
  destroy_component: r6,
  detach: a6,
  element: s6,
  empty: o6,
  group_outros: l6,
  init: u6,
  insert_hydration: c6,
  listen: f6,
  mount_component: h6,
  safe_not_equal: d6,
  space: _6,
  toggle_class: p6,
  transition_in: m6,
  transition_out: g6
} = window.__gradio__svelte__internal, {
  SvelteComponent: jm,
  attr: eu,
  children: Wm,
  claim_element: Xm,
  create_slot: Ym,
  detach: tu,
  element: Zm,
  get_all_dirty_from_scope: Km,
  get_slot_changes: Jm,
  init: Qm,
  insert_hydration: eg,
  null_to_empty: nu,
  safe_not_equal: tg,
  transition_in: ng,
  transition_out: ig,
  update_slot_base: rg
} = window.__gradio__svelte__internal;
function ag(n) {
  let e, t, i;
  const r = (
    /*#slots*/
    n[3].default
  ), a = Ym(
    r,
    n,
    /*$$scope*/
    n[2],
    null
  );
  return {
    c() {
      e = Zm("div"), a && a.c(), this.h();
    },
    l(s) {
      e = Xm(s, "DIV", { class: !0 });
      var o = Wm(e);
      a && a.l(o), o.forEach(tu), this.h();
    },
    h() {
      eu(e, "class", t = nu(`icon-button-wrapper ${/*top_panel*/
      n[0] ? "top-panel" : ""} ${/*display_top_corner*/
      n[1] ? "display-top-corner" : "hide-top-corner"}`) + " svelte-109se4");
    },
    m(s, o) {
      eg(s, e, o), a && a.m(e, null), i = !0;
    },
    p(s, [o]) {
      a && a.p && (!i || o & /*$$scope*/
      4) && rg(
        a,
        r,
        s,
        /*$$scope*/
        s[2],
        i ? Jm(
          r,
          /*$$scope*/
          s[2],
          o,
          null
        ) : Km(
          /*$$scope*/
          s[2]
        ),
        null
      ), (!i || o & /*top_panel, display_top_corner*/
      3 && t !== (t = nu(`icon-button-wrapper ${/*top_panel*/
      s[0] ? "top-panel" : ""} ${/*display_top_corner*/
      s[1] ? "display-top-corner" : "hide-top-corner"}`) + " svelte-109se4")) && eu(e, "class", t);
    },
    i(s) {
      i || (ng(a, s), i = !0);
    },
    o(s) {
      ig(a, s), i = !1;
    },
    d(s) {
      s && tu(e), a && a.d(s);
    }
  };
}
function sg(n, e, t) {
  let { $$slots: i = {}, $$scope: r } = e, { top_panel: a = !0 } = e, { display_top_corner: s = !1 } = e;
  return n.$$set = (o) => {
    "top_panel" in o && t(0, a = o.top_panel), "display_top_corner" in o && t(1, s = o.display_top_corner), "$$scope" in o && t(2, r = o.$$scope);
  }, [a, s, r, i];
}
class Cf extends jm {
  constructor(e) {
    super(), Qm(this, e, sg, ag, tg, { top_panel: 0, display_top_corner: 1 });
  }
}
const {
  SvelteComponent: og,
  check_outros: lg,
  claim_component: Sf,
  create_component: kf,
  destroy_component: Af,
  detach: ug,
  empty: iu,
  group_outros: cg,
  init: fg,
  insert_hydration: hg,
  mount_component: Ff,
  noop: Tf,
  safe_not_equal: dg,
  transition_in: Qr,
  transition_out: ea
} = window.__gradio__svelte__internal, { createEventDispatcher: _g } = window.__gradio__svelte__internal;
function pg(n) {
  let e, t;
  return e = new _n({
    props: { Icon: Hp, label: "Fullscreen" }
  }), e.$on(
    "click",
    /*click_handler_1*/
    n[3]
  ), {
    c() {
      kf(e.$$.fragment);
    },
    l(i) {
      Sf(e.$$.fragment, i);
    },
    m(i, r) {
      Ff(e, i, r), t = !0;
    },
    p: Tf,
    i(i) {
      t || (Qr(e.$$.fragment, i), t = !0);
    },
    o(i) {
      ea(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Af(e, i);
    }
  };
}
function mg(n) {
  let e, t;
  return e = new _n({
    props: {
      Icon: hm,
      label: "Exit fullscreen mode"
    }
  }), e.$on(
    "click",
    /*click_handler*/
    n[2]
  ), {
    c() {
      kf(e.$$.fragment);
    },
    l(i) {
      Sf(e.$$.fragment, i);
    },
    m(i, r) {
      Ff(e, i, r), t = !0;
    },
    p: Tf,
    i(i) {
      t || (Qr(e.$$.fragment, i), t = !0);
    },
    o(i) {
      ea(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Af(e, i);
    }
  };
}
function gg(n) {
  let e, t, i, r;
  const a = [mg, pg], s = [];
  function o(l, c) {
    return (
      /*fullscreen*/
      l[0] ? 0 : 1
    );
  }
  return e = o(n), t = s[e] = a[e](n), {
    c() {
      t.c(), i = iu();
    },
    l(l) {
      t.l(l), i = iu();
    },
    m(l, c) {
      s[e].m(l, c), hg(l, i, c), r = !0;
    },
    p(l, [c]) {
      let u = e;
      e = o(l), e === u ? s[e].p(l, c) : (cg(), ea(s[u], 1, 1, () => {
        s[u] = null;
      }), lg(), t = s[e], t ? t.p(l, c) : (t = s[e] = a[e](l), t.c()), Qr(t, 1), t.m(i.parentNode, i));
    },
    i(l) {
      r || (Qr(t), r = !0);
    },
    o(l) {
      ea(t), r = !1;
    },
    d(l) {
      l && ug(i), s[e].d(l);
    }
  };
}
function bg(n, e, t) {
  const i = _g();
  let { fullscreen: r } = e;
  const a = () => i("fullscreen", !1), s = () => i("fullscreen", !0);
  return n.$$set = (o) => {
    "fullscreen" in o && t(0, r = o.fullscreen);
  }, [r, i, a, s];
}
class If extends og {
  constructor(e) {
    super(), fg(this, e, bg, gg, dg, { fullscreen: 0 });
  }
}
var Da = typeof self < "u" ? self : global;
const Yi = typeof navigator < "u", vg = Yi && typeof HTMLImageElement > "u", ta = !(typeof global > "u" || typeof process > "u" || !process.versions || !process.versions.node), Ao = Da.Buffer, Sr = Da.BigInt, Fo = !!Ao, yg = (n) => n;
function na(n, e = yg) {
  if (ta) try {
    return typeof require == "function" ? Promise.resolve(e(require(n))) : import(
      /* webpackIgnore: true */
      n
    ).then(e);
  } catch {
    console.warn(`Couldn't load ${n}`);
  }
}
let To = Da.fetch;
const wg = (n) => To = n;
if (!Da.fetch) {
  const n = na("http", (i) => i), e = na("https", (i) => i), t = (i, { headers: r } = {}) => new Promise(async (a, s) => {
    let { port: o, hostname: l, pathname: c, protocol: u, search: f } = new URL(i);
    const h = { method: "GET", hostname: l, path: encodeURI(c) + f, headers: r };
    o !== "" && (h.port = Number(o));
    const d = (u === "https:" ? await e : await n).request(h, (p) => {
      if (p.statusCode === 301 || p.statusCode === 302) {
        let g = new URL(p.headers.location, i).toString();
        return t(g, { headers: r }).then(a).catch(s);
      }
      a({ status: p.statusCode, arrayBuffer: () => new Promise((g) => {
        let E = [];
        p.on("data", (w) => E.push(w)), p.on("end", () => g(Buffer.concat(E)));
      }) });
    });
    d.on("error", s), d.end();
  });
  wg(t);
}
function U(n, e, t) {
  return e in n ? Object.defineProperty(n, e, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : n[e] = t, n;
}
const ia = (n) => $f(n) ? void 0 : n, Dg = (n) => n !== void 0;
function $f(n) {
  return n === void 0 || (n instanceof Map ? n.size === 0 : Object.values(n).filter(Dg).length === 0);
}
function De(n) {
  let e = new Error(n);
  throw delete e.stack, e;
}
function Dn(n) {
  return (n = function(e) {
    for (; e.endsWith("\0"); ) e = e.slice(0, -1);
    return e;
  }(n).trim()) === "" ? void 0 : n;
}
function Ms(n) {
  let e = function(t) {
    let i = 0;
    return t.ifd0.enabled && (i += 1024), t.exif.enabled && (i += 2048), t.makerNote && (i += 2048), t.userComment && (i += 1024), t.gps.enabled && (i += 512), t.interop.enabled && (i += 100), t.ifd1.enabled && (i += 1024), i + 2048;
  }(n);
  return n.jfif.enabled && (e += 50), n.xmp.enabled && (e += 2e4), n.iptc.enabled && (e += 14e3), n.icc.enabled && (e += 6e3), e;
}
const Ns = (n) => String.fromCharCode.apply(null, n), ru = typeof TextDecoder < "u" ? new TextDecoder("utf-8") : void 0;
function Pf(n) {
  return ru ? ru.decode(n) : Fo ? Buffer.from(n).toString("utf8") : decodeURIComponent(escape(Ns(n)));
}
class Qe {
  static from(e, t) {
    return e instanceof this && e.le === t ? e : new Qe(e, void 0, void 0, t);
  }
  constructor(e, t = 0, i, r) {
    if (typeof r == "boolean" && (this.le = r), Array.isArray(e) && (e = new Uint8Array(e)), e === 0) this.byteOffset = 0, this.byteLength = 0;
    else if (e instanceof ArrayBuffer) {
      i === void 0 && (i = e.byteLength - t);
      let a = new DataView(e, t, i);
      this._swapDataView(a);
    } else if (e instanceof Uint8Array || e instanceof DataView || e instanceof Qe) {
      i === void 0 && (i = e.byteLength - t), (t += e.byteOffset) + i > e.byteOffset + e.byteLength && De("Creating view outside of available memory in ArrayBuffer");
      let a = new DataView(e.buffer, t, i);
      this._swapDataView(a);
    } else if (typeof e == "number") {
      let a = new DataView(new ArrayBuffer(e));
      this._swapDataView(a);
    } else De("Invalid input argument for BufferView: " + e);
  }
  _swapArrayBuffer(e) {
    this._swapDataView(new DataView(e));
  }
  _swapBuffer(e) {
    this._swapDataView(new DataView(e.buffer, e.byteOffset, e.byteLength));
  }
  _swapDataView(e) {
    this.dataView = e, this.buffer = e.buffer, this.byteOffset = e.byteOffset, this.byteLength = e.byteLength;
  }
  _lengthToEnd(e) {
    return this.byteLength - e;
  }
  set(e, t, i = Qe) {
    return e instanceof DataView || e instanceof Qe ? e = new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : e instanceof ArrayBuffer && (e = new Uint8Array(e)), e instanceof Uint8Array || De("BufferView.set(): Invalid data argument."), this.toUint8().set(e, t), new i(this, t, e.byteLength);
  }
  subarray(e, t) {
    return t = t || this._lengthToEnd(e), new Qe(this, e, t);
  }
  toUint8() {
    return new Uint8Array(this.buffer, this.byteOffset, this.byteLength);
  }
  getUint8Array(e, t) {
    return new Uint8Array(this.buffer, this.byteOffset + e, t);
  }
  getString(e = 0, t = this.byteLength) {
    return Pf(this.getUint8Array(e, t));
  }
  getLatin1String(e = 0, t = this.byteLength) {
    let i = this.getUint8Array(e, t);
    return Ns(i);
  }
  getUnicodeString(e = 0, t = this.byteLength) {
    const i = [];
    for (let r = 0; r < t && e + r < this.byteLength; r += 2) i.push(this.getUint16(e + r));
    return Ns(i);
  }
  getInt8(e) {
    return this.dataView.getInt8(e);
  }
  getUint8(e) {
    return this.dataView.getUint8(e);
  }
  getInt16(e, t = this.le) {
    return this.dataView.getInt16(e, t);
  }
  getInt32(e, t = this.le) {
    return this.dataView.getInt32(e, t);
  }
  getUint16(e, t = this.le) {
    return this.dataView.getUint16(e, t);
  }
  getUint32(e, t = this.le) {
    return this.dataView.getUint32(e, t);
  }
  getFloat32(e, t = this.le) {
    return this.dataView.getFloat32(e, t);
  }
  getFloat64(e, t = this.le) {
    return this.dataView.getFloat64(e, t);
  }
  getFloat(e, t = this.le) {
    return this.dataView.getFloat32(e, t);
  }
  getDouble(e, t = this.le) {
    return this.dataView.getFloat64(e, t);
  }
  getUintBytes(e, t, i) {
    switch (t) {
      case 1:
        return this.getUint8(e, i);
      case 2:
        return this.getUint16(e, i);
      case 4:
        return this.getUint32(e, i);
      case 8:
        return this.getUint64 && this.getUint64(e, i);
    }
  }
  getUint(e, t, i) {
    switch (t) {
      case 8:
        return this.getUint8(e, i);
      case 16:
        return this.getUint16(e, i);
      case 32:
        return this.getUint32(e, i);
      case 64:
        return this.getUint64 && this.getUint64(e, i);
    }
  }
  toString(e) {
    return this.dataView.toString(e, this.constructor.name);
  }
  ensureChunk() {
  }
}
function Us(n, e) {
  De(`${n} '${e}' was not loaded, try using full build of exifr.`);
}
class Io extends Map {
  constructor(e) {
    super(), this.kind = e;
  }
  get(e, t) {
    return this.has(e) || Us(this.kind, e), t && (e in t || function(i, r) {
      De(`Unknown ${i} '${r}'.`);
    }(this.kind, e), t[e].enabled || Us(this.kind, e)), super.get(e);
  }
  keyList() {
    return Array.from(this.keys());
  }
}
var li = new Io("file parser"), Me = new Io("segment parser"), mi = new Io("file reader");
function Eg(n, e) {
  return typeof n == "string" ? au(n, e) : Yi && !vg && n instanceof HTMLImageElement ? au(n.src, e) : n instanceof Uint8Array || n instanceof ArrayBuffer || n instanceof DataView ? new Qe(n) : Yi && n instanceof Blob ? Hs(n, e, "blob", qs) : void De("Invalid input argument");
}
function au(n, e) {
  return (t = n).startsWith("data:") || t.length > 1e4 ? Gs(n, e, "base64") : ta && n.includes("://") ? Hs(n, e, "url", zs) : ta ? Gs(n, e, "fs") : Yi ? Hs(n, e, "url", zs) : void De("Invalid input argument");
  var t;
}
async function Hs(n, e, t, i) {
  return mi.has(t) ? Gs(n, e, t) : i ? async function(r, a) {
    let s = await a(r);
    return new Qe(s);
  }(n, i) : void De(`Parser ${t} is not loaded`);
}
async function Gs(n, e, t) {
  let i = new (mi.get(t))(n, e);
  return await i.read(), i;
}
const zs = (n) => To(n).then((e) => e.arrayBuffer()), qs = (n) => new Promise((e, t) => {
  let i = new FileReader();
  i.onloadend = () => e(i.result || new ArrayBuffer()), i.onerror = t, i.readAsArrayBuffer(n);
});
class Cg extends Map {
  get tagKeys() {
    return this.allKeys || (this.allKeys = Array.from(this.keys())), this.allKeys;
  }
  get tagValues() {
    return this.allValues || (this.allValues = Array.from(this.values())), this.allValues;
  }
}
function $e(n, e, t) {
  let i = new Cg();
  for (let [r, a] of t) i.set(r, a);
  if (Array.isArray(e)) for (let r of e) n.set(r, i);
  else n.set(e, i);
  return i;
}
function Vs(n, e, t) {
  let i, r = n.get(e);
  for (i of t) r.set(i[0], i[1]);
}
const tt = /* @__PURE__ */ new Map(), Hn = /* @__PURE__ */ new Map(), Hr = /* @__PURE__ */ new Map(), kr = ["chunked", "firstChunkSize", "firstChunkSizeNode", "firstChunkSizeBrowser", "chunkSize", "chunkLimit"], xf = ["jfif", "xmp", "icc", "iptc", "ihdr"], js = ["tiff", ...xf], Ae = ["ifd0", "ifd1", "exif", "gps", "interop"], Ar = [...js, ...Ae], Fr = ["makerNote", "userComment"], Bf = ["translateKeys", "translateValues", "reviveValues", "multiSegment"], Tr = [...Bf, "sanitize", "mergeOutput", "silentErrors"];
class Of {
  get translate() {
    return this.translateKeys || this.translateValues || this.reviveValues;
  }
}
let Ai = class extends Of {
  get needed() {
    return this.enabled || this.deps.size > 0;
  }
  constructor(e, t, i, r) {
    if (super(), U(this, "enabled", !1), U(this, "skip", /* @__PURE__ */ new Set()), U(this, "pick", /* @__PURE__ */ new Set()), U(this, "deps", /* @__PURE__ */ new Set()), U(this, "translateKeys", !1), U(this, "translateValues", !1), U(this, "reviveValues", !1), this.key = e, this.enabled = t, this.parse = this.enabled, this.applyInheritables(r), this.canBeFiltered = Ae.includes(e), this.canBeFiltered && (this.dict = tt.get(e)), i !== void 0) if (Array.isArray(i)) this.parse = this.enabled = !0, this.canBeFiltered && i.length > 0 && this.translateTagSet(i, this.pick);
    else if (typeof i == "object") {
      if (this.enabled = !0, this.parse = i.parse !== !1, this.canBeFiltered) {
        let { pick: a, skip: s } = i;
        a && a.length > 0 && this.translateTagSet(a, this.pick), s && s.length > 0 && this.translateTagSet(s, this.skip);
      }
      this.applyInheritables(i);
    } else i === !0 || i === !1 ? this.parse = this.enabled = i : De(`Invalid options argument: ${i}`);
  }
  applyInheritables(e) {
    let t, i;
    for (t of Bf) i = e[t], i !== void 0 && (this[t] = i);
  }
  translateTagSet(e, t) {
    if (this.dict) {
      let i, r, { tagKeys: a, tagValues: s } = this.dict;
      for (i of e) typeof i == "string" ? (r = s.indexOf(i), r === -1 && (r = a.indexOf(Number(i))), r !== -1 && t.add(Number(a[r]))) : t.add(i);
    } else for (let i of e) t.add(i);
  }
  finalizeFilters() {
    !this.enabled && this.deps.size > 0 ? (this.enabled = !0, ra(this.pick, this.deps)) : this.enabled && this.pick.size > 0 && ra(this.pick, this.deps);
  }
};
var We = { jfif: !1, tiff: !0, xmp: !1, icc: !1, iptc: !1, ifd0: !0, ifd1: !1, exif: !0, gps: !0, interop: !1, ihdr: void 0, makerNote: !1, userComment: !1, multiSegment: !1, skip: [], pick: [], translateKeys: !0, translateValues: !0, reviveValues: !0, sanitize: !0, mergeOutput: !0, silentErrors: !0, chunked: !0, firstChunkSize: void 0, firstChunkSizeNode: 512, firstChunkSizeBrowser: 65536, chunkSize: 65536, chunkLimit: 5 }, su = /* @__PURE__ */ new Map();
class $o extends Of {
  static useCached(e) {
    let t = su.get(e);
    return t !== void 0 || (t = new this(e), su.set(e, t)), t;
  }
  constructor(e) {
    super(), e === !0 ? this.setupFromTrue() : e === void 0 ? this.setupFromUndefined() : Array.isArray(e) ? this.setupFromArray(e) : typeof e == "object" ? this.setupFromObject(e) : De(`Invalid options argument ${e}`), this.firstChunkSize === void 0 && (this.firstChunkSize = Yi ? this.firstChunkSizeBrowser : this.firstChunkSizeNode), this.mergeOutput && (this.ifd1.enabled = !1), this.filterNestedSegmentTags(), this.traverseTiffDependencyTree(), this.checkLoadedPlugins();
  }
  setupFromUndefined() {
    let e;
    for (e of kr) this[e] = We[e];
    for (e of Tr) this[e] = We[e];
    for (e of Fr) this[e] = We[e];
    for (e of Ar) this[e] = new Ai(e, We[e], void 0, this);
  }
  setupFromTrue() {
    let e;
    for (e of kr) this[e] = We[e];
    for (e of Tr) this[e] = We[e];
    for (e of Fr) this[e] = !0;
    for (e of Ar) this[e] = new Ai(e, !0, void 0, this);
  }
  setupFromArray(e) {
    let t;
    for (t of kr) this[t] = We[t];
    for (t of Tr) this[t] = We[t];
    for (t of Fr) this[t] = We[t];
    for (t of Ar) this[t] = new Ai(t, !1, void 0, this);
    this.setupGlobalFilters(e, void 0, Ae);
  }
  setupFromObject(e) {
    let t;
    for (t of (Ae.ifd0 = Ae.ifd0 || Ae.image, Ae.ifd1 = Ae.ifd1 || Ae.thumbnail, Object.assign(this, e), kr)) this[t] = hs(e[t], We[t]);
    for (t of Tr) this[t] = hs(e[t], We[t]);
    for (t of Fr) this[t] = hs(e[t], We[t]);
    for (t of js) this[t] = new Ai(t, We[t], e[t], this);
    for (t of Ae) this[t] = new Ai(t, We[t], e[t], this.tiff);
    this.setupGlobalFilters(e.pick, e.skip, Ae, Ar), e.tiff === !0 ? this.batchEnableWithBool(Ae, !0) : e.tiff === !1 ? this.batchEnableWithUserValue(Ae, e) : Array.isArray(e.tiff) ? this.setupGlobalFilters(e.tiff, void 0, Ae) : typeof e.tiff == "object" && this.setupGlobalFilters(e.tiff.pick, e.tiff.skip, Ae);
  }
  batchEnableWithBool(e, t) {
    for (let i of e) this[i].enabled = t;
  }
  batchEnableWithUserValue(e, t) {
    for (let i of e) {
      let r = t[i];
      this[i].enabled = r !== !1 && r !== void 0;
    }
  }
  setupGlobalFilters(e, t, i, r = i) {
    if (e && e.length) {
      for (let s of r) this[s].enabled = !1;
      let a = ou(e, i);
      for (let [s, o] of a) ra(this[s].pick, o), this[s].enabled = !0;
    } else if (t && t.length) {
      let a = ou(t, i);
      for (let [s, o] of a) ra(this[s].skip, o);
    }
  }
  filterNestedSegmentTags() {
    let { ifd0: e, exif: t, xmp: i, iptc: r, icc: a } = this;
    this.makerNote ? t.deps.add(37500) : t.skip.add(37500), this.userComment ? t.deps.add(37510) : t.skip.add(37510), i.enabled || e.skip.add(700), r.enabled || e.skip.add(33723), a.enabled || e.skip.add(34675);
  }
  traverseTiffDependencyTree() {
    let { ifd0: e, exif: t, gps: i, interop: r } = this;
    r.needed && (t.deps.add(40965), e.deps.add(40965)), t.needed && e.deps.add(34665), i.needed && e.deps.add(34853), this.tiff.enabled = Ae.some((a) => this[a].enabled === !0) || this.makerNote || this.userComment;
    for (let a of Ae) this[a].finalizeFilters();
  }
  get onlyTiff() {
    return !xf.map((e) => this[e].enabled).some((e) => e === !0) && this.tiff.enabled;
  }
  checkLoadedPlugins() {
    for (let e of js) this[e].enabled && !Me.has(e) && Us("segment parser", e);
  }
}
function ou(n, e) {
  let t, i, r, a, s = [];
  for (r of e) {
    for (a of (t = tt.get(r), i = [], t)) (n.includes(a[0]) || n.includes(a[1])) && i.push(a[0]);
    i.length && s.push([r, i]);
  }
  return s;
}
function hs(n, e) {
  return n !== void 0 ? n : e !== void 0 ? e : void 0;
}
function ra(n, e) {
  for (let t of e) n.add(t);
}
U($o, "default", We);
class Sg {
  constructor(e) {
    U(this, "parsers", {}), U(this, "output", {}), U(this, "errors", []), U(this, "pushToErrors", (t) => this.errors.push(t)), this.options = $o.useCached(e);
  }
  async read(e) {
    this.file = await Eg(e, this.options);
  }
  setup() {
    if (this.fileParser) return;
    let { file: e } = this, t = e.getUint16(0);
    for (let [i, r] of li) if (r.canHandle(e, t)) return this.fileParser = new r(this.options, this.file, this.parsers), e[i] = !0;
    this.file.close && this.file.close(), De("Unknown file format");
  }
  async parse() {
    let { output: e, errors: t } = this;
    return this.setup(), this.options.silentErrors ? (await this.executeParsers().catch(this.pushToErrors), t.push(...this.fileParser.errors)) : await this.executeParsers(), this.file.close && this.file.close(), this.options.silentErrors && t.length > 0 && (e.errors = t), ia(e);
  }
  async executeParsers() {
    let { output: e } = this;
    await this.fileParser.parse();
    let t = Object.values(this.parsers).map(async (i) => {
      let r = await i.parse();
      i.assignToOutput(e, r);
    });
    this.options.silentErrors && (t = t.map((i) => i.catch(this.pushToErrors))), await Promise.all(t);
  }
  async extractThumbnail() {
    this.setup();
    let { options: e, file: t } = this, i = Me.get("tiff", e);
    var r;
    if (t.tiff ? r = { start: 0, type: "tiff" } : t.jpeg && (r = await this.fileParser.getOrFindSegment("tiff")), r === void 0) return;
    let a = await this.fileParser.ensureSegmentChunk(r), s = this.parsers.tiff = new i(a, e, t), o = await s.extractThumbnail();
    return t.close && t.close(), o;
  }
}
async function kg(n, e) {
  let t = new Sg(e);
  return await t.read(n), t.parse();
}
class Ea {
  constructor(e, t, i) {
    U(this, "errors", []), U(this, "ensureSegmentChunk", async (r) => {
      let a = r.start, s = r.size || 65536;
      if (this.file.chunked) if (this.file.available(a, s)) r.chunk = this.file.subarray(a, s);
      else try {
        r.chunk = await this.file.readChunk(a, s);
      } catch (o) {
        De(`Couldn't read segment: ${JSON.stringify(r)}. ${o.message}`);
      }
      else this.file.byteLength > a + s ? r.chunk = this.file.subarray(a, s) : r.size === void 0 ? r.chunk = this.file.subarray(a) : De("Segment unreachable: " + JSON.stringify(r));
      return r.chunk;
    }), this.extendOptions && this.extendOptions(e), this.options = e, this.file = t, this.parsers = i;
  }
  injectSegment(e, t) {
    this.options[e].enabled && this.createParser(e, t);
  }
  createParser(e, t) {
    let i = new (Me.get(e))(t, this.options, this.file);
    return this.parsers[e] = i;
  }
  createParsers(e) {
    for (let t of e) {
      let { type: i, chunk: r } = t, a = this.options[i];
      if (a && a.enabled) {
        let s = this.parsers[i];
        s && s.append || s || this.createParser(i, r);
      }
    }
  }
  async readSegments(e) {
    let t = e.map(this.ensureSegmentChunk);
    await Promise.all(t);
  }
}
let St = class {
  static findPosition(e, t) {
    let i = e.getUint16(t + 2) + 2, r = typeof this.headerLength == "function" ? this.headerLength(e, t, i) : this.headerLength, a = t + r, s = i - r;
    return { offset: t, length: i, headerLength: r, start: a, size: s, end: a + s };
  }
  static parse(e, t = {}) {
    return new this(e, new $o({ [this.type]: t }), e).parse();
  }
  normalizeInput(e) {
    return e instanceof Qe ? e : new Qe(e);
  }
  constructor(e, t = {}, i) {
    U(this, "errors", []), U(this, "raw", /* @__PURE__ */ new Map()), U(this, "handleError", (r) => {
      if (!this.options.silentErrors) throw r;
      this.errors.push(r.message);
    }), this.chunk = this.normalizeInput(e), this.file = i, this.type = this.constructor.type, this.globalOptions = this.options = t, this.localOptions = t[this.type], this.canTranslate = this.localOptions && this.localOptions.translate;
  }
  translate() {
    this.canTranslate && (this.translated = this.translateBlock(this.raw, this.type));
  }
  get output() {
    return this.translated ? this.translated : this.raw ? Object.fromEntries(this.raw) : void 0;
  }
  translateBlock(e, t) {
    let i = Hr.get(t), r = Hn.get(t), a = tt.get(t), s = this.options[t], o = s.reviveValues && !!i, l = s.translateValues && !!r, c = s.translateKeys && !!a, u = {};
    for (let [f, h] of e) o && i.has(f) ? h = i.get(f)(h) : l && r.has(f) && (h = this.translateValue(h, r.get(f))), c && a.has(f) && (f = a.get(f) || f), u[f] = h;
    return u;
  }
  translateValue(e, t) {
    return t[e] || t.DEFAULT || e;
  }
  assignToOutput(e, t) {
    this.assignObjectToOutput(e, this.constructor.type, t);
  }
  assignObjectToOutput(e, t, i) {
    if (this.globalOptions.mergeOutput) return Object.assign(e, i);
    e[t] ? Object.assign(e[t], i) : e[t] = i;
  }
};
U(St, "headerLength", 4), U(St, "type", void 0), U(St, "multiSegment", !1), U(St, "canHandle", () => !1);
function Ag(n) {
  return n === 192 || n === 194 || n === 196 || n === 219 || n === 221 || n === 218 || n === 254;
}
function Fg(n) {
  return n >= 224 && n <= 239;
}
function Tg(n, e, t) {
  for (let [i, r] of Me) if (r.canHandle(n, e, t)) return i;
}
class lu extends Ea {
  constructor(...e) {
    super(...e), U(this, "appSegments", []), U(this, "jpegSegments", []), U(this, "unknownSegments", []);
  }
  static canHandle(e, t) {
    return t === 65496;
  }
  async parse() {
    await this.findAppSegments(), await this.readSegments(this.appSegments), this.mergeMultiSegments(), this.createParsers(this.mergedAppSegments || this.appSegments);
  }
  setupSegmentFinderArgs(e) {
    e === !0 ? (this.findAll = !0, this.wanted = new Set(Me.keyList())) : (e = e === void 0 ? Me.keyList().filter((t) => this.options[t].enabled) : e.filter((t) => this.options[t].enabled && Me.has(t)), this.findAll = !1, this.remaining = new Set(e), this.wanted = new Set(e)), this.unfinishedMultiSegment = !1;
  }
  async findAppSegments(e = 0, t) {
    this.setupSegmentFinderArgs(t);
    let { file: i, findAll: r, wanted: a, remaining: s } = this;
    if (!r && this.file.chunked && (r = Array.from(a).some((o) => {
      let l = Me.get(o), c = this.options[o];
      return l.multiSegment && c.multiSegment;
    }), r && await this.file.readWhole()), e = this.findAppSegmentsInRange(e, i.byteLength), !this.options.onlyTiff && i.chunked) {
      let o = !1;
      for (; s.size > 0 && !o && (i.canReadNextChunk || this.unfinishedMultiSegment); ) {
        let { nextChunkOffset: l } = i, c = this.appSegments.some((u) => !this.file.available(u.offset || u.start, u.length || u.size));
        if (o = e > l && !c ? !await i.readNextChunk(e) : !await i.readNextChunk(l), (e = this.findAppSegmentsInRange(e, i.byteLength)) === void 0) return;
      }
    }
  }
  findAppSegmentsInRange(e, t) {
    t -= 2;
    let i, r, a, s, o, l, { file: c, findAll: u, wanted: f, remaining: h, options: d } = this;
    for (; e < t; e++) if (c.getUint8(e) === 255) {
      if (i = c.getUint8(e + 1), Fg(i)) {
        if (r = c.getUint16(e + 2), a = Tg(c, e, r), a && f.has(a) && (s = Me.get(a), o = s.findPosition(c, e), l = d[a], o.type = a, this.appSegments.push(o), !u && (s.multiSegment && l.multiSegment ? (this.unfinishedMultiSegment = o.chunkNumber < o.chunkCount, this.unfinishedMultiSegment || h.delete(a)) : h.delete(a), h.size === 0))) break;
        d.recordUnknownSegments && (o = St.findPosition(c, e), o.marker = i, this.unknownSegments.push(o)), e += r + 1;
      } else if (Ag(i)) {
        if (r = c.getUint16(e + 2), i === 218 && d.stopAfterSos !== !1) return;
        d.recordJpegSegments && this.jpegSegments.push({ offset: e, length: r, marker: i }), e += r + 1;
      }
    }
    return e;
  }
  mergeMultiSegments() {
    if (!this.appSegments.some((t) => t.multiSegment)) return;
    let e = function(t, i) {
      let r, a, s, o = /* @__PURE__ */ new Map();
      for (let l = 0; l < t.length; l++) r = t[l], a = r[i], o.has(a) ? s = o.get(a) : o.set(a, s = []), s.push(r);
      return Array.from(o);
    }(this.appSegments, "type");
    this.mergedAppSegments = e.map(([t, i]) => {
      let r = Me.get(t, this.options);
      return r.handleMultiSegments ? { type: t, chunk: r.handleMultiSegments(i) } : i[0];
    });
  }
  getSegment(e) {
    return this.appSegments.find((t) => t.type === e);
  }
  async getOrFindSegment(e) {
    let t = this.getSegment(e);
    return t === void 0 && (await this.findAppSegments(0, [e]), t = this.getSegment(e)), t;
  }
}
U(lu, "type", "jpeg"), li.set("jpeg", lu);
const Ig = [void 0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8, 4];
class $g extends St {
  parseHeader() {
    var e = this.chunk.getUint16();
    e === 18761 ? this.le = !0 : e === 19789 && (this.le = !1), this.chunk.le = this.le, this.headerParsed = !0;
  }
  parseTags(e, t, i = /* @__PURE__ */ new Map()) {
    let { pick: r, skip: a } = this.options[t];
    r = new Set(r);
    let s = r.size > 0, o = a.size === 0, l = this.chunk.getUint16(e);
    e += 2;
    for (let c = 0; c < l; c++) {
      let u = this.chunk.getUint16(e);
      if (s) {
        if (r.has(u) && (i.set(u, this.parseTag(e, u, t)), r.delete(u), r.size === 0)) break;
      } else !o && a.has(u) || i.set(u, this.parseTag(e, u, t));
      e += 12;
    }
    return i;
  }
  parseTag(e, t, i) {
    let { chunk: r } = this, a = r.getUint16(e + 2), s = r.getUint32(e + 4), o = Ig[a];
    if (o * s <= 4 ? e += 8 : e = r.getUint32(e + 8), (a < 1 || a > 13) && De(`Invalid TIFF value type. block: ${i.toUpperCase()}, tag: ${t.toString(16)}, type: ${a}, offset ${e}`), e > r.byteLength && De(`Invalid TIFF value offset. block: ${i.toUpperCase()}, tag: ${t.toString(16)}, type: ${a}, offset ${e} is outside of chunk size ${r.byteLength}`), a === 1) return r.getUint8Array(e, s);
    if (a === 2) return Dn(r.getString(e, s));
    if (a === 7) return r.getUint8Array(e, s);
    if (s === 1) return this.parseTagValue(a, e);
    {
      let l = new (function(u) {
        switch (u) {
          case 1:
            return Uint8Array;
          case 3:
            return Uint16Array;
          case 4:
            return Uint32Array;
          case 5:
            return Array;
          case 6:
            return Int8Array;
          case 8:
            return Int16Array;
          case 9:
            return Int32Array;
          case 10:
            return Array;
          case 11:
            return Float32Array;
          case 12:
            return Float64Array;
          default:
            return Array;
        }
      }(a))(s), c = o;
      for (let u = 0; u < s; u++) l[u] = this.parseTagValue(a, e), e += c;
      return l;
    }
  }
  parseTagValue(e, t) {
    let { chunk: i } = this;
    switch (e) {
      case 1:
        return i.getUint8(t);
      case 3:
        return i.getUint16(t);
      case 4:
        return i.getUint32(t);
      case 5:
        return i.getUint32(t) / i.getUint32(t + 4);
      case 6:
        return i.getInt8(t);
      case 8:
        return i.getInt16(t);
      case 9:
        return i.getInt32(t);
      case 10:
        return i.getInt32(t) / i.getInt32(t + 4);
      case 11:
        return i.getFloat(t);
      case 12:
        return i.getDouble(t);
      case 13:
        return i.getUint32(t);
      default:
        De(`Invalid tiff type ${e}`);
    }
  }
}
class ds extends $g {
  static canHandle(e, t) {
    return e.getUint8(t + 1) === 225 && e.getUint32(t + 4) === 1165519206 && e.getUint16(t + 8) === 0;
  }
  async parse() {
    this.parseHeader();
    let { options: e } = this;
    return e.ifd0.enabled && await this.parseIfd0Block(), e.exif.enabled && await this.safeParse("parseExifBlock"), e.gps.enabled && await this.safeParse("parseGpsBlock"), e.interop.enabled && await this.safeParse("parseInteropBlock"), e.ifd1.enabled && await this.safeParse("parseThumbnailBlock"), this.createOutput();
  }
  safeParse(e) {
    let t = this[e]();
    return t.catch !== void 0 && (t = t.catch(this.handleError)), t;
  }
  findIfd0Offset() {
    this.ifd0Offset === void 0 && (this.ifd0Offset = this.chunk.getUint32(4));
  }
  findIfd1Offset() {
    if (this.ifd1Offset === void 0) {
      this.findIfd0Offset();
      let e = this.chunk.getUint16(this.ifd0Offset), t = this.ifd0Offset + 2 + 12 * e;
      this.ifd1Offset = this.chunk.getUint32(t);
    }
  }
  parseBlock(e, t) {
    let i = /* @__PURE__ */ new Map();
    return this[t] = i, this.parseTags(e, t, i), i;
  }
  async parseIfd0Block() {
    if (this.ifd0) return;
    let { file: e } = this;
    this.findIfd0Offset(), this.ifd0Offset < 8 && De("Malformed EXIF data"), !e.chunked && this.ifd0Offset > e.byteLength && De(`IFD0 offset points to outside of file.
this.ifd0Offset: ${this.ifd0Offset}, file.byteLength: ${e.byteLength}`), e.tiff && await e.ensureChunk(this.ifd0Offset, Ms(this.options));
    let t = this.parseBlock(this.ifd0Offset, "ifd0");
    return t.size !== 0 ? (this.exifOffset = t.get(34665), this.interopOffset = t.get(40965), this.gpsOffset = t.get(34853), this.xmp = t.get(700), this.iptc = t.get(33723), this.icc = t.get(34675), this.options.sanitize && (t.delete(34665), t.delete(40965), t.delete(34853), t.delete(700), t.delete(33723), t.delete(34675)), t) : void 0;
  }
  async parseExifBlock() {
    if (this.exif || (this.ifd0 || await this.parseIfd0Block(), this.exifOffset === void 0)) return;
    this.file.tiff && await this.file.ensureChunk(this.exifOffset, Ms(this.options));
    let e = this.parseBlock(this.exifOffset, "exif");
    return this.interopOffset || (this.interopOffset = e.get(40965)), this.makerNote = e.get(37500), this.userComment = e.get(37510), this.options.sanitize && (e.delete(40965), e.delete(37500), e.delete(37510)), this.unpack(e, 41728), this.unpack(e, 41729), e;
  }
  unpack(e, t) {
    let i = e.get(t);
    i && i.length === 1 && e.set(t, i[0]);
  }
  async parseGpsBlock() {
    if (this.gps || (this.ifd0 || await this.parseIfd0Block(), this.gpsOffset === void 0)) return;
    let e = this.parseBlock(this.gpsOffset, "gps");
    return e && e.has(2) && e.has(4) && (e.set("latitude", uu(...e.get(2), e.get(1))), e.set("longitude", uu(...e.get(4), e.get(3)))), e;
  }
  async parseInteropBlock() {
    if (!this.interop && (this.ifd0 || await this.parseIfd0Block(), this.interopOffset !== void 0 || this.exif || await this.parseExifBlock(), this.interopOffset !== void 0)) return this.parseBlock(this.interopOffset, "interop");
  }
  async parseThumbnailBlock(e = !1) {
    if (!this.ifd1 && !this.ifd1Parsed && (!this.options.mergeOutput || e)) return this.findIfd1Offset(), this.ifd1Offset > 0 && (this.parseBlock(this.ifd1Offset, "ifd1"), this.ifd1Parsed = !0), this.ifd1;
  }
  async extractThumbnail() {
    if (this.headerParsed || this.parseHeader(), this.ifd1Parsed || await this.parseThumbnailBlock(!0), this.ifd1 === void 0) return;
    let e = this.ifd1.get(513), t = this.ifd1.get(514);
    return this.chunk.getUint8Array(e, t);
  }
  get image() {
    return this.ifd0;
  }
  get thumbnail() {
    return this.ifd1;
  }
  createOutput() {
    let e, t, i, r = {};
    for (t of Ae) if (e = this[t], !$f(e)) if (i = this.canTranslate ? this.translateBlock(e, t) : Object.fromEntries(e), this.options.mergeOutput) {
      if (t === "ifd1") continue;
      Object.assign(r, i);
    } else r[t] = i;
    return this.makerNote && (r.makerNote = this.makerNote), this.userComment && (r.userComment = this.userComment), r;
  }
  assignToOutput(e, t) {
    if (this.globalOptions.mergeOutput) Object.assign(e, t);
    else for (let [i, r] of Object.entries(t)) this.assignObjectToOutput(e, i, r);
  }
}
function uu(n, e, t, i) {
  var r = n + e / 60 + t / 3600;
  return i !== "S" && i !== "W" || (r *= -1), r;
}
U(ds, "type", "tiff"), U(ds, "headerLength", 10), Me.set("tiff", ds);
const Po = { ifd0: !1, ifd1: !1, exif: !1, gps: !1, interop: !1, sanitize: !1, reviveValues: !0, translateKeys: !1, translateValues: !1, mergeOutput: !1 };
Object.assign({}, Po, { firstChunkSize: 4e4, gps: [1, 2, 3, 4] });
Object.assign({}, Po, { tiff: !1, ifd1: !0, mergeOutput: !1 });
Object.assign({}, Po, { firstChunkSize: 4e4, ifd0: [274] });
if (typeof navigator == "object") {
  let n = navigator.userAgent;
  if (n.includes("iPad") || n.includes("iPhone")) {
    let e = n.match(/OS (\d+)_(\d+)/);
    if (e) {
      let [, t, i] = e;
    }
  } else if (n.includes("OS X 10")) {
    let [, e] = n.match(/OS X 10[_.](\d+)/);
  }
  if (n.includes("Chrome/")) {
    let [, e] = n.match(/Chrome\/(\d+)/);
  } else if (n.includes("Firefox/")) {
    let [, e] = n.match(/Firefox\/(\d+)/);
  }
}
class Pg extends Qe {
  constructor(...e) {
    super(...e), U(this, "ranges", new xg()), this.byteLength !== 0 && this.ranges.add(0, this.byteLength);
  }
  _tryExtend(e, t, i) {
    if (e === 0 && this.byteLength === 0 && i) {
      let r = new DataView(i.buffer || i, i.byteOffset, i.byteLength);
      this._swapDataView(r);
    } else {
      let r = e + t;
      if (r > this.byteLength) {
        let { dataView: a } = this._extend(r);
        this._swapDataView(a);
      }
    }
  }
  _extend(e) {
    let t;
    t = Fo ? Ao.allocUnsafe(e) : new Uint8Array(e);
    let i = new DataView(t.buffer, t.byteOffset, t.byteLength);
    return t.set(new Uint8Array(this.buffer, this.byteOffset, this.byteLength), 0), { uintView: t, dataView: i };
  }
  subarray(e, t, i = !1) {
    return t = t || this._lengthToEnd(e), i && this._tryExtend(e, t), this.ranges.add(e, t), super.subarray(e, t);
  }
  set(e, t, i = !1) {
    i && this._tryExtend(t, e.byteLength, e);
    let r = super.set(e, t);
    return this.ranges.add(t, r.byteLength), r;
  }
  async ensureChunk(e, t) {
    this.chunked && (this.ranges.available(e, t) || await this.readChunk(e, t));
  }
  available(e, t) {
    return this.ranges.available(e, t);
  }
}
class xg {
  constructor() {
    U(this, "list", []);
  }
  get length() {
    return this.list.length;
  }
  add(e, t, i = 0) {
    let r = e + t, a = this.list.filter((s) => cu(e, s.offset, r) || cu(e, s.end, r));
    if (a.length > 0) {
      e = Math.min(e, ...a.map((o) => o.offset)), r = Math.max(r, ...a.map((o) => o.end)), t = r - e;
      let s = a.shift();
      s.offset = e, s.length = t, s.end = r, this.list = this.list.filter((o) => !a.includes(o));
    } else this.list.push({ offset: e, length: t, end: r });
  }
  available(e, t) {
    let i = e + t;
    return this.list.some((r) => r.offset <= e && i <= r.end);
  }
}
function cu(n, e, t) {
  return n <= e && e <= t;
}
class Ca extends Pg {
  constructor(e, t) {
    super(0), U(this, "chunksRead", 0), this.input = e, this.options = t;
  }
  async readWhole() {
    this.chunked = !1, await this.readChunk(this.nextChunkOffset);
  }
  async readChunked() {
    this.chunked = !0, await this.readChunk(0, this.options.firstChunkSize);
  }
  async readNextChunk(e = this.nextChunkOffset) {
    if (this.fullyRead) return this.chunksRead++, !1;
    let t = this.options.chunkSize, i = await this.readChunk(e, t);
    return !!i && i.byteLength === t;
  }
  async readChunk(e, t) {
    if (this.chunksRead++, (t = this.safeWrapAddress(e, t)) !== 0) return this._readChunk(e, t);
  }
  safeWrapAddress(e, t) {
    return this.size !== void 0 && e + t > this.size ? Math.max(0, this.size - e) : t;
  }
  get nextChunkOffset() {
    if (this.ranges.list.length !== 0) return this.ranges.list[0].length;
  }
  get canReadNextChunk() {
    return this.chunksRead < this.options.chunkLimit;
  }
  get fullyRead() {
    return this.size !== void 0 && this.nextChunkOffset === this.size;
  }
  read() {
    return this.options.chunked ? this.readChunked() : this.readWhole();
  }
  close() {
  }
}
mi.set("blob", class extends Ca {
  async readWhole() {
    this.chunked = !1;
    let n = await qs(this.input);
    this._swapArrayBuffer(n);
  }
  readChunked() {
    return this.chunked = !0, this.size = this.input.size, super.readChunked();
  }
  async _readChunk(n, e) {
    let t = e ? n + e : void 0, i = this.input.slice(n, t), r = await qs(i);
    return this.set(r, n, !0);
  }
});
mi.set("url", class extends Ca {
  async readWhole() {
    this.chunked = !1;
    let n = await zs(this.input);
    n instanceof ArrayBuffer ? this._swapArrayBuffer(n) : n instanceof Uint8Array && this._swapBuffer(n);
  }
  async _readChunk(n, e) {
    let t = e ? n + e - 1 : void 0, i = this.options.httpHeaders || {};
    (n || t) && (i.range = `bytes=${[n, t].join("-")}`);
    let r = await To(this.input, { headers: i }), a = await r.arrayBuffer(), s = a.byteLength;
    if (r.status !== 416) return s !== e && (this.size = n + s), this.set(a, n, !0);
  }
});
Qe.prototype.getUint64 = function(n) {
  let e = this.getUint32(n), t = this.getUint32(n + 4);
  return e < 1048575 ? e << 32 | t : typeof Sr !== void 0 ? (console.warn("Using BigInt because of type 64uint but JS can only handle 53b numbers."), Sr(e) << Sr(32) | Sr(t)) : void De("Trying to read 64b value but JS can only handle 53b numbers.");
};
class Bg extends Ea {
  parseBoxes(e = 0) {
    let t = [];
    for (; e < this.file.byteLength - 4; ) {
      let i = this.parseBoxHead(e);
      if (t.push(i), i.length === 0) break;
      e += i.length;
    }
    return t;
  }
  parseSubBoxes(e) {
    e.boxes = this.parseBoxes(e.start);
  }
  findBox(e, t) {
    return e.boxes === void 0 && this.parseSubBoxes(e), e.boxes.find((i) => i.kind === t);
  }
  parseBoxHead(e) {
    let t = this.file.getUint32(e), i = this.file.getString(e + 4, 4), r = e + 8;
    return t === 1 && (t = this.file.getUint64(e + 8), r += 8), { offset: e, length: t, kind: i, start: r };
  }
  parseBoxFullHead(e) {
    if (e.version !== void 0) return;
    let t = this.file.getUint32(e.start);
    e.version = t >> 24, e.start += 4;
  }
}
class Rf extends Bg {
  static canHandle(e, t) {
    if (t !== 0) return !1;
    let i = e.getUint16(2);
    if (i > 50) return !1;
    let r = 16, a = [];
    for (; r < i; ) a.push(e.getString(r, 4)), r += 4;
    return a.includes(this.type);
  }
  async parse() {
    let e = this.file.getUint32(0), t = this.parseBoxHead(e);
    for (; t.kind !== "meta"; ) e += t.length, await this.file.ensureChunk(e, 16), t = this.parseBoxHead(e);
    await this.file.ensureChunk(t.offset, t.length), this.parseBoxFullHead(t), this.parseSubBoxes(t), this.options.icc.enabled && await this.findIcc(t), this.options.tiff.enabled && await this.findExif(t);
  }
  async registerSegment(e, t, i) {
    await this.file.ensureChunk(t, i);
    let r = this.file.subarray(t, i);
    this.createParser(e, r);
  }
  async findIcc(e) {
    let t = this.findBox(e, "iprp");
    if (t === void 0) return;
    let i = this.findBox(t, "ipco");
    if (i === void 0) return;
    let r = this.findBox(i, "colr");
    r !== void 0 && await this.registerSegment("icc", r.offset + 12, r.length);
  }
  async findExif(e) {
    let t = this.findBox(e, "iinf");
    if (t === void 0) return;
    let i = this.findBox(e, "iloc");
    if (i === void 0) return;
    let r = this.findExifLocIdInIinf(t), a = this.findExtentInIloc(i, r);
    if (a === void 0) return;
    let [s, o] = a;
    await this.file.ensureChunk(s, o);
    let l = 4 + this.file.getUint32(s);
    s += l, o -= l, await this.registerSegment("tiff", s, o);
  }
  findExifLocIdInIinf(e) {
    this.parseBoxFullHead(e);
    let t, i, r, a, s = e.start, o = this.file.getUint16(s);
    for (s += 2; o--; ) {
      if (t = this.parseBoxHead(s), this.parseBoxFullHead(t), i = t.start, t.version >= 2 && (r = t.version === 3 ? 4 : 2, a = this.file.getString(i + r + 2, 4), a === "Exif")) return this.file.getUintBytes(i, r);
      s += t.length;
    }
  }
  get8bits(e) {
    let t = this.file.getUint8(e);
    return [t >> 4, 15 & t];
  }
  findExtentInIloc(e, t) {
    this.parseBoxFullHead(e);
    let i = e.start, [r, a] = this.get8bits(i++), [s, o] = this.get8bits(i++), l = e.version === 2 ? 4 : 2, c = e.version === 1 || e.version === 2 ? 2 : 0, u = o + r + a, f = e.version === 2 ? 4 : 2, h = this.file.getUintBytes(i, f);
    for (i += f; h--; ) {
      let d = this.file.getUintBytes(i, l);
      i += l + c + 2 + s;
      let p = this.file.getUint16(i);
      if (i += 2, d === t) return p > 1 && console.warn(`ILOC box has more than one extent but we're only processing one
Please create an issue at https://github.com/MikeKovarik/exifr with this file`), [this.file.getUintBytes(i + o, r), this.file.getUintBytes(i + o + r, a)];
      i += p * u;
    }
  }
}
class Lf extends Rf {
}
U(Lf, "type", "heic");
class fu extends Rf {
}
U(fu, "type", "avif"), li.set("heic", Lf), li.set("avif", fu), $e(tt, ["ifd0", "ifd1"], [[256, "ImageWidth"], [257, "ImageHeight"], [258, "BitsPerSample"], [259, "Compression"], [262, "PhotometricInterpretation"], [270, "ImageDescription"], [271, "Make"], [272, "Model"], [273, "StripOffsets"], [274, "Orientation"], [277, "SamplesPerPixel"], [278, "RowsPerStrip"], [279, "StripByteCounts"], [282, "XResolution"], [283, "YResolution"], [284, "PlanarConfiguration"], [296, "ResolutionUnit"], [301, "TransferFunction"], [305, "Software"], [306, "ModifyDate"], [315, "Artist"], [316, "HostComputer"], [317, "Predictor"], [318, "WhitePoint"], [319, "PrimaryChromaticities"], [513, "ThumbnailOffset"], [514, "ThumbnailLength"], [529, "YCbCrCoefficients"], [530, "YCbCrSubSampling"], [531, "YCbCrPositioning"], [532, "ReferenceBlackWhite"], [700, "ApplicationNotes"], [33432, "Copyright"], [33723, "IPTC"], [34665, "ExifIFD"], [34675, "ICC"], [34853, "GpsIFD"], [330, "SubIFD"], [40965, "InteropIFD"], [40091, "XPTitle"], [40092, "XPComment"], [40093, "XPAuthor"], [40094, "XPKeywords"], [40095, "XPSubject"]]), $e(tt, "exif", [[33434, "ExposureTime"], [33437, "FNumber"], [34850, "ExposureProgram"], [34852, "SpectralSensitivity"], [34855, "ISO"], [34858, "TimeZoneOffset"], [34859, "SelfTimerMode"], [34864, "SensitivityType"], [34865, "StandardOutputSensitivity"], [34866, "RecommendedExposureIndex"], [34867, "ISOSpeed"], [34868, "ISOSpeedLatitudeyyy"], [34869, "ISOSpeedLatitudezzz"], [36864, "ExifVersion"], [36867, "DateTimeOriginal"], [36868, "CreateDate"], [36873, "GooglePlusUploadCode"], [36880, "OffsetTime"], [36881, "OffsetTimeOriginal"], [36882, "OffsetTimeDigitized"], [37121, "ComponentsConfiguration"], [37122, "CompressedBitsPerPixel"], [37377, "ShutterSpeedValue"], [37378, "ApertureValue"], [37379, "BrightnessValue"], [37380, "ExposureCompensation"], [37381, "MaxApertureValue"], [37382, "SubjectDistance"], [37383, "MeteringMode"], [37384, "LightSource"], [37385, "Flash"], [37386, "FocalLength"], [37393, "ImageNumber"], [37394, "SecurityClassification"], [37395, "ImageHistory"], [37396, "SubjectArea"], [37500, "MakerNote"], [37510, "UserComment"], [37520, "SubSecTime"], [37521, "SubSecTimeOriginal"], [37522, "SubSecTimeDigitized"], [37888, "AmbientTemperature"], [37889, "Humidity"], [37890, "Pressure"], [37891, "WaterDepth"], [37892, "Acceleration"], [37893, "CameraElevationAngle"], [40960, "FlashpixVersion"], [40961, "ColorSpace"], [40962, "ExifImageWidth"], [40963, "ExifImageHeight"], [40964, "RelatedSoundFile"], [41483, "FlashEnergy"], [41486, "FocalPlaneXResolution"], [41487, "FocalPlaneYResolution"], [41488, "FocalPlaneResolutionUnit"], [41492, "SubjectLocation"], [41493, "ExposureIndex"], [41495, "SensingMethod"], [41728, "FileSource"], [41729, "SceneType"], [41730, "CFAPattern"], [41985, "CustomRendered"], [41986, "ExposureMode"], [41987, "WhiteBalance"], [41988, "DigitalZoomRatio"], [41989, "FocalLengthIn35mmFormat"], [41990, "SceneCaptureType"], [41991, "GainControl"], [41992, "Contrast"], [41993, "Saturation"], [41994, "Sharpness"], [41996, "SubjectDistanceRange"], [42016, "ImageUniqueID"], [42032, "OwnerName"], [42033, "SerialNumber"], [42034, "LensInfo"], [42035, "LensMake"], [42036, "LensModel"], [42037, "LensSerialNumber"], [42080, "CompositeImage"], [42081, "CompositeImageCount"], [42082, "CompositeImageExposureTimes"], [42240, "Gamma"], [59932, "Padding"], [59933, "OffsetSchema"], [65e3, "OwnerName"], [65001, "SerialNumber"], [65002, "Lens"], [65100, "RawFile"], [65101, "Converter"], [65102, "WhiteBalance"], [65105, "Exposure"], [65106, "Shadows"], [65107, "Brightness"], [65108, "Contrast"], [65109, "Saturation"], [65110, "Sharpness"], [65111, "Smoothness"], [65112, "MoireFilter"], [40965, "InteropIFD"]]), $e(tt, "gps", [[0, "GPSVersionID"], [1, "GPSLatitudeRef"], [2, "GPSLatitude"], [3, "GPSLongitudeRef"], [4, "GPSLongitude"], [5, "GPSAltitudeRef"], [6, "GPSAltitude"], [7, "GPSTimeStamp"], [8, "GPSSatellites"], [9, "GPSStatus"], [10, "GPSMeasureMode"], [11, "GPSDOP"], [12, "GPSSpeedRef"], [13, "GPSSpeed"], [14, "GPSTrackRef"], [15, "GPSTrack"], [16, "GPSImgDirectionRef"], [17, "GPSImgDirection"], [18, "GPSMapDatum"], [19, "GPSDestLatitudeRef"], [20, "GPSDestLatitude"], [21, "GPSDestLongitudeRef"], [22, "GPSDestLongitude"], [23, "GPSDestBearingRef"], [24, "GPSDestBearing"], [25, "GPSDestDistanceRef"], [26, "GPSDestDistance"], [27, "GPSProcessingMethod"], [28, "GPSAreaInformation"], [29, "GPSDateStamp"], [30, "GPSDifferential"], [31, "GPSHPositioningError"]]), $e(Hn, ["ifd0", "ifd1"], [[274, { 1: "Horizontal (normal)", 2: "Mirror horizontal", 3: "Rotate 180", 4: "Mirror vertical", 5: "Mirror horizontal and rotate 270 CW", 6: "Rotate 90 CW", 7: "Mirror horizontal and rotate 90 CW", 8: "Rotate 270 CW" }], [296, { 1: "None", 2: "inches", 3: "cm" }]]);
let Gi = $e(Hn, "exif", [[34850, { 0: "Not defined", 1: "Manual", 2: "Normal program", 3: "Aperture priority", 4: "Shutter priority", 5: "Creative program", 6: "Action program", 7: "Portrait mode", 8: "Landscape mode" }], [37121, { 0: "-", 1: "Y", 2: "Cb", 3: "Cr", 4: "R", 5: "G", 6: "B" }], [37383, { 0: "Unknown", 1: "Average", 2: "CenterWeightedAverage", 3: "Spot", 4: "MultiSpot", 5: "Pattern", 6: "Partial", 255: "Other" }], [37384, { 0: "Unknown", 1: "Daylight", 2: "Fluorescent", 3: "Tungsten (incandescent light)", 4: "Flash", 9: "Fine weather", 10: "Cloudy weather", 11: "Shade", 12: "Daylight fluorescent (D 5700 - 7100K)", 13: "Day white fluorescent (N 4600 - 5400K)", 14: "Cool white fluorescent (W 3900 - 4500K)", 15: "White fluorescent (WW 3200 - 3700K)", 17: "Standard light A", 18: "Standard light B", 19: "Standard light C", 20: "D55", 21: "D65", 22: "D75", 23: "D50", 24: "ISO studio tungsten", 255: "Other" }], [37385, { 0: "Flash did not fire", 1: "Flash fired", 5: "Strobe return light not detected", 7: "Strobe return light detected", 9: "Flash fired, compulsory flash mode", 13: "Flash fired, compulsory flash mode, return light not detected", 15: "Flash fired, compulsory flash mode, return light detected", 16: "Flash did not fire, compulsory flash mode", 24: "Flash did not fire, auto mode", 25: "Flash fired, auto mode", 29: "Flash fired, auto mode, return light not detected", 31: "Flash fired, auto mode, return light detected", 32: "No flash function", 65: "Flash fired, red-eye reduction mode", 69: "Flash fired, red-eye reduction mode, return light not detected", 71: "Flash fired, red-eye reduction mode, return light detected", 73: "Flash fired, compulsory flash mode, red-eye reduction mode", 77: "Flash fired, compulsory flash mode, red-eye reduction mode, return light not detected", 79: "Flash fired, compulsory flash mode, red-eye reduction mode, return light detected", 89: "Flash fired, auto mode, red-eye reduction mode", 93: "Flash fired, auto mode, return light not detected, red-eye reduction mode", 95: "Flash fired, auto mode, return light detected, red-eye reduction mode" }], [41495, { 1: "Not defined", 2: "One-chip color area sensor", 3: "Two-chip color area sensor", 4: "Three-chip color area sensor", 5: "Color sequential area sensor", 7: "Trilinear sensor", 8: "Color sequential linear sensor" }], [41728, { 1: "Film Scanner", 2: "Reflection Print Scanner", 3: "Digital Camera" }], [41729, { 1: "Directly photographed" }], [41985, { 0: "Normal", 1: "Custom", 2: "HDR (no original saved)", 3: "HDR (original saved)", 4: "Original (for HDR)", 6: "Panorama", 7: "Portrait HDR", 8: "Portrait" }], [41986, { 0: "Auto", 1: "Manual", 2: "Auto bracket" }], [41987, { 0: "Auto", 1: "Manual" }], [41990, { 0: "Standard", 1: "Landscape", 2: "Portrait", 3: "Night", 4: "Other" }], [41991, { 0: "None", 1: "Low gain up", 2: "High gain up", 3: "Low gain down", 4: "High gain down" }], [41996, { 0: "Unknown", 1: "Macro", 2: "Close", 3: "Distant" }], [42080, { 0: "Unknown", 1: "Not a Composite Image", 2: "General Composite Image", 3: "Composite Image Captured While Shooting" }]]);
const hu = { 1: "No absolute unit of measurement", 2: "Inch", 3: "Centimeter" };
Gi.set(37392, hu), Gi.set(41488, hu);
const _s = { 0: "Normal", 1: "Low", 2: "High" };
function du(n) {
  return typeof n == "object" && n.length !== void 0 ? n[0] : n;
}
function _u(n) {
  let e = Array.from(n).slice(1);
  return e[1] > 15 && (e = e.map((t) => String.fromCharCode(t))), e[2] !== "0" && e[2] !== 0 || e.pop(), e.join(".");
}
function ps(n) {
  if (typeof n == "string") {
    var [e, t, i, r, a, s] = n.trim().split(/[-: ]/g).map(Number), o = new Date(e, t - 1, i);
    return Number.isNaN(r) || Number.isNaN(a) || Number.isNaN(s) || (o.setHours(r), o.setMinutes(a), o.setSeconds(s)), Number.isNaN(+o) ? n : o;
  }
}
function Fi(n) {
  if (typeof n == "string") return n;
  let e = [];
  if (n[1] === 0 && n[n.length - 1] === 0) for (let t = 0; t < n.length; t += 2) e.push(pu(n[t + 1], n[t]));
  else for (let t = 0; t < n.length; t += 2) e.push(pu(n[t], n[t + 1]));
  return Dn(String.fromCodePoint(...e));
}
function pu(n, e) {
  return n << 8 | e;
}
Gi.set(41992, _s), Gi.set(41993, _s), Gi.set(41994, _s), $e(Hr, ["ifd0", "ifd1"], [[50827, function(n) {
  return typeof n != "string" ? Pf(n) : n;
}], [306, ps], [40091, Fi], [40092, Fi], [40093, Fi], [40094, Fi], [40095, Fi]]), $e(Hr, "exif", [[40960, _u], [36864, _u], [36867, ps], [36868, ps], [40962, du], [40963, du]]), $e(Hr, "gps", [[0, (n) => Array.from(n).join(".")], [7, (n) => Array.from(n).join(":")]]);
class ms extends St {
  static canHandle(e, t) {
    return e.getUint8(t + 1) === 225 && e.getUint32(t + 4) === 1752462448 && e.getString(t + 4, 20) === "http://ns.adobe.com/";
  }
  static headerLength(e, t) {
    return e.getString(t + 4, 34) === "http://ns.adobe.com/xmp/extension/" ? 79 : 33;
  }
  static findPosition(e, t) {
    let i = super.findPosition(e, t);
    return i.multiSegment = i.extended = i.headerLength === 79, i.multiSegment ? (i.chunkCount = e.getUint8(t + 72), i.chunkNumber = e.getUint8(t + 76), e.getUint8(t + 77) !== 0 && i.chunkNumber++) : (i.chunkCount = 1 / 0, i.chunkNumber = -1), i;
  }
  static handleMultiSegments(e) {
    return e.map((t) => t.chunk.getString()).join("");
  }
  normalizeInput(e) {
    return typeof e == "string" ? e : Qe.from(e).getString();
  }
  parse(e = this.chunk) {
    if (!this.localOptions.parse) return e;
    e = function(a) {
      let s = {}, o = {};
      for (let l of Hf) s[l] = [], o[l] = 0;
      return a.replace(Mg, (l, c, u) => {
        if (c === "<") {
          let f = ++o[u];
          return s[u].push(f), `${l}#${f}`;
        }
        return `${l}#${s[u].pop()}`;
      });
    }(e);
    let t = si.findAll(e, "rdf", "Description");
    t.length === 0 && t.push(new si("rdf", "Description", void 0, e));
    let i, r = {};
    for (let a of t) for (let s of a.properties) i = Lg(s.ns, r), Mf(s, i);
    return function(a) {
      let s;
      for (let o in a) s = a[o] = ia(a[o]), s === void 0 && delete a[o];
      return ia(a);
    }(r);
  }
  assignToOutput(e, t) {
    if (this.localOptions.parse) for (let [i, r] of Object.entries(t)) switch (i) {
      case "tiff":
        this.assignObjectToOutput(e, "ifd0", r);
        break;
      case "exif":
        this.assignObjectToOutput(e, "exif", r);
        break;
      case "xmlns":
        break;
      default:
        this.assignObjectToOutput(e, i, r);
    }
    else e.xmp = t;
  }
}
U(ms, "type", "xmp"), U(ms, "multiSegment", !0), Me.set("xmp", ms);
class aa {
  static findAll(e) {
    return Nf(e, /([a-zA-Z0-9-]+):([a-zA-Z0-9-]+)=("[^"]*"|'[^']*')/gm).map(aa.unpackMatch);
  }
  static unpackMatch(e) {
    let t = e[1], i = e[2], r = e[3].slice(1, -1);
    return r = Uf(r), new aa(t, i, r);
  }
  constructor(e, t, i) {
    this.ns = e, this.name = t, this.value = i;
  }
  serialize() {
    return this.value;
  }
}
class si {
  static findAll(e, t, i) {
    if (t !== void 0 || i !== void 0) {
      t = t || "[\\w\\d-]+", i = i || "[\\w\\d-]+";
      var r = new RegExp(`<(${t}):(${i})(#\\d+)?((\\s+?[\\w\\d-:]+=("[^"]*"|'[^']*'))*\\s*)(\\/>|>([\\s\\S]*?)<\\/\\1:\\2\\3>)`, "gm");
    } else r = /<([\w\d-]+):([\w\d-]+)(#\d+)?((\s+?[\w\d-:]+=("[^"]*"|'[^']*'))*\s*)(\/>|>([\s\S]*?)<\/\1:\2\3>)/gm;
    return Nf(e, r).map(si.unpackMatch);
  }
  static unpackMatch(e) {
    let t = e[1], i = e[2], r = e[4], a = e[8];
    return new si(t, i, r, a);
  }
  constructor(e, t, i, r) {
    this.ns = e, this.name = t, this.attrString = i, this.innerXml = r, this.attrs = aa.findAll(i), this.children = si.findAll(r), this.value = this.children.length === 0 ? Uf(r) : void 0, this.properties = [...this.attrs, ...this.children];
  }
  get isPrimitive() {
    return this.value !== void 0 && this.attrs.length === 0 && this.children.length === 0;
  }
  get isListContainer() {
    return this.children.length === 1 && this.children[0].isList;
  }
  get isList() {
    let { ns: e, name: t } = this;
    return e === "rdf" && (t === "Seq" || t === "Bag" || t === "Alt");
  }
  get isListItem() {
    return this.ns === "rdf" && this.name === "li";
  }
  serialize() {
    if (this.properties.length === 0 && this.value === void 0) return;
    if (this.isPrimitive) return this.value;
    if (this.isListContainer) return this.children[0].serialize();
    if (this.isList) return Rg(this.children.map(Og));
    if (this.isListItem && this.children.length === 1 && this.attrs.length === 0) return this.children[0].serialize();
    let e = {};
    for (let t of this.properties) Mf(t, e);
    return this.value !== void 0 && (e.value = this.value), ia(e);
  }
}
function Mf(n, e) {
  let t = n.serialize();
  t !== void 0 && (e[n.name] = t);
}
var Og = (n) => n.serialize(), Rg = (n) => n.length === 1 ? n[0] : n, Lg = (n, e) => e[n] ? e[n] : e[n] = {};
function Nf(n, e) {
  let t, i = [];
  if (!n) return i;
  for (; (t = e.exec(n)) !== null; ) i.push(t);
  return i;
}
function Uf(n) {
  if (function(i) {
    return i == null || i === "null" || i === "undefined" || i === "" || i.trim() === "";
  }(n)) return;
  let e = Number(n);
  if (!Number.isNaN(e)) return e;
  let t = n.toLowerCase();
  return t === "true" || t !== "false" && n.trim();
}
const Hf = ["rdf:li", "rdf:Seq", "rdf:Bag", "rdf:Alt", "rdf:Description"], Mg = new RegExp(`(<|\\/)(${Hf.join("|")})`, "g");
let mu = na("fs", (n) => n.promises);
mi.set("fs", class extends Ca {
  async readWhole() {
    this.chunked = !1, this.fs = await mu;
    let n = await this.fs.readFile(this.input);
    this._swapBuffer(n);
  }
  async readChunked() {
    this.chunked = !0, this.fs = await mu, await this.open(), await this.readChunk(0, this.options.firstChunkSize);
  }
  async open() {
    this.fh === void 0 && (this.fh = await this.fs.open(this.input, "r"), this.size = (await this.fh.stat(this.input)).size);
  }
  async _readChunk(n, e) {
    this.fh === void 0 && await this.open(), n + e > this.size && (e = this.size - n);
    var t = this.subarray(n, e, !0);
    return await this.fh.read(t.dataView, 0, e, n), t;
  }
  async close() {
    if (this.fh) {
      let n = this.fh;
      this.fh = void 0, await n.close();
    }
  }
});
mi.set("base64", class extends Ca {
  constructor(...n) {
    super(...n), this.input = this.input.replace(/^data:([^;]+);base64,/gim, ""), this.size = this.input.length / 4 * 3, this.input.endsWith("==") ? this.size -= 2 : this.input.endsWith("=") && (this.size -= 1);
  }
  async _readChunk(n, e) {
    let t, i, r = this.input;
    n === void 0 ? (n = 0, t = 0, i = 0) : (t = 4 * Math.floor(n / 3), i = n - t / 4 * 3), e === void 0 && (e = this.size);
    let a = n + e, s = t + 4 * Math.ceil(a / 3);
    r = r.slice(t, s);
    let o = Math.min(e, this.size - n);
    if (Fo) {
      let l = Ao.from(r, "base64").slice(i, i + o);
      return this.set(l, n, !0);
    }
    {
      let l = this.subarray(n, o, !0), c = atob(r), u = l.toUint8();
      for (let f = 0; f < o; f++) u[f] = c.charCodeAt(i + f);
      return l;
    }
  }
});
let gu = class extends Ea {
  static canHandle(e, t) {
    return t === 18761 || t === 19789;
  }
  extendOptions(e) {
    let { ifd0: t, xmp: i, iptc: r, icc: a } = e;
    i.enabled && t.deps.add(700), r.enabled && t.deps.add(33723), a.enabled && t.deps.add(34675), t.finalizeFilters();
  }
  async parse() {
    let { tiff: e, xmp: t, iptc: i, icc: r } = this.options;
    if (e.enabled || t.enabled || i.enabled || r.enabled) {
      let a = Math.max(Ms(this.options), this.options.chunkSize);
      await this.file.ensureChunk(0, a), this.createParser("tiff", this.file), this.parsers.tiff.parseHeader(), await this.parsers.tiff.parseIfd0Block(), this.adaptTiffPropAsSegment("xmp"), this.adaptTiffPropAsSegment("iptc"), this.adaptTiffPropAsSegment("icc");
    }
  }
  adaptTiffPropAsSegment(e) {
    if (this.parsers.tiff[e]) {
      let t = this.parsers.tiff[e];
      this.injectSegment(e, t);
    }
  }
};
U(gu, "type", "tiff"), li.set("tiff", gu);
let Ng = na("zlib");
const Ug = ["ihdr", "iccp", "text", "itxt", "exif"];
class bu extends Ea {
  constructor(...e) {
    super(...e), U(this, "catchError", (t) => this.errors.push(t)), U(this, "metaChunks", []), U(this, "unknownChunks", []);
  }
  static canHandle(e, t) {
    return t === 35152 && e.getUint32(0) === 2303741511 && e.getUint32(4) === 218765834;
  }
  async parse() {
    let { file: e } = this;
    await this.findPngChunksInRange(8, e.byteLength), await this.readSegments(this.metaChunks), this.findIhdr(), this.parseTextChunks(), await this.findExif().catch(this.catchError), await this.findXmp().catch(this.catchError), await this.findIcc().catch(this.catchError);
  }
  async findPngChunksInRange(e, t) {
    let { file: i } = this;
    for (; e < t; ) {
      let r = i.getUint32(e), a = i.getUint32(e + 4), s = i.getString(e + 4, 4).toLowerCase(), o = r + 4 + 4 + 4, l = { type: s, offset: e, length: o, start: e + 4 + 4, size: r, marker: a };
      Ug.includes(s) ? this.metaChunks.push(l) : this.unknownChunks.push(l), e += o;
    }
  }
  parseTextChunks() {
    let e = this.metaChunks.filter((t) => t.type === "text");
    for (let t of e) {
      let [i, r] = this.file.getString(t.start, t.size).split("\0");
      this.injectKeyValToIhdr(i, r);
    }
  }
  injectKeyValToIhdr(e, t) {
    let i = this.parsers.ihdr;
    i && i.raw.set(e, t);
  }
  findIhdr() {
    let e = this.metaChunks.find((t) => t.type === "ihdr");
    e && this.options.ihdr.enabled !== !1 && this.createParser("ihdr", e.chunk);
  }
  async findExif() {
    let e = this.metaChunks.find((t) => t.type === "exif");
    e && this.injectSegment("tiff", e.chunk);
  }
  async findXmp() {
    let e = this.metaChunks.filter((t) => t.type === "itxt");
    for (let t of e)
      t.chunk.getString(0, 17) === "XML:com.adobe.xmp" && this.injectSegment("xmp", t.chunk);
  }
  async findIcc() {
    let e = this.metaChunks.find((o) => o.type === "iccp");
    if (!e) return;
    let { chunk: t } = e, i = t.getUint8Array(0, 81), r = 0;
    for (; r < 80 && i[r] !== 0; ) r++;
    let a = r + 2, s = t.getString(0, r);
    if (this.injectKeyValToIhdr("ProfileName", s), ta) {
      let o = await Ng, l = t.getUint8Array(a);
      l = o.inflateSync(l), this.injectSegment("icc", l);
    }
  }
}
U(bu, "type", "png"), li.set("png", bu), $e(tt, "interop", [[1, "InteropIndex"], [2, "InteropVersion"], [4096, "RelatedImageFileFormat"], [4097, "RelatedImageWidth"], [4098, "RelatedImageHeight"]]), Vs(tt, "ifd0", [[11, "ProcessingSoftware"], [254, "SubfileType"], [255, "OldSubfileType"], [263, "Thresholding"], [264, "CellWidth"], [265, "CellLength"], [266, "FillOrder"], [269, "DocumentName"], [280, "MinSampleValue"], [281, "MaxSampleValue"], [285, "PageName"], [286, "XPosition"], [287, "YPosition"], [290, "GrayResponseUnit"], [297, "PageNumber"], [321, "HalftoneHints"], [322, "TileWidth"], [323, "TileLength"], [332, "InkSet"], [337, "TargetPrinter"], [18246, "Rating"], [18249, "RatingPercent"], [33550, "PixelScale"], [34264, "ModelTransform"], [34377, "PhotoshopSettings"], [50706, "DNGVersion"], [50707, "DNGBackwardVersion"], [50708, "UniqueCameraModel"], [50709, "LocalizedCameraModel"], [50736, "DNGLensInfo"], [50739, "ShadowScale"], [50740, "DNGPrivateData"], [33920, "IntergraphMatrix"], [33922, "ModelTiePoint"], [34118, "SEMInfo"], [34735, "GeoTiffDirectory"], [34736, "GeoTiffDoubleParams"], [34737, "GeoTiffAsciiParams"], [50341, "PrintIM"], [50721, "ColorMatrix1"], [50722, "ColorMatrix2"], [50723, "CameraCalibration1"], [50724, "CameraCalibration2"], [50725, "ReductionMatrix1"], [50726, "ReductionMatrix2"], [50727, "AnalogBalance"], [50728, "AsShotNeutral"], [50729, "AsShotWhiteXY"], [50730, "BaselineExposure"], [50731, "BaselineNoise"], [50732, "BaselineSharpness"], [50734, "LinearResponseLimit"], [50735, "CameraSerialNumber"], [50741, "MakerNoteSafety"], [50778, "CalibrationIlluminant1"], [50779, "CalibrationIlluminant2"], [50781, "RawDataUniqueID"], [50827, "OriginalRawFileName"], [50828, "OriginalRawFileData"], [50831, "AsShotICCProfile"], [50832, "AsShotPreProfileMatrix"], [50833, "CurrentICCProfile"], [50834, "CurrentPreProfileMatrix"], [50879, "ColorimetricReference"], [50885, "SRawType"], [50898, "PanasonicTitle"], [50899, "PanasonicTitle2"], [50931, "CameraCalibrationSig"], [50932, "ProfileCalibrationSig"], [50933, "ProfileIFD"], [50934, "AsShotProfileName"], [50936, "ProfileName"], [50937, "ProfileHueSatMapDims"], [50938, "ProfileHueSatMapData1"], [50939, "ProfileHueSatMapData2"], [50940, "ProfileToneCurve"], [50941, "ProfileEmbedPolicy"], [50942, "ProfileCopyright"], [50964, "ForwardMatrix1"], [50965, "ForwardMatrix2"], [50966, "PreviewApplicationName"], [50967, "PreviewApplicationVersion"], [50968, "PreviewSettingsName"], [50969, "PreviewSettingsDigest"], [50970, "PreviewColorSpace"], [50971, "PreviewDateTime"], [50972, "RawImageDigest"], [50973, "OriginalRawFileDigest"], [50981, "ProfileLookTableDims"], [50982, "ProfileLookTableData"], [51043, "TimeCodes"], [51044, "FrameRate"], [51058, "TStop"], [51081, "ReelName"], [51089, "OriginalDefaultFinalSize"], [51090, "OriginalBestQualitySize"], [51091, "OriginalDefaultCropSize"], [51105, "CameraLabel"], [51107, "ProfileHueSatMapEncoding"], [51108, "ProfileLookTableEncoding"], [51109, "BaselineExposureOffset"], [51110, "DefaultBlackRender"], [51111, "NewRawImageDigest"], [51112, "RawToPreviewGain"]]);
let vu = [[273, "StripOffsets"], [279, "StripByteCounts"], [288, "FreeOffsets"], [289, "FreeByteCounts"], [291, "GrayResponseCurve"], [292, "T4Options"], [293, "T6Options"], [300, "ColorResponseUnit"], [320, "ColorMap"], [324, "TileOffsets"], [325, "TileByteCounts"], [326, "BadFaxLines"], [327, "CleanFaxData"], [328, "ConsecutiveBadFaxLines"], [330, "SubIFD"], [333, "InkNames"], [334, "NumberofInks"], [336, "DotRange"], [338, "ExtraSamples"], [339, "SampleFormat"], [340, "SMinSampleValue"], [341, "SMaxSampleValue"], [342, "TransferRange"], [343, "ClipPath"], [344, "XClipPathUnits"], [345, "YClipPathUnits"], [346, "Indexed"], [347, "JPEGTables"], [351, "OPIProxy"], [400, "GlobalParametersIFD"], [401, "ProfileType"], [402, "FaxProfile"], [403, "CodingMethods"], [404, "VersionYear"], [405, "ModeNumber"], [433, "Decode"], [434, "DefaultImageColor"], [435, "T82Options"], [437, "JPEGTables"], [512, "JPEGProc"], [515, "JPEGRestartInterval"], [517, "JPEGLosslessPredictors"], [518, "JPEGPointTransforms"], [519, "JPEGQTables"], [520, "JPEGDCTables"], [521, "JPEGACTables"], [559, "StripRowCounts"], [999, "USPTOMiscellaneous"], [18247, "XP_DIP_XML"], [18248, "StitchInfo"], [28672, "SonyRawFileType"], [28688, "SonyToneCurve"], [28721, "VignettingCorrection"], [28722, "VignettingCorrParams"], [28724, "ChromaticAberrationCorrection"], [28725, "ChromaticAberrationCorrParams"], [28726, "DistortionCorrection"], [28727, "DistortionCorrParams"], [29895, "SonyCropTopLeft"], [29896, "SonyCropSize"], [32781, "ImageID"], [32931, "WangTag1"], [32932, "WangAnnotation"], [32933, "WangTag3"], [32934, "WangTag4"], [32953, "ImageReferencePoints"], [32954, "RegionXformTackPoint"], [32955, "WarpQuadrilateral"], [32956, "AffineTransformMat"], [32995, "Matteing"], [32996, "DataType"], [32997, "ImageDepth"], [32998, "TileDepth"], [33300, "ImageFullWidth"], [33301, "ImageFullHeight"], [33302, "TextureFormat"], [33303, "WrapModes"], [33304, "FovCot"], [33305, "MatrixWorldToScreen"], [33306, "MatrixWorldToCamera"], [33405, "Model2"], [33421, "CFARepeatPatternDim"], [33422, "CFAPattern2"], [33423, "BatteryLevel"], [33424, "KodakIFD"], [33445, "MDFileTag"], [33446, "MDScalePixel"], [33447, "MDColorTable"], [33448, "MDLabName"], [33449, "MDSampleInfo"], [33450, "MDPrepDate"], [33451, "MDPrepTime"], [33452, "MDFileUnits"], [33589, "AdventScale"], [33590, "AdventRevision"], [33628, "UIC1Tag"], [33629, "UIC2Tag"], [33630, "UIC3Tag"], [33631, "UIC4Tag"], [33918, "IntergraphPacketData"], [33919, "IntergraphFlagRegisters"], [33921, "INGRReserved"], [34016, "Site"], [34017, "ColorSequence"], [34018, "IT8Header"], [34019, "RasterPadding"], [34020, "BitsPerRunLength"], [34021, "BitsPerExtendedRunLength"], [34022, "ColorTable"], [34023, "ImageColorIndicator"], [34024, "BackgroundColorIndicator"], [34025, "ImageColorValue"], [34026, "BackgroundColorValue"], [34027, "PixelIntensityRange"], [34028, "TransparencyIndicator"], [34029, "ColorCharacterization"], [34030, "HCUsage"], [34031, "TrapIndicator"], [34032, "CMYKEquivalent"], [34152, "AFCP_IPTC"], [34232, "PixelMagicJBIGOptions"], [34263, "JPLCartoIFD"], [34306, "WB_GRGBLevels"], [34310, "LeafData"], [34687, "TIFF_FXExtensions"], [34688, "MultiProfiles"], [34689, "SharedData"], [34690, "T88Options"], [34732, "ImageLayer"], [34750, "JBIGOptions"], [34856, "Opto-ElectricConvFactor"], [34857, "Interlace"], [34908, "FaxRecvParams"], [34909, "FaxSubAddress"], [34910, "FaxRecvTime"], [34929, "FedexEDR"], [34954, "LeafSubIFD"], [37387, "FlashEnergy"], [37388, "SpatialFrequencyResponse"], [37389, "Noise"], [37390, "FocalPlaneXResolution"], [37391, "FocalPlaneYResolution"], [37392, "FocalPlaneResolutionUnit"], [37397, "ExposureIndex"], [37398, "TIFF-EPStandardID"], [37399, "SensingMethod"], [37434, "CIP3DataFile"], [37435, "CIP3Sheet"], [37436, "CIP3Side"], [37439, "StoNits"], [37679, "MSDocumentText"], [37680, "MSPropertySetStorage"], [37681, "MSDocumentTextPosition"], [37724, "ImageSourceData"], [40965, "InteropIFD"], [40976, "SamsungRawPointersOffset"], [40977, "SamsungRawPointersLength"], [41217, "SamsungRawByteOrder"], [41218, "SamsungRawUnknown"], [41484, "SpatialFrequencyResponse"], [41485, "Noise"], [41489, "ImageNumber"], [41490, "SecurityClassification"], [41491, "ImageHistory"], [41494, "TIFF-EPStandardID"], [41995, "DeviceSettingDescription"], [42112, "GDALMetadata"], [42113, "GDALNoData"], [44992, "ExpandSoftware"], [44993, "ExpandLens"], [44994, "ExpandFilm"], [44995, "ExpandFilterLens"], [44996, "ExpandScanner"], [44997, "ExpandFlashLamp"], [46275, "HasselbladRawImage"], [48129, "PixelFormat"], [48130, "Transformation"], [48131, "Uncompressed"], [48132, "ImageType"], [48256, "ImageWidth"], [48257, "ImageHeight"], [48258, "WidthResolution"], [48259, "HeightResolution"], [48320, "ImageOffset"], [48321, "ImageByteCount"], [48322, "AlphaOffset"], [48323, "AlphaByteCount"], [48324, "ImageDataDiscard"], [48325, "AlphaDataDiscard"], [50215, "OceScanjobDesc"], [50216, "OceApplicationSelector"], [50217, "OceIDNumber"], [50218, "OceImageLogic"], [50255, "Annotations"], [50459, "HasselbladExif"], [50547, "OriginalFileName"], [50560, "USPTOOriginalContentType"], [50656, "CR2CFAPattern"], [50710, "CFAPlaneColor"], [50711, "CFALayout"], [50712, "LinearizationTable"], [50713, "BlackLevelRepeatDim"], [50714, "BlackLevel"], [50715, "BlackLevelDeltaH"], [50716, "BlackLevelDeltaV"], [50717, "WhiteLevel"], [50718, "DefaultScale"], [50719, "DefaultCropOrigin"], [50720, "DefaultCropSize"], [50733, "BayerGreenSplit"], [50737, "ChromaBlurRadius"], [50738, "AntiAliasStrength"], [50752, "RawImageSegmentation"], [50780, "BestQualityScale"], [50784, "AliasLayerMetadata"], [50829, "ActiveArea"], [50830, "MaskedAreas"], [50935, "NoiseReductionApplied"], [50974, "SubTileBlockSize"], [50975, "RowInterleaveFactor"], [51008, "OpcodeList1"], [51009, "OpcodeList2"], [51022, "OpcodeList3"], [51041, "NoiseProfile"], [51114, "CacheVersion"], [51125, "DefaultUserCrop"], [51157, "NikonNEFInfo"], [65024, "KdcIFD"]];
Vs(tt, "ifd0", vu), Vs(tt, "exif", vu), $e(Hn, "gps", [[23, { M: "Magnetic North", T: "True North" }], [25, { K: "Kilometers", M: "Miles", N: "Nautical Miles" }]]);
class gs extends St {
  static canHandle(e, t) {
    return e.getUint8(t + 1) === 224 && e.getUint32(t + 4) === 1246120262 && e.getUint8(t + 8) === 0;
  }
  parse() {
    return this.parseTags(), this.translate(), this.output;
  }
  parseTags() {
    this.raw = /* @__PURE__ */ new Map([[0, this.chunk.getUint16(0)], [2, this.chunk.getUint8(2)], [3, this.chunk.getUint16(3)], [5, this.chunk.getUint16(5)], [7, this.chunk.getUint8(7)], [8, this.chunk.getUint8(8)]]);
  }
}
U(gs, "type", "jfif"), U(gs, "headerLength", 9), Me.set("jfif", gs), $e(tt, "jfif", [[0, "JFIFVersion"], [2, "ResolutionUnit"], [3, "XResolution"], [5, "YResolution"], [7, "ThumbnailWidth"], [8, "ThumbnailHeight"]]);
class yu extends St {
  parse() {
    return this.parseTags(), this.translate(), this.output;
  }
  parseTags() {
    this.raw = new Map([[0, this.chunk.getUint32(0)], [4, this.chunk.getUint32(4)], [8, this.chunk.getUint8(8)], [9, this.chunk.getUint8(9)], [10, this.chunk.getUint8(10)], [11, this.chunk.getUint8(11)], [12, this.chunk.getUint8(12)], ...Array.from(this.raw)]);
  }
}
U(yu, "type", "ihdr"), Me.set("ihdr", yu), $e(tt, "ihdr", [[0, "ImageWidth"], [4, "ImageHeight"], [8, "BitDepth"], [9, "ColorType"], [10, "Compression"], [11, "Filter"], [12, "Interlace"]]), $e(Hn, "ihdr", [[9, { 0: "Grayscale", 2: "RGB", 3: "Palette", 4: "Grayscale with Alpha", 6: "RGB with Alpha", DEFAULT: "Unknown" }], [10, { 0: "Deflate/Inflate", DEFAULT: "Unknown" }], [11, { 0: "Adaptive", DEFAULT: "Unknown" }], [12, { 0: "Noninterlaced", 1: "Adam7 Interlace", DEFAULT: "Unknown" }]]);
class Gr extends St {
  static canHandle(e, t) {
    return e.getUint8(t + 1) === 226 && e.getUint32(t + 4) === 1229144927;
  }
  static findPosition(e, t) {
    let i = super.findPosition(e, t);
    return i.chunkNumber = e.getUint8(t + 16), i.chunkCount = e.getUint8(t + 17), i.multiSegment = i.chunkCount > 1, i;
  }
  static handleMultiSegments(e) {
    return function(t) {
      let i = function(r) {
        let a = r[0].constructor, s = 0;
        for (let c of r) s += c.length;
        let o = new a(s), l = 0;
        for (let c of r) o.set(c, l), l += c.length;
        return o;
      }(t.map((r) => r.chunk.toUint8()));
      return new Qe(i);
    }(e);
  }
  parse() {
    return this.raw = /* @__PURE__ */ new Map(), this.parseHeader(), this.parseTags(), this.translate(), this.output;
  }
  parseHeader() {
    let { raw: e } = this;
    this.chunk.byteLength < 84 && De("ICC header is too short");
    for (let [t, i] of Object.entries(Hg)) {
      t = parseInt(t, 10);
      let r = i(this.chunk, t);
      r !== "\0\0\0\0" && e.set(t, r);
    }
  }
  parseTags() {
    let e, t, i, r, a, { raw: s } = this, o = this.chunk.getUint32(128), l = 132, c = this.chunk.byteLength;
    for (; o--; ) {
      if (e = this.chunk.getString(l, 4), t = this.chunk.getUint32(l + 4), i = this.chunk.getUint32(l + 8), r = this.chunk.getString(t, 4), t + i > c) return void console.warn("reached the end of the first ICC chunk. Enable options.tiff.multiSegment to read all ICC segments.");
      a = this.parseTag(r, t, i), a !== void 0 && a !== "\0\0\0\0" && s.set(e, a), l += 12;
    }
  }
  parseTag(e, t, i) {
    switch (e) {
      case "desc":
        return this.parseDesc(t);
      case "mluc":
        return this.parseMluc(t);
      case "text":
        return this.parseText(t, i);
      case "sig ":
        return this.parseSig(t);
    }
    if (!(t + i > this.chunk.byteLength)) return this.chunk.getUint8Array(t, i);
  }
  parseDesc(e) {
    let t = this.chunk.getUint32(e + 8) - 1;
    return Dn(this.chunk.getString(e + 12, t));
  }
  parseText(e, t) {
    return Dn(this.chunk.getString(e + 8, t - 8));
  }
  parseSig(e) {
    return Dn(this.chunk.getString(e + 8, 4));
  }
  parseMluc(e) {
    let { chunk: t } = this, i = t.getUint32(e + 8), r = t.getUint32(e + 12), a = e + 16, s = [];
    for (let o = 0; o < i; o++) {
      let l = t.getString(a + 0, 2), c = t.getString(a + 2, 2), u = t.getUint32(a + 4), f = t.getUint32(a + 8) + e, h = Dn(t.getUnicodeString(f, u));
      s.push({ lang: l, country: c, text: h }), a += r;
    }
    return i === 1 ? s[0].text : s;
  }
  translateValue(e, t) {
    return typeof e == "string" ? t[e] || t[e.toLowerCase()] || e : t[e] || e;
  }
}
U(Gr, "type", "icc"), U(Gr, "multiSegment", !0), U(Gr, "headerLength", 18);
const Hg = { 4: Kt, 8: function(n, e) {
  return [n.getUint8(e), n.getUint8(e + 1) >> 4, n.getUint8(e + 1) % 16].map((t) => t.toString(10)).join(".");
}, 12: Kt, 16: Kt, 20: Kt, 24: function(n, e) {
  const t = n.getUint16(e), i = n.getUint16(e + 2) - 1, r = n.getUint16(e + 4), a = n.getUint16(e + 6), s = n.getUint16(e + 8), o = n.getUint16(e + 10);
  return new Date(Date.UTC(t, i, r, a, s, o));
}, 36: Kt, 40: Kt, 48: Kt, 52: Kt, 64: (n, e) => n.getUint32(e), 80: Kt };
function Kt(n, e) {
  return Dn(n.getString(e, 4));
}
Me.set("icc", Gr), $e(tt, "icc", [[4, "ProfileCMMType"], [8, "ProfileVersion"], [12, "ProfileClass"], [16, "ColorSpaceData"], [20, "ProfileConnectionSpace"], [24, "ProfileDateTime"], [36, "ProfileFileSignature"], [40, "PrimaryPlatform"], [44, "CMMFlags"], [48, "DeviceManufacturer"], [52, "DeviceModel"], [56, "DeviceAttributes"], [64, "RenderingIntent"], [68, "ConnectionSpaceIlluminant"], [80, "ProfileCreator"], [84, "ProfileID"], ["Header", "ProfileHeader"], ["MS00", "WCSProfiles"], ["bTRC", "BlueTRC"], ["bXYZ", "BlueMatrixColumn"], ["bfd", "UCRBG"], ["bkpt", "MediaBlackPoint"], ["calt", "CalibrationDateTime"], ["chad", "ChromaticAdaptation"], ["chrm", "Chromaticity"], ["ciis", "ColorimetricIntentImageState"], ["clot", "ColorantTableOut"], ["clro", "ColorantOrder"], ["clrt", "ColorantTable"], ["cprt", "ProfileCopyright"], ["crdi", "CRDInfo"], ["desc", "ProfileDescription"], ["devs", "DeviceSettings"], ["dmdd", "DeviceModelDesc"], ["dmnd", "DeviceMfgDesc"], ["dscm", "ProfileDescriptionML"], ["fpce", "FocalPlaneColorimetryEstimates"], ["gTRC", "GreenTRC"], ["gXYZ", "GreenMatrixColumn"], ["gamt", "Gamut"], ["kTRC", "GrayTRC"], ["lumi", "Luminance"], ["meas", "Measurement"], ["meta", "Metadata"], ["mmod", "MakeAndModel"], ["ncl2", "NamedColor2"], ["ncol", "NamedColor"], ["ndin", "NativeDisplayInfo"], ["pre0", "Preview0"], ["pre1", "Preview1"], ["pre2", "Preview2"], ["ps2i", "PS2RenderingIntent"], ["ps2s", "PostScript2CSA"], ["psd0", "PostScript2CRD0"], ["psd1", "PostScript2CRD1"], ["psd2", "PostScript2CRD2"], ["psd3", "PostScript2CRD3"], ["pseq", "ProfileSequenceDesc"], ["psid", "ProfileSequenceIdentifier"], ["psvm", "PS2CRDVMSize"], ["rTRC", "RedTRC"], ["rXYZ", "RedMatrixColumn"], ["resp", "OutputResponse"], ["rhoc", "ReflectionHardcopyOrigColorimetry"], ["rig0", "PerceptualRenderingIntentGamut"], ["rig2", "SaturationRenderingIntentGamut"], ["rpoc", "ReflectionPrintOutputColorimetry"], ["sape", "SceneAppearanceEstimates"], ["scoe", "SceneColorimetryEstimates"], ["scrd", "ScreeningDesc"], ["scrn", "Screening"], ["targ", "CharTarget"], ["tech", "Technology"], ["vcgt", "VideoCardGamma"], ["view", "ViewingConditions"], ["vued", "ViewingCondDesc"], ["wtpt", "MediaWhitePoint"]]);
const Ir = { "4d2p": "Erdt Systems", AAMA: "Aamazing Technologies", ACER: "Acer", ACLT: "Acolyte Color Research", ACTI: "Actix Sytems", ADAR: "Adara Technology", ADBE: "Adobe", ADI: "ADI Systems", AGFA: "Agfa Graphics", ALMD: "Alps Electric", ALPS: "Alps Electric", ALWN: "Alwan Color Expertise", AMTI: "Amiable Technologies", AOC: "AOC International", APAG: "Apago", APPL: "Apple Computer", AST: "AST", "AT&T": "AT&T", BAEL: "BARBIERI electronic", BRCO: "Barco NV", BRKP: "Breakpoint", BROT: "Brother", BULL: "Bull", BUS: "Bus Computer Systems", "C-IT": "C-Itoh", CAMR: "Intel", CANO: "Canon", CARR: "Carroll Touch", CASI: "Casio", CBUS: "Colorbus PL", CEL: "Crossfield", CELx: "Crossfield", CGS: "CGS Publishing Technologies International", CHM: "Rochester Robotics", CIGL: "Colour Imaging Group, London", CITI: "Citizen", CL00: "Candela", CLIQ: "Color IQ", CMCO: "Chromaco", CMiX: "CHROMiX", COLO: "Colorgraphic Communications", COMP: "Compaq", COMp: "Compeq/Focus Technology", CONR: "Conrac Display Products", CORD: "Cordata Technologies", CPQ: "Compaq", CPRO: "ColorPro", CRN: "Cornerstone", CTX: "CTX International", CVIS: "ColorVision", CWC: "Fujitsu Laboratories", DARI: "Darius Technology", DATA: "Dataproducts", DCP: "Dry Creek Photo", DCRC: "Digital Contents Resource Center, Chung-Ang University", DELL: "Dell Computer", DIC: "Dainippon Ink and Chemicals", DICO: "Diconix", DIGI: "Digital", "DL&C": "Digital Light & Color", DPLG: "Doppelganger", DS: "Dainippon Screen", DSOL: "DOOSOL", DUPN: "DuPont", EPSO: "Epson", ESKO: "Esko-Graphics", ETRI: "Electronics and Telecommunications Research Institute", EVER: "Everex Systems", EXAC: "ExactCODE", Eizo: "Eizo", FALC: "Falco Data Products", FF: "Fuji Photo Film", FFEI: "FujiFilm Electronic Imaging", FNRD: "Fnord Software", FORA: "Fora", FORE: "Forefront Technology", FP: "Fujitsu", FPA: "WayTech Development", FUJI: "Fujitsu", FX: "Fuji Xerox", GCC: "GCC Technologies", GGSL: "Global Graphics Software", GMB: "Gretagmacbeth", GMG: "GMG", GOLD: "GoldStar Technology", GOOG: "Google", GPRT: "Giantprint", GTMB: "Gretagmacbeth", GVC: "WayTech Development", GW2K: "Sony", HCI: "HCI", HDM: "Heidelberger Druckmaschinen", HERM: "Hermes", HITA: "Hitachi America", HP: "Hewlett-Packard", HTC: "Hitachi", HiTi: "HiTi Digital", IBM: "IBM", IDNT: "Scitex", IEC: "Hewlett-Packard", IIYA: "Iiyama North America", IKEG: "Ikegami Electronics", IMAG: "Image Systems", IMI: "Ingram Micro", INTC: "Intel", INTL: "N/A (INTL)", INTR: "Intra Electronics", IOCO: "Iocomm International Technology", IPS: "InfoPrint Solutions Company", IRIS: "Scitex", ISL: "Ichikawa Soft Laboratory", ITNL: "N/A (ITNL)", IVM: "IVM", IWAT: "Iwatsu Electric", Idnt: "Scitex", Inca: "Inca Digital Printers", Iris: "Scitex", JPEG: "Joint Photographic Experts Group", JSFT: "Jetsoft Development", JVC: "JVC Information Products", KART: "Scitex", KFC: "KFC Computek Components", KLH: "KLH Computers", KMHD: "Konica Minolta", KNCA: "Konica", KODA: "Kodak", KYOC: "Kyocera", Kart: "Scitex", LCAG: "Leica", LCCD: "Leeds Colour", LDAK: "Left Dakota", LEAD: "Leading Technology", LEXM: "Lexmark International", LINK: "Link Computer", LINO: "Linotronic", LITE: "Lite-On", Leaf: "Leaf", Lino: "Linotronic", MAGC: "Mag Computronic", MAGI: "MAG Innovision", MANN: "Mannesmann", MICN: "Micron Technology", MICR: "Microtek", MICV: "Microvitec", MINO: "Minolta", MITS: "Mitsubishi Electronics America", MITs: "Mitsuba", MNLT: "Minolta", MODG: "Modgraph", MONI: "Monitronix", MONS: "Monaco Systems", MORS: "Morse Technology", MOTI: "Motive Systems", MSFT: "Microsoft", MUTO: "MUTOH INDUSTRIES", Mits: "Mitsubishi Electric", NANA: "NANAO", NEC: "NEC", NEXP: "NexPress Solutions", NISS: "Nissei Sangyo America", NKON: "Nikon", NONE: "none", OCE: "Oce Technologies", OCEC: "OceColor", OKI: "Oki", OKID: "Okidata", OKIP: "Okidata", OLIV: "Olivetti", OLYM: "Olympus", ONYX: "Onyx Graphics", OPTI: "Optiquest", PACK: "Packard Bell", PANA: "Matsushita Electric Industrial", PANT: "Pantone", PBN: "Packard Bell", PFU: "PFU", PHIL: "Philips Consumer Electronics", PNTX: "HOYA", POne: "Phase One A/S", PREM: "Premier Computer Innovations", PRIN: "Princeton Graphic Systems", PRIP: "Princeton Publishing Labs", QLUX: "Hong Kong", QMS: "QMS", QPCD: "QPcard AB", QUAD: "QuadLaser", QUME: "Qume", RADI: "Radius", RDDx: "Integrated Color Solutions", RDG: "Roland DG", REDM: "REDMS Group", RELI: "Relisys", RGMS: "Rolf Gierling Multitools", RICO: "Ricoh", RNLD: "Edmund Ronald", ROYA: "Royal", RPC: "Ricoh Printing Systems", RTL: "Royal Information Electronics", SAMP: "Sampo", SAMS: "Samsung", SANT: "Jaime Santana Pomares", SCIT: "Scitex", SCRN: "Dainippon Screen", SDP: "Scitex", SEC: "Samsung", SEIK: "Seiko Instruments", SEIk: "Seikosha", SGUY: "ScanGuy.com", SHAR: "Sharp Laboratories", SICC: "International Color Consortium", SONY: "Sony", SPCL: "SpectraCal", STAR: "Star", STC: "Sampo Technology", Scit: "Scitex", Sdp: "Scitex", Sony: "Sony", TALO: "Talon Technology", TAND: "Tandy", TATU: "Tatung", TAXA: "TAXAN America", TDS: "Tokyo Denshi Sekei", TECO: "TECO Information Systems", TEGR: "Tegra", TEKT: "Tektronix", TI: "Texas Instruments", TMKR: "TypeMaker", TOSB: "Toshiba", TOSH: "Toshiba", TOTK: "TOTOKU ELECTRIC", TRIU: "Triumph", TSBT: "Toshiba", TTX: "TTX Computer Products", TVM: "TVM Professional Monitor", TW: "TW Casper", ULSX: "Ulead Systems", UNIS: "Unisys", UTZF: "Utz Fehlau & Sohn", VARI: "Varityper", VIEW: "Viewsonic", VISL: "Visual communication", VIVO: "Vivo Mobile Communication", WANG: "Wang", WLBR: "Wilbur Imaging", WTG2: "Ware To Go", WYSE: "WYSE Technology", XERX: "Xerox", XRIT: "X-Rite", ZRAN: "Zoran", Zebr: "Zebra Technologies", appl: "Apple Computer", bICC: "basICColor", berg: "bergdesign", ceyd: "Integrated Color Solutions", clsp: "MacDermid ColorSpan", ds: "Dainippon Screen", dupn: "DuPont", ffei: "FujiFilm Electronic Imaging", flux: "FluxData", iris: "Scitex", kart: "Scitex", lcms: "Little CMS", lino: "Linotronic", none: "none", ob4d: "Erdt Systems", obic: "Medigraph", quby: "Qubyx Sarl", scit: "Scitex", scrn: "Dainippon Screen", sdp: "Scitex", siwi: "SIWI GRAFIKA", yxym: "YxyMaster" }, wu = { scnr: "Scanner", mntr: "Monitor", prtr: "Printer", link: "Device Link", abst: "Abstract", spac: "Color Space Conversion Profile", nmcl: "Named Color", cenc: "ColorEncodingSpace profile", mid: "MultiplexIdentification profile", mlnk: "MultiplexLink profile", mvis: "MultiplexVisualization profile", nkpf: "Nikon Input Device Profile (NON-STANDARD!)" };
$e(Hn, "icc", [[4, Ir], [12, wu], [40, Object.assign({}, Ir, wu)], [48, Ir], [80, Ir], [64, { 0: "Perceptual", 1: "Relative Colorimetric", 2: "Saturation", 3: "Absolute Colorimetric" }], ["tech", { amd: "Active Matrix Display", crt: "Cathode Ray Tube Display", kpcd: "Photo CD", pmd: "Passive Matrix Display", dcam: "Digital Camera", dcpj: "Digital Cinema Projector", dmpc: "Digital Motion Picture Camera", dsub: "Dye Sublimation Printer", epho: "Electrophotographic Printer", esta: "Electrostatic Printer", flex: "Flexography", fprn: "Film Writer", fscn: "Film Scanner", grav: "Gravure", ijet: "Ink Jet Printer", imgs: "Photo Image Setter", mpfr: "Motion Picture Film Recorder", mpfs: "Motion Picture Film Scanner", offs: "Offset Lithography", pjtv: "Projection Television", rpho: "Photographic Paper Printer", rscn: "Reflective Scanner", silk: "Silkscreen", twax: "Thermal Wax Printer", vidc: "Video Camera", vidm: "Video Monitor" }]]);
class $r extends St {
  static canHandle(e, t, i) {
    return e.getUint8(t + 1) === 237 && e.getString(t + 4, 9) === "Photoshop" && this.containsIptc8bim(e, t, i) !== void 0;
  }
  static headerLength(e, t, i) {
    let r, a = this.containsIptc8bim(e, t, i);
    if (a !== void 0) return r = e.getUint8(t + a + 7), r % 2 != 0 && (r += 1), r === 0 && (r = 4), a + 8 + r;
  }
  static containsIptc8bim(e, t, i) {
    for (let r = 0; r < i; r++) if (this.isIptcSegmentHead(e, t + r)) return r;
  }
  static isIptcSegmentHead(e, t) {
    return e.getUint8(t) === 56 && e.getUint32(t) === 943868237 && e.getUint16(t + 4) === 1028;
  }
  parse() {
    let { raw: e } = this, t = this.chunk.byteLength - 1, i = !1;
    for (let r = 0; r < t; r++) if (this.chunk.getUint8(r) === 28 && this.chunk.getUint8(r + 1) === 2) {
      i = !0;
      let a = this.chunk.getUint16(r + 3), s = this.chunk.getUint8(r + 2), o = this.chunk.getLatin1String(r + 5, a);
      e.set(s, this.pluralizeValue(e.get(s), o)), r += 4 + a;
    } else if (i) break;
    return this.translate(), this.output;
  }
  pluralizeValue(e, t) {
    return e !== void 0 ? e instanceof Array ? (e.push(t), e) : [e, t] : t;
  }
}
U($r, "type", "iptc"), U($r, "translateValues", !1), U($r, "reviveValues", !1), Me.set("iptc", $r), $e(tt, "iptc", [[0, "ApplicationRecordVersion"], [3, "ObjectTypeReference"], [4, "ObjectAttributeReference"], [5, "ObjectName"], [7, "EditStatus"], [8, "EditorialUpdate"], [10, "Urgency"], [12, "SubjectReference"], [15, "Category"], [20, "SupplementalCategories"], [22, "FixtureIdentifier"], [25, "Keywords"], [26, "ContentLocationCode"], [27, "ContentLocationName"], [30, "ReleaseDate"], [35, "ReleaseTime"], [37, "ExpirationDate"], [38, "ExpirationTime"], [40, "SpecialInstructions"], [42, "ActionAdvised"], [45, "ReferenceService"], [47, "ReferenceDate"], [50, "ReferenceNumber"], [55, "DateCreated"], [60, "TimeCreated"], [62, "DigitalCreationDate"], [63, "DigitalCreationTime"], [65, "OriginatingProgram"], [70, "ProgramVersion"], [75, "ObjectCycle"], [80, "Byline"], [85, "BylineTitle"], [90, "City"], [92, "Sublocation"], [95, "State"], [100, "CountryCode"], [101, "Country"], [103, "OriginalTransmissionReference"], [105, "Headline"], [110, "Credit"], [115, "Source"], [116, "CopyrightNotice"], [118, "Contact"], [120, "Caption"], [121, "LocalCaption"], [122, "Writer"], [125, "RasterizedCaption"], [130, "ImageType"], [131, "ImageOrientation"], [135, "LanguageIdentifier"], [150, "AudioType"], [151, "AudioSamplingRate"], [152, "AudioSamplingResolution"], [153, "AudioDuration"], [154, "AudioOutcue"], [184, "JobID"], [185, "MasterDocumentID"], [186, "ShortDocumentID"], [187, "UniqueDocumentID"], [188, "OwnerID"], [200, "ObjectPreviewFileFormat"], [201, "ObjectPreviewFileVersion"], [202, "ObjectPreviewData"], [221, "Prefs"], [225, "ClassifyState"], [228, "SimilarityIndex"], [230, "DocumentNotes"], [231, "DocumentHistory"], [232, "ExifCameraInfo"], [255, "CatalogSets"]]), $e(Hn, "iptc", [[10, { 0: "0 (reserved)", 1: "1 (most urgent)", 2: "2", 3: "3", 4: "4", 5: "5 (normal urgency)", 6: "6", 7: "7", 8: "8 (least urgent)", 9: "9 (user-defined priority)" }], [75, { a: "Morning", b: "Both Morning and Evening", p: "Evening" }], [131, { L: "Landscape", P: "Portrait", S: "Square" }]]);
const Gf = (n) => {
  let e;
  if (n.currentTarget instanceof Element)
    e = n.currentTarget.querySelector("img");
  else
    return [NaN, NaN];
  const t = e.getBoundingClientRect(), i = e.naturalWidth / t.width, r = e.naturalHeight / t.height;
  if (i > r) {
    const o = e.naturalHeight / i, l = (t.height - o) / 2;
    var a = Math.round((n.clientX - t.left) * i), s = Math.round((n.clientY - t.top - l) * i);
  } else {
    const o = e.naturalWidth / r, l = (t.width - o) / 2;
    var a = Math.round((n.clientX - t.left - l) * r), s = Math.round((n.clientY - t.top) * r);
  }
  return a < 0 || a >= e.naturalWidth || s < 0 || s >= e.naturalHeight ? null : [a, s];
};
async function zf(n, e) {
  if (!(n != null && n.url))
    return null;
  const t = n.url.toLowerCase();
  if (t.endsWith(".svg"))
    return {};
  try {
    const i = await kg(n.url, !0);
    if (!i)
      return {};
    if (t.endsWith(".png")) {
      const r = {};
      for (const [a, s] of Object.entries(i))
        (typeof s == "string" || typeof s == "number" || typeof s == "boolean") && (r[a] = s);
      return r;
    }
    if (t.endsWith(".jpg") || t.endsWith(".jpeg")) {
      let r = {};
      const a = {}, o = i[37510];
      if (o instanceof Uint8Array && o.length > 8)
        try {
          const l = new TextDecoder("utf-8", { fatal: !0 }), c = o.slice(8), u = l.decode(c).replace(/\0/g, "");
          r = JSON.parse(u);
        } catch (l) {
          console.error("Could not parse JSON from UserComment:", l), a.UserComment_RawError = "Failed to parse JSON content.";
        }
      if (e)
        return r;
      for (const [l, c] of Object.entries(i))
        Number(l) !== 37510 && (typeof c == "string" || typeof c == "number" || typeof c == "boolean") && (l in r || (a[l] = c));
      return { ...a, ...r };
    }
    return {};
  } catch (i) {
    return console.error("Failed to extract or process metadata:", i), { error: "Failed to extract metadata" };
  }
}
const qf = /* @__PURE__ */ new Set([
  "ImageWidth",
  "ImageHeight",
  "BitsPerSample",
  "Compression",
  "PhotometricInterpretation",
  "FillOrder",
  "DocumentName",
  "ImageDescription",
  "Orientation",
  "SamplesPerPixel",
  "PlanarConfiguration",
  "YCbCrSubSampling",
  "YCbCrPositioning",
  "XResolution",
  "YResolution",
  "ResolutionUnit",
  "StripOffsets",
  "RowsPerStrip",
  "StripByteCounts",
  "JPEGInterchangeFormat",
  "JPEGInterchangeFormatLength",
  "TransferFunction",
  "WhitePoint",
  "PrimaryChromaticities",
  "YCbCrCoefficients",
  "ReferenceBlackWhite",
  "DateTime",
  "ImageDescription",
  "Software",
  "HostComputer",
  "Predictor",
  "TileWidth",
  "TileLength",
  "TileOffsets",
  "TileByteCounts",
  "SubIFDs",
  "ExtraSamples",
  "SampleFormat",
  "JPEGTables",
  // === ExifIFD ===
  "ExifVersion",
  "FlashpixVersion",
  "ColorSpace",
  "ComponentsConfiguration",
  "CompressedBitsPerPixel",
  "PixelXDimension",
  "PixelYDimension",
  "MakerNote",
  "RelatedSoundFile",
  "DateTimeOriginal",
  "CreateDate",
  "SubSecTime",
  "SubSecTimeOriginal",
  "SubSecTimeDigitized",
  "FlashEnergy",
  "SpatialFrequencyResponse",
  "FocalPlaneXResolution",
  "FocalPlaneYResolution",
  "FocalPlaneResolutionUnit",
  "SubjectLocation",
  "SensingMethod",
  "FileSource",
  "SceneType",
  "CFAPattern",
  "Gamma",
  // === GPS IFD ===
  "GPSVersionID",
  "GPSLatitudeRef",
  "GPSLatitude",
  "GPSLongitudeRef",
  "GPSLongitude",
  "GPSAltitudeRef",
  "GPSAltitude",
  "GPSTimeStamp",
  "GPSSatellites",
  "GPSStatus",
  "GPSMeasureMode",
  "GPSDOP",
  "GPSSpeedRef",
  "GPSSpeed",
  "GPSTrackRef",
  "GPSTrack",
  "GPSImgDirectionRef",
  "GPSImgDirection",
  "GPSMapDatum",
  "GPSDestLatitudeRef",
  "GPSDestLatitude",
  "GPSDestLongitudeRef",
  "GPSDestLongitude",
  "GPSDestBearingRef",
  "GPSDestBearing",
  "GPSDestDistanceRef",
  "GPSDestDistance",
  "GPSProcessingMethod",
  "GPSAreaInformation",
  "GPSDateStamp",
  "GPSDifferential",
  "GPSHPositioningError",
  // === Interoperability IFD ===
  "InteroperabilityIndex",
  "InteroperabilityVersion",
  // === PNG Specific ===
  "BitDepth",
  "ColorType",
  "Filter",
  "Interlace",
  //==- Adobe Photoshop common ==
  "CreatorTool",
  "CreateDate",
  "ModifyDate",
  "MetadataDate",
  "format",
  "ColorMode",
  "InstanceID",
  "DocumentID",
  "OriginalDocumentID",
  // --- Other Common Tags ---
  "ThumbnailOffset",
  "ThumbnailLength"
]), { setContext: w6, getContext: Gg } = window.__gradio__svelte__internal, zg = "WORKER_PROXY_CONTEXT_KEY";
function Vf() {
  return Gg(zg);
}
const qg = "lite.local";
function Vg(n) {
  return n.host === window.location.host || n.host === "localhost:7860" || n.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  n.host === qg;
}
function jf(n, e) {
  const t = e.toLowerCase();
  for (const [i, r] of Object.entries(n))
    if (i.toLowerCase() === t)
      return r;
}
function Wf(n) {
  const e = typeof window < "u";
  if (n == null || !e)
    return !1;
  const t = new URL(n, window.location.href);
  return !(!Vg(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
let Pr;
async function jg(n) {
  const e = typeof window < "u";
  if (n == null || !e || !Wf(n))
    return n;
  if (Pr == null)
    try {
      Pr = Vf();
    } catch {
      return n;
    }
  if (Pr == null)
    return n;
  const i = new URL(n, window.location.href).pathname;
  return Pr.httpRequest({
    method: "GET",
    path: i,
    headers: {},
    query_string: ""
  }).then((r) => {
    if (r.status !== 200)
      throw new Error(`Failed to get file ${i} from the Wasm worker.`);
    const a = new Blob([r.body], {
      type: jf(r.headers, "content-type")
    });
    return URL.createObjectURL(a);
  });
}
const {
  SvelteComponent: Wg,
  assign: sa,
  check_outros: Xf,
  children: Yf,
  claim_element: Zf,
  compute_rest_props: Du,
  create_slot: xo,
  detach: ui,
  element: Kf,
  empty: oa,
  exclude_internal_props: Xg,
  get_all_dirty_from_scope: Bo,
  get_slot_changes: Oo,
  get_spread_update: Jf,
  group_outros: Qf,
  init: Yg,
  insert_hydration: Sa,
  listen: eh,
  prevent_default: Zg,
  safe_not_equal: Kg,
  set_attributes: la,
  set_style: Eu,
  toggle_class: ua,
  transition_in: Pn,
  transition_out: xn,
  update_slot_base: Ro
} = window.__gradio__svelte__internal, { createEventDispatcher: Jg, onMount: D6 } = window.__gradio__svelte__internal;
function Qg(n) {
  let e, t, i, r, a;
  const s = (
    /*#slots*/
    n[8].default
  ), o = xo(
    s,
    n,
    /*$$scope*/
    n[7],
    null
  );
  let l = [
    { class: "download-link" },
    { href: (
      /*href*/
      n[0]
    ) },
    {
      target: t = typeof window < "u" && window.__is_colab__ ? "_blank" : null
    },
    { rel: "noopener noreferrer" },
    { download: (
      /*download*/
      n[1]
    ) },
    /*$$restProps*/
    n[6]
  ], c = {};
  for (let u = 0; u < l.length; u += 1)
    c = sa(c, l[u]);
  return {
    c() {
      e = Kf("a"), o && o.c(), this.h();
    },
    l(u) {
      e = Zf(u, "A", {
        class: !0,
        href: !0,
        target: !0,
        rel: !0,
        download: !0
      });
      var f = Yf(e);
      o && o.l(f), f.forEach(ui), this.h();
    },
    h() {
      la(e, c), Eu(e, "position", "relative"), ua(e, "svelte-151nsdd", !0);
    },
    m(u, f) {
      Sa(u, e, f), o && o.m(e, null), i = !0, r || (a = eh(
        e,
        "click",
        /*dispatch*/
        n[3].bind(null, "click")
      ), r = !0);
    },
    p(u, f) {
      o && o.p && (!i || f & /*$$scope*/
      128) && Ro(
        o,
        s,
        u,
        /*$$scope*/
        u[7],
        i ? Oo(
          s,
          /*$$scope*/
          u[7],
          f,
          null
        ) : Bo(
          /*$$scope*/
          u[7]
        ),
        null
      ), la(e, c = Jf(l, [
        { class: "download-link" },
        (!i || f & /*href*/
        1) && { href: (
          /*href*/
          u[0]
        ) },
        { target: t },
        { rel: "noopener noreferrer" },
        (!i || f & /*download*/
        2) && { download: (
          /*download*/
          u[1]
        ) },
        f & /*$$restProps*/
        64 && /*$$restProps*/
        u[6]
      ])), Eu(e, "position", "relative"), ua(e, "svelte-151nsdd", !0);
    },
    i(u) {
      i || (Pn(o, u), i = !0);
    },
    o(u) {
      xn(o, u), i = !1;
    },
    d(u) {
      u && ui(e), o && o.d(u), r = !1, a();
    }
  };
}
function e0(n) {
  let e, t, i, r;
  const a = [n0, t0], s = [];
  function o(l, c) {
    return (
      /*is_downloading*/
      l[2] ? 0 : 1
    );
  }
  return e = o(n), t = s[e] = a[e](n), {
    c() {
      t.c(), i = oa();
    },
    l(l) {
      t.l(l), i = oa();
    },
    m(l, c) {
      s[e].m(l, c), Sa(l, i, c), r = !0;
    },
    p(l, c) {
      let u = e;
      e = o(l), e === u ? s[e].p(l, c) : (Qf(), xn(s[u], 1, 1, () => {
        s[u] = null;
      }), Xf(), t = s[e], t ? t.p(l, c) : (t = s[e] = a[e](l), t.c()), Pn(t, 1), t.m(i.parentNode, i));
    },
    i(l) {
      r || (Pn(t), r = !0);
    },
    o(l) {
      xn(t), r = !1;
    },
    d(l) {
      l && ui(i), s[e].d(l);
    }
  };
}
function t0(n) {
  let e, t, i, r;
  const a = (
    /*#slots*/
    n[8].default
  ), s = xo(
    a,
    n,
    /*$$scope*/
    n[7],
    null
  );
  let o = [
    /*$$restProps*/
    n[6],
    { href: (
      /*href*/
      n[0]
    ) }
  ], l = {};
  for (let c = 0; c < o.length; c += 1)
    l = sa(l, o[c]);
  return {
    c() {
      e = Kf("a"), s && s.c(), this.h();
    },
    l(c) {
      e = Zf(c, "A", { href: !0 });
      var u = Yf(e);
      s && s.l(u), u.forEach(ui), this.h();
    },
    h() {
      la(e, l), ua(e, "svelte-151nsdd", !0);
    },
    m(c, u) {
      Sa(c, e, u), s && s.m(e, null), t = !0, i || (r = eh(e, "click", Zg(
        /*wasm_click_handler*/
        n[5]
      )), i = !0);
    },
    p(c, u) {
      s && s.p && (!t || u & /*$$scope*/
      128) && Ro(
        s,
        a,
        c,
        /*$$scope*/
        c[7],
        t ? Oo(
          a,
          /*$$scope*/
          c[7],
          u,
          null
        ) : Bo(
          /*$$scope*/
          c[7]
        ),
        null
      ), la(e, l = Jf(o, [
        u & /*$$restProps*/
        64 && /*$$restProps*/
        c[6],
        (!t || u & /*href*/
        1) && { href: (
          /*href*/
          c[0]
        ) }
      ])), ua(e, "svelte-151nsdd", !0);
    },
    i(c) {
      t || (Pn(s, c), t = !0);
    },
    o(c) {
      xn(s, c), t = !1;
    },
    d(c) {
      c && ui(e), s && s.d(c), i = !1, r();
    }
  };
}
function n0(n) {
  let e;
  const t = (
    /*#slots*/
    n[8].default
  ), i = xo(
    t,
    n,
    /*$$scope*/
    n[7],
    null
  );
  return {
    c() {
      i && i.c();
    },
    l(r) {
      i && i.l(r);
    },
    m(r, a) {
      i && i.m(r, a), e = !0;
    },
    p(r, a) {
      i && i.p && (!e || a & /*$$scope*/
      128) && Ro(
        i,
        t,
        r,
        /*$$scope*/
        r[7],
        e ? Oo(
          t,
          /*$$scope*/
          r[7],
          a,
          null
        ) : Bo(
          /*$$scope*/
          r[7]
        ),
        null
      );
    },
    i(r) {
      e || (Pn(i, r), e = !0);
    },
    o(r) {
      xn(i, r), e = !1;
    },
    d(r) {
      i && i.d(r);
    }
  };
}
function i0(n) {
  let e, t, i, r, a;
  const s = [e0, Qg], o = [];
  function l(c, u) {
    return u & /*href*/
    1 && (e = null), e == null && (e = !!/*worker_proxy*/
    (c[4] && Wf(
      /*href*/
      c[0]
    ))), e ? 0 : 1;
  }
  return t = l(n, -1), i = o[t] = s[t](n), {
    c() {
      i.c(), r = oa();
    },
    l(c) {
      i.l(c), r = oa();
    },
    m(c, u) {
      o[t].m(c, u), Sa(c, r, u), a = !0;
    },
    p(c, [u]) {
      let f = t;
      t = l(c, u), t === f ? o[t].p(c, u) : (Qf(), xn(o[f], 1, 1, () => {
        o[f] = null;
      }), Xf(), i = o[t], i ? i.p(c, u) : (i = o[t] = s[t](c), i.c()), Pn(i, 1), i.m(r.parentNode, r));
    },
    i(c) {
      a || (Pn(i), a = !0);
    },
    o(c) {
      xn(i), a = !1;
    },
    d(c) {
      c && ui(r), o[t].d(c);
    }
  };
}
function r0(n, e, t) {
  const i = ["href", "download"];
  let r = Du(e, i), { $$slots: a = {}, $$scope: s } = e, { href: o = void 0 } = e, { download: l } = e;
  const c = Jg();
  let u = !1;
  const f = Vf();
  async function h() {
    if (u)
      return;
    if (c("click"), o == null)
      throw new Error("href is not defined.");
    if (f == null)
      throw new Error("Wasm worker proxy is not available.");
    const p = new URL(o, window.location.href).pathname;
    t(2, u = !0), f.httpRequest({
      method: "GET",
      path: p,
      headers: {},
      query_string: ""
    }).then((g) => {
      if (g.status !== 200)
        throw new Error(`Failed to get file ${p} from the Wasm worker.`);
      const E = new Blob(
        [g.body],
        {
          type: jf(g.headers, "content-type")
        }
      ), w = URL.createObjectURL(E), m = document.createElement("a");
      m.href = w, m.download = l, m.click(), URL.revokeObjectURL(w);
    }).finally(() => {
      t(2, u = !1);
    });
  }
  return n.$$set = (d) => {
    e = sa(sa({}, e), Xg(d)), t(6, r = Du(e, i)), "href" in d && t(0, o = d.href), "download" in d && t(1, l = d.download), "$$scope" in d && t(7, s = d.$$scope);
  }, [
    o,
    l,
    u,
    c,
    f,
    h,
    r,
    s,
    a
  ];
}
class a0 extends Wg {
  constructor(e) {
    super(), Yg(this, e, r0, i0, Kg, { href: 0, download: 1 });
  }
}
const {
  SvelteComponent: s0,
  assign: Ws,
  bubble: o0,
  claim_element: l0,
  compute_rest_props: Cu,
  detach: u0,
  element: c0,
  exclude_internal_props: f0,
  get_spread_update: h0,
  init: d0,
  insert_hydration: _0,
  listen: p0,
  noop: Su,
  safe_not_equal: m0,
  set_attributes: ku,
  src_url_equal: g0,
  toggle_class: Au
} = window.__gradio__svelte__internal;
function b0(n) {
  let e, t, i, r, a = [
    {
      src: t = /*resolved_src*/
      n[0]
    },
    /*$$restProps*/
    n[1]
  ], s = {};
  for (let o = 0; o < a.length; o += 1)
    s = Ws(s, a[o]);
  return {
    c() {
      e = c0("img"), this.h();
    },
    l(o) {
      e = l0(o, "IMG", { src: !0 }), this.h();
    },
    h() {
      ku(e, s), Au(e, "svelte-kxeri3", !0);
    },
    m(o, l) {
      _0(o, e, l), i || (r = p0(
        e,
        "load",
        /*load_handler*/
        n[4]
      ), i = !0);
    },
    p(o, [l]) {
      ku(e, s = h0(a, [
        l & /*resolved_src*/
        1 && !g0(e.src, t = /*resolved_src*/
        o[0]) && { src: t },
        l & /*$$restProps*/
        2 && /*$$restProps*/
        o[1]
      ])), Au(e, "svelte-kxeri3", !0);
    },
    i: Su,
    o: Su,
    d(o) {
      o && u0(e), i = !1, r();
    }
  };
}
function v0(n, e, t) {
  const i = ["src"];
  let r = Cu(e, i), { src: a = void 0 } = e, s, o;
  function l(c) {
    o0.call(this, n, c);
  }
  return n.$$set = (c) => {
    e = Ws(Ws({}, e), f0(c)), t(1, r = Cu(e, i)), "src" in c && t(2, a = c.src);
  }, n.$$.update = () => {
    if (n.$$.dirty & /*src, latest_src*/
    12) {
      t(0, s = a), t(3, o = a);
      const c = a;
      jg(c).then((u) => {
        o === c && t(0, s = u);
      });
    }
  }, [s, r, a, o, l];
}
class Lo extends s0 {
  constructor(e) {
    super(), d0(this, e, v0, b0, m0, { src: 2 });
  }
}
const {
  SvelteComponent: y0,
  append_hydration: Te,
  attr: st,
  binding_callbacks: w0,
  bubble: xr,
  check_outros: Oi,
  children: ft,
  claim_component: zt,
  claim_element: Ue,
  claim_space: It,
  claim_text: Xs,
  create_component: qt,
  destroy_component: Vt,
  destroy_each: D0,
  detach: ie,
  element: He,
  empty: ci,
  ensure_array_like: Fu,
  get_svelte_dataset: ca,
  group_outros: Ri,
  init: E0,
  insert_hydration: Ge,
  listen: Mo,
  mount_component: jt,
  noop: th,
  safe_not_equal: C0,
  set_data: Ys,
  set_style: un,
  space: $t,
  text: Zs,
  toggle_class: Tu,
  transition_in: he,
  transition_out: we
} = window.__gradio__svelte__internal, { createEventDispatcher: S0, onMount: E6 } = window.__gradio__svelte__internal;
function Iu(n, e, t) {
  const i = n.slice();
  return i[32] = e[t][0], i[33] = e[t][1], i;
}
function k0(n) {
  let e, t, i, r, a, s, o, l, c;
  return t = new Cf({
    props: {
      display_top_corner: (
        /*display_icon_button_wrapper_top_corner*/
        n[8]
      ),
      $$slots: { default: [T0] },
      $$scope: { ctx: n }
    }
  }), s = new Lo({
    props: {
      src: (
        /*value*/
        n[0].url
      ),
      alt: "",
      loading: "lazy"
    }
  }), s.$on(
    "load",
    /*load_handler*/
    n[29]
  ), {
    c() {
      e = He("div"), qt(t.$$.fragment), i = $t(), r = He("button"), a = He("div"), qt(s.$$.fragment), this.h();
    },
    l(u) {
      e = Ue(u, "DIV", { class: !0 });
      var f = ft(e);
      zt(t.$$.fragment, f), i = It(f), r = Ue(f, "BUTTON", { class: !0 });
      var h = ft(r);
      a = Ue(h, "DIV", { class: !0 });
      var d = ft(a);
      zt(s.$$.fragment, d), d.forEach(ie), h.forEach(ie), f.forEach(ie), this.h();
    },
    h() {
      st(a, "class", "image-frame svelte-1xu9fdw"), Tu(
        a,
        "selectable",
        /*selectable*/
        n[4]
      ), st(r, "class", "svelte-1xu9fdw"), st(e, "class", "image-container svelte-1xu9fdw"), un(
        e,
        "height",
        /*height*/
        n[12]
      ), un(
        e,
        "width",
        /*width*/
        n[13]
      );
    },
    m(u, f) {
      Ge(u, e, f), jt(t, e, null), Te(e, i), Te(e, r), Te(r, a), jt(s, a, null), n[30](e), o = !0, l || (c = Mo(
        r,
        "click",
        /*handle_click*/
        n[19]
      ), l = !0);
    },
    p(u, f) {
      const h = {};
      f[0] & /*display_icon_button_wrapper_top_corner*/
      256 && (h.display_top_corner = /*display_icon_button_wrapper_top_corner*/
      u[8]), f[0] & /*i18n, value, show_share_button, show_download_button, metadata, fullscreen, show_fullscreen_button*/
      17129 | f[1] & /*$$scope*/
      32 && (h.$$scope = { dirty: f, ctx: u }), t.$set(h);
      const d = {};
      f[0] & /*value*/
      1 && (d.src = /*value*/
      u[0].url), s.$set(d), (!o || f[0] & /*selectable*/
      16) && Tu(
        a,
        "selectable",
        /*selectable*/
        u[4]
      ), f[0] & /*height*/
      4096 && un(
        e,
        "height",
        /*height*/
        u[12]
      ), f[0] & /*width*/
      8192 && un(
        e,
        "width",
        /*width*/
        u[13]
      );
    },
    i(u) {
      o || (he(t.$$.fragment, u), he(s.$$.fragment, u), o = !0);
    },
    o(u) {
      we(t.$$.fragment, u), we(s.$$.fragment, u), o = !1;
    },
    d(u) {
      u && ie(e), Vt(t), Vt(s), n[30](null), l = !1, c();
    }
  };
}
function A0(n) {
  let e, t;
  return e = new pp({
    props: {
      unpadded_box: !0,
      size: "large",
      $$slots: { default: [I0] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      qt(e.$$.fragment);
    },
    l(i) {
      zt(e.$$.fragment, i);
    },
    m(i, r) {
      jt(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[1] & /*$$scope*/
      32 && (a.$$scope = { dirty: r, ctx: i }), e.$set(a);
    },
    i(i) {
      t || (he(e.$$.fragment, i), t = !0);
    },
    o(i) {
      we(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Vt(e, i);
    }
  };
}
function $u(n) {
  let e, t;
  return e = new If({
    props: { fullscreen: (
      /*fullscreen*/
      n[9]
    ) }
  }), e.$on(
    "fullscreen",
    /*fullscreen_handler*/
    n[24]
  ), {
    c() {
      qt(e.$$.fragment);
    },
    l(i) {
      zt(e.$$.fragment, i);
    },
    m(i, r) {
      jt(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*fullscreen*/
      512 && (a.fullscreen = /*fullscreen*/
      i[9]), e.$set(a);
    },
    i(i) {
      t || (he(e.$$.fragment, i), t = !0);
    },
    o(i) {
      we(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Vt(e, i);
    }
  };
}
function Pu(n) {
  let e, t;
  return e = new _n({
    props: {
      Icon: vf,
      label: "View Metadata",
      "aria-label": "View and send image metadata"
    }
  }), e.$on(
    "click",
    /*click_handler*/
    n[25]
  ), {
    c() {
      qt(e.$$.fragment);
    },
    l(i) {
      zt(e.$$.fragment, i);
    },
    m(i, r) {
      jt(e, i, r), t = !0;
    },
    p: th,
    i(i) {
      t || (he(e.$$.fragment, i), t = !0);
    },
    o(i) {
      we(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Vt(e, i);
    }
  };
}
function xu(n) {
  let e, t;
  return e = new a0({
    props: {
      href: (
        /*value*/
        n[0].url
      ),
      download: (
        /*value*/
        n[0].orig_name || "image"
      ),
      $$slots: { default: [F0] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      qt(e.$$.fragment);
    },
    l(i) {
      zt(e.$$.fragment, i);
    },
    m(i, r) {
      jt(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*value*/
      1 && (a.href = /*value*/
      i[0].url), r[0] & /*value*/
      1 && (a.download = /*value*/
      i[0].orig_name || "image"), r[0] & /*i18n*/
      64 | r[1] & /*$$scope*/
      32 && (a.$$scope = { dirty: r, ctx: i }), e.$set(a);
    },
    i(i) {
      t || (he(e.$$.fragment, i), t = !0);
    },
    o(i) {
      we(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Vt(e, i);
    }
  };
}
function F0(n) {
  let e, t;
  return e = new _n({
    props: {
      Icon: Bp,
      label: (
        /*i18n*/
        n[6]("common.download")
      )
    }
  }), {
    c() {
      qt(e.$$.fragment);
    },
    l(i) {
      zt(e.$$.fragment, i);
    },
    m(i, r) {
      jt(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*i18n*/
      64 && (a.label = /*i18n*/
      i[6]("common.download")), e.$set(a);
    },
    i(i) {
      t || (he(e.$$.fragment, i), t = !0);
    },
    o(i) {
      we(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Vt(e, i);
    }
  };
}
function Bu(n) {
  let e, t;
  return e = new $m({
    props: {
      i18n: (
        /*i18n*/
        n[6]
      ),
      formatter: (
        /*func*/
        n[26]
      ),
      value: (
        /*value*/
        n[0]
      )
    }
  }), e.$on(
    "share",
    /*share_handler*/
    n[27]
  ), e.$on(
    "error",
    /*error_handler*/
    n[28]
  ), {
    c() {
      qt(e.$$.fragment);
    },
    l(i) {
      zt(e.$$.fragment, i);
    },
    m(i, r) {
      jt(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*i18n*/
      64 && (a.i18n = /*i18n*/
      i[6]), r[0] & /*value*/
      1 && (a.value = /*value*/
      i[0]), e.$set(a);
    },
    i(i) {
      t || (he(e.$$.fragment, i), t = !0);
    },
    o(i) {
      we(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Vt(e, i);
    }
  };
}
function T0(n) {
  let e, t, i, r, a, s = (
    /*show_fullscreen_button*/
    n[7] && $u(n)
  ), o = (
    /*metadata*/
    n[14] !== null && Pu(n)
  ), l = (
    /*show_download_button*/
    n[3] && xu(n)
  ), c = (
    /*show_share_button*/
    n[5] && Bu(n)
  );
  return {
    c() {
      s && s.c(), e = $t(), o && o.c(), t = $t(), l && l.c(), i = $t(), c && c.c(), r = ci();
    },
    l(u) {
      s && s.l(u), e = It(u), o && o.l(u), t = It(u), l && l.l(u), i = It(u), c && c.l(u), r = ci();
    },
    m(u, f) {
      s && s.m(u, f), Ge(u, e, f), o && o.m(u, f), Ge(u, t, f), l && l.m(u, f), Ge(u, i, f), c && c.m(u, f), Ge(u, r, f), a = !0;
    },
    p(u, f) {
      /*show_fullscreen_button*/
      u[7] ? s ? (s.p(u, f), f[0] & /*show_fullscreen_button*/
      128 && he(s, 1)) : (s = $u(u), s.c(), he(s, 1), s.m(e.parentNode, e)) : s && (Ri(), we(s, 1, 1, () => {
        s = null;
      }), Oi()), /*metadata*/
      u[14] !== null ? o ? (o.p(u, f), f[0] & /*metadata*/
      16384 && he(o, 1)) : (o = Pu(u), o.c(), he(o, 1), o.m(t.parentNode, t)) : o && (Ri(), we(o, 1, 1, () => {
        o = null;
      }), Oi()), /*show_download_button*/
      u[3] ? l ? (l.p(u, f), f[0] & /*show_download_button*/
      8 && he(l, 1)) : (l = xu(u), l.c(), he(l, 1), l.m(i.parentNode, i)) : l && (Ri(), we(l, 1, 1, () => {
        l = null;
      }), Oi()), /*show_share_button*/
      u[5] ? c ? (c.p(u, f), f[0] & /*show_share_button*/
      32 && he(c, 1)) : (c = Bu(u), c.c(), he(c, 1), c.m(r.parentNode, r)) : c && (Ri(), we(c, 1, 1, () => {
        c = null;
      }), Oi());
    },
    i(u) {
      a || (he(s), he(o), he(l), he(c), a = !0);
    },
    o(u) {
      we(s), we(o), we(l), we(c), a = !1;
    },
    d(u) {
      u && (ie(e), ie(t), ie(i), ie(r)), s && s.d(u), o && o.d(u), l && l.d(u), c && c.d(u);
    }
  };
}
function I0(n) {
  let e, t;
  return e = new ko({}), {
    c() {
      qt(e.$$.fragment);
    },
    l(i) {
      zt(e.$$.fragment, i);
    },
    m(i, r) {
      jt(e, i, r), t = !0;
    },
    i(i) {
      t || (he(e.$$.fragment, i), t = !0);
    },
    o(i) {
      we(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Vt(e, i);
    }
  };
}
function Ou(n) {
  let e, t, i, r = "X", a, s, o = "Image Metadata", l, c, u, f;
  function h(g, E) {
    return E[0] & /*filteredMetadata*/
    262144 && (c = null), /*filteredMetadata*/
    g[18].error ? x0 : (c == null && (c = Object.keys(
      /*filteredMetadata*/
      g[18]
    ).length > 0), c ? P0 : $0);
  }
  let d = h(n, [-1, -1]), p = d(n);
  return {
    c() {
      e = He("div"), t = He("div"), i = He("button"), i.textContent = r, a = $t(), s = He("h3"), s.textContent = o, l = $t(), p.c(), this.h();
    },
    l(g) {
      e = Ue(g, "DIV", { class: !0 });
      var E = ft(e);
      t = Ue(E, "DIV", { class: !0 });
      var w = ft(t);
      i = Ue(w, "BUTTON", { class: !0, "data-svelte-h": !0 }), ca(i) !== "svelte-1irq3m4" && (i.textContent = r), a = It(w), s = Ue(w, "H3", { class: !0, "data-svelte-h": !0 }), ca(s) !== "svelte-1tc7pig" && (s.textContent = o), l = It(w), p.l(w), w.forEach(ie), E.forEach(ie), this.h();
    },
    h() {
      st(i, "class", "close-button svelte-1xu9fdw"), st(s, "class", "popup-title svelte-1xu9fdw"), st(t, "class", "popup-content svelte-1xu9fdw"), st(e, "class", "metadata-popup svelte-1xu9fdw"), un(e, "width", typeof /*popup_metadata_width*/
      n[10] == "number" ? `${Math.min(
        /*popup_metadata_width*/
        n[10],
        parseFloat(
          /*maxPopupWidth*/
          n[17]
        )
      )}px` : `min(${/*popup_metadata_width*/
      n[10]}, ${/*maxPopupWidth*/
      n[17]})`), un(e, "height", typeof /*popup_metadata_height*/
      n[11] == "number" ? `${/*popup_metadata_height*/
      n[11]}px` : (
        /*popup_metadata_height*/
        n[11]
      ));
    },
    m(g, E) {
      Ge(g, e, E), Te(e, t), Te(t, i), Te(t, a), Te(t, s), Te(t, l), p.m(t, null), u || (f = Mo(
        i,
        "click",
        /*closePopup*/
        n[22]
      ), u = !0);
    },
    p(g, E) {
      d === (d = h(g, E)) && p ? p.p(g, E) : (p.d(1), p = d(g), p && (p.c(), p.m(t, null))), E[0] & /*popup_metadata_width, maxPopupWidth*/
      132096 && un(e, "width", typeof /*popup_metadata_width*/
      g[10] == "number" ? `${Math.min(
        /*popup_metadata_width*/
        g[10],
        parseFloat(
          /*maxPopupWidth*/
          g[17]
        )
      )}px` : `min(${/*popup_metadata_width*/
      g[10]}, ${/*maxPopupWidth*/
      g[17]})`), E[0] & /*popup_metadata_height*/
      2048 && un(e, "height", typeof /*popup_metadata_height*/
      g[11] == "number" ? `${/*popup_metadata_height*/
      g[11]}px` : (
        /*popup_metadata_height*/
        g[11]
      ));
    },
    d(g) {
      g && ie(e), p.d(), u = !1, f();
    }
  };
}
function $0(n) {
  let e, t = "No custom metadata found.";
  return {
    c() {
      e = He("p"), e.textContent = t, this.h();
    },
    l(i) {
      e = Ue(i, "P", { class: !0, "data-svelte-h": !0 }), ca(e) !== "svelte-1qb2m81" && (e.textContent = t), this.h();
    },
    h() {
      st(e, "class", "no-metadata-message");
    },
    m(i, r) {
      Ge(i, e, r);
    },
    p: th,
    d(i) {
      i && ie(e);
    }
  };
}
function P0(n) {
  let e, t, i, r, a, s = "Load Metadata", o, l, c = Fu(Object.entries(
    /*filteredMetadata*/
    n[18]
  )), u = [];
  for (let f = 0; f < c.length; f += 1)
    u[f] = Lu(Iu(n, c, f));
  return {
    c() {
      e = He("div"), t = He("table"), i = He("tbody");
      for (let f = 0; f < u.length; f += 1)
        u[f].c();
      r = $t(), a = He("button"), a.textContent = s, this.h();
    },
    l(f) {
      e = Ue(f, "DIV", { class: !0 });
      var h = ft(e);
      t = Ue(h, "TABLE", { class: !0 });
      var d = ft(t);
      i = Ue(d, "TBODY", {});
      var p = ft(i);
      for (let g = 0; g < u.length; g += 1)
        u[g].l(p);
      p.forEach(ie), d.forEach(ie), h.forEach(ie), r = It(f), a = Ue(f, "BUTTON", { class: !0, "data-svelte-h": !0 }), ca(a) !== "svelte-1uwkq18" && (a.textContent = s), this.h();
    },
    h() {
      st(t, "class", "metadata-table svelte-1xu9fdw"), st(e, "class", "metadata-table-container svelte-1xu9fdw"), st(a, "class", "load-metadata-button svelte-1xu9fdw");
    },
    m(f, h) {
      Ge(f, e, h), Te(e, t), Te(t, i);
      for (let d = 0; d < u.length; d += 1)
        u[d] && u[d].m(i, null);
      Ge(f, r, h), Ge(f, a, h), o || (l = Mo(
        a,
        "click",
        /*dispatchLoadMetadata*/
        n[21]
      ), o = !0);
    },
    p(f, h) {
      if (h[0] & /*filteredMetadata*/
      262144) {
        c = Fu(Object.entries(
          /*filteredMetadata*/
          f[18]
        ));
        let d;
        for (d = 0; d < c.length; d += 1) {
          const p = Iu(f, c, d);
          u[d] ? u[d].p(p, h) : (u[d] = Lu(p), u[d].c(), u[d].m(i, null));
        }
        for (; d < u.length; d += 1)
          u[d].d(1);
        u.length = c.length;
      }
    },
    d(f) {
      f && (ie(e), ie(r), ie(a)), D0(u, f), o = !1, l();
    }
  };
}
function x0(n) {
  let e, t = (
    /*filteredMetadata*/
    n[18].error + ""
  ), i;
  return {
    c() {
      e = He("p"), i = Zs(t);
    },
    l(r) {
      e = Ue(r, "P", {});
      var a = ft(e);
      i = Xs(a, t), a.forEach(ie);
    },
    m(r, a) {
      Ge(r, e, a), Te(e, i);
    },
    p(r, a) {
      a[0] & /*filteredMetadata*/
      262144 && t !== (t = /*filteredMetadata*/
      r[18].error + "") && Ys(i, t);
    },
    d(r) {
      r && ie(e);
    }
  };
}
function Ru(n) {
  let e, t, i = (
    /*key*/
    n[32] + ""
  ), r, a, s, o = (
    /*val*/
    n[33] + ""
  ), l, c;
  return {
    c() {
      e = He("tr"), t = He("td"), r = Zs(i), a = $t(), s = He("td"), l = Zs(o), c = $t(), this.h();
    },
    l(u) {
      e = Ue(u, "TR", {});
      var f = ft(e);
      t = Ue(f, "TD", { class: !0 });
      var h = ft(t);
      r = Xs(h, i), h.forEach(ie), a = It(f), s = Ue(f, "TD", { class: !0 });
      var d = ft(s);
      l = Xs(d, o), d.forEach(ie), c = It(f), f.forEach(ie), this.h();
    },
    h() {
      st(t, "class", "metadata-label svelte-1xu9fdw"), st(s, "class", "metadata-value svelte-1xu9fdw");
    },
    m(u, f) {
      Ge(u, e, f), Te(e, t), Te(t, r), Te(e, a), Te(e, s), Te(s, l), Te(e, c);
    },
    p(u, f) {
      f[0] & /*filteredMetadata*/
      262144 && i !== (i = /*key*/
      u[32] + "") && Ys(r, i), f[0] & /*filteredMetadata*/
      262144 && o !== (o = /*val*/
      u[33] + "") && Ys(l, o);
    },
    d(u) {
      u && ie(e);
    }
  };
}
function Lu(n) {
  let e, t = (
    /*val*/
    n[33] && Ru(n)
  );
  return {
    c() {
      t && t.c(), e = ci();
    },
    l(i) {
      t && t.l(i), e = ci();
    },
    m(i, r) {
      t && t.m(i, r), Ge(i, e, r);
    },
    p(i, r) {
      /*val*/
      i[33] ? t ? t.p(i, r) : (t = Ru(i), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(i) {
      i && ie(e), t && t.d(i);
    }
  };
}
function B0(n) {
  let e, t, i, r, a, s, o;
  e = new mf({
    props: {
      show_label: (
        /*show_label*/
        n[2]
      ),
      Icon: ko,
      label: /*show_label*/ n[2] ? (
        /*label*/
        n[1] || /*i18n*/
        n[6]("image.image")
      ) : ""
    }
  });
  const l = [A0, k0], c = [];
  function u(h, d) {
    return (
      /*value*/
      h[0] === null || !/*value*/
      h[0].url ? 0 : 1
    );
  }
  i = u(n), r = c[i] = l[i](n);
  let f = (
    /*showMetadataPopup*/
    n[15] && /*filteredMetadata*/
    n[18] !== null && Ou(n)
  );
  return {
    c() {
      qt(e.$$.fragment), t = $t(), r.c(), a = $t(), f && f.c(), s = ci();
    },
    l(h) {
      zt(e.$$.fragment, h), t = It(h), r.l(h), a = It(h), f && f.l(h), s = ci();
    },
    m(h, d) {
      jt(e, h, d), Ge(h, t, d), c[i].m(h, d), Ge(h, a, d), f && f.m(h, d), Ge(h, s, d), o = !0;
    },
    p(h, d) {
      const p = {};
      d[0] & /*show_label*/
      4 && (p.show_label = /*show_label*/
      h[2]), d[0] & /*show_label, label, i18n*/
      70 && (p.label = /*show_label*/
      h[2] ? (
        /*label*/
        h[1] || /*i18n*/
        h[6]("image.image")
      ) : ""), e.$set(p);
      let g = i;
      i = u(h), i === g ? c[i].p(h, d) : (Ri(), we(c[g], 1, 1, () => {
        c[g] = null;
      }), Oi(), r = c[i], r ? r.p(h, d) : (r = c[i] = l[i](h), r.c()), he(r, 1), r.m(a.parentNode, a)), /*showMetadataPopup*/
      h[15] && /*filteredMetadata*/
      h[18] !== null ? f ? f.p(h, d) : (f = Ou(h), f.c(), f.m(s.parentNode, s)) : f && (f.d(1), f = null);
    },
    i(h) {
      o || (he(e.$$.fragment, h), he(r), o = !0);
    },
    o(h) {
      we(e.$$.fragment, h), we(r), o = !1;
    },
    d(h) {
      h && (ie(t), ie(a), ie(s)), Vt(e, h), c[i].d(h), f && f.d(h);
    }
  };
}
function O0(n, e, t) {
  let i, r, { value: a = null } = e, { label: s = void 0 } = e, { show_label: o } = e, { show_download_button: l = !0 } = e, { selectable: c = !1 } = e, { show_share_button: u = !1 } = e, { i18n: f } = e, { show_fullscreen_button: h = !0 } = e, { display_icon_button_wrapper_top_corner: d = !1 } = e, { fullscreen: p = !1 } = e, { only_custom_metadata: g = !0 } = e, { popup_metadata_width: E = 400 } = e, { popup_metadata_height: w = 300 } = e, { height: m = void 0 } = e, { width: _ = void 0 } = e, b = null, y = !1, D;
  const F = S0();
  function x(P) {
    let le = Gf(P);
    le && F("select", { index: le, value: null });
  }
  function T() {
    b !== null && t(15, y = !y);
  }
  function R() {
    b !== null && (F("load_metadata"), O());
  }
  function O() {
    t(15, y = !1);
  }
  function L(P) {
    xr.call(this, n, P);
  }
  const Z = (P) => {
    T(), P.stopPropagation();
  }, z = async (P) => P ? `<img src="${await md(P)}" />` : "";
  function ge(P) {
    xr.call(this, n, P);
  }
  function G(P) {
    xr.call(this, n, P);
  }
  function ve(P) {
    xr.call(this, n, P);
  }
  function q(P) {
    w0[P ? "unshift" : "push"](() => {
      D = P, t(16, D);
    });
  }
  return n.$$set = (P) => {
    "value" in P && t(0, a = P.value), "label" in P && t(1, s = P.label), "show_label" in P && t(2, o = P.show_label), "show_download_button" in P && t(3, l = P.show_download_button), "selectable" in P && t(4, c = P.selectable), "show_share_button" in P && t(5, u = P.show_share_button), "i18n" in P && t(6, f = P.i18n), "show_fullscreen_button" in P && t(7, h = P.show_fullscreen_button), "display_icon_button_wrapper_top_corner" in P && t(8, d = P.display_icon_button_wrapper_top_corner), "fullscreen" in P && t(9, p = P.fullscreen), "only_custom_metadata" in P && t(23, g = P.only_custom_metadata), "popup_metadata_width" in P && t(10, E = P.popup_metadata_width), "popup_metadata_height" in P && t(11, w = P.popup_metadata_height), "height" in P && t(12, m = P.height), "width" in P && t(13, _ = P.width);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*only_custom_metadata, value*/
    8388609 && (async (P) => {
      P ? P.metadata && Object.keys(P.metadata).length > 0 ? t(14, b = P.metadata) : t(14, b = await zf(P, g)) : t(14, b = null);
    })(a), n.$$.dirty[0] & /*only_custom_metadata, metadata*/
    8404992 && t(18, i = g ? Object.fromEntries(Object.entries(b || {}).filter(([P]) => !qf.has(P))) : b), n.$$.dirty[0] & /*width*/
    8192 && t(17, r = typeof _ == "number" ? _ - 20 : typeof _ == "string" ? `calc(${_} - 20px)` : "380px");
  }, [
    a,
    s,
    o,
    l,
    c,
    u,
    f,
    h,
    d,
    p,
    E,
    w,
    m,
    _,
    b,
    y,
    D,
    r,
    i,
    x,
    T,
    R,
    O,
    g,
    L,
    Z,
    z,
    ge,
    G,
    ve,
    q
  ];
}
class R0 extends y0 {
  constructor(e) {
    super(), E0(
      this,
      e,
      O0,
      B0,
      C0,
      {
        value: 0,
        label: 1,
        show_label: 2,
        show_download_button: 3,
        selectable: 4,
        show_share_button: 5,
        i18n: 6,
        show_fullscreen_button: 7,
        display_icon_button_wrapper_top_corner: 8,
        fullscreen: 9,
        only_custom_metadata: 23,
        popup_metadata_width: 10,
        popup_metadata_height: 11,
        height: 12,
        width: 13
      },
      null,
      [-1, -1]
    );
  }
}
new Intl.Collator(0, { numeric: 1 }).compare;
async function L0(n, e) {
  return n.map(
    (t) => new M0({
      path: t.name,
      orig_name: t.name,
      blob: t,
      size: t.size,
      mime_type: t.type,
      is_stream: e
    })
  );
}
class M0 {
  constructor({
    path: e,
    url: t,
    orig_name: i,
    size: r,
    blob: a,
    is_stream: s,
    mime_type: o,
    alt_text: l,
    b64: c
  }) {
    this.meta = { _type: "gradio.FileData" }, this.path = e, this.url = t, this.orig_name = i, this.size = r, this.blob = t ? void 0 : a, this.is_stream = s, this.mime_type = o, this.alt_text = l, this.b64 = c;
  }
}
typeof process < "u" && process.versions && process.versions.node;
var tn;
class C6 extends TransformStream {
  /** Constructs a new instance. */
  constructor(t = { allowCR: !1 }) {
    super({
      transform: (i, r) => {
        for (i = Zn(this, tn) + i; ; ) {
          const a = i.indexOf(`
`), s = t.allowCR ? i.indexOf("\r") : -1;
          if (s !== -1 && s !== i.length - 1 && (a === -1 || a - 1 > s)) {
            r.enqueue(i.slice(0, s)), i = i.slice(s + 1);
            continue;
          }
          if (a === -1)
            break;
          const o = i[a - 1] === "\r" ? a - 1 : a;
          r.enqueue(i.slice(0, o)), i = i.slice(a + 1);
        }
        ol(this, tn, i);
      },
      flush: (i) => {
        if (Zn(this, tn) === "")
          return;
        const r = t.allowCR && Zn(this, tn).endsWith("\r") ? Zn(this, tn).slice(0, -1) : Zn(this, tn);
        i.enqueue(r);
      }
    });
    Na(this, tn, "");
  }
}
tn = new WeakMap();
function kn() {
}
function N0(n) {
  return n();
}
function U0(n) {
  return typeof n == "function";
}
function H0(n, ...e) {
  if (n == null) {
    for (const i of e) i(void 0);
    return kn;
  }
  const t = n.subscribe(...e);
  return t.unsubscribe ? () => t.unsubscribe() : t;
}
const nh = typeof window < "u";
let Mu = nh ? () => window.performance.now() : () => Date.now(), ih = nh ? (n) => requestAnimationFrame(n) : kn;
const oi = /* @__PURE__ */ new Set();
function rh(n) {
  oi.forEach((e) => {
    e.c(n) || (oi.delete(e), e.f());
  }), oi.size !== 0 && ih(rh);
}
function G0(n) {
  let e;
  return oi.size === 0 && ih(rh), { promise: new Promise((t) => {
    oi.add(e = { c: n, f: t });
  }), abort() {
    oi.delete(e);
  } };
}
const ei = [];
function z0(n, e) {
  return { subscribe: ir(n, e).subscribe };
}
function ir(n, e = kn) {
  let t;
  const i = /* @__PURE__ */ new Set();
  function r(s) {
    if (l = s, ((o = n) != o ? l == l : o !== l || o && typeof o == "object" || typeof o == "function") && (n = s, t)) {
      const c = !ei.length;
      for (const u of i) u[1](), ei.push(u, n);
      if (c) {
        for (let u = 0; u < ei.length; u += 2) ei[u][0](ei[u + 1]);
        ei.length = 0;
      }
    }
    var o, l;
  }
  function a(s) {
    r(s(n));
  }
  return { set: r, update: a, subscribe: function(s, o = kn) {
    const l = [s, o];
    return i.add(l), i.size === 1 && (t = e(r, a) || kn), s(n), () => {
      i.delete(l), i.size === 0 && t && (t(), t = null);
    };
  } };
}
function gi(n, e, t) {
  const i = !Array.isArray(n), r = i ? [n] : n;
  if (!r.every(Boolean)) throw new Error("derived() expects stores as input, got a falsy value");
  const a = e.length < 2;
  return z0(t, (s, o) => {
    let l = !1;
    const c = [];
    let u = 0, f = kn;
    const h = () => {
      if (u) return;
      f();
      const p = e(i ? c[0] : c, s, o);
      a ? s(p) : f = U0(p) ? p : kn;
    }, d = r.map((p, g) => H0(p, (E) => {
      c[g] = E, u &= ~(1 << g), l && h();
    }, () => {
      u |= 1 << g;
    }));
    return l = !0, h(), function() {
      d.forEach(N0), f(), l = !1;
    };
  });
}
function Nu(n) {
  return Object.prototype.toString.call(n) === "[object Date]";
}
function Ks(n, e, t, i) {
  if (typeof t == "number" || Nu(t)) {
    const r = i - t, a = (t - e) / (n.dt || 1 / 60), s = (a + (n.opts.stiffness * r - n.opts.damping * a) * n.inv_mass) * n.dt;
    return Math.abs(s) < n.opts.precision && Math.abs(r) < n.opts.precision ? i : (n.settled = !1, Nu(t) ? new Date(t.getTime() + s) : t + s);
  }
  if (Array.isArray(t)) return t.map((r, a) => Ks(n, e[a], t[a], i[a]));
  if (typeof t == "object") {
    const r = {};
    for (const a in t) r[a] = Ks(n, e[a], t[a], i[a]);
    return r;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function Uu(n, e = {}) {
  const t = ir(n), { stiffness: i = 0.15, damping: r = 0.8, precision: a = 0.01 } = e;
  let s, o, l, c = n, u = n, f = 1, h = 0, d = !1;
  function p(E, w = {}) {
    u = E;
    const m = l = {};
    return n == null || w.hard || g.stiffness >= 1 && g.damping >= 1 ? (d = !0, s = Mu(), c = E, t.set(n = u), Promise.resolve()) : (w.soft && (h = 1 / (60 * (w.soft === !0 ? 0.5 : +w.soft)), f = 0), o || (s = Mu(), d = !1, o = G0((_) => {
      if (d) return d = !1, o = null, !1;
      f = Math.min(f + h, 1);
      const b = { inv_mass: f, opts: g, settled: !0, dt: 60 * (_ - s) / 1e3 }, y = Ks(b, c, n, u);
      return s = _, c = n, t.set(n = y), b.settled && (o = null), !b.settled;
    })), new Promise((_) => {
      o.promise.then(() => {
        m === l && _();
      });
    }));
  }
  const g = { set: p, update: (E, w) => p(E(u, n), w), subscribe: t.subscribe, stiffness: i, damping: r, precision: a };
  return g;
}
function q0(n) {
  return V0(n) && !j0(n);
}
function V0(n) {
  return !!n && typeof n == "object";
}
function j0(n) {
  var e = Object.prototype.toString.call(n);
  return e === "[object RegExp]" || e === "[object Date]" || Y0(n);
}
var W0 = typeof Symbol == "function" && Symbol.for, X0 = W0 ? Symbol.for("react.element") : 60103;
function Y0(n) {
  return n.$$typeof === X0;
}
var Z0 = q0;
function K0(n) {
  return Array.isArray(n) ? [] : {};
}
function Zi(n, e) {
  return e.clone !== !1 && e.isMergeableObject(n) ? fi(K0(n), n, e) : n;
}
function J0(n, e, t) {
  return n.concat(e).map(function(i) {
    return Zi(i, t);
  });
}
function Q0(n, e) {
  if (!e.customMerge)
    return fi;
  var t = e.customMerge(n);
  return typeof t == "function" ? t : fi;
}
function e1(n) {
  return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(n).filter(function(e) {
    return Object.propertyIsEnumerable.call(n, e);
  }) : [];
}
function Hu(n) {
  return Object.keys(n).concat(e1(n));
}
function ah(n, e) {
  try {
    return e in n;
  } catch {
    return !1;
  }
}
function t1(n, e) {
  return ah(n, e) && !(Object.hasOwnProperty.call(n, e) && Object.propertyIsEnumerable.call(n, e));
}
function n1(n, e, t) {
  var i = {};
  return t.isMergeableObject(n) && Hu(n).forEach(function(r) {
    i[r] = Zi(n[r], t);
  }), Hu(e).forEach(function(r) {
    t1(n, r) || (ah(n, r) && t.isMergeableObject(e[r]) ? i[r] = Q0(r, t)(n[r], e[r], t) : i[r] = Zi(e[r], t));
  }), i;
}
function fi(n, e, t) {
  t = t || {}, t.arrayMerge = t.arrayMerge || J0, t.isMergeableObject = t.isMergeableObject || Z0, t.cloneUnlessOtherwiseSpecified = Zi;
  var i = Array.isArray(e), r = Array.isArray(n), a = i === r;
  return a ? i ? t.arrayMerge(n, e, t) : n1(n, e, t) : Zi(e, t);
}
fi.all = function(e, t) {
  if (!Array.isArray(e))
    throw new Error("first argument should be an array");
  return e.reduce(function(i, r) {
    return fi(i, r, t);
  }, {});
};
var Js = function(n, e) {
  return Js = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(t, i) {
    t.__proto__ = i;
  } || function(t, i) {
    for (var r in i) Object.prototype.hasOwnProperty.call(i, r) && (t[r] = i[r]);
  }, Js(n, e);
};
function ka(n, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
  Js(n, e);
  function t() {
    this.constructor = n;
  }
  n.prototype = e === null ? Object.create(e) : (t.prototype = e.prototype, new t());
}
var Q = function() {
  return Q = Object.assign || function(e) {
    for (var t, i = 1, r = arguments.length; i < r; i++) {
      t = arguments[i];
      for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Q.apply(this, arguments);
};
function bs(n, e, t) {
  if (t || arguments.length === 2) for (var i = 0, r = e.length, a; i < r; i++)
    (a || !(i in e)) && (a || (a = Array.prototype.slice.call(e, 0, i)), a[i] = e[i]);
  return n.concat(a || Array.prototype.slice.call(e));
}
var W;
(function(n) {
  n[n.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", n[n.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", n[n.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", n[n.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", n[n.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", n[n.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", n[n.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", n[n.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", n[n.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", n[n.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", n[n.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", n[n.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", n[n.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", n[n.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", n[n.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", n[n.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", n[n.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", n[n.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", n[n.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", n[n.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", n[n.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", n[n.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", n[n.INVALID_TAG = 23] = "INVALID_TAG", n[n.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", n[n.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", n[n.UNCLOSED_TAG = 27] = "UNCLOSED_TAG";
})(W || (W = {}));
var fe;
(function(n) {
  n[n.literal = 0] = "literal", n[n.argument = 1] = "argument", n[n.number = 2] = "number", n[n.date = 3] = "date", n[n.time = 4] = "time", n[n.select = 5] = "select", n[n.plural = 6] = "plural", n[n.pound = 7] = "pound", n[n.tag = 8] = "tag";
})(fe || (fe = {}));
var hi;
(function(n) {
  n[n.number = 0] = "number", n[n.dateTime = 1] = "dateTime";
})(hi || (hi = {}));
function Gu(n) {
  return n.type === fe.literal;
}
function i1(n) {
  return n.type === fe.argument;
}
function sh(n) {
  return n.type === fe.number;
}
function oh(n) {
  return n.type === fe.date;
}
function lh(n) {
  return n.type === fe.time;
}
function uh(n) {
  return n.type === fe.select;
}
function ch(n) {
  return n.type === fe.plural;
}
function r1(n) {
  return n.type === fe.pound;
}
function fh(n) {
  return n.type === fe.tag;
}
function hh(n) {
  return !!(n && typeof n == "object" && n.type === hi.number);
}
function Qs(n) {
  return !!(n && typeof n == "object" && n.type === hi.dateTime);
}
var dh = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, a1 = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
function s1(n) {
  var e = {};
  return n.replace(a1, function(t) {
    var i = t.length;
    switch (t[0]) {
      case "G":
        e.era = i === 4 ? "long" : i === 5 ? "narrow" : "short";
        break;
      case "y":
        e.year = i === 2 ? "2-digit" : "numeric";
        break;
      case "Y":
      case "u":
      case "U":
      case "r":
        throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
      case "q":
      case "Q":
        throw new RangeError("`q/Q` (quarter) patterns are not supported");
      case "M":
      case "L":
        e.month = ["numeric", "2-digit", "short", "long", "narrow"][i - 1];
        break;
      case "w":
      case "W":
        throw new RangeError("`w/W` (week) patterns are not supported");
      case "d":
        e.day = ["numeric", "2-digit"][i - 1];
        break;
      case "D":
      case "F":
      case "g":
        throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
      case "E":
        e.weekday = i === 4 ? "short" : i === 5 ? "narrow" : "short";
        break;
      case "e":
        if (i < 4)
          throw new RangeError("`e..eee` (weekday) patterns are not supported");
        e.weekday = ["short", "long", "narrow", "short"][i - 4];
        break;
      case "c":
        if (i < 4)
          throw new RangeError("`c..ccc` (weekday) patterns are not supported");
        e.weekday = ["short", "long", "narrow", "short"][i - 4];
        break;
      case "a":
        e.hour12 = !0;
        break;
      case "b":
      case "B":
        throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
      case "h":
        e.hourCycle = "h12", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "H":
        e.hourCycle = "h23", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "K":
        e.hourCycle = "h11", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "k":
        e.hourCycle = "h24", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "j":
      case "J":
      case "C":
        throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
      case "m":
        e.minute = ["numeric", "2-digit"][i - 1];
        break;
      case "s":
        e.second = ["numeric", "2-digit"][i - 1];
        break;
      case "S":
      case "A":
        throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
      case "z":
        e.timeZoneName = i < 4 ? "short" : "long";
        break;
      case "Z":
      case "O":
      case "v":
      case "V":
      case "X":
      case "x":
        throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
    }
    return "";
  }), e;
}
var o1 = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
function l1(n) {
  if (n.length === 0)
    throw new Error("Number skeleton cannot be empty");
  for (var e = n.split(o1).filter(function(h) {
    return h.length > 0;
  }), t = [], i = 0, r = e; i < r.length; i++) {
    var a = r[i], s = a.split("/");
    if (s.length === 0)
      throw new Error("Invalid number skeleton");
    for (var o = s[0], l = s.slice(1), c = 0, u = l; c < u.length; c++) {
      var f = u[c];
      if (f.length === 0)
        throw new Error("Invalid number skeleton");
    }
    t.push({ stem: o, options: l });
  }
  return t;
}
function u1(n) {
  return n.replace(/^(.*?)-/, "");
}
var zu = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, _h = /^(@+)?(\+|#+)?[rs]?$/g, c1 = /(\*)(0+)|(#+)(0+)|(0+)/g, ph = /^(0+)$/;
function qu(n) {
  var e = {};
  return n[n.length - 1] === "r" ? e.roundingPriority = "morePrecision" : n[n.length - 1] === "s" && (e.roundingPriority = "lessPrecision"), n.replace(_h, function(t, i, r) {
    return typeof r != "string" ? (e.minimumSignificantDigits = i.length, e.maximumSignificantDigits = i.length) : r === "+" ? e.minimumSignificantDigits = i.length : i[0] === "#" ? e.maximumSignificantDigits = i.length : (e.minimumSignificantDigits = i.length, e.maximumSignificantDigits = i.length + (typeof r == "string" ? r.length : 0)), "";
  }), e;
}
function mh(n) {
  switch (n) {
    case "sign-auto":
      return {
        signDisplay: "auto"
      };
    case "sign-accounting":
    case "()":
      return {
        currencySign: "accounting"
      };
    case "sign-always":
    case "+!":
      return {
        signDisplay: "always"
      };
    case "sign-accounting-always":
    case "()!":
      return {
        signDisplay: "always",
        currencySign: "accounting"
      };
    case "sign-except-zero":
    case "+?":
      return {
        signDisplay: "exceptZero"
      };
    case "sign-accounting-except-zero":
    case "()?":
      return {
        signDisplay: "exceptZero",
        currencySign: "accounting"
      };
    case "sign-never":
    case "+_":
      return {
        signDisplay: "never"
      };
  }
}
function f1(n) {
  var e;
  if (n[0] === "E" && n[1] === "E" ? (e = {
    notation: "engineering"
  }, n = n.slice(2)) : n[0] === "E" && (e = {
    notation: "scientific"
  }, n = n.slice(1)), e) {
    var t = n.slice(0, 2);
    if (t === "+!" ? (e.signDisplay = "always", n = n.slice(2)) : t === "+?" && (e.signDisplay = "exceptZero", n = n.slice(2)), !ph.test(n))
      throw new Error("Malformed concise eng/scientific notation");
    e.minimumIntegerDigits = n.length;
  }
  return e;
}
function Vu(n) {
  var e = {}, t = mh(n);
  return t || e;
}
function h1(n) {
  for (var e = {}, t = 0, i = n; t < i.length; t++) {
    var r = i[t];
    switch (r.stem) {
      case "percent":
      case "%":
        e.style = "percent";
        continue;
      case "%x100":
        e.style = "percent", e.scale = 100;
        continue;
      case "currency":
        e.style = "currency", e.currency = r.options[0];
        continue;
      case "group-off":
      case ",_":
        e.useGrouping = !1;
        continue;
      case "precision-integer":
      case ".":
        e.maximumFractionDigits = 0;
        continue;
      case "measure-unit":
      case "unit":
        e.style = "unit", e.unit = u1(r.options[0]);
        continue;
      case "compact-short":
      case "K":
        e.notation = "compact", e.compactDisplay = "short";
        continue;
      case "compact-long":
      case "KK":
        e.notation = "compact", e.compactDisplay = "long";
        continue;
      case "scientific":
        e = Q(Q(Q({}, e), { notation: "scientific" }), r.options.reduce(function(l, c) {
          return Q(Q({}, l), Vu(c));
        }, {}));
        continue;
      case "engineering":
        e = Q(Q(Q({}, e), { notation: "engineering" }), r.options.reduce(function(l, c) {
          return Q(Q({}, l), Vu(c));
        }, {}));
        continue;
      case "notation-simple":
        e.notation = "standard";
        continue;
      case "unit-width-narrow":
        e.currencyDisplay = "narrowSymbol", e.unitDisplay = "narrow";
        continue;
      case "unit-width-short":
        e.currencyDisplay = "code", e.unitDisplay = "short";
        continue;
      case "unit-width-full-name":
        e.currencyDisplay = "name", e.unitDisplay = "long";
        continue;
      case "unit-width-iso-code":
        e.currencyDisplay = "symbol";
        continue;
      case "scale":
        e.scale = parseFloat(r.options[0]);
        continue;
      case "integer-width":
        if (r.options.length > 1)
          throw new RangeError("integer-width stems only accept a single optional option");
        r.options[0].replace(c1, function(l, c, u, f, h, d) {
          if (c)
            e.minimumIntegerDigits = u.length;
          else {
            if (f && h)
              throw new Error("We currently do not support maximum integer digits");
            if (d)
              throw new Error("We currently do not support exact integer digits");
          }
          return "";
        });
        continue;
    }
    if (ph.test(r.stem)) {
      e.minimumIntegerDigits = r.stem.length;
      continue;
    }
    if (zu.test(r.stem)) {
      if (r.options.length > 1)
        throw new RangeError("Fraction-precision stems only accept a single optional option");
      r.stem.replace(zu, function(l, c, u, f, h, d) {
        return u === "*" ? e.minimumFractionDigits = c.length : f && f[0] === "#" ? e.maximumFractionDigits = f.length : h && d ? (e.minimumFractionDigits = h.length, e.maximumFractionDigits = h.length + d.length) : (e.minimumFractionDigits = c.length, e.maximumFractionDigits = c.length), "";
      });
      var a = r.options[0];
      a === "w" ? e = Q(Q({}, e), { trailingZeroDisplay: "stripIfInteger" }) : a && (e = Q(Q({}, e), qu(a)));
      continue;
    }
    if (_h.test(r.stem)) {
      e = Q(Q({}, e), qu(r.stem));
      continue;
    }
    var s = mh(r.stem);
    s && (e = Q(Q({}, e), s));
    var o = f1(r.stem);
    o && (e = Q(Q({}, e), o));
  }
  return e;
}
var Br = {
  AX: [
    "H"
  ],
  BQ: [
    "H"
  ],
  CP: [
    "H"
  ],
  CZ: [
    "H"
  ],
  DK: [
    "H"
  ],
  FI: [
    "H"
  ],
  ID: [
    "H"
  ],
  IS: [
    "H"
  ],
  ML: [
    "H"
  ],
  NE: [
    "H"
  ],
  RU: [
    "H"
  ],
  SE: [
    "H"
  ],
  SJ: [
    "H"
  ],
  SK: [
    "H"
  ],
  AS: [
    "h",
    "H"
  ],
  BT: [
    "h",
    "H"
  ],
  DJ: [
    "h",
    "H"
  ],
  ER: [
    "h",
    "H"
  ],
  GH: [
    "h",
    "H"
  ],
  IN: [
    "h",
    "H"
  ],
  LS: [
    "h",
    "H"
  ],
  PG: [
    "h",
    "H"
  ],
  PW: [
    "h",
    "H"
  ],
  SO: [
    "h",
    "H"
  ],
  TO: [
    "h",
    "H"
  ],
  VU: [
    "h",
    "H"
  ],
  WS: [
    "h",
    "H"
  ],
  "001": [
    "H",
    "h"
  ],
  AL: [
    "h",
    "H",
    "hB"
  ],
  TD: [
    "h",
    "H",
    "hB"
  ],
  "ca-ES": [
    "H",
    "h",
    "hB"
  ],
  CF: [
    "H",
    "h",
    "hB"
  ],
  CM: [
    "H",
    "h",
    "hB"
  ],
  "fr-CA": [
    "H",
    "h",
    "hB"
  ],
  "gl-ES": [
    "H",
    "h",
    "hB"
  ],
  "it-CH": [
    "H",
    "h",
    "hB"
  ],
  "it-IT": [
    "H",
    "h",
    "hB"
  ],
  LU: [
    "H",
    "h",
    "hB"
  ],
  NP: [
    "H",
    "h",
    "hB"
  ],
  PF: [
    "H",
    "h",
    "hB"
  ],
  SC: [
    "H",
    "h",
    "hB"
  ],
  SM: [
    "H",
    "h",
    "hB"
  ],
  SN: [
    "H",
    "h",
    "hB"
  ],
  TF: [
    "H",
    "h",
    "hB"
  ],
  VA: [
    "H",
    "h",
    "hB"
  ],
  CY: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  GR: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  CO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  DO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KP: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  VE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BW: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BZ: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  DG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  FK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GB: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IM: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IO: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  JE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  LT: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MS: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NF: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NR: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NU: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  PN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SH: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  TA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ZA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  "af-ZA": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  AR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CL: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CU: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  EA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BO": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BR": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-EC": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-ES": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-GQ": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-PE": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  GT: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  HN: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  IC: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KG: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KM: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  LK: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MX: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  NI: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  PY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  SV: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  UY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  JP: [
    "H",
    "h",
    "K"
  ],
  AD: [
    "H",
    "hB"
  ],
  AM: [
    "H",
    "hB"
  ],
  AO: [
    "H",
    "hB"
  ],
  AT: [
    "H",
    "hB"
  ],
  AW: [
    "H",
    "hB"
  ],
  BE: [
    "H",
    "hB"
  ],
  BF: [
    "H",
    "hB"
  ],
  BJ: [
    "H",
    "hB"
  ],
  BL: [
    "H",
    "hB"
  ],
  BR: [
    "H",
    "hB"
  ],
  CG: [
    "H",
    "hB"
  ],
  CI: [
    "H",
    "hB"
  ],
  CV: [
    "H",
    "hB"
  ],
  DE: [
    "H",
    "hB"
  ],
  EE: [
    "H",
    "hB"
  ],
  FR: [
    "H",
    "hB"
  ],
  GA: [
    "H",
    "hB"
  ],
  GF: [
    "H",
    "hB"
  ],
  GN: [
    "H",
    "hB"
  ],
  GP: [
    "H",
    "hB"
  ],
  GW: [
    "H",
    "hB"
  ],
  HR: [
    "H",
    "hB"
  ],
  IL: [
    "H",
    "hB"
  ],
  IT: [
    "H",
    "hB"
  ],
  KZ: [
    "H",
    "hB"
  ],
  MC: [
    "H",
    "hB"
  ],
  MD: [
    "H",
    "hB"
  ],
  MF: [
    "H",
    "hB"
  ],
  MQ: [
    "H",
    "hB"
  ],
  MZ: [
    "H",
    "hB"
  ],
  NC: [
    "H",
    "hB"
  ],
  NL: [
    "H",
    "hB"
  ],
  PM: [
    "H",
    "hB"
  ],
  PT: [
    "H",
    "hB"
  ],
  RE: [
    "H",
    "hB"
  ],
  RO: [
    "H",
    "hB"
  ],
  SI: [
    "H",
    "hB"
  ],
  SR: [
    "H",
    "hB"
  ],
  ST: [
    "H",
    "hB"
  ],
  TG: [
    "H",
    "hB"
  ],
  TR: [
    "H",
    "hB"
  ],
  WF: [
    "H",
    "hB"
  ],
  YT: [
    "H",
    "hB"
  ],
  BD: [
    "h",
    "hB",
    "H"
  ],
  PK: [
    "h",
    "hB",
    "H"
  ],
  AZ: [
    "H",
    "hB",
    "h"
  ],
  BA: [
    "H",
    "hB",
    "h"
  ],
  BG: [
    "H",
    "hB",
    "h"
  ],
  CH: [
    "H",
    "hB",
    "h"
  ],
  GE: [
    "H",
    "hB",
    "h"
  ],
  LI: [
    "H",
    "hB",
    "h"
  ],
  ME: [
    "H",
    "hB",
    "h"
  ],
  RS: [
    "H",
    "hB",
    "h"
  ],
  UA: [
    "H",
    "hB",
    "h"
  ],
  UZ: [
    "H",
    "hB",
    "h"
  ],
  XK: [
    "H",
    "hB",
    "h"
  ],
  AG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  CA: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  DM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-001": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FJ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GD: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  JM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KN: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LR: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MH: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MP: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MW: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  NZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SL: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TT: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  UM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  US: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ZM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BO: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  EC: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  ES: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  GQ: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  PE: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  AE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  "ar-001": [
    "h",
    "hB",
    "hb",
    "H"
  ],
  BH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  DZ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EG: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  HK: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  IQ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  JO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  KW: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LB: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MR: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  OM: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PS: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  QA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SD: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  TN: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  YE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  AF: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  LA: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  CN: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  LV: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  TL: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  "zu-ZA": [
    "H",
    "hB",
    "hb",
    "h"
  ],
  CD: [
    "hB",
    "H"
  ],
  IR: [
    "hB",
    "H"
  ],
  "hi-IN": [
    "hB",
    "h",
    "H"
  ],
  "kn-IN": [
    "hB",
    "h",
    "H"
  ],
  "ml-IN": [
    "hB",
    "h",
    "H"
  ],
  "te-IN": [
    "hB",
    "h",
    "H"
  ],
  KH: [
    "hB",
    "h",
    "H",
    "hb"
  ],
  "ta-IN": [
    "hB",
    "h",
    "hb",
    "H"
  ],
  BN: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  MY: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  ET: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "gu-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "mr-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "pa-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  TW: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  KE: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  MM: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  TZ: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UG: [
    "hB",
    "hb",
    "H",
    "h"
  ]
};
function d1(n, e) {
  for (var t = "", i = 0; i < n.length; i++) {
    var r = n.charAt(i);
    if (r === "j") {
      for (var a = 0; i + 1 < n.length && n.charAt(i + 1) === r; )
        a++, i++;
      var s = 1 + (a & 1), o = a < 2 ? 1 : 3 + (a >> 1), l = "a", c = _1(e);
      for ((c == "H" || c == "k") && (o = 0); o-- > 0; )
        t += l;
      for (; s-- > 0; )
        t = c + t;
    } else r === "J" ? t += "H" : t += r;
  }
  return t;
}
function _1(n) {
  var e = n.hourCycle;
  if (e === void 0 && // @ts-ignore hourCycle(s) is not identified yet
  n.hourCycles && // @ts-ignore
  n.hourCycles.length && (e = n.hourCycles[0]), e)
    switch (e) {
      case "h24":
        return "k";
      case "h23":
        return "H";
      case "h12":
        return "h";
      case "h11":
        return "K";
      default:
        throw new Error("Invalid hourCycle");
    }
  var t = n.language, i;
  t !== "root" && (i = n.maximize().region);
  var r = Br[i || ""] || Br[t || ""] || Br["".concat(t, "-001")] || Br["001"];
  return r[0];
}
var vs, p1 = new RegExp("^".concat(dh.source, "*")), m1 = new RegExp("".concat(dh.source, "*$"));
function X(n, e) {
  return { start: n, end: e };
}
var g1 = !!String.prototype.startsWith, b1 = !!String.fromCodePoint, v1 = !!Object.fromEntries, y1 = !!String.prototype.codePointAt, w1 = !!String.prototype.trimStart, D1 = !!String.prototype.trimEnd, E1 = !!Number.isSafeInteger, C1 = E1 ? Number.isSafeInteger : function(n) {
  return typeof n == "number" && isFinite(n) && Math.floor(n) === n && Math.abs(n) <= 9007199254740991;
}, eo = !0;
try {
  var S1 = bh("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  eo = ((vs = S1.exec("a")) === null || vs === void 0 ? void 0 : vs[0]) === "a";
} catch {
  eo = !1;
}
var ju = g1 ? (
  // Native
  function(e, t, i) {
    return e.startsWith(t, i);
  }
) : (
  // For IE11
  function(e, t, i) {
    return e.slice(i, i + t.length) === t;
  }
), to = b1 ? String.fromCodePoint : (
  // IE11
  function() {
    for (var e = [], t = 0; t < arguments.length; t++)
      e[t] = arguments[t];
    for (var i = "", r = e.length, a = 0, s; r > a; ) {
      if (s = e[a++], s > 1114111)
        throw RangeError(s + " is not a valid code point");
      i += s < 65536 ? String.fromCharCode(s) : String.fromCharCode(((s -= 65536) >> 10) + 55296, s % 1024 + 56320);
    }
    return i;
  }
), Wu = (
  // native
  v1 ? Object.fromEntries : (
    // Ponyfill
    function(e) {
      for (var t = {}, i = 0, r = e; i < r.length; i++) {
        var a = r[i], s = a[0], o = a[1];
        t[s] = o;
      }
      return t;
    }
  )
), gh = y1 ? (
  // Native
  function(e, t) {
    return e.codePointAt(t);
  }
) : (
  // IE 11
  function(e, t) {
    var i = e.length;
    if (!(t < 0 || t >= i)) {
      var r = e.charCodeAt(t), a;
      return r < 55296 || r > 56319 || t + 1 === i || (a = e.charCodeAt(t + 1)) < 56320 || a > 57343 ? r : (r - 55296 << 10) + (a - 56320) + 65536;
    }
  }
), k1 = w1 ? (
  // Native
  function(e) {
    return e.trimStart();
  }
) : (
  // Ponyfill
  function(e) {
    return e.replace(p1, "");
  }
), A1 = D1 ? (
  // Native
  function(e) {
    return e.trimEnd();
  }
) : (
  // Ponyfill
  function(e) {
    return e.replace(m1, "");
  }
);
function bh(n, e) {
  return new RegExp(n, e);
}
var no;
if (eo) {
  var Xu = bh("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  no = function(e, t) {
    var i;
    Xu.lastIndex = t;
    var r = Xu.exec(e);
    return (i = r[1]) !== null && i !== void 0 ? i : "";
  };
} else
  no = function(e, t) {
    for (var i = []; ; ) {
      var r = gh(e, t);
      if (r === void 0 || vh(r) || $1(r))
        break;
      i.push(r), t += r >= 65536 ? 2 : 1;
    }
    return to.apply(void 0, i);
  };
var F1 = (
  /** @class */
  function() {
    function n(e, t) {
      t === void 0 && (t = {}), this.message = e, this.position = { offset: 0, line: 1, column: 1 }, this.ignoreTag = !!t.ignoreTag, this.locale = t.locale, this.requiresOtherClause = !!t.requiresOtherClause, this.shouldParseSkeletons = !!t.shouldParseSkeletons;
    }
    return n.prototype.parse = function() {
      if (this.offset() !== 0)
        throw Error("parser can only be used once");
      return this.parseMessage(0, "", !1);
    }, n.prototype.parseMessage = function(e, t, i) {
      for (var r = []; !this.isEOF(); ) {
        var a = this.char();
        if (a === 123) {
          var s = this.parseArgument(e, i);
          if (s.err)
            return s;
          r.push(s.val);
        } else {
          if (a === 125 && e > 0)
            break;
          if (a === 35 && (t === "plural" || t === "selectordinal")) {
            var o = this.clonePosition();
            this.bump(), r.push({
              type: fe.pound,
              location: X(o, this.clonePosition())
            });
          } else if (a === 60 && !this.ignoreTag && this.peek() === 47) {
            if (i)
              break;
            return this.error(W.UNMATCHED_CLOSING_TAG, X(this.clonePosition(), this.clonePosition()));
          } else if (a === 60 && !this.ignoreTag && io(this.peek() || 0)) {
            var s = this.parseTag(e, t);
            if (s.err)
              return s;
            r.push(s.val);
          } else {
            var s = this.parseLiteral(e, t);
            if (s.err)
              return s;
            r.push(s.val);
          }
        }
      }
      return { val: r, err: null };
    }, n.prototype.parseTag = function(e, t) {
      var i = this.clonePosition();
      this.bump();
      var r = this.parseTagName();
      if (this.bumpSpace(), this.bumpIf("/>"))
        return {
          val: {
            type: fe.literal,
            value: "<".concat(r, "/>"),
            location: X(i, this.clonePosition())
          },
          err: null
        };
      if (this.bumpIf(">")) {
        var a = this.parseMessage(e + 1, t, !0);
        if (a.err)
          return a;
        var s = a.val, o = this.clonePosition();
        if (this.bumpIf("</")) {
          if (this.isEOF() || !io(this.char()))
            return this.error(W.INVALID_TAG, X(o, this.clonePosition()));
          var l = this.clonePosition(), c = this.parseTagName();
          return r !== c ? this.error(W.UNMATCHED_CLOSING_TAG, X(l, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
            val: {
              type: fe.tag,
              value: r,
              children: s,
              location: X(i, this.clonePosition())
            },
            err: null
          } : this.error(W.INVALID_TAG, X(o, this.clonePosition())));
        } else
          return this.error(W.UNCLOSED_TAG, X(i, this.clonePosition()));
      } else
        return this.error(W.INVALID_TAG, X(i, this.clonePosition()));
    }, n.prototype.parseTagName = function() {
      var e = this.offset();
      for (this.bump(); !this.isEOF() && I1(this.char()); )
        this.bump();
      return this.message.slice(e, this.offset());
    }, n.prototype.parseLiteral = function(e, t) {
      for (var i = this.clonePosition(), r = ""; ; ) {
        var a = this.tryParseQuote(t);
        if (a) {
          r += a;
          continue;
        }
        var s = this.tryParseUnquoted(e, t);
        if (s) {
          r += s;
          continue;
        }
        var o = this.tryParseLeftAngleBracket();
        if (o) {
          r += o;
          continue;
        }
        break;
      }
      var l = X(i, this.clonePosition());
      return {
        val: { type: fe.literal, value: r, location: l },
        err: null
      };
    }, n.prototype.tryParseLeftAngleBracket = function() {
      return !this.isEOF() && this.char() === 60 && (this.ignoreTag || // If at the opening tag or closing tag position, bail.
      !T1(this.peek() || 0)) ? (this.bump(), "<") : null;
    }, n.prototype.tryParseQuote = function(e) {
      if (this.isEOF() || this.char() !== 39)
        return null;
      switch (this.peek()) {
        case 39:
          return this.bump(), this.bump(), "'";
        case 123:
        case 60:
        case 62:
        case 125:
          break;
        case 35:
          if (e === "plural" || e === "selectordinal")
            break;
          return null;
        default:
          return null;
      }
      this.bump();
      var t = [this.char()];
      for (this.bump(); !this.isEOF(); ) {
        var i = this.char();
        if (i === 39)
          if (this.peek() === 39)
            t.push(39), this.bump();
          else {
            this.bump();
            break;
          }
        else
          t.push(i);
        this.bump();
      }
      return to.apply(void 0, t);
    }, n.prototype.tryParseUnquoted = function(e, t) {
      if (this.isEOF())
        return null;
      var i = this.char();
      return i === 60 || i === 123 || i === 35 && (t === "plural" || t === "selectordinal") || i === 125 && e > 0 ? null : (this.bump(), to(i));
    }, n.prototype.parseArgument = function(e, t) {
      var i = this.clonePosition();
      if (this.bump(), this.bumpSpace(), this.isEOF())
        return this.error(W.EXPECT_ARGUMENT_CLOSING_BRACE, X(i, this.clonePosition()));
      if (this.char() === 125)
        return this.bump(), this.error(W.EMPTY_ARGUMENT, X(i, this.clonePosition()));
      var r = this.parseIdentifierIfPossible().value;
      if (!r)
        return this.error(W.MALFORMED_ARGUMENT, X(i, this.clonePosition()));
      if (this.bumpSpace(), this.isEOF())
        return this.error(W.EXPECT_ARGUMENT_CLOSING_BRACE, X(i, this.clonePosition()));
      switch (this.char()) {
        case 125:
          return this.bump(), {
            val: {
              type: fe.argument,
              // value does not include the opening and closing braces.
              value: r,
              location: X(i, this.clonePosition())
            },
            err: null
          };
        case 44:
          return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(W.EXPECT_ARGUMENT_CLOSING_BRACE, X(i, this.clonePosition())) : this.parseArgumentOptions(e, t, r, i);
        default:
          return this.error(W.MALFORMED_ARGUMENT, X(i, this.clonePosition()));
      }
    }, n.prototype.parseIdentifierIfPossible = function() {
      var e = this.clonePosition(), t = this.offset(), i = no(this.message, t), r = t + i.length;
      this.bumpTo(r);
      var a = this.clonePosition(), s = X(e, a);
      return { value: i, location: s };
    }, n.prototype.parseArgumentOptions = function(e, t, i, r) {
      var a, s = this.clonePosition(), o = this.parseIdentifierIfPossible().value, l = this.clonePosition();
      switch (o) {
        case "":
          return this.error(W.EXPECT_ARGUMENT_TYPE, X(s, l));
        case "number":
        case "date":
        case "time": {
          this.bumpSpace();
          var c = null;
          if (this.bumpIf(",")) {
            this.bumpSpace();
            var u = this.clonePosition(), f = this.parseSimpleArgStyleIfPossible();
            if (f.err)
              return f;
            var h = A1(f.val);
            if (h.length === 0)
              return this.error(W.EXPECT_ARGUMENT_STYLE, X(this.clonePosition(), this.clonePosition()));
            var d = X(u, this.clonePosition());
            c = { style: h, styleLocation: d };
          }
          var p = this.tryParseArgumentClose(r);
          if (p.err)
            return p;
          var g = X(r, this.clonePosition());
          if (c && ju(c == null ? void 0 : c.style, "::", 0)) {
            var E = k1(c.style.slice(2));
            if (o === "number") {
              var f = this.parseNumberSkeletonFromString(E, c.styleLocation);
              return f.err ? f : {
                val: { type: fe.number, value: i, location: g, style: f.val },
                err: null
              };
            } else {
              if (E.length === 0)
                return this.error(W.EXPECT_DATE_TIME_SKELETON, g);
              var w = E;
              this.locale && (w = d1(E, this.locale));
              var h = {
                type: hi.dateTime,
                pattern: w,
                location: c.styleLocation,
                parsedOptions: this.shouldParseSkeletons ? s1(w) : {}
              }, m = o === "date" ? fe.date : fe.time;
              return {
                val: { type: m, value: i, location: g, style: h },
                err: null
              };
            }
          }
          return {
            val: {
              type: o === "number" ? fe.number : o === "date" ? fe.date : fe.time,
              value: i,
              location: g,
              style: (a = c == null ? void 0 : c.style) !== null && a !== void 0 ? a : null
            },
            err: null
          };
        }
        case "plural":
        case "selectordinal":
        case "select": {
          var _ = this.clonePosition();
          if (this.bumpSpace(), !this.bumpIf(","))
            return this.error(W.EXPECT_SELECT_ARGUMENT_OPTIONS, X(_, Q({}, _)));
          this.bumpSpace();
          var b = this.parseIdentifierIfPossible(), y = 0;
          if (o !== "select" && b.value === "offset") {
            if (!this.bumpIf(":"))
              return this.error(W.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, X(this.clonePosition(), this.clonePosition()));
            this.bumpSpace();
            var f = this.tryParseDecimalInteger(W.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, W.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE);
            if (f.err)
              return f;
            this.bumpSpace(), b = this.parseIdentifierIfPossible(), y = f.val;
          }
          var D = this.tryParsePluralOrSelectOptions(e, o, t, b);
          if (D.err)
            return D;
          var p = this.tryParseArgumentClose(r);
          if (p.err)
            return p;
          var F = X(r, this.clonePosition());
          return o === "select" ? {
            val: {
              type: fe.select,
              value: i,
              options: Wu(D.val),
              location: F
            },
            err: null
          } : {
            val: {
              type: fe.plural,
              value: i,
              options: Wu(D.val),
              offset: y,
              pluralType: o === "plural" ? "cardinal" : "ordinal",
              location: F
            },
            err: null
          };
        }
        default:
          return this.error(W.INVALID_ARGUMENT_TYPE, X(s, l));
      }
    }, n.prototype.tryParseArgumentClose = function(e) {
      return this.isEOF() || this.char() !== 125 ? this.error(W.EXPECT_ARGUMENT_CLOSING_BRACE, X(e, this.clonePosition())) : (this.bump(), { val: !0, err: null });
    }, n.prototype.parseSimpleArgStyleIfPossible = function() {
      for (var e = 0, t = this.clonePosition(); !this.isEOF(); ) {
        var i = this.char();
        switch (i) {
          case 39: {
            this.bump();
            var r = this.clonePosition();
            if (!this.bumpUntil("'"))
              return this.error(W.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE, X(r, this.clonePosition()));
            this.bump();
            break;
          }
          case 123: {
            e += 1, this.bump();
            break;
          }
          case 125: {
            if (e > 0)
              e -= 1;
            else
              return {
                val: this.message.slice(t.offset, this.offset()),
                err: null
              };
            break;
          }
          default:
            this.bump();
            break;
        }
      }
      return {
        val: this.message.slice(t.offset, this.offset()),
        err: null
      };
    }, n.prototype.parseNumberSkeletonFromString = function(e, t) {
      var i = [];
      try {
        i = l1(e);
      } catch {
        return this.error(W.INVALID_NUMBER_SKELETON, t);
      }
      return {
        val: {
          type: hi.number,
          tokens: i,
          location: t,
          parsedOptions: this.shouldParseSkeletons ? h1(i) : {}
        },
        err: null
      };
    }, n.prototype.tryParsePluralOrSelectOptions = function(e, t, i, r) {
      for (var a, s = !1, o = [], l = /* @__PURE__ */ new Set(), c = r.value, u = r.location; ; ) {
        if (c.length === 0) {
          var f = this.clonePosition();
          if (t !== "select" && this.bumpIf("=")) {
            var h = this.tryParseDecimalInteger(W.EXPECT_PLURAL_ARGUMENT_SELECTOR, W.INVALID_PLURAL_ARGUMENT_SELECTOR);
            if (h.err)
              return h;
            u = X(f, this.clonePosition()), c = this.message.slice(f.offset, this.offset());
          } else
            break;
        }
        if (l.has(c))
          return this.error(t === "select" ? W.DUPLICATE_SELECT_ARGUMENT_SELECTOR : W.DUPLICATE_PLURAL_ARGUMENT_SELECTOR, u);
        c === "other" && (s = !0), this.bumpSpace();
        var d = this.clonePosition();
        if (!this.bumpIf("{"))
          return this.error(t === "select" ? W.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT : W.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT, X(this.clonePosition(), this.clonePosition()));
        var p = this.parseMessage(e + 1, t, i);
        if (p.err)
          return p;
        var g = this.tryParseArgumentClose(d);
        if (g.err)
          return g;
        o.push([
          c,
          {
            value: p.val,
            location: X(d, this.clonePosition())
          }
        ]), l.add(c), this.bumpSpace(), a = this.parseIdentifierIfPossible(), c = a.value, u = a.location;
      }
      return o.length === 0 ? this.error(t === "select" ? W.EXPECT_SELECT_ARGUMENT_SELECTOR : W.EXPECT_PLURAL_ARGUMENT_SELECTOR, X(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !s ? this.error(W.MISSING_OTHER_CLAUSE, X(this.clonePosition(), this.clonePosition())) : { val: o, err: null };
    }, n.prototype.tryParseDecimalInteger = function(e, t) {
      var i = 1, r = this.clonePosition();
      this.bumpIf("+") || this.bumpIf("-") && (i = -1);
      for (var a = !1, s = 0; !this.isEOF(); ) {
        var o = this.char();
        if (o >= 48 && o <= 57)
          a = !0, s = s * 10 + (o - 48), this.bump();
        else
          break;
      }
      var l = X(r, this.clonePosition());
      return a ? (s *= i, C1(s) ? { val: s, err: null } : this.error(t, l)) : this.error(e, l);
    }, n.prototype.offset = function() {
      return this.position.offset;
    }, n.prototype.isEOF = function() {
      return this.offset() === this.message.length;
    }, n.prototype.clonePosition = function() {
      return {
        offset: this.position.offset,
        line: this.position.line,
        column: this.position.column
      };
    }, n.prototype.char = function() {
      var e = this.position.offset;
      if (e >= this.message.length)
        throw Error("out of bound");
      var t = gh(this.message, e);
      if (t === void 0)
        throw Error("Offset ".concat(e, " is at invalid UTF-16 code unit boundary"));
      return t;
    }, n.prototype.error = function(e, t) {
      return {
        val: null,
        err: {
          kind: e,
          message: this.message,
          location: t
        }
      };
    }, n.prototype.bump = function() {
      if (!this.isEOF()) {
        var e = this.char();
        e === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += e < 65536 ? 1 : 2);
      }
    }, n.prototype.bumpIf = function(e) {
      if (ju(this.message, e, this.offset())) {
        for (var t = 0; t < e.length; t++)
          this.bump();
        return !0;
      }
      return !1;
    }, n.prototype.bumpUntil = function(e) {
      var t = this.offset(), i = this.message.indexOf(e, t);
      return i >= 0 ? (this.bumpTo(i), !0) : (this.bumpTo(this.message.length), !1);
    }, n.prototype.bumpTo = function(e) {
      if (this.offset() > e)
        throw Error("targetOffset ".concat(e, " must be greater than or equal to the current offset ").concat(this.offset()));
      for (e = Math.min(e, this.message.length); ; ) {
        var t = this.offset();
        if (t === e)
          break;
        if (t > e)
          throw Error("targetOffset ".concat(e, " is at invalid UTF-16 code unit boundary"));
        if (this.bump(), this.isEOF())
          break;
      }
    }, n.prototype.bumpSpace = function() {
      for (; !this.isEOF() && vh(this.char()); )
        this.bump();
    }, n.prototype.peek = function() {
      if (this.isEOF())
        return null;
      var e = this.char(), t = this.offset(), i = this.message.charCodeAt(t + (e >= 65536 ? 2 : 1));
      return i ?? null;
    }, n;
  }()
);
function io(n) {
  return n >= 97 && n <= 122 || n >= 65 && n <= 90;
}
function T1(n) {
  return io(n) || n === 47;
}
function I1(n) {
  return n === 45 || n === 46 || n >= 48 && n <= 57 || n === 95 || n >= 97 && n <= 122 || n >= 65 && n <= 90 || n == 183 || n >= 192 && n <= 214 || n >= 216 && n <= 246 || n >= 248 && n <= 893 || n >= 895 && n <= 8191 || n >= 8204 && n <= 8205 || n >= 8255 && n <= 8256 || n >= 8304 && n <= 8591 || n >= 11264 && n <= 12271 || n >= 12289 && n <= 55295 || n >= 63744 && n <= 64975 || n >= 65008 && n <= 65533 || n >= 65536 && n <= 983039;
}
function vh(n) {
  return n >= 9 && n <= 13 || n === 32 || n === 133 || n >= 8206 && n <= 8207 || n === 8232 || n === 8233;
}
function $1(n) {
  return n >= 33 && n <= 35 || n === 36 || n >= 37 && n <= 39 || n === 40 || n === 41 || n === 42 || n === 43 || n === 44 || n === 45 || n >= 46 && n <= 47 || n >= 58 && n <= 59 || n >= 60 && n <= 62 || n >= 63 && n <= 64 || n === 91 || n === 92 || n === 93 || n === 94 || n === 96 || n === 123 || n === 124 || n === 125 || n === 126 || n === 161 || n >= 162 && n <= 165 || n === 166 || n === 167 || n === 169 || n === 171 || n === 172 || n === 174 || n === 176 || n === 177 || n === 182 || n === 187 || n === 191 || n === 215 || n === 247 || n >= 8208 && n <= 8213 || n >= 8214 && n <= 8215 || n === 8216 || n === 8217 || n === 8218 || n >= 8219 && n <= 8220 || n === 8221 || n === 8222 || n === 8223 || n >= 8224 && n <= 8231 || n >= 8240 && n <= 8248 || n === 8249 || n === 8250 || n >= 8251 && n <= 8254 || n >= 8257 && n <= 8259 || n === 8260 || n === 8261 || n === 8262 || n >= 8263 && n <= 8273 || n === 8274 || n === 8275 || n >= 8277 && n <= 8286 || n >= 8592 && n <= 8596 || n >= 8597 && n <= 8601 || n >= 8602 && n <= 8603 || n >= 8604 && n <= 8607 || n === 8608 || n >= 8609 && n <= 8610 || n === 8611 || n >= 8612 && n <= 8613 || n === 8614 || n >= 8615 && n <= 8621 || n === 8622 || n >= 8623 && n <= 8653 || n >= 8654 && n <= 8655 || n >= 8656 && n <= 8657 || n === 8658 || n === 8659 || n === 8660 || n >= 8661 && n <= 8691 || n >= 8692 && n <= 8959 || n >= 8960 && n <= 8967 || n === 8968 || n === 8969 || n === 8970 || n === 8971 || n >= 8972 && n <= 8991 || n >= 8992 && n <= 8993 || n >= 8994 && n <= 9e3 || n === 9001 || n === 9002 || n >= 9003 && n <= 9083 || n === 9084 || n >= 9085 && n <= 9114 || n >= 9115 && n <= 9139 || n >= 9140 && n <= 9179 || n >= 9180 && n <= 9185 || n >= 9186 && n <= 9254 || n >= 9255 && n <= 9279 || n >= 9280 && n <= 9290 || n >= 9291 && n <= 9311 || n >= 9472 && n <= 9654 || n === 9655 || n >= 9656 && n <= 9664 || n === 9665 || n >= 9666 && n <= 9719 || n >= 9720 && n <= 9727 || n >= 9728 && n <= 9838 || n === 9839 || n >= 9840 && n <= 10087 || n === 10088 || n === 10089 || n === 10090 || n === 10091 || n === 10092 || n === 10093 || n === 10094 || n === 10095 || n === 10096 || n === 10097 || n === 10098 || n === 10099 || n === 10100 || n === 10101 || n >= 10132 && n <= 10175 || n >= 10176 && n <= 10180 || n === 10181 || n === 10182 || n >= 10183 && n <= 10213 || n === 10214 || n === 10215 || n === 10216 || n === 10217 || n === 10218 || n === 10219 || n === 10220 || n === 10221 || n === 10222 || n === 10223 || n >= 10224 && n <= 10239 || n >= 10240 && n <= 10495 || n >= 10496 && n <= 10626 || n === 10627 || n === 10628 || n === 10629 || n === 10630 || n === 10631 || n === 10632 || n === 10633 || n === 10634 || n === 10635 || n === 10636 || n === 10637 || n === 10638 || n === 10639 || n === 10640 || n === 10641 || n === 10642 || n === 10643 || n === 10644 || n === 10645 || n === 10646 || n === 10647 || n === 10648 || n >= 10649 && n <= 10711 || n === 10712 || n === 10713 || n === 10714 || n === 10715 || n >= 10716 && n <= 10747 || n === 10748 || n === 10749 || n >= 10750 && n <= 11007 || n >= 11008 && n <= 11055 || n >= 11056 && n <= 11076 || n >= 11077 && n <= 11078 || n >= 11079 && n <= 11084 || n >= 11085 && n <= 11123 || n >= 11124 && n <= 11125 || n >= 11126 && n <= 11157 || n === 11158 || n >= 11159 && n <= 11263 || n >= 11776 && n <= 11777 || n === 11778 || n === 11779 || n === 11780 || n === 11781 || n >= 11782 && n <= 11784 || n === 11785 || n === 11786 || n === 11787 || n === 11788 || n === 11789 || n >= 11790 && n <= 11798 || n === 11799 || n >= 11800 && n <= 11801 || n === 11802 || n === 11803 || n === 11804 || n === 11805 || n >= 11806 && n <= 11807 || n === 11808 || n === 11809 || n === 11810 || n === 11811 || n === 11812 || n === 11813 || n === 11814 || n === 11815 || n === 11816 || n === 11817 || n >= 11818 && n <= 11822 || n === 11823 || n >= 11824 && n <= 11833 || n >= 11834 && n <= 11835 || n >= 11836 && n <= 11839 || n === 11840 || n === 11841 || n === 11842 || n >= 11843 && n <= 11855 || n >= 11856 && n <= 11857 || n === 11858 || n >= 11859 && n <= 11903 || n >= 12289 && n <= 12291 || n === 12296 || n === 12297 || n === 12298 || n === 12299 || n === 12300 || n === 12301 || n === 12302 || n === 12303 || n === 12304 || n === 12305 || n >= 12306 && n <= 12307 || n === 12308 || n === 12309 || n === 12310 || n === 12311 || n === 12312 || n === 12313 || n === 12314 || n === 12315 || n === 12316 || n === 12317 || n >= 12318 && n <= 12319 || n === 12320 || n === 12336 || n === 64830 || n === 64831 || n >= 65093 && n <= 65094;
}
function ro(n) {
  n.forEach(function(e) {
    if (delete e.location, uh(e) || ch(e))
      for (var t in e.options)
        delete e.options[t].location, ro(e.options[t].value);
    else sh(e) && hh(e.style) || (oh(e) || lh(e)) && Qs(e.style) ? delete e.style.location : fh(e) && ro(e.children);
  });
}
function P1(n, e) {
  e === void 0 && (e = {}), e = Q({ shouldParseSkeletons: !0, requiresOtherClause: !0 }, e);
  var t = new F1(n, e).parse();
  if (t.err) {
    var i = SyntaxError(W[t.err.kind]);
    throw i.location = t.err.location, i.originalMessage = t.err.message, i;
  }
  return e != null && e.captureLocation || ro(t.val), t.val;
}
function ys(n, e) {
  var t = e && e.cache ? e.cache : M1, i = e && e.serializer ? e.serializer : L1, r = e && e.strategy ? e.strategy : O1;
  return r(n, {
    cache: t,
    serializer: i
  });
}
function x1(n) {
  return n == null || typeof n == "number" || typeof n == "boolean";
}
function B1(n, e, t, i) {
  var r = x1(i) ? i : t(i), a = e.get(r);
  return typeof a > "u" && (a = n.call(this, i), e.set(r, a)), a;
}
function yh(n, e, t) {
  var i = Array.prototype.slice.call(arguments, 3), r = t(i), a = e.get(r);
  return typeof a > "u" && (a = n.apply(this, i), e.set(r, a)), a;
}
function wh(n, e, t, i, r) {
  return t.bind(e, n, i, r);
}
function O1(n, e) {
  var t = n.length === 1 ? B1 : yh;
  return wh(n, this, t, e.cache.create(), e.serializer);
}
function R1(n, e) {
  return wh(n, this, yh, e.cache.create(), e.serializer);
}
var L1 = function() {
  return JSON.stringify(arguments);
};
function No() {
  this.cache = /* @__PURE__ */ Object.create(null);
}
No.prototype.get = function(n) {
  return this.cache[n];
};
No.prototype.set = function(n, e) {
  this.cache[n] = e;
};
var M1 = {
  create: function() {
    return new No();
  }
}, ws = {
  variadic: R1
}, di;
(function(n) {
  n.MISSING_VALUE = "MISSING_VALUE", n.INVALID_VALUE = "INVALID_VALUE", n.MISSING_INTL_API = "MISSING_INTL_API";
})(di || (di = {}));
var Aa = (
  /** @class */
  function(n) {
    ka(e, n);
    function e(t, i, r) {
      var a = n.call(this, t) || this;
      return a.code = i, a.originalMessage = r, a;
    }
    return e.prototype.toString = function() {
      return "[formatjs Error: ".concat(this.code, "] ").concat(this.message);
    }, e;
  }(Error)
), Yu = (
  /** @class */
  function(n) {
    ka(e, n);
    function e(t, i, r, a) {
      return n.call(this, 'Invalid values for "'.concat(t, '": "').concat(i, '". Options are "').concat(Object.keys(r).join('", "'), '"'), di.INVALID_VALUE, a) || this;
    }
    return e;
  }(Aa)
), N1 = (
  /** @class */
  function(n) {
    ka(e, n);
    function e(t, i, r) {
      return n.call(this, 'Value for "'.concat(t, '" must be of type ').concat(i), di.INVALID_VALUE, r) || this;
    }
    return e;
  }(Aa)
), U1 = (
  /** @class */
  function(n) {
    ka(e, n);
    function e(t, i) {
      return n.call(this, 'The intl string context variable "'.concat(t, '" was not provided to the string "').concat(i, '"'), di.MISSING_VALUE, i) || this;
    }
    return e;
  }(Aa)
), Xe;
(function(n) {
  n[n.literal = 0] = "literal", n[n.object = 1] = "object";
})(Xe || (Xe = {}));
function H1(n) {
  return n.length < 2 ? n : n.reduce(function(e, t) {
    var i = e[e.length - 1];
    return !i || i.type !== Xe.literal || t.type !== Xe.literal ? e.push(t) : i.value += t.value, e;
  }, []);
}
function G1(n) {
  return typeof n == "function";
}
function zr(n, e, t, i, r, a, s) {
  if (n.length === 1 && Gu(n[0]))
    return [
      {
        type: Xe.literal,
        value: n[0].value
      }
    ];
  for (var o = [], l = 0, c = n; l < c.length; l++) {
    var u = c[l];
    if (Gu(u)) {
      o.push({
        type: Xe.literal,
        value: u.value
      });
      continue;
    }
    if (r1(u)) {
      typeof a == "number" && o.push({
        type: Xe.literal,
        value: t.getNumberFormat(e).format(a)
      });
      continue;
    }
    var f = u.value;
    if (!(r && f in r))
      throw new U1(f, s);
    var h = r[f];
    if (i1(u)) {
      (!h || typeof h == "string" || typeof h == "number") && (h = typeof h == "string" || typeof h == "number" ? String(h) : ""), o.push({
        type: typeof h == "string" ? Xe.literal : Xe.object,
        value: h
      });
      continue;
    }
    if (oh(u)) {
      var d = typeof u.style == "string" ? i.date[u.style] : Qs(u.style) ? u.style.parsedOptions : void 0;
      o.push({
        type: Xe.literal,
        value: t.getDateTimeFormat(e, d).format(h)
      });
      continue;
    }
    if (lh(u)) {
      var d = typeof u.style == "string" ? i.time[u.style] : Qs(u.style) ? u.style.parsedOptions : i.time.medium;
      o.push({
        type: Xe.literal,
        value: t.getDateTimeFormat(e, d).format(h)
      });
      continue;
    }
    if (sh(u)) {
      var d = typeof u.style == "string" ? i.number[u.style] : hh(u.style) ? u.style.parsedOptions : void 0;
      d && d.scale && (h = h * (d.scale || 1)), o.push({
        type: Xe.literal,
        value: t.getNumberFormat(e, d).format(h)
      });
      continue;
    }
    if (fh(u)) {
      var p = u.children, g = u.value, E = r[g];
      if (!G1(E))
        throw new N1(g, "function", s);
      var w = zr(p, e, t, i, r, a), m = E(w.map(function(y) {
        return y.value;
      }));
      Array.isArray(m) || (m = [m]), o.push.apply(o, m.map(function(y) {
        return {
          type: typeof y == "string" ? Xe.literal : Xe.object,
          value: y
        };
      }));
    }
    if (uh(u)) {
      var _ = u.options[h] || u.options.other;
      if (!_)
        throw new Yu(u.value, h, Object.keys(u.options), s);
      o.push.apply(o, zr(_.value, e, t, i, r));
      continue;
    }
    if (ch(u)) {
      var _ = u.options["=".concat(h)];
      if (!_) {
        if (!Intl.PluralRules)
          throw new Aa(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, di.MISSING_INTL_API, s);
        var b = t.getPluralRules(e, { type: u.pluralType }).select(h - (u.offset || 0));
        _ = u.options[b] || u.options.other;
      }
      if (!_)
        throw new Yu(u.value, h, Object.keys(u.options), s);
      o.push.apply(o, zr(_.value, e, t, i, r, h - (u.offset || 0)));
      continue;
    }
  }
  return H1(o);
}
function z1(n, e) {
  return e ? Q(Q(Q({}, n || {}), e || {}), Object.keys(n).reduce(function(t, i) {
    return t[i] = Q(Q({}, n[i]), e[i] || {}), t;
  }, {})) : n;
}
function q1(n, e) {
  return e ? Object.keys(n).reduce(function(t, i) {
    return t[i] = z1(n[i], e[i]), t;
  }, Q({}, n)) : n;
}
function Ds(n) {
  return {
    create: function() {
      return {
        get: function(e) {
          return n[e];
        },
        set: function(e, t) {
          n[e] = t;
        }
      };
    }
  };
}
function V1(n) {
  return n === void 0 && (n = {
    number: {},
    dateTime: {},
    pluralRules: {}
  }), {
    getNumberFormat: ys(function() {
      for (var e, t = [], i = 0; i < arguments.length; i++)
        t[i] = arguments[i];
      return new ((e = Intl.NumberFormat).bind.apply(e, bs([void 0], t, !1)))();
    }, {
      cache: Ds(n.number),
      strategy: ws.variadic
    }),
    getDateTimeFormat: ys(function() {
      for (var e, t = [], i = 0; i < arguments.length; i++)
        t[i] = arguments[i];
      return new ((e = Intl.DateTimeFormat).bind.apply(e, bs([void 0], t, !1)))();
    }, {
      cache: Ds(n.dateTime),
      strategy: ws.variadic
    }),
    getPluralRules: ys(function() {
      for (var e, t = [], i = 0; i < arguments.length; i++)
        t[i] = arguments[i];
      return new ((e = Intl.PluralRules).bind.apply(e, bs([void 0], t, !1)))();
    }, {
      cache: Ds(n.pluralRules),
      strategy: ws.variadic
    })
  };
}
var j1 = (
  /** @class */
  function() {
    function n(e, t, i, r) {
      var a = this;
      if (t === void 0 && (t = n.defaultLocale), this.formatterCache = {
        number: {},
        dateTime: {},
        pluralRules: {}
      }, this.format = function(s) {
        var o = a.formatToParts(s);
        if (o.length === 1)
          return o[0].value;
        var l = o.reduce(function(c, u) {
          return !c.length || u.type !== Xe.literal || typeof c[c.length - 1] != "string" ? c.push(u.value) : c[c.length - 1] += u.value, c;
        }, []);
        return l.length <= 1 ? l[0] || "" : l;
      }, this.formatToParts = function(s) {
        return zr(a.ast, a.locales, a.formatters, a.formats, s, void 0, a.message);
      }, this.resolvedOptions = function() {
        return {
          locale: a.resolvedLocale.toString()
        };
      }, this.getAst = function() {
        return a.ast;
      }, this.locales = t, this.resolvedLocale = n.resolveLocale(t), typeof e == "string") {
        if (this.message = e, !n.__parse)
          throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
        this.ast = n.__parse(e, {
          ignoreTag: r == null ? void 0 : r.ignoreTag,
          locale: this.resolvedLocale
        });
      } else
        this.ast = e;
      if (!Array.isArray(this.ast))
        throw new TypeError("A message must be provided as a String or AST.");
      this.formats = q1(n.formats, i), this.formatters = r && r.formatters || V1(this.formatterCache);
    }
    return Object.defineProperty(n, "defaultLocale", {
      get: function() {
        return n.memoizedDefaultLocale || (n.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale), n.memoizedDefaultLocale;
      },
      enumerable: !1,
      configurable: !0
    }), n.memoizedDefaultLocale = null, n.resolveLocale = function(e) {
      var t = Intl.NumberFormat.supportedLocalesOf(e);
      return t.length > 0 ? new Intl.Locale(t[0]) : new Intl.Locale(typeof e == "string" ? e : e[0]);
    }, n.__parse = P1, n.formats = {
      number: {
        integer: {
          maximumFractionDigits: 0
        },
        currency: {
          style: "currency"
        },
        percent: {
          style: "percent"
        }
      },
      date: {
        short: {
          month: "numeric",
          day: "numeric",
          year: "2-digit"
        },
        medium: {
          month: "short",
          day: "numeric",
          year: "numeric"
        },
        long: {
          month: "long",
          day: "numeric",
          year: "numeric"
        },
        full: {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric"
        }
      },
      time: {
        short: {
          hour: "numeric",
          minute: "numeric"
        },
        medium: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric"
        },
        long: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        },
        full: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        }
      }
    }, n;
  }()
);
function W1(n, e) {
  if (e == null)
    return;
  if (e in n)
    return n[e];
  const t = e.split(".");
  let i = n;
  for (let r = 0; r < t.length; r++)
    if (typeof i == "object") {
      if (r > 0) {
        const a = t.slice(r, t.length).join(".");
        if (a in i) {
          i = i[a];
          break;
        }
      }
      i = i[t[r]];
    } else
      i = void 0;
  return i;
}
const cn = {}, X1 = (n, e, t) => t && (e in cn || (cn[e] = {}), n in cn[e] || (cn[e][n] = t), t), Dh = (n, e) => {
  if (e == null)
    return;
  if (e in cn && n in cn[e])
    return cn[e][n];
  const t = Fa(e);
  for (let i = 0; i < t.length; i++) {
    const r = t[i], a = Z1(r, n);
    if (a)
      return X1(n, e, a);
  }
};
let Uo;
const rr = ir({});
function Y1(n) {
  return Uo[n] || null;
}
function Eh(n) {
  return n in Uo;
}
function Z1(n, e) {
  if (!Eh(n))
    return null;
  const t = Y1(n);
  return W1(t, e);
}
function K1(n) {
  if (n == null)
    return;
  const e = Fa(n);
  for (let t = 0; t < e.length; t++) {
    const i = e[t];
    if (Eh(i))
      return i;
  }
}
function J1(n, ...e) {
  delete cn[n], rr.update((t) => (t[n] = fi.all([t[n] || {}, ...e]), t));
}
gi(
  [rr],
  ([n]) => Object.keys(n)
);
rr.subscribe((n) => Uo = n);
const qr = {};
function Q1(n, e) {
  qr[n].delete(e), qr[n].size === 0 && delete qr[n];
}
function Ch(n) {
  return qr[n];
}
function eb(n) {
  return Fa(n).map((e) => {
    const t = Ch(e);
    return [e, t ? [...t] : []];
  }).filter(([, e]) => e.length > 0);
}
function ao(n) {
  return n == null ? !1 : Fa(n).some(
    (e) => {
      var t;
      return (t = Ch(e)) == null ? void 0 : t.size;
    }
  );
}
function tb(n, e) {
  return Promise.all(
    e.map((i) => (Q1(n, i), i().then((r) => r.default || r)))
  ).then((i) => J1(n, ...i));
}
const Ti = {};
function Sh(n) {
  if (!ao(n))
    return n in Ti ? Ti[n] : Promise.resolve();
  const e = eb(n);
  return Ti[n] = Promise.all(
    e.map(
      ([t, i]) => tb(t, i)
    )
  ).then(() => {
    if (ao(n))
      return Sh(n);
    delete Ti[n];
  }), Ti[n];
}
const nb = {
  number: {
    scientific: { notation: "scientific" },
    engineering: { notation: "engineering" },
    compactLong: { notation: "compact", compactDisplay: "long" },
    compactShort: { notation: "compact", compactDisplay: "short" }
  },
  date: {
    short: { month: "numeric", day: "numeric", year: "2-digit" },
    medium: { month: "short", day: "numeric", year: "numeric" },
    long: { month: "long", day: "numeric", year: "numeric" },
    full: { weekday: "long", month: "long", day: "numeric", year: "numeric" }
  },
  time: {
    short: { hour: "numeric", minute: "numeric" },
    medium: { hour: "numeric", minute: "numeric", second: "numeric" },
    long: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    },
    full: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    }
  }
}, ib = {
  fallbackLocale: null,
  loadingDelay: 200,
  formats: nb,
  warnOnMissingMessages: !0,
  handleMissingMessage: void 0,
  ignoreTag: !0
}, rb = ib;
function _i() {
  return rb;
}
const Es = ir(!1);
var ab = Object.defineProperty, sb = Object.defineProperties, ob = Object.getOwnPropertyDescriptors, Zu = Object.getOwnPropertySymbols, lb = Object.prototype.hasOwnProperty, ub = Object.prototype.propertyIsEnumerable, Ku = (n, e, t) => e in n ? ab(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t, cb = (n, e) => {
  for (var t in e || (e = {}))
    lb.call(e, t) && Ku(n, t, e[t]);
  if (Zu)
    for (var t of Zu(e))
      ub.call(e, t) && Ku(n, t, e[t]);
  return n;
}, fb = (n, e) => sb(n, ob(e));
let so;
const fa = ir(null);
function Ju(n) {
  return n.split("-").map((e, t, i) => i.slice(0, t + 1).join("-")).reverse();
}
function Fa(n, e = _i().fallbackLocale) {
  const t = Ju(n);
  return e ? [.../* @__PURE__ */ new Set([...t, ...Ju(e)])] : t;
}
function Gn() {
  return so ?? void 0;
}
fa.subscribe((n) => {
  so = n ?? void 0, typeof window < "u" && n != null && document.documentElement.setAttribute("lang", n);
});
const hb = (n) => {
  if (n && K1(n) && ao(n)) {
    const { loadingDelay: e } = _i();
    let t;
    return typeof window < "u" && Gn() != null && e ? t = window.setTimeout(
      () => Es.set(!0),
      e
    ) : Es.set(!0), Sh(n).then(() => {
      fa.set(n);
    }).finally(() => {
      clearTimeout(t), Es.set(!1);
    });
  }
  return fa.set(n);
}, ar = fb(cb({}, fa), {
  set: hb
}), Ta = (n) => {
  const e = /* @__PURE__ */ Object.create(null);
  return (i) => {
    const r = JSON.stringify(i);
    return r in e ? e[r] : e[r] = n(i);
  };
};
var db = Object.defineProperty, ha = Object.getOwnPropertySymbols, kh = Object.prototype.hasOwnProperty, Ah = Object.prototype.propertyIsEnumerable, Qu = (n, e, t) => e in n ? db(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t, Ho = (n, e) => {
  for (var t in e || (e = {}))
    kh.call(e, t) && Qu(n, t, e[t]);
  if (ha)
    for (var t of ha(e))
      Ah.call(e, t) && Qu(n, t, e[t]);
  return n;
}, bi = (n, e) => {
  var t = {};
  for (var i in n)
    kh.call(n, i) && e.indexOf(i) < 0 && (t[i] = n[i]);
  if (n != null && ha)
    for (var i of ha(n))
      e.indexOf(i) < 0 && Ah.call(n, i) && (t[i] = n[i]);
  return t;
};
const Ki = (n, e) => {
  const { formats: t } = _i();
  if (n in t && e in t[n])
    return t[n][e];
  throw new Error(`[svelte-i18n] Unknown "${e}" ${n} format.`);
}, _b = Ta(
  (n) => {
    var e = n, { locale: t, format: i } = e, r = bi(e, ["locale", "format"]);
    if (t == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format numbers');
    return i && (r = Ki("number", i)), new Intl.NumberFormat(t, r);
  }
), pb = Ta(
  (n) => {
    var e = n, { locale: t, format: i } = e, r = bi(e, ["locale", "format"]);
    if (t == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format dates');
    return i ? r = Ki("date", i) : Object.keys(r).length === 0 && (r = Ki("date", "short")), new Intl.DateTimeFormat(t, r);
  }
), mb = Ta(
  (n) => {
    var e = n, { locale: t, format: i } = e, r = bi(e, ["locale", "format"]);
    if (t == null)
      throw new Error(
        '[svelte-i18n] A "locale" must be set to format time values'
      );
    return i ? r = Ki("time", i) : Object.keys(r).length === 0 && (r = Ki("time", "short")), new Intl.DateTimeFormat(t, r);
  }
), gb = (n = {}) => {
  var e = n, {
    locale: t = Gn()
  } = e, i = bi(e, [
    "locale"
  ]);
  return _b(Ho({ locale: t }, i));
}, bb = (n = {}) => {
  var e = n, {
    locale: t = Gn()
  } = e, i = bi(e, [
    "locale"
  ]);
  return pb(Ho({ locale: t }, i));
}, vb = (n = {}) => {
  var e = n, {
    locale: t = Gn()
  } = e, i = bi(e, [
    "locale"
  ]);
  return mb(Ho({ locale: t }, i));
}, yb = Ta(
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  (n, e = Gn()) => new j1(n, e, _i().formats, {
    ignoreTag: _i().ignoreTag
  })
), wb = (n, e = {}) => {
  var t, i, r, a;
  let s = e;
  typeof n == "object" && (s = n, n = s.id);
  const {
    values: o,
    locale: l = Gn(),
    default: c
  } = s;
  if (l == null)
    throw new Error(
      "[svelte-i18n] Cannot format a message without first setting the initial locale."
    );
  let u = Dh(n, l);
  if (!u)
    u = (a = (r = (i = (t = _i()).handleMissingMessage) == null ? void 0 : i.call(t, { locale: l, id: n, defaultValue: c })) != null ? r : c) != null ? a : n;
  else if (typeof u != "string")
    return console.warn(
      `[svelte-i18n] Message with id "${n}" must be of type "string", found: "${typeof u}". Gettin its value through the "$format" method is deprecated; use the "json" method instead.`
    ), u;
  if (!o)
    return u;
  let f = u;
  try {
    f = yb(u, l).format(o);
  } catch (h) {
    h instanceof Error && console.warn(
      `[svelte-i18n] Message "${n}" has syntax error:`,
      h.message
    );
  }
  return f;
}, Db = (n, e) => vb(e).format(n), Eb = (n, e) => bb(e).format(n), Cb = (n, e) => gb(e).format(n), Sb = (n, e = Gn()) => Dh(n, e);
gi([ar, rr], () => wb);
gi([ar], () => Db);
gi([ar], () => Eb);
gi([ar], () => Cb);
gi([ar, rr], () => Sb);
const {
  SvelteComponent: kb,
  append_hydration: Je,
  attr: mn,
  children: gn,
  claim_element: bn,
  claim_space: oo,
  claim_text: ti,
  detach: en,
  element: vn,
  init: Ab,
  insert_hydration: Fh,
  noop: ec,
  safe_not_equal: Fb,
  set_data: da,
  set_style: Cs,
  space: lo,
  text: ni,
  toggle_class: tc
} = window.__gradio__svelte__internal, { onMount: Tb, createEventDispatcher: Ib, onDestroy: $b } = window.__gradio__svelte__internal;
function nc(n) {
  let e, t, i, r, a = Li(
    /*file_to_display*/
    n[2]
  ) + "", s, o, l, c, u = (
    /*file_to_display*/
    n[2].orig_name + ""
  ), f;
  return {
    c() {
      e = vn("div"), t = vn("span"), i = vn("div"), r = vn("progress"), s = ni(a), l = lo(), c = vn("span"), f = ni(u), this.h();
    },
    l(h) {
      e = bn(h, "DIV", { class: !0 });
      var d = gn(e);
      t = bn(d, "SPAN", {});
      var p = gn(t);
      i = bn(p, "DIV", { class: !0 });
      var g = gn(i);
      r = bn(g, "PROGRESS", { style: !0, max: !0, class: !0 });
      var E = gn(r);
      s = ti(E, a), E.forEach(en), g.forEach(en), p.forEach(en), l = oo(d), c = bn(d, "SPAN", { class: !0 });
      var w = gn(c);
      f = ti(w, u), w.forEach(en), d.forEach(en), this.h();
    },
    h() {
      Cs(r, "visibility", "hidden"), Cs(r, "height", "0"), Cs(r, "width", "0"), r.value = o = Li(
        /*file_to_display*/
        n[2]
      ), mn(r, "max", "100"), mn(r, "class", "svelte-cr2edf"), mn(i, "class", "progress-bar svelte-cr2edf"), mn(c, "class", "file-name svelte-cr2edf"), mn(e, "class", "file svelte-cr2edf");
    },
    m(h, d) {
      Fh(h, e, d), Je(e, t), Je(t, i), Je(i, r), Je(r, s), Je(e, l), Je(e, c), Je(c, f);
    },
    p(h, d) {
      d & /*file_to_display*/
      4 && a !== (a = Li(
        /*file_to_display*/
        h[2]
      ) + "") && da(s, a), d & /*file_to_display*/
      4 && o !== (o = Li(
        /*file_to_display*/
        h[2]
      )) && (r.value = o), d & /*file_to_display*/
      4 && u !== (u = /*file_to_display*/
      h[2].orig_name + "") && da(f, u);
    },
    d(h) {
      h && en(e);
    }
  };
}
function Pb(n) {
  let e, t, i, r = (
    /*files_with_progress*/
    n[0].length + ""
  ), a, s, o = (
    /*files_with_progress*/
    n[0].length > 1 ? "files" : "file"
  ), l, c, u, f = (
    /*file_to_display*/
    n[2] && nc(n)
  );
  return {
    c() {
      e = vn("div"), t = vn("span"), i = ni("Uploading "), a = ni(r), s = lo(), l = ni(o), c = ni("..."), u = lo(), f && f.c(), this.h();
    },
    l(h) {
      e = bn(h, "DIV", { class: !0 });
      var d = gn(e);
      t = bn(d, "SPAN", { class: !0 });
      var p = gn(t);
      i = ti(p, "Uploading "), a = ti(p, r), s = oo(p), l = ti(p, o), c = ti(p, "..."), p.forEach(en), u = oo(d), f && f.l(d), d.forEach(en), this.h();
    },
    h() {
      mn(t, "class", "uploading svelte-cr2edf"), mn(e, "class", "wrap svelte-cr2edf"), tc(
        e,
        "progress",
        /*progress*/
        n[1]
      );
    },
    m(h, d) {
      Fh(h, e, d), Je(e, t), Je(t, i), Je(t, a), Je(t, s), Je(t, l), Je(t, c), Je(e, u), f && f.m(e, null);
    },
    p(h, [d]) {
      d & /*files_with_progress*/
      1 && r !== (r = /*files_with_progress*/
      h[0].length + "") && da(a, r), d & /*files_with_progress*/
      1 && o !== (o = /*files_with_progress*/
      h[0].length > 1 ? "files" : "file") && da(l, o), /*file_to_display*/
      h[2] ? f ? f.p(h, d) : (f = nc(h), f.c(), f.m(e, null)) : f && (f.d(1), f = null), d & /*progress*/
      2 && tc(
        e,
        "progress",
        /*progress*/
        h[1]
      );
    },
    i: ec,
    o: ec,
    d(h) {
      h && en(e), f && f.d();
    }
  };
}
function Li(n) {
  return n.progress * 100 / (n.size || 0) || 0;
}
function xb(n) {
  let e = 0;
  return n.forEach((t) => {
    e += Li(t);
  }), document.documentElement.style.setProperty("--upload-progress-width", (e / n.length).toFixed(2) + "%"), e / n.length;
}
function Bb(n, e, t) {
  let { upload_id: i } = e, { root: r } = e, { files: a } = e, { stream_handler: s } = e, o, l = !1, c, u, f = a.map((p) => ({ ...p, progress: 0 }));
  const h = Ib();
  function d(p, g) {
    t(0, f = f.map((E) => (E.orig_name === p && (E.progress += g), E)));
  }
  return Tb(async () => {
    if (o = await s(new URL(`${r}/gradio_api/upload_progress?upload_id=${i}`)), o == null)
      throw new Error("Event source is not defined");
    o.onmessage = async function(p) {
      const g = JSON.parse(p.data);
      l || t(1, l = !0), g.msg === "done" ? (o == null || o.close(), h("done")) : (t(7, c = g), d(g.orig_name, g.chunk_size));
    };
  }), $b(() => {
    (o != null || o != null) && o.close();
  }), n.$$set = (p) => {
    "upload_id" in p && t(3, i = p.upload_id), "root" in p && t(4, r = p.root), "files" in p && t(5, a = p.files), "stream_handler" in p && t(6, s = p.stream_handler);
  }, n.$$.update = () => {
    n.$$.dirty & /*files_with_progress*/
    1 && xb(f), n.$$.dirty & /*current_file_upload, files_with_progress*/
    129 && t(2, u = c || f[0]);
  }, [
    f,
    l,
    u,
    i,
    r,
    a,
    s,
    c
  ];
}
class Ob extends kb {
  constructor(e) {
    super(), Ab(this, e, Bb, Pb, Fb, {
      upload_id: 3,
      root: 4,
      files: 5,
      stream_handler: 6
    });
  }
}
function Rb() {
  let n, e;
  return {
    drag(t, i = {}) {
      e = i;
      function r() {
        n = document.createElement("input"), n.type = "file", n.style.display = "none", n.setAttribute("aria-label", "File upload"), n.setAttribute("data-testid", "file-upload");
        const f = Array.isArray(e.accepted_types) ? e.accepted_types.join(",") : e.accepted_types || void 0;
        f && (n.accept = f), n.multiple = e.mode === "multiple" || !1, e.mode === "directory" && (n.webkitdirectory = !0, n.setAttribute("directory", ""), n.setAttribute("mozdirectory", "")), t.appendChild(n);
      }
      r();
      function a(f) {
        f.preventDefault(), f.stopPropagation();
      }
      function s(f) {
        var h;
        f.preventDefault(), f.stopPropagation(), (h = e.on_drag_change) == null || h.call(e, !0);
      }
      function o(f) {
        var h;
        f.preventDefault(), f.stopPropagation(), (h = e.on_drag_change) == null || h.call(e, !1);
      }
      function l(f) {
        var d, p, g;
        if (f.preventDefault(), f.stopPropagation(), (d = e.on_drag_change) == null || d.call(e, !1), !((p = f.dataTransfer) != null && p.files)) return;
        const h = Array.from(f.dataTransfer.files);
        h.length > 0 && ((g = e.on_files) == null || g.call(e, h));
      }
      function c() {
        e.disable_click || (n.value = "", n.click());
      }
      function u() {
        var f;
        if (n.files) {
          const h = Array.from(n.files);
          h.length > 0 && ((f = e.on_files) == null || f.call(e, h));
        }
      }
      return t.addEventListener("drag", a), t.addEventListener("dragstart", a), t.addEventListener("dragend", a), t.addEventListener("dragover", a), t.addEventListener("dragenter", s), t.addEventListener("dragleave", o), t.addEventListener("drop", l), t.addEventListener("click", c), n.addEventListener("change", u), {
        update(f) {
          e = f, n.remove(), r(), n.addEventListener("change", u);
        },
        destroy() {
          t.removeEventListener("drag", a), t.removeEventListener("dragstart", a), t.removeEventListener("dragend", a), t.removeEventListener("dragover", a), t.removeEventListener("dragenter", s), t.removeEventListener("dragleave", o), t.removeEventListener("drop", l), t.removeEventListener("click", c), n.removeEventListener("change", u), n.remove();
        }
      };
    },
    open_file_upload() {
      n && (n.value = "", n.click());
    }
  };
}
const {
  SvelteComponent: Lb,
  action_destroyer: Mb,
  attr: Et,
  check_outros: Th,
  children: Ih,
  claim_component: Nb,
  claim_element: $h,
  create_component: Ub,
  create_slot: Ph,
  destroy_component: Hb,
  detach: pi,
  element: xh,
  empty: _a,
  get_all_dirty_from_scope: Bh,
  get_slot_changes: Oh,
  group_outros: Rh,
  init: Gb,
  insert_hydration: Ia,
  is_function: zb,
  listen: qb,
  mount_component: Vb,
  safe_not_equal: jb,
  set_style: pa,
  toggle_class: be,
  transition_in: hn,
  transition_out: Bn,
  update_slot_base: Lh
} = window.__gradio__svelte__internal, { createEventDispatcher: Wb, tick: Xb, getContext: S6 } = window.__gradio__svelte__internal;
function Yb(n) {
  let e, t, i, r, a, s, o;
  const l = (
    /*#slots*/
    n[30].default
  ), c = Ph(
    l,
    n,
    /*$$scope*/
    n[29],
    null
  );
  return {
    c() {
      e = xh("button"), c && c.c(), this.h();
    },
    l(u) {
      e = $h(u, "BUTTON", {
        tabindex: !0,
        "aria-label": !0,
        "aria-dropeffect": !0,
        class: !0
      });
      var f = Ih(e);
      c && c.l(f), f.forEach(pi), this.h();
    },
    h() {
      Et(e, "tabindex", t = /*hidden*/
      n[9] ? -1 : 0), Et(e, "aria-label", i = /*aria_label*/
      n[14] || "Click to upload or drop files"), Et(e, "aria-dropeffect", "copy"), Et(e, "class", "svelte-1o7nwih"), be(
        e,
        "hidden",
        /*hidden*/
        n[9]
      ), be(
        e,
        "center",
        /*center*/
        n[4]
      ), be(
        e,
        "boundedheight",
        /*boundedheight*/
        n[3]
      ), be(
        e,
        "flex",
        /*flex*/
        n[5]
      ), be(
        e,
        "disable_click",
        /*disable_click*/
        n[7]
      ), be(
        e,
        "icon-mode",
        /*icon_upload*/
        n[12]
      ), pa(
        e,
        "height",
        /*icon_upload*/
        n[12] ? "" : (
          /*height*/
          n[13] ? typeof /*height*/
          n[13] == "number" ? (
            /*height*/
            n[13] + "px"
          ) : (
            /*height*/
            n[13]
          ) : "100%"
        )
      );
    },
    m(u, f) {
      Ia(u, e, f), c && c.m(e, null), a = !0, s || (o = Mb(r = /*drag*/
      n[19].call(null, e, {
        on_drag_change: rc,
        on_files: (
          /*drag_function_1*/
          n[31]
        ),
        accepted_types: (
          /*accept_file_types*/
          n[18]
        ),
        mode: (
          /*file_count*/
          n[6]
        ),
        disable_click: (
          /*disable_click*/
          n[7]
        )
      })), s = !0);
    },
    p(u, f) {
      c && c.p && (!a || f[0] & /*$$scope*/
      536870912) && Lh(
        c,
        l,
        u,
        /*$$scope*/
        u[29],
        a ? Oh(
          l,
          /*$$scope*/
          u[29],
          f,
          null
        ) : Bh(
          /*$$scope*/
          u[29]
        ),
        null
      ), (!a || f[0] & /*hidden*/
      512 && t !== (t = /*hidden*/
      u[9] ? -1 : 0)) && Et(e, "tabindex", t), (!a || f[0] & /*aria_label*/
      16384 && i !== (i = /*aria_label*/
      u[14] || "Click to upload or drop files")) && Et(e, "aria-label", i), r && zb(r.update) && f[0] & /*accept_file_types, file_count, disable_click*/
      262336 && r.update.call(null, {
        on_drag_change: rc,
        on_files: (
          /*drag_function_1*/
          u[31]
        ),
        accepted_types: (
          /*accept_file_types*/
          u[18]
        ),
        mode: (
          /*file_count*/
          u[6]
        ),
        disable_click: (
          /*disable_click*/
          u[7]
        )
      }), (!a || f[0] & /*hidden*/
      512) && be(
        e,
        "hidden",
        /*hidden*/
        u[9]
      ), (!a || f[0] & /*center*/
      16) && be(
        e,
        "center",
        /*center*/
        u[4]
      ), (!a || f[0] & /*boundedheight*/
      8) && be(
        e,
        "boundedheight",
        /*boundedheight*/
        u[3]
      ), (!a || f[0] & /*flex*/
      32) && be(
        e,
        "flex",
        /*flex*/
        u[5]
      ), (!a || f[0] & /*disable_click*/
      128) && be(
        e,
        "disable_click",
        /*disable_click*/
        u[7]
      ), (!a || f[0] & /*icon_upload*/
      4096) && be(
        e,
        "icon-mode",
        /*icon_upload*/
        u[12]
      ), f[0] & /*icon_upload, height*/
      12288 && pa(
        e,
        "height",
        /*icon_upload*/
        u[12] ? "" : (
          /*height*/
          u[13] ? typeof /*height*/
          u[13] == "number" ? (
            /*height*/
            u[13] + "px"
          ) : (
            /*height*/
            u[13]
          ) : "100%"
        )
      );
    },
    i(u) {
      a || (hn(c, u), a = !0);
    },
    o(u) {
      Bn(c, u), a = !1;
    },
    d(u) {
      u && pi(e), c && c.d(u), s = !1, o();
    }
  };
}
function Zb(n) {
  let e, t, i = !/*hidden*/
  n[9] && ic(n);
  return {
    c() {
      i && i.c(), e = _a();
    },
    l(r) {
      i && i.l(r), e = _a();
    },
    m(r, a) {
      i && i.m(r, a), Ia(r, e, a), t = !0;
    },
    p(r, a) {
      /*hidden*/
      r[9] ? i && (Rh(), Bn(i, 1, 1, () => {
        i = null;
      }), Th()) : i ? (i.p(r, a), a[0] & /*hidden*/
      512 && hn(i, 1)) : (i = ic(r), i.c(), hn(i, 1), i.m(e.parentNode, e));
    },
    i(r) {
      t || (hn(i), t = !0);
    },
    o(r) {
      Bn(i), t = !1;
    },
    d(r) {
      r && pi(e), i && i.d(r);
    }
  };
}
function Kb(n) {
  let e, t, i, r, a, s;
  const o = (
    /*#slots*/
    n[30].default
  ), l = Ph(
    o,
    n,
    /*$$scope*/
    n[29],
    null
  );
  return {
    c() {
      e = xh("button"), l && l.c(), this.h();
    },
    l(c) {
      e = $h(c, "BUTTON", {
        tabindex: !0,
        "aria-label": !0,
        class: !0
      });
      var u = Ih(e);
      l && l.l(u), u.forEach(pi), this.h();
    },
    h() {
      Et(e, "tabindex", t = /*hidden*/
      n[9] ? -1 : 0), Et(e, "aria-label", i = /*aria_label*/
      n[14] || "Paste from clipboard"), Et(e, "class", "svelte-1o7nwih"), be(
        e,
        "hidden",
        /*hidden*/
        n[9]
      ), be(
        e,
        "center",
        /*center*/
        n[4]
      ), be(
        e,
        "boundedheight",
        /*boundedheight*/
        n[3]
      ), be(
        e,
        "flex",
        /*flex*/
        n[5]
      ), be(
        e,
        "icon-mode",
        /*icon_upload*/
        n[12]
      ), pa(
        e,
        "height",
        /*icon_upload*/
        n[12] ? "" : (
          /*height*/
          n[13] ? typeof /*height*/
          n[13] == "number" ? (
            /*height*/
            n[13] + "px"
          ) : (
            /*height*/
            n[13]
          ) : "100%"
        )
      );
    },
    m(c, u) {
      Ia(c, e, u), l && l.m(e, null), r = !0, a || (s = qb(
        e,
        "click",
        /*paste_clipboard*/
        n[15]
      ), a = !0);
    },
    p(c, u) {
      l && l.p && (!r || u[0] & /*$$scope*/
      536870912) && Lh(
        l,
        o,
        c,
        /*$$scope*/
        c[29],
        r ? Oh(
          o,
          /*$$scope*/
          c[29],
          u,
          null
        ) : Bh(
          /*$$scope*/
          c[29]
        ),
        null
      ), (!r || u[0] & /*hidden*/
      512 && t !== (t = /*hidden*/
      c[9] ? -1 : 0)) && Et(e, "tabindex", t), (!r || u[0] & /*aria_label*/
      16384 && i !== (i = /*aria_label*/
      c[14] || "Paste from clipboard")) && Et(e, "aria-label", i), (!r || u[0] & /*hidden*/
      512) && be(
        e,
        "hidden",
        /*hidden*/
        c[9]
      ), (!r || u[0] & /*center*/
      16) && be(
        e,
        "center",
        /*center*/
        c[4]
      ), (!r || u[0] & /*boundedheight*/
      8) && be(
        e,
        "boundedheight",
        /*boundedheight*/
        c[3]
      ), (!r || u[0] & /*flex*/
      32) && be(
        e,
        "flex",
        /*flex*/
        c[5]
      ), (!r || u[0] & /*icon_upload*/
      4096) && be(
        e,
        "icon-mode",
        /*icon_upload*/
        c[12]
      ), u[0] & /*icon_upload, height*/
      12288 && pa(
        e,
        "height",
        /*icon_upload*/
        c[12] ? "" : (
          /*height*/
          c[13] ? typeof /*height*/
          c[13] == "number" ? (
            /*height*/
            c[13] + "px"
          ) : (
            /*height*/
            c[13]
          ) : "100%"
        )
      );
    },
    i(c) {
      r || (hn(l, c), r = !0);
    },
    o(c) {
      Bn(l, c), r = !1;
    },
    d(c) {
      c && pi(e), l && l.d(c), a = !1, s();
    }
  };
}
function ic(n) {
  let e, t;
  return e = new Ob({
    props: {
      root: (
        /*root*/
        n[8]
      ),
      upload_id: (
        /*upload_id*/
        n[16]
      ),
      files: (
        /*file_data*/
        n[17]
      ),
      stream_handler: (
        /*stream_handler*/
        n[11]
      )
    }
  }), {
    c() {
      Ub(e.$$.fragment);
    },
    l(i) {
      Nb(e.$$.fragment, i);
    },
    m(i, r) {
      Vb(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*root*/
      256 && (a.root = /*root*/
      i[8]), r[0] & /*upload_id*/
      65536 && (a.upload_id = /*upload_id*/
      i[16]), r[0] & /*file_data*/
      131072 && (a.files = /*file_data*/
      i[17]), r[0] & /*stream_handler*/
      2048 && (a.stream_handler = /*stream_handler*/
      i[11]), e.$set(a);
    },
    i(i) {
      t || (hn(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Bn(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Hb(e, i);
    }
  };
}
function Jb(n) {
  let e, t, i, r;
  const a = [Kb, Zb, Yb], s = [];
  function o(l, c) {
    return (
      /*filetype*/
      l[0] === "clipboard" ? 0 : (
        /*uploading*/
        l[2] && /*show_progress*/
        l[10] ? 1 : 2
      )
    );
  }
  return e = o(n), t = s[e] = a[e](n), {
    c() {
      t.c(), i = _a();
    },
    l(l) {
      t.l(l), i = _a();
    },
    m(l, c) {
      s[e].m(l, c), Ia(l, i, c), r = !0;
    },
    p(l, c) {
      let u = e;
      e = o(l), e === u ? s[e].p(l, c) : (Rh(), Bn(s[u], 1, 1, () => {
        s[u] = null;
      }), Th(), t = s[e], t ? t.p(l, c) : (t = s[e] = a[e](l), t.c()), hn(t, 1), t.m(i.parentNode, i));
    },
    i(l) {
      r || (hn(t), r = !0);
    },
    o(l) {
      Bn(t), r = !1;
    },
    d(l) {
      l && pi(i), s[e].d(l);
    }
  };
}
function Qb(n, e, t) {
  if (!n || n === "*" || n === "file/*" || Array.isArray(n) && n.some((r) => r === "*" || r === "file/*"))
    return !0;
  let i;
  if (typeof n == "string")
    i = n.split(",").map((r) => r.trim());
  else if (Array.isArray(n))
    i = n;
  else
    return !1;
  return i.includes(e) || i.some((r) => {
    const [a] = r.split("/").map((s) => s.trim());
    return r.endsWith("/*") && t.startsWith(a + "/");
  });
}
const rc = (n) => n = n;
function e2(n, e, t) {
  let i, { $$slots: r = {}, $$scope: a } = e;
  const { drag: s, open_file_upload: o } = Rb();
  let { filetype: l = null } = e, { dragging: c = !1 } = e, { boundedheight: u = !0 } = e, { center: f = !0 } = e, { flex: h = !0 } = e, { file_count: d = "single" } = e, { disable_click: p = !1 } = e, { root: g } = e, { hidden: E = !1 } = e, { format: w = "file" } = e, { uploading: m = !1 } = e, { show_progress: _ = !0 } = e, { max_file_size: b = null } = e, { upload: y } = e, { stream_handler: D } = e, { icon_upload: F = !1 } = e, { height: x = void 0 } = e, { aria_label: T = void 0 } = e;
  function R() {
    o();
  }
  let O, L, Z, z = null;
  const ge = () => {
    if (typeof navigator < "u") {
      const $ = navigator.userAgent.toLowerCase();
      return $.indexOf("iphone") > -1 || $.indexOf("ipad") > -1;
    }
    return !1;
  }, G = Wb(), ve = ["image", "video", "audio", "text", "file"], q = ($) => i && $.startsWith(".") ? (z = !0, $) : i && $.includes("file/*") ? "*" : $.startsWith(".") || $.endsWith("/*") ? $ : ve.includes($) ? $ + "/*" : "." + $;
  function P() {
    navigator.clipboard.read().then(async ($) => {
      for (let V = 0; V < $.length; V++) {
        const J = $[V].types.find((se) => se.startsWith("image/"));
        if (J) {
          $[V].getType(J).then(async (se) => {
            const k = new File([se], `clipboard.${J.replace("image/", "")}`);
            await ee([k]);
          });
          break;
        }
      }
    });
  }
  function le() {
    o();
  }
  async function S($) {
    await Xb(), t(16, O = Math.random().toString(36).substring(2, 15)), t(2, m = !0);
    try {
      const V = await y($, g, O, b ?? 1 / 0);
      return G("load", d === "single" ? V == null ? void 0 : V[0] : V), t(2, m = !1), V || [];
    } catch (V) {
      return G("error", V.message), t(2, m = !1), [];
    }
  }
  async function ee($) {
    if (!$.length)
      return;
    let V = $.map((J) => new File([J], J instanceof File ? J.name : "file", { type: J.type }));
    return i && z && (V = V.filter((J) => K(J) ? !0 : (G("error", `Invalid file type: ${J.name}. Only ${l} allowed.`), !1)), V.length === 0) ? [] : (t(17, L = await L0(V)), await S(L));
  }
  function K($) {
    return l ? (Array.isArray(l) ? l : [l]).some((J) => {
      const se = q(J);
      if (se.startsWith("."))
        return $.name.toLowerCase().endsWith(se.toLowerCase());
      if (se === "*")
        return !0;
      if (se.endsWith("/*")) {
        const [k] = se.split("/");
        return $.type.startsWith(k + "/");
      }
      return $.type === se;
    }) : !0;
  }
  async function de($) {
    const V = $.filter((J) => {
      const se = "." + J.name.split(".").pop();
      return se && Qb(Z, se, J.type) || (se && Array.isArray(l) ? l.includes(se) : se === l) ? !0 : (G("error", `Invalid file type only ${l} allowed.`), !1);
    });
    if (w != "blob")
      await ee(V);
    else {
      if (d === "single") {
        G("load", V[0]);
        return;
      }
      G("load", V);
    }
  }
  async function I($) {
    var J;
    if (t(1, c = !1), !((J = $.dataTransfer) != null && J.files)) return;
    const V = Array.from($.dataTransfer.files).filter(K);
    if (w != "blob")
      await ee(V);
    else {
      if (d === "single") {
        G("load", V[0]);
        return;
      }
      G("load", V);
    }
  }
  const Ce = ($) => de($);
  return n.$$set = ($) => {
    "filetype" in $ && t(0, l = $.filetype), "dragging" in $ && t(1, c = $.dragging), "boundedheight" in $ && t(3, u = $.boundedheight), "center" in $ && t(4, f = $.center), "flex" in $ && t(5, h = $.flex), "file_count" in $ && t(6, d = $.file_count), "disable_click" in $ && t(7, p = $.disable_click), "root" in $ && t(8, g = $.root), "hidden" in $ && t(9, E = $.hidden), "format" in $ && t(21, w = $.format), "uploading" in $ && t(2, m = $.uploading), "show_progress" in $ && t(10, _ = $.show_progress), "max_file_size" in $ && t(22, b = $.max_file_size), "upload" in $ && t(23, y = $.upload), "stream_handler" in $ && t(11, D = $.stream_handler), "icon_upload" in $ && t(12, F = $.icon_upload), "height" in $ && t(13, x = $.height), "aria_label" in $ && t(14, T = $.aria_label), "$$scope" in $ && t(29, a = $.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*filetype, ios*/
    268435457 && (l == null ? t(18, Z = null) : typeof l == "string" ? t(18, Z = q(l)) : i && l.includes("file/*") ? t(18, Z = "*") : (t(0, l = l.map(q)), t(18, Z = l.join(", "))));
  }, t(28, i = ge()), [
    l,
    c,
    m,
    u,
    f,
    h,
    d,
    p,
    g,
    E,
    _,
    D,
    F,
    x,
    T,
    P,
    O,
    L,
    Z,
    s,
    de,
    w,
    b,
    y,
    R,
    le,
    ee,
    I,
    i,
    a,
    r,
    Ce
  ];
}
class t2 extends Lb {
  constructor(e) {
    super(), Gb(
      this,
      e,
      e2,
      Jb,
      jb,
      {
        filetype: 0,
        dragging: 1,
        boundedheight: 3,
        center: 4,
        flex: 5,
        file_count: 6,
        disable_click: 7,
        root: 8,
        hidden: 9,
        format: 21,
        uploading: 2,
        show_progress: 10,
        max_file_size: 22,
        upload: 23,
        stream_handler: 11,
        icon_upload: 12,
        height: 13,
        aria_label: 14,
        open_upload: 24,
        paste_clipboard: 15,
        open_file_upload: 25,
        load_files: 26,
        load_files_from_drop: 27
      },
      null,
      [-1, -1]
    );
  }
  get open_upload() {
    return this.$$.ctx[24];
  }
  get paste_clipboard() {
    return this.$$.ctx[15];
  }
  get open_file_upload() {
    return this.$$.ctx[25];
  }
  get load_files() {
    return this.$$.ctx[26];
  }
  get load_files_from_drop() {
    return this.$$.ctx[27];
  }
}
const {
  SvelteComponent: k6,
  check_outros: A6,
  claim_component: F6,
  claim_space: T6,
  create_component: I6,
  create_slot: $6,
  destroy_component: P6,
  detach: x6,
  get_all_dirty_from_scope: B6,
  get_slot_changes: O6,
  group_outros: R6,
  init: L6,
  insert_hydration: M6,
  mount_component: N6,
  safe_not_equal: U6,
  space: H6,
  transition_in: G6,
  transition_out: z6,
  update_slot_base: q6
} = window.__gradio__svelte__internal, { createEventDispatcher: V6 } = window.__gradio__svelte__internal, {
  SvelteComponent: n2,
  add_flush_callback: ac,
  append_hydration: Ie,
  attr: et,
  bind: sc,
  binding_callbacks: ma,
  bubble: oc,
  check_outros: Ji,
  children: ht,
  claim_component: An,
  claim_element: ze,
  claim_space: kt,
  claim_text: uo,
  create_component: Fn,
  create_slot: i2,
  destroy_component: Tn,
  destroy_each: r2,
  detach: ne,
  element: qe,
  empty: dn,
  ensure_array_like: lc,
  get_all_dirty_from_scope: a2,
  get_slot_changes: s2,
  get_svelte_dataset: ga,
  group_outros: Qi,
  init: o2,
  insert_hydration: Pe,
  listen: er,
  mount_component: In,
  noop: Mh,
  run_all: l2,
  safe_not_equal: u2,
  set_data: co,
  set_style: Ot,
  space: At,
  text: fo,
  toggle_class: uc,
  transition_in: _e,
  transition_out: Fe,
  update_slot_base: c2
} = window.__gradio__svelte__internal, { createEventDispatcher: f2, tick: Ss } = window.__gradio__svelte__internal;
function cc(n, e, t) {
  const i = n.slice();
  return i[44] = e[t][0], i[45] = e[t][1], i;
}
function fc(n) {
  let e, t, i, r, a = (
    /*show_fullscreen_button*/
    n[11] && hc(n)
  ), s = (
    /*metadata*/
    n[17] !== null && dc(n)
  );
  return i = new _n({
    props: { Icon: bf, label: "Remove Image" }
  }), i.$on(
    "click",
    /*click_handler_1*/
    n[36]
  ), {
    c() {
      a && a.c(), e = At(), s && s.c(), t = At(), Fn(i.$$.fragment);
    },
    l(o) {
      a && a.l(o), e = kt(o), s && s.l(o), t = kt(o), An(i.$$.fragment, o);
    },
    m(o, l) {
      a && a.m(o, l), Pe(o, e, l), s && s.m(o, l), Pe(o, t, l), In(i, o, l), r = !0;
    },
    p(o, l) {
      /*show_fullscreen_button*/
      o[11] ? a ? (a.p(o, l), l[0] & /*show_fullscreen_button*/
      2048 && _e(a, 1)) : (a = hc(o), a.c(), _e(a, 1), a.m(e.parentNode, e)) : a && (Qi(), Fe(a, 1, 1, () => {
        a = null;
      }), Ji()), /*metadata*/
      o[17] !== null ? s ? (s.p(o, l), l[0] & /*metadata*/
      131072 && _e(s, 1)) : (s = dc(o), s.c(), _e(s, 1), s.m(t.parentNode, t)) : s && (Qi(), Fe(s, 1, 1, () => {
        s = null;
      }), Ji());
    },
    i(o) {
      r || (_e(a), _e(s), _e(i.$$.fragment, o), r = !0);
    },
    o(o) {
      Fe(a), Fe(s), Fe(i.$$.fragment, o), r = !1;
    },
    d(o) {
      o && (ne(e), ne(t)), a && a.d(o), s && s.d(o), Tn(i, o);
    }
  };
}
function hc(n) {
  let e, t;
  return e = new If({
    props: { fullscreen: (
      /*fullscreen*/
      n[16]
    ) }
  }), e.$on(
    "fullscreen",
    /*fullscreen_handler*/
    n[34]
  ), {
    c() {
      Fn(e.$$.fragment);
    },
    l(i) {
      An(e.$$.fragment, i);
    },
    m(i, r) {
      In(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*fullscreen*/
      65536 && (a.fullscreen = /*fullscreen*/
      i[16]), e.$set(a);
    },
    i(i) {
      t || (_e(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Fe(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Tn(e, i);
    }
  };
}
function dc(n) {
  let e, t;
  return e = new _n({
    props: {
      Icon: vf,
      label: "View Metadata",
      "aria-label": "View and send image metadata"
    }
  }), e.$on(
    "click",
    /*click_handler*/
    n[35]
  ), {
    c() {
      Fn(e.$$.fragment);
    },
    l(i) {
      An(e.$$.fragment, i);
    },
    m(i, r) {
      In(e, i, r), t = !0;
    },
    p: Mh,
    i(i) {
      t || (_e(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Fe(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Tn(e, i);
    }
  };
}
function h2(n) {
  var r;
  let e, t, i = (
    /*value*/
    ((r = n[0]) == null ? void 0 : r.url) && fc(n)
  );
  return {
    c() {
      i && i.c(), e = dn();
    },
    l(a) {
      i && i.l(a), e = dn();
    },
    m(a, s) {
      i && i.m(a, s), Pe(a, e, s), t = !0;
    },
    p(a, s) {
      var o;
      /*value*/
      (o = a[0]) != null && o.url ? i ? (i.p(a, s), s[0] & /*value*/
      1 && _e(i, 1)) : (i = fc(a), i.c(), _e(i, 1), i.m(e.parentNode, e)) : i && (Qi(), Fe(i, 1, 1, () => {
        i = null;
      }), Ji());
    },
    i(a) {
      t || (_e(i), t = !0);
    },
    o(a) {
      Fe(i), t = !1;
    },
    d(a) {
      a && ne(e), i && i.d(a);
    }
  };
}
function _c(n) {
  let e;
  const t = (
    /*#slots*/
    n[33].default
  ), i = i2(
    t,
    n,
    /*$$scope*/
    n[42],
    null
  );
  return {
    c() {
      i && i.c();
    },
    l(r) {
      i && i.l(r);
    },
    m(r, a) {
      i && i.m(r, a), e = !0;
    },
    p(r, a) {
      i && i.p && (!e || a[1] & /*$$scope*/
      2048) && c2(
        i,
        t,
        r,
        /*$$scope*/
        r[42],
        e ? s2(
          t,
          /*$$scope*/
          r[42],
          a,
          null
        ) : a2(
          /*$$scope*/
          r[42]
        ),
        null
      );
    },
    i(r) {
      e || (_e(i, r), e = !0);
    },
    o(r) {
      Fe(i, r), e = !1;
    },
    d(r) {
      i && i.d(r);
    }
  };
}
function d2(n) {
  let e, t, i = (
    /*value*/
    n[0] === null && _c(n)
  );
  return {
    c() {
      i && i.c(), e = dn();
    },
    l(r) {
      i && i.l(r), e = dn();
    },
    m(r, a) {
      i && i.m(r, a), Pe(r, e, a), t = !0;
    },
    p(r, a) {
      /*value*/
      r[0] === null ? i ? (i.p(r, a), a[0] & /*value*/
      1 && _e(i, 1)) : (i = _c(r), i.c(), _e(i, 1), i.m(e.parentNode, e)) : i && (Qi(), Fe(i, 1, 1, () => {
        i = null;
      }), Ji());
    },
    i(r) {
      t || (_e(i), t = !0);
    },
    o(r) {
      Fe(i), t = !1;
    },
    d(r) {
      r && ne(e), i && i.d(r);
    }
  };
}
function pc(n) {
  let e, t, i, r, a;
  return t = new Lo({
    props: {
      src: (
        /*value*/
        n[0].url
      ),
      alt: (
        /*value*/
        n[0].alt_text
      )
    }
  }), {
    c() {
      e = qe("div"), Fn(t.$$.fragment), this.h();
    },
    l(s) {
      e = ze(s, "DIV", { class: !0 });
      var o = ht(e);
      An(t.$$.fragment, o), o.forEach(ne), this.h();
    },
    h() {
      et(e, "class", "image-frame svelte-g6oesc"), uc(
        e,
        "selectable",
        /*selectable*/
        n[5]
      );
    },
    m(s, o) {
      Pe(s, e, o), In(t, e, null), i = !0, r || (a = er(
        e,
        "click",
        /*handle_click*/
        n[25]
      ), r = !0);
    },
    p(s, o) {
      const l = {};
      o[0] & /*value*/
      1 && (l.src = /*value*/
      s[0].url), o[0] & /*value*/
      1 && (l.alt = /*value*/
      s[0].alt_text), t.$set(l), (!i || o[0] & /*selectable*/
      32) && uc(
        e,
        "selectable",
        /*selectable*/
        s[5]
      );
    },
    i(s) {
      i || (_e(t.$$.fragment, s), i = !0);
    },
    o(s) {
      Fe(t.$$.fragment, s), i = !1;
    },
    d(s) {
      s && ne(e), Tn(t), r = !1, a();
    }
  };
}
function mc(n) {
  let e, t, i, r = "X", a, s, o = "Image Metadata", l, c, u, f;
  function h(g, E) {
    return E[0] & /*filteredMetadata*/
    4194304 && (c = null), /*filteredMetadata*/
    g[22].error ? m2 : (c == null && (c = Object.keys(
      /*filteredMetadata*/
      g[22]
    ).length > 0), c ? p2 : _2);
  }
  let d = h(n, [-1, -1]), p = d(n);
  return {
    c() {
      e = qe("div"), t = qe("div"), i = qe("button"), i.textContent = r, a = At(), s = qe("h3"), s.textContent = o, l = At(), p.c(), this.h();
    },
    l(g) {
      e = ze(g, "DIV", { class: !0 });
      var E = ht(e);
      t = ze(E, "DIV", { class: !0 });
      var w = ht(t);
      i = ze(w, "BUTTON", { class: !0, "data-svelte-h": !0 }), ga(i) !== "svelte-1irq3m4" && (i.textContent = r), a = kt(w), s = ze(w, "H3", { class: !0, "data-svelte-h": !0 }), ga(s) !== "svelte-1tc7pig" && (s.textContent = o), l = kt(w), p.l(w), w.forEach(ne), E.forEach(ne), this.h();
    },
    h() {
      et(i, "class", "close-button svelte-g6oesc"), et(s, "class", "popup-title svelte-g6oesc"), et(t, "class", "popup-content svelte-g6oesc"), et(e, "class", "metadata-popup svelte-g6oesc"), Ot(e, "width", typeof /*popup_metadata_width*/
      n[14] == "number" ? `${Math.min(
        /*popup_metadata_width*/
        n[14],
        parseFloat(
          /*maxPopupWidth*/
          n[21]
        )
      )}px` : `min(${/*popup_metadata_width*/
      n[14]}, ${/*maxPopupWidth*/
      n[21]})`), Ot(e, "height", typeof /*popup_metadata_height*/
      n[15] == "number" ? `${/*popup_metadata_height*/
      n[15]}px` : (
        /*popup_metadata_height*/
        n[15]
      ));
    },
    m(g, E) {
      Pe(g, e, E), Ie(e, t), Ie(t, i), Ie(t, a), Ie(t, s), Ie(t, l), p.m(t, null), u || (f = er(
        i,
        "click",
        /*closePopup*/
        n[30]
      ), u = !0);
    },
    p(g, E) {
      d === (d = h(g, E)) && p ? p.p(g, E) : (p.d(1), p = d(g), p && (p.c(), p.m(t, null))), E[0] & /*popup_metadata_width, maxPopupWidth*/
      2113536 && Ot(e, "width", typeof /*popup_metadata_width*/
      g[14] == "number" ? `${Math.min(
        /*popup_metadata_width*/
        g[14],
        parseFloat(
          /*maxPopupWidth*/
          g[21]
        )
      )}px` : `min(${/*popup_metadata_width*/
      g[14]}, ${/*maxPopupWidth*/
      g[21]})`), E[0] & /*popup_metadata_height*/
      32768 && Ot(e, "height", typeof /*popup_metadata_height*/
      g[15] == "number" ? `${/*popup_metadata_height*/
      g[15]}px` : (
        /*popup_metadata_height*/
        g[15]
      ));
    },
    d(g) {
      g && ne(e), p.d(), u = !1, f();
    }
  };
}
function _2(n) {
  let e, t = "No custom metadata found.";
  return {
    c() {
      e = qe("p"), e.textContent = t, this.h();
    },
    l(i) {
      e = ze(i, "P", { class: !0, "data-svelte-h": !0 }), ga(e) !== "svelte-1qb2m81" && (e.textContent = t), this.h();
    },
    h() {
      et(e, "class", "no-metadata-message");
    },
    m(i, r) {
      Pe(i, e, r);
    },
    p: Mh,
    d(i) {
      i && ne(e);
    }
  };
}
function p2(n) {
  let e, t, i, r, a, s = "Load Metadata", o, l, c = lc(Object.entries(
    /*filteredMetadata*/
    n[22]
  )), u = [];
  for (let f = 0; f < c.length; f += 1)
    u[f] = bc(cc(n, c, f));
  return {
    c() {
      e = qe("div"), t = qe("table"), i = qe("tbody");
      for (let f = 0; f < u.length; f += 1)
        u[f].c();
      r = At(), a = qe("button"), a.textContent = s, this.h();
    },
    l(f) {
      e = ze(f, "DIV", { class: !0 });
      var h = ht(e);
      t = ze(h, "TABLE", { class: !0 });
      var d = ht(t);
      i = ze(d, "TBODY", {});
      var p = ht(i);
      for (let g = 0; g < u.length; g += 1)
        u[g].l(p);
      p.forEach(ne), d.forEach(ne), h.forEach(ne), r = kt(f), a = ze(f, "BUTTON", { class: !0, "data-svelte-h": !0 }), ga(a) !== "svelte-1uwkq18" && (a.textContent = s), this.h();
    },
    h() {
      et(t, "class", "metadata-table svelte-g6oesc"), et(e, "class", "metadata-table-container svelte-g6oesc"), et(a, "class", "load-metadata-button svelte-g6oesc");
    },
    m(f, h) {
      Pe(f, e, h), Ie(e, t), Ie(t, i);
      for (let d = 0; d < u.length; d += 1)
        u[d] && u[d].m(i, null);
      Pe(f, r, h), Pe(f, a, h), o || (l = er(
        a,
        "click",
        /*dispatchLoadMetadata*/
        n[29]
      ), o = !0);
    },
    p(f, h) {
      if (h[0] & /*filteredMetadata*/
      4194304) {
        c = lc(Object.entries(
          /*filteredMetadata*/
          f[22]
        ));
        let d;
        for (d = 0; d < c.length; d += 1) {
          const p = cc(f, c, d);
          u[d] ? u[d].p(p, h) : (u[d] = bc(p), u[d].c(), u[d].m(i, null));
        }
        for (; d < u.length; d += 1)
          u[d].d(1);
        u.length = c.length;
      }
    },
    d(f) {
      f && (ne(e), ne(r), ne(a)), r2(u, f), o = !1, l();
    }
  };
}
function m2(n) {
  let e, t = (
    /*filteredMetadata*/
    n[22].error + ""
  ), i;
  return {
    c() {
      e = qe("p"), i = fo(t);
    },
    l(r) {
      e = ze(r, "P", {});
      var a = ht(e);
      i = uo(a, t), a.forEach(ne);
    },
    m(r, a) {
      Pe(r, e, a), Ie(e, i);
    },
    p(r, a) {
      a[0] & /*filteredMetadata*/
      4194304 && t !== (t = /*filteredMetadata*/
      r[22].error + "") && co(i, t);
    },
    d(r) {
      r && ne(e);
    }
  };
}
function gc(n) {
  let e, t, i = (
    /*key*/
    n[44] + ""
  ), r, a, s, o = (
    /*val*/
    n[45] + ""
  ), l, c;
  return {
    c() {
      e = qe("tr"), t = qe("td"), r = fo(i), a = At(), s = qe("td"), l = fo(o), c = At(), this.h();
    },
    l(u) {
      e = ze(u, "TR", {});
      var f = ht(e);
      t = ze(f, "TD", { class: !0 });
      var h = ht(t);
      r = uo(h, i), h.forEach(ne), a = kt(f), s = ze(f, "TD", { class: !0 });
      var d = ht(s);
      l = uo(d, o), d.forEach(ne), c = kt(f), f.forEach(ne), this.h();
    },
    h() {
      et(t, "class", "metadata-label svelte-g6oesc"), et(s, "class", "metadata-value svelte-g6oesc");
    },
    m(u, f) {
      Pe(u, e, f), Ie(e, t), Ie(t, r), Ie(e, a), Ie(e, s), Ie(s, l), Ie(e, c);
    },
    p(u, f) {
      f[0] & /*filteredMetadata*/
      4194304 && i !== (i = /*key*/
      u[44] + "") && co(r, i), f[0] & /*filteredMetadata*/
      4194304 && o !== (o = /*val*/
      u[45] + "") && co(l, o);
    },
    d(u) {
      u && ne(e);
    }
  };
}
function bc(n) {
  let e, t = (
    /*val*/
    n[45] && gc(n)
  );
  return {
    c() {
      t && t.c(), e = dn();
    },
    l(i) {
      t && t.l(i), e = dn();
    },
    m(i, r) {
      t && t.m(i, r), Pe(i, e, r);
    },
    p(i, r) {
      /*val*/
      i[45] ? t ? t.p(i, r) : (t = gc(i), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(i) {
      i && ne(e), t && t.d(i);
    }
  };
}
function g2(n) {
  let e, t, i, r, a, s, o, l, c, u, f, h, d, p, g;
  e = new mf({
    props: {
      show_label: (
        /*show_label*/
        n[4]
      ),
      Icon: ko,
      label: (
        /*label*/
        n[3] || "Image"
      )
    }
  }), r = new Cf({
    props: {
      $$slots: { default: [h2] },
      $$scope: { ctx: n }
    }
  });
  function E(y) {
    n[38](y);
  }
  function w(y) {
    n[39](y);
  }
  let m = {
    hidden: (
      /*value*/
      n[0] !== null
    ),
    filetype: "image/*",
    root: (
      /*root*/
      n[6]
    ),
    max_file_size: (
      /*max_file_size*/
      n[8]
    ),
    disable_click: (
      /*value*/
      n[0] !== null
    ),
    upload: (
      /*upload*/
      n[9]
    ),
    stream_handler: (
      /*stream_handler*/
      n[10]
    ),
    aria_label: (
      /*i18n*/
      n[7]("image.drop_to_upload")
    ),
    $$slots: { default: [d2] },
    $$scope: { ctx: n }
  };
  /*uploading*/
  n[2] !== void 0 && (m.uploading = /*uploading*/
  n[2]), /*dragging*/
  n[1] !== void 0 && (m.dragging = /*dragging*/
  n[1]), o = new t2({ props: m }), n[37](o), ma.push(() => sc(o, "uploading", E)), ma.push(() => sc(o, "dragging", w)), o.$on(
    "load",
    /*handle_upload*/
    n[23]
  ), o.$on(
    "error",
    /*error_handler*/
    n[40]
  );
  let _ = (
    /*value*/
    n[0] !== null && pc(n)
  ), b = (
    /*showMetadataPopup*/
    n[19] && /*filteredMetadata*/
    n[22] !== null && mc(n)
  );
  return {
    c() {
      Fn(e.$$.fragment), t = At(), i = qe("div"), Fn(r.$$.fragment), a = At(), s = qe("div"), Fn(o.$$.fragment), u = At(), _ && _.c(), f = At(), b && b.c(), h = dn(), this.h();
    },
    l(y) {
      An(e.$$.fragment, y), t = kt(y), i = ze(y, "DIV", { "data-testid": !0, class: !0 });
      var D = ht(i);
      An(r.$$.fragment, D), a = kt(D), s = ze(D, "DIV", { class: !0 });
      var F = ht(s);
      An(o.$$.fragment, F), u = kt(F), _ && _.l(F), F.forEach(ne), D.forEach(ne), f = kt(y), b && b.l(y), h = dn(), this.h();
    },
    h() {
      et(s, "class", "upload-container svelte-g6oesc"), Ot(
        s,
        "width",
        /*value*/
        n[0] ? "auto" : "100%"
      ), et(i, "data-testid", "image"), et(i, "class", "image-container svelte-g6oesc"), Ot(
        i,
        "height",
        /*height*/
        n[12]
      ), Ot(
        i,
        "width",
        /*width*/
        n[13]
      );
    },
    m(y, D) {
      In(e, y, D), Pe(y, t, D), Pe(y, i, D), In(r, i, null), Ie(i, a), Ie(i, s), In(o, s, null), Ie(s, u), _ && _.m(s, null), n[41](i), Pe(y, f, D), b && b.m(y, D), Pe(y, h, D), d = !0, p || (g = [
        er(
          s,
          "dragover",
          /*on_drag_over*/
          n[26]
        ),
        er(
          s,
          "drop",
          /*on_drop*/
          n[27]
        )
      ], p = !0);
    },
    p(y, D) {
      const F = {};
      D[0] & /*show_label*/
      16 && (F.show_label = /*show_label*/
      y[4]), D[0] & /*label*/
      8 && (F.label = /*label*/
      y[3] || "Image"), e.$set(F);
      const x = {};
      D[0] & /*metadata, fullscreen, show_fullscreen_button, value*/
      198657 | D[1] & /*$$scope*/
      2048 && (x.$$scope = { dirty: D, ctx: y }), r.$set(x);
      const T = {};
      D[0] & /*value*/
      1 && (T.hidden = /*value*/
      y[0] !== null), D[0] & /*root*/
      64 && (T.root = /*root*/
      y[6]), D[0] & /*max_file_size*/
      256 && (T.max_file_size = /*max_file_size*/
      y[8]), D[0] & /*value*/
      1 && (T.disable_click = /*value*/
      y[0] !== null), D[0] & /*upload*/
      512 && (T.upload = /*upload*/
      y[9]), D[0] & /*stream_handler*/
      1024 && (T.stream_handler = /*stream_handler*/
      y[10]), D[0] & /*i18n*/
      128 && (T.aria_label = /*i18n*/
      y[7]("image.drop_to_upload")), D[0] & /*value*/
      1 | D[1] & /*$$scope*/
      2048 && (T.$$scope = { dirty: D, ctx: y }), !l && D[0] & /*uploading*/
      4 && (l = !0, T.uploading = /*uploading*/
      y[2], ac(() => l = !1)), !c && D[0] & /*dragging*/
      2 && (c = !0, T.dragging = /*dragging*/
      y[1], ac(() => c = !1)), o.$set(T), /*value*/
      y[0] !== null ? _ ? (_.p(y, D), D[0] & /*value*/
      1 && _e(_, 1)) : (_ = pc(y), _.c(), _e(_, 1), _.m(s, null)) : _ && (Qi(), Fe(_, 1, 1, () => {
        _ = null;
      }), Ji()), D[0] & /*value*/
      1 && Ot(
        s,
        "width",
        /*value*/
        y[0] ? "auto" : "100%"
      ), D[0] & /*height*/
      4096 && Ot(
        i,
        "height",
        /*height*/
        y[12]
      ), D[0] & /*width*/
      8192 && Ot(
        i,
        "width",
        /*width*/
        y[13]
      ), /*showMetadataPopup*/
      y[19] && /*filteredMetadata*/
      y[22] !== null ? b ? b.p(y, D) : (b = mc(y), b.c(), b.m(h.parentNode, h)) : b && (b.d(1), b = null);
    },
    i(y) {
      d || (_e(e.$$.fragment, y), _e(r.$$.fragment, y), _e(o.$$.fragment, y), _e(_), d = !0);
    },
    o(y) {
      Fe(e.$$.fragment, y), Fe(r.$$.fragment, y), Fe(o.$$.fragment, y), Fe(_), d = !1;
    },
    d(y) {
      y && (ne(t), ne(i), ne(f), ne(h)), Tn(e, y), Tn(r), n[37](null), Tn(o), _ && _.d(), n[41](null), b && b.d(y), p = !1, l2(g);
    }
  };
}
function b2(n, e, t) {
  let i, r, { $$slots: a = {}, $$scope: s } = e, { value: o = null } = e, { label: l = void 0 } = e, { show_label: c } = e, { selectable: u = !1 } = e, { root: f } = e, { i18n: h } = e, { max_file_size: d = null } = e, { upload: p } = e, { stream_handler: g } = e, { show_fullscreen_button: E = !0 } = e, { height: w = void 0 } = e, { width: m = void 0 } = e, { only_custom_metadata: _ = !0 } = e, { popup_metadata_width: b = 400 } = e, { popup_metadata_height: y = 300 } = e, D, { uploading: F = !1 } = e, { active_source: x = "upload" } = e, { fullscreen: T = !1 } = e, R = null, O = !1, L, { dragging: Z = !1 } = e;
  const z = f2();
  async function ge({ detail: k }) {
    t(0, o = k), await Ss(), z("upload"), z("change", o);
  }
  function G() {
    t(0, o = null), t(17, R = null), t(19, O = !1), z("clear"), z("change", null);
  }
  function ve(k) {
    let nt = Gf(k);
    nt && z("select", { index: nt, value: null });
  }
  function q(k) {
    k.preventDefault(), k.stopPropagation(), k.dataTransfer && (k.dataTransfer.dropEffect = "copy"), t(1, Z = !0);
  }
  async function P(k) {
    k.preventDefault(), k.stopPropagation(), t(1, Z = !1), o && (G(), await Ss()), t(31, x = "upload"), await Ss(), D.load_files_from_drop(k);
  }
  function le() {
    R !== null && t(19, O = !O);
  }
  function S() {
    R !== null && (z("load_metadata"), ee());
  }
  function ee() {
    t(19, O = !1);
  }
  function K(k) {
    oc.call(this, n, k);
  }
  const de = (k) => {
    le(), k.stopPropagation();
  }, I = (k) => {
    G(), k.stopPropagation();
  };
  function Ce(k) {
    ma[k ? "unshift" : "push"](() => {
      D = k, t(18, D);
    });
  }
  function $(k) {
    F = k, t(2, F);
  }
  function V(k) {
    Z = k, t(1, Z);
  }
  function J(k) {
    oc.call(this, n, k);
  }
  function se(k) {
    ma[k ? "unshift" : "push"](() => {
      L = k, t(20, L);
    });
  }
  return n.$$set = (k) => {
    "value" in k && t(0, o = k.value), "label" in k && t(3, l = k.label), "show_label" in k && t(4, c = k.show_label), "selectable" in k && t(5, u = k.selectable), "root" in k && t(6, f = k.root), "i18n" in k && t(7, h = k.i18n), "max_file_size" in k && t(8, d = k.max_file_size), "upload" in k && t(9, p = k.upload), "stream_handler" in k && t(10, g = k.stream_handler), "show_fullscreen_button" in k && t(11, E = k.show_fullscreen_button), "height" in k && t(12, w = k.height), "width" in k && t(13, m = k.width), "only_custom_metadata" in k && t(32, _ = k.only_custom_metadata), "popup_metadata_width" in k && t(14, b = k.popup_metadata_width), "popup_metadata_height" in k && t(15, y = k.popup_metadata_height), "uploading" in k && t(2, F = k.uploading), "active_source" in k && t(31, x = k.active_source), "fullscreen" in k && t(16, T = k.fullscreen), "dragging" in k && t(1, Z = k.dragging), "$$scope" in k && t(42, s = k.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*dragging*/
    2 && z("drag", Z), n.$$.dirty[0] & /*value*/
    1 | n.$$.dirty[1] & /*only_custom_metadata*/
    2 && (async (k) => {
      k ? k.metadata && Object.keys(k.metadata).length > 0 ? t(17, R = k.metadata) : t(17, R = await zf(k, _)) : t(17, R = null);
    })(o), n.$$.dirty[0] & /*metadata*/
    131072 | n.$$.dirty[1] & /*only_custom_metadata*/
    2 && t(22, i = _ ? Object.fromEntries(Object.entries(R || {}).filter(([k]) => !qf.has(k))) : R), n.$$.dirty[0] & /*width*/
    8192 && t(21, r = typeof m == "number" ? m - 20 : typeof m == "string" ? `calc(${m} - 20px)` : "380px");
  }, [
    o,
    Z,
    F,
    l,
    c,
    u,
    f,
    h,
    d,
    p,
    g,
    E,
    w,
    m,
    b,
    y,
    T,
    R,
    D,
    O,
    L,
    r,
    i,
    ge,
    G,
    ve,
    q,
    P,
    le,
    S,
    ee,
    x,
    _,
    a,
    K,
    de,
    I,
    Ce,
    $,
    V,
    J,
    se,
    s
  ];
}
class v2 extends n2 {
  constructor(e) {
    super(), o2(
      this,
      e,
      b2,
      g2,
      u2,
      {
        value: 0,
        label: 3,
        show_label: 4,
        selectable: 5,
        root: 6,
        i18n: 7,
        max_file_size: 8,
        upload: 9,
        stream_handler: 10,
        show_fullscreen_button: 11,
        height: 12,
        width: 13,
        only_custom_metadata: 32,
        popup_metadata_width: 14,
        popup_metadata_height: 15,
        uploading: 2,
        active_source: 31,
        fullscreen: 16,
        dragging: 1
      },
      null,
      [-1, -1]
    );
  }
}
function ii(n) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; n > 1e3 && t < e.length - 1; )
    n /= 1e3, t++;
  let i = e[t];
  return (Number.isInteger(n) ? n : n.toFixed(1)) + i;
}
const {
  SvelteComponent: y2,
  append_hydration: vt,
  attr: Y,
  children: ot,
  claim_element: w2,
  claim_svg_element: yt,
  component_subscribe: vc,
  detach: rt,
  element: D2,
  init: E2,
  insert_hydration: C2,
  noop: yc,
  safe_not_equal: S2,
  set_style: Or,
  svg_element: wt,
  toggle_class: wc
} = window.__gradio__svelte__internal, { onMount: k2 } = window.__gradio__svelte__internal;
function A2(n) {
  let e, t, i, r, a, s, o, l, c, u, f, h;
  return {
    c() {
      e = D2("div"), t = wt("svg"), i = wt("g"), r = wt("path"), a = wt("path"), s = wt("path"), o = wt("path"), l = wt("g"), c = wt("path"), u = wt("path"), f = wt("path"), h = wt("path"), this.h();
    },
    l(d) {
      e = w2(d, "DIV", { class: !0 });
      var p = ot(e);
      t = yt(p, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var g = ot(t);
      i = yt(g, "g", { style: !0 });
      var E = ot(i);
      r = yt(E, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ot(r).forEach(rt), a = yt(E, "path", { d: !0, fill: !0, class: !0 }), ot(a).forEach(rt), s = yt(E, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ot(s).forEach(rt), o = yt(E, "path", { d: !0, fill: !0, class: !0 }), ot(o).forEach(rt), E.forEach(rt), l = yt(g, "g", { style: !0 });
      var w = ot(l);
      c = yt(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ot(c).forEach(rt), u = yt(w, "path", { d: !0, fill: !0, class: !0 }), ot(u).forEach(rt), f = yt(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ot(f).forEach(rt), h = yt(w, "path", { d: !0, fill: !0, class: !0 }), ot(h).forEach(rt), w.forEach(rt), g.forEach(rt), p.forEach(rt), this.h();
    },
    h() {
      Y(r, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), Y(r, "fill", "#FF7C00"), Y(r, "fill-opacity", "0.4"), Y(r, "class", "svelte-43sxxs"), Y(a, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), Y(a, "fill", "#FF7C00"), Y(a, "class", "svelte-43sxxs"), Y(s, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), Y(s, "fill", "#FF7C00"), Y(s, "fill-opacity", "0.4"), Y(s, "class", "svelte-43sxxs"), Y(o, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), Y(o, "fill", "#FF7C00"), Y(o, "class", "svelte-43sxxs"), Or(i, "transform", "translate(" + /*$top*/
      n[1][0] + "px, " + /*$top*/
      n[1][1] + "px)"), Y(c, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), Y(c, "fill", "#FF7C00"), Y(c, "fill-opacity", "0.4"), Y(c, "class", "svelte-43sxxs"), Y(u, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), Y(u, "fill", "#FF7C00"), Y(u, "class", "svelte-43sxxs"), Y(f, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), Y(f, "fill", "#FF7C00"), Y(f, "fill-opacity", "0.4"), Y(f, "class", "svelte-43sxxs"), Y(h, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), Y(h, "fill", "#FF7C00"), Y(h, "class", "svelte-43sxxs"), Or(l, "transform", "translate(" + /*$bottom*/
      n[2][0] + "px, " + /*$bottom*/
      n[2][1] + "px)"), Y(t, "viewBox", "-1200 -1200 3000 3000"), Y(t, "fill", "none"), Y(t, "xmlns", "http://www.w3.org/2000/svg"), Y(t, "class", "svelte-43sxxs"), Y(e, "class", "svelte-43sxxs"), wc(
        e,
        "margin",
        /*margin*/
        n[0]
      );
    },
    m(d, p) {
      C2(d, e, p), vt(e, t), vt(t, i), vt(i, r), vt(i, a), vt(i, s), vt(i, o), vt(t, l), vt(l, c), vt(l, u), vt(l, f), vt(l, h);
    },
    p(d, [p]) {
      p & /*$top*/
      2 && Or(i, "transform", "translate(" + /*$top*/
      d[1][0] + "px, " + /*$top*/
      d[1][1] + "px)"), p & /*$bottom*/
      4 && Or(l, "transform", "translate(" + /*$bottom*/
      d[2][0] + "px, " + /*$bottom*/
      d[2][1] + "px)"), p & /*margin*/
      1 && wc(
        e,
        "margin",
        /*margin*/
        d[0]
      );
    },
    i: yc,
    o: yc,
    d(d) {
      d && rt(e);
    }
  };
}
function F2(n, e, t) {
  let i, r, { margin: a = !0 } = e;
  const s = Uu([0, 0]);
  vc(n, s, (h) => t(1, i = h));
  const o = Uu([0, 0]);
  vc(n, o, (h) => t(2, r = h));
  let l;
  async function c() {
    await Promise.all([s.set([125, 140]), o.set([-125, -140])]), await Promise.all([s.set([-125, 140]), o.set([125, -140])]), await Promise.all([s.set([-125, 0]), o.set([125, -0])]), await Promise.all([s.set([125, 0]), o.set([-125, 0])]);
  }
  async function u() {
    await c(), l || u();
  }
  async function f() {
    await Promise.all([s.set([125, 0]), o.set([-125, 0])]), u();
  }
  return k2(() => (f(), () => l = !0)), n.$$set = (h) => {
    "margin" in h && t(0, a = h.margin);
  }, [a, i, r, s, o];
}
class T2 extends y2 {
  constructor(e) {
    super(), E2(this, e, F2, A2, S2, { margin: 0 });
  }
}
const {
  SvelteComponent: I2,
  append_hydration: En,
  attr: Ft,
  binding_callbacks: Dc,
  check_outros: ho,
  children: Nt,
  claim_component: Nh,
  claim_element: Ut,
  claim_space: ut,
  claim_text: pe,
  create_component: Uh,
  create_slot: Hh,
  destroy_component: Gh,
  destroy_each: zh,
  detach: N,
  element: Ht,
  empty: dt,
  ensure_array_like: ba,
  get_all_dirty_from_scope: qh,
  get_slot_changes: Vh,
  group_outros: _o,
  init: $2,
  insert_hydration: H,
  mount_component: jh,
  noop: po,
  safe_not_equal: P2,
  set_data: _t,
  set_style: fn,
  space: ct,
  text: me,
  toggle_class: lt,
  transition_in: Ct,
  transition_out: Gt,
  update_slot_base: Wh
} = window.__gradio__svelte__internal, { tick: x2 } = window.__gradio__svelte__internal, { onDestroy: B2 } = window.__gradio__svelte__internal, { createEventDispatcher: O2 } = window.__gradio__svelte__internal, R2 = (n) => ({}), Ec = (n) => ({}), L2 = (n) => ({}), Cc = (n) => ({});
function Sc(n, e, t) {
  const i = n.slice();
  return i[40] = e[t], i[42] = t, i;
}
function kc(n, e, t) {
  const i = n.slice();
  return i[40] = e[t], i;
}
function M2(n) {
  let e, t, i, r, a = (
    /*i18n*/
    n[1]("common.error") + ""
  ), s, o, l;
  t = new _n({
    props: {
      Icon: bf,
      label: (
        /*i18n*/
        n[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    n[32]
  );
  const c = (
    /*#slots*/
    n[30].error
  ), u = Hh(
    c,
    n,
    /*$$scope*/
    n[29],
    Ec
  );
  return {
    c() {
      e = Ht("div"), Uh(t.$$.fragment), i = ct(), r = Ht("span"), s = me(a), o = ct(), u && u.c(), this.h();
    },
    l(f) {
      e = Ut(f, "DIV", { class: !0 });
      var h = Nt(e);
      Nh(t.$$.fragment, h), h.forEach(N), i = ut(f), r = Ut(f, "SPAN", { class: !0 });
      var d = Nt(r);
      s = pe(d, a), d.forEach(N), o = ut(f), u && u.l(f), this.h();
    },
    h() {
      Ft(e, "class", "clear-status svelte-17v219f"), Ft(r, "class", "error svelte-17v219f");
    },
    m(f, h) {
      H(f, e, h), jh(t, e, null), H(f, i, h), H(f, r, h), En(r, s), H(f, o, h), u && u.m(f, h), l = !0;
    },
    p(f, h) {
      const d = {};
      h[0] & /*i18n*/
      2 && (d.label = /*i18n*/
      f[1]("common.clear")), t.$set(d), (!l || h[0] & /*i18n*/
      2) && a !== (a = /*i18n*/
      f[1]("common.error") + "") && _t(s, a), u && u.p && (!l || h[0] & /*$$scope*/
      536870912) && Wh(
        u,
        c,
        f,
        /*$$scope*/
        f[29],
        l ? Vh(
          c,
          /*$$scope*/
          f[29],
          h,
          R2
        ) : qh(
          /*$$scope*/
          f[29]
        ),
        Ec
      );
    },
    i(f) {
      l || (Ct(t.$$.fragment, f), Ct(u, f), l = !0);
    },
    o(f) {
      Gt(t.$$.fragment, f), Gt(u, f), l = !1;
    },
    d(f) {
      f && (N(e), N(i), N(r), N(o)), Gh(t), u && u.d(f);
    }
  };
}
function N2(n) {
  let e, t, i, r, a, s, o, l, c, u = (
    /*variant*/
    n[8] === "default" && /*show_eta_bar*/
    n[18] && /*show_progress*/
    n[6] === "full" && Ac(n)
  );
  function f(_, b) {
    if (
      /*progress*/
      _[7]
    ) return G2;
    if (
      /*queue_position*/
      _[2] !== null && /*queue_size*/
      _[3] !== void 0 && /*queue_position*/
      _[2] >= 0
    ) return H2;
    if (
      /*queue_position*/
      _[2] === 0
    ) return U2;
  }
  let h = f(n), d = h && h(n), p = (
    /*timer*/
    n[5] && Ic(n)
  );
  const g = [j2, V2], E = [];
  function w(_, b) {
    return (
      /*last_progress_level*/
      _[15] != null ? 0 : (
        /*show_progress*/
        _[6] === "full" ? 1 : -1
      )
    );
  }
  ~(a = w(n)) && (s = E[a] = g[a](n));
  let m = !/*timer*/
  n[5] && Lc(n);
  return {
    c() {
      u && u.c(), e = ct(), t = Ht("div"), d && d.c(), i = ct(), p && p.c(), r = ct(), s && s.c(), o = ct(), m && m.c(), l = dt(), this.h();
    },
    l(_) {
      u && u.l(_), e = ut(_), t = Ut(_, "DIV", { class: !0 });
      var b = Nt(t);
      d && d.l(b), i = ut(b), p && p.l(b), b.forEach(N), r = ut(_), s && s.l(_), o = ut(_), m && m.l(_), l = dt(), this.h();
    },
    h() {
      Ft(t, "class", "progress-text svelte-17v219f"), lt(
        t,
        "meta-text-center",
        /*variant*/
        n[8] === "center"
      ), lt(
        t,
        "meta-text",
        /*variant*/
        n[8] === "default"
      );
    },
    m(_, b) {
      u && u.m(_, b), H(_, e, b), H(_, t, b), d && d.m(t, null), En(t, i), p && p.m(t, null), H(_, r, b), ~a && E[a].m(_, b), H(_, o, b), m && m.m(_, b), H(_, l, b), c = !0;
    },
    p(_, b) {
      /*variant*/
      _[8] === "default" && /*show_eta_bar*/
      _[18] && /*show_progress*/
      _[6] === "full" ? u ? u.p(_, b) : (u = Ac(_), u.c(), u.m(e.parentNode, e)) : u && (u.d(1), u = null), h === (h = f(_)) && d ? d.p(_, b) : (d && d.d(1), d = h && h(_), d && (d.c(), d.m(t, i))), /*timer*/
      _[5] ? p ? p.p(_, b) : (p = Ic(_), p.c(), p.m(t, null)) : p && (p.d(1), p = null), (!c || b[0] & /*variant*/
      256) && lt(
        t,
        "meta-text-center",
        /*variant*/
        _[8] === "center"
      ), (!c || b[0] & /*variant*/
      256) && lt(
        t,
        "meta-text",
        /*variant*/
        _[8] === "default"
      );
      let y = a;
      a = w(_), a === y ? ~a && E[a].p(_, b) : (s && (_o(), Gt(E[y], 1, 1, () => {
        E[y] = null;
      }), ho()), ~a ? (s = E[a], s ? s.p(_, b) : (s = E[a] = g[a](_), s.c()), Ct(s, 1), s.m(o.parentNode, o)) : s = null), /*timer*/
      _[5] ? m && (_o(), Gt(m, 1, 1, () => {
        m = null;
      }), ho()) : m ? (m.p(_, b), b[0] & /*timer*/
      32 && Ct(m, 1)) : (m = Lc(_), m.c(), Ct(m, 1), m.m(l.parentNode, l));
    },
    i(_) {
      c || (Ct(s), Ct(m), c = !0);
    },
    o(_) {
      Gt(s), Gt(m), c = !1;
    },
    d(_) {
      _ && (N(e), N(t), N(r), N(o), N(l)), u && u.d(_), d && d.d(), p && p.d(), ~a && E[a].d(_), m && m.d(_);
    }
  };
}
function Ac(n) {
  let e, t = `translateX(${/*eta_level*/
  (n[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Ht("div"), this.h();
    },
    l(i) {
      e = Ut(i, "DIV", { class: !0 }), Nt(e).forEach(N), this.h();
    },
    h() {
      Ft(e, "class", "eta-bar svelte-17v219f"), fn(e, "transform", t);
    },
    m(i, r) {
      H(i, e, r);
    },
    p(i, r) {
      r[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (i[17] || 0) * 100 - 100}%)`) && fn(e, "transform", t);
    },
    d(i) {
      i && N(e);
    }
  };
}
function U2(n) {
  let e;
  return {
    c() {
      e = me("processing |");
    },
    l(t) {
      e = pe(t, "processing |");
    },
    m(t, i) {
      H(t, e, i);
    },
    p: po,
    d(t) {
      t && N(e);
    }
  };
}
function H2(n) {
  let e, t = (
    /*queue_position*/
    n[2] + 1 + ""
  ), i, r, a, s;
  return {
    c() {
      e = me("queue: "), i = me(t), r = me("/"), a = me(
        /*queue_size*/
        n[3]
      ), s = me(" |");
    },
    l(o) {
      e = pe(o, "queue: "), i = pe(o, t), r = pe(o, "/"), a = pe(
        o,
        /*queue_size*/
        n[3]
      ), s = pe(o, " |");
    },
    m(o, l) {
      H(o, e, l), H(o, i, l), H(o, r, l), H(o, a, l), H(o, s, l);
    },
    p(o, l) {
      l[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      o[2] + 1 + "") && _t(i, t), l[0] & /*queue_size*/
      8 && _t(
        a,
        /*queue_size*/
        o[3]
      );
    },
    d(o) {
      o && (N(e), N(i), N(r), N(a), N(s));
    }
  };
}
function G2(n) {
  let e, t = ba(
    /*progress*/
    n[7]
  ), i = [];
  for (let r = 0; r < t.length; r += 1)
    i[r] = Tc(kc(n, t, r));
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      e = dt();
    },
    l(r) {
      for (let a = 0; a < i.length; a += 1)
        i[a].l(r);
      e = dt();
    },
    m(r, a) {
      for (let s = 0; s < i.length; s += 1)
        i[s] && i[s].m(r, a);
      H(r, e, a);
    },
    p(r, a) {
      if (a[0] & /*progress*/
      128) {
        t = ba(
          /*progress*/
          r[7]
        );
        let s;
        for (s = 0; s < t.length; s += 1) {
          const o = kc(r, t, s);
          i[s] ? i[s].p(o, a) : (i[s] = Tc(o), i[s].c(), i[s].m(e.parentNode, e));
        }
        for (; s < i.length; s += 1)
          i[s].d(1);
        i.length = t.length;
      }
    },
    d(r) {
      r && N(e), zh(i, r);
    }
  };
}
function Fc(n) {
  let e, t = (
    /*p*/
    n[40].unit + ""
  ), i, r, a = " ", s;
  function o(u, f) {
    return (
      /*p*/
      u[40].length != null ? q2 : z2
    );
  }
  let l = o(n), c = l(n);
  return {
    c() {
      c.c(), e = ct(), i = me(t), r = me(" | "), s = me(a);
    },
    l(u) {
      c.l(u), e = ut(u), i = pe(u, t), r = pe(u, " | "), s = pe(u, a);
    },
    m(u, f) {
      c.m(u, f), H(u, e, f), H(u, i, f), H(u, r, f), H(u, s, f);
    },
    p(u, f) {
      l === (l = o(u)) && c ? c.p(u, f) : (c.d(1), c = l(u), c && (c.c(), c.m(e.parentNode, e))), f[0] & /*progress*/
      128 && t !== (t = /*p*/
      u[40].unit + "") && _t(i, t);
    },
    d(u) {
      u && (N(e), N(i), N(r), N(s)), c.d(u);
    }
  };
}
function z2(n) {
  let e = ii(
    /*p*/
    n[40].index || 0
  ) + "", t;
  return {
    c() {
      t = me(e);
    },
    l(i) {
      t = pe(i, e);
    },
    m(i, r) {
      H(i, t, r);
    },
    p(i, r) {
      r[0] & /*progress*/
      128 && e !== (e = ii(
        /*p*/
        i[40].index || 0
      ) + "") && _t(t, e);
    },
    d(i) {
      i && N(t);
    }
  };
}
function q2(n) {
  let e = ii(
    /*p*/
    n[40].index || 0
  ) + "", t, i, r = ii(
    /*p*/
    n[40].length
  ) + "", a;
  return {
    c() {
      t = me(e), i = me("/"), a = me(r);
    },
    l(s) {
      t = pe(s, e), i = pe(s, "/"), a = pe(s, r);
    },
    m(s, o) {
      H(s, t, o), H(s, i, o), H(s, a, o);
    },
    p(s, o) {
      o[0] & /*progress*/
      128 && e !== (e = ii(
        /*p*/
        s[40].index || 0
      ) + "") && _t(t, e), o[0] & /*progress*/
      128 && r !== (r = ii(
        /*p*/
        s[40].length
      ) + "") && _t(a, r);
    },
    d(s) {
      s && (N(t), N(i), N(a));
    }
  };
}
function Tc(n) {
  let e, t = (
    /*p*/
    n[40].index != null && Fc(n)
  );
  return {
    c() {
      t && t.c(), e = dt();
    },
    l(i) {
      t && t.l(i), e = dt();
    },
    m(i, r) {
      t && t.m(i, r), H(i, e, r);
    },
    p(i, r) {
      /*p*/
      i[40].index != null ? t ? t.p(i, r) : (t = Fc(i), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(i) {
      i && N(e), t && t.d(i);
    }
  };
}
function Ic(n) {
  let e, t = (
    /*eta*/
    n[0] ? `/${/*formatted_eta*/
    n[19]}` : ""
  ), i, r;
  return {
    c() {
      e = me(
        /*formatted_timer*/
        n[20]
      ), i = me(t), r = me("s");
    },
    l(a) {
      e = pe(
        a,
        /*formatted_timer*/
        n[20]
      ), i = pe(a, t), r = pe(a, "s");
    },
    m(a, s) {
      H(a, e, s), H(a, i, s), H(a, r, s);
    },
    p(a, s) {
      s[0] & /*formatted_timer*/
      1048576 && _t(
        e,
        /*formatted_timer*/
        a[20]
      ), s[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      a[0] ? `/${/*formatted_eta*/
      a[19]}` : "") && _t(i, t);
    },
    d(a) {
      a && (N(e), N(i), N(r));
    }
  };
}
function V2(n) {
  let e, t;
  return e = new T2({
    props: { margin: (
      /*variant*/
      n[8] === "default"
    ) }
  }), {
    c() {
      Uh(e.$$.fragment);
    },
    l(i) {
      Nh(e.$$.fragment, i);
    },
    m(i, r) {
      jh(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*variant*/
      256 && (a.margin = /*variant*/
      i[8] === "default"), e.$set(a);
    },
    i(i) {
      t || (Ct(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Gt(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Gh(e, i);
    }
  };
}
function j2(n) {
  let e, t, i, r, a, s = `${/*last_progress_level*/
  n[15] * 100}%`, o = (
    /*progress*/
    n[7] != null && $c(n)
  );
  return {
    c() {
      e = Ht("div"), t = Ht("div"), o && o.c(), i = ct(), r = Ht("div"), a = Ht("div"), this.h();
    },
    l(l) {
      e = Ut(l, "DIV", { class: !0 });
      var c = Nt(e);
      t = Ut(c, "DIV", { class: !0 });
      var u = Nt(t);
      o && o.l(u), u.forEach(N), i = ut(c), r = Ut(c, "DIV", { class: !0 });
      var f = Nt(r);
      a = Ut(f, "DIV", { class: !0 }), Nt(a).forEach(N), f.forEach(N), c.forEach(N), this.h();
    },
    h() {
      Ft(t, "class", "progress-level-inner svelte-17v219f"), Ft(a, "class", "progress-bar svelte-17v219f"), fn(a, "width", s), Ft(r, "class", "progress-bar-wrap svelte-17v219f"), Ft(e, "class", "progress-level svelte-17v219f");
    },
    m(l, c) {
      H(l, e, c), En(e, t), o && o.m(t, null), En(e, i), En(e, r), En(r, a), n[31](a);
    },
    p(l, c) {
      /*progress*/
      l[7] != null ? o ? o.p(l, c) : (o = $c(l), o.c(), o.m(t, null)) : o && (o.d(1), o = null), c[0] & /*last_progress_level*/
      32768 && s !== (s = `${/*last_progress_level*/
      l[15] * 100}%`) && fn(a, "width", s);
    },
    i: po,
    o: po,
    d(l) {
      l && N(e), o && o.d(), n[31](null);
    }
  };
}
function $c(n) {
  let e, t = ba(
    /*progress*/
    n[7]
  ), i = [];
  for (let r = 0; r < t.length; r += 1)
    i[r] = Rc(Sc(n, t, r));
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      e = dt();
    },
    l(r) {
      for (let a = 0; a < i.length; a += 1)
        i[a].l(r);
      e = dt();
    },
    m(r, a) {
      for (let s = 0; s < i.length; s += 1)
        i[s] && i[s].m(r, a);
      H(r, e, a);
    },
    p(r, a) {
      if (a[0] & /*progress_level, progress*/
      16512) {
        t = ba(
          /*progress*/
          r[7]
        );
        let s;
        for (s = 0; s < t.length; s += 1) {
          const o = Sc(r, t, s);
          i[s] ? i[s].p(o, a) : (i[s] = Rc(o), i[s].c(), i[s].m(e.parentNode, e));
        }
        for (; s < i.length; s += 1)
          i[s].d(1);
        i.length = t.length;
      }
    },
    d(r) {
      r && N(e), zh(i, r);
    }
  };
}
function Pc(n) {
  let e, t, i, r, a = (
    /*i*/
    n[42] !== 0 && W2()
  ), s = (
    /*p*/
    n[40].desc != null && xc(n)
  ), o = (
    /*p*/
    n[40].desc != null && /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[42]
    ] != null && Bc()
  ), l = (
    /*progress_level*/
    n[14] != null && Oc(n)
  );
  return {
    c() {
      a && a.c(), e = ct(), s && s.c(), t = ct(), o && o.c(), i = ct(), l && l.c(), r = dt();
    },
    l(c) {
      a && a.l(c), e = ut(c), s && s.l(c), t = ut(c), o && o.l(c), i = ut(c), l && l.l(c), r = dt();
    },
    m(c, u) {
      a && a.m(c, u), H(c, e, u), s && s.m(c, u), H(c, t, u), o && o.m(c, u), H(c, i, u), l && l.m(c, u), H(c, r, u);
    },
    p(c, u) {
      /*p*/
      c[40].desc != null ? s ? s.p(c, u) : (s = xc(c), s.c(), s.m(t.parentNode, t)) : s && (s.d(1), s = null), /*p*/
      c[40].desc != null && /*progress_level*/
      c[14] && /*progress_level*/
      c[14][
        /*i*/
        c[42]
      ] != null ? o || (o = Bc(), o.c(), o.m(i.parentNode, i)) : o && (o.d(1), o = null), /*progress_level*/
      c[14] != null ? l ? l.p(c, u) : (l = Oc(c), l.c(), l.m(r.parentNode, r)) : l && (l.d(1), l = null);
    },
    d(c) {
      c && (N(e), N(t), N(i), N(r)), a && a.d(c), s && s.d(c), o && o.d(c), l && l.d(c);
    }
  };
}
function W2(n) {
  let e;
  return {
    c() {
      e = me(" /");
    },
    l(t) {
      e = pe(t, " /");
    },
    m(t, i) {
      H(t, e, i);
    },
    d(t) {
      t && N(e);
    }
  };
}
function xc(n) {
  let e = (
    /*p*/
    n[40].desc + ""
  ), t;
  return {
    c() {
      t = me(e);
    },
    l(i) {
      t = pe(i, e);
    },
    m(i, r) {
      H(i, t, r);
    },
    p(i, r) {
      r[0] & /*progress*/
      128 && e !== (e = /*p*/
      i[40].desc + "") && _t(t, e);
    },
    d(i) {
      i && N(t);
    }
  };
}
function Bc(n) {
  let e;
  return {
    c() {
      e = me("-");
    },
    l(t) {
      e = pe(t, "-");
    },
    m(t, i) {
      H(t, e, i);
    },
    d(t) {
      t && N(e);
    }
  };
}
function Oc(n) {
  let e = (100 * /*progress_level*/
  (n[14][
    /*i*/
    n[42]
  ] || 0)).toFixed(1) + "", t, i;
  return {
    c() {
      t = me(e), i = me("%");
    },
    l(r) {
      t = pe(r, e), i = pe(r, "%");
    },
    m(r, a) {
      H(r, t, a), H(r, i, a);
    },
    p(r, a) {
      a[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (r[14][
        /*i*/
        r[42]
      ] || 0)).toFixed(1) + "") && _t(t, e);
    },
    d(r) {
      r && (N(t), N(i));
    }
  };
}
function Rc(n) {
  let e, t = (
    /*p*/
    (n[40].desc != null || /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[42]
    ] != null) && Pc(n)
  );
  return {
    c() {
      t && t.c(), e = dt();
    },
    l(i) {
      t && t.l(i), e = dt();
    },
    m(i, r) {
      t && t.m(i, r), H(i, e, r);
    },
    p(i, r) {
      /*p*/
      i[40].desc != null || /*progress_level*/
      i[14] && /*progress_level*/
      i[14][
        /*i*/
        i[42]
      ] != null ? t ? t.p(i, r) : (t = Pc(i), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(i) {
      i && N(e), t && t.d(i);
    }
  };
}
function Lc(n) {
  let e, t, i, r;
  const a = (
    /*#slots*/
    n[30]["additional-loading-text"]
  ), s = Hh(
    a,
    n,
    /*$$scope*/
    n[29],
    Cc
  );
  return {
    c() {
      e = Ht("p"), t = me(
        /*loading_text*/
        n[9]
      ), i = ct(), s && s.c(), this.h();
    },
    l(o) {
      e = Ut(o, "P", { class: !0 });
      var l = Nt(e);
      t = pe(
        l,
        /*loading_text*/
        n[9]
      ), l.forEach(N), i = ut(o), s && s.l(o), this.h();
    },
    h() {
      Ft(e, "class", "loading svelte-17v219f");
    },
    m(o, l) {
      H(o, e, l), En(e, t), H(o, i, l), s && s.m(o, l), r = !0;
    },
    p(o, l) {
      (!r || l[0] & /*loading_text*/
      512) && _t(
        t,
        /*loading_text*/
        o[9]
      ), s && s.p && (!r || l[0] & /*$$scope*/
      536870912) && Wh(
        s,
        a,
        o,
        /*$$scope*/
        o[29],
        r ? Vh(
          a,
          /*$$scope*/
          o[29],
          l,
          L2
        ) : qh(
          /*$$scope*/
          o[29]
        ),
        Cc
      );
    },
    i(o) {
      r || (Ct(s, o), r = !0);
    },
    o(o) {
      Gt(s, o), r = !1;
    },
    d(o) {
      o && (N(e), N(i)), s && s.d(o);
    }
  };
}
function X2(n) {
  let e, t, i, r, a;
  const s = [N2, M2], o = [];
  function l(c, u) {
    return (
      /*status*/
      c[4] === "pending" ? 0 : (
        /*status*/
        c[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = l(n)) && (i = o[t] = s[t](n)), {
    c() {
      e = Ht("div"), i && i.c(), this.h();
    },
    l(c) {
      e = Ut(c, "DIV", { class: !0 });
      var u = Nt(e);
      i && i.l(u), u.forEach(N), this.h();
    },
    h() {
      Ft(e, "class", r = "wrap " + /*variant*/
      n[8] + " " + /*show_progress*/
      n[6] + " svelte-17v219f"), lt(e, "hide", !/*status*/
      n[4] || /*status*/
      n[4] === "complete" || /*show_progress*/
      n[6] === "hidden" || /*status*/
      n[4] == "streaming"), lt(
        e,
        "translucent",
        /*variant*/
        n[8] === "center" && /*status*/
        (n[4] === "pending" || /*status*/
        n[4] === "error") || /*translucent*/
        n[11] || /*show_progress*/
        n[6] === "minimal"
      ), lt(
        e,
        "generating",
        /*status*/
        n[4] === "generating" && /*show_progress*/
        n[6] === "full"
      ), lt(
        e,
        "border",
        /*border*/
        n[12]
      ), fn(
        e,
        "position",
        /*absolute*/
        n[10] ? "absolute" : "static"
      ), fn(
        e,
        "padding",
        /*absolute*/
        n[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(c, u) {
      H(c, e, u), ~t && o[t].m(e, null), n[33](e), a = !0;
    },
    p(c, u) {
      let f = t;
      t = l(c), t === f ? ~t && o[t].p(c, u) : (i && (_o(), Gt(o[f], 1, 1, () => {
        o[f] = null;
      }), ho()), ~t ? (i = o[t], i ? i.p(c, u) : (i = o[t] = s[t](c), i.c()), Ct(i, 1), i.m(e, null)) : i = null), (!a || u[0] & /*variant, show_progress*/
      320 && r !== (r = "wrap " + /*variant*/
      c[8] + " " + /*show_progress*/
      c[6] + " svelte-17v219f")) && Ft(e, "class", r), (!a || u[0] & /*variant, show_progress, status, show_progress*/
      336) && lt(e, "hide", !/*status*/
      c[4] || /*status*/
      c[4] === "complete" || /*show_progress*/
      c[6] === "hidden" || /*status*/
      c[4] == "streaming"), (!a || u[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && lt(
        e,
        "translucent",
        /*variant*/
        c[8] === "center" && /*status*/
        (c[4] === "pending" || /*status*/
        c[4] === "error") || /*translucent*/
        c[11] || /*show_progress*/
        c[6] === "minimal"
      ), (!a || u[0] & /*variant, show_progress, status, show_progress*/
      336) && lt(
        e,
        "generating",
        /*status*/
        c[4] === "generating" && /*show_progress*/
        c[6] === "full"
      ), (!a || u[0] & /*variant, show_progress, border*/
      4416) && lt(
        e,
        "border",
        /*border*/
        c[12]
      ), u[0] & /*absolute*/
      1024 && fn(
        e,
        "position",
        /*absolute*/
        c[10] ? "absolute" : "static"
      ), u[0] & /*absolute*/
      1024 && fn(
        e,
        "padding",
        /*absolute*/
        c[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(c) {
      a || (Ct(i), a = !0);
    },
    o(c) {
      Gt(i), a = !1;
    },
    d(c) {
      c && N(e), ~t && o[t].d(), n[33](null);
    }
  };
}
let Rr = [], ks = !1;
const Y2 = typeof window < "u", Xh = Y2 ? window.requestAnimationFrame : (n) => {
};
async function Z2(n, e = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && e !== !0)) {
    if (Rr.push(n), !ks) ks = !0;
    else return;
    await x2(), Xh(() => {
      let t = [0, 0];
      for (let i = 0; i < Rr.length; i++) {
        const a = Rr[i].getBoundingClientRect();
        (i === 0 || a.top + window.scrollY <= t[0]) && (t[0] = a.top + window.scrollY, t[1] = i);
      }
      window.scrollTo({ top: t[0] - 20, behavior: "smooth" }), ks = !1, Rr = [];
    });
  }
}
function K2(n, e, t) {
  let i, { $$slots: r = {}, $$scope: a } = e;
  const s = O2();
  let { i18n: o } = e, { eta: l = null } = e, { queue_position: c } = e, { queue_size: u } = e, { status: f } = e, { scroll_to_output: h = !1 } = e, { timer: d = !0 } = e, { show_progress: p = "full" } = e, { message: g = null } = e, { progress: E = null } = e, { variant: w = "default" } = e, { loading_text: m = "Loading..." } = e, { absolute: _ = !0 } = e, { translucent: b = !1 } = e, { border: y = !1 } = e, { autoscroll: D } = e, F, x = !1, T = 0, R = 0, O = null, L = null, Z = 0, z = null, ge, G = null, ve = !0;
  const q = () => {
    t(0, l = t(27, O = t(19, S = null))), t(25, T = performance.now()), t(26, R = 0), x = !0, P();
  };
  function P() {
    Xh(() => {
      t(26, R = (performance.now() - T) / 1e3), x && P();
    });
  }
  function le() {
    t(26, R = 0), t(0, l = t(27, O = t(19, S = null))), x && (x = !1);
  }
  B2(() => {
    x && le();
  });
  let S = null;
  function ee(I) {
    Dc[I ? "unshift" : "push"](() => {
      G = I, t(16, G), t(7, E), t(14, z), t(15, ge);
    });
  }
  const K = () => {
    s("clear_status");
  };
  function de(I) {
    Dc[I ? "unshift" : "push"](() => {
      F = I, t(13, F);
    });
  }
  return n.$$set = (I) => {
    "i18n" in I && t(1, o = I.i18n), "eta" in I && t(0, l = I.eta), "queue_position" in I && t(2, c = I.queue_position), "queue_size" in I && t(3, u = I.queue_size), "status" in I && t(4, f = I.status), "scroll_to_output" in I && t(22, h = I.scroll_to_output), "timer" in I && t(5, d = I.timer), "show_progress" in I && t(6, p = I.show_progress), "message" in I && t(23, g = I.message), "progress" in I && t(7, E = I.progress), "variant" in I && t(8, w = I.variant), "loading_text" in I && t(9, m = I.loading_text), "absolute" in I && t(10, _ = I.absolute), "translucent" in I && t(11, b = I.translucent), "border" in I && t(12, y = I.border), "autoscroll" in I && t(24, D = I.autoscroll), "$$scope" in I && t(29, a = I.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (l === null && t(0, l = O), l != null && O !== l && (t(28, L = (performance.now() - T) / 1e3 + l), t(19, S = L.toFixed(1)), t(27, O = l))), n.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, Z = L === null || L <= 0 || !R ? null : Math.min(R / L, 1)), n.$$.dirty[0] & /*progress*/
    128 && E != null && t(18, ve = !1), n.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (E != null ? t(14, z = E.map((I) => {
      if (I.index != null && I.length != null)
        return I.index / I.length;
      if (I.progress != null)
        return I.progress;
    })) : t(14, z = null), z ? (t(15, ge = z[z.length - 1]), G && (ge === 0 ? t(16, G.style.transition = "0", G) : t(16, G.style.transition = "150ms", G))) : t(15, ge = void 0)), n.$$.dirty[0] & /*status*/
    16 && (f === "pending" ? q() : le()), n.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && F && h && (f === "pending" || f === "complete") && Z2(F, D), n.$$.dirty[0] & /*status, message*/
    8388624, n.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, i = R.toFixed(1));
  }, [
    l,
    o,
    c,
    u,
    f,
    d,
    p,
    E,
    w,
    m,
    _,
    b,
    y,
    F,
    z,
    ge,
    G,
    Z,
    ve,
    S,
    i,
    s,
    h,
    g,
    D,
    T,
    R,
    O,
    L,
    a,
    r,
    ee,
    K,
    de
  ];
}
class Yh extends I2 {
  constructor(e) {
    super(), $2(
      this,
      e,
      K2,
      X2,
      P2,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: Zh,
  setPrototypeOf: Mc,
  isFrozen: J2,
  getPrototypeOf: Q2,
  getOwnPropertyDescriptor: ev
} = Object;
let {
  freeze: Ye,
  seal: pt,
  create: Kh
} = Object, {
  apply: mo,
  construct: go
} = typeof Reflect < "u" && Reflect;
Ye || (Ye = function(e) {
  return e;
});
pt || (pt = function(e) {
  return e;
});
mo || (mo = function(e, t, i) {
  return e.apply(t, i);
});
go || (go = function(e, t) {
  return new e(...t);
});
const Lr = Ze(Array.prototype.forEach), tv = Ze(Array.prototype.lastIndexOf), Nc = Ze(Array.prototype.pop), Ii = Ze(Array.prototype.push), nv = Ze(Array.prototype.splice), Vr = Ze(String.prototype.toLowerCase), As = Ze(String.prototype.toString), Uc = Ze(String.prototype.match), $i = Ze(String.prototype.replace), iv = Ze(String.prototype.indexOf), rv = Ze(String.prototype.trim), Dt = Ze(Object.prototype.hasOwnProperty), je = Ze(RegExp.prototype.test), Pi = av(TypeError);
function Ze(n) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, i = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++)
      i[r - 1] = arguments[r];
    return mo(n, e, i);
  };
}
function av(n) {
  return function() {
    for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
      t[i] = arguments[i];
    return go(n, t);
  };
}
function j(n, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Vr;
  Mc && Mc(n, null);
  let i = e.length;
  for (; i--; ) {
    let r = e[i];
    if (typeof r == "string") {
      const a = t(r);
      a !== r && (J2(e) || (e[i] = a), r = a);
    }
    n[r] = !0;
  }
  return n;
}
function sv(n) {
  for (let e = 0; e < n.length; e++)
    Dt(n, e) || (n[e] = null);
  return n;
}
function Qt(n) {
  const e = Kh(null);
  for (const [t, i] of Zh(n))
    Dt(n, t) && (Array.isArray(i) ? e[t] = sv(i) : i && typeof i == "object" && i.constructor === Object ? e[t] = Qt(i) : e[t] = i);
  return e;
}
function xi(n, e) {
  for (; n !== null; ) {
    const i = ev(n, e);
    if (i) {
      if (i.get)
        return Ze(i.get);
      if (typeof i.value == "function")
        return Ze(i.value);
    }
    n = Q2(n);
  }
  function t() {
    return null;
  }
  return t;
}
const Hc = Ye(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), Fs = Ye(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Ts = Ye(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), ov = Ye(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Is = Ye(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), lv = Ye(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Gc = Ye(["#text"]), zc = Ye(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), $s = Ye(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), qc = Ye(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), Mr = Ye(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), uv = pt(/\{\{[\w\W]*|[\w\W]*\}\}/gm), cv = pt(/<%[\w\W]*|[\w\W]*%>/gm), fv = pt(/\$\{[\w\W]*/gm), hv = pt(/^data-[\-\w.\u00B7-\uFFFF]+$/), dv = pt(/^aria-[\-\w]+$/), Jh = pt(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), _v = pt(/^(?:\w+script|data):/i), pv = pt(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Qh = pt(/^html$/i), mv = pt(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Vc = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: dv,
  ATTR_WHITESPACE: pv,
  CUSTOM_ELEMENT: mv,
  DATA_ATTR: hv,
  DOCTYPE_NAME: Qh,
  ERB_EXPR: cv,
  IS_ALLOWED_URI: Jh,
  IS_SCRIPT_OR_DATA: _v,
  MUSTACHE_EXPR: uv,
  TMPLIT_EXPR: fv
});
const Bi = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, gv = function() {
  return typeof window > "u" ? null : window;
}, bv = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let i = null;
  const r = "data-tt-policy-suffix";
  t && t.hasAttribute(r) && (i = t.getAttribute(r));
  const a = "dompurify" + (i ? "#" + i : "");
  try {
    return e.createPolicy(a, {
      createHTML(s) {
        return s;
      },
      createScriptURL(s) {
        return s;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + a + " could not be created."), null;
  }
}, jc = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function ed() {
  let n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : gv();
  const e = (M) => ed(M);
  if (e.version = "3.2.6", e.removed = [], !n || !n.document || n.document.nodeType !== Bi.document || !n.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = n;
  const i = t, r = i.currentScript, {
    DocumentFragment: a,
    HTMLTemplateElement: s,
    Node: o,
    Element: l,
    NodeFilter: c,
    NamedNodeMap: u = n.NamedNodeMap || n.MozNamedAttrMap,
    HTMLFormElement: f,
    DOMParser: h,
    trustedTypes: d
  } = n, p = l.prototype, g = xi(p, "cloneNode"), E = xi(p, "remove"), w = xi(p, "nextSibling"), m = xi(p, "childNodes"), _ = xi(p, "parentNode");
  if (typeof s == "function") {
    const M = t.createElement("template");
    M.content && M.content.ownerDocument && (t = M.content.ownerDocument);
  }
  let b, y = "";
  const {
    implementation: D,
    createNodeIterator: F,
    createDocumentFragment: x,
    getElementsByTagName: T
  } = t, {
    importNode: R
  } = i;
  let O = jc();
  e.isSupported = typeof Zh == "function" && typeof _ == "function" && D && D.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: L,
    ERB_EXPR: Z,
    TMPLIT_EXPR: z,
    DATA_ATTR: ge,
    ARIA_ATTR: G,
    IS_SCRIPT_OR_DATA: ve,
    ATTR_WHITESPACE: q,
    CUSTOM_ELEMENT: P
  } = Vc;
  let {
    IS_ALLOWED_URI: le
  } = Vc, S = null;
  const ee = j({}, [...Hc, ...Fs, ...Ts, ...Is, ...Gc]);
  let K = null;
  const de = j({}, [...zc, ...$s, ...qc, ...Mr]);
  let I = Object.seal(Kh(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), Ce = null, $ = null, V = !0, J = !0, se = !1, k = !0, nt = !1, Pt = !0, Wt = !1, vi = !1, yi = !1, an = !1, zn = !1, qn = !1, sr = !0, or = !1;
  const $a = "user-content-";
  let C = !0, Ve = !1, Vn = {}, jn = null;
  const qo = j({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Vo = null;
  const jo = j({}, ["audio", "video", "img", "source", "image", "track"]);
  let Pa = null;
  const Wo = j({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), lr = "http://www.w3.org/1998/Math/MathML", ur = "http://www.w3.org/2000/svg", Xt = "http://www.w3.org/1999/xhtml";
  let Wn = Xt, xa = !1, Ba = null;
  const sd = j({}, [lr, ur, Xt], As);
  let cr = j({}, ["mi", "mo", "mn", "ms", "mtext"]), fr = j({}, ["annotation-xml"]);
  const od = j({}, ["title", "style", "font", "a", "script"]);
  let wi = null;
  const ld = ["application/xhtml+xml", "text/html"], ud = "text/html";
  let Se = null, Xn = null;
  const cd = t.createElement("form"), Xo = function(v) {
    return v instanceof RegExp || v instanceof Function;
  }, Oa = function() {
    let v = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Xn && Xn === v)) {
      if ((!v || typeof v != "object") && (v = {}), v = Qt(v), wi = // eslint-disable-next-line unicorn/prefer-includes
      ld.indexOf(v.PARSER_MEDIA_TYPE) === -1 ? ud : v.PARSER_MEDIA_TYPE, Se = wi === "application/xhtml+xml" ? As : Vr, S = Dt(v, "ALLOWED_TAGS") ? j({}, v.ALLOWED_TAGS, Se) : ee, K = Dt(v, "ALLOWED_ATTR") ? j({}, v.ALLOWED_ATTR, Se) : de, Ba = Dt(v, "ALLOWED_NAMESPACES") ? j({}, v.ALLOWED_NAMESPACES, As) : sd, Pa = Dt(v, "ADD_URI_SAFE_ATTR") ? j(Qt(Wo), v.ADD_URI_SAFE_ATTR, Se) : Wo, Vo = Dt(v, "ADD_DATA_URI_TAGS") ? j(Qt(jo), v.ADD_DATA_URI_TAGS, Se) : jo, jn = Dt(v, "FORBID_CONTENTS") ? j({}, v.FORBID_CONTENTS, Se) : qo, Ce = Dt(v, "FORBID_TAGS") ? j({}, v.FORBID_TAGS, Se) : Qt({}), $ = Dt(v, "FORBID_ATTR") ? j({}, v.FORBID_ATTR, Se) : Qt({}), Vn = Dt(v, "USE_PROFILES") ? v.USE_PROFILES : !1, V = v.ALLOW_ARIA_ATTR !== !1, J = v.ALLOW_DATA_ATTR !== !1, se = v.ALLOW_UNKNOWN_PROTOCOLS || !1, k = v.ALLOW_SELF_CLOSE_IN_ATTR !== !1, nt = v.SAFE_FOR_TEMPLATES || !1, Pt = v.SAFE_FOR_XML !== !1, Wt = v.WHOLE_DOCUMENT || !1, an = v.RETURN_DOM || !1, zn = v.RETURN_DOM_FRAGMENT || !1, qn = v.RETURN_TRUSTED_TYPE || !1, yi = v.FORCE_BODY || !1, sr = v.SANITIZE_DOM !== !1, or = v.SANITIZE_NAMED_PROPS || !1, C = v.KEEP_CONTENT !== !1, Ve = v.IN_PLACE || !1, le = v.ALLOWED_URI_REGEXP || Jh, Wn = v.NAMESPACE || Xt, cr = v.MATHML_TEXT_INTEGRATION_POINTS || cr, fr = v.HTML_INTEGRATION_POINTS || fr, I = v.CUSTOM_ELEMENT_HANDLING || {}, v.CUSTOM_ELEMENT_HANDLING && Xo(v.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (I.tagNameCheck = v.CUSTOM_ELEMENT_HANDLING.tagNameCheck), v.CUSTOM_ELEMENT_HANDLING && Xo(v.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (I.attributeNameCheck = v.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), v.CUSTOM_ELEMENT_HANDLING && typeof v.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (I.allowCustomizedBuiltInElements = v.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), nt && (J = !1), zn && (an = !0), Vn && (S = j({}, Gc), K = [], Vn.html === !0 && (j(S, Hc), j(K, zc)), Vn.svg === !0 && (j(S, Fs), j(K, $s), j(K, Mr)), Vn.svgFilters === !0 && (j(S, Ts), j(K, $s), j(K, Mr)), Vn.mathMl === !0 && (j(S, Is), j(K, qc), j(K, Mr))), v.ADD_TAGS && (S === ee && (S = Qt(S)), j(S, v.ADD_TAGS, Se)), v.ADD_ATTR && (K === de && (K = Qt(K)), j(K, v.ADD_ATTR, Se)), v.ADD_URI_SAFE_ATTR && j(Pa, v.ADD_URI_SAFE_ATTR, Se), v.FORBID_CONTENTS && (jn === qo && (jn = Qt(jn)), j(jn, v.FORBID_CONTENTS, Se)), C && (S["#text"] = !0), Wt && j(S, ["html", "head", "body"]), S.table && (j(S, ["tbody"]), delete Ce.tbody), v.TRUSTED_TYPES_POLICY) {
        if (typeof v.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw Pi('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof v.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw Pi('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        b = v.TRUSTED_TYPES_POLICY, y = b.createHTML("");
      } else
        b === void 0 && (b = bv(d, r)), b !== null && typeof y == "string" && (y = b.createHTML(""));
      Ye && Ye(v), Xn = v;
    }
  }, Yo = j({}, [...Fs, ...Ts, ...ov]), Zo = j({}, [...Is, ...lv]), fd = function(v) {
    let A = _(v);
    (!A || !A.tagName) && (A = {
      namespaceURI: Wn,
      tagName: "template"
    });
    const B = Vr(v.tagName), ce = Vr(A.tagName);
    return Ba[v.namespaceURI] ? v.namespaceURI === ur ? A.namespaceURI === Xt ? B === "svg" : A.namespaceURI === lr ? B === "svg" && (ce === "annotation-xml" || cr[ce]) : !!Yo[B] : v.namespaceURI === lr ? A.namespaceURI === Xt ? B === "math" : A.namespaceURI === ur ? B === "math" && fr[ce] : !!Zo[B] : v.namespaceURI === Xt ? A.namespaceURI === ur && !fr[ce] || A.namespaceURI === lr && !cr[ce] ? !1 : !Zo[B] && (od[B] || !Yo[B]) : !!(wi === "application/xhtml+xml" && Ba[v.namespaceURI]) : !1;
  }, xt = function(v) {
    Ii(e.removed, {
      element: v
    });
    try {
      _(v).removeChild(v);
    } catch {
      E(v);
    }
  }, Yn = function(v, A) {
    try {
      Ii(e.removed, {
        attribute: A.getAttributeNode(v),
        from: A
      });
    } catch {
      Ii(e.removed, {
        attribute: null,
        from: A
      });
    }
    if (A.removeAttribute(v), v === "is")
      if (an || zn)
        try {
          xt(A);
        } catch {
        }
      else
        try {
          A.setAttribute(v, "");
        } catch {
        }
  }, Ko = function(v) {
    let A = null, B = null;
    if (yi)
      v = "<remove></remove>" + v;
    else {
      const Ee = Uc(v, /^[\r\n\t ]+/);
      B = Ee && Ee[0];
    }
    wi === "application/xhtml+xml" && Wn === Xt && (v = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + v + "</body></html>");
    const ce = b ? b.createHTML(v) : v;
    if (Wn === Xt)
      try {
        A = new h().parseFromString(ce, wi);
      } catch {
      }
    if (!A || !A.documentElement) {
      A = D.createDocument(Wn, "template", null);
      try {
        A.documentElement.innerHTML = xa ? y : ce;
      } catch {
      }
    }
    const xe = A.body || A.documentElement;
    return v && B && xe.insertBefore(t.createTextNode(B), xe.childNodes[0] || null), Wn === Xt ? T.call(A, Wt ? "html" : "body")[0] : Wt ? A.documentElement : xe;
  }, Jo = function(v) {
    return F.call(
      v.ownerDocument || v,
      v,
      // eslint-disable-next-line no-bitwise
      c.SHOW_ELEMENT | c.SHOW_COMMENT | c.SHOW_TEXT | c.SHOW_PROCESSING_INSTRUCTION | c.SHOW_CDATA_SECTION,
      null
    );
  }, Ra = function(v) {
    return v instanceof f && (typeof v.nodeName != "string" || typeof v.textContent != "string" || typeof v.removeChild != "function" || !(v.attributes instanceof u) || typeof v.removeAttribute != "function" || typeof v.setAttribute != "function" || typeof v.namespaceURI != "string" || typeof v.insertBefore != "function" || typeof v.hasChildNodes != "function");
  }, Qo = function(v) {
    return typeof o == "function" && v instanceof o;
  };
  function Yt(M, v, A) {
    Lr(M, (B) => {
      B.call(e, v, A, Xn);
    });
  }
  const el = function(v) {
    let A = null;
    if (Yt(O.beforeSanitizeElements, v, null), Ra(v))
      return xt(v), !0;
    const B = Se(v.nodeName);
    if (Yt(O.uponSanitizeElement, v, {
      tagName: B,
      allowedTags: S
    }), Pt && v.hasChildNodes() && !Qo(v.firstElementChild) && je(/<[/\w!]/g, v.innerHTML) && je(/<[/\w!]/g, v.textContent) || v.nodeType === Bi.progressingInstruction || Pt && v.nodeType === Bi.comment && je(/<[/\w]/g, v.data))
      return xt(v), !0;
    if (!S[B] || Ce[B]) {
      if (!Ce[B] && nl(B) && (I.tagNameCheck instanceof RegExp && je(I.tagNameCheck, B) || I.tagNameCheck instanceof Function && I.tagNameCheck(B)))
        return !1;
      if (C && !jn[B]) {
        const ce = _(v) || v.parentNode, xe = m(v) || v.childNodes;
        if (xe && ce) {
          const Ee = xe.length;
          for (let Ke = Ee - 1; Ke >= 0; --Ke) {
            const Zt = g(xe[Ke], !0);
            Zt.__removalCount = (v.__removalCount || 0) + 1, ce.insertBefore(Zt, w(v));
          }
        }
      }
      return xt(v), !0;
    }
    return v instanceof l && !fd(v) || (B === "noscript" || B === "noembed" || B === "noframes") && je(/<\/no(script|embed|frames)/i, v.innerHTML) ? (xt(v), !0) : (nt && v.nodeType === Bi.text && (A = v.textContent, Lr([L, Z, z], (ce) => {
      A = $i(A, ce, " ");
    }), v.textContent !== A && (Ii(e.removed, {
      element: v.cloneNode()
    }), v.textContent = A)), Yt(O.afterSanitizeElements, v, null), !1);
  }, tl = function(v, A, B) {
    if (sr && (A === "id" || A === "name") && (B in t || B in cd))
      return !1;
    if (!(J && !$[A] && je(ge, A))) {
      if (!(V && je(G, A))) {
        if (!K[A] || $[A]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(nl(v) && (I.tagNameCheck instanceof RegExp && je(I.tagNameCheck, v) || I.tagNameCheck instanceof Function && I.tagNameCheck(v)) && (I.attributeNameCheck instanceof RegExp && je(I.attributeNameCheck, A) || I.attributeNameCheck instanceof Function && I.attributeNameCheck(A)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            A === "is" && I.allowCustomizedBuiltInElements && (I.tagNameCheck instanceof RegExp && je(I.tagNameCheck, B) || I.tagNameCheck instanceof Function && I.tagNameCheck(B)))
          ) return !1;
        } else if (!Pa[A]) {
          if (!je(le, $i(B, q, ""))) {
            if (!((A === "src" || A === "xlink:href" || A === "href") && v !== "script" && iv(B, "data:") === 0 && Vo[v])) {
              if (!(se && !je(ve, $i(B, q, "")))) {
                if (B)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, nl = function(v) {
    return v !== "annotation-xml" && Uc(v, P);
  }, il = function(v) {
    Yt(O.beforeSanitizeAttributes, v, null);
    const {
      attributes: A
    } = v;
    if (!A || Ra(v))
      return;
    const B = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: K,
      forceKeepAttr: void 0
    };
    let ce = A.length;
    for (; ce--; ) {
      const xe = A[ce], {
        name: Ee,
        namespaceURI: Ke,
        value: Zt
      } = xe, Di = Se(Ee), La = Zt;
      let Be = Ee === "value" ? La : rv(La);
      if (B.attrName = Di, B.attrValue = Be, B.keepAttr = !0, B.forceKeepAttr = void 0, Yt(O.uponSanitizeAttribute, v, B), Be = B.attrValue, or && (Di === "id" || Di === "name") && (Yn(Ee, v), Be = $a + Be), Pt && je(/((--!?|])>)|<\/(style|title)/i, Be)) {
        Yn(Ee, v);
        continue;
      }
      if (B.forceKeepAttr)
        continue;
      if (!B.keepAttr) {
        Yn(Ee, v);
        continue;
      }
      if (!k && je(/\/>/i, Be)) {
        Yn(Ee, v);
        continue;
      }
      nt && Lr([L, Z, z], (al) => {
        Be = $i(Be, al, " ");
      });
      const rl = Se(v.nodeName);
      if (!tl(rl, Di, Be)) {
        Yn(Ee, v);
        continue;
      }
      if (b && typeof d == "object" && typeof d.getAttributeType == "function" && !Ke)
        switch (d.getAttributeType(rl, Di)) {
          case "TrustedHTML": {
            Be = b.createHTML(Be);
            break;
          }
          case "TrustedScriptURL": {
            Be = b.createScriptURL(Be);
            break;
          }
        }
      if (Be !== La)
        try {
          Ke ? v.setAttributeNS(Ke, Ee, Be) : v.setAttribute(Ee, Be), Ra(v) ? xt(v) : Nc(e.removed);
        } catch {
          Yn(Ee, v);
        }
    }
    Yt(O.afterSanitizeAttributes, v, null);
  }, hd = function M(v) {
    let A = null;
    const B = Jo(v);
    for (Yt(O.beforeSanitizeShadowDOM, v, null); A = B.nextNode(); )
      Yt(O.uponSanitizeShadowNode, A, null), el(A), il(A), A.content instanceof a && M(A.content);
    Yt(O.afterSanitizeShadowDOM, v, null);
  };
  return e.sanitize = function(M) {
    let v = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, A = null, B = null, ce = null, xe = null;
    if (xa = !M, xa && (M = "<!-->"), typeof M != "string" && !Qo(M))
      if (typeof M.toString == "function") {
        if (M = M.toString(), typeof M != "string")
          throw Pi("dirty is not a string, aborting");
      } else
        throw Pi("toString is not a function");
    if (!e.isSupported)
      return M;
    if (vi || Oa(v), e.removed = [], typeof M == "string" && (Ve = !1), Ve) {
      if (M.nodeName) {
        const Zt = Se(M.nodeName);
        if (!S[Zt] || Ce[Zt])
          throw Pi("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (M instanceof o)
      A = Ko("<!---->"), B = A.ownerDocument.importNode(M, !0), B.nodeType === Bi.element && B.nodeName === "BODY" || B.nodeName === "HTML" ? A = B : A.appendChild(B);
    else {
      if (!an && !nt && !Wt && // eslint-disable-next-line unicorn/prefer-includes
      M.indexOf("<") === -1)
        return b && qn ? b.createHTML(M) : M;
      if (A = Ko(M), !A)
        return an ? null : qn ? y : "";
    }
    A && yi && xt(A.firstChild);
    const Ee = Jo(Ve ? M : A);
    for (; ce = Ee.nextNode(); )
      el(ce), il(ce), ce.content instanceof a && hd(ce.content);
    if (Ve)
      return M;
    if (an) {
      if (zn)
        for (xe = x.call(A.ownerDocument); A.firstChild; )
          xe.appendChild(A.firstChild);
      else
        xe = A;
      return (K.shadowroot || K.shadowrootmode) && (xe = R.call(i, xe, !0)), xe;
    }
    let Ke = Wt ? A.outerHTML : A.innerHTML;
    return Wt && S["!doctype"] && A.ownerDocument && A.ownerDocument.doctype && A.ownerDocument.doctype.name && je(Qh, A.ownerDocument.doctype.name) && (Ke = "<!DOCTYPE " + A.ownerDocument.doctype.name + `>
` + Ke), nt && Lr([L, Z, z], (Zt) => {
      Ke = $i(Ke, Zt, " ");
    }), b && qn ? b.createHTML(Ke) : Ke;
  }, e.setConfig = function() {
    let M = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Oa(M), vi = !0;
  }, e.clearConfig = function() {
    Xn = null, vi = !1;
  }, e.isValidAttribute = function(M, v, A) {
    Xn || Oa({});
    const B = Se(M), ce = Se(v);
    return tl(B, ce, A);
  }, e.addHook = function(M, v) {
    typeof v == "function" && Ii(O[M], v);
  }, e.removeHook = function(M, v) {
    if (v !== void 0) {
      const A = tv(O[M], v);
      return A === -1 ? void 0 : nv(O[M], A, 1)[0];
    }
    return Nc(O[M]);
  }, e.removeHooks = function(M) {
    O[M] = [];
  }, e.removeAllHooks = function() {
    O = jc();
  }, e;
}
ed();
const {
  HtmlTagHydration: j6,
  SvelteComponent: W6,
  add_render_callback: X6,
  append_hydration: Y6,
  attr: Z6,
  bubble: K6,
  check_outros: J6,
  children: Q6,
  claim_component: e9,
  claim_element: t9,
  claim_html_tag: n9,
  claim_space: i9,
  claim_text: r9,
  create_component: a9,
  create_in_transition: s9,
  create_out_transition: o9,
  destroy_component: l9,
  detach: u9,
  element: c9,
  get_svelte_dataset: f9,
  group_outros: h9,
  init: d9,
  insert_hydration: _9,
  listen: p9,
  mount_component: m9,
  run_all: g9,
  safe_not_equal: b9,
  set_data: v9,
  space: y9,
  stop_propagation: w9,
  text: D9,
  toggle_class: E9,
  transition_in: C9,
  transition_out: S9
} = window.__gradio__svelte__internal, { createEventDispatcher: k9, onMount: A9 } = window.__gradio__svelte__internal, {
  SvelteComponent: F9,
  append_hydration: T9,
  attr: I9,
  bubble: $9,
  check_outros: P9,
  children: x9,
  claim_component: B9,
  claim_element: O9,
  claim_space: R9,
  create_animation: L9,
  create_component: M9,
  destroy_component: N9,
  detach: U9,
  element: H9,
  ensure_array_like: G9,
  fix_and_outro_and_destroy_block: z9,
  fix_position: q9,
  group_outros: V9,
  init: j9,
  insert_hydration: W9,
  mount_component: X9,
  noop: Y9,
  safe_not_equal: Z9,
  set_style: K9,
  space: J9,
  transition_in: Q9,
  transition_out: eI,
  update_keyed_each: tI
} = window.__gradio__svelte__internal, {
  SvelteComponent: nI,
  attr: iI,
  children: rI,
  claim_element: aI,
  detach: sI,
  element: oI,
  empty: lI,
  init: uI,
  insert_hydration: cI,
  noop: fI,
  safe_not_equal: hI,
  set_style: dI
} = window.__gradio__svelte__internal, {
  SvelteComponent: vv,
  attr: yv,
  check_outros: wv,
  children: Dv,
  claim_component: Ev,
  claim_element: Cv,
  create_component: Sv,
  destroy_component: kv,
  detach: Wc,
  element: Av,
  group_outros: Fv,
  init: Tv,
  insert_hydration: Iv,
  mount_component: $v,
  safe_not_equal: Pv,
  toggle_class: ln,
  transition_in: jr,
  transition_out: bo
} = window.__gradio__svelte__internal;
function Xc(n) {
  let e, t;
  return e = new Lo({
    props: { src: (
      /*value*/
      n[0].url
    ), alt: "" }
  }), {
    c() {
      Sv(e.$$.fragment);
    },
    l(i) {
      Ev(e.$$.fragment, i);
    },
    m(i, r) {
      $v(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r & /*value*/
      1 && (a.src = /*value*/
      i[0].url), e.$set(a);
    },
    i(i) {
      t || (jr(e.$$.fragment, i), t = !0);
    },
    o(i) {
      bo(e.$$.fragment, i), t = !1;
    },
    d(i) {
      kv(e, i);
    }
  };
}
function xv(n) {
  let e, t, i = (
    /*value*/
    n[0] && Xc(n)
  );
  return {
    c() {
      e = Av("div"), i && i.c(), this.h();
    },
    l(r) {
      e = Cv(r, "DIV", { class: !0 });
      var a = Dv(e);
      i && i.l(a), a.forEach(Wc), this.h();
    },
    h() {
      yv(e, "class", "container svelte-1sgcyba"), ln(
        e,
        "table",
        /*type*/
        n[1] === "table"
      ), ln(
        e,
        "gallery",
        /*type*/
        n[1] === "gallery"
      ), ln(
        e,
        "selected",
        /*selected*/
        n[2]
      ), ln(
        e,
        "border",
        /*value*/
        n[0]
      );
    },
    m(r, a) {
      Iv(r, e, a), i && i.m(e, null), t = !0;
    },
    p(r, [a]) {
      /*value*/
      r[0] ? i ? (i.p(r, a), a & /*value*/
      1 && jr(i, 1)) : (i = Xc(r), i.c(), jr(i, 1), i.m(e, null)) : i && (Fv(), bo(i, 1, 1, () => {
        i = null;
      }), wv()), (!t || a & /*type*/
      2) && ln(
        e,
        "table",
        /*type*/
        r[1] === "table"
      ), (!t || a & /*type*/
      2) && ln(
        e,
        "gallery",
        /*type*/
        r[1] === "gallery"
      ), (!t || a & /*selected*/
      4) && ln(
        e,
        "selected",
        /*selected*/
        r[2]
      ), (!t || a & /*value*/
      1) && ln(
        e,
        "border",
        /*value*/
        r[0]
      );
    },
    i(r) {
      t || (jr(i), t = !0);
    },
    o(r) {
      bo(i), t = !1;
    },
    d(r) {
      r && Wc(e), i && i.d();
    }
  };
}
function Bv(n, e, t) {
  let { value: i } = e, { type: r } = e, { selected: a = !1 } = e;
  return n.$$set = (s) => {
    "value" in s && t(0, i = s.value), "type" in s && t(1, r = s.type), "selected" in s && t(2, a = s.selected);
  }, [i, r, a];
}
class _I extends vv {
  constructor(e) {
    super(), Tv(this, e, Bv, xv, Pv, { value: 0, type: 1, selected: 2 });
  }
}
const {
  SvelteComponent: Ov,
  add_flush_callback: ri,
  assign: td,
  bind: ai,
  binding_callbacks: Cn,
  check_outros: Rv,
  claim_component: On,
  claim_space: nd,
  create_component: Rn,
  destroy_component: Ln,
  detach: Go,
  empty: Yc,
  flush: oe,
  get_spread_object: id,
  get_spread_update: rd,
  group_outros: Lv,
  init: Mv,
  insert_hydration: zo,
  mount_component: Mn,
  safe_not_equal: Nv,
  space: ad,
  transition_in: nn,
  transition_out: rn
} = window.__gradio__svelte__internal, { afterUpdate: Uv } = window.__gradio__svelte__internal;
function Hv(n) {
  let e, t, i;
  function r(s) {
    n[55](s);
  }
  let a = {
    visible: (
      /*visible*/
      n[4]
    ),
    variant: (
      /*value*/
      n[0] === null ? "dashed" : "solid"
    ),
    border_mode: (
      /*dragging*/
      n[27] ? "focus" : "base"
    ),
    padding: !1,
    elem_id: (
      /*elem_id*/
      n[2]
    ),
    elem_classes: (
      /*elem_classes*/
      n[3]
    ),
    height: (
      /*height*/
      n[12] || void 0
    ),
    width: (
      /*width*/
      n[13]
    ),
    allow_overflow: !1,
    container: (
      /*container*/
      n[15]
    ),
    scale: (
      /*scale*/
      n[16]
    ),
    min_width: (
      /*min_width*/
      n[17]
    ),
    $$slots: { default: [qv] },
    $$scope: { ctx: n }
  };
  return (
    /*fullscreen*/
    n[26] !== void 0 && (a.fullscreen = /*fullscreen*/
    n[26]), e = new nf({ props: a }), Cn.push(() => ai(e, "fullscreen", r)), e.$on(
      "dragenter",
      /*handle_drag_event*/
      n[30]
    ), e.$on(
      "dragleave",
      /*handle_drag_event*/
      n[30]
    ), e.$on(
      "dragover",
      /*handle_drag_event*/
      n[30]
    ), e.$on(
      "drop",
      /*handle_drop*/
      n[31]
    ), {
      c() {
        Rn(e.$$.fragment);
      },
      l(s) {
        On(e.$$.fragment, s);
      },
      m(s, o) {
        Mn(e, s, o), i = !0;
      },
      p(s, o) {
        const l = {};
        o[0] & /*visible*/
        16 && (l.visible = /*visible*/
        s[4]), o[0] & /*value*/
        1 && (l.variant = /*value*/
        s[0] === null ? "dashed" : "solid"), o[0] & /*dragging*/
        134217728 && (l.border_mode = /*dragging*/
        s[27] ? "focus" : "base"), o[0] & /*elem_id*/
        4 && (l.elem_id = /*elem_id*/
        s[2]), o[0] & /*elem_classes*/
        8 && (l.elem_classes = /*elem_classes*/
        s[3]), o[0] & /*height*/
        4096 && (l.height = /*height*/
        s[12] || void 0), o[0] & /*width*/
        8192 && (l.width = /*width*/
        s[13]), o[0] & /*container*/
        32768 && (l.container = /*container*/
        s[15]), o[0] & /*scale*/
        65536 && (l.scale = /*scale*/
        s[16]), o[0] & /*min_width*/
        131072 && (l.min_width = /*min_width*/
        s[17]), o[0] & /*_selectable, root, sources, fullscreen, label, show_label, pending, show_fullscreen_button, gradio, height, width, only_custom_metadata, popup_metadata_width, popup_metadata_height, upload_component, uploading, active_source, value, dragging, loading_status, placeholder*/
        1072201571 | o[1] & /*$$scope*/
        67108864 && (l.$$scope = { dirty: o, ctx: s }), !t && o[0] & /*fullscreen*/
        67108864 && (t = !0, l.fullscreen = /*fullscreen*/
        s[26], ri(() => t = !1)), e.$set(l);
      },
      i(s) {
        i || (nn(e.$$.fragment, s), i = !0);
      },
      o(s) {
        rn(e.$$.fragment, s), i = !1;
      },
      d(s) {
        Ln(e, s);
      }
    }
  );
}
function Gv(n) {
  let e, t, i;
  function r(s) {
    n[39](s);
  }
  let a = {
    visible: (
      /*visible*/
      n[4]
    ),
    variant: "solid",
    border_mode: (
      /*dragging*/
      n[27] ? "focus" : "base"
    ),
    padding: !1,
    elem_id: (
      /*elem_id*/
      n[2]
    ),
    elem_classes: (
      /*elem_classes*/
      n[3]
    ),
    height: (
      /*height*/
      n[12] || void 0
    ),
    width: (
      /*width*/
      n[13]
    ),
    allow_overflow: !1,
    container: (
      /*container*/
      n[15]
    ),
    scale: (
      /*scale*/
      n[16]
    ),
    min_width: (
      /*min_width*/
      n[17]
    ),
    $$slots: { default: [Vv] },
    $$scope: { ctx: n }
  };
  return (
    /*fullscreen*/
    n[26] !== void 0 && (a.fullscreen = /*fullscreen*/
    n[26]), e = new nf({ props: a }), Cn.push(() => ai(e, "fullscreen", r)), {
      c() {
        Rn(e.$$.fragment);
      },
      l(s) {
        On(e.$$.fragment, s);
      },
      m(s, o) {
        Mn(e, s, o), i = !0;
      },
      p(s, o) {
        const l = {};
        o[0] & /*visible*/
        16 && (l.visible = /*visible*/
        s[4]), o[0] & /*dragging*/
        134217728 && (l.border_mode = /*dragging*/
        s[27] ? "focus" : "base"), o[0] & /*elem_id*/
        4 && (l.elem_id = /*elem_id*/
        s[2]), o[0] & /*elem_classes*/
        8 && (l.elem_classes = /*elem_classes*/
        s[3]), o[0] & /*height*/
        4096 && (l.height = /*height*/
        s[12] || void 0), o[0] & /*width*/
        8192 && (l.width = /*width*/
        s[13]), o[0] & /*container*/
        32768 && (l.container = /*container*/
        s[15]), o[0] & /*scale*/
        65536 && (l.scale = /*scale*/
        s[16]), o[0] & /*min_width*/
        131072 && (l.min_width = /*min_width*/
        s[17]), o[0] & /*fullscreen, value, label, show_label, show_download_button, _selectable, show_share_button, gradio, show_fullscreen_button, height, width, only_custom_metadata, popup_metadata_width, popup_metadata_height, loading_status*/
        92569315 | o[1] & /*$$scope*/
        67108864 && (l.$$scope = { dirty: o, ctx: s }), !t && o[0] & /*fullscreen*/
        67108864 && (t = !0, l.fullscreen = /*fullscreen*/
        s[26], ri(() => t = !1)), e.$set(l);
      },
      i(s) {
        i || (nn(e.$$.fragment, s), i = !0);
      },
      o(s) {
        rn(e.$$.fragment, s), i = !1;
      },
      d(s) {
        Ln(e, s);
      }
    }
  );
}
function zv(n) {
  let e, t;
  return e = new Vm({
    props: {
      i18n: (
        /*gradio*/
        n[24].i18n
      ),
      type: "image",
      placeholder: (
        /*placeholder*/
        n[22]
      )
    }
  }), {
    c() {
      Rn(e.$$.fragment);
    },
    l(i) {
      On(e.$$.fragment, i);
    },
    m(i, r) {
      Mn(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*gradio*/
      16777216 && (a.i18n = /*gradio*/
      i[24].i18n), r[0] & /*placeholder*/
      4194304 && (a.placeholder = /*placeholder*/
      i[22]), e.$set(a);
    },
    i(i) {
      t || (nn(e.$$.fragment, i), t = !0);
    },
    o(i) {
      rn(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Ln(e, i);
    }
  };
}
function qv(n) {
  var E;
  let e, t, i, r, a, s, o, l;
  const c = [
    {
      autoscroll: (
        /*gradio*/
        n[24].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      n[24].i18n
    ) },
    /*loading_status*/
    n[1]
  ];
  let u = {};
  for (let w = 0; w < c.length; w += 1)
    u = td(u, c[w]);
  e = new Yh({ props: u }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    n[40]
  );
  function f(w) {
    n[43](w);
  }
  function h(w) {
    n[44](w);
  }
  function d(w) {
    n[45](w);
  }
  function p(w) {
    n[46](w);
  }
  let g = {
    selectable: (
      /*_selectable*/
      n[14]
    ),
    root: (
      /*root*/
      n[8]
    ),
    sources: (
      /*sources*/
      n[19]
    ),
    fullscreen: (
      /*fullscreen*/
      n[26]
    ),
    label: (
      /*label*/
      n[5]
    ),
    show_label: (
      /*show_label*/
      n[6]
    ),
    pending: (
      /*pending*/
      n[21]
    ),
    show_fullscreen_button: (
      /*show_fullscreen_button*/
      n[23]
    ),
    max_file_size: (
      /*gradio*/
      n[24].max_file_size
    ),
    i18n: (
      /*gradio*/
      n[24].i18n
    ),
    upload: (
      /*func*/
      n[41]
    ),
    stream_handler: (
      /*gradio*/
      (E = n[24].client) == null ? void 0 : E.stream
    ),
    height: (
      /*height*/
      n[12] || void 0
    ),
    width: (
      /*width*/
      n[13]
    ),
    only_custom_metadata: (
      /*only_custom_metadata*/
      n[9]
    ),
    popup_metadata_width: (
      /*popup_metadata_width*/
      n[10]
    ),
    popup_metadata_height: (
      /*popup_metadata_height*/
      n[11]
    ),
    $$slots: { default: [zv] },
    $$scope: { ctx: n }
  };
  return (
    /*uploading*/
    n[25] !== void 0 && (g.uploading = /*uploading*/
    n[25]), /*active_source*/
    n[28] !== void 0 && (g.active_source = /*active_source*/
    n[28]), /*value*/
    n[0] !== void 0 && (g.value = /*value*/
    n[0]), /*dragging*/
    n[27] !== void 0 && (g.dragging = /*dragging*/
    n[27]), i = new v2({ props: g }), n[42](i), Cn.push(() => ai(i, "uploading", f)), Cn.push(() => ai(i, "active_source", h)), Cn.push(() => ai(i, "value", d)), Cn.push(() => ai(i, "dragging", p)), i.$on(
      "edit",
      /*edit_handler*/
      n[47]
    ), i.$on(
      "clear",
      /*clear_handler*/
      n[48]
    ), i.$on(
      "drag",
      /*drag_handler*/
      n[49]
    ), i.$on(
      "upload",
      /*upload_handler*/
      n[50]
    ), i.$on(
      "select",
      /*select_handler_1*/
      n[51]
    ), i.$on(
      "share",
      /*share_handler_1*/
      n[52]
    ), i.$on(
      "load_metadata",
      /*handle_load_metadata*/
      n[32]
    ), i.$on(
      "error",
      /*error_handler_1*/
      n[53]
    ), i.$on(
      "fullscreen",
      /*fullscreen_handler_1*/
      n[54]
    ), {
      c() {
        Rn(e.$$.fragment), t = ad(), Rn(i.$$.fragment);
      },
      l(w) {
        On(e.$$.fragment, w), t = nd(w), On(i.$$.fragment, w);
      },
      m(w, m) {
        Mn(e, w, m), zo(w, t, m), Mn(i, w, m), l = !0;
      },
      p(w, m) {
        var y;
        const _ = m[0] & /*gradio, loading_status*/
        16777218 ? rd(c, [
          m[0] & /*gradio*/
          16777216 && {
            autoscroll: (
              /*gradio*/
              w[24].autoscroll
            )
          },
          m[0] & /*gradio*/
          16777216 && { i18n: (
            /*gradio*/
            w[24].i18n
          ) },
          m[0] & /*loading_status*/
          2 && id(
            /*loading_status*/
            w[1]
          )
        ]) : {};
        e.$set(_);
        const b = {};
        m[0] & /*_selectable*/
        16384 && (b.selectable = /*_selectable*/
        w[14]), m[0] & /*root*/
        256 && (b.root = /*root*/
        w[8]), m[0] & /*sources*/
        524288 && (b.sources = /*sources*/
        w[19]), m[0] & /*fullscreen*/
        67108864 && (b.fullscreen = /*fullscreen*/
        w[26]), m[0] & /*label*/
        32 && (b.label = /*label*/
        w[5]), m[0] & /*show_label*/
        64 && (b.show_label = /*show_label*/
        w[6]), m[0] & /*pending*/
        2097152 && (b.pending = /*pending*/
        w[21]), m[0] & /*show_fullscreen_button*/
        8388608 && (b.show_fullscreen_button = /*show_fullscreen_button*/
        w[23]), m[0] & /*gradio*/
        16777216 && (b.max_file_size = /*gradio*/
        w[24].max_file_size), m[0] & /*gradio*/
        16777216 && (b.i18n = /*gradio*/
        w[24].i18n), m[0] & /*gradio*/
        16777216 && (b.upload = /*func*/
        w[41]), m[0] & /*gradio*/
        16777216 && (b.stream_handler = /*gradio*/
        (y = w[24].client) == null ? void 0 : y.stream), m[0] & /*height*/
        4096 && (b.height = /*height*/
        w[12] || void 0), m[0] & /*width*/
        8192 && (b.width = /*width*/
        w[13]), m[0] & /*only_custom_metadata*/
        512 && (b.only_custom_metadata = /*only_custom_metadata*/
        w[9]), m[0] & /*popup_metadata_width*/
        1024 && (b.popup_metadata_width = /*popup_metadata_width*/
        w[10]), m[0] & /*popup_metadata_height*/
        2048 && (b.popup_metadata_height = /*popup_metadata_height*/
        w[11]), m[0] & /*gradio, placeholder*/
        20971520 | m[1] & /*$$scope*/
        67108864 && (b.$$scope = { dirty: m, ctx: w }), !r && m[0] & /*uploading*/
        33554432 && (r = !0, b.uploading = /*uploading*/
        w[25], ri(() => r = !1)), !a && m[0] & /*active_source*/
        268435456 && (a = !0, b.active_source = /*active_source*/
        w[28], ri(() => a = !1)), !s && m[0] & /*value*/
        1 && (s = !0, b.value = /*value*/
        w[0], ri(() => s = !1)), !o && m[0] & /*dragging*/
        134217728 && (o = !0, b.dragging = /*dragging*/
        w[27], ri(() => o = !1)), i.$set(b);
      },
      i(w) {
        l || (nn(e.$$.fragment, w), nn(i.$$.fragment, w), l = !0);
      },
      o(w) {
        rn(e.$$.fragment, w), rn(i.$$.fragment, w), l = !1;
      },
      d(w) {
        w && Go(t), Ln(e, w), n[42](null), Ln(i, w);
      }
    }
  );
}
function Vv(n) {
  let e, t, i, r;
  const a = [
    {
      autoscroll: (
        /*gradio*/
        n[24].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      n[24].i18n
    ) },
    /*loading_status*/
    n[1]
  ];
  let s = {};
  for (let o = 0; o < a.length; o += 1)
    s = td(s, a[o]);
  return e = new Yh({ props: s }), i = new R0({
    props: {
      fullscreen: (
        /*fullscreen*/
        n[26]
      ),
      value: (
        /*value*/
        n[0]
      ),
      label: (
        /*label*/
        n[5]
      ),
      show_label: (
        /*show_label*/
        n[6]
      ),
      show_download_button: (
        /*show_download_button*/
        n[7]
      ),
      selectable: (
        /*_selectable*/
        n[14]
      ),
      show_share_button: (
        /*show_share_button*/
        n[18]
      ),
      i18n: (
        /*gradio*/
        n[24].i18n
      ),
      show_fullscreen_button: (
        /*show_fullscreen_button*/
        n[23]
      ),
      height: (
        /*height*/
        n[12] || void 0
      ),
      width: (
        /*width*/
        n[13]
      ),
      only_custom_metadata: (
        /*only_custom_metadata*/
        n[9]
      ),
      popup_metadata_width: (
        /*popup_metadata_width*/
        n[10]
      ),
      popup_metadata_height: (
        /*popup_metadata_height*/
        n[11]
      )
    }
  }), i.$on(
    "select",
    /*select_handler*/
    n[35]
  ), i.$on(
    "share",
    /*share_handler*/
    n[36]
  ), i.$on(
    "error",
    /*error_handler*/
    n[37]
  ), i.$on(
    "load_metadata",
    /*handle_load_metadata*/
    n[32]
  ), i.$on(
    "fullscreen",
    /*fullscreen_handler*/
    n[38]
  ), {
    c() {
      Rn(e.$$.fragment), t = ad(), Rn(i.$$.fragment);
    },
    l(o) {
      On(e.$$.fragment, o), t = nd(o), On(i.$$.fragment, o);
    },
    m(o, l) {
      Mn(e, o, l), zo(o, t, l), Mn(i, o, l), r = !0;
    },
    p(o, l) {
      const c = l[0] & /*gradio, loading_status*/
      16777218 ? rd(a, [
        l[0] & /*gradio*/
        16777216 && {
          autoscroll: (
            /*gradio*/
            o[24].autoscroll
          )
        },
        l[0] & /*gradio*/
        16777216 && { i18n: (
          /*gradio*/
          o[24].i18n
        ) },
        l[0] & /*loading_status*/
        2 && id(
          /*loading_status*/
          o[1]
        )
      ]) : {};
      e.$set(c);
      const u = {};
      l[0] & /*fullscreen*/
      67108864 && (u.fullscreen = /*fullscreen*/
      o[26]), l[0] & /*value*/
      1 && (u.value = /*value*/
      o[0]), l[0] & /*label*/
      32 && (u.label = /*label*/
      o[5]), l[0] & /*show_label*/
      64 && (u.show_label = /*show_label*/
      o[6]), l[0] & /*show_download_button*/
      128 && (u.show_download_button = /*show_download_button*/
      o[7]), l[0] & /*_selectable*/
      16384 && (u.selectable = /*_selectable*/
      o[14]), l[0] & /*show_share_button*/
      262144 && (u.show_share_button = /*show_share_button*/
      o[18]), l[0] & /*gradio*/
      16777216 && (u.i18n = /*gradio*/
      o[24].i18n), l[0] & /*show_fullscreen_button*/
      8388608 && (u.show_fullscreen_button = /*show_fullscreen_button*/
      o[23]), l[0] & /*height*/
      4096 && (u.height = /*height*/
      o[12] || void 0), l[0] & /*width*/
      8192 && (u.width = /*width*/
      o[13]), l[0] & /*only_custom_metadata*/
      512 && (u.only_custom_metadata = /*only_custom_metadata*/
      o[9]), l[0] & /*popup_metadata_width*/
      1024 && (u.popup_metadata_width = /*popup_metadata_width*/
      o[10]), l[0] & /*popup_metadata_height*/
      2048 && (u.popup_metadata_height = /*popup_metadata_height*/
      o[11]), i.$set(u);
    },
    i(o) {
      r || (nn(e.$$.fragment, o), nn(i.$$.fragment, o), r = !0);
    },
    o(o) {
      rn(e.$$.fragment, o), rn(i.$$.fragment, o), r = !1;
    },
    d(o) {
      o && Go(t), Ln(e, o), Ln(i, o);
    }
  };
}
function jv(n) {
  let e, t, i, r;
  const a = [Gv, Hv], s = [];
  function o(l, c) {
    return (
      /*interactive*/
      l[20] ? 1 : 0
    );
  }
  return e = o(n), t = s[e] = a[e](n), {
    c() {
      t.c(), i = Yc();
    },
    l(l) {
      t.l(l), i = Yc();
    },
    m(l, c) {
      s[e].m(l, c), zo(l, i, c), r = !0;
    },
    p(l, c) {
      let u = e;
      e = o(l), e === u ? s[e].p(l, c) : (Lv(), rn(s[u], 1, 1, () => {
        s[u] = null;
      }), Rv(), t = s[e], t ? t.p(l, c) : (t = s[e] = a[e](l), t.c()), nn(t, 1), t.m(i.parentNode, i));
    },
    i(l) {
      r || (nn(t), r = !0);
    },
    o(l) {
      rn(t), r = !1;
    },
    d(l) {
      l && Go(i), s[e].d(l);
    }
  };
}
function Wv(n, e, t) {
  let { value_is_output: i = !1 } = e, { elem_id: r = "" } = e, { elem_classes: a = [] } = e, { visible: s = !0 } = e, { value: o = null } = e, { label: l } = e, { show_label: c } = e, { show_download_button: u } = e, { root: f } = e, { only_custom_metadata: h = !0 } = e, { popup_metadata_width: d = 400 } = e, { popup_metadata_height: p = 300 } = e, { height: g } = e, { width: E } = e, { _selectable: w = !1 } = e, { container: m = !0 } = e, { scale: _ = null } = e, { min_width: b = void 0 } = e, { loading_status: y } = e, { show_share_button: D = !1 } = e, { sources: F = ["upload"] } = e, { interactive: x } = e, { pending: T } = e, { placeholder: R = void 0 } = e, { show_fullscreen_button: O } = e, { gradio: L } = e, Z = null, z = !1, ge = !1, G, ve = "upload", q;
  Uv(() => {
    t(33, i = !1);
  });
  const P = (C) => {
    const Ve = C;
    Ve.preventDefault(), Ve.stopPropagation(), Ve.type === "dragenter" || Ve.type === "dragover" ? t(27, G = !0) : Ve.type === "dragleave" && t(27, G = !1);
  }, le = (C) => {
    if (x) {
      const Ve = C;
      Ve.preventDefault(), Ve.stopPropagation(), t(27, G = !1), q && q.loadFilesFromDrop(Ve);
    }
  };
  function S() {
    L.dispatch("load_metadata");
  }
  const ee = ({ detail: C }) => L.dispatch("select", C), K = ({ detail: C }) => L.dispatch("share", C), de = ({ detail: C }) => L.dispatch("error", C), I = ({ detail: C }) => {
    t(26, z = C);
  };
  function Ce(C) {
    z = C, t(26, z);
  }
  const $ = () => L.dispatch("clear_status", y), V = (...C) => L.client.upload(...C);
  function J(C) {
    Cn[C ? "unshift" : "push"](() => {
      q = C, t(29, q);
    });
  }
  function se(C) {
    ge = C, t(25, ge);
  }
  function k(C) {
    ve = C, t(28, ve);
  }
  function nt(C) {
    o = C, t(0, o);
  }
  function Pt(C) {
    G = C, t(27, G);
  }
  const Wt = () => L.dispatch("edit"), vi = () => {
    L.dispatch("clear");
  }, yi = ({ detail: C }) => t(27, G = C), an = () => L.dispatch("upload"), zn = ({ detail: C }) => L.dispatch("select", C), qn = ({ detail: C }) => L.dispatch("share", C), sr = ({ detail: C }) => {
    t(1, y = y || {}), t(1, y.status = "error", y), L.dispatch("error", C);
  }, or = ({ detail: C }) => {
    t(26, z = C);
  };
  function $a(C) {
    z = C, t(26, z);
  }
  return n.$$set = (C) => {
    "value_is_output" in C && t(33, i = C.value_is_output), "elem_id" in C && t(2, r = C.elem_id), "elem_classes" in C && t(3, a = C.elem_classes), "visible" in C && t(4, s = C.visible), "value" in C && t(0, o = C.value), "label" in C && t(5, l = C.label), "show_label" in C && t(6, c = C.show_label), "show_download_button" in C && t(7, u = C.show_download_button), "root" in C && t(8, f = C.root), "only_custom_metadata" in C && t(9, h = C.only_custom_metadata), "popup_metadata_width" in C && t(10, d = C.popup_metadata_width), "popup_metadata_height" in C && t(11, p = C.popup_metadata_height), "height" in C && t(12, g = C.height), "width" in C && t(13, E = C.width), "_selectable" in C && t(14, w = C._selectable), "container" in C && t(15, m = C.container), "scale" in C && t(16, _ = C.scale), "min_width" in C && t(17, b = C.min_width), "loading_status" in C && t(1, y = C.loading_status), "show_share_button" in C && t(18, D = C.show_share_button), "sources" in C && t(19, F = C.sources), "interactive" in C && t(20, x = C.interactive), "pending" in C && t(21, T = C.pending), "placeholder" in C && t(22, R = C.placeholder), "show_fullscreen_button" in C && t(23, O = C.show_fullscreen_button), "gradio" in C && t(24, L = C.gradio);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*uploading*/
    33554432, n.$$.dirty[0] & /*value, gradio*/
    16777217 | n.$$.dirty[1] & /*old_value, value_is_output*/
    12 && JSON.stringify(o) !== JSON.stringify(Z) && (t(34, Z = o), L.dispatch("change"), i || L.dispatch("input"));
  }, [
    o,
    y,
    r,
    a,
    s,
    l,
    c,
    u,
    f,
    h,
    d,
    p,
    g,
    E,
    w,
    m,
    _,
    b,
    D,
    F,
    x,
    T,
    R,
    O,
    L,
    ge,
    z,
    G,
    ve,
    q,
    P,
    le,
    S,
    i,
    Z,
    ee,
    K,
    de,
    I,
    Ce,
    $,
    V,
    J,
    se,
    k,
    nt,
    Pt,
    Wt,
    vi,
    yi,
    an,
    zn,
    qn,
    sr,
    or,
    $a
  ];
}
class pI extends Ov {
  constructor(e) {
    super(), Mv(
      this,
      e,
      Wv,
      jv,
      Nv,
      {
        value_is_output: 33,
        elem_id: 2,
        elem_classes: 3,
        visible: 4,
        value: 0,
        label: 5,
        show_label: 6,
        show_download_button: 7,
        root: 8,
        only_custom_metadata: 9,
        popup_metadata_width: 10,
        popup_metadata_height: 11,
        height: 12,
        width: 13,
        _selectable: 14,
        container: 15,
        scale: 16,
        min_width: 17,
        loading_status: 1,
        show_share_button: 18,
        sources: 19,
        interactive: 20,
        pending: 21,
        placeholder: 22,
        show_fullscreen_button: 23,
        gradio: 24
      },
      null,
      [-1, -1]
    );
  }
  get value_is_output() {
    return this.$$.ctx[33];
  }
  set value_is_output(e) {
    this.$$set({ value_is_output: e }), oe();
  }
  get elem_id() {
    return this.$$.ctx[2];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), oe();
  }
  get elem_classes() {
    return this.$$.ctx[3];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), oe();
  }
  get visible() {
    return this.$$.ctx[4];
  }
  set visible(e) {
    this.$$set({ visible: e }), oe();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(e) {
    this.$$set({ value: e }), oe();
  }
  get label() {
    return this.$$.ctx[5];
  }
  set label(e) {
    this.$$set({ label: e }), oe();
  }
  get show_label() {
    return this.$$.ctx[6];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), oe();
  }
  get show_download_button() {
    return this.$$.ctx[7];
  }
  set show_download_button(e) {
    this.$$set({ show_download_button: e }), oe();
  }
  get root() {
    return this.$$.ctx[8];
  }
  set root(e) {
    this.$$set({ root: e }), oe();
  }
  get only_custom_metadata() {
    return this.$$.ctx[9];
  }
  set only_custom_metadata(e) {
    this.$$set({ only_custom_metadata: e }), oe();
  }
  get popup_metadata_width() {
    return this.$$.ctx[10];
  }
  set popup_metadata_width(e) {
    this.$$set({ popup_metadata_width: e }), oe();
  }
  get popup_metadata_height() {
    return this.$$.ctx[11];
  }
  set popup_metadata_height(e) {
    this.$$set({ popup_metadata_height: e }), oe();
  }
  get height() {
    return this.$$.ctx[12];
  }
  set height(e) {
    this.$$set({ height: e }), oe();
  }
  get width() {
    return this.$$.ctx[13];
  }
  set width(e) {
    this.$$set({ width: e }), oe();
  }
  get _selectable() {
    return this.$$.ctx[14];
  }
  set _selectable(e) {
    this.$$set({ _selectable: e }), oe();
  }
  get container() {
    return this.$$.ctx[15];
  }
  set container(e) {
    this.$$set({ container: e }), oe();
  }
  get scale() {
    return this.$$.ctx[16];
  }
  set scale(e) {
    this.$$set({ scale: e }), oe();
  }
  get min_width() {
    return this.$$.ctx[17];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), oe();
  }
  get loading_status() {
    return this.$$.ctx[1];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), oe();
  }
  get show_share_button() {
    return this.$$.ctx[18];
  }
  set show_share_button(e) {
    this.$$set({ show_share_button: e }), oe();
  }
  get sources() {
    return this.$$.ctx[19];
  }
  set sources(e) {
    this.$$set({ sources: e }), oe();
  }
  get interactive() {
    return this.$$.ctx[20];
  }
  set interactive(e) {
    this.$$set({ interactive: e }), oe();
  }
  get pending() {
    return this.$$.ctx[21];
  }
  set pending(e) {
    this.$$set({ pending: e }), oe();
  }
  get placeholder() {
    return this.$$.ctx[22];
  }
  set placeholder(e) {
    this.$$set({ placeholder: e }), oe();
  }
  get show_fullscreen_button() {
    return this.$$.ctx[23];
  }
  set show_fullscreen_button(e) {
    this.$$set({ show_fullscreen_button: e }), oe();
  }
  get gradio() {
    return this.$$.ctx[24];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), oe();
  }
}
export {
  _I as BaseExample,
  Lo as BaseImage,
  v2 as BaseImageUploader,
  R0 as BaseStaticImage,
  pI as default
};
