export { default as Image } from "./Image.svelte";
export { default as StaticImage } from "./ImagePreview.svelte";
