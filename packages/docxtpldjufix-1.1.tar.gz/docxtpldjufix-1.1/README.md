ATTENTION!
This library was not created by me! The original author is:
authors = [{name="Eric Lapouyade", email="elapouya@proton.me"}]

Here are the links to his stuff:
homepage = "https://github.com/elapouya/python-docx-template"
repository = "https://github.com/elapouya/python-docx-template.git"
document = "https://docxtpl.readthedocs.org"

Also the workaround the deprecation issue cased pkg_resources was not invented by me either.
I found it on github (https://github.com/dlt-hub/dlt/pull/2707) and I believe I discovered it from the user: djudjuu

All of the credit goes to the people mentioned above.