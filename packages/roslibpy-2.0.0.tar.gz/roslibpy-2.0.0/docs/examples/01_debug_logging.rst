Enable debug logging
====================

This example shows how to enable debugging output using Python ``logging`` infrastructure.

.. literalinclude :: 01_debug_logging.py
   :language: python
