# Henotace AI Tutor SDK

A Python SDK for integrating with Henotace AI's AI Tutor API. Provides intelligent tutoring capabilities for personalized learning experiences.

## Features

- **AI Tutoring Sessions**: Create and manage personalized tutoring sessions
- **Intelligent Chat**: Interactive conversations with AI tutors
- **Multi-Subject Support**: Mathematics, Science, English, and more
- **Grade-Level Adaptation**: Content tailored to different educational levels
- **Context-Aware Responses**: Maintains conversation context for better learning
- **Secure Authentication**: API key-based authentication
- **Usage Tracking**: Built-in usage tracking and rate limiting

## Installation

```bash
pip install henotace-ai-sdk
```

## Quick Start

```python
from henotace_sdk import HenotaceAITutorSDK, create_ai_tutor_client

# Initialize the AI Tutor SDK
tutor = create_ai_tutor_client(api_key="your_api_key_here")

# Create a tutoring session
session = tutor.create_tutoring_session(
    student_id="student_123",
    subject="mathematics",
    grade_level="secondary",
    topic="algebra"
)

# Start a conversation with the AI tutor
response = tutor.chat_with_tutor(
    session_id=session['data']['session_id'],
    message="Can you help me solve 2x + 5 = 13?",
    context={"previous_messages": []}
)

print(f"AI Tutor: {response['data']['ai_response']}")

# Continue the conversation
follow_up = tutor.chat_with_tutor(
    session_id=session['data']['session_id'],
    message="What's the next step?",
    context={"previous_messages": [response['data']]}
)

print(f"AI Tutor: {follow_up['data']['ai_response']}")
```

## API Reference

### HenotaceAITutorSDK

#### `create_tutoring_session(student_id, subject, grade_level, topic="", language="en")`
Creates a new AI tutoring session.

**Parameters:**
- `student_id` (str): Unique identifier for the student
- `subject` (str): Subject area (e.g., 'mathematics', 'science', 'english')
- `grade_level` (str): Grade level (e.g., 'primary', 'secondary', 'university')
- `topic` (str): Specific topic to focus on (optional)
- `language` (str): Language for the session (default: 'en')

**Returns:** Session information including session_id

#### `chat_with_tutor(session_id, message, context=None)`
Send a message to the AI tutor.

**Parameters:**
- `session_id` (str): Session ID from create_tutoring_session
- `message` (str): Student's message/question
- `context` (dict): Additional context (optional)

**Returns:** AI tutor's response

#### `get_status()`
Get API status and client information.

**Returns:** Status information including remaining API calls

#### `get_remaining_calls()`
Get remaining API calls for the current client.

**Returns:** Number of remaining API calls

#### `is_healthy()`
Check if the API is healthy and accessible.

**Returns:** True if API is healthy, False otherwise

## Error Handling

```python
from henotace_sdk import HenotaceAPIError

try:
    response = tutor.chat_with_tutor(session_id, message)
except HenotaceAPIError as e:
    print(f"API Error: {e.message}")
    print(f"Status Code: {e.status_code}")
```

## Configuration

```python
# For production use
tutor = HenotaceAITutorSDK(
    api_key="your_api_key_here",
    base_url="https://api.henotace.ai/api/external"
)

# For development
tutor = HenotaceAITutorSDK(
    api_key="your_api_key_here",
    base_url="http://localhost:8000/api/external"
)
```

## Development

### Setup Development Environment

```bash
git clone https://github.com/henotace/henotace-ai-sdk-python.git
cd henotace-ai-sdk-python
pip install -e ".[dev]"
```

### Running Tests

```bash
pytest
```

### Code Formatting

```bash
black henotace_sdk/
flake8 henotace_sdk/
```

## Documentation

For more information, visit [Henotace AI Documentation](https://docs.henotace.ai).

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

- 📧 Email: support@henotace.ai
- 📖 Documentation: https://docs.henotace.ai
- 🐛 Issues: https://github.com/henotace/henotace-ai-sdk-python/issues

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Changelog

### 1.1.0
- Focused on AI Tutor functionality only
- Simplified API for tutoring sessions
- Enhanced conversation context handling
- Improved error handling and documentation

### 1.0.0
- Initial release with full educational API support