from qtpy.QtWidgets import *  # noqa: F403
