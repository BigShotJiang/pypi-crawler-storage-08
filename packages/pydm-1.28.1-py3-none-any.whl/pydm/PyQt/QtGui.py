from qtpy.QtGui import *  # noqa: F403
from qtpy.QtWidgets import *  # noqa: F403
