import warnings

warnings.warn(
    "'pydm.PyQt' is deprecated, please directly import from the 'qtpy' module.  pydm.PyQt will be removed in PyDM v1.8"
)
