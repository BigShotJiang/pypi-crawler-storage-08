from qtpy.QtSvg import *  # noqa: F403
