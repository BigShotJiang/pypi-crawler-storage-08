from qtpy.uic import *  # noqa: F403
