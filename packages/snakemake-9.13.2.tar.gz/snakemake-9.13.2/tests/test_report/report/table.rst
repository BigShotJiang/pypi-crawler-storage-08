An example table.
