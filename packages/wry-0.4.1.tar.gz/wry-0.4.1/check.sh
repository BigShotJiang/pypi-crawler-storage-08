#!/bin/bash

pre-commit run --all-files
