slapos.core
===========

The core of SlapOS.
Contains the SLAP library, and the slapos command line tools.
For more information, see https://slapos.nexedi.com/ .
