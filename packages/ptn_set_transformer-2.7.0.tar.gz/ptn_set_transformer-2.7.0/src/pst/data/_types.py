from typing import Literal

FeatureLevel = Literal["node", "graph", "protein", "scaffold", "genome"]
