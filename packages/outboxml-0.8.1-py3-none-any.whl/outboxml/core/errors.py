class ConfigError(Exception):
    pass


class ModelNotFoundError(Exception):
    pass


class EnsembleError(Exception):
    pass
