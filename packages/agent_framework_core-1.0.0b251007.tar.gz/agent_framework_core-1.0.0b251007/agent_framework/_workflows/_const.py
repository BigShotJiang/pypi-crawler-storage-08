# Copyright (c) Microsoft. All rights reserved.

DEFAULT_MAX_ITERATIONS = 100  # Default maximum iterations for workflow execution.
