# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Ugc Service."""

__version__ = "2.25.0"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .admin_create_type import AdminCreateType
from .admin_delete_type import AdminDeleteType
from .admin_get_type import AdminGetType
from .admin_update_type import AdminUpdateType
