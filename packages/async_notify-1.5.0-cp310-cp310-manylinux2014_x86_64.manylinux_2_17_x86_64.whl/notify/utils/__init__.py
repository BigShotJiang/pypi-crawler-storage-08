from .functions import cPrint, Msg

__all__ = (
    "cPrint",
    "Msg",
)
