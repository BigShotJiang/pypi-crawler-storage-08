from .typedefs import SafeDict, AttrDict


__all__ = (
    'SafeDict', 'AttrDict',
)
