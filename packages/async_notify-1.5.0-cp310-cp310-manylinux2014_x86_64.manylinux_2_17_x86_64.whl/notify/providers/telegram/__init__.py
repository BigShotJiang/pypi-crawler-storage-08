"""
telegram.

using a bot to send messages to a Telegram Chat.
"""
from .Telegram import Telegram

__all__ = ("Telegram",)
