"""
XMPP.

Provider to sent XMPP Messages (jabber protocol)
"""

from .xmpp import Xmpp

__all__ = ["Xmpp"]
