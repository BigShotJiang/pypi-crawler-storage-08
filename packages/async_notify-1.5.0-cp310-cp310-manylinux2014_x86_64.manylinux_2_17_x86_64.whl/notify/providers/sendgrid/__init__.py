"""
email.

Provider for basic email messages
"""
from .sendgrid import Sendgrid

__all__ = ["Sendgrid"]
