"""
MS Teams.

using a webhook to send messages to a MS Teams Channel.
"""
from .teams import Teams

__all__ = ("Teams",)
