"""
Amazon AWS Email.

Sending Emails using Amazon SMTP services
"""
from .aws import Aws

__all__ = ["Aws"]
