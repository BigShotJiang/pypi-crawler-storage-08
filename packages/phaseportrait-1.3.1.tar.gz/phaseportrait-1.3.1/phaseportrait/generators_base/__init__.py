try:
    __GENERATOR_BASE_IMPORTED__
except NameError:
    __GENERATOR_BASE_IMPORTED__= False

if not __GENERATOR_BASE_IMPORTED__:
    from .generator_base import _Generator_
__GENERATOR_BASE_IMPORTED__ = True