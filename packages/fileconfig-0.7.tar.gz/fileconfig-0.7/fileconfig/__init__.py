"""Parse config file and return class instances for each section."""

from .bases import Config, Stacked

__all__ = ['Config', 'Stacked']

__title__ = 'fileconfig'
__version__ = '0.7'
__author__ = 'Sebastian Bank <sebastian.bank@uni-leipzig.de>'
__license__ = 'MIT, see LICENSE.txt'
__copyright__ = 'Copyright (c) 2014-2025 Sebastian Bank'
