from enum import Enum, auto


class Mode(Enum):
    TRAIN = auto()
    TEST = auto()
    POPULATE = auto()
