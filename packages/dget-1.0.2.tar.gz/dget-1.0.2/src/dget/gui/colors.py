dget_state_used = "#fa4d56"
dget_state_unused = "#009d9a"
dget_spectra = "#a56eff"
dget_spectra_series = ["#a56eff", "#1192e8"]
