# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.9.1
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x01\x88\
[\
Icon Theme]\x0aName\
=dget\x0aComment=Ic\
ons from KDE the\
me Breeze\x0aDirect\
ories=16x16,22x2\
2,24x24,32x32,16\
x16@2,22x22@2,24\
x24@2,32x32@2\x0a\x0a[\
16x16]\x0aSize=16\x0aT\
ype=Fixed\x0a\x0a[16x1\
6@2]\x0aSize=16\x0aSca\
le=2\x0aType=Fixed\x0a\
\x0a[22x22]\x0aSize=22\
\x0aType=Fixed\x0a\x0a[22\
x22@2]\x0aSize=22\x0aS\
cale=2\x0aType=Fixe\
d\x0a\x0a[24x24]\x0aSize=\
24\x0aType=Fixed\x0a\x0a[\
24x24@2]\x0aSize=24\
\x0aScale=2\x0aType=Fi\
xed\x0a\x0a[32x32]\x0aSiz\
e=32\x0aType=Fixed\x0a\
\x0a[32x32@2]\x0aSize=\
32\x0aScale=2\x0aType=\
Fixed\x0a\x0a\
\x00\x00\x02\x88\
<\
svg version=\x221.1\
\x22 viewBox=\x220 0 2\
2 22\x22 xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22>\x0a    <d\
efs>\x0a        <st\
yle type=\x22text/c\
ss\x22 id=\x22current-\
color-scheme\x22>\x0a \
           .Colo\
rScheme-Text {\x0a \
               c\
olor:#232629;\x0a  \
          }\x0a    \
    </style>\x0a   \
 </defs>\x0a    <pa\
th style=\x22fill:c\
urrentColor;fill\
-opacity:1;strok\
e:none\x22\x0a        \
  d=\x22m14 11c-2.2\
15995 0-4 1.7840\
05-4 4s1.784005 \
4 4 4 4-1.784005\
 4-4-1.784005-4-\
4-4m0 1c1.661995\
 0 3 1.338005 3 \
3s-1.338005 3-3 \
3-3-1.338005-3-3\
 1.338005-3 3-3m\
-1 1v3h2v-1h-1v-\
2h-1m-9-10v16h6v\
-1h-5v-14h8v4h4v\
3h1v-4.0078125l-\
3.992188-3.99218\
75-0.007812 0.00\
97656v-0.0097656\
h-9z\x22\x0a          \
class=\x22ColorSche\
me-Text\x22\x0a    />\x0a\
</svg>\x0a\
\x00\x00\x02\x80\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 22 22\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a     style=\x22f\
ill:currentColor\
;fill-opacity:1;\
stroke:none\x22 \x0a  \
   d=\x22M 11 3 C 6\
.568 3 3 6.568 3\
 11 C 3 15.432 6\
.568 19 11 19 C \
15.432 19 19 15.\
432 19 11 C 19 6\
.568 15.432 3 11\
 3 z M 11 4 C 14\
.878 4 18 7.122 \
18 11 C 18 14.87\
8 14.878 18 11 1\
8 C 7.122 18 4 1\
4.878 4 11 C 4 7\
.122 7.122 4 11 \
4 z M 10 6 L 10 \
8 L 12 8 L 12 6 \
L 10 6 z M 10 9 \
L 10 16 L 12 16 \
L 12 9 L 10 9 z \
\x22\x0a     class=\x22Co\
lorScheme-Text\x22\x0a\
     />\x0a</svg>\x0a\
\x00\x00\x03Q\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 22 22\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a    style=\x22fi\
ll:currentColor;\
fill-opacity:1;s\
troke:none\x22 \x0a\x09d=\
\x22M 2 3 L 2 19 L \
19 19 L 19 3 L 2\
 3 z M 3 4 L 10 \
4 L 10 10 L 3 10\
 L 3 4 z M 11 4 \
L 18 4 L 18 10 L\
 11 10 L 11 4 z \
M 6.0800781 5.00\
19531 A 2 2 0 0 \
0 4.6230469 5.55\
07812 A 2 2 0 0 \
0 4.2519531 7.97\
07031 A 2 2 0 0 \
0 6.5019531 8.93\
55469 A 2 2 0 0 \
0 8 7 L 6 7 L 7.\
0585938 5.302734\
4 A 2 2 0 0 0 6.\
0800781 5.001953\
1 z M 3 11 L 10 \
11 L 10 18 L 3 1\
8 L 3 11 z M 11 \
11 L 18 11 L 18 \
18 L 11 18 L 11 \
11 z M 16 12 L 1\
6 17 L 17 17 L 1\
7 12 L 16 12 z M\
 14 14 L 14 17 L\
 15 17 L 15 14 L\
 14 14 z M 12 15\
 L 12 17 L 13 17\
 L 13 15 L 12 15\
 z \x22\x0a    class=\x22\
ColorScheme-Text\
\x22\x0a    />\x0a</svg>\x0a\
\
\x00\x00\x02\xcd\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 22 22\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a    style=\x22fi\
ll:currentColor;\
fill-opacity:1;s\
troke:none\x22 \x0a   \
 d=\x22M 3 3 L 3 19\
 L 19 19 L 19 3 \
L 3 3 z M 4 7 L \
18 7 L 18 18 L 4\
 18 L 4 7 z M 6 \
8 L 6 12 L 10 12\
 L 10 8 L 6 8 z \
M 12 8 L 12 12 L\
 16 12 L 16 8 L \
12 8 z M 7 9 L 9\
 9 L 9 11 L 7 11\
 L 7 9 z M 13 9 \
L 15 9 L 15 11 L\
 13 11 L 13 9 z \
M 6 13 L 6 17 L \
10 17 L 10 13 L \
6 13 z M 12 13 L\
 12 17 L 16 17 L\
 16 13 L 12 13 z\
 M 7 14 L 9 14 L\
 9 16 L 7 16 L 7\
 14 z M 13 14 L \
15 14 L 15 16 L \
13 16 L 13 14 z \
\x22\x0a\x09class=\x22ColorS\
cheme-Text\x22\x0a    \
/>  \x0a</svg>\x0a\
\x00\x00\x06\x9d\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 22 22\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      .ColorSc\
heme-Accent {\x0a  \
      color:#3da\
ee9;\x0a      }\x0a   \
   </style>\x0a  </\
defs>\x0a <path \x0a  \
   style=\x22fill:c\
urrentColor;fill\
-opacity:1;strok\
e:none\x22 \x0a     d=\
\x22M 4 3 L 4 9 L 4\
 10 L 4 15 L 4 1\
6 L 4 17 L 3 17 \
L 3 18 L 4 18 L \
4 19 L 5 19 L 5 \
18 L 18.292969 1\
8 L 19 18 L 19 1\
7.292969 L 19 17\
 L 18.707031 17 \
L 17.958984 16.2\
51953 L 17.13085\
9 15.423828 L 15\
.130859 13.42382\
8 L 15.126953 13\
.427734 L 15.121\
094 13.423828 L \
12.998047 15.546\
875 L 11.703125 \
14.251953 L 10.8\
75 13.423828 L 8\
.875 11.423828 L\
 8.8730469 11.42\
3828 L 7 11.4238\
28 L 6 11.423828\
 L 5 11.423828 L\
 5 11 L 5 10 L 6\
 10 L 7 10 L 8.8\
730469 10 L 8.87\
5 10 L 10.875 8 \
L 11.703125 7.17\
1875 L 12.998047\
 5.8769531 L 15.\
121094 8 L 15.12\
6953 7.9960938 L\
 15.130859 8 L 1\
7.130859 6 L 17.\
958984 5.171875 \
L 19 4.1308594 L\
 18.292969 3.423\
8281 L 17.251953\
 4.4648438 L 16.\
423828 5.2929688\
 L 15.126953 6.5\
898438 L 13 4.46\
48438 L 12.99804\
7 4.4667969 L 12\
.996094 4.464843\
8 L 11.46875 5.9\
921875 L 5 5.992\
1875 L 5 5 L 5 3\
 L 4 3 z M 5 6 L\
 11.460938 6 L 1\
0.996094 6.46484\
38 L 10.167969 7\
.2929688 L 8.460\
9375 9 L 7 9 L 6\
 9 L 5 9 L 5 6 z\
 M 5 12.423828 L\
 6 12.423828 L 7\
 12.423828 L 8.4\
609375 12.423828\
 L 10.167969 14.\
130859 L 10.9960\
94 14.958984 L 1\
1.460938 15.4238\
28 L 5 15.423828\
 L 5 15 L 5 12.4\
23828 z M 15.126\
953 14.833984 L \
16.423828 16.130\
859 L 17.251953 \
16.958984 L 17.2\
92969 17 L 5 17 \
L 5 16 L 5 15.43\
1641 L 11.46875 \
15.431641 L 12.9\
96094 16.958984 \
L 12.998047 16.9\
57031 L 13 16.95\
8984 L 15.126953\
 14.833984 z \x22\x0a \
    class=\x22Color\
Scheme-Text\x22\x0a   \
  />\x0a</svg>\x0a\
\x00\x00\x02\xb0\
<\
svg id=\x22svg6\x22 ve\
rsion=\x221.1\x22 view\
Box=\x220 0 22 22\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a    <defs id\
=\x22defs3051\x22>\x0a   \
 <style type=\x22te\
xt/css\x22 id=\x22curr\
ent-color-scheme\
\x22>\x0a        .Colo\
rScheme-Text {  \
          color:\
#232629;        \
}\x0a    </style>\x0a \
   </defs>\x0a    <\
path id=\x22path347\
\x22 d=\x22m11 3a8 8 0\
 0 0-8 8 8 8 0 0\
 0 8 8 8 8 0 0 0\
 4.892578-1.6933\
59l3.400391 3.40\
039a1 1 0 0 0 1.\
414062 0 1 1 0 0\
 0 0-1.414062l-3\
.40039-3.400391a\
8 8 0 0 0 1.6933\
59-4.892578 8 8 \
0 0 0-8-8zm0 1a7\
 7 0 0 1 7 7 7 7\
 0 0 1-7 7 7 7 0\
 0 1-7-7 7 7 0 0\
 1 7-7zm-4 3v8h4\
v-8h-4zm6 4v4h2v\
-4h-2z\x22 class=\x22C\
olorScheme-Text\x22\
 fill=\x22currentCo\
lor\x22 stroke-line\
cap=\x22square\x22 str\
oke-width=\x222\x22 st\
yle=\x22paint-order\
:markers stroke \
fill\x22/>\x0a</svg>\x0a\
\x00\x00\x02\xf8\
<\
svg id=\x22svg6\x22 ve\
rsion=\x221.1\x22 view\
Box=\x220 0 22 22\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a    <defs id\
=\x22defs3051\x22>\x0a   \
 <style type=\x22te\
xt/css\x22 id=\x22curr\
ent-color-scheme\
\x22>\x0a        .Colo\
rScheme-Text {  \
          color:\
#232629;        \
}\x0a    </style>\x0a \
   </defs>\x0a    <\
path id=\x22path347\
\x22 d=\x22m3 3v6h0.26\
95312 1.0332032 \
4.6972656l-2.939\
4531-2.9394531a7\
 7 0 0 1 4.93945\
31-2.0605469 7 7\
 0 0 1 7 7 7 7 0\
 0 1-7 7 7 7 0 0\
 1-7-7h-1a8 8 0 \
0 0 8 8 8 8 0 0 \
0 4.892578-1.693\
359l3.400391 3.4\
0039a1 1 0 0 0 1\
.414062 0 1 1 0 \
0 0 0-1.414062l-\
3.40039-3.400391\
a8 8 0 0 0 1.693\
359-4.892578 8 8\
 0 0 0-8-8 8 8 0\
 0 0-5.6347656 2\
.3652344l-2.3652\
344-2.3652344z\x22 \
class=\x22ColorSche\
me-Text\x22 fill=\x22c\
urrentColor\x22 str\
oke-linecap=\x22squ\
are\x22 stroke-widt\
h=\x222\x22 style=\x22pai\
nt-order:markers\
 stroke fill\x22/>\x0a\
</svg>\x0a\
\x00\x00\x01s\
<\
svg version=\x221.1\
\x22 viewBox=\x220 0 2\
2 22\x22 xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
        .ColorSc\
heme-Accent {\x0a  \
          color:\
#3daee9;\x0a       \
 }\x0a    </style>\x0a\
    <rect class=\
\x22ColorScheme-Acc\
ent\x22 x=\x223\x22 y=\x223\x22\
 width=\x2216\x22 heig\
ht=\x2216\x22 rx=\x222\x22 f\
ill=\x22currentColo\
r\x22/>\x0a    <path d\
=\x22m10 6v2h2v-2zm\
0 4v6h2v-6z\x22 fil\
l=\x22#fff\x22/>\x0a</svg\
>\x0a\
\x00\x00\x01\xbf\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2222\
\x22 height=\x2222\x22>\x0d\x0a\
    <defs id=\x22de\
fs3051\x22>\x0d\x0a      \
  <style type=\x22t\
ext/css\x22 id=\x22cur\
rent-color-schem\
e\x22>\x0d\x0a        .Co\
lorScheme-Negati\
veText {\x0d\x0a      \
      color:#da4\
453;\x0d\x0a        }\x0d\
\x0a        </style\
>\x0d\x0a    </defs>\x0d\x0a\
 <path\x0d\x0a     sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22\x0d\x0a     class=\x22C\
olorScheme-Negat\
iveText\x22\x0d\x0a     d\
=\x22m3 3v4 12h1 14\
 1v-1-12-3h-15-1\
m1 4h14v11h-14v-\
11m4 4v2h6v-2h-6\
\x22 />\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x02S\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 22 22\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a    style=\x22fi\
ll:currentColor;\
fill-opacity:1;s\
troke:none\x22 \x0a   \
 d=\x22M 4 3 L 4 19\
 L 9 19 L 9 18 L\
 5 18 L 5 4 L 13\
 4 L 13 8 L 17 8\
 L 17 11 L 18 11\
 L 18 7 L 14 3 L\
 14 3 L 14 3 L 5\
 3 L 4 3 z M 10 \
12 L 10 19 L 18 \
19 L 18 13 L 15 \
13 L 14 12 L 14 \
12 L 14 12 L 10 \
12 z M 13.1 14 L\
 17 14 L 17 18 L\
 11 18 L 11 15 L\
 12 15 L 13.1 14\
 z \x22\x0a    class=\x22\
ColorScheme-Text\
\x22\x0a    />  \x0a</svg\
>\x0a\
\x00\x00\x02\xb0\
<\
svg id=\x22svg6\x22 ve\
rsion=\x221.1\x22 view\
Box=\x220 0 22 22\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a    <defs id\
=\x22defs3051\x22>\x0a   \
 <style type=\x22te\
xt/css\x22 id=\x22curr\
ent-color-scheme\
\x22>\x0a        .Colo\
rScheme-Text {  \
          color:\
#232629;        \
}\x0a    </style>\x0a \
   </defs>\x0a    <\
path id=\x22path347\
\x22 d=\x22m11 3a8 8 0\
 0 0-8 8 8 8 0 0\
 0 8 8 8 8 0 0 0\
 4.892578-1.6933\
59l3.400391 3.40\
039a1 1 0 0 0 1.\
414062 0 1 1 0 0\
 0 0-1.414062l-3\
.40039-3.400391a\
8 8 0 0 0 1.6933\
59-4.892578 8 8 \
0 0 0-8-8zm0 1a7\
 7 0 0 1 7 7 7 7\
 0 0 1-7 7 7 7 0\
 0 1-7-7 7 7 0 0\
 1 7-7zm0 3v8h4v\
-8h-4zm-4 4v4h2v\
-4h-2z\x22 class=\x22C\
olorScheme-Text\x22\
 fill=\x22currentCo\
lor\x22 stroke-line\
cap=\x22square\x22 str\
oke-width=\x222\x22 st\
yle=\x22paint-order\
:markers stroke \
fill\x22/>\x0a</svg>\x0a\
\x00\x00\x01\xac\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 22 22\x22>\x0d\x0a  <\
defs id=\x22defs305\
1\x22>\x0d\x0a    <style \
type=\x22text/css\x22 \
id=\x22current-colo\
r-scheme\x22>\x0d\x0a    \
  .ColorScheme-T\
ext {\x0d\x0a        c\
olor:#232629;\x0d\x0a \
     }\x0d\x0a      </\
style>\x0d\x0a  </defs\
>\x0d\x0a <path \x0d\x0a    \
 style=\x22fill:cur\
rentColor;fill-o\
pacity:1;stroke:\
none\x22 \x0d\x0a     d=\x22\
m5 3v1 1h-2v3h2v\
6h-2v3h2v2h1 13v\
-1-14-1h-14m1 1h\
2v14h-2v-14m3 0h\
9v14h-9v-14\x22\x0d\x0a\x09 \
class=\x22ColorSche\
me-Text\x22\x0d\x0a     /\
>\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x03\x88\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 22 22\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 11.5 3 C 10.28\
6139 3 9.2809778\
 3.8559279 9.050\
7812 5 L 3 5 L 3\
 6 L 9.0507812 6\
 C 9.2809778 7.1\
440721 10.286139\
 8 11.5 8 C 12.7\
13861 8 13.71902\
2 7.1440721 13.9\
49219 6 L 19 6 L\
 19 5 L 13.94921\
9 5 C 13.719022 \
3.8559279 12.713\
861 3 11.5 3 z M\
 5.5 14 C 4.1149\
999 14 3 15.115 \
3 16.5 C 3 17.88\
5 4.1149999 19 5\
.5 19 C 6.713860\
4 19 7.7190223 1\
8.144072 7.94921\
88 17 L 19 17 L \
19 16 L 7.949218\
8 16 C 7.7190223\
 14.855928 6.713\
8604 14 5.5 14 z\
 M 5.5 15 C 6.33\
10001 15 7 15.66\
9 7 16.5 C 7 17.\
331 6.3310001 18\
 5.5 18 C 4.6689\
999 18 4 17.331 \
4 16.5 C 4 15.66\
9 4.6689999 15 5\
.5 15 z \x22\x0a     c\
lass=\x22ColorSchem\
e-Text\x22\x0a     />\x0a\
</svg>\x0a\
\x00\x00\x02\xa5\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 22 22\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a     style=\x22f\
ill:currentColor\
;fill-opacity:1;\
stroke:none\x22 \x0a  \
   d=\x22M 4 3 L 4 \
9 L 4 10 L 4 15 \
L 4 16 L 4 17 L \
3 17 L 3 18 L 4 \
18 L 4 19 L 5 19\
 L 5 18 L 19 18 \
L 19 17 L 16 17 \
L 16 8 L 15 8 L \
12 8 L 12 17 L 1\
0 17 L 10 7 L 10\
 4 L 10 3 L 6 3 \
L 6 17 L 5 17 L \
5 16 L 5 15 L 5 \
12 L 5 11 L 5 10\
 L 5 9 L 5 6 L 5\
 5.9921875 L 5 5\
 L 5 3 L 4 3 z M\
 7 4 L 9 4 L 9 1\
7 L 7 17 L 7 4 z\
 M 13 9 L 15 9 L\
 15 17 L 13 17 L\
 13 9 z \x22\x0a\x09 clas\
s=\x22ColorScheme-T\
ext\x22\x0a     />\x0a</s\
vg>\x0a\
\x00\x00\x02\xa6\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 version=\x22\
1.1\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24\x22 height=\x2224\x22>\
\x0a  <defs>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
            .Col\
orScheme-Text {\x0a\
                \
color:#232629;\x0a \
           }\x0a   \
     </style>\x0a  \
</defs>\x0a  <g tra\
nsform=\x22translat\
e(1,1)\x22>\x0a    <pa\
th style=\x22fill:c\
urrentColor;fill\
-opacity:1;strok\
e:none\x22 d=\x22m14 1\
1c-2.215995 0-4 \
1.784005-4 4s1.7\
84005 4 4 4 4-1.\
784005 4-4-1.784\
005-4-4-4m0 1c1.\
661995 0 3 1.338\
005 3 3s-1.33800\
5 3-3 3-3-1.3380\
05-3-3 1.338005-\
3 3-3m-1 1v3h2v-\
1h-1v-2h-1m-9-10\
v16h6v-1h-5v-14h\
8v4h4v3h1v-4.007\
8125l-3.992188-3\
.9921875-0.00781\
2 0.0097656v-0.0\
097656h-9z\x22 clas\
s=\x22ColorScheme-T\
ext\x22/>\x0a  </g>\x0a</\
svg>\x0a\
\x00\x00\x02\xab\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 11 3 C 6.\
568 3 3 6.568 3 \
11 C 3 15.432 6.\
568 19 11 19 C 1\
5.432 19 19 15.4\
32 19 11 C 19 6.\
568 15.432 3 11 \
3 z M 11 4 C 14.\
878 4 18 7.122 1\
8 11 C 18 14.878\
 14.878 18 11 18\
 C 7.122 18 4 14\
.878 4 11 C 4 7.\
122 7.122 4 11 4\
 z M 10 6 L 10 8\
 L 12 8 L 12 6 L\
 10 6 z M 10 9 L\
 10 16 L 12 16 L\
 12 9 L 10 9 z \x22\
 class=\x22ColorSch\
eme-Text\x22/>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x03\x83\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 2 3 L 2 1\
9 L 19 19 L 19 3\
 L 2 3 z M 3 4 L\
 10 4 L 10 10 L \
3 10 L 3 4 z M 1\
1 4 L 18 4 L 18 \
10 L 11 10 L 11 \
4 z M 6.0800781 \
5.0019531 A 2 2 \
0 0 0 4.6230469 \
5.5507812 A 2 2 \
0 0 0 4.2519531 \
7.9707031 A 2 2 \
0 0 0 6.5019531 \
8.9355469 A 2 2 \
0 0 0 8 7 L 6 7 \
L 7.0585938 5.30\
27344 A 2 2 0 0 \
0 6.0800781 5.00\
19531 z M 3 11 L\
 10 11 L 10 18 L\
 3 18 L 3 11 z M\
 11 11 L 18 11 L\
 18 18 L 11 18 L\
 11 11 z M 16 12\
 L 16 17 L 17 17\
 L 17 12 L 16 12\
 z M 14 14 L 14 \
17 L 15 17 L 15 \
14 L 14 14 z M 1\
2 15 L 12 17 L 1\
3 17 L 13 15 L 1\
2 15 z \x22 class=\x22\
ColorScheme-Text\
\x22/>\x0a  </g>\x0a</svg\
>\x0a\
\x00\x00\x02\xfd\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 3 3 L 3 1\
9 L 19 19 L 19 3\
 L 3 3 z M 4 7 L\
 18 7 L 18 18 L \
4 18 L 4 7 z M 6\
 8 L 6 12 L 10 1\
2 L 10 8 L 6 8 z\
 M 12 8 L 12 12 \
L 16 12 L 16 8 L\
 12 8 z M 7 9 L \
9 9 L 9 11 L 7 1\
1 L 7 9 z M 13 9\
 L 15 9 L 15 11 \
L 13 11 L 13 9 z\
 M 6 13 L 6 17 L\
 10 17 L 10 13 L\
 6 13 z M 12 13 \
L 12 17 L 16 17 \
L 16 13 L 12 13 \
z M 7 14 L 9 14 \
L 9 16 L 7 16 L \
7 14 z M 13 14 L\
 15 14 L 15 16 L\
 13 16 L 13 14 z\
 \x22 class=\x22ColorS\
cheme-Text\x22/>\x0a  \
</g>\x0a</svg>\x0a\
\x00\x00\x06\xc8\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      .\
ColorScheme-Acce\
nt {\x0a        col\
or:#3daee9;\x0a    \
  }\x0a      </styl\
e>\x0a  </defs>\x0a  <\
g transform=\x22tra\
nslate(1,1)\x22>\x0a  \
  <path style=\x22f\
ill:currentColor\
;fill-opacity:1;\
stroke:none\x22 d=\x22\
M 4 3 L 4 9 L 4 \
10 L 4 15 L 4 16\
 L 4 17 L 3 17 L\
 3 18 L 4 18 L 4\
 19 L 5 19 L 5 1\
8 L 18.292969 18\
 L 19 18 L 19 17\
.292969 L 19 17 \
L 18.707031 17 L\
 17.958984 16.25\
1953 L 17.130859\
 15.423828 L 15.\
130859 13.423828\
 L 15.126953 13.\
427734 L 15.1210\
94 13.423828 L 1\
2.998047 15.5468\
75 L 11.703125 1\
4.251953 L 10.87\
5 13.423828 L 8.\
875 11.423828 L \
8.8730469 11.423\
828 L 7 11.42382\
8 L 6 11.423828 \
L 5 11.423828 L \
5 11 L 5 10 L 6 \
10 L 7 10 L 8.87\
30469 10 L 8.875\
 10 L 10.875 8 L\
 11.703125 7.171\
875 L 12.998047 \
5.8769531 L 15.1\
21094 8 L 15.126\
953 7.9960938 L \
15.130859 8 L 17\
.130859 6 L 17.9\
58984 5.171875 L\
 19 4.1308594 L \
18.292969 3.4238\
281 L 17.251953 \
4.4648438 L 16.4\
23828 5.2929688 \
L 15.126953 6.58\
98438 L 13 4.464\
8438 L 12.998047\
 4.4667969 L 12.\
996094 4.4648438\
 L 11.46875 5.99\
21875 L 5 5.9921\
875 L 5 5 L 5 3 \
L 4 3 z M 5 6 L \
11.460938 6 L 10\
.996094 6.464843\
8 L 10.167969 7.\
2929688 L 8.4609\
375 9 L 7 9 L 6 \
9 L 5 9 L 5 6 z \
M 5 12.423828 L \
6 12.423828 L 7 \
12.423828 L 8.46\
09375 12.423828 \
L 10.167969 14.1\
30859 L 10.99609\
4 14.958984 L 11\
.460938 15.42382\
8 L 5 15.423828 \
L 5 15 L 5 12.42\
3828 z M 15.1269\
53 14.833984 L 1\
6.423828 16.1308\
59 L 17.251953 1\
6.958984 L 17.29\
2969 17 L 5 17 L\
 5 16 L 5 15.431\
641 L 11.46875 1\
5.431641 L 12.99\
6094 16.958984 L\
 12.998047 16.95\
7031 L 13 16.958\
984 L 15.126953 \
14.833984 z \x22 cl\
ass=\x22ColorScheme\
-Text\x22/>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x02\xeb\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 id=\x22svg6\x22\
 version=\x221.1\x22 v\
iewBox=\x220 0 24 2\
4\x22 width=\x2224\x22 he\
ight=\x2224\x22>\x0a  <de\
fs id=\x22defs3051\x22\
>\x0a    <style typ\
e=\x22text/css\x22 id=\
\x22current-color-s\
cheme\x22>\x0a        \
.ColorScheme-Tex\
t {            c\
olor:#232629;   \
     }\x0a    </sty\
le>\x0a  </defs>\x0a  \
<g transform=\x22tr\
anslate(1,1)\x22>\x0a \
   <path id=\x22pat\
h347\x22 d=\x22m11 3a8\
 8 0 0 0-8 8 8 8\
 0 0 0 8 8 8 8 0\
 0 0 4.892578-1.\
693359l3.400391 \
3.40039a1 1 0 0 \
0 1.414062 0 1 1\
 0 0 0 0-1.41406\
2l-3.40039-3.400\
391a8 8 0 0 0 1.\
693359-4.892578 \
8 8 0 0 0-8-8zm0\
 1a7 7 0 0 1 7 7\
 7 7 0 0 1-7 7 7\
 7 0 0 1-7-7 7 7\
 0 0 1 7-7zm-4 3\
v8h4v-8h-4zm6 4v\
4h2v-4h-2z\x22 clas\
s=\x22ColorScheme-T\
ext\x22 fill=\x22curre\
ntColor\x22 stroke-\
linecap=\x22square\x22\
 stroke-width=\x222\
\x22 style=\x22paint-o\
rder:markers str\
oke fill\x22/>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x033\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 id=\x22svg6\x22\
 version=\x221.1\x22 v\
iewBox=\x220 0 24 2\
4\x22 width=\x2224\x22 he\
ight=\x2224\x22>\x0a  <de\
fs id=\x22defs3051\x22\
>\x0a    <style typ\
e=\x22text/css\x22 id=\
\x22current-color-s\
cheme\x22>\x0a        \
.ColorScheme-Tex\
t {            c\
olor:#232629;   \
     }\x0a    </sty\
le>\x0a  </defs>\x0a  \
<g transform=\x22tr\
anslate(1,1)\x22>\x0a \
   <path id=\x22pat\
h347\x22 d=\x22m3 3v6h\
0.2695312 1.0332\
032 4.6972656l-2\
.9394531-2.93945\
31a7 7 0 0 1 4.9\
394531-2.0605469\
 7 7 0 0 1 7 7 7\
 7 0 0 1-7 7 7 7\
 0 0 1-7-7h-1a8 \
8 0 0 0 8 8 8 8 \
0 0 0 4.892578-1\
.693359l3.400391\
 3.40039a1 1 0 0\
 0 1.414062 0 1 \
1 0 0 0 0-1.4140\
62l-3.40039-3.40\
0391a8 8 0 0 0 1\
.693359-4.892578\
 8 8 0 0 0-8-8 8\
 8 0 0 0-5.63476\
56 2.3652344l-2.\
3652344-2.365234\
4z\x22 class=\x22Color\
Scheme-Text\x22 fil\
l=\x22currentColor\x22\
 stroke-linecap=\
\x22square\x22 stroke-\
width=\x222\x22 style=\
\x22paint-order:mar\
kers stroke fill\
\x22/>\x0a  </g>\x0a</svg\
>\x0a\
\x00\x00\x01\xb0\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 version=\x22\
1.1\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24\x22 height=\x2224\x22>\
\x0a  <style type=\x22\
text/css\x22 id=\x22cu\
rrent-color-sche\
me\x22>\x0a        .Co\
lorScheme-Accent\
 {\x0a            c\
olor:#3daee9;\x0a  \
      }\x0a    </st\
yle>\x0a  <g transf\
orm=\x22translate(1\
,1)\x22>\x0a    <rect \
class=\x22ColorSche\
me-Accent\x22 x=\x223\x22\
 y=\x223\x22 width=\x2216\
\x22 height=\x2216\x22 rx\
=\x222\x22 fill=\x22curre\
ntColor\x22/>\x0a    <\
path d=\x22m10 6v2h\
2v-2zm0 4v6h2v-6\
z\x22 fill=\x22#fff\x22/>\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x01\xd9\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
        .ColorSc\
heme-NegativeTex\
t {\x0a            \
color:#da4453;\x0a \
       }\x0a       \
 </style>\x0a  </de\
fs>\x0a  <g transfo\
rm=\x22translate(1,\
1)\x22>\x0a    <path s\
tyle=\x22fill:curre\
ntColor;fill-opa\
city:1;stroke:no\
ne\x22 class=\x22Color\
Scheme-NegativeT\
ext\x22 d=\x22m3 3v4 1\
2h1 14 1v-1-12-3\
h-15-1m1 4h14v11\
h-14v-11m4 4v2h6\
v-2h-6\x22/>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x02\x80\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 1\
9 L 9 19 L 9 18 \
L 5 18 L 5 4 L 1\
3 4 L 13 8 L 17 \
8 L 17 11 L 18 1\
1 L 18 7 L 14 3 \
L 14 3 L 14 3 L \
5 3 L 4 3 z M 10\
 12 L 10 19 L 18\
 19 L 18 13 L 15\
 13 L 14 12 L 14\
 12 L 14 12 L 10\
 12 z M 13.1 14 \
L 17 14 L 17 18 \
L 11 18 L 11 15 \
L 12 15 L 13.1 1\
4 z \x22 class=\x22Col\
orScheme-Text\x22/>\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x02\xeb\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 id=\x22svg6\x22\
 version=\x221.1\x22 v\
iewBox=\x220 0 24 2\
4\x22 width=\x2224\x22 he\
ight=\x2224\x22>\x0a  <de\
fs id=\x22defs3051\x22\
>\x0a    <style typ\
e=\x22text/css\x22 id=\
\x22current-color-s\
cheme\x22>\x0a        \
.ColorScheme-Tex\
t {            c\
olor:#232629;   \
     }\x0a    </sty\
le>\x0a  </defs>\x0a  \
<g transform=\x22tr\
anslate(1,1)\x22>\x0a \
   <path id=\x22pat\
h347\x22 d=\x22m11 3a8\
 8 0 0 0-8 8 8 8\
 0 0 0 8 8 8 8 0\
 0 0 4.892578-1.\
693359l3.400391 \
3.40039a1 1 0 0 \
0 1.414062 0 1 1\
 0 0 0 0-1.41406\
2l-3.40039-3.400\
391a8 8 0 0 0 1.\
693359-4.892578 \
8 8 0 0 0-8-8zm0\
 1a7 7 0 0 1 7 7\
 7 7 0 0 1-7 7 7\
 7 0 0 1-7-7 7 7\
 0 0 1 7-7zm0 3v\
8h4v-8h-4zm-4 4v\
4h2v-4h-2z\x22 clas\
s=\x22ColorScheme-T\
ext\x22 fill=\x22curre\
ntColor\x22 stroke-\
linecap=\x22square\x22\
 stroke-width=\x222\
\x22 style=\x22paint-o\
rder:markers str\
oke fill\x22/>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x01\xcc\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22m5 3v1 1h-2\
v3h2v6h-2v3h2v2h\
1 13v-1-14-1h-14\
m1 1h2v14h-2v-14\
m3 0h9v14h-9v-14\
\x22 class=\x22ColorSc\
heme-Text\x22/>\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x03\xb9\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 11.5 3 C \
10.286139 3 9.28\
09778 3.8559279 \
9.0507812 5 L 3 \
5 L 3 6 L 9.0507\
812 6 C 9.280977\
8 7.1440721 10.2\
86139 8 11.5 8 C\
 12.713861 8 13.\
719022 7.1440721\
 13.949219 6 L 1\
9 6 L 19 5 L 13.\
949219 5 C 13.71\
9022 3.8559279 1\
2.713861 3 11.5 \
3 z M 5.5 14 C 4\
.1149999 14 3 15\
.115 3 16.5 C 3 \
17.885 4.1149999\
 19 5.5 19 C 6.7\
138604 19 7.7190\
223 18.144072 7.\
9492188 17 L 19 \
17 L 19 16 L 7.9\
492188 16 C 7.71\
90223 14.855928 \
6.7138604 14 5.5\
 14 z M 5.5 15 C\
 6.3310001 15 7 \
15.669 7 16.5 C \
7 17.331 6.33100\
01 18 5.5 18 C 4\
.6689999 18 4 17\
.331 4 16.5 C 4 \
15.669 4.6689999\
 15 5.5 15 z \x22 c\
lass=\x22ColorSchem\
e-Text\x22/>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x02\xd3\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 9\
 L 4 10 L 4 15 L\
 4 16 L 4 17 L 3\
 17 L 3 18 L 4 1\
8 L 4 19 L 5 19 \
L 5 18 L 19 18 L\
 19 17 L 16 17 L\
 16 8 L 15 8 L 1\
2 8 L 12 17 L 10\
 17 L 10 7 L 10 \
4 L 10 3 L 6 3 L\
 6 17 L 5 17 L 5\
 16 L 5 15 L 5 1\
2 L 5 11 L 5 10 \
L 5 9 L 5 6 L 5 \
5.9921875 L 5 5 \
L 5 3 L 4 3 z M \
7 4 L 9 4 L 9 17\
 L 7 17 L 7 4 z \
M 13 9 L 15 9 L \
15 17 L 13 17 L \
13 9 z \x22 class=\x22\
ColorScheme-Text\
\x22/>\x0a  </g>\x0a</svg\
>\x0a\
\x00\x00\x05\x1b\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22?>\x0a<svg xmlns\
=\x22http://www.w3.\
org/2000/svg\x22 xm\
lns:xlink=\x22http:\
//www.w3.org/199\
9/xlink\x22 xmlns:c\
c=\x22http://creati\
vecommons.org/ns\
#\x22 xmlns:dc=\x22htt\
p://purl.org/dc/\
elements/1.1/\x22 x\
mlns:rdf=\x22http:/\
/www.w3.org/1999\
/02/22-rdf-synta\
x-ns#\x22 xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22 xmlns:sodipo\
di=\x22http://sodip\
odi.sourceforge.\
net/DTD/sodipodi\
-0.dtd\x22 width=\x223\
2\x22 height=\x2232\x22>\x0a\
    <style type=\
\x22text/css\x22 id=\x22c\
urrent-color-sch\
eme\x22>\x0a      .Col\
orScheme-Text {\x0a\
        color:#3\
1363b;\x0a      }\x0a \
     .ColorSchem\
e-Background {\x0a \
       color:#ef\
f0f1;\x0a      }\x0a  \
    .ColorScheme\
-Accent {\x0a      \
  color:#3daee9;\
\x0a      }\x0a      .\
ColorScheme-Butt\
onText {\x0a       \
 color:#31363b;\x0a\
      }\x0a      .C\
olorScheme-Negat\
iveText {\x0a      \
  color:#da4453;\
\x0a      }\x0a  </sty\
le>\x0a    <g trans\
form=\x22translate(\
27,27) translate\
(-22,-22)\x22 id=\x22d\
ocument-open-rec\
ent\x22>\x0a    <path \
id=\x22path14\x22 d=\x22m\
 0,-3 0,28 10,0 \
0,-1 -9,0 0,-26 \
20,0 0,15 1,0 0,\
-16 -22,0 z m 16\
,16 a 6,6 0 0 0 \
-6,6 6,6 0 0 0 6\
,6 6,6 0 0 0 6,-\
6 6,6 0 0 0 -6,-\
6 z m 0,1 a 5,5 \
0 0 1 5,5 5,5 0 \
0 1 -5,5 5,5 0 0\
 1 -5,-5 5,5 0 0\
 1 5,-5 z m -1,1\
 0,5 1,0 3,0 0,-\
1 -3,0 0,-4 -1,0\
 z\x22 style=\x22opaci\
ty:1;fill:curren\
tColor\x22 class=\x22C\
olorScheme-Text\x22\
/>\x0a    <rect id=\
\x22rect23\x22 width=\x22\
32\x22 height=\x2232\x22 \
x=\x22-5\x22 y=\x22-5\x22 st\
yle=\x22opacity:1;f\
ill:none\x22/>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x0a(\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0a<svg width=\x2232\x22\
 version=\x221.1\x22 x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22 height=\x2232\x22 xm\
lns:xlink=\x22http:\
//www.w3.org/199\
9/xlink\x22 xmlns:i\
nkscape=\x22http://\
www.inkscape.org\
/namespaces/inks\
cape\x22>\x0a <defs id\
=\x22defs5455\x22>\x0a  <\
linearGradient i\
nkscape:collect=\
\x22always\x22 id=\x22lin\
earGradient4143\x22\
>\x0a   <stop style\
=\x22stop-color:#19\
7cf1\x22 id=\x22stop41\
45\x22/>\x0a   <stop o\
ffset=\x221\x22 style=\
\x22stop-color:#20b\
cfa\x22 id=\x22stop414\
7\x22/>\x0a  </linearG\
radient>\x0a  <line\
arGradient inksc\
ape:collect=\x22alw\
ays\x22 xlink:href=\
\x22#linearGradient\
4143\x22 id=\x22linear\
Gradient4149\x22 y1\
=\x22545.79797\x22 y2=\
\x22517.79797\x22 x2=\x22\
0\x22 gradientUnits\
=\x22userSpaceOnUse\
\x22 gradientTransf\
orm=\x22matrix(0.92\
857108 0 0 0.928\
57057 28.612354 \
37.986142)\x22/>\x0a  \
<linearGradient \
inkscape:collect\
=\x22always\x22 id=\x22li\
nearGradient4290\
\x22>\x0a   <stop styl\
e=\x22stop-color:#7\
cbaf8\x22 id=\x22stop4\
292\x22/>\x0a   <stop \
offset=\x221\x22 style\
=\x22stop-color:#f4\
fcff\x22 id=\x22stop42\
94\x22/>\x0a  </linear\
Gradient>\x0a  <lin\
earGradient inks\
cape:collect=\x22al\
ways\x22 xlink:href\
=\x22#linearGradien\
t4290\x22 id=\x22linea\
rGradient4144\x22 y\
1=\x2229.999973\x22 y2\
=\x222\x22 x2=\x220\x22 grad\
ientUnits=\x22userS\
paceOnUse\x22/>\x0a  <\
linearGradient i\
nkscape:collect=\
\x22always\x22 id=\x22lin\
earGradient4227\x22\
>\x0a   <stop style\
=\x22stop-color:#29\
2c2f\x22 id=\x22stop42\
29\x22/>\x0a   <stop o\
ffset=\x221\x22 style=\
\x22stop-opacity:0\x22\
 id=\x22stop4231\x22/>\
\x0a  </linearGradi\
ent>\x0a  <linearGr\
adient inkscape:\
collect=\x22always\x22\
 xlink:href=\x22#li\
nearGradient4227\
\x22 id=\x22linearGrad\
ient4191\x22 y1=\x229\x22\
 x1=\x229.00001\x22 y2\
=\x2223\x22 x2=\x2223.000\
04\x22 gradientUnit\
s=\x22userSpaceOnUs\
e\x22/>\x0a </defs>\x0a <\
metadata id=\x22met\
adata5458\x22/>\x0a <g\
 inkscape:label=\
\x22Capa 1\x22 inkscap\
e:groupmode=\x22lay\
er\x22 id=\x22layer1\x22 \
transform=\x22matri\
x(1 0 0 1 -384.5\
7143 -515.798)\x22>\
\x0a  <rect width=\x22\
26\x22 x=\x22387.57144\
\x22 y=\x22518.79797\x22 \
rx=\x2212.999993\x22 h\
eight=\x2226\x22 style\
=\x22fill:url(#line\
arGradient4149)\x22\
 id=\x22rect4130\x22/>\
\x0a  <path style=\x22\
fill:url(#linear\
Gradient4191);op\
acity:0.2;fill-r\
ule:evenodd\x22 id=\
\x22path4184\x22 d=\x22M \
17 9 L 15 11 L 1\
7 13 L 15 23 L 2\
3 31 L 26 31 L 2\
9 31 L 31 31 L 3\
1 27 L 31 23 L 1\
7 9 z \x22 transfor\
m=\x22matrix(1 0 0 \
1 384.57143 515.\
798)\x22/>\x0a  <path \
inkscape:connect\
or-curvature=\x220\x22\
 style=\x22fill:url\
(#linearGradient\
4144)\x22 id=\x22rect4\
133\x22 d=\x22M 16,2 C\
 8.4128491,2 2.2\
891329,7.9794391\
 2.0253906,15.5 \
2.0195214,15.667\
36 2,15.831158 2\
,16 c 0,7.756003\
 6.2439968,14 14\
,14 7.756003,0 1\
4,-6.243997 14,-\
14 0,-0.168842 -\
0.01952,-0.33264\
 -0.02539,-0.5 C\
 29.710867,7.979\
4391 23.587151,2\
 16,2 Z m 0,1 C \
23.201993,3 29,8\
.7980074 29,16 2\
9,23.201993 23.2\
01993,29 16,29 8\
.7980074,29 3,23\
.201993 3,16 3,8\
.7980074 8.79800\
74,3 16,3 Z m -1\
,6 0,2 2,0 0,-2 \
z m 0,4 0,10 2,0\
 0,-10 z\x22 transf\
orm=\x22matrix(1 0 \
0 1 384.57143 51\
5.798)\x22/>\x0a </g>\x0a\
</svg>\x0a\
\x00\x00\x03\x07\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs\x0a     id=\x22def\
s3051\x22>\x0a    <sty\
le\x0a       type=\x22\
text/css\x22\x0a      \
 id=\x22current-col\
or-scheme\x22>\x0a    \
  .ColorScheme-T\
ext {\x0a        co\
lor:#232629;\x0a   \
   }\x0a      </sty\
le>\x0a  </defs>\x0a  \
<path\x0a     style\
=\x22fill:currentCo\
lor;fill-opacity\
:1;stroke:none\x22 \
\x0a     d=\x22M 4 4 L\
 4 28 L 28 28 L \
28 4 L 4 4 z M 5\
 9 L 27 9 L 27 2\
7 L 5 27 L 5 9 z\
 M 8 11 L 8 17 L\
 15 17 L 15 11 L\
 8 11 z M 17 11 \
L 17 17 L 24 17 \
L 24 11 L 17 11 \
z M 9 12 L 14 12\
 L 14 16 L 9 16 \
L 9 12 z M 18 12\
 L 23 12 L 23 16\
 L 18 16 L 18 12\
 z M 8 19 L 8 25\
 L 15 25 L 15 19\
 L 8 19 z M 17 1\
9 L 17 25 L 24 2\
5 L 24 19 L 17 1\
9 z M 9 20 L 14 \
20 L 14 24 L 9 2\
4 L 9 20 z M 18 \
20 L 23 20 L 23 \
24 L 18 24 L 18 \
20 z \x22\x0a     id=\x22\
path45\x22 \x0a     cl\
ass=\x22ColorScheme\
-Text\x22\x0a     />\x0a<\
/svg>\x0a\
\x00\x00\x02\xe2\
<\
svg id=\x22svg6\x22 ve\
rsion=\x221.1\x22 view\
Box=\x220 0 32 32\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a    <defs id\
=\x22defs3051\x22>\x0a   \
 <style type=\x22te\
xt/css\x22 id=\x22curr\
ent-color-scheme\
\x22>\x0a        .Colo\
rScheme-Text {  \
          color:\
#232629;        \
}\x0a    </style>\x0a \
   </defs>\x0a    <\
path id=\x22path142\
32\x22 d=\x22m16 4a12 \
12 0 0 0-12 12 1\
2 12 0 0 0 12 12\
 12 12 0 0 0 7.3\
37891-2.541016l4\
.101562 4.101563\
a1.5 1.5 0 0 0 2\
.121094 0 1.5 1.\
5 0 0 0 0-2.1210\
94l-4.101563-4.1\
01562a12 12 0 0 \
0 2.541016-7.337\
891 12 12 0 0 0-\
12-12zm0 2a10 10\
 0 0 1 10 10 10 \
10 0 0 1-10 10 1\
0 10 0 0 1-10-10\
 10 10 0 0 1 10-\
10zm-6 4v12h6v-1\
2h-6zm9 6v6h3v-6\
h-3z\x22 class=\x22Col\
orScheme-Text\x22 f\
ill=\x22currentColo\
r\x22 stroke-lineca\
p=\x22round\x22 style=\
\x22-inkscape-strok\
e:none;paint-ord\
er:markers strok\
e fill\x22/>\x0a</svg>\
\x0a\
\x00\x00\x03\x00\
<\
svg id=\x22svg6\x22 ve\
rsion=\x221.1\x22 view\
Box=\x220 0 32 32\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a    <defs id\
=\x22defs3051\x22>\x0a   \
 <style type=\x22te\
xt/css\x22 id=\x22curr\
ent-color-scheme\
\x22>\x0a        .Colo\
rScheme-Text {  \
          color:\
#232629;        \
}\x0a    </style>\x0a \
   </defs>\x0a    <\
path id=\x22path299\
\x22 d=\x22m4 4v9h0.40\
42969 2.0644531 \
6.53125l-4.06445\
31-4.0644531a10 \
10 0 0 1 7.06445\
31-2.9355469 10 \
10 0 0 1 10 10 1\
0 10 0 0 1-10 10\
 10 10 0 0 1-10-\
10h-2a12 12 0 0 \
0 12 12 12 12 0 \
0 0 7.337891-2.5\
41016l4.101562 4\
.101563a1.5 1.5 \
0 0 0 2.121094 0\
 1.5 1.5 0 0 0 0\
-2.121094l-4.101\
563-4.101562a12 \
12 0 0 0 2.54101\
6-7.337891 12 12\
 0 0 0-12-12 12 \
12 0 0 0-8.45312\
5 3.546875l-3.54\
6875-3.546875z\x22 \
class=\x22ColorSche\
me-Text\x22 fill=\x22c\
urrentColor\x22 str\
oke-width=\x222\x22 st\
yle=\x22paint-order\
:markers stroke \
fill\x22/>\x0a</svg>\x0a\
\x00\x00\x01\xa5\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22><defs\
 id=\x22defs3051\x22>\x0a\
        <style t\
ype=\x22text/css\x22 i\
d=\x22current-color\
-scheme\x22>\x0a      \
      .ColorSche\
me-NegativeText \
{\x0a              \
  color:#da4453;\
\x0a            }\x0a \
       </style>\x0a\
    </defs>\x0a    \
<g style=\x22fill:c\
urrentColor;fill\
-opacity:1;strok\
e:none\x22 class=\x22C\
olorScheme-Negat\
iveText\x22><path d\
=\x22M4 4v24h24V4zm\
1 6h22v17H5z\x22/><\
path d=\x22M12 17h8\
v3h-8z\x22/></g></s\
vg>\x0a\
\x00\x00\x02\xc1\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 6 4 L 6 28 L 1\
3 28 L 13 27 L 7\
 27 L 7 5 L 18 5\
 L 18 12 L 25 12\
 L 25 16 L 26 16\
 L 26 11 L 19 4 \
L 18 4 L 6 4 z M\
 14 16 L 14 17 L\
 14 20 L 14 21 L\
 14 27 L 14 28 L\
 26 28 L 26 27 L\
 26 20 L 26 19 L\
 26 18 L 21 18 L\
 19 16 L 19 16 L\
 19 16 L 15 16 L\
 14 16 z M 15 17\
 L 18.6 17 L 19.\
6 18 L 19 18 L 1\
9 18 L 19 18 L 1\
7 20 L 15 20 L 1\
5 17 z M 15 21 L\
 25 21 L 25 27 L\
 15 27 L 15 21 z\
 \x22\x0a     class=\x22C\
olorScheme-Text\x22\
\x0a     />\x0a</svg>\x0a\
\
\x00\x00\x02\xe2\
<\
svg id=\x22svg6\x22 ve\
rsion=\x221.1\x22 view\
Box=\x220 0 32 32\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a    <defs id\
=\x22defs3051\x22>\x0a   \
 <style type=\x22te\
xt/css\x22 id=\x22curr\
ent-color-scheme\
\x22>\x0a        .Colo\
rScheme-Text {  \
          color:\
#232629;        \
}\x0a    </style>\x0a \
   </defs>\x0a    <\
path id=\x22path142\
32\x22 d=\x22m16 4a12 \
12 0 0 0-12 12 1\
2 12 0 0 0 12 12\
 12 12 0 0 0 7.3\
37891-2.541016l4\
.101562 4.101563\
a1.5 1.5 0 0 0 2\
.121094 0 1.5 1.\
5 0 0 0 0-2.1210\
94l-4.101563-4.1\
01562a12 12 0 0 \
0 2.541016-7.337\
891 12 12 0 0 0-\
12-12zm0 2a10 10\
 0 0 1 10 10 10 \
10 0 0 1-10 10 1\
0 10 0 0 1-10-10\
 10 10 0 0 1 10-\
10zm0 4v12h6v-12\
h-6zm-6 6v6h3v-6\
h-3z\x22 class=\x22Col\
orScheme-Text\x22 f\
ill=\x22currentColo\
r\x22 stroke-lineca\
p=\x22round\x22 style=\
\x22-inkscape-strok\
e:none;paint-ord\
er:markers strok\
e fill\x22/>\x0a</svg>\
\x0a\
\x00\x00\x02\xd5\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      .ColorSc\
heme-Accent {\x0a  \
      color:#3da\
ee9;\x0a      }\x0a   \
   </style>\x0a  </\
defs>\x0a <path \x0a  \
   style=\x22fill:c\
urrentColor;fill\
-opacity:1;strok\
e:none\x22 \x0a     d=\
\x22M18.5 6A3.5 3.5\
 0 0 0 15.04102 \
9H4V10H15.04A3.5\
 3.5 0 0 0 18.5 \
13 3.5 3.5 0 0 0\
 21.958984 10H28\
V9H21.961A3.5 3.\
5 0 0 0 18.5 6M7\
.5 19A3.5 3.5 0 \
0 0 4 22.5 3.5 3\
.5 0 0 0 7.5 26 \
3.5 3.5 0 0 0 10\
.960938 23H28V22\
H10.959A3.5 3.5 \
0 0 0 7.5 19m0 1\
A2.5 2.5 0 0 1 1\
0 22.5 2.5 2.5 0\
 0 1 7.5 25 2.5 \
2.5 0 0 1 5 22.5\
 2.5 2.5 0 0 1 7\
.5 20\x22\x0a     clas\
s=\x22ColorScheme-T\
ext\x22\x0a     />\x0a</s\
vg>\x0a\
\x00\x00\x02}\
<\
svg version=\x221.1\
\x22 viewBox=\x220 0 1\
6 16\x22 xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22>\x0a    <d\
efs>\x0a        <st\
yle type=\x22text/c\
ss\x22 id=\x22current-\
color-scheme\x22>\x0a \
           .Colo\
rScheme-Text {\x0a \
               c\
olor:#232629;\x0a  \
          }\x0a    \
    </style>\x0a   \
 </defs>\x0a    <pa\
th style=\x22fill:c\
urrentColor;fill\
-opacity:1;strok\
e:none\x22\x0a        \
  d=\x22m9.0000002 \
9v3h1.9999998v-1\
h-1v-2zm0.999999\
8-1c-1.6619998 0\
-2.9999998 1.338\
-2.9999998 3s1.3\
38 3 2.9999998 3\
c1.662 0 3-1.338\
 3-3s-1.338-3-3-\
3zm0 1a2 2 0 0 1\
 2 2 2 2 0 0 1-2\
 2 2 2 0 0 1-1.9\
999998-2 2 2 0 0\
 1 1.9999998-2zm\
-7-7v12h4v-1h-3v\
-10h5v3h3v2h1v-3\
l-3-3h-1z\x22\x0a     \
     class=\x22Colo\
rScheme-Text\x22\x0a  \
  />\x0a</svg>\x0a\
\x00\x00\x01\xef\
<\
svg viewBox=\x220 0\
 16 16\x22 xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22>\x0a    \
<style type=\x22tex\
t/css\x22 id=\x22curre\
nt-color-scheme\x22\
>\x0a        .Color\
Scheme-Text {\x0a  \
          color:\
#232629;\x0a       \
 }\x0a    </style>\x0a\
    <g class=\x22Co\
lorScheme-Text\x22 \
fill=\x22currentCol\
or\x22 fill-rule=\x22e\
venodd\x22>\x0a       \
 <path d=\x22m8 2a6\
 6 0 0 0 -6 6 6 \
6 0 0 0 6 6 6 6 \
0 0 0 6-6 6 6 0 \
0 0 -6-6zm0 1a5 \
5 0 0 1 5 5 5 5 \
0 0 1 -5 5 5 5 0\
 0 1 -5-5 5 5 0 \
0 1 5-5z\x22/>\x0a    \
    <path d=\x22m7 \
4h2v2h-2z\x22/>\x0a   \
     <path d=\x22m7\
 7h2v5h-2z\x22/>\x0a  \
  </g>\x0a</svg>\x0a\
\x00\x00\x02\xfc\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a    <\
path\x0a       styl\
e=\x22fill:currentC\
olor;fill-opacit\
y:1;stroke:none\x22\
 \x0a       d=\x22M 2 \
2 L 2 14 L 14 14\
 L 14 2 L 2 2 z \
M 3 3 L 7 3 L 7 \
7 L 3 7 L 3 3 z \
M 8 3 L 13 3 L 1\
3 7 L 8 7 L 8 3 \
z M 5.0390625 4 \
A 1 1 0 0 0 4.31\
05469 4.2753906 \
A 1 1 0 0 0 4.12\
5 5.484375 A 1 1\
 0 0 0 5.25 5.96\
875 A 1 1 0 0 0 \
6 5 L 5 5 L 5.52\
92969 4.1523438 \
A 1 1 0 0 0 5.03\
90625 4 z M 3 8 \
L 7 8 L 7 13 L 3\
 13 L 3 8 z M 8 \
8 L 13 8 L 13 13\
 L 8 13 L 8 8 z \
M 11 9 L 11 12 L\
 12 12 L 12 9 L \
11 9 z M 9 11 L \
9 12 L 10 12 L 1\
0 11 L 9 11 z \x22\x0a\
        class=\x22C\
olorScheme-Text\x22\
 />\x0a</svg>\x0a\
\x00\x00\x02d\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22M 2 2 L 2 5 L \
2 14 L 3 14 L 14\
 14 L 14 13 L 14\
 2 L 3 2 L 2 2 z\
 M 3 5 L 13 5 L \
13 13 L 3 13 L 3\
 5 z M 4 6 L 4 8\
 L 6 8 L 6 6 L 4\
 6 z M 7 6 L 7 8\
 L 9 8 L 9 6 L 7\
 6 z M 10 6 L 10\
 8 L 12 8 L 12 6\
 L 10 6 z M 4 10\
 L 4 12 L 6 12 L\
 6 10 L 4 10 z M\
 7 10 L 7 12 L 9\
 12 L 9 10 L 7 1\
0 z \x22\x0a     class\
=\x22ColorScheme-Te\
xt\x22\x0a     />\x0a</sv\
g>\x0a\
\x00\x00\x04G\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a    style=\x22fi\
ll:currentColor;\
fill-opacity:1;s\
troke:none\x22 \x0a   \
 d=\x22M 2 2 L 2 3 \
L 2 4 L 2 8 L 2 \
9 L 2 10.626953 \
L 2 11.626953 L \
2 13 L 2 14 L 14\
 14 L 14 13.0019\
53 L 14 13 L 14 \
11.867188 L 13.9\
58984 11.828125 \
L 11.130859 9 L \
11.126953 9.0039\
062 L 11.121094 \
9 L 8.9980469 11\
.123047 L 5.875 \
8 L 4.4609375 8 \
L 3 8 L 3 4 L 3 \
3 L 3 2 L 2 2 z \
M 9 2 L 4.998046\
9 6.0019531 L 3.\
0019531 6.001953\
1 L 3.0019531 7.\
0019531 L 5.4121\
094 7.0019531 L \
9.0019531 3.4121\
094 L 11.125 5.5\
351562 L 11.1308\
59 5.53125 L 11.\
134766 5.5351562\
 L 13.962891 2.7\
070312 C 13.9658\
57 2.7120315 13.\
255859 2 13.2558\
59 2 L 11.130859\
 4.125 L 9.00390\
62 2 L 9.0019531\
 2.0019531 L 9 2\
 z M 3 9 L 5.460\
9375 9 L 8.99609\
38 12.535156 L 8\
.9980469 12.5332\
03 L 9 12.535156\
 L 11.126953 10.\
410156 L 13.2519\
53 12.535156 L 1\
3.734375 13 L 3 \
13 L 3 11.626953\
 L 3 10.626953 L\
 3 9 z \x22\x0a    cla\
ss=\x22ColorScheme-\
Text\x22\x0a    />  \x0a<\
/svg>\x0a\
\x00\x00\x02\xb3\
<\
svg id=\x22svg859\x22 \
version=\x221.1\x22 vi\
ewBox=\x220 0 16 16\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22>\x0a    <defs \
id=\x22defs3051\x22>\x0a \
   <style type=\x22\
text/css\x22 id=\x22cu\
rrent-color-sche\
me\x22>\x0a        .Co\
lorScheme-Text {\
            colo\
r:#232629;      \
  }\x0a    </style>\
\x0a    </defs>\x0a   \
 <g id=\x22layer1\x22>\
\x0a        <path i\
d=\x22path289\x22 d=\x22m\
8 2a6 6 0 0 0-6 \
6 6 6 0 0 0 6 6 \
6 6 0 0 0 3.6679\
69-1.269531l2.04\
8828 2.048828a0.\
75 0.75 0 0 0 1.\
0625 0 0.75 0.75\
 0 0 0 0-1.0625l\
-2.048828-2.0488\
28a6 6 0 0 0 1.2\
69531-3.667969 6\
 6 0 0 0-6-6zm0 \
1a5 5 0 0 1 5 5 \
5 5 0 0 1-5 5 5 \
5 0 0 1-5-5 5 5 \
0 0 1 5-5zm-3 2v\
6h3v-6h-3zm4 3v3\
h2v-3h-2z\x22 class\
=\x22ColorScheme-Te\
xt\x22 fill=\x22curren\
tColor\x22 style=\x22p\
aint-order:marke\
rs stroke fill\x22/\
>\x0a    </g>\x0a</svg\
>\x0a\
\x00\x00\x02\xe4\
<\
svg id=\x22svg859\x22 \
version=\x221.1\x22 vi\
ewBox=\x220 0 16 16\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22>\x0a        <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a       \
 .ColorScheme-Te\
xt {            \
color:#232629;  \
      }\x0a    </st\
yle>\x0a    </defs>\
\x0a    <g id=\x22laye\
r1\x22>\x0a        <pa\
th id=\x22path289\x22 \
d=\x22m2 2v4h4l-1.5\
195312-1.5195312\
a5 5 0 0 1 3.519\
5312-1.4804688 5\
 5 0 0 1 5 5 5 5\
 0 0 1-5 5 5 5 0\
 0 1-5-5h-1a6 6 \
0 0 0 6 6 6 6 0 \
0 0 3.667969-1.2\
69531l2.048828 2\
.048828a0.75 0.7\
5 0 0 0 1.0625 0\
 0.75 0.75 0 0 0\
 0-1.0625l-2.048\
828-2.048828a6 6\
 0 0 0 1.269531-\
3.667969 6 6 0 0\
 0-6-6 6 6 0 0 0\
-4.2304688 1.769\
5312l-1.7695312-\
1.7695312z\x22 clas\
s=\x22ColorScheme-T\
ext\x22 fill=\x22curre\
ntColor\x22 style=\x22\
paint-order:mark\
ers stroke fill\x22\
/>\x0a    </g>\x0a</sv\
g>\x0a\
\x00\x00\x01r\
<\
svg version=\x221.1\
\x22 viewBox=\x220 0 1\
6 16\x22 xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
        .ColorSc\
heme-Accent {\x0a  \
          color:\
#3daee9;\x0a       \
 }\x0a    </style>\x0a\
    <rect class=\
\x22ColorScheme-Acc\
ent\x22 x=\x222\x22 y=\x222\x22\
 width=\x2212\x22 heig\
ht=\x2212\x22 rx=\x222\x22 f\
ill=\x22currentColo\
r\x22/>\x0a    <path d\
=\x22m7 4v2h2v-2zm0\
 3v5h2v-5z\x22 fill\
=\x22#fff\x22/>\x0a</svg>\
\x0a\
\x00\x00\x01\xc9\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      .ColorSc\
heme-NegativeTex\
t {\x0a        colo\
r:#da4453;\x0a     \
 }\x0a      </style\
>\x0a  </defs>\x0a  <p\
ath\x0a     style=\x22\
fill:currentColo\
r;fill-opacity:1\
;stroke:none\x22 \x0a \
    class=\x22Color\
Scheme-NegativeT\
ext\x22\x0a     d=\x22m2 \
2v12h12v-12zm1 3\
h10v8h-10zm3 3v2\
h4v-2z\x22\x0a      />\
\x0a</svg>\x0a\
\x00\x00\x02\x0e\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a     style=\x22f\
ill:currentColor\
;fill-opacity:1;\
stroke:none\x22 \x0a  \
   d=\x22M 3 2 L 3 \
14 L 6 14 L 6 13\
 L 4 13 L 4 3 L \
9 3 L 9 6 L 12 6\
 L 12 8 L 13 8 L\
 13 5 L 10 2 L 9\
 2 L 3 2 z M 7 8\
 L 7 14 L 13 14 \
L 13 9 L 11 9 L \
10 8 L 7 8 z M 8\
 10 L 12 10 L 12\
 13 L 8 13 L 8 1\
0 z \x22\x0a     class\
=\x22ColorScheme-Te\
xt\x22/>\x0a</svg>\x0a\
\x00\x00\x02\xb3\
<\
svg id=\x22svg859\x22 \
version=\x221.1\x22 vi\
ewBox=\x220 0 16 16\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22>\x0a    <defs \
id=\x22defs3051\x22>\x0a \
   <style type=\x22\
text/css\x22 id=\x22cu\
rrent-color-sche\
me\x22>\x0a        .Co\
lorScheme-Text {\
            colo\
r:#232629;      \
  }\x0a    </style>\
\x0a    </defs>\x0a   \
 <g id=\x22layer1\x22>\
\x0a        <path i\
d=\x22path289\x22 d=\x22m\
8 2a6 6 0 0 0-6 \
6 6 6 0 0 0 6 6 \
6 6 0 0 0 3.6679\
69-1.269531l2.04\
8828 2.048828a0.\
75 0.75 0 0 0 1.\
0625 0 0.75 0.75\
 0 0 0 0-1.0625l\
-2.048828-2.0488\
28a6 6 0 0 0 1.2\
69531-3.667969 6\
 6 0 0 0-6-6zm0 \
1a5 5 0 0 1 5 5 \
5 5 0 0 1-5 5 5 \
5 0 0 1-5-5 5 5 \
0 0 1 5-5zm0 2v6\
h3v-6h-3zm-3 3v3\
h2v-3h-2z\x22 class\
=\x22ColorScheme-Te\
xt\x22 fill=\x22curren\
tColor\x22 style=\x22p\
aint-order:marke\
rs stroke fill\x22/\
>\x0a    </g>\x0a</svg\
>\x0a\
\x00\x00\x02\x0e\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22M 3 2 L 3 3 L \
3 4 L 2 4 L 2 6 \
L 3 6 L 3 10 L 2\
 10 L 2 12 L 3 1\
2 L 3 13.5 L 3 1\
4 L 14 14 L 14 1\
3 L 14 3 L 14 2 \
L 3 2 z M 4 3 L \
5 3 L 5 13 L 4 1\
3 L 4 3 z M 6 3 \
L 13 3 L 13 13 L\
 6 13 L 6 3 z \x22\x0a\
     class=\x22Colo\
rScheme-Text\x22\x0a  \
   />\x0a</svg>\x0a\
\x00\x00\x03\xdd\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22M 10 2.5 C 9.0\
680195 2.5 8.284\
4627 3.1373007 8\
.0625 4 L 2 4 L \
2 5 L 8.0625 5 C\
 8.2844627 5.862\
6993 9.0680195 6\
.5 10 6.5 C 10.9\
31981 6.5 11.715\
537 5.8626993 11\
.9375 5 L 14 5 L\
 14 4 L 11.9375 \
4 C 11.715537 3.\
1373007 10.93198\
1 2.5 10 2.5 z M\
 5 9.5 C 4.06801\
91 9.5 3.2844626\
 10.137301 3.062\
5 11 L 2 11 L 2 \
12 L 3.0625 12 C\
 3.2844626 12.86\
2699 4.0680191 1\
3.5 5 13.5 C 5.9\
319809 13.5 6.71\
55374 12.862699 \
6.9375 12 L 7 12\
 L 9 12 L 14 12 \
L 14 11 L 9 11 L\
 7 11 L 6.9375 1\
1 C 6.7155374 10\
.137301 5.931980\
9 9.5 5 9.5 z M \
5 10.5 C 5.55228\
 10.5 6 10.94772\
 6 11.5 C 6 12.0\
5228 5.55228 12.\
5 5 12.5 C 4.447\
72 12.5 4 12.052\
28 4 11.5 C 4 10\
.94772 4.44772 1\
0.5 5 10.5 z \x22\x0a \
    class=\x22Color\
Scheme-Text\x22\x0a   \
  />\x0a</svg>\x0a\
\x00\x00\x02\x01\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a     style=\x22f\
ill:currentColor\
;fill-opacity:1;\
stroke:none\x22 \x0a  \
   d=\x22M 2 2 L 2 \
14 L 14 14 L 14 \
13 L 13 13 L 13 \
8 L 9 8 L 9 13 L\
 8 13 L 8 2 L 4 \
2 L 4 13 L 3 13 \
L 3 2 L 2 2 z M \
5 3 L 7 3 L 7 13\
 L 5 13 L 5 3 z \
M 10 9 L 12 9 L \
12 13 L 10 13 L \
10 9 z \x22\x0a     cl\
ass=\x22ColorScheme\
-Text\x22/>\x0a</svg>\x0a\
\
"

qt_resource_name = b"\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x04\
\x00\x06\xad\xc4\
\x00d\
\x00g\x00e\x00t\
\x00\x07\
\x06\x9bfR\
\x003\
\x002\x00x\x003\x002\x00@\x002\
\x00\x05\
\x004\xdbF\
\x001\
\x006\x00x\x001\x006\
\x00\x05\
\x005\xbbT\
\x002\
\x004\x00x\x002\x004\
\x00\x07\
\x04\xdbJR\
\x001\
\x006\x00x\x001\x006\x00@\x002\
\x00\x05\
\x006\x9bb\
\x003\
\x002\x00x\x003\x002\
\x00\x07\
\x05\x9bVR\
\x002\
\x002\x00x\x002\x002\x00@\x002\
\x00\x0b\
\x0b\xba\x81\xb5\
\x00i\
\x00n\x00d\x00e\x00x\x00.\x00t\x00h\x00e\x00m\x00e\
\x00\x07\
\x05\xbbXR\
\x002\
\x004\x00x\x002\x004\x00@\x002\
\x00\x05\
\x005\x9bR\
\x002\
\x002\x00x\x002\x002\
\x00\x18\
\x00\x8c5\xa7\
\x00d\
\x00o\x00c\x00u\x00m\x00e\x00n\x00t\x00-\x00o\x00p\x00e\x00n\x00-\x00r\x00e\x00c\
\x00e\x00n\x00t\x00.\x00s\x00v\x00g\
\x00\x0e\
\x0e\xa1.G\
\x00h\
\x00e\x00l\x00p\x00-\x00a\x00b\x00o\x00u\x00t\x00.\x00s\x00v\x00g\
\x00\x11\
\x05\xc9q\xc7\
\x00o\
\x00f\x00f\x00i\x00c\x00e\x00-\x00r\x00e\x00p\x00o\x00r\x00t\x00.\x00s\x00v\x00g\
\
\x00\x0e\
\x09W8\xc7\
\x00v\
\x00i\x00e\x00w\x00-\x00g\x00r\x00o\x00u\x00p\x00.\x00s\x00v\x00g\
\x00\x15\
\x02\xb4\x12\x87\
\x00o\
\x00f\x00f\x00i\x00c\x00e\x00-\x00c\x00h\x00a\x00r\x00t\x00-\x00l\x00i\x00n\x00e\
\x00.\x00s\x00v\x00g\
\x00\x0f\
\x0e\x02\xf6'\
\x00z\
\x00o\x00o\x00m\x00-\x002\x00-\x00t\x00o\x00-\x001\x00.\x00s\x00v\x00g\
\x00\x11\
\x0e\xab>\xc7\
\x00z\
\x00o\x00o\x00m\x00-\x00o\x00r\x00i\x00g\x00i\x00n\x00a\x00l\x00.\x00s\x00v\x00g\
\
\x00\x16\
\x0b\xee\xa6\xa7\
\x00d\
\x00i\x00a\x00l\x00o\x00g\x00-\x00i\x00n\x00f\x00o\x00r\x00m\x00a\x00t\x00i\x00o\
\x00n\x00.\x00s\x00v\x00g\
\x00\x14\
\x07@\xafG\
\x00a\
\x00p\x00p\x00l\x00i\x00c\x00a\x00t\x00i\x00o\x00n\x00-\x00e\x00x\x00i\x00t\x00.\
\x00s\x00v\x00g\
\x00\x11\
\x01\xa6\xc9\x07\
\x00d\
\x00o\x00c\x00u\x00m\x00e\x00n\x00t\x00-\x00o\x00p\x00e\x00n\x00.\x00s\x00v\x00g\
\
\x00\x0f\
\x0e\x07\xd6'\
\x00z\
\x00o\x00o\x00m\x00-\x001\x00-\x00t\x00o\x00-\x002\x00.\x00s\x00v\x00g\
\x00\x11\
\x0b\x87`\x87\
\x00d\
\x00o\x00c\x00u\x00m\x00e\x00n\x00t\x00a\x00t\x00i\x00o\x00n\x00.\x00s\x00v\x00g\
\
\x00\x16\
\x0cb\xb8G\
\x00s\
\x00e\x00t\x00t\x00i\x00n\x00g\x00s\x00-\x00c\x00o\x00n\x00f\x00i\x00g\x00u\x00r\
\x00e\x00.\x00s\x00v\x00g\
\x00\x14\
\x08j\x1e\xa7\
\x00o\
\x00f\x00f\x00i\x00c\x00e\x00-\x00c\x00h\x00a\x00r\x00t\x00-\x00b\x00a\x00r\x00.\
\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00\x09\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x002\x00\x02\x00\x00\x00\x0e\x00\x00\x00d\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\xba\x00\x02\x00\x00\x00\x0e\x00\x00\x00V\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00B\x00\x02\x00\x00\x00\x0e\x00\x00\x00H\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00f\x00\x02\x00\x00\x00\x09\x00\x00\x00?\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00R\x00\x02\x00\x00\x00\x0e\x00\x00\x001\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00v\x00\x02\x00\x00\x00\x0e\x00\x00\x00#\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\xa6\x00\x02\x00\x00\x00\x0e\x00\x00\x00\x15\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x1e\x00\x02\x00\x00\x00\x09\x00\x00\x00\x0c\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x8a\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x97\xe3\xa1\x17U\
\x00\x00\x00\xca\x00\x00\x00\x00\x00\x01\x00\x00Sx\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02H\x00\x00\x00\x00\x00\x01\x00\x00ma\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\x1a\x00\x00\x00\x00\x00\x01\x00\x00k\xb8\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01J\x00\x00\x00\x00\x00\x01\x00\x00b\xc3\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\xbc\x00\x00\x00\x00\x00\x01\x00\x00s\x0c\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x9c\x00\x00\x00\x00\x00\x01\x00\x00e\xce\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02p\x00\x00\x00\x00\x00\x01\x00\x00p&\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x00\x00\x00\x00\x00\x00\x01\x00\x00X\x97\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\xc0\x00\x00\x00\x00\x00\x01\x00\x00h\xb4\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x00\xca\x00\x00\x00\x00\x00\x01\x00\x00)=\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02H\x00\x00\x00\x00\x00\x01\x00\x00E\xa1\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01l\x00\x00\x00\x00\x00\x01\x00\x005\x1e\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x22\x00\x00\x00\x00\x00\x01\x00\x00.\x96\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\x1a\x00\x00\x00\x00\x00\x01\x00\x00C\xc4\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\xee\x00\x00\x00\x00\x00\x01\x00\x00P\xa1\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01J\x00\x00\x00\x00\x00\x01\x00\x002\x1d\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\x94\x00\x00\x00\x00\x00\x01\x00\x00K\x14\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\xe8\x00\x00\x00\x00\x00\x01\x00\x00B\x10\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\xbc\x00\x00\x00\x00\x00\x01\x00\x00L\xe4\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x9c\x00\x00\x00\x00\x00\x01\x00\x00;\xea\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02p\x00\x00\x00\x00\x00\x01\x00\x00H%\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x00\x00\x00\x00\x00\x00\x01\x00\x00+\xe7\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\xc0\x00\x00\x00\x00\x00\x01\x00\x00>\xd9\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x00\xca\x00\x00\x00\x00\x00\x01\x00\x00\x01\x8c\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02H\x00\x00\x00\x00\x00\x01\x00\x00\x1cM\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01l\x00\x00\x00\x00\x00\x01\x00\x00\x0c\xc2\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x22\x00\x00\x00\x00\x00\x01\x00\x00\x06\x9c\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\x1a\x00\x00\x00\x00\x00\x01\x00\x00\x1a\x8a\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\xee\x00\x00\x00\x00\x00\x01\x00\x00&\x94\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01J\x00\x00\x00\x00\x00\x01\x00\x00\x09\xf1\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\x94\x00\x00\x00\x00\x00\x01\x00\x00!X\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\xe8\x00\x00\x00\x00\x00\x01\x00\x00\x19\x13\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\xbc\x00\x00\x00\x00\x00\x01\x00\x00#\x08\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x9c\x00\x00\x00\x00\x00\x01\x00\x00\x13c\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02p\x00\x00\x00\x00\x00\x01\x00\x00\x1e\xa4\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x00\x00\x00\x00\x00\x00\x01\x00\x00\x04\x18\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\xc0\x00\x00\x00\x00\x00\x01\x00\x00\x16\x17\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x00\xca\x00\x00\x00\x00\x00\x01\x00\x00u\xe5\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02H\x00\x00\x00\x00\x00\x01\x00\x00\x8c\xee\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01l\x00\x00\x00\x00\x00\x01\x00\x00\x7f\xc1\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x22\x00\x00\x00\x00\x00\x01\x00\x00zY\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\x1a\x00\x00\x00\x00\x00\x01\x00\x00\x8b!\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\xee\x00\x00\x00\x00\x00\x01\x00\x00\x97\xaa\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01J\x00\x00\x00\x00\x00\x01\x00\x00}Y\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\x94\x00\x00\x00\x00\x00\x01\x00\x00\x91\xb7\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\xe8\x00\x00\x00\x00\x00\x01\x00\x00\x89\xab\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\xbc\x00\x00\x00\x00\x00\x01\x00\x00\x93\xc9\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x9c\x00\x00\x00\x00\x00\x01\x00\x00\x84\x0c\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02p\x00\x00\x00\x00\x00\x01\x00\x00\x8f\x00\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x00\x00\x00\x00\x00\x00\x01\x00\x00xf\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\xc0\x00\x00\x00\x00\x00\x01\x00\x00\x86\xc3\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x00\xca\x00\x00\x00\x00\x00\x01\x00\x00Sx\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02H\x00\x00\x00\x00\x00\x01\x00\x00ma\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\x1a\x00\x00\x00\x00\x00\x01\x00\x00k\xb8\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01J\x00\x00\x00\x00\x00\x01\x00\x00b\xc3\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\xbc\x00\x00\x00\x00\x00\x01\x00\x00s\x0c\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x9c\x00\x00\x00\x00\x00\x01\x00\x00e\xce\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02p\x00\x00\x00\x00\x00\x01\x00\x00p&\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x00\x00\x00\x00\x00\x00\x01\x00\x00X\x97\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\xc0\x00\x00\x00\x00\x00\x01\x00\x00h\xb4\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x00\xca\x00\x00\x00\x00\x00\x01\x00\x00)=\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02H\x00\x00\x00\x00\x00\x01\x00\x00E\xa1\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01l\x00\x00\x00\x00\x00\x01\x00\x005\x1e\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x22\x00\x00\x00\x00\x00\x01\x00\x00.\x96\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\x1a\x00\x00\x00\x00\x00\x01\x00\x00C\xc4\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\xee\x00\x00\x00\x00\x00\x01\x00\x00P\xa1\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01J\x00\x00\x00\x00\x00\x01\x00\x002\x1d\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\x94\x00\x00\x00\x00\x00\x01\x00\x00K\x14\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\xe8\x00\x00\x00\x00\x00\x01\x00\x00B\x10\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\xbc\x00\x00\x00\x00\x00\x01\x00\x00L\xe4\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x9c\x00\x00\x00\x00\x00\x01\x00\x00;\xea\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02p\x00\x00\x00\x00\x00\x01\x00\x00H%\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x00\x00\x00\x00\x00\x00\x01\x00\x00+\xe7\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\xc0\x00\x00\x00\x00\x00\x01\x00\x00>\xd9\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x00\xca\x00\x00\x00\x00\x00\x01\x00\x00\x01\x8c\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02H\x00\x00\x00\x00\x00\x01\x00\x00\x1cM\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01l\x00\x00\x00\x00\x00\x01\x00\x00\x0c\xc2\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x22\x00\x00\x00\x00\x00\x01\x00\x00\x06\x9c\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\x1a\x00\x00\x00\x00\x00\x01\x00\x00\x1a\x8a\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\xee\x00\x00\x00\x00\x00\x01\x00\x00&\x94\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01J\x00\x00\x00\x00\x00\x01\x00\x00\x09\xf1\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\x94\x00\x00\x00\x00\x00\x01\x00\x00!X\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\xe8\x00\x00\x00\x00\x00\x01\x00\x00\x19\x13\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\xbc\x00\x00\x00\x00\x00\x01\x00\x00#\x08\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x9c\x00\x00\x00\x00\x00\x01\x00\x00\x13c\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02p\x00\x00\x00\x00\x00\x01\x00\x00\x1e\xa4\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x00\x00\x00\x00\x00\x00\x01\x00\x00\x04\x18\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\xc0\x00\x00\x00\x00\x00\x01\x00\x00\x16\x17\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x00\xca\x00\x00\x00\x00\x00\x01\x00\x00u\xe5\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02H\x00\x00\x00\x00\x00\x01\x00\x00\x8c\xee\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01l\x00\x00\x00\x00\x00\x01\x00\x00\x7f\xc1\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x22\x00\x00\x00\x00\x00\x01\x00\x00zY\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\x1a\x00\x00\x00\x00\x00\x01\x00\x00\x8b!\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\xee\x00\x00\x00\x00\x00\x01\x00\x00\x97\xaa\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01J\x00\x00\x00\x00\x00\x01\x00\x00}Y\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\x94\x00\x00\x00\x00\x00\x01\x00\x00\x91\xb7\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\xe8\x00\x00\x00\x00\x00\x01\x00\x00\x89\xab\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02\xbc\x00\x00\x00\x00\x00\x01\x00\x00\x93\xc9\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x9c\x00\x00\x00\x00\x00\x01\x00\x00\x84\x0c\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x02p\x00\x00\x00\x00\x00\x01\x00\x00\x8f\x00\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\x00\x00\x00\x00\x00\x00\x01\x00\x00xf\
\x00\x00\x01\x97i\xbd\x15\xa8\
\x00\x00\x01\xc0\x00\x00\x00\x00\x00\x01\x00\x00\x86\xc3\
\x00\x00\x01\x97i\xbd\x15\xa8\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
