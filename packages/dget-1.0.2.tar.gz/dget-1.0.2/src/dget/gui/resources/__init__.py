from PySide6 import QtGui

from . import icons  # noqa: F401

QtGui.QIcon.setThemeName("dget")
