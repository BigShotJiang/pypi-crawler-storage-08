"""Version information for jbang-jupyter-runner"""

__version__ = "1.0.0"
