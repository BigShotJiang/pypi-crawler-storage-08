"""
Domain package for IceCap.
"""
