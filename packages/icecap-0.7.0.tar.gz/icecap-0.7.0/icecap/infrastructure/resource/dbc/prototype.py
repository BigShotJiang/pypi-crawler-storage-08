class BaseDBCRecord:
    pass
