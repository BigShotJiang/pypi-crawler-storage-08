import warnings

warnings.warn(
    "The 'factrainer.xgboost' module is currently a placeholder and not yet implemented. "
    "Functionality will be added in a future release.",
    UserWarning,
    stacklevel=2,
)
