def test_foo() -> None:
    import factrainer.catboost  # noqa: F401
