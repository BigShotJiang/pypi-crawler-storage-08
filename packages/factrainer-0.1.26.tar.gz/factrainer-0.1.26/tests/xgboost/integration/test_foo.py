def test_foo() -> None:
    import factrainer.xgboost  # noqa: F401
