# factrainer.core

Main cross-validation functionality that is installed by default. Used in combination with the framework-specific plugin packages.
