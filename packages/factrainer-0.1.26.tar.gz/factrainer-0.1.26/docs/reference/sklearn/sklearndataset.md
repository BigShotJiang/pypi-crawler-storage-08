# SklearnDataset

::: factrainer.sklearn.SklearnDataset
    options:
        members:
            - X
            - y