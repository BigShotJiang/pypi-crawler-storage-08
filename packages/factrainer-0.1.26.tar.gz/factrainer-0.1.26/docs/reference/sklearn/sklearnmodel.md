# SklearnModel

::: factrainer.sklearn.SklearnModel
    options:
        members:
            - estimator