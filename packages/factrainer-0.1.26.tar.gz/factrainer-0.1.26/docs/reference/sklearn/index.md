# factrainer.sklearn

Optionally installable plugin package for Scikit-learn integration.
