# factrainer.catboost

!!! note "Implementation Status"
    The CatBoost integration is currently WIP. It will be added in a future release.
