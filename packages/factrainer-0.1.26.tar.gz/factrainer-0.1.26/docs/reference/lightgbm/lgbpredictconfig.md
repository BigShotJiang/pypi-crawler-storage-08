# LgbPredictConfig

::: factrainer.lightgbm.LgbPredictConfig
    options:
        members:
            - start_iteration
            - num_iteration
            - raw_score
            - pred_leaf
            - pred_contrib
            - data_has_header
            - validate_features
