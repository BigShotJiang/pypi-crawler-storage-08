# LgbTrainConfig

::: factrainer.lightgbm.LgbTrainConfig
    options:
        members:
            - params
            - num_boost_round
            - valid_names
            - feval
            - init_model
            - keep_training_booster
            - callbacks