# factrainer.xgboost

!!! note "Implementation Status"
    The XGBoost integration is currently WIP. It will be added in a future release.
