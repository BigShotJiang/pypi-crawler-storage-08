"""Package supporting dynamic dosstrings."""

from .inherit_docstrings import inherit_docstrings

__all__ = ["inherit_docstrings"]
