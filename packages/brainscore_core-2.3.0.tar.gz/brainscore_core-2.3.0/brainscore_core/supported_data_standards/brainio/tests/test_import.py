def test_import_brainio_collection():
    # noinspection PyUnresolvedReferences
    from brainscore_core.supported_data_standards.brainio.packaging import package_stimulus_set, package_data_assembly