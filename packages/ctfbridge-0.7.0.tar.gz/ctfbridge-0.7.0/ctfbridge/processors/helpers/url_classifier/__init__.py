from .classifier import classify_links

__all__ = ["classify_links"]
