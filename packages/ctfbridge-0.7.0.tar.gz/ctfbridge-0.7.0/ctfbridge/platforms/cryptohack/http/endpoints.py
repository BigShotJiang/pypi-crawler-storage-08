class Endpoints:
    class Challenges:
        CATEGORIES = "/challenges/"

        @staticmethod
        def category_challenges(category_path: str):
            return category_path
