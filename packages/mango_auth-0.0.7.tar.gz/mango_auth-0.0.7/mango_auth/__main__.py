"""Main module function"""

from . import iinit_cli

if __name__ == "__main__":
    iinit_cli()
