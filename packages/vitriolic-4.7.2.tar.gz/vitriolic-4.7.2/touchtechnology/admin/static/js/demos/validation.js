$(function () {
 
  // Prevent demo form submission
  $('#demo-validation').submit (function (e) {
    e.preventDefault ()
  })

})