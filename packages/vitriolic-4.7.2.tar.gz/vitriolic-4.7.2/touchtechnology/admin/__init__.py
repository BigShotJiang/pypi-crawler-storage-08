"""[Developer API] Administration interface enhancements."""

default_app_config = "touchtechnology.admin.apps.AdminConfig"
