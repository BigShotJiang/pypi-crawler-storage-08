"""[Developer API] Shared utilities for touchtechnology apps.

This package contains common models and helpers intended for reuse.
"""

default_app_config = "touchtechnology.common.apps.CommonConfig"
