"""[Developer API] News publishing components."""

default_app_config = "touchtechnology.news.apps.NewsConfig"

INSTALL = ("NewsSite",)
