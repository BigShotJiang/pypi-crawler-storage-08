"""Test configuration for pytest-once tests."""

pytest_plugins = ["pytester"]
