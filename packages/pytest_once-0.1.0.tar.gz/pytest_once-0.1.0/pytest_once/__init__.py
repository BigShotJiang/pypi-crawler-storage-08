"""pytest-once: xdist-safe 'run once' fixture decorator for pytest."""

from pytest_once.decorator import once_fixture

__all__ = ["once_fixture"]
