The source files in this directory are copied from the zlib compression library, version 1.3.1
available from https://www.zlib.net/ .

The source files here are only a subset of the complete zlib library. The files have not been
changed except for the addition of a comment at the top of each file, noting its association
with the zlib license and the version number.

Within Ghidra, the zlib license is available (in both the source repository and distributions)
in licenses/zlib_License.txt.  Additionally the license appears at the top of zlib.h in this
directory.
