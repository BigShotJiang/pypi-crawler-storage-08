PKG_NAME = "inspect_swe"
