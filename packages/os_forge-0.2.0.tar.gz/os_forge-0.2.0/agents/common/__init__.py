# Common agent utilities and base classes
