=======
Credits
=======

Developers
----------

* Uwe Schmitt <uwe.schmitt@id.ethz.ch>


Credits
-------

``sympy2c`` uses ideas previously developed by Joel Akeret and Lukas Gamper
within `HOPE <https://cosmology.ethz.ch/research/software-lab/HOPE.html>`_.


Contact information
-------------------

If you have any suggestions or questions about ``sympy2c`` feel free to email
us at `pycosmo@lists.phys.ethz.ch <mailto:pycosmo@lists.phys.ethz.ch>`_.
