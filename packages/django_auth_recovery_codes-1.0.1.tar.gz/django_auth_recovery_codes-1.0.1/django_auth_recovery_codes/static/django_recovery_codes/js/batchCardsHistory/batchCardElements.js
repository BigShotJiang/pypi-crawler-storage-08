// Placed in a separe file because the elements will be needed in other files
// This creates a central place rather having the elements scattered.
// 

export const generaterecoveryBatchSectionElement = document.getElementById("generate-code-section");
export const recoveryBatchSectionElement         = document.getElementById("static-batch-cards-history");
