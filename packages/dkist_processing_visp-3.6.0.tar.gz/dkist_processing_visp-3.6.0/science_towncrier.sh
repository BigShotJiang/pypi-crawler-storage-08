#!/bin/bash

towncrier "$@" --config towncrier_science.toml
