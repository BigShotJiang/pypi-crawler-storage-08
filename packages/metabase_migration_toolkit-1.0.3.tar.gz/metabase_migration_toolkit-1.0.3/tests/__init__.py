"""
Test suite for Metabase Migration Toolkit.

This package contains unit tests, integration tests, and test fixtures
for the metabase_migration package.
"""
