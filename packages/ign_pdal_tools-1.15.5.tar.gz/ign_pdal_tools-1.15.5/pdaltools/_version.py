__version__ = "1.15.5"


if __name__ == "__main__":
    print(__version__)
