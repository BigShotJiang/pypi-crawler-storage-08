"""CLI package for Team Pal."""

from __future__ import annotations

from .cli_main import main, run_cli

__all__ = ["main", "run_cli"]
