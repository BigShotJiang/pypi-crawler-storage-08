/**
 * Example of [Jest](https://jestjs.io/docs/getting-started) unit tests
 */

describe('jupyterlab_close_all_tabs_extension', () => {
  it('should be tested', () => {
    expect(1 + 1).toEqual(2);
  });
});
