from __future__ import annotations

from .base import Base


class Info(Base):
    pass
