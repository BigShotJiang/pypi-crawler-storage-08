# Release History

## 1.0.0 (2025-09-25)

### Features Added

  - Model `DurableTaskMgmtClient` added parameter `cloud_setting` in method `__init__`
  - Added enum `SchedulerSkuName`

## 1.0.0b2 (2025-04-24)

### Features Added

  - Client `DurableTaskMgmtClient` added operation group `retention_policies`
  - Added enum `PurgeableOrchestrationState`
  - Added model `RetentionPolicy`
  - Added model `RetentionPolicyDetails`
  - Added model `RetentionPolicyProperties`
  - Added operation group `RetentionPoliciesOperations`

## 1.0.0b1 (2025-03-25)

### Other Changes

  - Initial version
