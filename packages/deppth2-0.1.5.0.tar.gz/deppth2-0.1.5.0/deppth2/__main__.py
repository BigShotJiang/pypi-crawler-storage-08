"""__main__: executed when deppth2 directory is called as a script."""

from .deppth2 import main
main()