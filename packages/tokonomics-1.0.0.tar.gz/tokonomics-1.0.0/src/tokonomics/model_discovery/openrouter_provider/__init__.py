"""OpenRouter model info Provider."""

from tokonomics.model_discovery.openrouter_provider.provider import (
    OpenRouterProvider,
)

__all__ = ["OpenRouterProvider"]
