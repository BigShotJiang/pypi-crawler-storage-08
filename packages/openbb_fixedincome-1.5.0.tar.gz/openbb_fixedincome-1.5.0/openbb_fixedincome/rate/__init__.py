"""Initialize Fixed income rate router."""
