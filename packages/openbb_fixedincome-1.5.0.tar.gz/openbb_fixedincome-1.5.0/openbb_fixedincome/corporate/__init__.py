"""Initialize the Fixed Income Corporate module."""
