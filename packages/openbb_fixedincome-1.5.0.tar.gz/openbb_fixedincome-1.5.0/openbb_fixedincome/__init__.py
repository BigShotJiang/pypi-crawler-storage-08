"""Fixed income router init."""
