"""Initialize the Fixed Income Spreads module."""
