"""Initialize the Fixed Income Government module."""
