#!/usr/bin/env python
from setuptools import setup

if __name__ == "__main__":
    # Defer all metadata to pyproject.toml (PEP 621)
    setup()
