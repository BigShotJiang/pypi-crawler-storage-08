from llmling.completions.protocols import CompletionProvider
from llmling.completions.types import CompletionFunction

__all__ = [
    "CompletionFunction",
    "CompletionProvider",
]
