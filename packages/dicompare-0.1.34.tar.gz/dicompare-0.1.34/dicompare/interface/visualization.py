"""
Visualization utilities for dicompare interface.

This module provides image processing and visualization functions
for web interfaces and external consumption.

NOTE: All visualization functions have been removed as they are unused.
This file exists to maintain the module structure.
"""

# This module is currently empty as all visualization functions were unused
# and have been removed for code cleanup.