"""
Utility Tools for Concur MCP Server

Provides utility MCP tools for testing connections, getting reference data, etc.
"""

from typing import Dict, Any
from enum import Enum
from ..sdk import ConcurExpenseSDK, AuthenticationError, ConcurAPIError


class ConcurAPITopic(Enum):
    """Available topics for Concur API guides and examples."""
    
    # Getting Started
    QUICK_START = "quick_start"
    AUTHENTICATION = "authentication"
    SETUP = "setup"
    
    # Core Operations
    REPORTS = "reports"
    EXPENSES = "expenses"
    
    # Reference Data
    EXPENSE_TYPES = "expense_types"
    PAYMENT_TYPES = "payment_types"
    
    # Common Patterns
    ERROR_HANDLING = "error_handling"
    PAGINATION = "pagination"
    BATCH_OPERATIONS = "batch_operations"
    
    # Troubleshooting
    DEBUGGING = "debugging"
    BEST_PRACTICES = "best_practices"


def register_utility_tools(mcp, concur_sdk: ConcurExpenseSDK):
    """Register utility tools with the MCP server."""
    
    @mcp.tool()
    def test_concur_connection() -> Dict[str, Any]:
        """
        Test the connection to Concur v4 APIs.
        
        Returns:
            Dictionary indicating connection status and API version
        """
        try:
            result = concur_sdk.test_connection()
            if result['success']:
                result['api_version'] = 'v4'
                result['message'] = f"Successfully connected to Concur v4 APIs. {result.get('message', '')}"
            return result
            
        except (AuthenticationError, ConcurAPIError) as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Failed to connect to Concur v4 APIs: {str(e)}"
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Unexpected error testing v4 connection: {str(e)}"
            }
    
    @mcp.tool()
    def get_concur_expense_types() -> Dict[str, Any]:
        """
        Get available expense types using v4 user-specific API.
        
        This function retrieves expense types that are available to the current user,
        based on their policy and configuration.
        
        Returns:
            Dictionary containing available expense types
        """
        try:
            result = concur_sdk.get_expense_types()
            if result['success']:
                result['api_version'] = 'v4'
                result['message'] = f"Successfully retrieved {result['count']} expense types using v4 API"
            return result
            
        except (AuthenticationError, ConcurAPIError) as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Failed to retrieve expense types from v4 API: {str(e)}"
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Unexpected error retrieving expense types: {str(e)}"
            }
    
    @mcp.tool()
    def get_concur_payment_types() -> Dict[str, Any]:
        """
        Get available payment types using v4 API.
        
        Returns:
            Dictionary containing available payment types
        """
        try:
            result = concur_sdk.get_payment_types()
            if result['success']:
                result['api_version'] = 'v4'
                result['message'] = f"Successfully retrieved {result['count']} payment types using v4 API"
            return result
            
        except (AuthenticationError, ConcurAPIError) as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Failed to retrieve payment types from v4 API: {str(e)}"
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Unexpected error retrieving payment types: {str(e)}"
            }
    
    @mcp.tool()
    def get_concur_user_id() -> Dict[str, Any]:
        """
        Get the current user's ID from the v4 API.
        
        Returns:
            Dictionary containing user ID and profile information
        """
        try:
            result = concur_sdk.get_user_id()
            if result['success']:
                result['api_version'] = 'v4'
                result['message'] = "Successfully retrieved user ID from v4 API"
            return result
            
        except (AuthenticationError, ConcurAPIError) as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Failed to retrieve user ID from v4 API: {str(e)}"
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Unexpected error retrieving user ID: {str(e)}"
            }
    
    @mcp.tool()
    def get_concur_api_guide(
        topic: ConcurAPITopic,
        include_examples: bool = True,
        include_howto: bool = True
    ) -> Dict[str, Any]:
        """
        Get comprehensive Concur v4 API guide with examples and how-to instructions.
        
        Note: This is a simplified version. For full documentation guides, 
        please refer to the Concur API documentation or use the legacy tools.
        
        Available Topics:
        - AUTHENTICATION: OAuth2 setup and token management for v4 APIs
        - REPORTS: Creating, listing, and deleting expense reports
        - EXPENSES: Managing expense entries
        - ERROR_HANDLING: Common API errors and troubleshooting
        - BEST_PRACTICES: Performance optimization and security
        
        Args:
            topic: The API topic to get guidance for
            include_examples: Whether to include code examples (default: True)
            include_howto: Whether to include step-by-step instructions (default: True)
        
        Returns:
            Comprehensive guide with examples and reference information
        """
        try:
            # Simplified guide - provides basic information
            guides = {
                ConcurAPITopic.AUTHENTICATION: {
                    "title": "Concur v4 API Authentication",
                    "overview": "Use OAuth2 password grant flow for v4 authentication",
                    "message": "Refer to Concur API documentation for detailed authentication guides"
                },
                ConcurAPITopic.REPORTS: {
                    "title": "Managing Expense Reports",
                    "overview": "Use list_concur_reports, create_concur_report, and delete_concur_report tools",
                    "message": "Refer to tool descriptions for detailed usage"
                },
                ConcurAPITopic.EXPENSES: {
                    "title": "Managing Expense Entries",
                    "overview": "Use expense management tools to create, update, and delete expenses",
                    "message": "Refer to tool descriptions for detailed usage"
                },
            }
            
            guide = guides.get(topic, {
                "title": f"Guide for {topic.value}",
                "overview": "Documentation not yet available",
                "message": f"Please refer to SAP Concur API documentation for {topic.value}"
            })
            
            return {
                'success': True,
                'topic': topic.value,
                'api_version': 'v4',
                **guide
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'message': f'Failed to generate guide for {topic.value}: {str(e)}'
            }

