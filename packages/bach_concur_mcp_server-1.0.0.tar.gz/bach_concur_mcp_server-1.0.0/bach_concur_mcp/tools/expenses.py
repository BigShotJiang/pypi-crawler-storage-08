"""
Expense Management Tools for Concur MCP Server

Provides MCP tools for managing expense entries using Concur v4 APIs.
"""

from typing import Dict, Any, Optional
from ..sdk import ConcurExpenseSDK, AuthenticationError, NotFoundError, ValidationError, ConcurAPIError


def register_expense_tools(mcp, concur_sdk: ConcurExpenseSDK):
    """Register expense management tools with the MCP server."""
    
    @mcp.tool()
    def list_concur_expenses(report_id: str, limit: int = 25, offset: int = 0) -> Dict[str, Any]:
        """
        List expense entries for a specific report using v4 API.
        
        Args:
            report_id: The ID of the report to list expenses from
            limit: Maximum number of expenses to return (default: 25)
            offset: Number of expenses to skip (default: 0)
        
        Returns:
            Dictionary containing expenses and v4 metadata
        """
        try:
            result = concur_sdk.list_expenses(report_id=report_id, limit=limit, offset=offset)
            if result['success']:
                result['api_version'] = 'v4'
                result['message'] = f"Successfully retrieved {result['count']} expenses using v4 API"
            return result
            
        except (AuthenticationError, NotFoundError, ConcurAPIError) as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Failed to retrieve expenses from v4 API: {str(e)}"
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Unexpected error retrieving expenses: {str(e)}"
            }
    
    @mcp.tool()
    def get_concur_expense_details(expense_id: str, report_id: str) -> Dict[str, Any]:
        """
        Get detailed information about a specific expense entry.
        
        Args:
            expense_id: The ID of the expense to retrieve
            report_id: The ID of the report containing the expense
        
        Returns:
            Dictionary containing detailed expense information
        """
        try:
            result = concur_sdk.get_expense(expense_id=expense_id, report_id=report_id)
            if result['success']:
                result['message'] = f"Successfully retrieved details for expense {expense_id}"
            return result
            
        except NotFoundError:
            return {
                'success': False,
                'error': 'Expense not found',
                'message': f"No expense found with ID: {expense_id}"
            }
        except (AuthenticationError, ValidationError, ConcurAPIError) as e:
            return {
                'success': False,
                'error': str(e),
                'message': f"Failed to retrieve expense details: {str(e)}"
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'message': f"Unexpected error retrieving expense details: {str(e)}"
            }
    
    @mcp.tool()
    def create_concur_expense(report_id: str, expense_type: str, amount: float, 
                             currency_code: str = "USD", transaction_date: Optional[str] = None,
                             business_purpose: str = "", vendor_description: str = "") -> Dict[str, Any]:
        """
        Create a new expense entry using v4 API.
        
        Args:
            report_id: The ID of the report to add the expense to
            expense_type: Type of expense (e.g., 'INCTS' for Internet/Telecom Service)
            amount: Amount of the expense
            currency_code: Currency code (default: USD)
            transaction_date: Transaction date in YYYY-MM-DD format (default: today)
            business_purpose: Business justification for the expense
            vendor_description: Vendor or merchant name
        
        Returns:
            Dictionary containing created expense details
        """
        try:
            result = concur_sdk.create_expense(
                report_id=report_id,
                expense_type=expense_type,
                amount=amount,
                currency_code=currency_code,
                transaction_date=transaction_date,
                business_purpose=business_purpose,
                vendor_description=vendor_description
            )
            if result['success']:
                result['api_version'] = 'v4'
                result['message'] = f"Successfully created expense using v4 API"
            return result
            
        except (AuthenticationError, ValidationError, ConcurAPIError) as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Failed to create expense using v4 API: {str(e)}"
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Unexpected error creating expense: {str(e)}"
            }
    
    @mcp.tool()
    def update_concur_expense(expense_id: str, report_id: str, amount: Optional[float] = None,
                             expense_type: Optional[str] = None, currency_code: Optional[str] = None,
                             transaction_date: Optional[str] = None, business_purpose: Optional[str] = None,
                             vendor_description: Optional[str] = None) -> Dict[str, Any]:
        """
        Update an existing expense entry using v4 API.
        
        Args:
            expense_id: The ID of the expense to update
            report_id: The ID of the report containing the expense
            amount: New amount (optional)
            expense_type: New expense type (optional)
            currency_code: New currency code (optional)
            transaction_date: New transaction date in YYYY-MM-DD format (optional)
            business_purpose: New business justification (optional)
            vendor_description: New vendor name (optional)
        
        Returns:
            Dictionary containing updated expense details
        """
        try:
            result = concur_sdk.update_expense(
                expense_id=expense_id,
                report_id=report_id,
                amount=amount,
                expense_type=expense_type,
                currency_code=currency_code,
                transaction_date=transaction_date,
                business_purpose=business_purpose,
                vendor_description=vendor_description
            )
            if result['success']:
                result['api_version'] = 'v4'
                result['message'] = f"Successfully updated expense {expense_id} using v4 API"
            return result
            
        except NotFoundError:
            return {
                'success': False,
                'error': 'Expense not found',
                'api_version': 'v4',
                'message': f"No expense found with ID: {expense_id}"
            }
        except (AuthenticationError, ValidationError, ConcurAPIError) as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Failed to update expense using v4 API: {str(e)}"
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Unexpected error updating expense: {str(e)}"
            }
    
    @mcp.tool()
    def delete_concur_expense(expense_id: str, report_id: str) -> Dict[str, Any]:
        """
        Delete an expense entry using v4 API.
        
        Args:
            expense_id: The ID of the expense to delete
            report_id: The ID of the report containing the expense
        
        Returns:
            Dictionary indicating deletion success
        """
        try:
            result = concur_sdk.delete_expense(expense_id=expense_id, report_id=report_id)
            if result['success']:
                result['api_version'] = 'v4'
                result['message'] = f"Successfully deleted expense {expense_id} using v4 API"
            return result
            
        except NotFoundError:
            return {
                'success': False,
                'error': 'Expense not found',
                'api_version': 'v4',
                'message': f"No expense found with ID: {expense_id}"
            }
        except (AuthenticationError, ValidationError, ConcurAPIError) as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Failed to delete expense using v4 API: {str(e)}"
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Unexpected error deleting expense: {str(e)}"
            }

