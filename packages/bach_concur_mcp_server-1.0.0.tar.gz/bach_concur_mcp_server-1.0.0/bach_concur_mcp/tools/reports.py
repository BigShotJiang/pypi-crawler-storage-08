"""
Report Management Tools for Concur MCP Server

Provides MCP tools for managing expense reports using Concur v4 APIs.
"""

from typing import Dict, Any, Optional
from ..sdk import ConcurExpenseSDK, AuthenticationError, NotFoundError, ValidationError, ConcurAPIError


def register_report_tools(mcp, concur_sdk: ConcurExpenseSDK):
    """Register report management tools with the MCP server."""
    
    @mcp.tool()
    def list_concur_reports(limit: int = 25, user: Optional[str] = None) -> Dict[str, Any]:
        """
        List expense reports using v4 API.
        
        Args:
            limit: Maximum number of reports to return (default: 25)
            user: Optional user ID (default: current authenticated user)
        
        Returns:
            Dictionary containing reports and v4 metadata
        """
        try:
            result = concur_sdk.list_reports(limit=limit, user=user)
            if result['success']:
                result['api_version'] = 'v4'
                result['message'] = f"Successfully retrieved {result['count']} reports using v4 API"
            return result
            
        except (AuthenticationError, ConcurAPIError) as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Failed to retrieve reports from v4 API: {str(e)}"
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Unexpected error retrieving reports: {str(e)}"
            }
    
    @mcp.tool()
    def get_concur_report_details(report_id: str) -> Dict[str, Any]:
        """
        Get detailed information about a specific Concur expense report.
        
        Args:
            report_id: The ID of the expense report to retrieve
        
        Returns:
            Dictionary containing detailed report information
        """
        try:
            result = concur_sdk.get_report(report_id)
            if result['success']:
                result['message'] = f"Successfully retrieved details for report {report_id}"
            return result
            
        except NotFoundError:
            return {
                'success': False,
                'error': 'Report not found',
                'message': f"No report found with ID: {report_id}"
            }
        except (AuthenticationError, ValidationError, ConcurAPIError) as e:
            return {
                'success': False,
                'error': str(e),
                'message': f"Failed to retrieve report details: {str(e)}"
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'message': f"Unexpected error retrieving report details: {str(e)}"
            }
    
    @mcp.tool()
    def create_concur_report(name: str, purpose: str = "", business_purpose: str = "", 
                           currency_code: str = "USD", country: str = "US") -> Dict[str, Any]:
        """
        Create a new expense report using v4 API.
        
        Args:
            name: Name of the report
            purpose: Purpose of the report
            business_purpose: Business justification for the report
            currency_code: Currency code (default: USD)
            country: Country code (default: US)
        
        Returns:
            Dictionary containing created report details
        """
        try:
            result = concur_sdk.create_report(
                name=name, 
                purpose=purpose, 
                business_purpose=business_purpose,
                currency_code=currency_code, 
                country=country
            )
            if result['success']:
                result['api_version'] = 'v4'
                result['message'] = f"Successfully created report '{name}' using v4 API"
            return result
            
        except (AuthenticationError, ValidationError, ConcurAPIError) as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Failed to create report using v4 API: {str(e)}"
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Unexpected error creating report: {str(e)}"
            }
    
    @mcp.tool()
    def delete_concur_report(report_id: str) -> Dict[str, Any]:
        """
        Delete an expense report using v4 API.
        
        Args:
            report_id: The ID of the report to delete
        
        Returns:
            Dictionary indicating deletion success
        """
        try:
            result = concur_sdk.delete_report(report_id)
            if result['success']:
                result['api_version'] = 'v4'
                result['message'] = f"Successfully deleted report {report_id} using v4 API"
            return result
            
        except NotFoundError:
            return {
                'success': False,
                'error': 'Report not found',
                'api_version': 'v4',
                'message': f"No report found with ID: {report_id}"
            }
        except (AuthenticationError, ValidationError, ConcurAPIError) as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Failed to delete report using v4 API: {str(e)}"
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'api_version': 'v4',
                'message': f"Unexpected error deleting report: {str(e)}"
            }

