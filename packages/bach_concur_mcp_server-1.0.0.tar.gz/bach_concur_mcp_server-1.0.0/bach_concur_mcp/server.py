#!/usr/bin/env python3
"""
Bach Concur MCP Server

Main server module for the Concur expense management MCP server.
"""

import os
import sys
import logging
import argparse
from typing import Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def parse_arguments() -> Optional[argparse.Namespace]:
    """Parse command line arguments for Concur API credentials"""
    parser = argparse.ArgumentParser(
        description='Concur MCP Server - SAP Concur integration via Model Context Protocol',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Using command-line arguments
  %(prog)s --client-id YOUR_ID --client-secret YOUR_SECRET --username USER --password PASS
  
  # Using environment variables (set in .env or shell)
  %(prog)s
  
  # Using uvx with arguments
  uvx bach-concur-mcp-server --client-id YOUR_ID --client-secret YOUR_SECRET --username USER --password PASS
  
Environment Variables:
  CONCUR_CLIENT_ID       Your Concur app client ID
  CONCUR_CLIENT_SECRET   Your Concur app client secret  
  CONCUR_USERNAME        Your Concur username
  CONCUR_PASSWORD        Your Concur password
  
Note: Command-line arguments take precedence over environment variables.
        """
    )
    
    parser.add_argument(
        '--client-id',
        dest='client_id',
        help='Concur API client ID (overrides CONCUR_CLIENT_ID env var)'
    )
    
    parser.add_argument(
        '--client-secret',
        dest='client_secret',
        help='Concur API client secret (overrides CONCUR_CLIENT_SECRET env var)'
    )
    
    parser.add_argument(
        '--username',
        dest='username',
        help='Concur username (overrides CONCUR_USERNAME env var)'
    )
    
    parser.add_argument(
        '--password',
        dest='password',
        help='Concur password (overrides CONCUR_PASSWORD env var)'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='%(prog)s 1.0.0'
    )
    
    return parser.parse_args()


def apply_cli_arguments(args: argparse.Namespace) -> None:
    """Apply command-line arguments to environment variables"""
    if args.client_id:
        os.environ['CONCUR_CLIENT_ID'] = args.client_id
        logger.info("✅ CONCUR_CLIENT_ID set from command-line argument")
    
    if args.client_secret:
        os.environ['CONCUR_CLIENT_SECRET'] = args.client_secret
        logger.info("✅ CONCUR_CLIENT_SECRET set from command-line argument")
    
    if args.username:
        os.environ['CONCUR_USERNAME'] = args.username
        logger.info("✅ CONCUR_USERNAME set from command-line argument")
    
    if args.password:
        os.environ['CONCUR_PASSWORD'] = args.password
        logger.info("✅ CONCUR_PASSWORD set from command-line argument")


def check_environment():
    """Check and validate environment variables"""
    logger.info("Checking environment configuration...")
    
    # Load environment variables with fallbacks
    try:
        from dotenv import load_dotenv
        load_dotenv()
        logger.info("✅ Environment variables loaded from .env")
    except ImportError:
        logger.warning("⚠️  python-dotenv not available, using system environment only")
    except Exception as e:
        logger.warning(f"⚠️  Could not load .env file: {e}")
    
    # Required environment variables
    required_vars = {
        "CONCUR_CLIENT_ID": os.getenv("CONCUR_CLIENT_ID"),
        "CONCUR_CLIENT_SECRET": os.getenv("CONCUR_CLIENT_SECRET"), 
        "CONCUR_USERNAME": os.getenv("CONCUR_USERNAME"),
        "CONCUR_PASSWORD": os.getenv("CONCUR_PASSWORD")
    }
    
    missing_vars = [var for var, value in required_vars.items() if not value]
    
    if missing_vars:
        logger.error(f"❌ Missing required environment variables: {', '.join(missing_vars)}")
        logger.error("Please set these variables in your deployment environment:")
        for var in missing_vars:
            logger.error(f"   - {var}")
        return False
    
    # Log success (without exposing values)
    for var in required_vars:
        logger.info(f"✅ {var}: configured")
    
    return True


def create_server():
    """Create and configure the MCP server instance"""
    try:
        from fastmcp import FastMCP
        from .sdk import ConcurExpenseSDK
        from .tools import register_report_tools, register_expense_tools, register_utility_tools
        
        # Initialize the MCP server
        mcp = FastMCP(name="BachConcurServer")
        logger.info("✅ FastMCP server created")
        
        # Initialize the Concur SDK
        try:
            concur_sdk = ConcurExpenseSDK()
            logger.info("✅ ConcurExpenseSDK initialized")
            
            # Test connection
            connection_result = concur_sdk.test_connection()
            if connection_result.get('success'):
                logger.info("✅ Concur API connection verified")
            else:
                logger.warning(f"⚠️  Concur API connection test failed: {connection_result.get('message')}")
                
        except Exception as e:
            logger.error(f"❌ SDK initialization failed: {e}")
            return None
        
        # Register all tools
        try:
            register_report_tools(mcp, concur_sdk)
            logger.info("✅ Report tools registered")
            
            register_expense_tools(mcp, concur_sdk)
            logger.info("✅ Expense tools registered")
            
            register_utility_tools(mcp, concur_sdk)
            logger.info("✅ Utility tools registered")
            
        except Exception as e:
            logger.error(f"❌ Failed to register tools: {e}")
            return None
        
        logger.info("✅ Server initialized successfully")
        return mcp
        
    except Exception as e:
        logger.error(f"❌ Server creation failed: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return None


def main():
    """Main server startup function"""
    logger.info("🚀 Starting Bach Concur MCP Server")
    logger.info("=" * 60)
    
    # Step 0: Parse and apply command-line arguments
    args = parse_arguments()
    apply_cli_arguments(args)
    
    # Step 1: Check environment
    if not check_environment():
        logger.error("❌ Environment check failed")
        return False
    
    # Step 2: Create server
    mcp = create_server()
    if not mcp:
        logger.error("❌ Server creation failed")
        return False
    
    # Step 3: Start server
    logger.info("🎯 Starting MCP server...")
    logger.info("Available tools:")
    logger.info("  📊 Report Management:")
    logger.info("    - list_concur_reports")
    logger.info("    - get_concur_report_details")
    logger.info("    - create_concur_report")
    logger.info("    - delete_concur_report")
    logger.info("  💰 Expense Management:")
    logger.info("    - list_concur_expenses")
    logger.info("    - get_concur_expense_details")
    logger.info("    - create_concur_expense")
    logger.info("    - update_concur_expense")
    logger.info("    - delete_concur_expense")
    logger.info("  🔧 Utility Tools:")
    logger.info("    - test_concur_connection")
    logger.info("    - get_concur_expense_types")
    logger.info("    - get_concur_payment_types")
    logger.info("    - get_concur_user_id")
    logger.info("    - get_concur_api_guide")
    
    try:
        logger.info("✅ Server starting successfully...")
        mcp.run()
        
    except KeyboardInterrupt:
        logger.info("👋 Server stopped by user")
        return True
    except Exception as e:
        logger.error(f"❌ Server runtime error: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return False


# Export mcp instance for FastMCP Cloud deployment
mcp = None

def get_mcp_instance():
    """Get or create the MCP server instance for cloud deployment"""
    global mcp
    if mcp is None:
        logger.info("Initializing MCP instance for cloud deployment...")
        if not check_environment():
            raise RuntimeError("Environment check failed")
        mcp = create_server()
        if not mcp:
            raise RuntimeError("Server creation failed")
        logger.info("✅ MCP instance ready for cloud deployment")
    return mcp


# Initialize mcp for direct import (cloud deployment)
# Only initialize if not running as main script
if __name__ != "__main__":
    try:
        mcp = get_mcp_instance()
    except Exception as e:
        logger.warning(f"Cloud deployment initialization deferred: {e}")
        mcp = None
else:
    mcp = None


if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except Exception as e:
        logger.error(f"❌ Fatal error: {e}")
        import traceback
        logger.error(traceback.format_exc())
        sys.exit(1)

