"""
Bach Concur MCP Server

A Model Context Protocol (MCP) server for SAP Concur expense management integration.
Built with FastMCP and supporting Claude Desktop, fast-agent, and other MCP clients.
"""

__version__ = "1.0.0"
__author__ = "bachstudio"

from .server import create_server, main

__all__ = ["create_server", "main", "__version__", "__author__"]

