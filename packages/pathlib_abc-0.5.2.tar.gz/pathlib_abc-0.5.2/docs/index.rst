.. include:: ../README.rst

Contents
--------

.. toctree::
    api
    examples
    changes
