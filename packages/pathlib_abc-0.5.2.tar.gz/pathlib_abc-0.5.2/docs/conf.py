project = 'pathlib-abc'
copyright = '2023'
author = 'Barney Gale'
extensions = [
    'sphinx_copybutton',
]
exclude_patterns = ['_build', 'Thumbs.db', '.DS_Store']
html_theme = 'furo'
