=======
History
=======

1.0.5 (2025-10-09)
------------------

* Fixed AttributeError in cli.py by updating __init__.py.

1.0.4 (2023-10-27)
------------------

* Decreased dependencies for install
* Added tryCatch for Aperio data without expected metadata



0.1.0 (2021-1-22)
------------------

* First release on PyPI.
