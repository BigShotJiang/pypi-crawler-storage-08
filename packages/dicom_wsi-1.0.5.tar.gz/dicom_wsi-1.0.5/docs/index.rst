Welcome to dicom-wsi's documentation!
======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   installation
   tldr
   gettingstarted
   example
   isyntax
   annotations
   extract
   code
   contributing
   authors
   history

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
