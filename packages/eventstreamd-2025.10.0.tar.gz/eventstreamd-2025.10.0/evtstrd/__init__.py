"""
A simple event stream server.

Events are sent on a Unix socket and then distributed to all interested
listeners via HTTP event streams.
"""
