# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["CustomizationConfigFilterParam"]


class CustomizationConfigFilterParam(TypedDict, total=False):
    enabled: bool
    """Filter by whether the target is enabled or not for customization"""

    finetuning_type: str
    """Filter by the finetuning type"""

    name: str
    """Filter by the name of the customization config"""

    namespace: str
    """The namespace of the configuration"""

    target_base_model: str
    """Filter by name of the target's base model."""

    target_name: str
    """Filter by name of the target."""

    training_type: str
    """Filter by the training type"""
