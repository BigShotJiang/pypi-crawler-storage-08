# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Required, TypeAlias, TypedDict

from .audit_config_param import AuditConfigParam
from .audit_target_param import AuditTargetParam

__all__ = ["AuditJobConfigParam", "Config", "Target"]

Config: TypeAlias = Union[str, AuditConfigParam]

Target: TypeAlias = Union[str, AuditTargetParam]


class AuditJobConfigParam(TypedDict, total=False):
    config: Required[Config]
    """A reference to AuditConfig."""

    target: Required[Target]
    """A reference to AuditTarget."""
