=========
Changelog
=========

Version 0.7.0
=============

- Add product commands for listing and count


Version 0.3.0
=============

- Add store info command


Version 0.1.0
=============

- Initial Release.
