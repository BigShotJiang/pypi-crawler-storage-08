"""Pydantic-Model Widget."""

from streambricks.widgets.model_widget.main import (
    render_model_form,
    render_model_readonly,
)


__all__ = ["render_model_form", "render_model_readonly"]
