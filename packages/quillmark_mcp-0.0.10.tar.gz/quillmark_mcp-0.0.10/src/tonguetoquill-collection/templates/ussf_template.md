---
QUILL: usaf_memo
letterhead_title: DEPARTMENT OF THE AIR FORCE
letterhead_caption:
  - United States Space Force
  - Space Delta [X]
memo_for:
  - ORG/SYMBOL
  # - 2nd ORG/SYMBOL
memo_from:
  - ORG/SYMBOL
  - ORGANIZATION
  - Street Address
  - City St 12345-6789
subject: Comply without pain -- markdown to official memo
signature_block:
  - FIRST M. LAST, Rank, USSF
---

Write your paragraphs here. Separate them with two new lines.

- Use bullets to nest paragraphs.
  - Indent to go deeper.

You can also **bold**, _italicize_, `code`, ~strikethrough~,
and [link](https://example.com/) your text.

Less formatting. More lethality.
