from generic_request_signer.backend import BasicSettingsApiCredentialsBackend  # noqa F401
