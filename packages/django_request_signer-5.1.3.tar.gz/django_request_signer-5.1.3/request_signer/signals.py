import django.dispatch

successful_signed_request = django.dispatch.Signal("request")
