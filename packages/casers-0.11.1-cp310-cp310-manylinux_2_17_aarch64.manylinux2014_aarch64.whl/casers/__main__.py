from .cli.app import run

run()
