"""LlamaIndex Chunker."""

from docler.chunkers.llamaindex_chunker.chunker import LlamaIndexChunker

__all__ = ["LlamaIndexChunker"]
