"""MarkItDown provider package."""

from docler.converters.markitdown_provider.provider import MarkItDownConverter

__all__ = ["MarkItDownConverter"]
