Inherit this module in your l10n_xx_country_states Module and translate
the states names.
