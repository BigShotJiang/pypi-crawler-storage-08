This module allows to translate the country states names.
