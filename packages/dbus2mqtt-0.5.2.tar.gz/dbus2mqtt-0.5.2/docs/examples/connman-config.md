---
hide:
  - toc
---

# Connman (WIP)

Using dbus2mqtt, you can control you network configuration using connman through mqtt topics.

## Setup activities

Trying out this example

```bash
uv run dbus2mqtt --config docs/examples/connman-config.yaml
```

## Features

This configuration is a passthrough of the D-BUS architecture of connman. refer to connman D-BUS API.
