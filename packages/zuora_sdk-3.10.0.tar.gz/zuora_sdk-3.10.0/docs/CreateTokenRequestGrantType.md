# CreateTokenRequestGrantType

The OAuth grant type that will be used to generate the token. The value of this parameter must be `client_credentials`. 

## Enum

* `CLIENT_CREDENTIALS` (value: `'client_credentials'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


