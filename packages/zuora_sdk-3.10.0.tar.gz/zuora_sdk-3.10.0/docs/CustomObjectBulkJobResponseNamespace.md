# CustomObjectBulkJobResponseNamespace

The namespace of the object. Custom objects belong to the `default` namespace. Zuora standard objects belong to the `com_zuora` namespace. Bulk job operations on the following Zuora standard objects are supported: * SavedQuery 

## Enum

* `DEFAULT` (value: `'default'`)

* `COM_ZUORA` (value: `'com_zuora'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


