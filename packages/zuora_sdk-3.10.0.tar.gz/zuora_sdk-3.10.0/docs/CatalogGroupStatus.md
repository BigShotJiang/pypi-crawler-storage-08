# CatalogGroupStatus

The status of the product rate plan. 

## Enum

* `ACTIVE` (value: `'Active'`)

* `EXPIRED` (value: `'Expired'`)

* `NOTSTARTED` (value: `'NotStarted'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


