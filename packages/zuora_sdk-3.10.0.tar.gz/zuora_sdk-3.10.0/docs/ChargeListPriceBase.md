# ChargeListPriceBase


## Enum

* `PER_BILLING_PERIOD` (value: `'Per_Billing_Period'`)

* `PER_MONTH` (value: `'Per_Month'`)

* `PER_WEEK` (value: `'Per_Week'`)

* `PER_YEAR` (value: `'Per_Year'`)

* `PER_SPECIFIC_MONTHS` (value: `'Per_Specific_Months'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


