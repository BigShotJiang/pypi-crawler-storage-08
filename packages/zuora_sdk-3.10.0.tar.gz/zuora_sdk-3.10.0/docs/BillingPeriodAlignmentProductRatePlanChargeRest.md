# BillingPeriodAlignmentProductRatePlanChargeRest

Aligns charges within the same subscription if multiple charges begin on different dates.

## Enum

* `ALIGNTOCHARGE` (value: `'AlignToCharge'`)

* `ALIGNTOSUBSCRIPTIONSTART` (value: `'AlignToSubscriptionStart'`)

* `ALIGNTOTERMSTART` (value: `'AlignToTermStart'`)

* `ALIGNTOTERMEND` (value: `'AlignToTermEnd'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


