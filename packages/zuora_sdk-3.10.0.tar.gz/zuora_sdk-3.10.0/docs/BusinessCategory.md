# BusinessCategory

Business Category of Customer Account E-Invoice Profile

## Enum

* `B2B` (value: `'B2B'`)

* `B2C` (value: `'B2C'`)

* `B2G` (value: `'B2G'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


