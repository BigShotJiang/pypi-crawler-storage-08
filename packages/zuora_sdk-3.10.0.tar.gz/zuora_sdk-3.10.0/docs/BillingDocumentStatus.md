# BillingDocumentStatus

The status of the billing document.

## Enum

* `DRAFT` (value: `'Draft'`)

* `POSTED` (value: `'Posted'`)

* `CANCELED` (value: `'Canceled'`)

* `CANCELINPROGRESS` (value: `'CancelInProgress'`)

* `GENERATING` (value: `'Generating'`)

* `PENDINGFORTAX` (value: `'PendingForTax'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


