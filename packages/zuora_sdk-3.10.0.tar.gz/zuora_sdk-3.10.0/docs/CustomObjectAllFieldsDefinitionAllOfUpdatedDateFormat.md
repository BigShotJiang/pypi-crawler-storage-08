# CustomObjectAllFieldsDefinitionAllOfUpdatedDateFormat

The field data format

## Enum

* `DATE_MINUS_TIME` (value: `'date-time'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


