# BillingDocumentItemSourceType


## Enum

* `SUBSCRIPTIONCOMPONENT` (value: `'SubscriptionComponent'`)

* `PRODUCTRATEPLANCHARGE` (value: `'ProductRatePlanCharge'`)

* `ORDERLINEITEM` (value: `'OrderLineItem'`)

* `INVOICEDETAIL` (value: `'InvoiceDetail'`)

* `CREDITMEMOITEM` (value: `'CreditMemoItem'`)

* `DEBITMEMOITEM` (value: `'DebitMemoItem'`)

* `ADJUSTMENT` (value: `'Adjustment'`)

* `ROUNDING` (value: `'Rounding'`)

* `NONE` (value: `'None'`)

* `SURCHARGE` (value: `'Surcharge'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


