# ChildrenSettingValueRequestMethod

One of the HTTP methods supported by the setting endpoint, for example, GET,Put,POST or Delete. 

## Enum

* `GET` (value: `'GET'`)

* `HEAD` (value: `'HEAD'`)

* `POST` (value: `'POST'`)

* `PUT` (value: `'PUT'`)

* `PATCH` (value: `'PATCH'`)

* `DELETE` (value: `'DELETE'`)

* `OPTIONS` (value: `'OPTIONS'`)

* `TRACE` (value: `'TRACE'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


