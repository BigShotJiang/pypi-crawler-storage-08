# CustomObjectRecordBatchActionType

The type of the batch action

## Enum

* `DELETE` (value: `'delete'`)

* `UPDATE` (value: `'update'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


