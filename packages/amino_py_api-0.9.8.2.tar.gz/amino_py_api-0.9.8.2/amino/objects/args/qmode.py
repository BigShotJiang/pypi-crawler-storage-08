
class QuizMode:
	"""
	Quiz modes

	attributes:
	
	- NormalMode
	- HellMode
	
	"""

	NormalMode: int = 0
	HellMode: int = 1