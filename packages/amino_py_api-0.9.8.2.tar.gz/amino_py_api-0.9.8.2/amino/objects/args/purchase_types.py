class PurchaseTypes:
	"""
	types of objects to purchase

	attributes:
	
	- Bubble
	- Frame
	
	"""

	Bubble: int = 116
	Frame: int = 122