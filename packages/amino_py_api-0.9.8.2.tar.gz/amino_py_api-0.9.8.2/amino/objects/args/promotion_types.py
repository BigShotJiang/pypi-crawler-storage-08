class PromotionTypes:
	"""
	promotion types

	attributes:
	
	- Accept
	- Deny
	
	"""

	Accept: str = "accept"
	Deny: str = "deny"