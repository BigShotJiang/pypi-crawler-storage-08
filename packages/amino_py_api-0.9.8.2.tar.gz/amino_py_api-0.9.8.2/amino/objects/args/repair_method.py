class RepairMethod:
	"""
	types of methods for repair

	attributes:
	
	- Coins
	- AminoPlus

	- all (list of all attributes)

	"""
	  
	Coins: str = "1"
	AminoPlus: str = "2"

	all: list = [Coins, AminoPlus]