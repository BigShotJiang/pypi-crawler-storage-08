class Sorting:
	"""
	sorting for functions

	attributes:
	
	- Newest
	- Oldest
	- Top

	- all (list of all attributes)

	"""
	  
	Newest: str = "newest"
	Oldest: str = "oldest"
	Top: str = "vote"

	all: list = [Newest, Oldest, Top]