class FeatureDays:
	"""
	days of consolidation (featured) of post

	attributes:
	
	- ONE_DAY
	- TWO_DAYS
	- THREE_DAYS
	"""

	ONE_DAY = 1
	TWO_DAYS = 2
	THREE_DAYS = 3