class ClientTypes:
    """
    Authorization client types
    
    attributes:
    - User

    """

    User: int = 100