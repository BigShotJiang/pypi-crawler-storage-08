class Sorting2:
	"""
	sorting chats and maybe something else

	attributes:
	
	- Recommended
	- Latest
	- Popular
	"""

	Recommended: str = "recommended"
	Latest: str = "latest"
	Popular: str = "popular"