class ChatTypes:
    """
    types of chats
    
    attributes:
    - User

    """
    Private: int = 0
    Group: int = 1
    Public: int = 2