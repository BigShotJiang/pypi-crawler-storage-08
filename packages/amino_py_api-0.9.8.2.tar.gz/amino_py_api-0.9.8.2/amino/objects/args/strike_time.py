class StrikeTime:
	"""
	reading mode time
	
	attributes:
	
	- ONE_HOUR
	- TWO_DAYS
	- THREE_DAYS
	"""

	ONE_HOUR = 1
	TWO_DAYS = 2
	THREE_DAYS = 3