from .logger import Logger, logging

log = Logger()