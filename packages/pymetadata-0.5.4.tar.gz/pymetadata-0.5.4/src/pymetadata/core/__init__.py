"""Core data structures."""
