Python MetzConnect Modbus TCP
==============================

TODO
