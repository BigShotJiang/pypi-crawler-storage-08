"""Entity Forge - Entity intelligence service"""

from entity_forge._version import __version__

__all__ = ["__version__"]
