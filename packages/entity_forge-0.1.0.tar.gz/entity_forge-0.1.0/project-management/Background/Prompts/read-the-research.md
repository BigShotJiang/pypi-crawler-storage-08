I've performed extensive research that I'd like you to read, understand, synthesize and then incorporate as part of our process.

Please read all of the documents in `project-management/Background/research/*` as part of our DESIGN phase.
