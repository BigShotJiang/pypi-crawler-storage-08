# All The Things

## Purpose and Vision

State of the Art (SOTA) Named Entity Recognition and Resolution.
