from .basic import Ingestor
__all__ = ["Ingestor"]
