"""FastStream - taskiq integration to schedule FastStream tasks."""

from importlib.metadata import version

__version__ = version("taskiq_faststream")
