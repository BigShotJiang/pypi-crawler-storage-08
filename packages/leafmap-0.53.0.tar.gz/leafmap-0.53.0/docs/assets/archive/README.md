# Credits

Credits to [Iban Ameztoy](https://twitter.com/i_ameztoy) for designing the first leafmap logo.

![logo](https://raw.githubusercontent.com/opengeos/leafmap/master/docs/assets/archive/logo.png)
