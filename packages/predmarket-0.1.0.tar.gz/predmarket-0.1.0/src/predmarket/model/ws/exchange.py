from abc import ABC


class BaseWebSocket(ABC): ...
