============
Installation
============

At the command line::

    pip install django-siruta
