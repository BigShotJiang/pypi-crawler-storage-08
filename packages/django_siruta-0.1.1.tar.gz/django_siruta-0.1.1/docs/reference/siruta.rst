siruta
======

.. testsetup::

    from siruta import *

.. automodule:: siruta
    :members:
    :undoc-members:
    :special-members: __init__, __len__
