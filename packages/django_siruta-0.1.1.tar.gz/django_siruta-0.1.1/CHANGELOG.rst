
Changelog
=========

0.1.1 (2025-10-10)
------------------

* First release on PyPI.
