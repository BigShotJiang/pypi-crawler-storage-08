from .regret import cumulative_regret

__all__ = ["cumulative_regret"]