from .classical.egreedy import EpsilonGreedy

__all__ = ["EpsilonGreedy"]