In the menu *Invoicing \> Configuration \> Settings*, check these
options:

- *XML Format embedded in PDF invoice*: if you want to generate Factur-X
  invoices, this option must be set to *Factur-X (CII)*
- the *Factur-X Level*: unless you have a good reason, you should keep
  the default value *EN 16931 (Comfort)*
- *Factur-X Refund Type*: choose the type of the XML invoice for
  customer refunds (keep the default value if you are not familiar with
  this setting).
