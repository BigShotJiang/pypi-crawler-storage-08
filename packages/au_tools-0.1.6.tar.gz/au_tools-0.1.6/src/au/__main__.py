from au.cli import main

main()
