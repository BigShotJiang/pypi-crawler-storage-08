# Core xNode functionality tests
