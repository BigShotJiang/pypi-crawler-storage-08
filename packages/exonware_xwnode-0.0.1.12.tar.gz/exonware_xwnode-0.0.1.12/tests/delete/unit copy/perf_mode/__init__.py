"""
Performance Mode Test Package
============================

This package contains comprehensive tests for xNode performance modes,
including the new ADAPTIVE mode and comparison tests.
"""

__version__ = '1.0.0'
__author__ = 'xNode Team'
