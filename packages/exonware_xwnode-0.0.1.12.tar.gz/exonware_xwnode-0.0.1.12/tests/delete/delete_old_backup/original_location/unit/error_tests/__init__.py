"""
xNode Error Tests
=================

Error handling and exception tests for XNode library.
"""

__version__ = "1.0.0" 