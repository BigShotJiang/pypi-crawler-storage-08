"""
xNode Core Tests
================

Core functionality tests for XNode facade and factory methods.
"""

__version__ = "1.0.0" 