.. include:: ../../README.rst

HGraph Documentation
====================


Contents
--------

.. toctree::
    :maxdepth: 1

    Home <self>
    getting_started
    quick_start/index
    programming_model/index
    concepts/index
    tools/index
    adaptors/index
    tutorial/index
    reference/index
    papers/index
    references
