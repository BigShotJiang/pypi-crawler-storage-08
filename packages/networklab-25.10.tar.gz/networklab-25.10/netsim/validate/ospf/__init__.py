OSPF_PREFIX_NAMES: dict = {
  'cost': 'cost',
  'rt'  : 'route type'
}