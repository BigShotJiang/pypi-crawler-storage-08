import { JupyterFrontEndPlugin } from '@jupyterlab/application';
/**
 * Initialization data for the my-extension extension.
 */
declare const plugin: JupyterFrontEndPlugin<void>;
export default plugin;
