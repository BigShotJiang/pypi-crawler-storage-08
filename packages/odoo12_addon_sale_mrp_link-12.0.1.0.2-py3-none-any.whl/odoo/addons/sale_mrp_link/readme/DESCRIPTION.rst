This module adds a link between the manufacturing orders and the associated sale order.
A button shown in the form view of sale orders allow the user to access to the related manufacturing orders.
