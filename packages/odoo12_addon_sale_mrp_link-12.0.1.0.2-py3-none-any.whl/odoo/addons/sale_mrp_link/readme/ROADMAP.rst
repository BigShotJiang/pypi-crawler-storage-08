The module is incompatible with the following modules:

* `sale_sourced_by_line <https://github.com/OCA/sale-workflow/tree/10.0/sale_sourced_by_line>`_
* `sale_stock_picking_blocking_proc_group_by_line <https://github.com/OCA/sale-workflow/tree/10.0/sale_stock_picking_blocking_proc_group_by_line>`_
* `sale_delivery_split_date <https://github.com/OCA/sale-workflow/tree/10.0/sale_delivery_split_date>`_
* `sale_quotation_sourcing <https://github.com/OCA/sale-workflow/blob/10.0/sale_quotation_sourcing>`_ (please note this latter is not migrated yet).

Please see https://github.com/OCA/sale-workflow/pull/661#discussion_r214031110 for further info.
