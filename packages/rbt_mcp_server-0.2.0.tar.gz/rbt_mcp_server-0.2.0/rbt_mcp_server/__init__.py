"""
RBT MCP Server - MCP tool for editing RBT documents.

@REQ: REQ-rbt-mcp-tool
@BP: BP-rbt-mcp-tool
"""

__version__ = "0.2.0"
