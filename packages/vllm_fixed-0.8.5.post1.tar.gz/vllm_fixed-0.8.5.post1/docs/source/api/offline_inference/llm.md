# LLM Class

```{eval-rst}
.. autoclass:: vllm.LLM
    :members:
    :show-inheritance:
```
