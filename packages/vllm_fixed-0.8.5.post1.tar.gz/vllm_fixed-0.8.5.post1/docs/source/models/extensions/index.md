# Built-in Extensions

:::{toctree}
:maxdepth: 1

runai_model_streamer
tensorizer
fastsafetensor
:::
