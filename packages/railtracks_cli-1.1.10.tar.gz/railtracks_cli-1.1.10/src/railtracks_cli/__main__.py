"""Entry point for railtracks CLI when run as a module"""

from railtracks_cli import main

if __name__ == "__main__":
    main()
