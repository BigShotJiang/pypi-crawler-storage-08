# SPDX-FileCopyrightText: 2024-2025 MTS PJSC
# SPDX-License-Identifier: Apache-2.0

from data_rentgen.services.uow import UnitOfWork

__all__ = ["UnitOfWork"]
