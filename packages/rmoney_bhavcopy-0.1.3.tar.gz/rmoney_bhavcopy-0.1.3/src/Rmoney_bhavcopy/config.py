conf = {
    "hostname" : "192.168.50.110",
    "database" : "Bhavcopy",
    "username" : "postgres",
    "pwd" : "Quant@123",
    "port" : 5432
}