"""Tool for finding removed features in your Django project"""

__version__ = "1.1.0"
