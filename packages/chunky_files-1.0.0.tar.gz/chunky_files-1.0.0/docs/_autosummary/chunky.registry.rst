chunky.registry
===============

.. automodule:: chunky.registry

   
   .. rubric:: Classes

   .. autosummary::
   
      ChunkerRegistry
   