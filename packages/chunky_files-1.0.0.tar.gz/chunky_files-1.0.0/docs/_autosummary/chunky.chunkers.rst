chunky.chunkers
===============

.. automodule:: chunky.chunkers

   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   fallback
