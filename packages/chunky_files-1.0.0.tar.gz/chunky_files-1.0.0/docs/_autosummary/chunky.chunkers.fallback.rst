chunky.chunkers.fallback
========================

.. automodule:: chunky.chunkers.fallback

   
   .. rubric:: Classes

   .. autosummary::
   
      SlidingWindowChunker
   