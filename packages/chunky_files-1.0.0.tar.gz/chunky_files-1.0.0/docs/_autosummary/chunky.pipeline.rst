chunky.pipeline
===============

.. automodule:: chunky.pipeline

   
   .. rubric:: Classes

   .. autosummary::
   
      ChunkPipeline
   