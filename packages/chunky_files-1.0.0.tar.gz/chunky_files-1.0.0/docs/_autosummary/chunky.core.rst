chunky.core
===========

.. automodule:: chunky.core

   
   .. rubric:: Classes

   .. autosummary::
   
      Chunker
   
   .. rubric:: Exceptions

   .. autosummary::
   
      ChunkingError
   