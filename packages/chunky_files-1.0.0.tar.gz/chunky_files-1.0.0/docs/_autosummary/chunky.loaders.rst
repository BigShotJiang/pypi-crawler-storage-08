chunky.loaders
==============

.. automodule:: chunky.loaders

   
   .. rubric:: Classes

   .. autosummary::
   
      DocumentLoader
      FileSystemLoader
   