chunky.types
============

.. automodule:: chunky.types

   
   .. rubric:: Classes

   .. autosummary::
   
      Chunk
      ChunkerConfig
      Document
   