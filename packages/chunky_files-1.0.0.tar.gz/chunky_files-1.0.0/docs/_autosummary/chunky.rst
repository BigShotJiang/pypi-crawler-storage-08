﻿chunky
======

.. automodule:: chunky

   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   chunkers
   core
   loaders
   pipeline
   registry
   types
