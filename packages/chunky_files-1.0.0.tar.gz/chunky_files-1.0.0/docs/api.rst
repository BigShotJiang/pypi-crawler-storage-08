API Reference
=============

.. autosummary::
   :toctree: _autosummary
   :caption: Public API
   :recursive:

   chunky
