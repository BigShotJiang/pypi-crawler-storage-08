"""IMF Static Assets."""
