class MissingEssentialProp(Exception):
  pass