eegdash.dataset.registry module
===============================

.. automodule:: eegdash.dataset.registry
   :members:
   :show-inheritance:
   :undoc-members:
