eegdash.features.feature\_bank.signal module
============================================

.. automodule:: eegdash.features.feature_bank.signal
   :members:
   :show-inheritance:
   :undoc-members:
