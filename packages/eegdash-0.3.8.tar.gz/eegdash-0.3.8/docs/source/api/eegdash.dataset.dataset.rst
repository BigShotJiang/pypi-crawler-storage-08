eegdash.dataset.dataset module
==============================

.. automodule:: eegdash.dataset.dataset
   :members:
   :show-inheritance:
   :undoc-members:
