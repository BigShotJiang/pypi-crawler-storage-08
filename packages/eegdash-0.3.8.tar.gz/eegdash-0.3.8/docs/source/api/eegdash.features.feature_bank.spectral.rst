eegdash.features.feature\_bank.spectral module
==============================================

.. automodule:: eegdash.features.feature_bank.spectral
   :members:
   :show-inheritance:
   :undoc-members:
