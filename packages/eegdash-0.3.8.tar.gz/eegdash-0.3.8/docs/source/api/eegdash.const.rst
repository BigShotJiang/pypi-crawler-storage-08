eegdash.const module
====================

.. automodule:: eegdash.const
   :members:
   :show-inheritance:
   :undoc-members:
