class WrongParameterFormat(Exception):
    pass
