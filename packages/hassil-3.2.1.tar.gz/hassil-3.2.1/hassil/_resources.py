"""Shared access to package resources"""

import importlib.metadata

__version__ = importlib.metadata.version("hassil")
