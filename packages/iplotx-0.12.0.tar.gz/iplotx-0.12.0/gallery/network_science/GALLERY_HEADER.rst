Network science
+++++++++++++++
The following examples show the capabilities of ``iplotx`` for visualizing general networks.
