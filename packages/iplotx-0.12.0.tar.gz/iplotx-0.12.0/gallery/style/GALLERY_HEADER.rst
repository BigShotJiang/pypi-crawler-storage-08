Style
+++++
Examples showcasing various styling options for the visualization components.
