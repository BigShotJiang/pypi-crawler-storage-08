Basic
+++++
Introductory examples for simple plots.
