"""
iplotx version information module.
"""

__version__ = "0.12.0"
