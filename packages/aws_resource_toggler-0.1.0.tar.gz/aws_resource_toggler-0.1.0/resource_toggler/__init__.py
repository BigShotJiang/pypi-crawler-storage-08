from .manager import toggle_resources, lambda_handler
# Expose the main functions directly when the package is imported
