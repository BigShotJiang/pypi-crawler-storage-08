To configure this module, you need to:

* set **Discount on lines** group to be able to see discounts on the lines
