* Nicolas Mac Rouillon <@nicomacr>
* Juan José Scarafía <jjs@adhoc.com.ar>
* Alex Comba <alex.comba@agilebg.com>
* David Vidal <david.vidal@tecnativa.com>
* Simone Rubino <simone.rubino@agilebg.com>
* Jacques-Etienne Baudoux (BCIM sprl) <je@bcim.be>
* Lorenzo Battistini (`TAKOBI <https://takobi.online>`_)
* `Nextev Srl <https://www.nextev.it>`_
