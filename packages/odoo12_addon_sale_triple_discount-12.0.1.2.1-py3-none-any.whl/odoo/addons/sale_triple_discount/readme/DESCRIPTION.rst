This module allows to have three discounts on every sale order line.
