def test_func() -> bool:
    return True
