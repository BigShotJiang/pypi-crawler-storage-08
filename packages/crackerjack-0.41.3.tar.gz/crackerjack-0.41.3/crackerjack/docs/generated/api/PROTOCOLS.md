# Protocol Reference

This document describes all protocol interfaces used in the codebase.
