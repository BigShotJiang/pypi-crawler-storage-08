2.0.0 (2025-10-08)


### Features

- Drop python2 and Plone 5.x support. Mark as Plone 6 only @erral 

Changelog
=========

<!-- towncrier release notes start -->



2.0.0 (unreleased)
------------------

- Drop support for Python 2.7, 3.5, 3.6., 3.7.

- Drop support for Python 2.7, 3.5, 3.6., 3.7.

- Drop support for Python 2.7, 3.5, 3.6., 3.7.


1.4.2 (2024-05-06)
------------------

- Create wheels
  [erral]

1.4.1 (2024-05-06)
------------------

- add new supported python versions [Mikel Larreategi <mlarreategi@codesyntax.com>]

-  [Mikel Larreategi <mlarreategi@codesyntax.com>]

- [ci skip] [Mikel Larreategi <mlarreategi@codesyntax.com>]

  [erral]

1.4 (2024-05-06)
----------------

- Add additional methods to the utility
  [libargutxi]


1.3 (2021-10-25)
----------------

- Fix 'Connection Should not load state' errors, with a new strategy to obtain the settings in the utility.
  [erral]

1.2.1 (2020-07-14)
------------------

- Hide upgrade profile from install screen.
  [erral]


1.2 (2020-06-29)
----------------

- Add an option to let the administrator configure how should Campaign Monitor behave when unsubscribed users are subscribed again using the default form.
  [erral]


1.1 (2020-06-26)
----------------

- Allow passing the 'resubscribe' parameter when subscribing a user
  [erral]


1.0.2 (2020-06-25)
------------------

- Update classifiers: Plone 5.2 and python3.
  [erral]


1.0.1 (2020-06-25)
------------------

- Add eu and es translations.
  [erral]


1.0 (2020-02-24)
----------------

- Send name when subscribing user to a list if name is given.
  [erral]


1.0b1 (2019-07-11)
------------------

- Initial release.
  [erral]
