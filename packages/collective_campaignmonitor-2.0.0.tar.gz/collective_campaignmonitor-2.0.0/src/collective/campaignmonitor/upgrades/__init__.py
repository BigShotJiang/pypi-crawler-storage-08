import logging


logger = logging.getLogger("collective.campaignmonitor")
