from importlib import metadata

CLIENT_NAME = "rapidpro-python"
CLIENT_VERSION = metadata.version("rapidpro-python")
