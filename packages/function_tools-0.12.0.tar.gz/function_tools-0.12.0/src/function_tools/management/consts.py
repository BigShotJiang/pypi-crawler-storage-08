PARAMETERS_DIALOG_WINDOW = 'ParametersDialogWindow'
