Constants
=========

.. automodule:: beyond.constants
    :members: