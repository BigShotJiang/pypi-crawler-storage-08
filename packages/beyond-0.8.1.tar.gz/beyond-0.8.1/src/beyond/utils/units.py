# Distance
m = 1.0
km = 1000.0
cm = 0.01
AU = 149597870700.0
feet = 0.3048
inch = 0.0254
day = 86400
sideral_day = 86164.0905
