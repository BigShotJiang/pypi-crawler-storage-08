const e="5";typeof window<"u"&&(window.__svelte||(window.__svelte={v:new Set})).v.add(e);
