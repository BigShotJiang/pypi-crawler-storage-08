__version__ = "0.0.2"

from .talk import chat_with_file