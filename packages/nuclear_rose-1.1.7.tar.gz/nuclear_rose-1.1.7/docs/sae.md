# Scattering Amplitude Emulator

The Scattering Amplitude Emulator (SAE) is the primary user-facing class.
Minimally, all the user should have to do is (1) pick an Interaction, (2) choose
a set of parameter-space, training points, and (3) pick an $\ell_\max$. That's
it. There is no step... well, there's no step 4 at least.

::: rose.scattering_amplitude_emulator