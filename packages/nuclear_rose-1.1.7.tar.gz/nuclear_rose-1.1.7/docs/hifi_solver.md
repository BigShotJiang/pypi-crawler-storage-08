# High-Fidelity Solver

::: rose.schroedinger