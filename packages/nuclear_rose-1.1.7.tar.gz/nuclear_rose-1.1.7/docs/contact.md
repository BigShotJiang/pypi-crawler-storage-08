# Contact Information

Do you have a question? Did you find a bug? `rose` is hosted on
[GitHub](https://github.com/odell/rose), and we rely heavily on Issues and Pull
Requests. Feel free to contribute whatever feedback you're willing to share.