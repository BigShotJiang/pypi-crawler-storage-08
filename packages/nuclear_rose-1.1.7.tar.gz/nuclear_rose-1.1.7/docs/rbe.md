# Reduced-Basis Emulator

::: rose.reduced_basis_emulator