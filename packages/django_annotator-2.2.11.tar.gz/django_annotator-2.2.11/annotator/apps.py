from django.apps import AppConfig


class AnnotatorConfig(AppConfig):
    name = "annotator"
