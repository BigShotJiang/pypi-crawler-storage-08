class BaseError(Exception):
    pass


class MysqlError(BaseError):
    pass
