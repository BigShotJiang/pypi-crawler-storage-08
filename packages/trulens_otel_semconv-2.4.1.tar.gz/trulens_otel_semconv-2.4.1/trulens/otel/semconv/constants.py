TRULENS_INSTRUMENT_WRAPPER_FLAG = "__trulens_instrument_wrapper__"
TRULENS_APP_SPECIFIC_INSTRUMENT_WRAPPER_FLAG = (
    "__trulens_app_specific_instrument_wrapper__"
)
TRULENS_RECORD_ROOT_INSTRUMENT_WRAPPER_FLAG = (
    "__trulens_record_root_instrument_wrapper__"
)
TRULENS_SPAN_END_CALLBACKS = "__trulens_span_end_callbacks__"
