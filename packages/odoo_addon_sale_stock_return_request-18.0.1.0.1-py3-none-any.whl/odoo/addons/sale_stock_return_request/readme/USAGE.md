To use this module, you need to:

1.  Go to *Inventory \> Operations \> Return Request* and place a new
    return.
2.  Select the supplier and enter the location from where the stock will
    be returned.
3.  Choose wether or not the return must be refunded.
4.  Confirm the return to check if the return is possible.
5.  Validate the return to amend the Purchase Orders associated to the
    supplier.
