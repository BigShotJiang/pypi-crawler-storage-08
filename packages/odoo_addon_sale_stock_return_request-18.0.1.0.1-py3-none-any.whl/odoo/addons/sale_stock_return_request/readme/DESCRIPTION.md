This module extends stockreturn_request to be able to link the returns
to their corresponding purchase orders in the case of returns to
supplier as well as to be able to get the corresponding refunds.
