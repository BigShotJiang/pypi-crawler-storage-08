# @omlish-lite
"""
Basically the old asyncore system, which still has usecases over asyncio (such as single-threaded, forking code).
"""
