# @omlish-lite
"""
These are the 'core' lite modules. These generally have a 'full' equivalent, in which case standard code should prefer
that.
"""
