from .app import Ventricle

__app__ = [
    "Ventricle",
]