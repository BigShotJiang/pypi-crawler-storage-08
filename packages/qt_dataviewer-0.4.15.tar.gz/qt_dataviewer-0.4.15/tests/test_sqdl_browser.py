
from qt_dataviewer.sqdl import SqdlDataBrowser

browser = SqdlDataBrowser()
# browser = SqdlDataBrowser("MV-Shell Occupancy")
# browser = SqdlDataBrowser("LV-sixdot")

