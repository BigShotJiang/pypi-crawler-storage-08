class Runtime:
    def get_fns(self) -> dict: pass
