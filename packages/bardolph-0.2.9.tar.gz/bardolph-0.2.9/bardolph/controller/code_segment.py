class CodeSegment:
    def __init__(self):
        self._instructions = []


class Module:
    def __init__(self):
        self._segments = []
