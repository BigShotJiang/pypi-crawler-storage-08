class WebApp: pass
