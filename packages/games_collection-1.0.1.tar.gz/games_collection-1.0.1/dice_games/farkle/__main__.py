"""Entry point for Farkle game."""

from __future__ import annotations

from .cli import main

if __name__ == "__main__":
    main()
