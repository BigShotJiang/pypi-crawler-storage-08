"""Entry point for Sokoban."""

from __future__ import annotations

from .cli import main

if __name__ == "__main__":
    main()
