* Handle Timezone related to the default time
