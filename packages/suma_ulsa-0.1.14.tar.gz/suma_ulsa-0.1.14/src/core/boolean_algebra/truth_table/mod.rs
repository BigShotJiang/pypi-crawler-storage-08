mod truth_table;
pub use truth_table::{  TruthTable, DetailedTruthTable};  // REEXPORTADO