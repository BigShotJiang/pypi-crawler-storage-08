"""Test cases for shapes module."""
