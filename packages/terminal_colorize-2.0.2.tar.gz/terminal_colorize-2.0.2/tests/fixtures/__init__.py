"""Test fixtures and sample data for ColorTerm tests."""
