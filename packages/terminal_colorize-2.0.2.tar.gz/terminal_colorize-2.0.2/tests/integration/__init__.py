"""Integration tests for ColorTerm."""
