"""
Test suite for ColorTerminal library.
"""
