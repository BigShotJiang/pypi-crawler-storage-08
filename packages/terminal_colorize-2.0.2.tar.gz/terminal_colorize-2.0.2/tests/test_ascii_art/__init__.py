"""Tests for ASCII art module."""
