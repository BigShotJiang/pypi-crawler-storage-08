class Colors:
    WHITE: str = '\u001b[37m'
    RED: str = '\u001b[31m'
    YELLOW: str = '\u001b[33m'
    GREEN: str = '\u001b[32m'
    RESET: str = '\033[0m'
