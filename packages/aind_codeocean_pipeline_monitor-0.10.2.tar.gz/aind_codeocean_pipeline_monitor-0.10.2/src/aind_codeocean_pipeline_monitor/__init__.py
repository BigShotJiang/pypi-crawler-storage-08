"""Package to define and run a Code Ocean Pipeline Monitor"""

__version__ = "0.10.2"
