from ydata.profiling.model.description import BaseDescription

__all__ = ["BaseDescription"]
