from ydata.report.styles.html import StyleHTML

__all__ = ["StyleHTML"]
