from enum import Enum


class ReportStatus(Enum):
    OK = "ok"
    WARNING = "warning"
    FAILED = "failed"
