import os

RUNNING_ENV = os.environ.get("RUNNING_ENV", "LOCAL")
