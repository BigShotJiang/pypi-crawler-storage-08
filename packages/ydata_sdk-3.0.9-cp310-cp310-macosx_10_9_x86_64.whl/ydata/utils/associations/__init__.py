from ydata.utils.associations.association_matrix import association_matrix

__all__ = ["association_matrix"]
