"""Utility functions shared between YData modules."""
_SUPPORTED_DTYPES = ["int", "float", "string", "category", "bool"]
