from ydata.quality.outlier.projection.ica import ICA
from ydata.quality.outlier.projection.pca import PCA

__all__ = ["ICA", "PCA"]
