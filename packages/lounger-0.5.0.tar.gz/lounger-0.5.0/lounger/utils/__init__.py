"""
utils module
"""
from .cache import cache, memory_cache, disk_cache
from .dependence import dependent_func
