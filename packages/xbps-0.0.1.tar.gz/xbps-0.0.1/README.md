# xbps.py

Aspirationally, this will be bindings to `libxbps`, a utility library for interacting
with xbps repositories and packages, and a selection of useful scripts. Maybe it will
end up like that, who knows.
