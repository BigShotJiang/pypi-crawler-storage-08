# QtUI: A collection of UI libraries for pyqt (pyside)

## Description
QtUI is a collection of UI libraries for pyqt (pyside)

## Libraries
1. [dayu_widgets](https://github.com/phenom-films/dayu_widgets) is a UI components library for PySide, and is licensed under the MIT license