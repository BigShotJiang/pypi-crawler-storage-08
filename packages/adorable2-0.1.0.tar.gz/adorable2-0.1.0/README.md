# adorable 2

```python
from adorable.common import *

print(f"Hello {RED:dangerous} world")
```

> [!TIP]
> You can also embed variables in the string interpolation:
>
> ```python
> message = "Hello"
> f"{RED:{message}}"
> ```
