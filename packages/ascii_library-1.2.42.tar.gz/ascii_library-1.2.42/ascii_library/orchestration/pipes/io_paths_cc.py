ccc_version = "1.0.0"
step1_cc_index_meta_nodes = "nodes-meta"
step1_cc_index_nodes = "nodes"

step2_cc_edges = "edges"

step3_cc_graph = "graph"

step4_cc_graph_aggregated = "graph-aggregated-registered-domain"

step5_cc_tokenization = "tokenization"
step5_cc_frequency = "token-frequency"
step5_cc_models = "models"
step6_cc_cluster = "cluster-prediction"
