from .client import MinioClient as MinioClient
