"""Core functionality tests."""

