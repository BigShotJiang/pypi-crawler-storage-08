
  # Turing Machine Simulator UI

  This is a code bundle for Turing Machine Simulator UI. The original project is available at https://www.figma.com/design/LAmbewQmu2L9PAZc4Rdz7g/Turing-Machine-Simulator-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  