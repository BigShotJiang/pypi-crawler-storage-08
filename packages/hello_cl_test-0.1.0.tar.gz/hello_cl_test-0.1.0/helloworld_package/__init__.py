"""A simple Hello World package."""
__version__ = "0.1.0"

def test_print():
    """Print Hello World to the console."""
    print("Hello CL")