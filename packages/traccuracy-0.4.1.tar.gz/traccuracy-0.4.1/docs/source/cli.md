# CLI

```{eval-rst}
.. click:: traccuracy.cli:typer_click_object
   :prog: traccuracy
   :nested: full
```
