This module saves time by automatically managing product attribute values. 
When you add a new value to an attribute, it will also be automatically added in all product templates that have this attribute.

You can exclude specific product templates from this automatic update by enabling the **"Disable Attribute Autoupdate"** checkbox on the product template form.
