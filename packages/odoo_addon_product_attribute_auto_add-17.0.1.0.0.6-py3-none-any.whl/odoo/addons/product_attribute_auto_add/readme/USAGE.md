## To add a new attribute variant to products

- Go to Settings -> Products -> Variants -> Attributes
- Select an attribute record or create a new one
- Add new Value on the Attribute Values notebook tab 
- When a new attribute value is added, it will automatically be added to all products that have this attribute  
  (except those where **"Disable Attribute Autoupdate"** is enabled).

![](../static/img/usage.PNG)

