"""Utility modules for PDF Text Organizer."""
