"""PDF Text Organizer - A Vultus Serpentis demonstration application."""

__version__ = "1.0.0"
