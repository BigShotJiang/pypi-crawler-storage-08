"""UI components for PDF Text Organizer."""
