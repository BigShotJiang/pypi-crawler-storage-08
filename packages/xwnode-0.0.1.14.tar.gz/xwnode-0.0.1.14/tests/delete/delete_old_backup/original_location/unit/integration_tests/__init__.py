"""
xNode Integration Tests
=======================

Integration and end-to-end tests for XNode library.
"""

__version__ = "1.0.0" 