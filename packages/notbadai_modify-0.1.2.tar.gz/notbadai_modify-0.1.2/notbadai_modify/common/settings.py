LLM_PROVIDERS = [
    {
        'name': 'deepinfra',
        'base_url': 'https://api.deepinfra.com/v1/openai',
    },
    {
        'name': 'openrouter',
        'base_url': 'https://openrouter.ai/api/v1',
    }
]
