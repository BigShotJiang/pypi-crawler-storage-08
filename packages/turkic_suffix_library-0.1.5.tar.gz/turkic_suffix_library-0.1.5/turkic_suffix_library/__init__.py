from turkic_suffix_library.azeri import Azeri
from turkic_suffix_library.kazakh import Kazakh
from turkic_suffix_library.turkish import Turkish
from turkic_suffix_library.turkmen import Turkmen
from turkic_suffix_library.uzbek import Uzbek
