class OsTicketException(Exception):
    pass
