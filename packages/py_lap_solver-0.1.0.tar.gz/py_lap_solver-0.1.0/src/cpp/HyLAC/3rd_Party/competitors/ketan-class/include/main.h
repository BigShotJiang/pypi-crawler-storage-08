#pragma once
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <queue>
#include <float.h>
#include <ctime>
#include <map>
#include <algorithm>
#include <vector>
#include <cctype>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <random>
#include <stdlib.h>
#include <chrono>
#include "cuda_runtime.h"
#include "device_launch_parameters.h"
#include "cost_generator.h"

#include "culap.h"

using namespace std;