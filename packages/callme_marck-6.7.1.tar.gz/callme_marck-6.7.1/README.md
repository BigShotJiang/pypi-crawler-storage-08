# callme

Using it to test something.

Version 6.7.1 (final release with patch)

## Usage
```python
from callme import callme
print(callme())