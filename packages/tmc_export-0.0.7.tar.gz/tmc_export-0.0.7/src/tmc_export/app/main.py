#!/usr/bin/env python3
import sys 
import tmc_export
def main() -> None:
    sys.exit(tmc_export.main(sys.argv[1:]))

