When configuring AI OCA Bridge's record payload, add some of your previously created extra parameters.
