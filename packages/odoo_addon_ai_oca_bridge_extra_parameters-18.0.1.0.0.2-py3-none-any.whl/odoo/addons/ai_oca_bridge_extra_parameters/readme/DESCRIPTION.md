This module is used for adding extra parameters to the AI OCA Bridge's payloads
