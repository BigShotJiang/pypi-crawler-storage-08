# SPDX-FileCopyrightText: 2025-present Kaburi <specialemail90@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.11"
