from sqlalchemy.orm import Mapped, mapped_column

M = Mapped
mc = mapped_column