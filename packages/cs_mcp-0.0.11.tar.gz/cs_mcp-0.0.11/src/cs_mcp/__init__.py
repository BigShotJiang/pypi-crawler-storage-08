from cs_mcp.server import run_mcp


def main():
    run_mcp()


if __name__ == "__main__":
    main()
