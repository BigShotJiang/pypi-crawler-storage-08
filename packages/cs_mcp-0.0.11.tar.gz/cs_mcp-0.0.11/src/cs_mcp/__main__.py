from . import main

main()