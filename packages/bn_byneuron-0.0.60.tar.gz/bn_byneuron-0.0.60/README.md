# Byneuron


## About
byneuron API tool that works via backend endpoints
Handles entities and eventdata.

## get started
provide environment variables, e.g. .ENV file in root with
-> BYNEURON_URL
-> KEYCLOAK_TOKEN_URL
-> OAUTH2_CLIENT_ID
-> OAUTH2_CLIENT_SECRET

