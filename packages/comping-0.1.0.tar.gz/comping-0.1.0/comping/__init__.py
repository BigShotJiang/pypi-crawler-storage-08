# comping/__init__.py
def hello_comping():
    print('Hello from comping concept drift python package!')
