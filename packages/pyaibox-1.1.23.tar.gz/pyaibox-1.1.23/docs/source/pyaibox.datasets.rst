pyaibox.datasets package
========================

Submodules
----------

pyaibox.datasets.mnist module
-----------------------------

.. automodule:: pyaibox.datasets.mnist
   :members:
   :show-inheritance:
   :undoc-members:

pyaibox.datasets.mstar module
-----------------------------

.. automodule:: pyaibox.datasets.mstar
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pyaibox.datasets
   :members:
   :show-inheritance:
   :undoc-members:
