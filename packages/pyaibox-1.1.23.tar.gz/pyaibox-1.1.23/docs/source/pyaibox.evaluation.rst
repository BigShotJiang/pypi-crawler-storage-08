pyaibox.evaluation package
==========================

Submodules
----------

pyaibox.evaluation.classification module
----------------------------------------

.. automodule:: pyaibox.evaluation.classification
   :members:
   :show-inheritance:
   :undoc-members:

pyaibox.evaluation.contrast module
----------------------------------

.. automodule:: pyaibox.evaluation.contrast
   :members:
   :show-inheritance:
   :undoc-members:

pyaibox.evaluation.detection\_voc module
----------------------------------------

.. automodule:: pyaibox.evaluation.detection_voc
   :members:
   :show-inheritance:
   :undoc-members:

pyaibox.evaluation.entropy module
---------------------------------

.. automodule:: pyaibox.evaluation.entropy
   :members:
   :show-inheritance:
   :undoc-members:

pyaibox.evaluation.error module
-------------------------------

.. automodule:: pyaibox.evaluation.error
   :members:
   :show-inheritance:
   :undoc-members:

pyaibox.evaluation.norm module
------------------------------

.. automodule:: pyaibox.evaluation.norm
   :members:
   :show-inheritance:
   :undoc-members:

pyaibox.evaluation.snrs module
------------------------------

.. automodule:: pyaibox.evaluation.snrs
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pyaibox.evaluation
   :members:
   :show-inheritance:
   :undoc-members:
