pyaibox
=======

.. toctree::
   :maxdepth: 4

   pyaibox
   setup
