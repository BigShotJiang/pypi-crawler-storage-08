setup module
============

.. automodule:: setup
   :members:
   :show-inheritance:
   :undoc-members:
