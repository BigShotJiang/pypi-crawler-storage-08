Get Started
============

Several links:

#. `pypi, pyaibox <https://pypi.org/project/pyaibox/>`_

#. `github, pyaibox <https://github.com/antsfamily/pyaibox/>`_

#. `document, pyaibox <https://iridescent.ink/pyaibox/>`_


Installation
-------------

The `pyaibox <https://pypi.org/project/pyaibox/>`_ package can be easily installed by ``pip install pyaibox``. After it is installed, just excute ``import pyaibox as pl`` to import the package.


