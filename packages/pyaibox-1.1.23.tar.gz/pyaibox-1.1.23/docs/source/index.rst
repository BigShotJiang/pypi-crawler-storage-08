.. pyaibox documentation master file, created by
   sphinx-quickstart on Sun Dec 16 21:41:00 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pyaibox's documentation!
======================================

.. toctree::
   :maxdepth: 6
   :caption: Contents:

   getstarted
   modules


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
