# pyaibox

A Python Toolbox.

You can install and test ``pyaibox`` by:

```bash
pip install pyaibox
import pyaibox as pb
print(pb.__version__)
```

Please see [pyaibox's documentation](http://iridescent.ink/pyaibox) for using details.
