# Sand Box / 沙盒

相关功能将于 v2.1.0系列上新，届时将通过沙盒的形式运行以Session为单位的Stata运行环境。

Related features will be introduced in the v2.1.0 series, which will run Stata runtime environments on a per-session basis through sandboxing.


