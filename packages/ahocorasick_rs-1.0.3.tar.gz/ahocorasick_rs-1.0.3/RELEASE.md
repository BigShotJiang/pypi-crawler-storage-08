# Release process

1. Update version in `Cargo.toml`.
2. `cargo check` to update `Cargo.lock`.
3. Commit and push.
4. Tag release in GitHub.
