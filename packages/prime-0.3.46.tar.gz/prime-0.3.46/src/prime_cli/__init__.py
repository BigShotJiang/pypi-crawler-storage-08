"""Prime Intellect CLI."""

# The version is the single source of truth for packaging metadata.
__version__ = "0.3.46"
