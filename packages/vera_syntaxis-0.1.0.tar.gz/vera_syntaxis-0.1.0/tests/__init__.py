"""Test suite for Vera Syntaxis."""
