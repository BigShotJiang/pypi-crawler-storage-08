"""Controller layer for Vera Syntaxis GUI."""

from vera_syntaxis.gui.controller.app_controller import AppController

__all__ = ['AppController']
