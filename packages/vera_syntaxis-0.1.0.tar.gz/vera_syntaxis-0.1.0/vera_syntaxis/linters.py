# This file is intentionally left blank. Its contents were moved to linter_base.py.
