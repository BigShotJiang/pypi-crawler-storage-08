"""Setup configuration for Vera Syntaxis."""
from setuptools import setup

# Configuration is in pyproject.toml
# This file exists for compatibility with older tools
setup()
