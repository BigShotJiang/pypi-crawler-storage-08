"""BLS Provider Static Assets."""
