module.exports = {
  arrowParens: 'always',
  bracketSameLine: false,
  bracketSpacing: false,
  endOfLine: 'lf',
  printWidth: 80,
  semi: true,
  singleAttributePerLine: false,
  singleQuote: true,
  tabWidth: 2,
  trailingComma: 'none',
  useTabs: false
};
