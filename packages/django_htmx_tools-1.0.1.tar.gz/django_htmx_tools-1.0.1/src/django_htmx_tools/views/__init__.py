from .mixins import IsHtmxRequestMixin

__all__ = ["IsHtmxRequestMixin"]
