from .estimateH import whittle, variogram, tdml
from .generators import fbm, arfima