// Copyright 2018-2023 Xanadu Quantum Technologies Inc.

// Licensed under the Apache License, Version 2.0 (the License);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at

// http://www.apache.org/licenses/LICENSE-2.0

// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an AS IS BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
#include <algorithm>
#include <complex>
#include <limits> // numeric_limits
#include <random>
#include <type_traits>
#include <vector>

#include <catch2/catch.hpp>

#include "LinearAlgebra.hpp" //randomUnitary
#include "StateVectorLQubitManaged.hpp"
#include "StateVectorLQubitRaw.hpp"
#include "TestHelpers.hpp" // createRandomStateVectorData
#include "TestHelpersWires.hpp"

/**
 * @file
 *  Tests for functionality:
 *      - defined in the intermediate base class StateVectorLQubit.
 *      - shared between all child classes.
 */

/// @cond DEV
namespace {
using namespace Pennylane::LightningQubit;
using Pennylane::Util::randomUnitary;
} // namespace
/// @endcond

TEMPLATE_TEST_CASE("StateVectorLQubit::Constructibility",
                   "[Default Constructibility]", StateVectorLQubitRaw<>,
                   StateVectorLQubitManaged<>) {
    SECTION("StateVectorBackend<>") {
        REQUIRE(!std::is_constructible_v<TestType>);
    }
}

TEMPLATE_PRODUCT_TEST_CASE("StateVectorLQubit::setBasisState",
                           "[setBasisState]",
                           (StateVectorLQubitManaged, StateVectorLQubitRaw),
                           (float, double)) {
    using StateVectorT = TestType;
    using ComplexT = typename StateVectorT::ComplexT;

    SECTION("setBasisState") {
        const ComplexT one{1.0};
        const ComplexT zero{0.0};

        std::vector<ComplexT> init_state_zeros = {zero, zero, zero, zero,
                                                  zero, zero, zero, zero};
        std::vector<ComplexT> expected_state_000 = {one,  zero, zero, zero,
                                                    zero, zero, zero, zero};

        StateVectorT sv(init_state_zeros.data(), init_state_zeros.size());
        sv.setBasisState({0}, {0});
        REQUIRE(sv.getDataVector() == approx(expected_state_000));

        std::vector<ComplexT> expected_state_001 = {zero, one,  zero, zero,
                                                    zero, zero, zero, zero};
        sv.setBasisState({1}, {2});
        REQUIRE(sv.getDataVector() == approx(expected_state_001));

        std::vector<ComplexT> expected_state_010 = {zero, zero, one,  zero,
                                                    zero, zero, zero, zero};
        sv.setBasisState({1}, {1});
        REQUIRE(sv.getDataVector() == approx(expected_state_010));

        std::vector<ComplexT> expected_state_011 = {zero, zero, zero, one,
                                                    zero, zero, zero, zero};
        sv.setBasisState({1, 1}, {1, 2});
        REQUIRE(sv.getDataVector() == approx(expected_state_011));

        std::vector<ComplexT> expected_state_100 = {zero, zero, zero, zero,
                                                    one,  zero, zero, zero};
        sv.setBasisState({1}, {0});
        REQUIRE(sv.getDataVector() == approx(expected_state_100));

        std::vector<ComplexT> expected_state_101 = {zero, zero, zero, zero,
                                                    zero, one,  zero, zero};

        sv.setBasisState({1, 0, 1}, {0, 1, 2});
        REQUIRE(sv.getDataVector() == approx(expected_state_101));

        std::vector<ComplexT> expected_state_110 = {zero, zero, zero, zero,
                                                    zero, zero, one,  zero};
        sv.setBasisState({1, 1}, {0, 1});
        REQUIRE(sv.getDataVector() == approx(expected_state_110));

        std::vector<ComplexT> expected_state_111 = {zero, zero, zero, zero,
                                                    zero, zero, zero, one};
        sv.setBasisState({1, 1, 1}, {0, 1, 2});
        REQUIRE(sv.getDataVector() == approx(expected_state_111));
    }
}

TEMPLATE_PRODUCT_TEST_CASE("StateVectorLQubit::setStateVector",
                           "[setStateVector]",
                           (StateVectorLQubitManaged, StateVectorLQubitRaw),
                           (float, double)) {
    using StateVectorT = TestType;
    using ComplexT = typename StateVectorT::ComplexT;

    SECTION("setStateVector") {
        const ComplexT one{1.0};
        const ComplexT zero{0.0};

        std::vector<ComplexT> init_state_zeros = {zero, zero, zero, zero,
                                                  zero, zero, zero, zero};
        std::vector<ComplexT> expected_state_000 = {one,  zero, zero, zero,
                                                    zero, zero, zero, zero};

        StateVectorT sv(init_state_zeros.data(), init_state_zeros.size());
        sv.setStateVector({one, zero}, {0});
        REQUIRE(sv.getDataVector() == approx(expected_state_000));

        std::vector<ComplexT> expected_state_001 = {zero, one,  zero, zero,
                                                    zero, zero, zero, zero};
        sv.resetStateVector();
        sv.setStateVector({zero, one}, {2});
        REQUIRE(sv.getDataVector() == approx(expected_state_001));

        std::vector<ComplexT> expected_state_010 = {zero, zero, one,  zero,
                                                    zero, zero, zero, zero};

        sv.resetStateVector();
        sv.setStateVector({zero, one}, {1});
        REQUIRE(sv.getDataVector() == approx(expected_state_010));

        std::vector<ComplexT> expected_state_011 = {zero, zero, zero, one,
                                                    zero, zero, zero, zero};
        sv.resetStateVector();
        sv.setStateVector({zero, zero, zero, one}, {1, 2});
        REQUIRE(sv.getDataVector() == approx(expected_state_011));

        std::vector<ComplexT> expected_state_100 = {zero, zero, zero, zero,
                                                    one,  zero, zero, zero};
        sv.resetStateVector();
        sv.setStateVector({zero, one}, {0});
        REQUIRE(sv.getDataVector() == approx(expected_state_100));

        std::vector<ComplexT> expected_state_101 = {zero, zero, zero, zero,
                                                    zero, one,  zero, zero};
        sv.resetStateVector();
        sv.setStateVector({zero, zero, zero, one}, {0, 2});
        REQUIRE(sv.getDataVector() == approx(expected_state_101));

        std::vector<ComplexT> expected_state_110 = {zero, zero, zero, zero,
                                                    zero, zero, one,  zero};
        sv.resetStateVector();
        sv.setStateVector({zero, zero, zero, one}, {0, 1});
        REQUIRE(sv.getDataVector() == approx(expected_state_110));

        std::vector<ComplexT> expected_state_111 = {zero, zero, zero, zero,
                                                    zero, zero, zero, one};
        sv.resetStateVector();
        sv.setStateVector({zero, zero, zero, zero, zero, zero, zero, one},
                          {0, 1, 2});
        REQUIRE(sv.getDataVector() == approx(expected_state_111));
    }
}

TEMPLATE_PRODUCT_TEST_CASE("StateVectorLQubit::Constructibility",
                           "[General Constructibility]",
                           (StateVectorLQubitManaged, StateVectorLQubitRaw),
                           (float, double)) {
    using StateVectorT = TestType;
    using ComplexT = typename StateVectorT::ComplexT;

    SECTION("StateVectorBackend<TestType>") {
        REQUIRE(!std::is_constructible_v<StateVectorT>);
    }
    SECTION("StateVectorBackend<TestType> {ComplexT*, std::size_t}") {
        REQUIRE(std::is_constructible_v<StateVectorT, ComplexT *, std::size_t>);
    }
    SECTION("StateVectorBackend<TestType> {ComplexT*, std::size_t}: Fails if "
            "provided an inconsistent length.") {
        std::vector<ComplexT> st_data(14, 0.0);
        REQUIRE_THROWS_WITH(
            StateVectorT(st_data.data(), st_data.size()),
            Catch::Contains("The size of provided data must be a power of 2."));
    }
    SECTION(
        "StateVectorBackend<TestType> {const StateVectorBackend<TestType>&}") {
        REQUIRE(std::is_copy_constructible_v<StateVectorT>);
    }
    SECTION("StateVectorBackend<TestType> {StateVectorBackend<TestType>&&}") {
        REQUIRE(std::is_move_constructible_v<StateVectorT>);
    }
}

TEMPLATE_PRODUCT_TEST_CASE("StateVectorLQubit::applyMatrix with a std::vector",
                           "[applyMatrix]",
                           (StateVectorLQubitManaged, StateVectorLQubitRaw),
                           (float, double)) {
    using StateVectorT = TestType;
    using PrecisionT = typename StateVectorT::PrecisionT;
    using ComplexT = typename StateVectorT::ComplexT;
    using VectorT = TestVector<ComplexT>;
    std::mt19937_64 re{1337};

    SECTION("Test wrong matrix size") {
        std::vector<ComplexT> m(7, 0.0);
        const std::size_t num_qubits = 4;
        VectorT st_data =
            createRandomStateVectorData<PrecisionT>(re, num_qubits);

        StateVectorT state_vector(st_data.data(), st_data.size());
        REQUIRE_THROWS_WITH(
            state_vector.applyMatrix(m, {0, 1}),
            Catch::Contains(
                "The size of matrix does not match with the given"));
    }

    SECTION("Test wrong number of wires") {
        std::vector<ComplexT> m(8, 0.0);
        const std::size_t num_qubits = 4;
        VectorT st_data =
            createRandomStateVectorData<PrecisionT>(re, num_qubits);

        StateVectorT state_vector(st_data.data(), st_data.size());
        REQUIRE_THROWS_WITH(
            state_vector.applyMatrix(m, {0}),
            Catch::Contains(
                "The size of matrix does not match with the given"));
    }
}

TEMPLATE_PRODUCT_TEST_CASE("StateVectorLQubit::applyMatrix with a pointer",
                           "[applyMatrix]",
                           (StateVectorLQubitManaged, StateVectorLQubitRaw),
                           (float, double)) {
    using StateVectorT = TestType;
    using PrecisionT = typename StateVectorT::PrecisionT;
    using ComplexT = typename StateVectorT::ComplexT;
    using VectorT = TestVector<ComplexT>;
    std::mt19937_64 re{1337};

    SECTION("Test wrong matrix") {
        std::vector<ComplexT> m(8, 0.0);
        const std::size_t num_qubits = 4;
        VectorT st_data =
            createRandomStateVectorData<PrecisionT>(re, num_qubits);

        StateVectorT state_vector(st_data.data(), st_data.size());
        REQUIRE_THROWS_WITH(state_vector.applyMatrix(m.data(), {}),
                            Catch::Contains("must be larger than 0"));
    }
}

TEMPLATE_PRODUCT_TEST_CASE("StateVectorLQubit::applyOperations",
                           "[applyOperations invalid arguments]",
                           (StateVectorLQubitManaged, StateVectorLQubitRaw),
                           (float, double)) {
    using StateVectorT = TestType;
    using PrecisionT = typename StateVectorT::PrecisionT;
    using ComplexT = typename StateVectorT::ComplexT;
    using VectorT = TestVector<ComplexT>;
    std::mt19937_64 re{1337};

    SECTION("Test invalid arguments without parameters") {
        const std::size_t num_qubits = 4;
        VectorT st_data =
            createRandomStateVectorData<PrecisionT>(re, num_qubits);

        StateVectorT state_vector(st_data.data(), st_data.size());

        PL_REQUIRE_THROWS_MATCHES(
            state_vector.applyOperations({"PauliX", "PauliY"}, {{0}},
                                         {false, false}),
            LightningException,
            "must all be equal"); // invalid wires
        PL_REQUIRE_THROWS_MATCHES(
            state_vector.applyOperations({"PauliX", "PauliY"}, {{0}, {1}},
                                         {false}),
            LightningException, "must all be equal"); // invalid inverse
    }

    SECTION("Test invalid arguments with parameters") {
        const std::size_t num_qubits = 4;

        VectorT st_data =
            createRandomStateVectorData<PrecisionT>(re, num_qubits);

        StateVectorT state_vector(st_data.data(), st_data.size());

        PL_REQUIRE_THROWS_MATCHES(
            state_vector.applyOperations({"RX", "RY"}, {{0}}, {false, false},
                                         {{0.0}, {0.0}}),
            LightningException, "must all be equal"); // invalid wires

        PL_REQUIRE_THROWS_MATCHES(
            state_vector.applyOperations({"RX", "RY"}, {{0}, {1}}, {false},
                                         {{0.0}, {0.0}}),
            LightningException, "must all be equal"); // invalid wires

        PL_REQUIRE_THROWS_MATCHES(
            state_vector.applyOperations({"RX", "RY"}, {{0}, {1}},
                                         {false, false}, {{0.0}}),
            LightningException, "must all be equal"); // invalid parameters
    }
}

TEMPLATE_PRODUCT_TEST_CASE("StateVectorLQubit::collapse", "[StateVectorLQubit]",
                           (StateVectorLQubitManaged, StateVectorLQubitRaw),
                           (float, double)) {
    using StateVectorT = TestType;
    using PrecisionT = typename StateVectorT::PrecisionT;
    using ComplexT = typename StateVectorT::ComplexT;
    using TestVectorT = TestVector<ComplexT>;

    const std::size_t num_qubits = 3;

    SECTION("Collapse the state vector as after having measured one of the "
            "qubits.") {
        TestVectorT init_state = createPlusState<PrecisionT>(num_qubits);

        const ComplexT coef{0.5, PrecisionT{0.0}};
        const ComplexT zero{PrecisionT{0.0}, PrecisionT{0.0}};

        std::vector<std::vector<std::vector<ComplexT>>> expected_state = {
            {{coef, coef, coef, coef, zero, zero, zero, zero},
             {coef, coef, zero, zero, coef, coef, zero, zero},
             {coef, zero, coef, zero, coef, zero, coef, zero}},
            {{zero, zero, zero, zero, coef, coef, coef, coef},
             {zero, zero, coef, coef, zero, zero, coef, coef},
             {zero, coef, zero, coef, zero, coef, zero, coef}},
        };

        std::size_t wire = GENERATE(0, 1, 2);
        std::size_t branch = GENERATE(0, 1);
        StateVectorT sv(init_state.data(), init_state.size());
        sv.collapse(wire, branch);

        REQUIRE(sv.getDataVector() == approx(expected_state[branch][wire]));
    }
}

TEMPLATE_PRODUCT_TEST_CASE("StateVectorLQubit::normalize",
                           "[StateVectorLQubit]",
                           (StateVectorLQubitManaged, StateVectorLQubitRaw),
                           (float, double)) {
    using StateVectorT = TestType;
    using PrecisionT = typename StateVectorT::PrecisionT;
    using ComplexT = typename StateVectorT::ComplexT;

    SECTION("Normalize state vector.") {
        const ComplexT init{1.0, PrecisionT{0.0}};
        const ComplexT half{0.5, PrecisionT{0.0}};
        const ComplexT zero{PrecisionT{0.0}, PrecisionT{0.0}};

        std::vector<ComplexT> init_state = {init, zero, init, init,
                                            zero, zero, init, zero};

        std::vector<ComplexT> expected_state = {half, zero, half, half,
                                                zero, zero, half, zero};

        StateVectorT sv(init_state.data(), init_state.size());
        sv.normalize();

        REQUIRE(sv.getDataVector() == approx(expected_state));
    }
}
