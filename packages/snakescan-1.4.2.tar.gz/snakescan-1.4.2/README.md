Scanner to scan port
import SnakeScan

and use module to scan port 

For full compatibility, I recommend using python 3.x.x

[*]added new check all port search:
 [$]Port--> --a 
 
[*]added new check all port using thread:
 [$]Port--> --t 
 
 [*]added new dos attack:
     
     [$]Host-->https://example.com --d
 [*]added new check you ip:
     
     --l and you need internet connection to use him
     
     added new help information
 
 