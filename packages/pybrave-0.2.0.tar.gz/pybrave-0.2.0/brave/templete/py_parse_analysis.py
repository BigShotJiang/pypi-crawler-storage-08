import json
import pandas as pd 
# def get_data(item):
#     content = item.content #json.loads(item.content)
#     return {
#         "sample_key":item.sample_key,
#         "fastq1":content['fastq1'],
#         "fastq2":content['fastq2'],
#     }

def get_db_field():
    return []


def parse_data(request_param,db_dict):
    # reads = db_dict['clean_reads']
    # samples = [get_data(item) for item in reads]
    # result = {
    #     "samples":samples,
    #     "genome_index":request_param['genome_index']
    # }
    return []
