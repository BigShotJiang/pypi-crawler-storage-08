class FrogmlCommandException(Exception):
    pass
