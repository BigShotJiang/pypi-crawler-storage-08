
Changelog
=========

2.0.0 (2020-07-02)
------------------

* First release on PyPI.
