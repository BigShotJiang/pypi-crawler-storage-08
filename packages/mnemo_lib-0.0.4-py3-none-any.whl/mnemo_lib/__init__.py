# -*- coding: utf-8 -*-

"""
A library to read MNemo Survey Tool Memory files
"""

__version__ = "0.0.4"
