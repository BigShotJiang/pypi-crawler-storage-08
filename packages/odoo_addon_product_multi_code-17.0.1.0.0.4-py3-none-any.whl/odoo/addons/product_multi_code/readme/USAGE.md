To use this module:

  1. Go to the Products menu.
  2. Open a product.
  3. You will see a new section for Internal References where you can add multiple codes.

The system will automatically link the internal code with the corresponding product and template.
If you try to add a duplicate internal reference, a validation error will be raised.
