class HamiltonianCircuitProxy(object):

    h = None
    J = None
    sampler = None
    embedding = None

    def __init__(self):
        self.h = None
        self.J = None
        self.sampler = None
        self.embedding = None