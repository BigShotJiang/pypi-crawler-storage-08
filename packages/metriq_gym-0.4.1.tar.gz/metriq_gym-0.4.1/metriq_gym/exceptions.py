class QBraidSetupError(Exception):
    pass
