def bf(a: bool) -> bool:
    return not a
