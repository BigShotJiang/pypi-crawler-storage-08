from typing import Iterable, Tuple


def ex(a):
    # type: (Iterable[str]) -> Tuple[str, ...]
    """Example typed package."""
    return list(a)
