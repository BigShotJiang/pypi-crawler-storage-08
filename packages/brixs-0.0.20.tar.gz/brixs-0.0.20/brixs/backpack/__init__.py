from .other import *
from .numanip import *
from .arraymanip import *
from .figmanip import *
from .filemanip import *
from .vectormanip import *
# from .xlsx import *