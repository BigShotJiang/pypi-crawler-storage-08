#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Template for data analysis of I21 data"""
# To do!