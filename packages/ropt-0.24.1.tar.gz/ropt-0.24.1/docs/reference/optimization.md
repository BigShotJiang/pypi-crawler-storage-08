::: ropt.optimization.EnsembleOptimizer
::: ropt.optimization.SignalEvaluationCallback
::: ropt.optimization.NestedOptimizerCallback
::: ropt.optimization.OptimizerCallback
::: ropt.optimization.OptimizerCallbackResult
