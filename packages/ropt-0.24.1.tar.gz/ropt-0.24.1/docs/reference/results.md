::: ropt.results
    options:
        members: []
::: ropt.results.Results
    options:
        members:
            - transform_from_optimizer
            - to_dataframe
::: ropt.results.ResultField
    options:
        members:
            - get_axes
::: ropt.results.FunctionResults
    options:
        members: []
::: ropt.results.GradientResults
    options:
        members: []
::: ropt.results.Functions
    options:
        members: []
::: ropt.results.Gradients
    options:
        members: []
::: ropt.results.FunctionEvaluations
    options:
        members: []
::: ropt.results.GradientEvaluations
    options:
        members: []
::: ropt.results.Realizations
    options:
        members: []
::: ropt.results.ConstraintInfo
    options:
        members: []
::: ropt.results.results_to_dataframe
