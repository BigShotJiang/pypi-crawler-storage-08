::: ropt.exceptions
    options:
        show_bases: true
        show_root_members_full_path: false
