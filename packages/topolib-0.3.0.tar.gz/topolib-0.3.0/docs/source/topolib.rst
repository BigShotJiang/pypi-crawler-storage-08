topolib package
===============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   topolib.analysis
   topolib.elements
   topolib.topology

Module contents
---------------

.. automodule:: topolib
   :members:
   :undoc-members:
   :show-inheritance:
