"""Constants for simulation module."""
