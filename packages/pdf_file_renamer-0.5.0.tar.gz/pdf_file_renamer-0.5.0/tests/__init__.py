"""Tests for PDF Renamer."""
