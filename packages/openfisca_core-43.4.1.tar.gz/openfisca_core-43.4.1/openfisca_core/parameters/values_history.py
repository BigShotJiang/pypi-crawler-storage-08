from .parameter import Parameter


class ValuesHistory(Parameter):
    """Only for backward compatibility."""
