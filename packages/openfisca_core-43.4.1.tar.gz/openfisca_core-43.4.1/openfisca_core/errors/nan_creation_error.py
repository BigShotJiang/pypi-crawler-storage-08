class NaNCreationError(Exception):
    """Simulation error."""
