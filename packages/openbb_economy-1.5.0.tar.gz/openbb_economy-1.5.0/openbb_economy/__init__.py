"""OpenBB Economy Extension."""
