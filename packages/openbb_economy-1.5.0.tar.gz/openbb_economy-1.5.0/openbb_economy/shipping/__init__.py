"""Economy shipping module."""
