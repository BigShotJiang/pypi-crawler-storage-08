# OpenBB Economy Extension

The Economy extension provides global macroeconomic data access for the OpenBB Platform.

## Installation

To install the extension, run the following command in this folder:

```bash
pip install openbb-economy
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
