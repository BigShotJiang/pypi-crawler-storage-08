from . import mpr

if __name__ == '__main__':
    mpr.main()
