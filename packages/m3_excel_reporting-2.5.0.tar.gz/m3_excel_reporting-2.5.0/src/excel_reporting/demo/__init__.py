#coding: utf-8
"""
File: __init__.py
Author: Rinat F Sabitov
Description: демонстрационный апп для генератора отчетов на основе apachePOI
"""

