"""
File: models.py
Author: Rinat F Sabitov
Description:
"""

