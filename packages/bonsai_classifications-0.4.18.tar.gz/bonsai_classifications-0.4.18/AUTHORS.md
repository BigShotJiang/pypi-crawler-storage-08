# Authors

## Contributors to this package
* Maik Budzinski (Aalborg University)
* Joao F. D. Rodrigues (2.-0 LCA consultants)
* Valentin Starlinger (2.-0 LCA consultants)
* Albert K. Osei-Owusu (Aalborg University)
* Mathieu Delpierre (2.-0 LCA consultants)
* Jonas Lindberg (2.-0 LCA consultants)
* Sander van Nielen (Aalborg University)
* Bertram F. de Boer (2.-0 LCA consultants)

## Getting The Data Right team
This package is part of the Getting The Data Right project. The full list of team members can be found [here](https://bonsamurais.gitlab.io/bonsai/documentation/miscellaneous/authors.html).

## Contact
Email [admin.gettingthedataright@aau.dk](mailto:admin.gettingthedataright@aau.dk) for enquiries.
