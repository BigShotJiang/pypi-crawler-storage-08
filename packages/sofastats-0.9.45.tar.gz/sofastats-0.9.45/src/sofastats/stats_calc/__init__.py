"""
Actual statistical algorithms or calculation of worked examples only
"""