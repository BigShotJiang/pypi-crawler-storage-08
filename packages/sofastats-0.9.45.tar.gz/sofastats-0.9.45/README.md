# sofastats

Statistics Open For All the Python Library.

A Python library for statistical analysis and reporting based on the
design of the SOFA Statistics package.
