from wisort.characters import app


__version__ = "0.1.0"
if __name__ == "__main__":
    app()
