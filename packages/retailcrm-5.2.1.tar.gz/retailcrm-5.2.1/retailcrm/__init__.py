# coding=utf-8

"""
Init
"""

from retailcrm.versions.v3 import Client as v3
from retailcrm.versions.v4 import Client as v4
from retailcrm.versions.v5 import Client as v5
