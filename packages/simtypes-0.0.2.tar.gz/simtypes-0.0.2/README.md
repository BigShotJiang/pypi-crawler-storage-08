![logo](https://raw.githubusercontent.com/pomponchik/simtypes/develop/docs/assets/logo_2.svg)

[![Downloads](https://static.pepy.tech/badge/simtypes/month)](https://pepy.tech/project/simtypes)
[![Downloads](https://static.pepy.tech/badge/simtypes)](https://pepy.tech/project/simtypes)
[![Coverage Status](https://coveralls.io/repos/github/pomponchik/simtypes/badge.svg?branch=main)](https://coveralls.io/github/pomponchik/simtypes?branch=main)
[![Lines of code](https://sloc.xyz/github/pomponchik/simtypes/?category=code)](https://github.com/boyter/scc/)
[![Hits-of-Code](https://hitsofcode.com/github/pomponchik/simtypes?branch=main)](https://hitsofcode.com/github/pomponchik/simtypes/view?branch=main)
[![Test-Package](https://github.com/pomponchik/simtypes/actions/workflows/tests_and_coverage.yml/badge.svg)](https://github.com/pomponchik/simtypes/actions/workflows/tests_and_coverage.yml)
[![Python versions](https://img.shields.io/pypi/pyversions/simtypes.svg)](https://pypi.python.org/pypi/simtypes)
[![PyPI version](https://badge.fury.io/py/simtypes.svg)](https://badge.fury.io/py/simtypes)
[![Checked with mypy](http://www.mypy-lang.org/static/mypy_badge.svg)](http://mypy-lang.org/)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![DeepWiki](https://deepwiki.com/badge.svg)](https://deepwiki.com/pomponchik/simtypes)


Python type checking tools are usually very complex. In this case, we have thrown out almost all the places where there is a lot of complexity, and left only the most obvious and necessary things for runtime.


## Table of contents

- [**Why?**](#why)
- [**Installation**](#installation)
- [**Usage**](#usage)


## Why?

It's been a long time since static type checking tools like [`mypy`](https://github.com/python/mypy) for `Python` have been available, and they've become very complex. The typing system has also become noticeably more complicated, providing us with more and more new types of annotations, new syntax and other tools. It seems that `Python` devs procrastinate endlessly, postponing all the really important [`CPyhton`](https://github.com/python/cpython) improvements in order to add more garbage to [`typing`](https://docs.python.org/3/library/typing.html).

A separate difficulty arises for those who try to use type annotations in runtime. Many data types make sense only in the context of static validation, and there is no way to verify these aspects in runtime. And some checks, although theoretically possible, would be extremely expensive. For example, to verify the validity of annotation `List[int]` in relation to a list, you would need to go through all its objects linearly to make sure that none of them violates the contract from the annotation.

So, why do we need this package? There is only one function where you can pass a type or a type annotation + a specific value, and you will find out if one corresponds to the other. That's it! You can use this feature as a support when creating runtime type checking tools, however, we do not offer these tools here. You decide for yourself whether to wrap this function in syntactic sugar like decorators with automatic type checking.

Also, we are not trying to cover the whole chasm of semantics that, for example, `mypy` can track. Our approach is to make type checking as stupid as possible. This is the only way to avoid the stupid typing games that complex tools impose on us.

What exactly does this library support:

- The basis of everything is the simplest type checking via [`isinstance`](https://docs.python.org/3/library/functions.html#isinstance). If you don't use any special types from [`typing`](https://docs.python.org/3/library/typing.html), expect direct type matching.
- [`Union`](https://docs.python.org/3/library/typing.html#typing.Union) support. You can combine the two types through a logical OR.
- Checking the [`Optional`](https://docs.python.org/3/library/typing.html#typing.Optional) type and `None` as an annotation.
- Using [`Any`](https://docs.python.org/3/library/typing.html#typing.Any) annotation.

And that's what's not here:

- Supports types with complex semantics from the [`typing`](https://docs.python.org/3/library/typing.html) module.
- Checking the contents of collections. Collections are checked only for the base type.
- Support for string annotations.

If you need more complex semantics, use static validation tools. If you need strange and expensive runtime checks that try to confuse static semantics by adding thousands of exceptions, use other runtime tools. Use this library if you need a MINIMUM.


## Installation

You can install [`simtypes`](https://pypi.python.org/pypi/simtypes) using pip:

```bash
pip install simtypes
```

You can also quickly try out this and other packages without having to install using [instld](https://github.com/pomponchik/instld).


## Usage

Import the `check` function:

```python
from simtypes import check
```

And pass there 2 arguments, a type or type annotation + value:

```python
print(check(int, 1))
#> True
print(check(str, 1))
#> False
print(check(Any, 1))
#> True
print(check(Any, 'kek'))
#> True
print(check(List, 1))
#> False
print(check(List, [1]))
#> True
print(check(List[int], [1]))
#> True
print(check(List[int], ['kek']))  # Attention! The tool does not check the contents of the list in runtime.
#> True
print(check(Optional[int], 1))
#> True
print(check(Optional[int], None))
#> True
print(check(Optional[str], 1))
#> False
print(check(None, 1))
#> False
print(check(None, None))
#> True
```

> ↑ As you can see, the function returns `True` or `False`, depending on whether the value matches its annotation.
