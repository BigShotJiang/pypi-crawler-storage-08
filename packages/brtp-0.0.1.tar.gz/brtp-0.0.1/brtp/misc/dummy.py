def dummy_fun(x: float) -> float:
    return x