# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

from .deepresearch_request_param import DeepresearchRequestParam

__all__ = ["DeepResearchCreateParams"]


class DeepResearchCreateParams(TypedDict, total=False):
    body: Required[DeepresearchRequestParam]
