# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

from .tool_request_param import ToolRequestParam

__all__ = ["ToolExecuteCodeParams"]


class ToolExecuteCodeParams(TypedDict, total=False):
    body: Required[ToolRequestParam]
