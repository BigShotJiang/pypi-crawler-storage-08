"""Tests for core functionality and utilities."""
