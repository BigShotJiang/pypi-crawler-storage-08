"""Tests for django-seo-audit package."""
