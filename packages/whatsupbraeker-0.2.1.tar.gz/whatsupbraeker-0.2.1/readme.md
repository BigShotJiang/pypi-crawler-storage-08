# What-s-up-braeker

Go-библиотека для работы с [WhatsApp](https://www.whatsapp.com/) через [`whatsmeow`](https://github.com/tulir/whatsmeow). Пакет предоставляет минимальный API, пригодный для собственных Go-приложений и для использования через `ctypes` в Python.

## Структура проекта
- `pkg/waclient` — основная логика соединения, отправки и получения сообщений.
- `cmd/wa-bridge` — точка сборки `c-shared`, экспортирующая функции `WaRun` и `WaFree`.
- `python/whatsapp_client.py` — удобный Python-клиент и CLI.
- `python/examples/` — готовые скрипты для отправки, логирования и автоответов.
- `examples/python/client.py` — низкоуровневый пример работы через `ctypes`.
- `main.go` — демонстрация использования пакета напрямую из Go.

## Использование в Go
```bash
go run ./main.go
```
Перед запуском задайте номер телефона и текст сообщения в `main.go`. При первой авторизации появится QR-код, который нужно отсканировать в WhatsApp.

Чтобы подключить библиотеку в другом проекте:
```go
import "github.com/Alias1177/What-s-up-braeker/pkg/waclient"
```

## Сборка динамической библиотеки
```bash
mkdir -p dist
go build -buildmode=c-shared -o dist/libwa.so ./cmd/wa-bridge
```
Команда создаст `dist/libwa.so` и заголовок `dist/libwa.h`. В средах с ограниченными правами на запись в глобальные кэши можно использовать локальные каталоги:
```bash
GOTOOLCHAIN=go1.24.0 \
GOMODCACHE=$PWD/.gomodcache \
GOCACHE=$PWD/.gocache \
go build -buildmode=c-shared -o dist/libwa.so ./cmd/wa-bridge
```

## Python Wrapper
The library can now be used from Python:
```python
from python.whatsapp_client import WhatsAppClient

client = WhatsAppClient(phone="79991234567")
response = client.send_message("79991234568", "Hello!")

if response.success:
    print(f"Sent! Message ID: {response.message_id}")
```

More details: [python/README.md](python/README.md)

## Требования
- Go 1.24+ (для зависимостей `whatsmeow`);
- база WhatsApp (`whatsapp.db`) рядом с бинарём;
- Python 3.8+ (для примера).

## Примечания
- В `pkg/waclient.Config` можно управлять тайм-аутами, логами и выводом QR.
- `WaRun` возвращает JSON c полями `success`, `message_id`, `messages`, `requires_qr` и `error`.
