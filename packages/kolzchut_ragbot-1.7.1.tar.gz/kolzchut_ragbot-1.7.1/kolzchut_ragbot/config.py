import os

EMBEDDING_INDEX = os.getenv("ES_EMBEDDING_INDEX", "embeddings")
MODELS_LOCATION = os.getenv("MODELS_LOCATION", "models")

