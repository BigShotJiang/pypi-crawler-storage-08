"""This module is the hello world example."""


def hello() -> str:
    """This returns the Hello World! greeting."""
    return "Hello World!"
