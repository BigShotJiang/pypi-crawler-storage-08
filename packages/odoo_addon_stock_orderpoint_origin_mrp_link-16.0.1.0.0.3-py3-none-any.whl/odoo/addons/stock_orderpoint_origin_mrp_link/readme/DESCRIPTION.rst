The Inventory Replenishment menu alows to choose a route and create orders to
replenish the needed quantities of a Product.

However the Purchase Orders created do not have the information
about the documents that generated that demand.
The Purchase Order "Origin" field will only
identify the replenishment/reorder rule that generated it.

This feature updates the Purchase Order "Origin" field with the documents
that generated the demand, generating the demand, such as Sales Orders or Manufacturing Orders.
This is done based on the information provided by the Forecast report.

This particular extension also adds the source demand Manufacturing Orders
to the Purchase Order smart button, allowing to navigate directly to them.
