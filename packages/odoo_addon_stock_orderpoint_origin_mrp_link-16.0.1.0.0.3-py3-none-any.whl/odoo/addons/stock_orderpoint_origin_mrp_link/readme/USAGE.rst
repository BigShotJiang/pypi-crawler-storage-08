- Create order from the Replenishment menu, for example, using the "Order Once" button.
- Verify the Origin field of the created orders. It should include the references to the
  orders generating this demand at the time of replenishment creation.
- If demand was generated from Manufacturing Orders, the "Manufacturin" smart button
  should be available.
