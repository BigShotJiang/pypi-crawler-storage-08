# OpenBB Financial Modeling Prep Provider

This extension integrates the [Financial Modeling Prep](https://site.financialmodelingprep.com/) data provider into the OpenBB Platform.

## Installation

To install the extension:

```bash
pip install openbb-fmp
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
