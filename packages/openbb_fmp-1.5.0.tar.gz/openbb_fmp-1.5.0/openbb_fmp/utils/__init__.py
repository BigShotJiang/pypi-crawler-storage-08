"""FMP utils."""
