from . import ir_model
from . import web_form_banner_rule
