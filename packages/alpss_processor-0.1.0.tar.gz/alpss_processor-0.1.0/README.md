the openmsistream dependency requires installing libsodium, a package used for its cryptographic functions.

Run the following shell command if you use conda/miniconda:

``conda install -c anaconda libsodium``