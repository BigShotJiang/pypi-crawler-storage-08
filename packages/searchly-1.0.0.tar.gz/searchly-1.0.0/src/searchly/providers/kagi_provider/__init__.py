"""Kagi API client."""
