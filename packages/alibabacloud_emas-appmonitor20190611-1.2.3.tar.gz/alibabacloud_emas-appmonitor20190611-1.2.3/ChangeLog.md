2025-08-07 Version: 1.2.2
- Update API GetError: add request parameters DigestHash.
- Update API GetError: add response parameters Body.Model.StructuredStack.
- Update API GetErrors: add response parameters Body.Model.Items.$.DigestHash.
- Update API GetIssue: add response parameters Body.Model.AllocSizeMax.
- Update API GetIssue: add response parameters Body.Model.AllocSizePct50.
- Update API GetIssue: add response parameters Body.Model.AllocSizePct70.
- Update API GetIssue: add response parameters Body.Model.AllocSizePct90.
- Update API GetIssue: add response parameters Body.Model.EventTime.
- Update API GetIssues: add response parameters Body.Model.Items.$.AllocSizeMax.
- Update API GetIssues: add response parameters Body.Model.Items.$.AllocSizePct50.
- Update API GetIssues: add response parameters Body.Model.Items.$.AllocSizePct70.
- Update API GetIssues: add response parameters Body.Model.Items.$.AllocSizePct90.


2025-06-09 Version: 1.2.1
- Update API GetSymbolicFiles: add request parameters BuildId.


2025-04-02 Version: 1.2.0
- Support API GetSymbolicFiles.
- Support API RequestUploadToken.
- Support API SubmitSymbolic.


2025-02-25 Version: 1.1.0
- Support API GetErrors.
- Support API GetIssue.
- Support API GetIssues.


2025-02-25 Version: 1.0.0
- Support API GetError.


