# squirrely/__init__.py
from .main import main
