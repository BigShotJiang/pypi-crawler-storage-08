VERSION = (0, 3, 2)

__version__ = ".".join(map(str, VERSION))  # noqa: F401
