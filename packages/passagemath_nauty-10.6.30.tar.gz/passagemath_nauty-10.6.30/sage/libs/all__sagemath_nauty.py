# sage_setup: distribution = sagemath-nauty
