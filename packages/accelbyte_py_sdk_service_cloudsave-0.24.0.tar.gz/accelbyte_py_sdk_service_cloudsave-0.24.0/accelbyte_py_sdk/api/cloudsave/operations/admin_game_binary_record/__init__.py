# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Cloudsave Service."""

__version__ = "3.27.0"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .admin_delete_game_binar_3752d7 import AdminDeleteGameBinaryRecordV1
from .admin_get_game_binary_r_5df25c import AdminGetGameBinaryRecordV1
from .admin_list_game_binary__f439a9 import AdminListGameBinaryRecordsV1
from .admin_post_game_binary__ce9dc6 import AdminPostGameBinaryPresignedURLV1
from .admin_post_game_binary__ace069 import AdminPostGameBinaryRecordV1
from .admin_put_game_binary_r_47597f import AdminPutGameBinaryRecordV1
from .admin_put_game_binary_r_a490ed import AdminPutGameBinaryRecorMetadataV1
