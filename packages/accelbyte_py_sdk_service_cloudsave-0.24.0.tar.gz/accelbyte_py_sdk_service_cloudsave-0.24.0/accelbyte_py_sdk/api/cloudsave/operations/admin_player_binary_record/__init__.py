# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Cloudsave Service."""

__version__ = "3.27.0"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .admin_delete_player_bin_892eb5 import AdminDeletePlayerBinaryRecordV1
from .admin_get_player_binary_1076b9 import AdminGetPlayerBinaryRecordV1
from .admin_list_player_binar_e452ce import AdminListPlayerBinaryRecordsV1
from .admin_post_player_binar_f1a4e9 import AdminPostPlayerBinaryPresignedURLV1
from .admin_post_player_binar_e33f40 import AdminPostPlayerBinaryRecordV1
from .admin_put_player_binary_6424e4 import AdminPutPlayerBinaryRecordV1
from .admin_put_player_binary_bcf941 import AdminPutPlayerBinaryRecorMetadataV1
