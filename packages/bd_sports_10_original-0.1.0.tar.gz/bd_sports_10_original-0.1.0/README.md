# 🏏 BD Sports-10 Dataset

The **BD Sports-10 Dataset** is a comprehensive collection of **3,000 high-resolution videos (1920×1080 pixels at 30 frames per second)** showcasing **ten culturally and traditionally significant Bangladeshi sports**.

This dataset is designed to support research in **action recognition**, **cultural heritage preservation**, **sports video classification**, and **machine learning applications**.

---

## 📁 Dataset Structure

The dataset directory (`BD_Sports_10`) contains two main subfolders:

- **Annotation/** → Annotation files
- **Dataset/** → Video data categorized into 10 sports classes

Each class folder contains **300 videos**, ensuring a **balanced distribution** suitable for **supervised learning** and **deep learning** model benchmarking.

---

## 🏸 Sports Categories

The dataset includes the following **ten Bangladeshi indigenous sports**:

1. Hari Vanga
2. Joldanga
3. Kanamachi
4. Lathim
5. Morog Lorai
6. Toilakto Kolagach Arohon (Kolagach)
7. Nouka Baich
8. Kabaddi
9. Kho Kho
10. Lathi Khela

## 🎯 Research Applications

This dataset is designed to support:

- Human action recognition
- Cultural heritage preservation
- Bangladeshi Sports video classification
- Supervised learning tasks
- Deep learning model benchmarking

---

- **Original Version (1920×1080 pixels):** [Science Data Bank](https://doi.org/10.57760/sciencedb.24216)
- [![BD Sports-10 Dataset (1920×1080 Pixels, Original Version)](https://img.shields.io/badge/BD_Sports_10_Original_Version-1920x1080-green)](https://doi.org/10.57760/sciencedb.24216)

> 📜 The dataset is licensed under the **Creative Commons Attribution 4.0 International (CC BY 4.0)** license.  
> Proper citation is required when using or redistributing this dataset.

---

## 📜 Citation: BD Sports-10 Dataset (Original Dataset)

### Please cite the dataset if used:

- Wazih Ullah Tanzim, Syed Md. Minhaz Hossain, Niloy Barua Supta, et al. (2025). **“BD Sports-10 Dataset”**, V4. Science Data Bank. DOI: [10.57760/sciencedb.24216](https://doi.org/10.57760/sciencedb.24216)

---

## 🔖 APA Citation (Original Dataset):

- Tanzim, W. U., Hossain, S. M. M., Supta, N. B., & Shifatun Nur, S. (2025). BD Sports-10 Dataset (Version V4) [Data set]. https://doi.org/10.57760/sciencedb.24216

---

**BibTeX Citation:**

## 📚 BibTex Citation (Original Dataset):

```bibtex
@misc{Tanzim_BD_Sports-10_Dataset_2025,
  author = {Tanzim, Wazih Ullah and Hossain, Syed Md. Minhaz and Supta, Niloy Barua and Shifatun Nur, Shifa},
  doi = {10.57760/sciencedb.24216},
  title = {{BD Sports-10 Dataset}},
  url = {https://doi.org/10.57760/sciencedb.24216},
  year = {2025}
}
```

## 📄 License

- **Dataset** → CC BY 4.0 (attribution required)
