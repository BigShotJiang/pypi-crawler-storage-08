"""gli4py - A Python library for GL.iNet routers"""
from .glinet import GLinet

if __name__ == "__main__":
    pass
