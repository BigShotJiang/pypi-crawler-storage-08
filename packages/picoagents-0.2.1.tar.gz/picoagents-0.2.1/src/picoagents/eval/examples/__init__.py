"""
Evaluation examples for picoagents.

This module contains example scripts demonstrating how to use the evaluation system.
"""
