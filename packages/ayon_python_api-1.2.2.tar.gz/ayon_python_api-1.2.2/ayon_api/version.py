"""Package declaring Python API for AYON server."""
__version__ = "1.2.2"
