import urnc.main

urnc.main.main()
