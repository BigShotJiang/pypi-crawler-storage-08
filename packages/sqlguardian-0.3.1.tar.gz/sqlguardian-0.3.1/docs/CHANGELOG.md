# CHANGELOG


## v0.3.1 (2025-10-09)

### Bug Fixes

- Ctes
  ([`153ee52`](https://github.com/MicaelJarniac/sqlguardian/commit/153ee5209ec500c43224eed57180d588a5724e88))


## v0.3.0 (2025-09-22)

### Features

- Disable guard per table
  ([`26a8d63`](https://github.com/MicaelJarniac/sqlguardian/commit/26a8d63df731b0a058e384f10deaa624e0d31e2a))


## v0.2.1 (2025-09-22)

### Bug Fixes

- Ctes
  ([`c67881e`](https://github.com/MicaelJarniac/sqlguardian/commit/c67881e4502192ad28c715e6334d2f195c8eef6c))


## v0.2.0 (2025-09-19)

### Features

- Initial release
  ([`d6f256b`](https://github.com/MicaelJarniac/sqlguardian/commit/d6f256bec2be6dd59f3d788dbd6090bc1326c9bd))


## v0.1.0 (2025-09-18)

### Chores

- Cleanup
  ([`54e7cff`](https://github.com/MicaelJarniac/sqlguardian/commit/54e7cffd247fffdba58d13af8f9d332595b7869d))

### Features

- Initial release, still WIP
  ([`06055f4`](https://github.com/MicaelJarniac/sqlguardian/commit/06055f4b3a0ec925d44492d49748cc7fc9dc12a3))


## v0.0.0 (2025-09-17)
