"""Benchmarking for sqlguardian."""
