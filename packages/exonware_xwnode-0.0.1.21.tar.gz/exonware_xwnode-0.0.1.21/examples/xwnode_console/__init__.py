"""XWQuery Interactive Console - Demo and Testing Tool"""

__version__ = "0.0.1"

