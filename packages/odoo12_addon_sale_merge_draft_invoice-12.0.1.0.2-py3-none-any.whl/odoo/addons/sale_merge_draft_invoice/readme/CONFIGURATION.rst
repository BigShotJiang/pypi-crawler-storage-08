#. Go to 'Sales / Configuration / Settings'
#. In 'Quotations & Sales' go to 'Invoices' and activate the option 'Merge
   new invoices with existing draft ones'.
#. Go to 'Settings / Users / Groups' and assign to the group 'Change sale
   to invoice merge proposal' all the users that can have the possibility to
   activate/deactivate the option of merging the new invoice with existing
   draft ones.
