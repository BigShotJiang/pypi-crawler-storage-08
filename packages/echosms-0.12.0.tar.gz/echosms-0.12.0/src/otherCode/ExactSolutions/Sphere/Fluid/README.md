# Fluid-Filled Spheres

# Fluid-filled sphere code
Anderson_fluid.py is Python code for calculating the acoustic backscatter and target strength using [Anderson's 1950 paper](https://doi.org/10.1121/1.1906621).


