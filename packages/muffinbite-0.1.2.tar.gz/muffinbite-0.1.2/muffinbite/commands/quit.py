def quit():
    """
    Exit the MuffinBite
    """
    return exit(0)