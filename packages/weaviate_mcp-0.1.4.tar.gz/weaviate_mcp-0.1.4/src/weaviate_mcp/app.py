"""
Central application instance definition.
"""

from mcp.server.fastmcp import FastMCP

# Central FastMCP instance
mcp = FastMCP(name="weaviate-mcp")
