"""Weaviate MCP - Weaviate vector database integration for Model Context Protocol."""

__version__ = "0.1.0"
