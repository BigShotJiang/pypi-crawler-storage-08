# Define your opportunities helper methods here
