from django.test import TestCase

# Create your opportunities tests here.
