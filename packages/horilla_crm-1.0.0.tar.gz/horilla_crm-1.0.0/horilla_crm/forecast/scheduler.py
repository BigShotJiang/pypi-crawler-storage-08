# Define your forecasts scheduled tasks here
