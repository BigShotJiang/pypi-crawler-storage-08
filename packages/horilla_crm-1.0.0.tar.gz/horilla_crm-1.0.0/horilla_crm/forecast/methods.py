# Define your forecasts helper methods here
