from django.test import TestCase

# Create your forecasts tests here.
