from django.test import TestCase

# Create your accounts tests here.
