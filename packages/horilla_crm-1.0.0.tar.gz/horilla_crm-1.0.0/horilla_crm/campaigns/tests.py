from django.test import TestCase

# Create your campaigns tests here.
