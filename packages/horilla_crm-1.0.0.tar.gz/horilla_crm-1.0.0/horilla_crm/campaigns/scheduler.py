# Define your campaigns scheduled tasks here
