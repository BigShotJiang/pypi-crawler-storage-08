# Define your campaigns helper methods here
