# Define your contacts helper methods here
