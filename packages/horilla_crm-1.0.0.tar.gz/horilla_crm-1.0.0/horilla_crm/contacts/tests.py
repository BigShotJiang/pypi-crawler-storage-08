from django.test import TestCase

# Create your contacts tests here.
