from django.db.models.signals import pre_save, post_save
from django.dispatch import receiver

# Define your timeline signals here
