# Define your timeline helper methods here
