# Define your reports helper methods here
