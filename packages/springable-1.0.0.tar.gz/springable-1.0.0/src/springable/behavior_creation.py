from .gui.start_behavior_creation_app import start_behavior_creation


def start():
    print('GUI has started in a new window...')
    start_behavior_creation()