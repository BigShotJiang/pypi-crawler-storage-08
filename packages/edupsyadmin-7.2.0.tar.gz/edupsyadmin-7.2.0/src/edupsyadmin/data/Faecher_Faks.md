Pflichtfächer

- Pädagogik/Psychologie/Heilpädagogik
- Politik und Gesellschaft sowie Soziologie
- Mathematisch-naturwissenschaftliche Bildung
- Ökologie/Gesundheitspädagogik
- Recht und Organisation
- Literatur- und Medienpädagogik
- Englisch
- Deutsch
- Theologie/Religionspädagogik, nach Konfession
- Praxis- und Methodenlehre mit Gesprächsführung
- Kunst- und Werkpädagogik
- Musik- und Bewegungspädagogik
- Übungen
- Sozialpädagogische Praxis

Zusatzfach Mathematik

Prüfungsfächer

- Pädagogik/Psychologie/Heilpädagogik
- Literatur- und Medienpädagogik
- Theologie/Religionspädagogik, nach Konfession
