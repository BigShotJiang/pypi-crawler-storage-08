"""Main application entry point.

python -m edupsyadmin  ...

"""


def main() -> None:
    """Execute the application."""
    raise NotImplementedError


# Make the script executable.

if __name__ == "__main__":
    main()
