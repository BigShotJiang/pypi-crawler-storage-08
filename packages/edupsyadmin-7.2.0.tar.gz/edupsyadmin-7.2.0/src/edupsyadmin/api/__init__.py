"""Application commands common to all interfaces."""

from . import managers

__all__ = ("managers",)
