"""DeepSeek CLI package"""

from . import api
from . import cli
from . import config
from . import handlers
from . import utils

__version__ = "0.2.3"
