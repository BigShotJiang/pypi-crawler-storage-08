VERSION = "0.1.2"

from sevdesk.client import Client
