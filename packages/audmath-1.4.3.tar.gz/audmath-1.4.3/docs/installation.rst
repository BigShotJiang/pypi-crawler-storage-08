Installation
============

To install :mod:`audmath` run:

.. code-block:: bash

    $ pip install audmath

To interactively test it run:

.. code-block:: bash

    $ uvx --with audmath ipython


