audmath
=======

.. automodule:: audmath

.. autosummary::
    :toctree:
    :nosignatures:

    db
    duration_in_seconds
    inverse_db
    inverse_normal_distribution
    rms
    samples
    similarity
    window
