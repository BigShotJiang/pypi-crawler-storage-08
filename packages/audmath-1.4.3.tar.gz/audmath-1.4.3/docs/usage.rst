Usage
=====

Look at the modules API documentation at :mod:`audmath`
to find usage examples for all available functions.
