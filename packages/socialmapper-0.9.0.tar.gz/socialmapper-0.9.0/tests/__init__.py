"""SocialMapper test package."""
