#!/usr/bin/env python3
"""Configuration package for SocialMapper.

This package provides configuration utilities for the library.
"""

__all__ = []
