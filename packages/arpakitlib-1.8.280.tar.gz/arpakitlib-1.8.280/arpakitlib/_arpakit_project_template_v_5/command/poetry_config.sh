cd ..
poetry config --list