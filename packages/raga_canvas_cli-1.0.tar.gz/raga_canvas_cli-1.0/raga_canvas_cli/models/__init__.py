"""Data models for Raga Canvas CLI."""
