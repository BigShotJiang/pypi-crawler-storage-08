"""Operations module for Canvas CLI commands."""
