"""Raga Canvas CLI - Command line interface for Raga Canvas platform."""

__version__ = "0.1.0"
__author__ = "Raga AI"
__email__ = "support@raga.ai"
