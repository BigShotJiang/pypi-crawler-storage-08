from src.wsqlite3 import __main__
__main__.run()
