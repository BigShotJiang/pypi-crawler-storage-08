"""Tests for dql-core package."""
