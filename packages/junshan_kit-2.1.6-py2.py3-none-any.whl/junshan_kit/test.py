import DataProcessor


data_loader = DataProcessor.CSVToPandas()
data_loader.ccfd_kaggle()