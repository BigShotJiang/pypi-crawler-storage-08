from ragu.common.prompts.prompt_storage import (
    PromptTemplate,
    DEFAULT_PROMPT_TEMPLATES
)