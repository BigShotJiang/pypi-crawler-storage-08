# PLEASE DO NOT MODIFY THIS FILE MANUALLY.
# This file re-exports everything from the connector-sdk-types package for backwards compatibility.
# Any time someone changes the OpenAPI spec, this file needs to be regenerated.

from connector_sdk_types.generated.models.list_custom_attributes_schema_request import ListCustomAttributesSchemaRequest

__all__ = [
    "ListCustomAttributesSchemaRequest",
]
