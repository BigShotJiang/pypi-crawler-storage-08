"""
Backtesting module for MeridianAlgo.
"""

from .engine import BacktestEngine

__all__ = ['BacktestEngine']