class SchemaProcessingError(Exception):
    """Base exception for schema processing errors during parsing or analysis."""
