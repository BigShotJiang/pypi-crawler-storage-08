from peak.main import main

main()
