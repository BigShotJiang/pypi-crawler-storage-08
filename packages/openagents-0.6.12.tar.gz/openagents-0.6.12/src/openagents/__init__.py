"""OpenAgents - AI Agent Networks for Open Collaboration."""

__version__ = "0.6.12"
