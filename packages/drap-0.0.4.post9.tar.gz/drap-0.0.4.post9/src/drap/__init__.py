drap = "drap.main:main"

__version__ = "0.1.0"
