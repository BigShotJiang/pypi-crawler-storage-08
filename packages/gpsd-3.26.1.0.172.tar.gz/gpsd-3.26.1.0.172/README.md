# Pessimus GPS

WARNING: Any files at GitLab, GitHub, or other providers are not official
        release files. The releases only occur at PyPI, similar to GPSDs
        releases only at savannah.

## General

This module is a Fork of GPSds 'gps' python module for installs not blessed
by GPSD. It includes some clients interacting with GPSD.

## Resources and Support

There are none; deal with it. In particular, DON'T clog the GPSD community
support asking for help with this.

## Credit

The credit belongs to all the people who worked on GPSD; Gary E Miller, Eric S
Raymond, Chris Keuthe, Brook Milligan, Russ Nelson, Remco Treffkorn,
Timo Ylhainen, Carl Carter, Ville Nuorvala, Amaury Jacquot, Curt Mills,
Derrick J. Brashear, Bob Lorenzini, Carsten Tschach, and too many other
people to list.

## LICENSE

This parent software (GPSD) releases under the terms and conditions of the
BSD License, including a copy in the file gps/COPYING.

This parent software and its bits are Copyright 2013 by the GPSD project.

I see no need to use another license.
