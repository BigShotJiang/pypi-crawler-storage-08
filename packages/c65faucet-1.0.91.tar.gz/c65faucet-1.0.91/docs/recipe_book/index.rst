Configuration Recipe Book
=========================

In this section we will cover some common network configurations and how you
would configure these with the Faucet YAML configuration format.

.. toctree::
   :maxdepth: 2

   forwarding
   routing
   policy
