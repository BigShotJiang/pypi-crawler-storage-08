Faucet Documentation
====================


Viewing documentation
---------------------

Docs are viewable on `docs.faucet.nz <http://docs.faucet.nz>`_.

Building documentation
----------------------

.. code:: console

  sudo apt-get install librsvg2-bin
  sudo pip3 install -r requirements.txt
  make html
