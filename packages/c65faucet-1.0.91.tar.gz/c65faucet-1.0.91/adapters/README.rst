Adapter Support
==================================

This directory is intended for community contributed adapters that sit
alongside FAUCET.
