import inspect
import io

import httpx
import pytest
from httpx_ws import aconnect_ws
from httpx_ws.transport import ASGIWebSocketTransport
from pydantic import BaseModel
from typing_extensions import Annotated

from kui.asgi import (
    Body,
    Cookie,
    Depends,
    Header,
    Kui,
    Path,
    Query,
    SocketView,
    UploadFile,
    auto_params,
    request,
    websocket,
)


@pytest.mark.asyncio
async def test_path():
    app = Kui()

    @app.router.http.get("/")
    @app.router.http.get("/{name}", name=None)
    @app.router.http.get("/{id:int}", name=None)
    async def path(name: Annotated[str, Path()]):
        return name

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://testserver"
    ) as client:
        resp = await client.get("/aber")
        assert resp.text == "aber"

        resp = await client.get("/")
        assert resp.status_code == 404

        resp = await client.get("/1")
        assert resp.status_code == 404

    assert not inspect.signature(app.router.search("http", "/aber")[1]).parameters


@pytest.mark.asyncio
async def test_query():
    app = Kui()

    @app.router.http.get("/")
    async def query(name: Annotated[str, Query(...)]):
        return name

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://testserver"
    ) as client:
        resp = await client.get("/", params={"name": "aber"})
        assert resp.text == "aber"

        resp = await client.get("/", params={})
        assert resp.status_code == 422

    assert not inspect.signature(app.router.search("http", "/")[1]).parameters


@pytest.mark.asyncio
async def test_header():
    app = Kui()

    @app.router.http.get("/")
    async def header(name: Annotated[str, Header(alias="Name")]):
        return name

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://testserver"
    ) as client:
        resp = await client.get("/", headers={"name": "aber"})
        assert resp.text == "aber"

        resp = await client.get("/", headers={"name0": "aber"})
        assert resp.status_code == 422

    assert not inspect.signature(app.router.search("http", "/")[1]).parameters


@pytest.mark.asyncio
async def test_cookie():
    app = Kui()

    @app.router.http.get("/")
    async def cookie(name: Annotated[str, Cookie()]):
        return name

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app),
        base_url="http://testserver",
        cookies={"name": "aber"},
    ) as client:
        resp = await client.get("/")
        assert resp.text == "aber"

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app),
        base_url="http://testserver",
        cookies={"name0": "aber"},
    ) as client:
        resp = await client.get("/")
        assert resp.status_code == 422

    assert not inspect.signature(app.router.search("http", "/")[1]).parameters


@pytest.mark.asyncio
async def test_body():
    app = Kui()

    @app.router.http.post("/")
    async def body(name: Annotated[str, Body()]):
        return name

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://testserver"
    ) as client:
        resp = await client.post("/", data={"name": "aber"})
        assert resp.text == "aber"

        resp = await client.post("/", data={"name0": "aber"})
        assert resp.status_code == 422

    assert not inspect.signature(app.router.search("http", "/")[1]).parameters

    @app.router.http.post("/exclusive")
    async def exclusive(name: Annotated[str, Body(exclusive=True)]):
        return name

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://testserver"
    ) as client:
        resp = await client.post("/exclusive", json="aber")
        assert resp.text == "aber"


@pytest.mark.asyncio
async def test_depend():
    app = Kui()

    def get_name(name: Annotated[str, Body(...)]):
        return name

    @app.router.http.post("/")
    async def homepage(name: Annotated[str, Depends(get_name)]):
        return name

    in_gen = False

    def gen(name: Annotated[str, Query(...)]):
        nonlocal in_gen
        in_gen = True
        try:
            yield name
        finally:
            in_gen = False

    @app.router.http.post("/gen")
    async def depend_gen(name: Annotated[str, Depends(gen)]):
        assert in_gen
        return name

    async def async_get_name(name: Annotated[str, Body(...)]):
        return name

    @app.router.http.post("/async/")
    async def depend_async(name: Annotated[str, Depends(async_get_name)]):
        return name

    async def async_gen(name: Annotated[str, Query(...)]):
        nonlocal in_gen
        in_gen = True
        try:
            yield name
        finally:
            in_gen = False

    @app.router.http.post("/async/gen")
    async def depend_async_gen(name: Annotated[str, Depends(async_gen)]):
        assert in_gen
        return name

    count = 0

    async def cached_get_name(name: Annotated[str, Body(...)]):
        nonlocal count
        count += 1
        return name

    @app.router.http.post("/cache/enable")
    async def cache_enable(
        name0: Annotated[str, Depends(cached_get_name, cache=True)],
        name1: Annotated[str, Depends(cached_get_name, cache=True)],
    ):
        assert name0 == name1
        return name0

    @app.router.http.post("/cache/disable")
    async def cache_disable(
        name0: Annotated[str, Depends(cached_get_name, cache=False)],
        name1: Annotated[str, Depends(cached_get_name, cache=False)],
    ):
        assert name0 == name1
        return name0

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://testserver"
    ) as client:
        resp = await client.post("/", json={"name": "aber"})
        assert resp.text == "aber"

        resp = await client.post("/gen", params={"name": "123"})
        assert resp.text == "123"
        assert not in_gen

        resp = await client.post("/async/", json={"name": "123"})
        assert resp.text == "123"

        resp = await client.post("/async/gen", params={"name": "123"})
        assert resp.text == "123"
        assert not in_gen

        resp = await client.post("/cache/enable", json={"name": "123"})
        assert resp.text == "123"
        assert count == 1

        resp = await client.post("/cache/disable", json={"name": "123"})
        assert resp.text == "123"
        assert count == 3


@pytest.mark.asyncio
async def test_middleware():
    app = Kui()

    def middleware(endpoint):
        async def middleware_wrapper(query: Annotated[str, Query(...)]):
            return await endpoint()

        return middleware_wrapper

    @app.router.http.get("/", middlewares=[middleware])
    async def cookie(name: Annotated[str, Cookie()]):
        return name

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app),
        base_url="http://testserver",
        cookies={"name": "aber"},
    ) as client:
        resp = await client.get("/")
        assert resp.status_code == 422

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app),
        base_url="http://testserver",
        cookies={"name": "aber"},
    ) as client:
        resp = await client.get("/?query=123")
        assert resp.text == "aber"

    assert not inspect.signature(app.router.search("http", "/")[1]).parameters


@pytest.mark.asyncio
async def test_upload_file():
    app = Kui()

    @app.router.http.post("/")
    async def upload_file(file: Annotated[UploadFile, Body(...)]):
        return {
            "filename": file.filename,
            "content": file.read().decode("utf8"),
        }

    async with httpx.AsyncClient(
        base_url="http://testserver", transport=httpx.ASGITransport(app=app)
    ) as client:
        resp = await client.post("/", files={"file": ("file", io.BytesIO(b"123"))})
        assert resp.json() == {"filename": "file", "content": "123"}

        resp = await client.post("/", files={"file0": io.BytesIO(b"123")})
        assert resp.status_code == 422


@pytest.mark.asyncio
async def test_parameters_nest_model():
    app = Kui()

    class User(BaseModel):
        name: str
        age: int

    @app.router.http.post("/")
    async def create_user(user: Annotated[User, Body(...)]):
        assert user.age >= 18
        return user

    async with httpx.AsyncClient(
        base_url="http://testserver", transport=httpx.ASGITransport(app=app)
    ) as client:
        resp = await client.post("/", json={"user": {"name": "aber", "age": 18}})
        assert resp.json() == {"name": "aber", "age": 18}

        resp = await client.post("/", json={"name": "aber", "age": 18})
        assert resp.status_code == 422


@pytest.mark.asyncio
async def test_auto_params():
    app = Kui()

    @app.router.http.get("/")
    async def index(name: Annotated[str, Query(...)]):
        return await tf()

    @auto_params
    async def tf(name: str = Query(...)):
        return name

    @app.router.http("/di")
    async def di(name: Annotated[str, Depends(tf)]):
        return name

    async with httpx.AsyncClient(
        base_url="http://testserver",
        transport=httpx.ASGITransport(app=app),  # type: ignore
    ) as client:
        resp = await client.get("/?name=123")
        assert resp.text == "123"

        resp = await client.get("/di?name=123")
        assert resp.text == "123"


@pytest.mark.asyncio
async def test_websocket():
    app = Kui()

    @app.router.websocket("/")
    class T(SocketView):
        def __init__(self, name: Annotated[str, Query(...)]):
            self.name = name

        async def on_receive(self, data) -> None:
            await websocket.send_text(self.name)

    async with httpx.AsyncClient(transport=ASGIWebSocketTransport(app=app)) as client:
        async with aconnect_ws("http://testserver/?name=kui", client=client) as client:
            await client.send_text("ping")
            assert await client.receive_text() == "kui"


@pytest.mark.asyncio
async def test_request_depends_cache():
    app = Kui()

    closed = False

    async def di():
        request.state["di"] = "start"
        yield
        request.state["di"] = "end"
        nonlocal closed
        closed = True

    @auto_params
    async def d(t: str = Depends(di)):
        assert request.state["di"] == "start"

    @app.router.http.get("/")
    async def index(t: Annotated[str, Depends(di)]):
        await d()
        assert request.state["di"] == "start"
        return b""

    async with httpx.AsyncClient(
        base_url="http://testserver",
        transport=httpx.ASGITransport(app=app),  # type: ignore
    ) as client:
        resp = await client.get("/")
        assert resp.text == ""
        assert closed


@pytest.mark.asyncio
async def test_request_depends_exception():
    app = Kui()

    closed = False

    async def di():
        request.state["di"] = "start"
        try:
            yield
        except NotImplementedError:
            request.state["di"] = "end"
            nonlocal closed
            closed = True
            raise

    @app.router.http.get("/")
    async def index(t: Annotated[str, Depends(di)]):
        raise NotImplementedError

    async with httpx.AsyncClient(
        base_url="http://testserver",
        transport=httpx.ASGITransport(app=app),  # type: ignore
    ) as client:
        with pytest.raises(NotImplementedError):
            await client.get("/")
        assert closed


@pytest.mark.asyncio
async def test_request_depends_cache_exception():
    app = Kui()

    closed = False

    async def di():
        request.state["di"] = "start"
        try:
            yield
        except NotImplementedError:
            request.state["di"] = "end"
            nonlocal closed
            closed = True
            raise

    @auto_params
    async def d(t: str = Depends(di)):
        assert request.state["di"] == "start"

    @app.router.http.get("/")
    async def index(t: Annotated[str, Depends(di, cache=True)]):
        raise NotImplementedError

    async with httpx.AsyncClient(
        base_url="http://testserver",
        transport=httpx.ASGITransport(app=app),  # type: ignore
    ) as client:
        with pytest.raises(NotImplementedError):
            await client.get("/")
        assert closed
