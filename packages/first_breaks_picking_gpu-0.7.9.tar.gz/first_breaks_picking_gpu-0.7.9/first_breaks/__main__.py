from first_breaks.desktop.main_gui import run_app

if __name__ == "__main__":
    run_app()
