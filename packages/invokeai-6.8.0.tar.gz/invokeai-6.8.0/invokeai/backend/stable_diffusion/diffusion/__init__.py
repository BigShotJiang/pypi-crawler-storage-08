"""
Initialization file for invokeai.models.diffusion
"""

from invokeai.backend.stable_diffusion.diffusion.shared_invokeai_diffusion import (
    InvokeAIDiffuserComponent,  # noqa: F401
)
