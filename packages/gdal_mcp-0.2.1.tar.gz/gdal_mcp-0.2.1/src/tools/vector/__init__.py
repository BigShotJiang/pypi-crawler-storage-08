"""Vector tools package."""
