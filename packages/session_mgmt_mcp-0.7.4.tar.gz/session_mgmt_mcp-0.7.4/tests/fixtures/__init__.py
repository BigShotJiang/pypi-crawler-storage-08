"""Test fixtures and data factories for session-mgmt-mcp testing."""
