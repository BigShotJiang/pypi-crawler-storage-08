def my_function(name: str) -> str:
    template = "Hi, my name is {name}! I'm using this package!"
    return template.format(name=name)
