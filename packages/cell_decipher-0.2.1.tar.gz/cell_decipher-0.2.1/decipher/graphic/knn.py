r"""
k-nearest neighbor searching
"""
from rui_utils.knn import knn  # noqa
