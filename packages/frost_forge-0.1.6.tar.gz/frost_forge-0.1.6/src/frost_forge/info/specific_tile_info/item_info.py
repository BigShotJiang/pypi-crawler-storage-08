FERTILIZER_SPAWN = (
    (0.002, "bluebell"),
    (0.005, "potato"),
    (0.01, "carrot"),
    (0.02, "spore"),
    (0.035, "sapling"),
)
FERTILIZER_EFFICIENCY = {
    "fertilizer": 20,
    "compost": 1,
}
FOOD = {
    "carrot": 2,
    "mushroom": 1,
    "mushroom stew": 6,
    "potato": 3,
    "rabbit meat": 1,
    "roasted mushroom": 3,
    "roasted rabbit meat": 4,
}
HEALTH_INCREASE = {"life crystal": (20, 40, 4)}
UNOBTAINABLE = {
    "big rock",
    "carroot",
    "coal ore",
    "corpse",
    "junk",
    "potatoo",
    "rabbit adult",
    "rabbit child",
    "slime",
    "tree",
    "treeling",
}
