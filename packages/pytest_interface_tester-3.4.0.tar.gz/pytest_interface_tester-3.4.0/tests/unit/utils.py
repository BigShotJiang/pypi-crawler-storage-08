from pathlib import Path

CRI_LIKE_PATH = Path(__file__).parent.parent / "resources" / "cri-like-path"
