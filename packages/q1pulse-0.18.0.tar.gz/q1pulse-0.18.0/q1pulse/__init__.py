__version__ = "0.18.0"

from .instrument import Q1Instrument, set_exception_on_overload
from .lang.math_expressions import Lsr as lsr

