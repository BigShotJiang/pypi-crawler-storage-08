#!/usr/bin/env python
"""
Normalize Jupyter notebooks
"""
import docutils as ut
ut.normalize_notebooks()
