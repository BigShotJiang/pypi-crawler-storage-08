#!/usr/bin/env python
"""
Remove auto-generated files
"""
import docutils as ut
ut.clean_outputs()