from .cholera       import *
from .ebola         import *
from .gonorrhea     import *
from .hiv           import *
from .measles       import *
from .syphilis      import *
