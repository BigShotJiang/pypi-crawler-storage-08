## To enable Auto-Create Product Variants

- Go to Settings -> Products -> Variants -> Attributes
- Select an attribute record or create a new one
- On the Attribute form view, enable the "Auto-Add Value to Product Templates" checkbox

## To exclude products from automatic attribute value updates

- Go to **Products → Products**
- Open the product template you want to exclude
- Enable the **"Disable Attribute Autoupdate"** checkbox
