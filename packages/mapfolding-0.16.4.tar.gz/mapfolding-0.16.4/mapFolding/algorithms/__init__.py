"""Hand-made algorithms."""
