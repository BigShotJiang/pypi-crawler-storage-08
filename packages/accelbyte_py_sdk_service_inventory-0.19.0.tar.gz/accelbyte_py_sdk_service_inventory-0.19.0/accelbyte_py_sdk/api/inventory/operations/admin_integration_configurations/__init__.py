# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Inventory Service."""

__version__ = "0.2.17"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .admin_create_integratio_c6b1bd import AdminCreateIntegrationConfiguration
from .admin_list_integration__420e8d import AdminListIntegrationConfigurations
from .admin_list_integration__420e8d import (
    SortByEnum as AdminListIntegrationConfigurationsSortByEnum,
)
from .admin_update_integratio_fe692f import AdminUpdateIntegrationConfiguration
from .admin_update_status_int_703321 import AdminUpdateStatusIntegrationConfiguration
