
from wofry.propagator.propagator import PropagationMode

class SRWPropagationMode(PropagationMode):
    STEP_BY_STEP_WOFRY = 2
