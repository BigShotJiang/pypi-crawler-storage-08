from artistools.nltepops import plotnltepops


def main() -> None:
    plotnltepops.main()


if __name__ == "__main__":
    main()
