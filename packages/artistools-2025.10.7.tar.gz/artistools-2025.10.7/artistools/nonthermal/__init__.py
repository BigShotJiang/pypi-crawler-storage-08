"""Artistools - spectra related functions."""

__all__ = ["solvespencerfanocmd"]

from artistools.nonthermal import solvespencerfanocmd as solvespencerfanocmd
from artistools.nonthermal.solvespencerfanocmd import addargs as addargs
from artistools.nonthermal.solvespencerfanocmd import main as main
