::: qcop.adapters.terachem.TeraChemAdapter

::: qcop.adapters.terachem_fe.TeraChemFEAdapter

::: qcop.adapters.terachem_pbs.TeraChemPBSAdapter
