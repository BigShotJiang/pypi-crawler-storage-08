```python
{!examples/single_point.py!}
```