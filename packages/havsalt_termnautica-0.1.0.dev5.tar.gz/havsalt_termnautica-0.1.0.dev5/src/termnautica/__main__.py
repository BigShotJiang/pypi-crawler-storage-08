import termnautica
import sys

sys.exit(termnautica.main())
