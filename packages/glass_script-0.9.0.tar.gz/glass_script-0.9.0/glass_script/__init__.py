from .main import GlassScript
