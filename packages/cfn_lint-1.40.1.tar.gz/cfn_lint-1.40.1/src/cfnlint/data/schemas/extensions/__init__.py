"""
Cfn-lint created JSON Schemas to extend validation of the registry provided schemas
"""
