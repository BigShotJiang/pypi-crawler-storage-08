"""
Patches applied to the schemas to support extenended cfn-lint schemas
"""
