"""
Geek Cafe Services - Base Reusable Services for SaaS

Version 0.2.0 adds Lambda Handler Wrappers for reducing boilerplate code.
"""
__version__ = "0.4.1"

# Import main modules for easier access
from . import services
