nestle
======

/ˈnesəl/ (rhymes with "wrestle")

Pure Python, MIT-licensed implementation of nested sampling algorithms for
evaluating Bayesian evidence.

[![Build Status](https://img.shields.io/travis/kbarbary/nestle.svg?style=flat-square)](https://travis-ci.org/kbarbary/nestle)
[![Coverage Status](http://img.shields.io/coveralls/kbarbary/nestle.svg?style=flat-square)](https://coveralls.io/r/kbarbary/nestle?branch=master)


Documentation
-------------

See http://kbarbary.github.io/nestle.
