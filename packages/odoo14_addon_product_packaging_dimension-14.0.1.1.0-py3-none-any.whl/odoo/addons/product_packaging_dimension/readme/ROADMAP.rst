* Resolve conflict with delivery module
