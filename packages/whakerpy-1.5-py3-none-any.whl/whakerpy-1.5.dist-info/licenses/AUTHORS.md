
-------------------------------------------------------------------------

WhakerPy
Copyright (C) 2023-2025 Brigitte Bigi, CNRS
Laboratoire Parole et Langage, Aix-en-Provence, France

-------------------------------------------------------------------------

See the accompanying LICENSE file for details.

A contributing author is a person or company who contributed code that
is now part of WhakerPy.

For the purpose of copyright and licensing, this is the official list
of contributing authors.

-------------------------------------------------------------------------

Main author, contributor, maintainer, developer:

    * 2023-: Brigitte Bigi - https://sppas.org/bigi/

Contributors:

    * april-june 2023: Florian Lopitaux
    * february-june 2024: Florian Lopitaux
