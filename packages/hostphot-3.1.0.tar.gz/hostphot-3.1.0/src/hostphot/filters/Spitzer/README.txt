# Filters taken from SVO: http://svo2.cab.inta-csic.es/svo/theory/fps3/index.php?id=Spitzer/IRAC.I1
IRAC.1 = 3.6 μm 
IRAC.2 = 4.5 μm 
IRAC.3 = 5.8 μm 
IRAC.4 = 8.0 μm
MIPS.1 = 24.0 μm
