Filters from SVO (Filter + Instrument + Atmosphere)
