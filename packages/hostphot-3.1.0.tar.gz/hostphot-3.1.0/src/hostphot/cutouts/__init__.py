# -*- coding: utf-8 -*-

from .downloads import download_images
from .hst import set_HST_image
from .jwst import set_JWST_image