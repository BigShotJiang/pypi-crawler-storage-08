from fabricks.cdc.base._types import ChangeDataCaptures
from fabricks.cdc.base.cdc import BaseCDC

__all__ = ["BaseCDC", "ChangeDataCaptures"]
