from typing import Literal

ChangeDataCaptures = Literal["nocdc", "scd1", "scd2"]
