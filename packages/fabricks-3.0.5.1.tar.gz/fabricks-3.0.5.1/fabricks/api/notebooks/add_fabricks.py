# Databricks notebook source
import os
import sys

# COMMAND ----------

root = os.path.abspath("../../..")

# COMMAND ----------

sys.path.append(root)

# COMMAND ----------
