import importlib.metadata

FABRICKS_VERSION = importlib.metadata.version("fabricks")
