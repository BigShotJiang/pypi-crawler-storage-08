from fabricks.core.views import create_or_replace_view, create_or_replace_views

__all__ = [
    "create_or_replace_view",
    "create_or_replace_views",
]
