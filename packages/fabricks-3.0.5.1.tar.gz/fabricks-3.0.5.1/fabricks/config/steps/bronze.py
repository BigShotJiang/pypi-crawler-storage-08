from __future__ import annotations

from fabricks.config.steps.base import BaseStepConfig


class BronzeStepConfig(BaseStepConfig):
    pass
