select `id` as __key, `id` as id, name as monarch, `doubleField` as value, `__timestamp`
from silver.monarch_scd1__current s
