select `id` as id, `name` as monarch, `doubleField` as value, true as __it_should_not_be_found
from silver.monarch_scd1__current
