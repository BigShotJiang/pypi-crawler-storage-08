select `id` as id, `name` as monarch, `__timestamp` from silver.monarch_scd1__current
