select 1 as dummy
union
select 2 as dummy
union
select 3 as dummy
