// 主入口文件，导入所有模块
import "./hookLoadImage.js";
import "./postEvent.js";
import "./handleStyle.js";
import "./clipspaceToOss.js";
