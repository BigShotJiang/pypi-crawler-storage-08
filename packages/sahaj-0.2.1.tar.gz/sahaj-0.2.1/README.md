# SAHAJ

SAHAJ is an open-source CLI tool to install and manage open-source software easily.

## Installation
```powershell
pip install SAHAJ
