pylbmisc package
================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pylbmisc.datasets

Submodules
----------

pylbmisc.dm module
------------------

.. automodule:: pylbmisc.dm
   :members:
   :undoc-members:
   :show-inheritance:

pylbmisc.fig module
-------------------

.. automodule:: pylbmisc.fig
   :members:
   :undoc-members:
   :show-inheritance:

pylbmisc.io module
------------------

.. automodule:: pylbmisc.io
   :members:
   :undoc-members:
   :show-inheritance:

pylbmisc.iter module
--------------------

.. automodule:: pylbmisc.iter
   :members:
   :undoc-members:
   :show-inheritance:

pylbmisc.r module
-----------------

.. automodule:: pylbmisc.r
   :members:
   :undoc-members:
   :show-inheritance:

pylbmisc.rand module
--------------------

.. automodule:: pylbmisc.rand
   :members:
   :undoc-members:
   :show-inheritance:

pylbmisc.stats module
---------------------

.. automodule:: pylbmisc.stats
   :members:
   :undoc-members:
   :show-inheritance:

pylbmisc.surv module
--------------------

.. automodule:: pylbmisc.surv
   :members:
   :undoc-members:
   :show-inheritance:

pylbmisc.tg module
------------------

.. automodule:: pylbmisc.tg
   :members:
   :undoc-members:
   :show-inheritance:

pylbmisc.utils module
---------------------

.. automodule:: pylbmisc.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pylbmisc
   :members:
   :undoc-members:
   :show-inheritance:
