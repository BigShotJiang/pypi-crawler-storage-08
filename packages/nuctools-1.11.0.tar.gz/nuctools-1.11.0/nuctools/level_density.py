import numpy as np


def gilbert_cameron():
    print('not implemented.')
