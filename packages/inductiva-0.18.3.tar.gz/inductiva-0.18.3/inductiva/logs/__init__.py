#pylint: disable=missing-module-docstring
from .log import setup, is_cli, mute_logging
