# sage_setup: distribution = sagemath-schemes
"""nodoctest
all.py -- export of Berkovich spaces to all of Sage
"""

from sage.schemes.berkovich.berkovich_space import Berkovich_Cp_Affine, Berkovich_Cp_Projective
