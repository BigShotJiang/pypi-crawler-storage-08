# sage_setup: distribution = sagemath-schemes
from sage.schemes.plane_quartics.quartic_constructor import QuarticCurve
