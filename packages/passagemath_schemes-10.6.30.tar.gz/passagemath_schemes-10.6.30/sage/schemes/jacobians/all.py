# sage_setup: distribution = sagemath-schemes
# from abstract_jacobian import is_Jacobian, Jacobian
