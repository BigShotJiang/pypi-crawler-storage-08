# sage_setup: distribution = sagemath-schemes
from sage.modular.drinfeld_modform.ring import DrinfeldModularForms
