# sage_setup: distribution = sagemath-schemes
from sage.modular.local_comp.local_comp import LocalComponent
