"""
Android App Publishing Module
"""

def publish_ios():
    print("publishing iOS")