def main():
    print("Hello from huum-cli!")


if __name__ == "__main__":
    main()
