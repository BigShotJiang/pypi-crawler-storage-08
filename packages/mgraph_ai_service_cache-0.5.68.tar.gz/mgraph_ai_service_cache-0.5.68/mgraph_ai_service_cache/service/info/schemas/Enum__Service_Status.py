from enum import Enum

class Enum__Service_Status(Enum):
    operational : str = 'operational'
    degraded    : str = 'degraded'