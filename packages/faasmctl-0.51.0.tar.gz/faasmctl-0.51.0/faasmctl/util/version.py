FAASMCTL_VERSION = "0.51.0"


def get_version():
    return FAASMCTL_VERSION
