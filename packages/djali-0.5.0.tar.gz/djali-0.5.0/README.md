README
======

djali is a thin layer library/client for popular Key/Value databases.
Currently supporting DynamoDB and CouchDB.

As of 2024-05-26 project moved to sourceforge (https://sourceforge.net/projects/djali/).

