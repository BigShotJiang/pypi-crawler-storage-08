# gridworks-scada-protocol

This package contains data structures used in messages between [gridworks-scada]
devices, the gridworks ATN and the [gridworks-admin].

[gridworks-scada]: https://github.com/thegridelectric/gridworks-scada 
[gridworks-admin]: https://pypi.org/project/gridworks-admin/