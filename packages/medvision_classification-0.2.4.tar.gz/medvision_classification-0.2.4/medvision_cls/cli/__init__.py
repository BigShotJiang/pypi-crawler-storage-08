"""
CLI module for MedVision Classification
"""

from .main import main, cli

__all__ = ["main", "cli"]
