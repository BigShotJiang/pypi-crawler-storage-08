from django.utils.translation import gettext as _

EMAIL_CONFIRMATION_PIN_TITLE = _("Email confirmation PIN")
EMAIL_CONFIRMATION_PIN_BODY = _("Your email confirmation PIN is %s")
PHONE_NUMBER_CONFIRMATION_PIN_BODY = _("Your email confirmation PIN is %s")
PASSWORD_RESET_PIN_BODY = _("Your email confirmation PIN is %s")
PASSWORD_RESET_PIN_TITLE = _("Password reset")