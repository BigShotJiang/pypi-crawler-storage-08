# Security Policy

## Supported Versions

`qiskit-ibm-runtime` supports one minor version release at a time, both for bug
and security fixes. For example, if the most recent release is 0.12.1, then the
0.12.x release series is currently supported.

## Reporting a Vulnerability

To report vulnerabilities, you can privately report a potential security issue
via the Github security vulnerabilities feature. This can be done here:

https://github.com/Qiskit/qiskit-ibm-runtime/security/advisories

Please do **not** open a public issue about a potential security vulnerability.

You can find more details on the security vulnerability feature in the Github
documentation here:

https://docs.github.com/en/code-security/security-advisories/guidance-on-reporting-and-writing/privately-reporting-a-security-vulnerability
