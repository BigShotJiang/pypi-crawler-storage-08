"""Tests for pipefunc.map.storage."""
