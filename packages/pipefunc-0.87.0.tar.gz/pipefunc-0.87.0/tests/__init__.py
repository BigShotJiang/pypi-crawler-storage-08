"""Tests for pipefunc."""
