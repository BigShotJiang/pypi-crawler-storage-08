"""pipefunc.map._storage: Modules that handle storage for MapSpecs."""
