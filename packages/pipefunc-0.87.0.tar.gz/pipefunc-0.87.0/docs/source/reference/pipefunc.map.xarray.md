## `pipefunc.map.xarray` module

```{eval-rst}
.. automodule:: pipefunc.map.xarray
    :members:
    :undoc-members:
    :show-inheritance:
```
