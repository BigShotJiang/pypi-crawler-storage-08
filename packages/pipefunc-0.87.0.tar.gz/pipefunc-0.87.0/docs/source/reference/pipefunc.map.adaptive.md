## `pipefunc.map.adaptive` module

```{eval-rst}
.. automodule:: pipefunc.map.adaptive
    :members:
    :undoc-members:
    :show-inheritance:
```
