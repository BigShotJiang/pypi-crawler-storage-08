# moodle-xml-parser
python library for parsing a moodle xml file extracting all the information about various type of questions (for now multichoice and cloze types)
