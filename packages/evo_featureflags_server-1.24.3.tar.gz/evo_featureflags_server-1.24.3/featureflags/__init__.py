import os

__version__ = "1.24.3"
__build_version__ = os.getenv("BUILD_VERSION", "0")
