# Qlibx: A Quantum Computing Library

Qlibx is a Python library designed to provide foundational tools for quantum computing. It offers classes and methods to represent and manipulate quantum states, operators, and their interactions. The library is lightweight and focuses on the mathematical foundations of quantum mechanics, making it an excellent choice for learning and experimentation.

---

## Features

- **Quantum States**:
    - `Ket` and `Bra` classes to represent quantum states.
    - Support for operations like addition, subtraction, scalar multiplication, tensor products, and inner/outer products.

- **Quantum Operators**:
    - `Operator` class to represent quantum operators.
    - Methods for Hermitian, unitary, and normality checks.
    - Commutator and anti-commutator calculations.
    - Spectral decomposition and partial trace.
    - Von Neumann entropy calculation.

- **Predefined Operators**:
    - Pauli matrices (`pauli_x`, `pauli_y`, `pauli_z`) and the identity matrix.

---

## Installation

Clone the repository and include the library in your Python project:

```bash
git clone https://github.com/your-repo/qpylib.git
cd qpylib
```

Ensure the `qpylib` directory is in your Python path.

---

## Usage

### Importing the Library

```python
from qpylib import Ket, Bra, Operator
```

### Creating Quantum States

```python
# Create a Ket vector
ket = Ket([1, 0])

# Create a Bra vector
bra = Bra([1, 0])
```

### Quantum Operations

```python
# Inner product
inner = ket.inner_product(bra)

# Outer product
outer = ket.outer_product(bra)

# Tensor product
tensor = ket.tensor(Ket([0, 1]))
```

### Working with Operators

```python
# Define an operator
op = Operator([[0, 1], [1, 0]])

# Apply operator to a Ket
result = op.op(ket)

# Check if the operator is unitary
is_unitary = op.unitary()
```

---

## Example: Quantum Circuit Simulation

```python
from qpylib import Ket, Operator

# Define a quantum state |ψ⟩
psi = Ket([1, 0])

# Define a Pauli-X gate
pauli_x = Operator(Operator.pauli_x)

# Apply the gate
new_state = pauli_x.op(psi)

print(new_state)
```

---

## Contributing

Contributions are welcome! If you find a bug or have a feature request, please open an issue or submit a pull request.

---

## License

This project is licensed under the [MIT License](LICENSE).

---

## Acknowledgments

Qlibx is inspired by the mathematical foundations of quantum mechanics and aims to provide an intuitive interface for quantum computing enthusiasts.
