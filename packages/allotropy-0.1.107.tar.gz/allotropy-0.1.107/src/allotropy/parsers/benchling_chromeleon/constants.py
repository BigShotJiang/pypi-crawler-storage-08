DISPLAY_NAME = "Benchling Thermo Fisher Scientific Chromeleon"
SOFTWARE_NAME = "Thermo Fisher Scientific Chromeleon"
PRODUCT_MANUFACTURER = "Thermo Fisher Scientific"
DEVICE_TYPE = "HPLC"
