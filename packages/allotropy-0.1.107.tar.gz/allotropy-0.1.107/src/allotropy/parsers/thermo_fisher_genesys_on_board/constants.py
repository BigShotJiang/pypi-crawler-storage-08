DISPLAY_NAME = "Thermo Fisher Scientific Genesys On-Board"
SOFTWARE_NAME = "Genesys On-Board"
