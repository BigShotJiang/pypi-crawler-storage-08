DEVICE_TYPE = "fluorescence detector"
DETECTION_TYPE = "Fluorescence"
PROTOCOL_ID = "Weyland Yutani Example"
ASSAY_ID = "Example Assay"
