from .tesserocr import __version__
from .tesserocr import *
