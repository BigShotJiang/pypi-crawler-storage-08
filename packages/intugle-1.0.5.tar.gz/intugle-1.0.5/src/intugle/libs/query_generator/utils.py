def get_formatted_dataset_field(dataset: str, field: str) -> str:
    return f"{dataset}.{field}"


def get_formatted_name(name: str) -> str:
    return name