#define My_ctype_DEF
#include "f2c_ctype.h"
