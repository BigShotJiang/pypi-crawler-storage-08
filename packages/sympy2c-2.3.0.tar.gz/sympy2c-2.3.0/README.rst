sympy2c
=======

sympy2c is a sympy to c compiler including solving odes at c level.
