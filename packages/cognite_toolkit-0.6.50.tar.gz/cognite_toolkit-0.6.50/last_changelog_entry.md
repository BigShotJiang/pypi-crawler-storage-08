## cdf 

### Added

- [alpha] You can now use `CogniteFile` instead of asset-centric file
when deploying a Function. You do this by specifying a `space` in the
function configuration. This is behind the `function-cognite-file` flag.

### Fixed

- [alpha] Data-modeling only projects, require you to use `CogniteFile`
instead of asset-centric file when deploying a Function.

## templates

No changes.