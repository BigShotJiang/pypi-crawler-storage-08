from __future__ import annotations

from django_spire.core.tests.test_cases import BaseTestCase


class UserAccountFactoriesUnitTestCase(BaseTestCase):
    pass
