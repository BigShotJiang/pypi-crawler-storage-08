"""Version configuration for ZephFlow Python SDK."""

# Python SDK version - this should match the published version
PYTHON_SDK_VERSION = "0.3.1"

# Java SDK version - used by jar_manager to download the correct JAR
JAVA_SDK_VERSION = "0.3.1"
