# Installation Instructions

This document has moved to the
[Synapse documentation website](https://element-hq.github.io/synapse/latest/setup/installation.html).
Please update your links.

The markdown source is available in [docs/setup/installation.md](docs/setup/installation.md).
