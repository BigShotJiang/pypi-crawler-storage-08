# ROUTIR: A Simple and Fast Search Service for Hosting State-of-the-Art Retrieval Models.

```bash
python -m routir.serve config.json
```
