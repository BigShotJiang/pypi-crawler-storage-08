import sys
from .SystemTest import main
main()