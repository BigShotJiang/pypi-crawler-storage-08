"""Datastore class file."""

from bits.google import Datastore as DatastoreBase


class Datastore(DatastoreBase):
    """Datastore class."""
