"""BITSdbAPI class file."""

# from bits.google import Google


class BITSdbAPI:
    """BITSdbAPI class."""
