"""Firestore class file."""

from bits.google import Firestore as FirestoreBase


class Firestore(FirestoreBase):
    """Firestore class."""
