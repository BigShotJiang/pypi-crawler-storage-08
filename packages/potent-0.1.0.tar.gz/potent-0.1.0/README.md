# potent

A CLI for running idem**potent** shell scripts.
