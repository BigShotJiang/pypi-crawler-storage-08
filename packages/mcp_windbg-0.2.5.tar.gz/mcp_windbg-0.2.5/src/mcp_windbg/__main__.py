# __main__.py

from mcp_windbg import main

main()
