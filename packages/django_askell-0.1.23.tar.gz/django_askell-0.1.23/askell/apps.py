from django.apps import AppConfig


class AskellConfig(AppConfig):
    name = 'askell'
    default_auto_field = 'django.db.models.BigAutoField'