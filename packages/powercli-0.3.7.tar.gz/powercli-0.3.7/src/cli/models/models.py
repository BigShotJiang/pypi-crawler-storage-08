class CalledProcessError(Exception):
    pass
