from cli.output.message import Message


def test_message() -> None:
    Message()
