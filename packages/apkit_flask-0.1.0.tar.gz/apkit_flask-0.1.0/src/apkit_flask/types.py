from dataclasses import dataclass
from typing import List, Optional, TYPE_CHECKING

from apkit.models import Activity
from apkit.types import ActorKey
from apkit.client.sync.client import ActivityPubClient
from apkit.abc.types import AbstractContext
from apmodel.types import ActivityPubModel
from apmodel.vocab.actor import Actor, ActorEndpoints
from apmodel.vocab.activity import Accept, Reject
from cryptography.hazmat.primitives.asymmetric import rsa
from flask import Request

if TYPE_CHECKING:
    from . import ApkitIntegration

@dataclass
class Context(AbstractContext):
    _apkit: "ApkitIntegration"
    
    activity: Activity
    request: Request

    def send(self, keys: List[ActorKey], target: Actor, activity: ActivityPubModel):
        with ActivityPubClient() as client:

            inbox = None
            priv_key = None
            key_id = None

            if target.endpoints is ActorEndpoints and target.endpoints.sharedInbox:
                if not isinstance(activity, Accept) and not isinstance(activity, Reject):
                    inbox = target.endpoints.sharedInbox
            else:
                inbox = target.inbox
            if not isinstance(inbox, str):
                raise ValueError("Unsupported Inbox Type")


            for key in keys:
                if isinstance(key.private_key, rsa.RSAPrivateKey):
                    priv_key = key.private_key
                    key_id = key.key_id
                    break
            if priv_key and key_id and inbox:
                resp = client.post(inbox, key_id=key_id, signature=priv_key, json=activity)
                return None
            else:
                pass


    def get_actor_keys(self, identifier: Optional[str]) -> List[ActorKey]:
        if identifier:
            if self._apkit._get_actor_keys:
                actor_keys = self._apkit._get_actor_keys(identifier)
                if actor_keys:
                    return actor_keys
        return []