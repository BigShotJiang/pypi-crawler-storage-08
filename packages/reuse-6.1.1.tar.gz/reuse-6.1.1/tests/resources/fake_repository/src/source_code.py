# SPDX-FileCopyrightText: 2017 Jane Doe
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""Module docstring."""

if __name__ == "__main__":
    print("Hello, world!")
