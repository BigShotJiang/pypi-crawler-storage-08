# Copyright Nova Code (http://www.novacode.nl)
# See LICENSE file for full licensing details.

from .component import Component


class contentComponent(Component):
    # XXX should we move the initEmpty from base
    pass
