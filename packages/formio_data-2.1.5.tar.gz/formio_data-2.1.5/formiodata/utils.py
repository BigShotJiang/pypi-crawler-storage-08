# Copyright Nova Code (http://www.novacode.nl)
# See LICENSE file for full licensing details.

import base64
import requests
import tempfile
import re

from datetime import datetime


def base64_encode_url(url):
    content = requests.get(url).content
    tf = tempfile.TemporaryFile()
    tf.write(content)
    tf.seek(0)
    b64encode = base64.b64encode(tf.read())
    tf.close()
    # prefix and decode bytes to str
    b64encode = '%s,%s' % ('data:image/png;base64', b64encode.decode())
    return b64encode


def decode_resource_template(tmp):
    res = re.sub(r"<.*?>", " ", tmp)
    strcleaned = re.sub(r'\{{ |\ }}', "", res)
    list_kyes = strcleaned.strip().split(".")
    return list_kyes[1:]


def fetch_dict_get_value(dict_src, list_keys):
    if len(list_keys) == 0:
        return
    node = list_keys[0]
    list_keys.remove(node)
    nextdict = dict_src.get(node)
    if len(list_keys) >= 1:
        return fetch_dict_get_value(nextdict, list_keys)
    else:
        return dict_src.get(node)

def datetime_fromisoformat(date_string):
    # Backport of Python 3.7 datetime.fromisoformat
    if hasattr(datetime, 'fromisoformat'):
        # Python >= 3.7
        return datetime.fromisoformat(date_string)
    else:
        # Python < 3.7
        # replaces the fromisoformat, not available in Python < 3.7
        #
        # XXX following:
        # - Raises: '2021-02-25T00:00:00+01:00' does not match format '%Y-%m-%dT%H:%M%z'
        # - Due to %z not obtaing the colon in '+1:00' (tz offset)
        # - More info: https://stackoverflow.com/questions/54268458/datetime-strptime-issue-with-a-timezone-offset-with-colons
        # fmt_str =  r"%Y-%m-%dT%H:%M:%S%z"
        # return datetime.strptime(value, fmt_str)
        #
        # REQUIREMENT (TODO document, setup dependency or try/except raise exception)
        # - pip install dateutil
        # - https://dateutil.readthedocs.io/
        from dateutil.parser import parse
        return parse(date_string)
