#include <stdio.h>

#include "example.h"


int main(){
    printf(FOO);
}
