raise Exception('Error during import :(')
