/* Some header-only library... */

#define FOO "bar"
