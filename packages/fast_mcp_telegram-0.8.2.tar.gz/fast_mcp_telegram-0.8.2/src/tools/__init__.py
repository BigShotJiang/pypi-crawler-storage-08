"""
Tools package for Telegram MCP server functionality.
"""

__version__ = "1.0.0"
