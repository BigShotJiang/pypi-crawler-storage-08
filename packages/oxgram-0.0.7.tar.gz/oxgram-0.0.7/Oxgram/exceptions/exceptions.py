class ExpiredPremium(Exception):
    pass

class LimitedMessage(Exception):
    pass

class SecuredMessage(Exception):
    pass

class Accessblocked(Exception):
    pass

class CancelledTask(Exception):
    pass

class InvalidReply(Exception):
    pass

class Positivemode(Exception):
    pass

class Negativemode(Exception):
    pass

class InvalidKey(Exception):
    pass

class Cancelled(Exception):
    pass
