class Scripted:

    DATA01 = ""
    DATA02 = " "
