appname = 'oxgram'
version = '0.0.7'

caption = 'ㅤ'
pythons = '~=3.10'
clinton = 'Clinton Abraham'
profile = 'https://github.com/Clinton-Abraham'

install = ['pyrofork', 'tgcryptos']
mention = ['bot', 'bots', 'telegram']

DATA01 = 'clintonabrahamc@gmail.com'
DATA02 = ['Natural Language :: English',
          'Intended Audience :: Developers',
          'Operating System :: OS Independent',
          'Programming Language :: Python :: 3.10',
          'Programming Language :: Python :: 3.11',
          'Programming Language :: Python :: 3.12',
          'Programming Language :: Python :: 3.13',
          'Programming Language :: Python :: 3.14',
          'Topic :: Software Development :: Libraries',
          'Topic :: Software Development :: Localization',
          'Topic :: Software Development :: User Interfaces',
          'Topic :: Software Development :: Version Control']
