<p align="center">
 📦 <a href="https://pypi.org/project/oxgram" style="text-decoration:none;">Oxgram</a>
</p>


```python

from Oxgram.functions import Pyrogram

dcid = await Pyrogram.get01(update)

print(dcid)

```
