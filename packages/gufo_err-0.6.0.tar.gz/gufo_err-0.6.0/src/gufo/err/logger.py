# ---------------------------------------------------------------------
# Gufo Err: Traceback class
# ---------------------------------------------------------------------
# Copyright (C) 2022-23, Gufo Labs
# ---------------------------------------------------------------------
"""Define gufo.err logger."""

# Python modules
import logging

# Define gufo.err logger
logger = logging.getLogger("gufo.err")
