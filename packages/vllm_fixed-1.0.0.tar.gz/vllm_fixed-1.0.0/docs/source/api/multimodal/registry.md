# Registry

## Module Contents

```{eval-rst}
.. automodule:: vllm.multimodal.registry
    :members:
    :member-order: bysource
```
