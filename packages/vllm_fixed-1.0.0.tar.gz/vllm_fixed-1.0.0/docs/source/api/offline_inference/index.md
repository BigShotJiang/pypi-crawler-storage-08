# Offline Inference

:::{toctree}
:caption: Contents
:maxdepth: 1

llm
llm_inputs
:::
