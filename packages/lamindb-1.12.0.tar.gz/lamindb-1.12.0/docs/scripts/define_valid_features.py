import lamindb as ln

schema = ln.Schema(name="valid_features", itype=ln.Feature).save()
