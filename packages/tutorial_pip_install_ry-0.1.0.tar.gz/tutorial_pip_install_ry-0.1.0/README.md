# tutorial_pip_install_ry

A simple, educational example showing how to make a pip-installable package
that loads data and pretrained models from Hugging Face Hub.

## Installation
```bash
pip install tutorial_pip_install_ry
