
import codePipelineRoutes from './routes/codePipelineRoutes';

app.use("/api/codepipeline",codePipelineRoutes)