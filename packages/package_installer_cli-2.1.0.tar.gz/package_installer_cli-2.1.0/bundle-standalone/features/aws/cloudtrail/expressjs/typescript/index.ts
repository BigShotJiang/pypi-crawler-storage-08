
import cloudTrailRoutes from "./routes/awsCloudTrailRoutes";

app.use("/api/cloud-trail", cloudTrailRoutes);