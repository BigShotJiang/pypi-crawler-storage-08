import awsCloudFrontRoutes from "./routes/awsCloudFrontRoutes";

app.use("/api/cloudfront", awsCloudFrontRoutes);