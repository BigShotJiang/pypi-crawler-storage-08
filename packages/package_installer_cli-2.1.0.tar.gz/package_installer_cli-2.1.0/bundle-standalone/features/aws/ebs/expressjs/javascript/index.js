
import awsEbsRoutes from './routes/awsEbsRoutes.js';

app.use("/api/ebs",awsEbsRoutes)