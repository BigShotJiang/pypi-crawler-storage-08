
import cloudWatchRoutes from "./routes/awsCloudWatchRoutes.js";

app.use("/api/cloud-watch", cloudWatchRoutes);