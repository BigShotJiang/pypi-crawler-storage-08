
import cloudWatchRoutes from "./routes/awsCloudWatchRoutes";

app.use("/api/cloud-watch", cloudWatchRoutes);