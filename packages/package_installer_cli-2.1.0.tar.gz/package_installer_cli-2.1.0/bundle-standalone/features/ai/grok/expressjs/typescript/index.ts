import grokRoutes from './routes/grokRoutes';

app.use("/api/grok", grokRoutes);