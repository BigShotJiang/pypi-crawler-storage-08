import claudeRoutes from './routes/claudeRoutes';

app.use("/api/claude", claudeRoutes);