import openAiRoutes from './routes/openAiRoutes';

app.use("/api/open-ai", openAiRoutes);