# Weather MCP

A simple weather MCP for learning

## Features

- Fetches and current weather data

## License

MIT License

## build
python3 -m build
python3 -m twine upload dist/* --verbose