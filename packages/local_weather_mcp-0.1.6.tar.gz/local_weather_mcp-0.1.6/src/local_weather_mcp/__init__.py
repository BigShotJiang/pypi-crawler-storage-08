"""Local Weather MCP Server."""
