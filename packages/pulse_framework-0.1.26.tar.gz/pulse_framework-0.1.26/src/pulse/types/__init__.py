from .event_handler import (
    EventHandler0,
    EventHandler1,
    EventHandler2,
    EventHandler3,
    EventHandler4,
    EventHandler5,
    EventHandler6,
    EventHandler7,
    EventHandler8,
    EventHandler9,
    EventHandler10,
)

__all__ = [
    "EventHandler0",
    "EventHandler1",
    "EventHandler2",
    "EventHandler3",
    "EventHandler4",
    "EventHandler5",
    "EventHandler6",
    "EventHandler7",
    "EventHandler8",
    "EventHandler9",
    "EventHandler10",
]
