# map3C

A package for processing 3C/Hi-C data. 

See [`docs/`](docs/) for usage instructions.
