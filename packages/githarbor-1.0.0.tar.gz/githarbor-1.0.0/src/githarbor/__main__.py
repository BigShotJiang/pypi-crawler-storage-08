"""Main module for running the GitHarbor MCP server as a command line application."""

from githarbor.mcp_server import main


if __name__ == "__main__":
    main()
