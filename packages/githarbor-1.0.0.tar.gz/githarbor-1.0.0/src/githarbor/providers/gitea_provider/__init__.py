"""Gitea Provider package."""

from githarbor.providers.gitea_provider.repository import GiteaRepository

__all__ = ["GiteaRepository"]
