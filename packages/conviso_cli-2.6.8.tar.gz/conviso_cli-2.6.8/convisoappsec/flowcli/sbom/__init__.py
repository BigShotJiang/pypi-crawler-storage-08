from .entrypoint import sbom

__all__ = ['sbom']
