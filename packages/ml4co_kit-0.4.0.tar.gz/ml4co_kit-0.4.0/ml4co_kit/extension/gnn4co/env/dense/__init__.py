from .atsp import atsp_dense_process
from .cvrp import cvrp_dense_process
from .tsp import tsp_dense_process