/******************************************************************************
 * problem_factory.cpp 
 *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 *
 *****************************************************************************/

#include "problem_factory.h"

problem_factory::problem_factory() {
                
}

problem_factory::~problem_factory() {
                
}

