/**
 * initial_mis.cpp
 * Purpose: Interface for different initial solution algorithms.
 *
 *****************************************************************************/

#include "initial_mis.h"

initial_mis::initial_mis() {

}

initial_mis::~initial_mis() {

}

