/**
 * combine.h
 * Purpose: Interface for the combine operators.
 *
 *****************************************************************************/

#ifndef _COMBINE_H_
#define _COMBINE_H_

#include "data_structure/graph_access.h"

class combine {
    public:
        combine();
        virtual ~combine();
};

#endif

