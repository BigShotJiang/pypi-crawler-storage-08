/******************************************************************************
 * partial_boundary.cpp 
 *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 *
 *****************************************************************************/

#include "partial_boundary.h"

PartialBoundary::PartialBoundary() {
                
}

PartialBoundary::~PartialBoundary() {
                
}

