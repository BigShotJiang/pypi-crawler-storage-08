/******************************************************************************
 * node_ordering.cpp         
 *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 *
 *****************************************************************************/


#include "node_ordering.h"

node_ordering::node_ordering() {
                
}

node_ordering::~node_ordering() {
                
}

