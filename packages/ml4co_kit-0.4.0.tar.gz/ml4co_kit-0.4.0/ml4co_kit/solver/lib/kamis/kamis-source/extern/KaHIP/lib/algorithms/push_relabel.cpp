/******************************************************************************
 * push_relabel.cpp
 *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning 
 * 
 *****************************************************************************/

#include "push_relabel.h"

push_relabel::push_relabel( ) {
                
}

push_relabel::~push_relabel() {
                
}

