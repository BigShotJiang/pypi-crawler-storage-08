#!/bin/bash

rm -rf deploy
rm -rf optimized
