/******************************************************************************
 * refinement.cpp 
 *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 *
 *****************************************************************************/

#include "refinement.h"

refinement::refinement() {
                
}

refinement::~refinement() {
                
}



