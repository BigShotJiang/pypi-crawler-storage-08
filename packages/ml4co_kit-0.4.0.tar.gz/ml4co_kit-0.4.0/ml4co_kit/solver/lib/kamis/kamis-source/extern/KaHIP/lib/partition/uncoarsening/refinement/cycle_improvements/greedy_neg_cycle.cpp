/******************************************************************************
 * greedy_neg_cycle.cpp 
 *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 *
 *****************************************************************************/

#include "greedy_neg_cycle.h"

greedy_neg_cycle::greedy_neg_cycle() {
                
}

greedy_neg_cycle::~greedy_neg_cycle() {
                
}

