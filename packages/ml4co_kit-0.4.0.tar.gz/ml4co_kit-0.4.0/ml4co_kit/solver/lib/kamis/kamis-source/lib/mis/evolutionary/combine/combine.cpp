/**
 * combine.cpp
 * Purpose: Interface for the combine operators.
 *
 *****************************************************************************/

#include "combine.h"

combine::combine() {

}

combine::~combine() {

}

