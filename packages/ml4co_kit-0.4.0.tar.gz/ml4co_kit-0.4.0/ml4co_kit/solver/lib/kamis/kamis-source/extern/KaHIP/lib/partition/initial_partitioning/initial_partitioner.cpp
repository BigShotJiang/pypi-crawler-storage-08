/******************************************************************************
 * initial_partitioner.cpp 
 *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 *
 *****************************************************************************/

#include "initial_partitioner.h"

initial_partitioner::initial_partitioner() {
                
}

initial_partitioner::~initial_partitioner() {
                
}

