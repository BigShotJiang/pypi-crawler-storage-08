======================================
ML4CO-Kit: Python toolkit for ML4CO
======================================

.. mdinclude:: ../README.md

Contents of Official Documentation
------------------------------------

.. toctree::
   :maxdepth: 1

   self
   guide/introduction.rst
   guide/get_started.rst
   api/ml4co_kit.rst