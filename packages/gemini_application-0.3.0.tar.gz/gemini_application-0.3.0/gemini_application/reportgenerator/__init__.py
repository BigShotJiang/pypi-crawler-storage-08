"""Report generation application."""
