from fast_depends.library.model import CustomField
from fast_depends.library.serializer import Serializer

__all__ = (
    "CustomField",
    "Serializer",
)
