"""FastDepends - extracted and cleared from HTTP domain FastAPI Dependency Injection System"""

from importlib.metadata import version

__version__ = version("fast_depends")
