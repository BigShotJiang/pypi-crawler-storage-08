from fast_depends.pydantic.serializer import PydanticSerializer

__all__ = ("PydanticSerializer",)
