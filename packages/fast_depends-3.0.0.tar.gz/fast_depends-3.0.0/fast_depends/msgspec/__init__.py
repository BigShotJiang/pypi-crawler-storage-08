from fast_depends.msgspec.serializer import MsgSpecSerializer

__all__ = ("MsgSpecSerializer",)
