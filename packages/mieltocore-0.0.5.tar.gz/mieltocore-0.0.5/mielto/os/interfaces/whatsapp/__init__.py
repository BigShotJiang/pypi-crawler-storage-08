from mielto.os.interfaces.whatsapp.whatsapp import Whatsapp

__all__ = ["Whatsapp"]
