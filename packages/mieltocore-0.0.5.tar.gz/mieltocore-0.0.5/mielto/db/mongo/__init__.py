from mielto.db.mongo.mongo import MongoDb

__all__ = ["MongoDb"]
