```{eval-rst}
.. _location-api:
```
# Location

```{eval-rst}
.. autopydantic_model:: infrasys.location.Location
   :members:
```
