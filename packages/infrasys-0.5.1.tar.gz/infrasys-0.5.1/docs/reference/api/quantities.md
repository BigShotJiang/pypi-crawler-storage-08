# Quantities

```{eval-rst}
.. _base-quantity-api:
```

## BaseQuantity

```{eval-rst}
.. autoclass:: infrasys.base_quantity.BaseQuantity
   :members:
```

```{eval-rst}
.. _quantity-api:
```

## infrasys.quantities

```{eval-rst}
.. automodule:: infrasys.quantities
   :members:
```

