```{eval-rst}
.. _components-api:
```

# Components

```{eval-rst}
.. autopydantic_model:: infrasys.component.Component
   :members:
```
