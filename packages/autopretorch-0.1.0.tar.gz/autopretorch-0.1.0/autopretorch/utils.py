
import pandas as pd

def sample_preview(df, n=5):
    return df.head(n)
