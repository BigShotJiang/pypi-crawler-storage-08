from .dashboard_view import DashboardView

__all__ = ["DashboardView"]
