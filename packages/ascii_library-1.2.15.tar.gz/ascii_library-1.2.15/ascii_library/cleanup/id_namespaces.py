# print(uuid.uuid4())
ascii_company_namespace = "bf3b75f4-79e7-4341-aa33-a5383e6f2d15"
