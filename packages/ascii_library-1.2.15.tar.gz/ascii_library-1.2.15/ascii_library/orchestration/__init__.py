duckdb_ccc_warehouse_name = "duckdb_ccc"
