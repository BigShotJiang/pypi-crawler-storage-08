"""Session management scripts"""
