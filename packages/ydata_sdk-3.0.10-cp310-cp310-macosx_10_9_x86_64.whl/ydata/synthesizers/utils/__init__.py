"""YData utils."""
