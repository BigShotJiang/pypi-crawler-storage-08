"""GMX platform implementation"""

from .client import GMXClient

__all__ = ['GMXClient']