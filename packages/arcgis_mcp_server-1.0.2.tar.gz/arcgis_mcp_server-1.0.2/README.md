mcp-name: io.github.esrisaudiarabia/arcgis-mcp-server

