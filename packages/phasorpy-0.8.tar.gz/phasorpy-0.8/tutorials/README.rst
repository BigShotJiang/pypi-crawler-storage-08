Tutorials
=========

A gallery of examples that showcase how the :doc:`PhasorPy library <../index>`
can be used to analyze time-resolved and hyperspectral fluorescence images
using the :doc:`../phasor_approach`.

Some tutorials demonstrate the use of the programming interface in general,
while others provide problem-oriented how-to guides for advanced applications.
