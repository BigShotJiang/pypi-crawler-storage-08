phasorpy.color
--------------

.. automodule:: phasorpy.color
    :members:
    :exclude-members: SRGB_SPECTRUM, CATEGORICAL

.. autodata:: phasorpy.color.CATEGORICAL
   :no-value:

.. image:: ../_static/categorical.png
  :alt: phasorpy.color.CATEGORICAL
  :align: center

.. autodata:: phasorpy.color.SRGB_SPECTRUM
   :no-value:

.. image:: ../_static/srgb_spectrum.png
  :alt: phasorpy.color.SRGB_SPECTRUM
  :align: center
