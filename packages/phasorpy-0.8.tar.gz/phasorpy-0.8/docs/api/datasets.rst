phasorpy.datasets
-----------------

.. automodule:: phasorpy.datasets
    :members:
    :exclude-members: REPOSITORIES

.. autodata:: phasorpy.datasets.REPOSITORIES
   :no-value:
