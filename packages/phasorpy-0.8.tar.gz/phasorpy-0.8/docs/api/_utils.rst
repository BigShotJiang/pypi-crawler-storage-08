phasorpy._utils
---------------

.. automodule:: phasorpy._utils
    :members:
