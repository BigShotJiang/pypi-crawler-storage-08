Command line interface
----------------------

.. click:: phasorpy.cli:main
   :prog: python -m phasorpy
   :nested: full
