"""
Create pipeline systems to run multiple pipelines sequentially with execution consistency.
"""

from ._core import System as System