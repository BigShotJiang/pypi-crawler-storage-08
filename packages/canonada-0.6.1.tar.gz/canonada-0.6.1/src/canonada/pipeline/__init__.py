"""
Manage pipelines and nodes
"""

from ._core import Node as Node
from ._core import Pipeline as Pipeline