# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Gdpr Service."""

__version__ = "2.20.1"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .s2s_get_list_finished_a_52b7a0 import S2SGetListFinishedAccountDeletionRequest
from .s2s_submit_user_account_5c299d import S2SSubmitUserAccountDeletionRequest
