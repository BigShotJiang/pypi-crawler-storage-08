"""The Currency router init."""
