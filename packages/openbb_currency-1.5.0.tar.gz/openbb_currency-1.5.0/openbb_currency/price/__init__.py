"""The Currency price router init."""
