# OpenBB Currency Extension

This extension provides currency exchange related data for the OpenBB Platform.

## Installation

To install the extension, run the following command in this folder:

```bash
pip install openbb-currency
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
