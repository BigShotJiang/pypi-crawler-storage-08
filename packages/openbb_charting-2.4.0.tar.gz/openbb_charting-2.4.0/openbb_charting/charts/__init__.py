"""OpenBB Charting utils."""
