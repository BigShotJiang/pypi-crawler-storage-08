"""Charting Extension Styles"""
