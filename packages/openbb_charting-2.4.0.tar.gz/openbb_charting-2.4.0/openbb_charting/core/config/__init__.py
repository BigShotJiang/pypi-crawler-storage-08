"""OpenBB Charting core configuration."""
