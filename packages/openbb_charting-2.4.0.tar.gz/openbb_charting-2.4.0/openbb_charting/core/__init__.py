"""OpenBB Charting core."""
