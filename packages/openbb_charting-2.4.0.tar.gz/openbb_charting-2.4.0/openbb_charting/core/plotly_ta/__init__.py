"""Plotly TA core package."""
