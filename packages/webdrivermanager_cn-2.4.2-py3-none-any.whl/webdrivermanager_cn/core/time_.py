import time


def get_time(_format="%Y%m%d%H%M%S"):
    return time.strftime(_format)
