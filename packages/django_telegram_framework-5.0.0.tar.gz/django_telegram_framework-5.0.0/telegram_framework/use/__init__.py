from .list import list_action
from .detail import detail_action
from .template import template_action
from .create import create_action
