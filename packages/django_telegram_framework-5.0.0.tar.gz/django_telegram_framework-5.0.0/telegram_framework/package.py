"""
Package info
"""
name = 'django-telegram-framework'
version = '5.0.0'
status = '3 - Alpha'
