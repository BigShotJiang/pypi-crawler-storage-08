"""Used by importlib.resources and setuptools"""
