"""Core infrastructure for lazy-ecs."""
