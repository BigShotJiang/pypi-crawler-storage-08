from .htmx import is_htmx

__all__ = ["is_htmx"]
