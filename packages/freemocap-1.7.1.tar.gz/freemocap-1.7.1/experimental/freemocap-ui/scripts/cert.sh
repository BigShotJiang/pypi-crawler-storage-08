mkcert -install
mkcert localhost
