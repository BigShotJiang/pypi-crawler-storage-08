"""mcp-pytest-runner: MCP server providing standardized pytest execution for AI agents."""

from mcp_pytest_runner import domain  # noqa: F401

__version__ = "0.2.1"

__all__ = ["domain", "__version__"]
