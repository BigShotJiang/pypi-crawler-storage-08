"""Session management for executors."""
