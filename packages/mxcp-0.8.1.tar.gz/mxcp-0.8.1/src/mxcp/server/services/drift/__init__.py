"""MXCP drift detection module."""
