# DynamicDNS

[![PyPI - Version](https://img.shields.io/pypi/v/dynamicdns.svg)](https://pypi.org/project/dynamicdns)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/dynamicdns.svg)](https://pypi.org/project/dynamicdns)

-----

## Table of Contents

- [DynamicDNS](#dynamicdns)
  - [Table of Contents](#table-of-contents)
  - [Installation](#installation)
  - [License](#license)

## Installation

```console
pip install dynamicdns
```

## License

`dynamicdns` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
