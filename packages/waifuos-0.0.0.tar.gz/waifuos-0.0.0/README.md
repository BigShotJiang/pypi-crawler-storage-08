# WaifuOS

The software suite for creating your waifu and the world where your waifu lives.💕
