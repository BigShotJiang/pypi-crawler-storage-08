# SPDX-License-Identifier: Apache-2.0
version = (2, 0, 2)
VERSION = "%d.%d.%d" % version
