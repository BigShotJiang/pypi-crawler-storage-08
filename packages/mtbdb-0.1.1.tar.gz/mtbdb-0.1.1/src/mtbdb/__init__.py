from pathlib import Path

DATA_DIR = Path(__file__).parent / 'data'

__all__ = ['DATA_DIR']