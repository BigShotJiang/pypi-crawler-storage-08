# uv_easy

uv를 더 쉽게 사용하기 위한 파이썬 패키지입니다. 버전 관리와 빌드 과정을 간소화하여 개발 워크플로우를 개선합니다.

## 기능

- **버전 관리**: pyproject.toml의 버전을 쉽게 증가시킬 수 있습니다
- **자동 빌드**: 버전 증가와 빌드를 한 번에 처리합니다
- **자동 설치**: 빌드된 패키지를 현재 환경에 자동으로 설치할 수 있습니다

## 설치

```bash
# 프로젝트 디렉토리에서
uv sync
```

## 사용법

### 버전 관리

#### 현재 버전 확인
```bash
uv_easy version show
```

#### 버전 증가
```bash
# 패치 버전 증가 (0.1.0 → 0.1.1)
uv_easy version up --patch

# 마이너 버전 증가 (0.1.0 → 0.2.0)
uv_easy version up --minor

# 메이저 버전 증가 (0.1.0 → 1.0.0)
uv_easy version up --major
```

### 빌드

#### 기본 빌드 (패치 버전 증가 후 빌드)
```bash
uv_easy build
```

#### 버전 증가 없이 빌드만
```bash
uv_easy build --no-version-up
```

#### 특정 버전 증가 후 빌드
```bash
# 마이너 버전 증가 후 빌드
uv_easy build --minor

# 메이저 버전 증가 후 빌드
uv_easy build --major

# 패치 버전 증가 후 빌드
uv_easy build --patch
```

#### 빌드 후 자동 설치
```bash
uv_easy build --install
```

### PyPI 배포

#### PyPI 배포 준비 (URLs 설정)
```bash
uv_easy ready_pypi
```

#### PyPI 업로드
```bash
uv_easy publish
```

## 명령어 옵션

### `uv_easy version up`
- `--major`: 메이저 버전을 증가시킵니다
- `--minor`: 마이너 버전을 증가시킵니다
- `--patch`: 패치 버전을 증가시킵니다

### `uv_easy build`
- `--no-version-up`: 버전을 증가시키지 않고 빌드만 실행합니다
- `--major`: 메이저 버전을 증가시킨 후 빌드합니다
- `--minor`: 마이너 버전을 증가시킨 후 빌드합니다
- `--patch`: 패치 버전을 증가시킨 후 빌드합니다
- `--install`: 빌드 후 현재 환경에 패키지를 설치합니다

### `uv_easy ready_pypi`
- pyproject.toml에 PyPI 배포를 위한 project.urls를 자동으로 추가합니다
- GitHub 저장소 링크, 이슈 트래커 등을 설정합니다

### `uv_easy publish`
- dist 디렉토리의 패키지를 PyPI에 업로드합니다
- twine을 사용하여 안전하게 업로드합니다

## 예시 워크플로우

### 개발 중 패치 릴리즈
```bash
# 버그 수정 후
uv_easy build --patch --install
```

### 새로운 기능 추가
```bash
# 기능 추가 후
uv_e_easy build --minor --install
```

### 메이저 업데이트
```bash
# 호환성을 깨는 변경 후
uv_easy build --major --install
```

### 개발 중 테스트 빌드
```bash
# 버전 증가 없이 빌드만
uv_easy build --no-version-up
```

### PyPI 배포 워크플로우
```bash
# 1. PyPI 배포 준비 (URLs 설정)
uv_easy ready_pypi

# 2. 빌드
uv_easy build --patch

# 3. PyPI 업로드
uv_easy publish
```

## 요구사항

- Python 3.9 이상
- uv
- pyproject.toml 파일이 있는 프로젝트

## 라이선스

이 프로젝트는 MIT 라이선스 하에 배포됩니다.
