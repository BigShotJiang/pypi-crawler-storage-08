from .CodexDecoder import CodexDecoder as CodexDecoder

__version__ = "1.1.1"
