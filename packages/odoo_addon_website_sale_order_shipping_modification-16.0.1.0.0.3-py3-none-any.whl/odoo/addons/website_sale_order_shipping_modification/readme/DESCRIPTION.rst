This module allows portal users to edit the **delivery address** of a quotation
directly from the portal view, reusing the standard website checkout address selector.
