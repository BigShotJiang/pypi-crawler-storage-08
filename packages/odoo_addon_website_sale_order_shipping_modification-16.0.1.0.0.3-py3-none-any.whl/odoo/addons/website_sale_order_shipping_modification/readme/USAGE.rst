* Go to *Quotations* in the portal and open a quotation.
* In sent quotations, a button will appear to edit the delivery address.
* Clicking it opens the standard checkout address selector:

  - The portal user or a guest with a valid access token can pick one of the
    existing delivery addresses of the commercial partner.
  - The portal user can also create a new address.
  - Only allowed addresses are shown.
  - Select one and confirm, the changes will be applied to the order.
