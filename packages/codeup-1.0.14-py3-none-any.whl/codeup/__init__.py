"""CodeUp - Intelligent git workflow automation tool."""

__version__ = "1.0.14"

from .main import main

__all__ = ["main"]
