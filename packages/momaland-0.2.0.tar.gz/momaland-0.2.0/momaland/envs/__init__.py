"""Environment modules for momaland."""

import momaland.envs.beach
