"""MO Beach problem domain.

From Mannion, P., Devlin, S., Duggan, J., and Howley, E. (2018).
Reward shaping for knowledge-based multi-objective multi-agent reinforcement learning.
"""
