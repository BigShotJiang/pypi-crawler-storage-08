"""Gem Mining Problem."""
