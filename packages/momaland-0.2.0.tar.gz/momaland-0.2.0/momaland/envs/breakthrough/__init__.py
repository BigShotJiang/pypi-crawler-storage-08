"""Adaptation of the Breakthrough game to multi-objective settings."""
