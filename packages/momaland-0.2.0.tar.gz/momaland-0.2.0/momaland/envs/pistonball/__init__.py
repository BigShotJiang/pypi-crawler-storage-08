"""Adapted from the Pistonball environment in PettingZoo."""
