"""MO Route Choice Game.

From De Oliveira Ramos, G., Radulescu, R., Nowe, A., Tavares, A. (2020).
Toll-Based Learning for Minimising Congestion under Heterogeneous Preferences.
"""
