"""Connect 4 environment with multiple objectives."""

from momaland.envs.samegame.same_game import env, raw_env


__all__ = ["env", "raw_env"]
