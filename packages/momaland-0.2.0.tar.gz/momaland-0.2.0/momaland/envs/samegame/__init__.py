"""Adaptation of SameGame to multi-agent and multi-objective settings."""
