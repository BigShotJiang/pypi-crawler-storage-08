"""Adaptation of the Connect4 game to multi-objective settings."""
