"""Multi-objective Ingenious Game."""

from momaland.envs.ingenious.ingenious import env, raw_env


__all__ = ["env", "raw_env"]
