"""Multi-objective Ingenious environment."""
