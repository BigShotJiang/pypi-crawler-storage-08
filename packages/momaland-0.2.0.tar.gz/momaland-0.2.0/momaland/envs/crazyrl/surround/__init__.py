"""Surround environment for multi-agent reinforcement learning."""
