"""Catch environment for multi-agent reinforcement learning."""
