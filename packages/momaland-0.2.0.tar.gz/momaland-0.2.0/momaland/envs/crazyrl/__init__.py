"""CrazyRL Environments, from https://github.com/ffelten/CrazyRL."""
