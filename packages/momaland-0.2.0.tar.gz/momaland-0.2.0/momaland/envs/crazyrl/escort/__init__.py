"""Escort environment for multi-agent reinforcement learning."""
