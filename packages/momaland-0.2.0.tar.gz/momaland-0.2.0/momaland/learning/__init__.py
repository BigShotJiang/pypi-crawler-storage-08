"""Learning module for momaland."""
