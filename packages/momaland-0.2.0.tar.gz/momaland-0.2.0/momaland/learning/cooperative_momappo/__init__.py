"""Cooperative MOMAPPO."""
