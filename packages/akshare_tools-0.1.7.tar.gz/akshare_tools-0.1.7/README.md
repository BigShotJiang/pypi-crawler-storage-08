# AKShare MCP Server

A Model Context Protocol (MCP) server for accessing Chinese stock market data via [AKShare](https://github.com/akfamily/akshare).

## Features

- 🏢 **Market Overview**: Shanghai and Shenzhen Exchange market statistics data
- 🏢 **Stock Information**: East Money stock information, Xueqiu company profiles
- 🏭 **Industry Sectors**: Industry sector data, real-time quotes, constituent stock information
- 🔥 **Stock Hotness**: A-share popularity rankings, Xueqiu trading rankings
- 📈 **Real-time Quotes**: Shanghai-Shenzhen-Beijing A-share real-time quotes, stock prices, limit-up stock pools
- 📊 **Historical Data**: A-share historical K-line data, Tencent Securities historical data, intraday quotes
- 💰 **Fundamental Analysis**: Financial indicators, profit forecasts, information disclosure announcements
- 📈 **Fund Flow**: Dragon and Tiger list details, individual stock fund flow, institutional participation
- 📰 **News & Updates**: Global financial news, Futu Niuniu updates
- 📊 **Peer Comparison**: Valuation comparison, growth comparison
- 🔧 **Utility Tools**: Stock code lookup, trading calendar, insider trading data, stock research reports

## Installation

```bash
pip install akshare-tools
```

## Usage

### Using MCP Inspector

MCP Inspector is a command-line tool for testing and debugging MCP servers:

```bash
npx @modelcontextprotocol/inspector uvx akshare-tools
```

### Using with MCP Client

Configure in MCP-compatible applications (like Claude Desktop):

```json
{
    "mcpServers": {
      "akshare-mcp": {
        "command": "uvx",
        "args": [
          "akshare-tools"
        ]
      }
    }
}
```

## Available Tools

### 📊 Stock Market Overview
- `get_stock_sse_summary`: Shanghai Stock Exchange stock data summary
- `get_stock_szse_summary`: Shenzhen Stock Exchange market summary - security category statistics

### 🏢 Stock Information
- `get_stock_individual_info_em`: East Money - Individual Stock - Stock Information
- `get_stock_individual_basic_info_xq`: Xueqiu - Individual Stock - Company Profile - Company Introduction

### 🏭 Industry Sectors
- `get_stock_board_industry_name_em`: East Money - Shanghai-Shenzhen-Beijing Sectors - Industry Sector Data
- `get_stock_board_industry_spot_em`: East Money - Shanghai-Shenzhen Sectors - Industry Sector - Real-time Quote Data
- `get_stock_board_industry_cons_em`: East Money - Shanghai-Shenzhen Sectors - Industry Sector - Sector Constituent Stock Data

### 🔥 Stock Hotness
- `get_stock_hot_rank_em`: East Money - Stock Hotness - Popularity Ranking Data
- `get_stock_hot_deal_xq`: Xueqiu - Shanghai-Shenzhen Stock Market - Hotness Ranking - Trading Ranking Data

### 📈 Real-time Quotes
- `get_stock_zh_a_spot_em`: Shanghai-Shenzhen-Beijing A-share Real-time Quote Data
- `get_stock_info_xueqiu`: Xueqiu Individual Stock Real-time Market Data Information
- `get_stock_zt_pool_em`: East Money - Limit-up Stock Pool Data

### 📊 Historical Data
- `get_stock_a_hist`: A-share Historical K-line Data
- `get_stock_zh_a_hist_tx`: Tencent Securities - Daily Frequency - Stock Historical Data
- `get_stock_zh_a_hist_min_em`: East Money - Shanghai-Shenzhen-Beijing A-shares - Daily Intraday Quote Data

### 💰 Fundamental Analysis
- `get_stock_financial_analysis_indicator`: Sina Finance - Financial Analysis - Financial Indicator Data
- `get_stock_profit_forecast_em`: East Money - Data Center - Research Reports - Profit Forecast
- `get_stock_zh_a_disclosure_report_cninfo`: CNINFO - Information Disclosure Announcements

### 📈 Fund Flow
- `get_stock_lhb_detail_em`: East Money - Data Center - Dragon and Tiger List - Dragon and Tiger List Details
- `get_stock_individual_fund_flow`: East Money - Data Center - Individual Stock Fund Flow
- `get_stock_comment_detail_zlkp_jgcyd_em`: East Money - Data Center - Featured Data - Thousands of Comments - Main Control - Institutional Participation Data

### 📰 News & Updates
- `get_stock_info_global_em`: East Money - Global Financial News
- `get_stock_info_global_futu`: Futu Niuniu - Updates

### 📊 Peer Comparison
- `get_stock_zh_valuation_comparison_em`: East Money - Quote Center - Peer Comparison - Valuation Comparison Data
- `get_stock_zh_growth_comparison_em`: East Money - Quote Center - Peer Comparison - Growth Comparison Data

### 🔧 Utility Tools
- `get_stock_info_a_code_name`: Shanghai-Shenzhen-Beijing A-share Stock Codes and Stock Short Names Data (supports fuzzy matching by company name)
- `get_tool_trade_date_hist_sina`: Sina Finance - Stock Trading Calendar Data
- `get_stock_inner_trade_xq`: Xueqiu - Quote Center - Shanghai-Shenzhen Stock Market - Insider Trading Data
- `get_stock_research_report_em`: East Money - Data Center - Research Reports - Individual Stock Research Report Data

## Development

### Install Development Dependencies

```bash
pip install -e ".[dev]"
```

### Run Tests

```bash
pytest
```

### Code Formatting

```bash
black src/
ruff check src/
```

## License

MIT License - see [LICENSE](LICENSE) file for details

## Contributing

Issues and Pull Requests are welcome!

## Related Links

- [AKShare Official Documentation](https://akshare.akfamily.xyz/)
- [Model Context Protocol](https://modelcontextprotocol.io/)
- [FastMCP](https://github.com/jlowin/fastmcp)

---
*Language: [English](README.md) | [中文](README_CN.md)*