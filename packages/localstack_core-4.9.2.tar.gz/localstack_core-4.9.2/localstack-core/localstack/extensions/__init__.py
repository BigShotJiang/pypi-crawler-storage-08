"""Extensions are third-party software modules to customize localstack."""

name = "extensions"
