# Mahoraga

[![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/hingebase/mahoraga/publish-pypi.yml?label=ci&logo=github)](https://github.com/hingebase/mahoraga/actions)
[![GitHub commit activity](https://img.shields.io/github/commit-activity/y/hingebase/mahoraga?logo=github)](https://github.com/hingebase/mahoraga/commits)
[![PyPI - Version](https://img.shields.io/pypi/v/mahoraga)](https://pypi.org/project/mahoraga)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/mahoraga)
![Apache-2.0 License](https://img.shields.io/pypi/l/mahoraga)  
![basedpyright](https://img.shields.io/badge/basedpyright-checked-42b983)
![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)
![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)

A reverse proxy for Python mirrors. [Docs](https://hingebase.github.io/mahoraga/)
