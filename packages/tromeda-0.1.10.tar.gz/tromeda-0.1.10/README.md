# TROPOS Measurement Datafiles (TroMeDa) get_tropos_datafiles

A tool for getting available data-files of TROPOS devices.
