Project description
Albion_GLS
Albion Interface

Installation
pip install Albion_GLS

Designed to work with Albion, Wadiso 6, Sewsan 6, HydroSwmm and Edisan engineering software packages.