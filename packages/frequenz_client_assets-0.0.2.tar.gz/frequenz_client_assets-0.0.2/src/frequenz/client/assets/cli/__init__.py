"""CLI for the Assets API."""
