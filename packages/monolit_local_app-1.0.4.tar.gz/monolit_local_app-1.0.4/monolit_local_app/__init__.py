from monolit_local_app.src import *
from monolit_local_app.server import server
from monolit_local_app.other import info
from flask import jsonify, Request
from os.path import dirname