# (C) Datadog, Inc. 2018-present
# All rights reserved
# Licensed under Simplified BSD License (see LICENSE)
# ruff: noqa
from ..base.utils.limiter import *
