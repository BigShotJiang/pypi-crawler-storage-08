# (C) Datadog, Inc. 2019-present
# All rights reserved
# Licensed under a 3-clause BSD style license (see LICENSE)
METRIC_NAMESPACE_METRICS = 'datadog.agent.metrics'
METRIC_NAMESPACE_PROFILE = 'datadog.agent.profile'
