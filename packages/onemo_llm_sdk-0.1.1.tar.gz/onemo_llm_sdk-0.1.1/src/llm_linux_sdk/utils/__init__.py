from .license_validator import LicenseValidator

__all__ = ["LicenseValidator"]