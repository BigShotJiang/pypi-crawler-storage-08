from importlib.metadata import version

__version__ = version("fast_dynamic_batcher")
