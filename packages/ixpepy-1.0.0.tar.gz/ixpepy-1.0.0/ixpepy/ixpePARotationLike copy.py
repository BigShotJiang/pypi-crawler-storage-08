import os
import numpy

from threeML.plugin_prototype import PluginPrototype
from threeML.data_list import DataList
from threeML.classicMLE.joint_likelihood import JointLikelihood
from threeML.bayesian.bayesian_analysis import BayesianAnalysis
from astromodels.functions.function import Function1D, FunctionMeta
from astromodels.core.model import Model
from astromodels.sources.point_source import PointSource
from astromodels.functions.priors import Uniform_prior
from ixpeobssim.core import pipeline
from ixpeobssim.utils.logging_ import logger
from ixpeobssim.evt.event import xEventFile
from ixpeobssim.core.spline import xInterpolatedUnivariateSpline
from ixpeobssim.evt.align import align_phi, align_stokes_parameters
from ixpeobssim.evt.kislat2015 import xStokesAnalysis
from ixpeobssim.utils.matplotlib_ import plt
from ixpeobssim.irf import load_modf

DEFAULT_IRF_NAME = 'ixpe:obssim20240701:v13'

def get_rotation_angle(modelx_, modely_):
    """
    """
    angles = numpy.arctan2(modely_, modelx_)

    return -angles

def rotate_points_to_x_axis(x_, y_, angle_):
    """
    Rotate arrays of points (x_, y_) in the QN-UN plane to align with the x-axis.
    The rotation angle is derived from the coordinates of each point.
    """    
    # Create a matrix of rotation matrices for each point
    cos_vals = numpy.cos(-angle_)
    sin_vals = numpy.sin(-angle_)
    
    # Apply the rotation to each point
    rotated_x = x_ * cos_vals - y_ * sin_vals
    rotated_y = x_ * sin_vals + y_ * cos_vals
    
    return rotated_x, rotated_y

def xpphasesalign(q_phase_spline, u_phase_spline, offset=0., **kwargs):
    """Run the phi alignmnent with the PA as a function of phi.
       Note: the filelist needs to have the PHASE column. The files should 
       be already cleaned an cut so that th PD derived from the pseudo Stokes
    """
    outlist = []
    file_list = kwargs.get('filelist')
    for file_path in file_list:
        assert file_path.endswith('.fits')
        outfile = file_path.replace('.fits', '_phasealign.fits')
        suffix = kwargs.get('suffix')
        if suffix is not None:
            outfile = outfile.replace('.fits', '_%s.fits' % suffix)
        outlist.append(outfile)
        if os.path.exists(outfile) and not kwargs.get('overwrite'):
            logger.info('Output file %s already exists.', outfile)
            logger.info('Remove it or set "overwrite = True" to overwite it.')
            continue
        # Open the input file and recover the relevant columns.
        input_file = xEventFile(file_path)

        ph = input_file.phase_data()
        q = input_file.q_data()
        u = input_file.u_data()

        # extract the model q and u used to apply the rotation
        model_q = q_phase_spline(ph+offset)
        model_u = u_phase_spline(ph+offset)
        
        ang = get_rotation_angle(model_q, model_u)
        q, u = rotate_points_to_x_axis(q, u, ang)
        # q, u = align_stokes_parameters(q, u, model_q, model_u)

        data = input_file.hdu_list['EVENTS'].data
        data['Q'] = q
        data['U'] = u
        # And we're ready to write the output file!
        logger.info('Writing output file %s', outfile)
        input_file.hdu_list.writeto(outfile, overwrite=True)
    return outlist

def xpphasesalign2(pa_phase_spline, **kwargs):
    """Run the phi alignmnent with the PA as a function of phi.
       Note: the filelist needs to have the PHASE column. The files should 
       be already cleaned an cut so that th PD derived from the pseudo Stokes
    """
    outlist = []
    file_list = kwargs.get('filelist')
    for file_path in file_list:
        assert file_path.endswith('.fits')
        outfile = file_path.replace('.fits', '_phasealign.fits')
        suffix = kwargs.get('suffix')
        if suffix is not None:
            outfile = outfile.replace('.fits', '_%s.fits' % suffix)
        outlist.append(outfile)
        if os.path.exists(outfile) and not kwargs.get('overwrite'):
            logger.info('Output file %s already exists.', outfile)
            logger.info('Remove it or set "overwrite = True" to overwite it.')
            continue
        # Open the input file and recover the relevant columns.
        input_file = xEventFile(file_path)

        ph = input_file.phase_data()
        q = input_file.q_data()
        u = input_file.u_data()

        # extract the model q and u used to apply the rotation
        ang = pa_phase_spline(ph)
        
        q, u = rotate_points_to_x_axis(q, u, ang)

        data = input_file.hdu_list['EVENTS'].data
        data['Q'] = q
        data['U'] = u
        # And we're ready to write the output file!
        logger.info('Writing output file %s', outfile)
        input_file.hdu_list.writeto(outfile, overwrite=True)
    return outlist


class Fourier_series(Function1D, metaclass=FunctionMeta):
    r"""
    description :
        A Fourier series approximation as a function of phase [0,1]

    latex : not available

    parameters :

        a0 :

            desc : a0
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 

        a1 :

            desc : a1
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 

        b1 :

            desc : b1
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 
        
        a2 :

            desc : a2
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 

        b2 :

            desc : b2
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 

        a3 :

            desc : a3
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 

        b3 :

            desc : b3
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad

        a4 :

            desc : a4
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 

        b4 :

            desc : b4
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad

    """
    @staticmethod
    def fourier_series(phi, coeffs):
        """
        Evaluate a Fourier series approximation at a given point phi.

        Parameters:
        phi : float
            The independent variable, between 0 and 1.
        coeffs : list or array
            A list of 9 Fourier coefficients: [a0, a1, b1, a2, b2, a3, b3, a4, b4]
        Returns:
        float
            The value of the Fourier series at phi.
        """
        a0 = coeffs[0]
        result = a0 / 2.0
        harmonics = (len(coeffs) - 1) // 2
        for n in range(1, harmonics + 1):
            a_n = coeffs[2 * n - 1]
            b_n = coeffs[2 * n]
            result += a_n * numpy.cos(2 * numpy.pi * n * phi) + b_n * numpy.sin(2 * numpy.pi * n * phi)
        return result

    def _set_units(self, x_unit, y_unit):
        pass

    # noinspection PyPep8Naming
    def evaluate(self, x, a0, a1, b1, a2, b2, a3, b3, a4, b4):
        coeffs = [a0, a1, b1, a2, b2, a3, b3, a4, b4]
        return self.fourier_series(x, coeffs)


class ixpePARotationLike(PluginPrototype):

    def __init__(self, name, file_list):
        super(ixpePARotationLike,self).__init__(name, {})
        input_file = xEventFile(file_list[0])
        self.ph = input_file.phase_data()
        self.energy = input_file.energy_data()
        modf1 = load_modf(irf_name=DEFAULT_IRF_NAME, du_id=1)
        modf_e = modf1(self.energy)
        self.q = input_file.q_data() / modf_e
        self.u = input_file.u_data() / modf_e
        print(modf1.weighted_average(self.energy))
        modf_aves = [modf1.weighted_average(self.energy)]
        # valuto mu all'energia dell'evento: self.mu
        for i, file_path in enumerate(file_list[1:]):
            i = i + 2
            self.energy = numpy.concatenate((self.energy, input_file.energy_data()))
            modf = load_modf(irf_name=DEFAULT_IRF_NAME, du_id=i)
            modf_e = modf(input_file.energy_data())
            self.ph = numpy.concatenate((self.ph, input_file.phase_data()))
            self.q = numpy.concatenate((self.q, input_file.q_data()/modf_e))
            self.u = numpy.concatenate((self.u, input_file.u_data()/modf_e))
            
            modf_aves.append(modf.weighted_average(self.energy))
    
        self.ave_mu = sum(modf_aves)/3 
        print('Average modulations: ',modf_aves, self.ave_mu )

    @staticmethod
    def rotate_points_to_x_axis(x_, y_, angle_):
        """
        Rotate arrays of points (x_, y_) in the QN-UN plane to align with the x-axis.
        The rotation angle is derived from the coordinates of each point.
        """
        # Create a matrix of rotation matrices for each point
        cos_vals = numpy.cos(-angle_)
        sin_vals = numpy.sin(-angle_)
        
        # Apply the rotation to each point
        rotated_x = x_ * cos_vals - y_ * sin_vals
        rotated_y = x_ * sin_vals + y_ * cos_vals
        
        return rotated_x, rotated_y

    def set_model(self, model):
        # attach the model to the object
        self._model = model

    def get_log_like(self):
        ang = model._point_sources['IXPE_J1723'](self.ph)
        q, u = self.rotate_points_to_x_axis(self.q, self.u, ang)
        Q = numpy.sum(q)
        U = numpy.sum(u)
        pd = numpy.sqrt(Q**2 + U**2) / len(q)
        m = pd * self.ave_mu
        pd_err = numpy.sqrt((2. - m**2.) / ((len(q) - 1.) * self.ave_mu**2.))
        rel_err = 1/ (pd_err / pd)
        # print('------------------------------------- Rel_err', rel_err)
        return rel_err
    
    def inner_fit(self):
        return self.get_log_like()

    def simulate(self, pa, pd=0.5):
        modf = load_modf()
        phi = modf.rvs_phi(self.energy, pd, pa)
        self.q = xStokesAnalysis.stokes_q(phi, weights=None)
        self.u = xStokesAnalysis.stokes_u(phi, weights=None)
        

if __name__ == "__main__":
    BAYES = True
    SIM = False

    name = 'IXPE_J1723'
    folder = '/Users/mnegro/MyDocuments/_IXPE/_IXPE_DATA/SPIDER_PULSARS/PSRJ1723-28/event_l2/'
    folder_sim = '/Users/mnegro/MyDocuments/_IXPE/_IXPE_DATA/SPIDER_PULSARS/PSRJ1723-28/simulations/'

    t, sim_i = numpy.loadtxt('totivt.dat').T
    t, sim_q = numpy.loadtxt('totqvt.dat').T
    t, sim_u = numpy.loadtxt('totuvt.dat').T

    def compute_y(x1, y1, x2, y2, x):
        slope = (y2 - y1) / (x2 - x1)
        intercept = y1 - slope * x1
        y = slope * x + intercept
        return y

    def get_phase(time_array, tmin=265.86, tmax=66465., cycle_num=1.25, ph0=0.75):
        ph = compute_y(tmin, 0, tmax, cycle_num, time_array)
        ph = (ph + ph0) % 1 
        return ph

    ph = get_phase(t)
    sim_qn = sim_q/sim_i
    sim_un = sim_u/sim_i
    sim_pa = 0.5*numpy.arctan2(sim_un,sim_qn)
    
    # folder = '/home/ndilalla/work/ixpe/ixpedata/Spider_pulsar/'
    file_list = [folder + 'ixpe03006799_det%d_evt2_v02_rej_gticorr_bary_psr_folded.fits' % du for du in [1,2,3]]
    file_list = [folder_sim + 'psrj1723_du%d_psr_folded.fits' % du for du in [1,2,3]]

    # add ENERGY dependence

    PHASE_BINNING_LO = numpy.linspace(0, 1, 15)[:-1]
    PHASE_BINNING_HI = numpy.linspace(0, 1, 15)[1:]
    qn1 = []
    un1 = []
    pa1 = []
    pa1err = []

    from ixpeobssim.binning.polarization import xBinnedPolarizationCube
    for min_, max_ in zip(PHASE_BINNING_LO, PHASE_BINNING_HI):
        src_pcubes_list = [folder_sim + 'psrj1723_du1_psr_folded_phase_%.3f_%.3f_pcube.fits'% (min_, max_),
                        folder_sim + 'psrj1723_du2_psr_folded_phase_%.3f_%.3f_pcube.fits'% (min_, max_),
                        folder_sim + 'psrj1723_du3_psr_folded_phase_%.3f_%.3f_pcube.fits'% (min_, max_)
                        ]
        
        pcube_src = xBinnedPolarizationCube.from_file_list(src_pcubes_list)
        qn1.append(pcube_src.QN[0])
        un1.append(pcube_src.UN[0])
        pa1.append(pcube_src.PA[0])
        pa1err.append(pcube_src.PA_ERR[0])

    phase = 0.5*(PHASE_BINNING_LO + PHASE_BINNING_HI)
    phase_err = 0.5*(PHASE_BINNING_HI - PHASE_BINNING_LO)

    fig, ax1 = plt.subplots()
    ax1.plot(phase, qn1, 'o-', label='QN sim', color='tab:blue')
    ax1.plot(phase, un1, 'o-', label='UN sim', color='tab:orange')
    ax1.plot(ph, sim_qn, '.', label='QN teo', color='tab:blue')#, label=r'(Q/I)$^2$')
    ax1.plot(ph, sim_un, '.', label='UN teo', color='tab:orange')#, label=r'(U/I)$^2$')
    plt.legend()

    fig, ax1 = plt.subplots()
    ax1.errorbar(phase, numpy.radians(pa1), yerr=numpy.radians(pa1err), fmt='o-', label='PA sim', color='tab:blue')
    ax1.plot(ph, sim_pa, '.', label='PA teo', color='tab:blue')#, label=r'(Q/I)$^2$')
    plt.legend()
    ##########################################################

    psr = PointSource(name, ra=260.8445729, dec=-28.6329211, 
                      spectral_shape=Fourier_series())
    model = Model(psr)
    model.IXPE_J1723.spectrum.main.Fourier_series.a0 = 0.
    model.IXPE_J1723.spectrum.main.Fourier_series.a0.fix = True
    model.IXPE_J1723.spectrum.main.Fourier_series.a3.fix = False
    model.IXPE_J1723.spectrum.main.Fourier_series.b3.fix = False
    model.IXPE_J1723.spectrum.main.Fourier_series.a4.fix = False
    model.IXPE_J1723.spectrum.main.Fourier_series.b4.fix = False
    
    fp = model.free_parameters
    for i, (key, value) in enumerate(fp.items()):
        value.set_uninformative_prior(Uniform_prior)
    plugin = ixpePARotationLike('%s_plugin' % name, file_list)
    
    # if SIM:
    #     initvalues = [1.0, -2.0, -1.0, 1.0, 0, 0, 0, 0]
    #     for i, (key, value) in enumerate(fp.items()):
    #         value.value = parvalues[i]
        
    #     plt.figure('Results')
    #     phase = numpy.linspace(0,1,100)
    #     angles = model._point_sources[name](phase)
    #     plt.plot(phase, angles, label='Input')
    #     angles = model._point_sources[name](plugin.ph)
    #     plugin.simulate(angles)

    datalist = DataList(plugin)
    model.display()
    
    if BAYES:
        npars = len(fp)
        points = 1000
        like = BayesianAnalysis(model, datalist)
        like.set_sampler("dynesty_nested") #multinest
        like.sampler.setup(n_live_points=points)
        like.sample()
        # print(like.results.get_data_frame())
        like.restore_median_fit()
        like.results.corner_plot()
        label = "bayes_%dpars_%d" % (npars, points)
    else:
        like = JointLikelihood(model, datalist)
        like.fit()
        label = 'jl'

    angle = {}
    plt.figure('Results')
    PHASE_MIN, PHASE_MAX =  0, 1
    phase = numpy.linspace(PHASE_MIN, PHASE_MAX, 100)
    angle['map'] = like.results.optimized_model._point_sources[name](phase)
    plt.plot(phase, angle['map'], label='MAP')
    plt.plot(ph, sim_pa, label='Sim PA')

    par_results = {}
    par_values = []
    for par in ['a1', 'b1', 'a2', 'b2', 'a3', 'b3', 'a4', 'b4']:
        par_results[par] = like.results.get_variates('IXPE_J1723.spectrum.main.Fourier_series.%s' % par)
        par_values.append(par_results[par].value)
    # print(par_results)

    med_model = like.results.get_median_fit_model()
    fp = med_model.free_parameters
    for i, (key, value) in enumerate(fp.items()):
        value.value = par_values[i]
    angle['median'] = med_model._point_sources[name](phase)
    plt.plot(phase, angle['median'], label='Median')
    plt.plot(ph, sim_pa, label='Sim PA')

    #med_model.display()
    plt.legend()

    for l in ['map', 'median']:
        fmt = dict(xlabel='Pulse phase', ylabel='PA')
        pa_phase_spline = xInterpolatedUnivariateSpline(phase, angle[l], k=2, **fmt)
        aligned_folded_files = xpphasesalign2(pa_phase_spline, filelist=file_list, overwrite=True, suffix='fourier_%s_%s' % (label, l))
        
        ENERGY_BINNING = [2, 8]
        pipeline.xpbin(*aligned_folded_files, algorithm='PCUBE', ebinalg='LIST', ebinning=ENERGY_BINNING, 
                       irfname='ixpe:obssim20240701:v13', overwrite=True)
    
    plt.show()

    

