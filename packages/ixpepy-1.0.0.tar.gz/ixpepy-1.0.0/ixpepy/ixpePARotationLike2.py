import os
import numpy
import corner

from threeML.plugin_prototype import PluginPrototype
from threeML.data_list import DataList
from threeML.classicMLE.joint_likelihood import JointLikelihood
from threeML.bayesian.bayesian_analysis import BayesianAnalysis
from threeML.parallel.parallel_client import parallel_computation
from astromodels.functions.function import Function1D, FunctionMeta
from astromodels.functions.functions_1D import Line, StepFunction
from astromodels.core.model import Model
from astromodels.core.model_parser import clone_model
from astromodels.sources.point_source import PointSource
from astromodels.functions.priors import Uniform_prior
from ixpeobssim.core import pipeline
from ixpeobssim.utils.logging_ import logger
from ixpeobssim.evt.event import xEventFile
from ixpeobssim.core.spline import xInterpolatedUnivariateSpline
from ixpeobssim.evt.align import align_phi, align_stokes_parameters
from ixpeobssim.evt.kislat2015 import xStokesAnalysis
from ixpeobssim.utils.matplotlib_ import plt
from ixpeobssim.binning.polarization import xBinnedPolarizationCube
from ixpeobssim.irf import load_modf

DEFAULT_IRF_NAME = 'ixpe:obssim20240701:v13'

def wrap_angles(angles):
    """
    Wrap an array of angles in radians to the range [-pi/2, pi/2].

    Parameters:
    angles (array-like): Input angles in radians.

    Returns:
    numpy.ndarray: Array of wrapped angles in the range [-pi/2, pi/2].
    """
    wrapped_angles = (angles + numpy.pi / 2) % (numpy.pi) - numpy.pi / 2
    return wrapped_angles

def get_rotation_angle(modelx_, modely_):
    """
    """
    angles = numpy.arctan2(modely_, modelx_)

    return -angles

def rotate_points_to_x_axis(x_, y_, angle_):
    """
    Rotate arrays of points (x_, y_) in the QN-UN plane to align with the x-axis.
    The rotation angle is derived from the coordinates of each point.
    """    
    # Create a matrix of rotation matrices for each point
    cos_vals = numpy.cos(-angle_)
    sin_vals = numpy.sin(-angle_)
    
    # Apply the rotation to each point
    rotated_x = x_ * cos_vals - y_ * sin_vals
    rotated_y = x_ * sin_vals + y_ * cos_vals
    
    return rotated_x, rotated_y

def xpphasesalign(q_phase_spline, u_phase_spline, offset=0., **kwargs):
    """Run the phi alignmnent with the PA as a function of phi.
       Note: the filelist needs to have the PHASE column. The files should 
       be already cleaned an cut so that th PD derived from the pseudo Stokes
    """
    outlist = []
    file_list = kwargs.get('filelist')
    for file_path in file_list:
        assert file_path.endswith('.fits')
        outfile = file_path.replace('.fits', '_phasealign.fits')
        suffix = kwargs.get('suffix')
        if suffix is not None:
            outfile = outfile.replace('.fits', '_%s.fits' % suffix)
        outlist.append(outfile)
        if os.path.exists(outfile) and not kwargs.get('overwrite'):
            logger.info('Output file %s already exists.', outfile)
            logger.info('Remove it or set "overwrite = True" to overwite it.')
            continue
        # Open the input file and recover the relevant columns.
        input_file = xEventFile(file_path)

        ph = input_file.phase_data()
        q = input_file.q_data()
        u = input_file.u_data()

        # extract the model q and u used to apply the rotation
        model_q = q_phase_spline(ph+offset)
        model_u = u_phase_spline(ph+offset)
        
        ang = get_rotation_angle(model_q, model_u)
        q, u = rotate_points_to_x_axis(q, u, ang)
        # q, u = align_stokes_parameters(q, u, model_q, model_u)

        data = input_file.hdu_list['EVENTS'].data
        data['Q'] = q
        data['U'] = u
        # And we're ready to write the output file!
        logger.info('Writing output file %s', outfile)
        input_file.hdu_list.writeto(outfile, overwrite=True)
    return outlist

def xpphasesalign2(pa_phase_spline, **kwargs):
    """Run the phi alignmnent with the PA as a function of phi.
       Note: the filelist needs to have the PHASE column. The files should 
       be already cleaned an cut so that th PD derived from the pseudo Stokes
    """
    outlist = []
    file_list = kwargs.get('filelist')
    for file_path in file_list:
        assert file_path.endswith('.fits')
        outfile = file_path.replace('.fits', '_phasealign.fits')
        suffix = kwargs.get('suffix')
        if suffix is not None:
            outfile = outfile.replace('.fits', '_%s.fits' % suffix)
        outlist.append(outfile)
        if os.path.exists(outfile) and not kwargs.get('overwrite'):
            logger.info('Output file %s already exists.', outfile)
            logger.info('Remove it or set "overwrite = True" to overwite it.')
            continue
        # Open the input file and recover the relevant columns.
        input_file = xEventFile(file_path)

        ph = input_file.phase_data()
        q = input_file.q_data()
        u = input_file.u_data()

        # extract the model q and u used to apply the rotation
        ang = pa_phase_spline(ph)
        
        q, u = rotate_points_to_x_axis(q, u, 2 * ang)

        data = input_file.hdu_list['EVENTS'].data
        data['Q'] = q
        data['U'] = u
        # And we're ready to write the output file!
        logger.info('Writing output file %s', outfile)
        input_file.hdu_list.writeto(outfile, overwrite=True)
    return outlist


class Fourier_series(Function1D, metaclass=FunctionMeta):
    r"""
    description :
        A Fourier series approximation as a function of phase [0,1]

    latex : not available

    parameters :

        a0 :

            desc : a0
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 

        a1 :

            desc : a1
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 

        b1 :

            desc : b1
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 
        
        a2 :

            desc : a2
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 

        b2 :

            desc : b2
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 

        a3 :

            desc : a3
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 

        b3 :

            desc : b3
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad

        a4 :

            desc : a4
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 

        b4 :

            desc : b4
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad
        
        a5 :

            desc : a5
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 

        b5 :

            desc : b5
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad

        a6 :

            desc : a6
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad 

        b6 :

            desc : b6
            initial value : 0
            min : -np.pi
            max : +np.pi
            unit: rad

    """
    @staticmethod
    def fourier_series(phi, coeffs):
        """
        Evaluate a Fourier series approximation at a given point phi.

        Parameters:
        phi : float
            The independent variable, between 0 and 1.
        coeffs : list or array
            A list of 13 Fourier coefficients: [a0, a1, b1, a2, b2, a3, b3, a4, b4, a5, b5, a6, b6]
        Returns:
        float
            The value of the Fourier series at phi.
        """
        a0 = coeffs[0]
        result = a0 / 2.0
        harmonics = (len(coeffs) - 1) // 2
        for n in range(1, harmonics + 1):
            a_n = coeffs[2 * n - 1]
            b_n = coeffs[2 * n]
            result += a_n * numpy.cos(2 * numpy.pi * n * phi) + b_n * numpy.sin(2 * numpy.pi * n * phi)
        return result

    def _set_units(self, x_unit, y_unit):
        pass

    # noinspection PyPep8Naming
    def evaluate(self, x, a0, a1, b1, a2, b2, a3, b3, a4, b4, a5, b5, a6, b6):
        coeffs = [a0, a1, b1, a2, b2, a3, b3, a4, b4, a5, b5, a6, b6]
        return self.fourier_series(x, coeffs)

def get_linear_model():
    shape = Line() - StepFunction() - StepFunction()
    shape.a_1 = numpy.radians(0)
    shape.a_1.bounds = (-numpy.radians(200), numpy.radians(200))
    shape.b_1 = 6
    shape.b_1.bounds = (-15, +15)
    shape.lower_bound_2 = 0.25
    shape.lower_bound_2.bounds = (0, 0.5)
    shape.upper_bound_2 = 1.5
    shape.upper_bound_2.fix = True
    shape.value_2 = numpy.radians(0)
    shape.value_2.bounds = (-numpy.radians(200), numpy.radians(200))
    shape.lower_bound_3 = 0.75
    shape.lower_bound_3.bounds = (0.5, 1)
    shape.upper_bound_3 = 1.5
    shape.upper_bound_3.fix = True
    shape.value_3 = numpy.radians(0)
    shape.value_3.bounds = (-numpy.radians(200), numpy.radians(200))
    return shape
    

class ixpePARotationLike(PluginPrototype):
    def __init__(self, name, file_list, emin=2., emax=8.):
        super(ixpePARotationLike,self).__init__(name, {})
        input_file = xEventFile(file_list[0])
        energy = input_file.energy_data()
        mask = (energy > emin) * (energy < emax)
        self.energy = energy[mask]
        self.ph = input_file.phase_data()[mask]
        modf1 = load_modf(irf_name=DEFAULT_IRF_NAME, du_id=1)
        modf_e = modf1(self.energy)
        self.q = input_file.q_data()[mask] / modf_e
        self.u = input_file.u_data()[mask] / modf_e
        print(modf1.weighted_average(self.energy))
        modf_aves = [modf1.weighted_average(self.energy)]
        # valuto mu all'energia dell'evento: self.mu
        for i, file_path in enumerate(file_list[1:]):
            i = i + 2
            energy = input_file.energy_data()
            mask = (energy > emin) * (energy < emax)
            self.energy = numpy.concatenate((self.energy, energy[mask]))
            modf = load_modf(irf_name=DEFAULT_IRF_NAME, du_id=i)
            modf_e = modf(energy[mask])
            self.ph = numpy.concatenate((self.ph, input_file.phase_data()[mask]))
            self.q = numpy.concatenate((self.q, input_file.q_data()[mask]/modf_e))
            self.u = numpy.concatenate((self.u, input_file.u_data()[mask]/modf_e))
            
            modf_aves.append(modf.weighted_average(energy[mask]))
    
        self.ave_mu = numpy.mean(modf_aves)
        print('Average modulations: ', modf_aves, self.ave_mu )
        print('Min/Max phase: %f, %f' % (numpy.min(self.ph), numpy.max(self.ph)))

    @staticmethod
    def rotate_points_to_x_axis(x_, y_, angle_):
        """
        Rotate arrays of points (x_, y_) in the QN-UN plane to align with the x-axis.
        The rotation angle is derived from the coordinates of each point.
        """
        # Create a matrix of rotation matrices for each point
        cos_vals = numpy.cos(-angle_)
        sin_vals = numpy.sin(-angle_)
        
        # Apply the rotation to each point
        rotated_x = x_ * cos_vals - y_ * sin_vals
        rotated_y = x_ * sin_vals + y_ * cos_vals
        
        return rotated_x, rotated_y

    def set_model(self, model):
        # attach the model to the object
        self._model = model

    def get_log_like(self):
        ang = model._point_sources['IXPE_J1723'](self.ph)
        q, u = self.rotate_points_to_x_axis(self.q, self.u, 2 * ang)
        Q = numpy.sum(q)
        U = numpy.sum(u)
        pd = numpy.sqrt(Q**2 + U**2) / len(q)
        m = pd * self.ave_mu
        pd_err = numpy.sqrt((2. - m**2.) / ((len(q) - 1.) * self.ave_mu**2.))
        rel_err = pd / pd_err
        #print('rel_err', rel_err)
        return rel_err
    
    def inner_fit(self):
        return self.get_log_like()

if __name__ == "__main__":
    BAYES = True
    SIM = False
    FOURIER = True
    WRAP = True
    points = 5000
    sampler = 'multinest'

    name = 'IXPE_J1723'
    if SIM:
        # folder = '/home/ndilalla/work/ixpe/ixpedata/Spider_pulsar/simulated_data/'
        # folder = '/home/ndilalla/work/ixpe/ixpedata/Spider_pulsar/simulated_data100/'
        folder = '/home/ndilalla/work/ixpe/ixpedata/Spider_pulsar/simulated_unpol/'
        file_list = [folder + 'psrj1723_du%d_psr_folded.fits' % du for du in [1,2,3]]
        # folder = '/home/ndilalla/work/ixpe/outdata/ixpeobssim/'
        # file_list = [folder + 'toy_periodic_source_du%d_phase.fits' % du for du in [1,2,3]]
    else:
        #folder = '/Users/mnegro/MyDocuments/_IXPE/_IXPE_DATA/SPIDER_PULSARS/PSRJ1723-28/event_l2/'
        folder = '/home/ndilalla/work/ixpe/ixpedata/Spider_pulsar/real_data/'
        # file_list = [folder + 'ixpe03006799_det%d_evt2_v02_rej_gticorr_bary_psr_folded.fits' % du for du in [1,2,3]]
        file_list = [folder + 'ixpe03006799_det%d_evt2_v02_rej_gticorr_bary_psr_folded_select.fits' % du for du in [1,2,3]]

    if FOURIER:
        mod = 'fourier_select'
        shape = Fourier_series()
        shape.a0 = 0.
        shape.a0.fix = True
        shape.a3.fix = False
        shape.b3.fix = False
        shape.a4.fix = False
        shape.b4.fix = False
        shape.a5.fix = False
        shape.b5.fix = False
        shape.a6.fix = False
        shape.b6.fix = False
    else:
        mod = 'linear_select'
        shape = get_linear_model()
        shape.a_1 = numpy.radians(0)
        shape.a_1.fix = True
        shape.b_1 = -2*numpy.pi
        shape.b_1.fix = False
        shape.lower_bound_2 = 0.25
        shape.lower_bound_2.fix = False
        shape.value_2 = numpy.radians(0)
        shape.value_2.fix = False
        shape.lower_bound_3 = 0.75
        shape.lower_bound_3.fix = False
        shape.value_3 = numpy.radians(0)
        shape.value_3.fix = False
    
    psr = PointSource(name, ra=260.8445729, dec=-28.6329211, 
                      spectral_shape=shape)
    model = Model(psr)
    model.display()
    
    fp = model.free_parameters
    npars = len(fp)
    for i, (key, value) in enumerate(fp.items()):
        value.set_uninformative_prior(Uniform_prior)
    plugin = ixpePARotationLike('%s_plugin' % name, file_list)
    datalist = DataList(plugin)
    model.display()

    if False:#SIM:
        plt.figure('model_%s_%dpars' % (mod, npars))
        sim_model = get_linear_model()
        sim_model.a_1 = numpy.radians(0)
        sim_model.lower_bound_2 = 0.25
        sim_model.value_2 = numpy.radians(0)
        sim_model.lower_bound_3 = 0.75
        sim_model.value_3 = numpy.radians(0)
        phase = numpy.linspace(0, 1, 100)
        sim_angle = wrap_angles(sim_model(phase))
        plt.plot(phase, sim_angle, label='Input Model', linewidth=2)
        if WRAP:
            plt.figure('model_%s_%dpars_wrapped' % (mod, npars))
            plt.plot(phase, sim_angle, label='Input Model', linewidth=2)
        # plt.figure('Model')
        # plt.plot(phase, shape(phase), label='Input Model')
        # plt.show()
        # input()
    
    if BAYES:
        like = BayesianAnalysis(model, datalist)
        if sampler == 'multinest':
            like.set_sampler("multinest")
            like.sampler.setup(n_live_points=points)
            like.sample()
        elif sampler == 'ultranest':
            like.set_sampler("ultranest")
            like.sampler.setup(
                min_num_live_points=points, frac_remain=0.5, use_mlfriends=False
            )
            like.sample()
        elif sampler == 'zeus':
            like.set_sampler("zeus")
            like.sampler.setup(n_walkers=20, n_iterations=points)
            with parallel_computation(start_cluster=True, n_jobs=6):
                like.sample()
        else:
            raise RuntimeError
        #print(like.results.get_data_frame())
        like.restore_median_fit()
        corn_fig = like.results.corner_plot()
        corner.overplot_lines(corn_fig, like.results._values, color='red')
        corner.overplot_points(corn_fig, like.results._values[None], marker="s", color='red')
        plt.gcf().canvas.manager.set_window_title('corner_%s_%dpars' % (mod, npars))
        label = "%s_bayes_%dpars_%d" % (mod, npars, points)
    else:
        like = JointLikelihood(model, datalist)
        like.fit()
        label = '%s_jl' % mod

    like_values = like.log_like_values
    id_sort = numpy.argsort(like_values)
    like_values = like_values[id_sort]
    samples = like.raw_samples[id_sort]
    samp_model = clone_model(like.results.optimized_model)
    phase = numpy.linspace(0, 1, 200)
    n_samples = len(samples)
    nsamp_plot = 50
    for sample in samples[n_samples-nsamp_plot:]:
        plt.figure('model_%s_%dpars' % (mod, npars))
        fp = samp_model.free_parameters
        for i, value in enumerate(fp.values()):
            value.value = sample[i]
        angles = samp_model._point_sources[name](phase)
        plt.plot(phase, angles, alpha=0.3)
        if WRAP:
            plt.figure('model_%s_%dpars_wrapped' % (mod, npars))
            plt.plot(phase, wrap_angles(angles), alpha=0.2)

    plt.figure('model_%s_%dpars' % (mod, npars))
    map_label = 'MAP'
    angle = {}
    like.restore_MAP_fit()
    like.results.get_data_frame()
    angle[map_label] = like.results.optimized_model._point_sources[name](phase)
    plt.plot(phase, angle[map_label], label=map_label, linewidth=2)
    if WRAP:
        plt.figure('model_%s_%dpars_wrapped' % (mod, npars))
        plt.plot(phase, wrap_angles(angle[map_label]), label=map_label, linewidth=2)

    plt.figure('model_%s_%dpars' % (mod, npars))
    like.restore_median_fit()
    med_label = 'Median'
    med_model = like.results.get_median_fit_model()
    fp = med_model.free_parameters
    map_values = []
    for i, (key, value) in enumerate(fp.items()):
        par = like.results.get_variates(key)
        value.value = par.median
    med_model.display()
    angle[med_label] = med_model._point_sources[name](phase)
    plt.plot(phase, angle[med_label], label=med_label, linewidth=2)
    plt.legend()
    plt.grid()

    if WRAP:
        plt.figure('model_%s_%dpars_wrapped' % (mod, npars))
        plt.plot(phase, wrap_angles(angle[med_label]), label=med_label, linewidth=2)
        plt.legend()
        plt.grid()


    # like.results.convergence_plots(points // 5, 2)
    like.results.write_to('%s/results_%s.fits' % (folder, label), 
        overwrite=True)

    plt.figure('pcube_%s_%dpars' % (mod, npars))

    prop_cycle = plt.rcParams['axes.prop_cycle']
    colors = prop_cycle.by_key()['color']
    for l, c in zip([map_label, med_label], colors):
        fmt = dict(xlabel='Pulse phase', ylabel='PA')
        pa_phase_spline = xInterpolatedUnivariateSpline(phase, angle[l], k=2, **fmt)
        aligned_folded_files = xpphasesalign2(pa_phase_spline, filelist=file_list, overwrite=True, suffix='%s_%s' % (label, l))
        
        ENERGY_BINNING = [2, 8]
        binned_files = pipeline.xpbin(*aligned_folded_files, algorithm='PCUBE', ebinalg='LIST', ebinning=ENERGY_BINNING, irfname=DEFAULT_IRF_NAME, overwrite=True)

        pcubes = xBinnedPolarizationCube.from_file_list(binned_files)
        pcubes.plot(label=l, marker=True, annotate_energies=False, colors=c, setup_axes=l=='MAP')
    plt.legend()

    plt.show()