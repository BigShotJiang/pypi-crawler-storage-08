"""
Tests for process_raw_data.py utility functions.

This module tests the raw IXPE data processing functionality including
the load_raw_detector_files function.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from ixpepy.utils.process_raw_data import load_raw_detector_files


class TestLoadRawDetectorFiles:
    """Test class for load_raw_detector_files function."""
    
    def test_load_raw_detector_files_success(self):
        """Test successful processing of raw detector files."""
        basename = "test_source"
        datafiles = ["file1.fits", "file2.fits", "file3.fits"]
        ra, dec, rad = 100.0, 20.0, 2.0
        caldb = "/path/to/caldb"
        
        # Mock ixpeobssim availability
        with patch('ixpepy.has_ixpeobssim', True):
            # Mock ixpeobssim modules
            with patch('ixpeobssim.bin.xpselect') as mock_xpselect:
                with patch('ixpeobssim.bin.xpbin') as mock_xpbin:
                    with patch('ixpepy.ixpeOGIPSpectrumLike.ixpeOGIPSpectrumLike') as mock_ixpe:
                        
                        # Setup mocks
                        mock_selections = ["sel1.fits", "sel2.fits", "sel3.fits"]
                        mock_xpselect.xpselect.return_value = mock_selections
                        
                        mock_pha1 = ["pha1_1.fits", "pha1_2.fits", "pha1_3.fits"]
                        mock_pha1u = ["pha1u_1.fits", "pha1u_2.fits", "pha1u_3.fits"]
                        mock_pha1q = ["pha1q_1.fits", "pha1q_2.fits", "pha1q_3.fits"]
                        
                        mock_xpbin.xpbin.side_effect = [mock_pha1, mock_pha1u, mock_pha1q]
                        
                        mock_ixpe_instance = Mock()
                        mock_ixpe.return_value = mock_ixpe_instance
                        mock_ixpe_instance.load_file_list.return_value = mock_ixpe_instance
                        
                        # Call function
                        result = load_raw_detector_files(
                            basename, datafiles, ra, dec, rad, caldb
                        )
                        
                        # Verify xpselect was called correctly
                        mock_xpselect.xpselect.assert_called_once_with(
                            filelist=datafiles, mcsrcid=basename, 
                            ra=ra, dec=dec, rad=rad
                        )
                        
                        # Verify xpbin was called for each algorithm
                        assert mock_xpbin.xpbin.call_count == 3
                        
                        # Verify ixpeOGIPSpectrumLike was created
                        mock_ixpe.assert_called_once_with(
                            energy_range='2-8', caldb=caldb
                        )
                        
                        # Verify load_file_list was called with all files
                        expected_files = mock_pha1 + mock_pha1u + mock_pha1q
                        mock_ixpe_instance.load_file_list.assert_called_once_with(expected_files)
                        
                        # Verify return value
                        assert result == mock_ixpe_instance
        
    def test_load_raw_detector_files_custom_parameters(self):
        """Test processing with custom parameters."""
        basename = "custom_source"
        datafiles = ["custom.fits"]
        ra, dec, rad = 200.0, -30.0, 5.0
        caldb = "/custom/caldb"
        irfname = "ixpe:custom:v1"
        energy_range = "1-10"
        
        with patch('ixpepy.has_ixpeobssim', True):
            with patch('ixpeobssim.bin.xpselect') as mock_xpselect:
                with patch('ixpeobssim.bin.xpbin') as mock_xpbin:
                    with patch('ixpepy.ixpeOGIPSpectrumLike.ixpeOGIPSpectrumLike') as mock_ixpe:
                        
                        # Setup mocks
                        mock_selections = ["sel.fits"]
                        mock_xpselect.xpselect.return_value = mock_selections
                        mock_xpbin.xpbin.return_value = ["pha.fits"]
                        
                        mock_ixpe_instance = Mock()
                        mock_ixpe.return_value = mock_ixpe_instance
                        mock_ixpe_instance.load_file_list.return_value = mock_ixpe_instance
                        
                        # Call function with custom parameters
                        result = load_raw_detector_files(
                            basename, datafiles, ra, dec, rad, caldb,
                            irfname=irfname, energy_range=energy_range
                        )
                        
                        # Verify custom parameters were used
                        mock_ixpe.assert_called_once_with(
                            energy_range=energy_range, caldb=caldb
                        )
                        
                        # Verify xpbin was called with custom irfname
                        xpbin_calls = mock_xpbin.xpbin.call_args_list
                        for call in xpbin_calls:
                            assert call[1]['irfname'] == irfname
        
    def test_load_raw_detector_files_no_ixpeobssim(self):
        """Test error when ixpeobssim is not available."""
        basename = "test_source"
        datafiles = ["file1.fits"]
        ra, dec, rad = 100.0, 20.0, 2.0
        caldb = "/path/to/caldb"
        
        # Mock ixpeobssim not available
        with patch('ixpepy.has_ixpeobssim', False):
            with pytest.raises(AssertionError, match="Must have ixpeobssim to convert raw detector files"):
                load_raw_detector_files(basename, datafiles, ra, dec, rad, caldb)
    
    def test_load_raw_detector_files_empty_filelist(self):
        """Test handling of empty file list."""
        basename = "test_source"
        datafiles = []
        ra, dec, rad = 100.0, 20.0, 2.0
        caldb = "/path/to/caldb"
        
        with patch('ixpepy.has_ixpeobssim', True):
            with patch('ixpeobssim.bin.xpselect') as mock_xpselect:
                with patch('ixpeobssim.bin.xpbin') as mock_xpbin:
                    with patch('ixpepy.ixpeOGIPSpectrumLike.ixpeOGIPSpectrumLike') as mock_ixpe:
                        
                        # Setup mocks for empty case
                        mock_xpselect.xpselect.return_value = []
                        mock_xpbin.xpbin.return_value = []
                        
                        mock_ixpe_instance = Mock()
                        mock_ixpe.return_value = mock_ixpe_instance
                        mock_ixpe_instance.load_file_list.return_value = mock_ixpe_instance
                        
                        # Call function
                        result = load_raw_detector_files(
                            basename, datafiles, ra, dec, rad, caldb
                        )
                        
                        # Should still work with empty lists
                        mock_xpselect.xpselect.assert_called_once()
                        assert mock_xpbin.xpbin.call_count == 3
                        mock_ixpe_instance.load_file_list.assert_called_once_with([])
    
    def test_load_raw_detector_files_ixpeobssim_import_error(self):
        """Test handling of ixpeobssim import errors."""
        basename = "test_source"
        datafiles = ["file1.fits"]
        ra, dec, rad = 100.0, 20.0, 2.0
        caldb = "/path/to/caldb"
        
        with patch('ixpepy.has_ixpeobssim', True):
            # Mock import error
            with patch('ixpeobssim.bin.xpselect', side_effect=ImportError("No module named 'ixpeobssim'")):
                with pytest.raises(ImportError):
                    load_raw_detector_files(basename, datafiles, ra, dec, rad, caldb)
    
    def test_load_raw_detector_files_parameter_types(self):
        """Test that function handles different parameter types correctly."""
        basename = "test_source"
        datafiles = ["file1.fits"]
        ra, dec, rad = 100, 20, 2  # Integers instead of floats
        caldb = "/path/to/caldb"
        
        with patch('ixpepy.has_ixpeobssim', True):
            with patch('ixpeobssim.bin.xpselect') as mock_xpselect:
                with patch('ixpeobssim.bin.xpbin') as mock_xpbin:
                    with patch('ixpepy.ixpeOGIPSpectrumLike.ixpeOGIPSpectrumLike') as mock_ixpe:
                        
                        # Setup mocks
                        mock_xpselect.xpselect.return_value = ["sel.fits"]
                        mock_xpbin.xpbin.return_value = ["pha.fits"]
                        
                        mock_ixpe_instance = Mock()
                        mock_ixpe.return_value = mock_ixpe_instance
                        mock_ixpe_instance.load_file_list.return_value = mock_ixpe_instance
                        
                        # Should work with integer coordinates
                        result = load_raw_detector_files(
                            basename, datafiles, ra, dec, rad, caldb
                        )
                        
                        # Verify coordinates were passed correctly
                        mock_xpselect.xpselect.assert_called_once_with(
                            filelist=datafiles, mcsrcid=basename, 
                            ra=ra, dec=dec, rad=rad
                        )
