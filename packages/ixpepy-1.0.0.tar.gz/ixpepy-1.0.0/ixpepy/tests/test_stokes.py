"""
Tests for stokes.py utility functions.

This module tests the Stokes parameter calculation functions including
polarization angle and polarization degree calculations.
"""

import pytest
import numpy as np
from ixpepy.utils.stokes import get_polarization_angle, get_polarization_degree


class TestStokesCalculations:
    """Test class for Stokes parameter calculations."""
    
    def test_polarization_angle_scalar(self):
        """Test polarization angle calculation with scalar inputs."""
        # Test case: Q=0.1, U=0.0 -> PA = 0 degrees
        pa = get_polarization_angle(0.1, 0.0)
        assert pa == 0.0
        
        # Test case: Q=0.0, U=0.1 -> PA = 45 degrees
        pa = get_polarization_angle(0.0, 0.1)
        assert pa == 45.0
        
        # Test case: Q=-0.1, U=0.1 -> PA = 67.5 degrees
        pa = get_polarization_angle(-0.1, 0.1)
        assert abs(pa - 67.5) < 0.1
        
    def test_polarization_angle_array(self, sample_stokes_data):
        """Test polarization angle calculation with array inputs."""
        q = sample_stokes_data['q']
        u = sample_stokes_data['u']
        expected_pa = sample_stokes_data['expected_pa']
        
        pa = get_polarization_angle(q, u)
        
        # Check that result is numpy array
        assert isinstance(pa, np.ndarray)
        
        # Check shape matches input
        assert pa.shape == q.shape
        
        # Check values are approximately correct
        np.testing.assert_allclose(pa, expected_pa, rtol=0.1)
        
    def test_polarization_angle_edge_cases(self):
        """Test polarization angle calculation edge cases."""
        # Test zero values
        pa = get_polarization_angle(0.0, 0.0)
        assert np.isnan(pa) or pa == 0.0
        
        # Test negative values
        pa = get_polarization_angle(-0.1, -0.1)
        assert abs(pa - 45.0) < 0.1
        
        # Test large values
        pa = get_polarization_angle(1.0, 1.0)
        assert abs(pa - 45.0) < 0.1
        
    def test_polarization_degree_scalar(self):
        """Test polarization degree calculation with scalar inputs."""
        # Test case: Q=0.3, U=0.4 -> PD = 0.5
        pd = get_polarization_degree(0.3, 0.4)
        assert abs(pd - 0.5) < 0.01
        
        # Test case: Q=0.0, U=0.0 -> PD = 0.0
        pd = get_polarization_degree(0.0, 0.0)
        assert pd == 0.0
        
        # Test case: Q=1.0, U=0.0 -> PD = 1.0
        pd = get_polarization_degree(1.0, 0.0)
        assert pd == 1.0
        
    def test_polarization_degree_array(self, sample_stokes_data):
        """Test polarization degree calculation with array inputs."""
        q = sample_stokes_data['q']
        u = sample_stokes_data['u']
        expected_pd = sample_stokes_data['expected_pd']
        
        pd = get_polarization_degree(q, u)
        
        # Check that result is numpy array
        assert isinstance(pd, np.ndarray)
        
        # Check shape matches input
        assert pd.shape == q.shape
        
        # Check values are approximately correct
        np.testing.assert_allclose(pd, expected_pd, rtol=0.1)
        
    def test_polarization_degree_edge_cases(self):
        """Test polarization degree calculation edge cases."""
        # Test negative values
        pd = get_polarization_degree(-0.3, -0.4)
        assert abs(pd - 0.5) < 0.01
        
        # Test large values
        pd = get_polarization_degree(10.0, 0.0)
        assert pd == 10.0
        
        # Test mixed positive/negative
        pd = get_polarization_degree(0.3, -0.4)
        assert abs(pd - 0.5) < 0.01
        
    def test_input_types(self):
        """Test that functions handle different input types correctly."""
        # Test with lists
        q_list = [0.1, 0.2, 0.3]
        u_list = [0.0, 0.1, 0.2]
        
        pa_list = get_polarization_angle(q_list, u_list)
        pd_list = get_polarization_degree(q_list, u_list)
        
        assert isinstance(pa_list, np.ndarray)
        assert isinstance(pd_list, np.ndarray)
        assert len(pa_list) == 3
        assert len(pd_list) == 3
        
        # Test with numpy arrays
        q_array = np.array(q_list)
        u_array = np.array(u_list)
        
        pa_array = get_polarization_angle(q_array, u_array)
        pd_array = get_polarization_degree(q_array, u_array)
        
        np.testing.assert_array_equal(pa_list, pa_array)
        np.testing.assert_array_equal(pd_list, pd_array)
        
    def test_physical_limits(self):
        """Test that results are within physical limits."""
        # Generate random Stokes parameters
        np.random.seed(42)
        q = np.random.uniform(-1, 1, 100)
        u = np.random.uniform(-1, 1, 100)
        
        pa = get_polarization_angle(q, u)
        pd = get_polarization_degree(q, u)
        
        # Polarization angle should be between -90 and +90 degrees
        assert np.all(pa >= -90.0)
        assert np.all(pa <= 90.0)
        
        # Polarization degree should be non-negative
        assert np.all(pd >= 0.0)
        
        # For normalized Stokes parameters, PD should be <= 1
        # (though we don't enforce this in the function)
        assert np.all(pd <= np.sqrt(2))  # Maximum for Q,U in [-1,1]
