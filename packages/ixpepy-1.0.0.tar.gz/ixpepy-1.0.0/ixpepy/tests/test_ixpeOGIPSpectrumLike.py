"""
Tests for ixpeOGIPSpectrumLike.py main class.

This module tests the IXPE OGIP spectrum analysis functionality including
data loading, rebinning, energy range setting, and plugin management.
"""

import pytest
import numpy as np
import os
import tempfile
from unittest.mock import Mock, patch, MagicMock
from astropy.io import fits
from threeML.data_list import DataList

# Import the classes we're testing
from ixpepy.ixpeOGIPSpectrumLike import ixpeOGIPSpectrumLike, ixpeOGIPSpectrumPlugin


class TestIxpeOGIPSpectrumLike:
    """Test class for ixpeOGIPSpectrumLike main class."""
    
    def test_init_default_parameters(self):
        """Test initialization with default parameters."""
        ixpe = ixpeOGIPSpectrumLike()
        
        assert ixpe.energy_range == '2-8'
        assert ixpe.caldb is None
        assert ixpe.use_poisson is True
        assert ixpe.detector_stokes == {}
        assert ixpe.plugins == []
    
    def test_init_custom_parameters(self):
        """Test initialization with custom parameters."""
        ixpe = ixpeOGIPSpectrumLike(
            energy_range='1-10',
            caldb='/custom/caldb',
            use_poisson=False
        )
        
        assert ixpe.energy_range == '1-10'
        assert ixpe.caldb == '/custom/caldb'
        assert ixpe.use_poisson is False
    
    def test_from_basename(self, temp_dir, sample_file_list):
        """Test loading files using basename pattern."""
        # Create mock files
        for filename in sample_file_list:
            filepath = os.path.join(temp_dir, filename)
            with open(filepath, 'w') as f:
                f.write('mock fits content')
        
        ixpe = ixpeOGIPSpectrumLike()
        
        with patch.object(ixpe, 'load_file_list') as mock_load:
            result = ixpe.from_basename(temp_dir, 'toy_point_source')
            
            # Verify load_file_list was called
            mock_load.assert_called_once()
            call_args = mock_load.call_args[0]
            file_list, bkg_file_list = call_args
            
            # Should have 9 files (3 DUs × 3 Stokes)
            assert len(file_list) == 9
            assert bkg_file_list is None
            
            # Check file naming pattern
            assert all('toy_point_source_du' in f for f in file_list)
            assert any('pha1.fits' in f for f in file_list)  # I
            assert any('pha1q.fits' in f for f in file_list)  # Q
            assert any('pha1u.fits' in f for f in file_list)  # U
    
    def test_from_basename_custom_suffix(self, temp_dir):
        """Test from_basename with custom suffix."""
        ixpe = ixpeOGIPSpectrumLike()
        
        with patch.object(ixpe, 'load_file_list') as mock_load:
            ixpe.from_basename(temp_dir, 'test_source', suffix='-')
            
            call_args = mock_load.call_args[0]
            file_list = call_args[0]
            
            # Check custom suffix was used
            assert all('test_source-du' in f for f in file_list)
    
    def test_load_file_list_no_background(self, temp_dir, sample_file_list):
        """Test loading file list without background files."""
        # Create mock files
        for filename in sample_file_list[:3]:  # Just first 3 files
            filepath = os.path.join(temp_dir, filename)
            with open(filepath, 'w') as f:
                f.write('mock fits content')
        
        ixpe = ixpeOGIPSpectrumLike()
        
        with patch.object(ixpe, '_load_file') as mock_load:
            file_list = [os.path.join(temp_dir, f) for f in sample_file_list[:3]]
            ixpe.load_file_list(file_list)
            
            # Should call _load_file for each file
            assert mock_load.call_count == 3
            for i, call in enumerate(mock_load.call_args_list):
                args, kwargs = call
                assert args[0] == file_list[i]
                assert args[1] is None  # No background
                assert kwargs['name'] == 'ixpe'
    
    def test_load_file_list_with_background(self, temp_dir, sample_file_list):
        """Test loading file list with background files."""
        # Create mock files
        source_files = sample_file_list[:3]
        bkg_files = [f.replace('pha1', 'bkg1') for f in source_files]
        
        for filename in source_files + bkg_files:
            filepath = os.path.join(temp_dir, filename)
            with open(filepath, 'w') as f:
                f.write('mock fits content')
        
        ixpe = ixpeOGIPSpectrumLike()
        
        with patch.object(ixpe, '_load_file') as mock_load:
            source_list = [os.path.join(temp_dir, f) for f in source_files]
            bkg_list = [os.path.join(temp_dir, f) for f in bkg_files]
            
            ixpe.load_file_list(source_list, bkg_list)
            
            # Should call _load_file for each file pair
            assert mock_load.call_count == 3
            for i, call in enumerate(mock_load.call_args_list):
                args, kwargs = call
                assert args[0] == source_list[i]
                assert args[1] == bkg_list[i]
    
    def test_load_file_list_mismatched_lengths(self, temp_dir):
        """Test error when source and background lists have different lengths."""
        ixpe = ixpeOGIPSpectrumLike()
        
        source_list = ['file1.fits', 'file2.fits']
        bkg_list = ['bkg1.fits']  # Different length
        
        with pytest.raises(AssertionError):
            ixpe.load_file_list(source_list, bkg_list)
    
    def test_set_energy_range(self):
        """Test setting energy range for all plugins."""
        ixpe = ixpeOGIPSpectrumLike()
        
        # Create mock plugins
        mock_plugin1 = Mock()
        mock_plugin2 = Mock()
        ixpe.plugins = [mock_plugin1, mock_plugin2]
        
        # Set new energy range
        ixpe.set_energy_range('1-10')
        
        # Check that energy range was updated
        assert ixpe.energy_range == '1-10'
        
        # Check that all plugins were updated
        mock_plugin1.set_active_measurements.assert_called_once_with('1-10')
        mock_plugin2.set_active_measurements.assert_called_once_with('1-10')
    
    def test_rebin_on_source(self):
        """Test rebinning on source counts."""
        ixpe = ixpeOGIPSpectrumLike()
        
        # Create mock plugins with different DUs and Stokes
        mock_plugin_i1 = Mock()
        mock_plugin_i1._du = 'DU1'
        mock_plugin_i1._stokes = 'I'
        mock_plugin_i1.rebin_on_source.return_value = 'rebinner_du1'
        
        mock_plugin_q1 = Mock()
        mock_plugin_q1._du = 'DU1'
        mock_plugin_q1._stokes = 'Q'
        
        mock_plugin_i2 = Mock()
        mock_plugin_i2._du = 'DU2'
        mock_plugin_i2._stokes = 'I'
        mock_plugin_i2.rebin_on_source.return_value = 'rebinner_du2'
        
        mock_plugin_u2 = Mock()
        mock_plugin_u2._du = 'DU2'
        mock_plugin_u2._stokes = 'U'
        
        ixpe.plugins = [mock_plugin_i1, mock_plugin_q1, mock_plugin_i2, mock_plugin_u2]
        
        # Perform rebinning
        ixpe.rebin_on_source(10)
        
        # Check that I spectra were rebinned
        mock_plugin_i1.rebin_on_source.assert_called_once_with(10)
        mock_plugin_i2.rebin_on_source.assert_called_once_with(10)
        
        # Check that Q/U spectra had rebinners applied
        mock_plugin_q1._apply_rebinner.assert_called_once_with('rebinner_du1')
        mock_plugin_u2._apply_rebinner.assert_called_once_with('rebinner_du2')
    
    def test_apply_area_correction(self):
        """Test applying area corrections to plugins."""
        ixpe = ixpeOGIPSpectrumLike()
        
        # Create mock plugins
        mock_plugin1 = Mock()
        mock_plugin1.name = 'ixpe_DU1_I'
        mock_plugin2 = Mock()
        mock_plugin2.name = 'ixpe_DU2_Q'
        
        ixpe.plugins = [mock_plugin1, mock_plugin2]
        ixpe.detector_stokes = {
            'ixpe_DU1_I': ('DU1', 'I'),
            'ixpe_DU2_Q': ('DU2', 'Q')
        }
        
        area_corrections = {'DU1': 0.85, 'DU2': 0.80}
        
        with patch('threeML.log') as mock_log:
            ixpe.apply_area_correction(area_corrections)
        
        # Check that corrections were applied
        mock_plugin1.use_effective_area_correction.assert_called_once_with(0.5, 1.2)
        mock_plugin1.fix_effective_area_correction.assert_called_once_with(0.85)
        
        mock_plugin2.use_effective_area_correction.assert_called_once_with(0.5, 1.2)
        mock_plugin2.fix_effective_area_correction.assert_called_once_with(0.80)
    
    def test_fit_area_correction(self):
        """Test enabling area correction fitting."""
        ixpe = ixpeOGIPSpectrumLike()
        
        # Create mock datalist
        mock_datalist = {'plugin1': Mock(), 'plugin2': Mock()}
        
        with patch.object(ixpe, 'get_datalist', return_value=mock_datalist):
            with patch('ixpepy.ixpeOGIPSpectrumLike.ixpeOGIPSpectrumLike._fit_area_correction') as mock_fit:
                mock_model = Mock()
                
                ixpe.fit_area_correction(mock_model, min_value=0.8, max_value=1.2)
                
                # Check that _fit_area_correction was called
                mock_fit.assert_called_once_with(
                    mock_model, mock_datalist, 0.8, 1.2, 'ixpe', False, ''
                )
    
    def test_get_datalist(self):
        """Test getting DataList from plugins."""
        ixpe = ixpeOGIPSpectrumLike()
        
        # Create mock plugins
        mock_plugin1 = Mock()
        mock_plugin2 = Mock()
        ixpe.plugins = [mock_plugin1, mock_plugin2]
        
        with patch('threeML.data_list.DataList') as mock_datalist:
            result = ixpe.get_datalist()
            
            # Check that DataList was created with plugins
            mock_datalist.assert_called_once_with(mock_plugin1, mock_plugin2)
            assert result == mock_datalist.return_value
    
    def test_get_number_of_data_points(self):
        """Test getting total number of data points."""
        ixpe = ixpeOGIPSpectrumLike()
        
        # Create mock plugins with different n_data_points
        mock_plugin1 = Mock()
        mock_plugin1.n_data_points = 10
        mock_plugin2 = Mock()
        mock_plugin2.n_data_points = 15
        mock_plugin3 = Mock()
        mock_plugin3.n_data_points = 5
        
        ixpe.plugins = [mock_plugin1, mock_plugin2, mock_plugin3]
        
        total_points = ixpe.get_number_of_data_points()
        
        assert total_points == 30  # 10 + 15 + 5
    
    def test_get_pha_spectrum_poisson_i(self, mock_fits_file, temp_dir):
        """Test PHA spectrum loading with Poisson errors for Stokes I."""
        # Create temporary FITS file
        fits_file = os.path.join(temp_dir, 'test_I.fits')
        mock_fits_file.writeto(fits_file, overwrite=True)
        
        ixpe = ixpeOGIPSpectrumLike(use_poisson=True)
        
        with patch('threeML.log') as mock_log:
            with patch.object(ixpe, '_sanitize_hdu'):
                with patch.object(ixpe, 'get_irfs', return_value=('test.rsp', 'test.arf')):
                    with patch('threeML.utils.OGIP.pha.PHAII') as mock_phaii:
                        with patch('threeML.utils.spectrum.pha_spectrum.PHASpectrum') as mock_phaspectrum:
                            
                            mock_phaii.from_fits_file.return_value._hdu_list = {'SPECTRUM': mock_fits_file[1]}
                            
                            result = ixpe.get_pha_spectrum(fits_file)
                            
                            name, stokes, du, is_gaussian, pha_spectrum = result
                            
                            # Check results
                            assert stokes == 'I'
                            assert du == 'DU1'
                            assert is_gaussian is False  # Poisson for I
                            assert 'ixpe_DU1_I' in name
    
    def test_get_pha_spectrum_gaussian_qu(self, temp_dir):
        """Test PHA spectrum loading with Gaussian errors for Stokes Q/U."""
        # Create mock FITS file for Q
        hdu = fits.PrimaryHDU()
        hdu.header['DETNAM'] = 'DU1'
        hdu.header['XFLT0001'] = 'Stokes:1'  # Q
        hdu.header['BACKSCAL'] = 1.0
        hdu.header['EXPOSURE'] = 1000.0
        hdu.header['RESPFILE'] = 'test.rsp'
        hdu.header['ANCRFILE'] = 'test.arf'
        
        fits_file = os.path.join(temp_dir, 'test_Q.fits')
        hdu.writeto(fits_file, overwrite=True)
        
        ixpe = ixpeOGIPSpectrumLike(use_poisson=True)
        
        with patch('threeML.log') as mock_log:
            with patch.object(ixpe, '_sanitize_hdu'):
                with patch.object(ixpe, 'get_irfs', return_value=('test.rsp', 'test.arf')):
                    with patch('threeML.utils.OGIP.pha.PHAII') as mock_phaii:
                        with patch('threeML.utils.spectrum.pha_spectrum.PHASpectrum') as mock_phaspectrum:
                            
                            mock_phaii.from_fits_file.return_value._hdu_list = {'SPECTRUM': hdu}
                            
                            result = ixpe.get_pha_spectrum(fits_file)
                            
                            name, stokes, du, is_gaussian, pha_spectrum = result
                            
                            # Check results
                            assert stokes == 'Q'
                            assert du == 'DU1'
                            assert is_gaussian is True  # Gaussian for Q/U
                            assert 'ixpe_DU1_Q' in name


class TestIxpeOGIPSpectrumPlugin:
    """Test class for ixpeOGIPSpectrumPlugin class."""
    
    def test_init(self):
        """Test plugin initialization."""
        mock_observation = Mock()
        
        plugin = ixpeOGIPSpectrumPlugin(
            name='test_plugin',
            observation=mock_observation,
            stokes='I',
            du='DU1'
        )
        
        assert plugin._stokes == 'I'
        assert plugin._du == 'DU1'
    
    def test_init_invalid_stokes(self):
        """Test error for invalid Stokes parameter."""
        mock_observation = Mock()
        
        with pytest.raises(AssertionError):
            ixpeOGIPSpectrumPlugin(
                name='test_plugin',
                observation=mock_observation,
                stokes='X',  # Invalid
                du='DU1'
            )
    
    def test_get_simulated_dataset(self):
        """Test generating simulated dataset."""
        mock_observation = Mock()
        
        plugin = ixpeOGIPSpectrumPlugin(
            name='test_plugin',
            observation=mock_observation,
            stokes='Q',
            du='DU2'
        )
        
        with patch('threeML.plugins.OGIPLike.OGIPLike.get_simulated_dataset') as mock_super:
            mock_super.return_value = 'simulated_plugin'
            
            result = plugin.get_simulated_dataset('sim_name')
            
            # Check that parent method was called with correct parameters
            mock_super.assert_called_once_with(
                'sim_name', stokes='Q', du='DU2'
            )
            assert result == 'simulated_plugin'
