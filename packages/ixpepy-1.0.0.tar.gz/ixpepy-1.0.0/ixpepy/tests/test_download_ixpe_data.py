"""
Tests for download_ixpe_data.py functions.

This module tests the IXPE data download functionality including
file downloading and observation ID handling.
"""

import pytest
import os
import json
import tempfile
from unittest.mock import Mock, patch, mock_open
from ixpepy.io.download_ixpe_data import download_files_from_url, download_obsid, download_source


class TestDownloadFilesFromUrl:
    """Test class for download_files_from_url function."""
    
    def test_download_files_success(self, temp_dir, mock_download_response):
        """Test successful file download."""
        url = "http://example.com/"
        filenames = ["file1.fits", "file2.fits"]
        
        with patch('requests.get', return_value=mock_download_response):
            with patch('builtins.open', mock_open()) as mock_file:
                with patch('os.path.exists', return_value=False):
                    with patch('os.makedirs'):
                        result = download_files_from_url(url, temp_dir, filenames)
        
        # Check that function returns list of local paths
        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0] == os.path.join(temp_dir, "file1.fits")
        assert result[1] == os.path.join(temp_dir, "file2.fits")
        
    def test_download_files_existing_file(self, temp_dir, mock_download_response):
        """Test skipping download of existing files."""
        url = "http://example.com/"
        filenames = ["existing_file.fits"]
        existing_path = os.path.join(temp_dir, "existing_file.fits")
        
        # Mock file exists with correct size
        with patch('requests.get', return_value=mock_download_response):
            with patch('os.path.exists', return_value=True):
                with patch('os.path.getsize', return_value=1024):
                    result = download_files_from_url(url, temp_dir, filenames)
        
        assert len(result) == 1
        assert result[0] == existing_path
        
    def test_download_files_create_directory(self, temp_dir, mock_download_response):
        """Test that destination directory is created if it doesn't exist."""
        url = "http://example.com/"
        filenames = ["test.fits"]
        new_dir = os.path.join(temp_dir, "new_subdir")
        
        with patch('requests.get', return_value=mock_download_response):
            with patch('builtins.open', mock_open()):
                with patch('os.path.exists', side_effect=[False, False]):  # dir doesn't exist, file doesn't exist
                    with patch('os.makedirs') as mock_makedirs:
                        download_files_from_url(url, new_dir, filenames)
        
        mock_makedirs.assert_called_once_with(new_dir, exist_ok=True)
        
    def test_download_files_url_normalization(self, temp_dir, mock_download_response):
        """Test that URL is normalized to end with /."""
        url = "http://example.com"  # No trailing slash
        filenames = ["test.fits"]
        
        with patch('requests.get', return_value=mock_download_response) as mock_get:
            with patch('builtins.open', mock_open()):
                with patch('os.path.exists', return_value=False):
                    with patch('os.makedirs'):
                        download_files_from_url(url, temp_dir, filenames)
        
        # Check that URL was normalized
        expected_url = "http://example.com/test.fits"
        mock_get.assert_called_once()
        call_args = mock_get.call_args[0]
        assert call_args[0] == expected_url
        
    def test_download_files_error_handling(self, temp_dir):
        """Test error handling during download."""
        url = "http://example.com/"
        filenames = ["error_file.fits"]
        
        # Mock request to raise exception
        with patch('requests.get', side_effect=Exception("Network error")):
            with patch('os.path.exists', return_value=False):
                with patch('os.makedirs'):
                    result = download_files_from_url(url, temp_dir, filenames)
        
        # Should return empty list on error
        assert result == []
        
    def test_download_files_mixed_success_failure(self, temp_dir, mock_download_response):
        """Test handling of mixed success/failure scenarios."""
        url = "http://example.com/"
        filenames = ["good_file.fits", "bad_file.fits"]
        
        def mock_get_side_effect(url, **kwargs):
            if "good_file" in url:
                return mock_download_response
            else:
                raise Exception("Download failed")
        
        with patch('requests.get', side_effect=mock_get_side_effect):
            with patch('builtins.open', mock_open()):
                with patch('os.path.exists', return_value=False):
                    with patch('os.makedirs'):
                        result = download_files_from_url(url, temp_dir, filenames)
        
        # Should return only successful downloads
        assert len(result) == 1
        assert result[0] == os.path.join(temp_dir, "good_file.fits")


class TestDownloadObsid:
    """Test class for download_obsid function."""
    
    def test_download_obsid_xpqlt(self, temp_dir, mock_obsid_db):
        """Test downloading XPQLT files for an observation ID."""
        obs_id = "01001099"
        
        with patch('ixpepy.io.download_ixpe_data.download_obsid_db') as mock_db:
            with patch('builtins.open', mock_open(read_data=json.dumps(mock_obsid_db))):
                with patch('ixpepy.io.download_ixpe_data.download_files_from_url') as mock_download:
                    download_obsid(obs_id, destination=temp_dir, xpqlt=True)
        
        # Check that database was called
        mock_db.assert_called_once_with(update=True)
        
        # Check that download was called with correct parameters
        mock_download.assert_called_once()
        call_args = mock_download.call_args
        url_base, destination, filenames = call_args[0]
        
        assert destination == temp_dir
        assert len(filenames) == 3  # DU1, DU2, DU3
        assert all("du" in fname.lower() for fname in filenames)
        
    def test_download_obsid_original(self, temp_dir, mock_obsid_db):
        """Test downloading original compressed files for an observation ID."""
        obs_id = "01001099"
        
        with patch('ixpepy.io.download_ixpe_data.download_obsid_db') as mock_db:
            with patch('builtins.open', mock_open(read_data=json.dumps(mock_obsid_db))):
                with patch('ixpepy.io.download_ixpe_data.download_files_from_url') as mock_download:
                    download_obsid(obs_id, destination=temp_dir, xpqlt=False)
        
        # Check that download was called with original files
        mock_download.assert_called_once()
        call_args = mock_download.call_args
        url_base, destination, filenames = call_args[0]
        
        assert destination == temp_dir
        assert len(filenames) == 3  # DU1, DU2, DU3
        assert all(".gz" in fname for fname in filenames)
        
    def test_download_obsid_default_destination(self, mock_obsid_db):
        """Test that default destination is used when none specified."""
        obs_id = "01001099"
        
        with patch('ixpepy.io.download_ixpe_data.download_obsid_db'):
            with patch('builtins.open', mock_open(read_data=json.dumps(mock_obsid_db))):
                with patch('ixpepy.io.download_ixpe_data.download_files_from_url') as mock_download:
                    with patch('ixpepy.IXPE_DATA', '/default/data/path'):
                        download_obsid(obs_id)
        
        # Check that default destination was used
        call_args = mock_download.call_args
        destination = call_args[0][1]
        expected_destination = "/default/data/path/001001099"
        assert destination == expected_destination
        
    def test_download_obsid_invalid_id(self, mock_obsid_db):
        """Test error handling for invalid observation ID."""
        obs_id = "99999999"  # Not in database
        
        with patch('ixpepy.io.download_ixpe_data.download_obsid_db'):
            with patch('builtins.open', mock_open(read_data=json.dumps(mock_obsid_db))):
                with pytest.raises(RuntimeError, match="Obs ID 99999999 not available"):
                    download_obsid(obs_id)
        
    def test_download_obsid_update_db_false(self, temp_dir, mock_obsid_db):
        """Test that database update can be disabled."""
        obs_id = "01001099"
        
        with patch('ixpepy.io.download_ixpe_data.download_obsid_db') as mock_db:
            with patch('builtins.open', mock_open(read_data=json.dumps(mock_obsid_db))):
                with patch('ixpepy.io.download_ixpe_data.download_files_from_url'):
                    download_obsid(obs_id, destination=temp_dir, update_db=False)
        
        # Check that database was called with update=False
        mock_db.assert_called_once_with(update=False)
        
    def test_download_obsid_obs_id_conversion(self, temp_dir, mock_obsid_db):
        """Test that observation ID is properly converted to string."""
        obs_id = 1001099  # Integer input
        
        with patch('ixpepy.io.download_ixpe_data.download_obsid_db'):
            with patch('builtins.open', mock_open(read_data=json.dumps(mock_obsid_db))):
                with patch('ixpepy.io.download_ixpe_data.download_files_from_url') as mock_download:
                    download_obsid(obs_id, destination=temp_dir)
        
        # Should work with integer input
        mock_download.assert_called_once()


class TestDownloadSource:
    """Test class for download_source function."""
    
    def test_download_source_success(self, temp_dir):
        """Test successful download of all observations for a source."""
        source_name = "Crab"
        
        # Mock source database with multiple observations
        mock_source_db = {
            "Crab": {
                "srctype": "PWN",
                "ra": 83.633,
                "dec": 22.015,
                "is_extended": True,
                "obsids": {
                    "1001099": {},
                    "1001199": {}
                }
            }
        }
        
        with patch('ixpepy.io.download_ixpe_data.download_source_obsid_db') as mock_source_db_fn:
            with patch('builtins.open', mock_open(read_data=json.dumps(mock_source_db))):
                with patch('ixpepy.io.download_ixpe_data.download_obsid') as mock_download_obsid:
                    result = download_source(source_name, destination=temp_dir)
        
        # Check that database function was called
        mock_source_db_fn.assert_called_once_with(update=True)
        
        # Check that download_obsid was called for each observation
        assert mock_download_obsid.call_count == 2
        
        # Check return value
        assert len(result) == 2
        assert "1001099" in result
        assert "1001199" in result
    
    def test_download_source_invalid_name(self):
        """Test error handling for invalid source name."""
        source_name = "NonExistentSource"
        
        mock_source_db = {
            "Crab": {
                "srctype": "PWN",
                "obsids": {"1001099": {}}
            }
        }
        
        with patch('ixpepy.io.download_ixpe_data.download_source_obsid_db'):
            with patch('builtins.open', mock_open(read_data=json.dumps(mock_source_db))):
                with pytest.raises(RuntimeError, match="Source 'NonExistentSource' not available"):
                    download_source(source_name)
    
    def test_download_source_no_observations(self):
        """Test error handling when source has no observations."""
        source_name = "EmptySource"
        
        mock_source_db = {
            "EmptySource": {
                "srctype": "Unknown",
                "obsids": {}
            }
        }
        
        with patch('ixpepy.io.download_ixpe_data.download_source_obsid_db'):
            with patch('builtins.open', mock_open(read_data=json.dumps(mock_source_db))):
                with pytest.raises(RuntimeError, match="No observations found for source"):
                    download_source(source_name)
    
    def test_download_source_xpqlt_false(self, temp_dir):
        """Test downloading original compressed files."""
        source_name = "Her X-1"
        
        mock_source_db = {
            "Her X-1": {
                "srctype": "X-ray binary",
                "ra": 254.458,
                "dec": 35.342,
                "is_extended": False,
                "obsids": {"1001899": {}}
            }
        }
        
        with patch('ixpepy.io.download_ixpe_data.download_source_obsid_db'):
            with patch('builtins.open', mock_open(read_data=json.dumps(mock_source_db))):
                with patch('ixpepy.io.download_ixpe_data.download_obsid') as mock_download_obsid:
                    download_source(source_name, destination=temp_dir, xpqlt=False)
        
        # Check that download_obsid was called with xpqlt=False
        mock_download_obsid.assert_called_once()
        call_kwargs = mock_download_obsid.call_args[1]
        assert call_kwargs['xpqlt'] is False
    
    def test_download_source_update_db_false(self, temp_dir):
        """Test that database update can be disabled."""
        source_name = "Cyg X-1"
        
        mock_source_db = {
            "Cyg X-1": {
                "srctype": "X-ray binary",
                "obsids": {"1001401": {}}
            }
        }
        
        with patch('ixpepy.io.download_ixpe_data.download_source_obsid_db') as mock_source_db_fn:
            with patch('builtins.open', mock_open(read_data=json.dumps(mock_source_db))):
                with patch('ixpepy.io.download_ixpe_data.download_obsid'):
                    download_source(source_name, destination=temp_dir, update_db=False)
        
        # Check that database was called with update=False
        mock_source_db_fn.assert_called_once_with(update=False)
    
    def test_download_source_default_destination(self):
        """Test that default destination organizes files by source name."""
        source_name = "Mrk 501"
        
        mock_source_db = {
            "Mrk 501": {
                "srctype": "Blazar",
                "obsids": {"1004501": {}}
            }
        }
        
        with patch('ixpepy.io.download_ixpe_data.download_source_obsid_db'):
            with patch('builtins.open', mock_open(read_data=json.dumps(mock_source_db))):
                with patch('ixpepy.io.download_ixpe_data.download_obsid') as mock_download_obsid:
                    with patch('ixpepy.IXPE_DATA', '/default/data/path'):
                        download_source(source_name)
        
        # Check that destination includes source name
        call_kwargs = mock_download_obsid.call_args[1]
        destination = call_kwargs['destination']
        assert "Mrk_501" in destination  # Spaces replaced with underscores
        assert "01004501" in destination
    
    def test_download_source_partial_failure(self, temp_dir):
        """Test handling of partial download failures."""
        source_name = "Test Source"
        
        mock_source_db = {
            "Test Source": {
                "srctype": "Test",
                "obsids": {
                    "1001099": {},
                    "1001199": {},
                    "1001299": {}
                }
            }
        }
        
        # Mock download_obsid to fail for second observation
        def mock_download_side_effect(obs_id, **kwargs):
            if obs_id == "1001199":
                raise Exception("Download failed")
            return None
        
        with patch('ixpepy.io.download_ixpe_data.download_source_obsid_db'):
            with patch('builtins.open', mock_open(read_data=json.dumps(mock_source_db))):
                with patch('ixpepy.io.download_ixpe_data.download_obsid', side_effect=mock_download_side_effect):
                    result = download_source(source_name, destination=temp_dir)
        
        # Should return only successful downloads
        assert len(result) == 2
        assert "1001099" in result
        assert "1001299" in result
        assert "1001199" not in result
    
    def test_download_source_special_characters_in_name(self, temp_dir):
        """Test handling of source names with special characters."""
        source_name = "4U 1626-67"
        
        mock_source_db = {
            "4U 1626-67": {
                "srctype": "X-ray binary",
                "obsids": {"1002701": {}}
            }
        }
        
        with patch('ixpepy.io.download_ixpe_data.download_source_obsid_db'):
            with patch('builtins.open', mock_open(read_data=json.dumps(mock_source_db))):
                with patch('ixpepy.io.download_ixpe_data.download_obsid') as mock_download_obsid:
                    with patch('ixpepy.IXPE_DATA', '/data'):
                        download_source(source_name)
        
        # Check that destination path was created properly
        call_kwargs = mock_download_obsid.call_args[1]
        destination = call_kwargs['destination']
        # Spaces should be replaced with underscores
        assert "4U_1626-67" in destination or "4U 1626-67" in destination
