"""
Test runner script for ixpepy test suite.

This script provides a convenient way to run all tests or specific test modules.
"""

import sys
import os
import pytest

# Add the parent directory to the path so we can import ixpepy
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def run_all_tests():
    """Run all tests in the test suite."""
    test_dir = os.path.dirname(os.path.abspath(__file__))
    return pytest.main([test_dir, '-v', '--tb=short'])


def run_specific_test(test_module):
    """Run a specific test module."""
    test_dir = os.path.dirname(os.path.abspath(__file__))
    test_file = os.path.join(test_dir, f'test_{test_module}.py')
    
    if not os.path.exists(test_file):
        print(f"Test file {test_file} not found!")
        return 1
    
    return pytest.main([test_file, '-v', '--tb=short'])


def run_tests_with_coverage():
    """Run tests with coverage reporting."""
    test_dir = os.path.dirname(os.path.abspath(__file__))
    return pytest.main([
        test_dir, 
        '-v', 
        '--tb=short',
        '--cov=ixpepy',
        '--cov-report=html',
        '--cov-report=term-missing'
    ])


if __name__ == '__main__':
    if len(sys.argv) > 1:
        if sys.argv[1] == '--coverage':
            exit_code = run_tests_with_coverage()
        else:
            exit_code = run_specific_test(sys.argv[1])
    else:
        exit_code = run_all_tests()
    
    sys.exit(exit_code)
