"""
Pytest configuration and fixtures for ixpepy tests.

This module provides common fixtures and test configuration for the ixpepy test suite.
"""

import pytest
import numpy as np
import tempfile
import os
from unittest.mock import Mock, patch
from astropy.io import fits


@pytest.fixture
def temp_dir():
    """Create a temporary directory for test files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def sample_stokes_data():
    """Provide sample Stokes Q and U values for testing."""
    return {
        'q': np.array([0.1, 0.0, -0.1, 0.2]),
        'u': np.array([0.0, 0.1, 0.1, -0.1]),
        'expected_pa': np.array([0.0, 45.0, 67.5, -13.5]),  # degrees
        'expected_pd': np.array([0.1, 0.1, 0.1414, 0.2236])  # approximate
    }


@pytest.fixture
def mock_fits_file():
    """Create a mock FITS file for testing."""
    hdu = fits.PrimaryHDU()
    hdu.header['DETNAM'] = 'DU1'
    hdu.header['XFLT0001'] = 'Stokes:0'
    hdu.header['BACKSCAL'] = 1.0
    hdu.header['EXPOSURE'] = 1000.0
    hdu.header['RESPFILE'] = 'test.rsp'
    hdu.header['ANCRFILE'] = 'test.arf'
    
    # Create spectrum data
    n_channels = 10
    spectrum_data = np.zeros(n_channels, dtype=[
        ('CHANNEL', 'i4'),
        ('COUNTS', 'i4'),
        ('STAT_ERR', 'f4'),
        ('RATE', 'f4')
    ])
    
    spectrum_data['CHANNEL'] = np.arange(1, n_channels + 1)
    spectrum_data['COUNTS'] = np.random.poisson(10, n_channels)
    spectrum_data['STAT_ERR'] = np.sqrt(spectrum_data['COUNTS'])
    spectrum_data['RATE'] = spectrum_data['COUNTS'] / 1000.0
    
    spectrum_hdu = fits.BinTableHDU(spectrum_data, name='SPECTRUM')
    
    hdul = fits.HDUList([hdu, spectrum_hdu])
    return hdul


@pytest.fixture
def sample_file_list():
    """Provide a sample list of IXPE data files."""
    return [
        'toy_point_source_du1_pha1.fits',
        'toy_point_source_du1_pha1q.fits',
        'toy_point_source_du1_pha1u.fits',
        'toy_point_source_du2_pha1.fits',
        'toy_point_source_du2_pha1q.fits',
        'toy_point_source_du2_pha1u.fits',
        'toy_point_source_du3_pha1.fits',
        'toy_point_source_du3_pha1q.fits',
        'toy_point_source_du3_pha1u.fits'
    ]


@pytest.fixture
def mock_download_response():
    """Mock response for download testing."""
    response = Mock()
    response.headers = {'Content-Length': '1024'}
    response.iter_content.return_value = [b'fake data chunk']
    response.raise_for_status.return_value = None
    return response


@pytest.fixture
def mock_obsid_db():
    """Mock observation database for testing."""
    return {
        "01001099": {
            "xpqlt_url_fits_du1": "http://example.com/obs_du1_pha1.fits",
            "xpqlt_url_fits_du2": "http://example.com/obs_du2_pha1.fits", 
            "xpqlt_url_fits_du3": "http://example.com/obs_du3_pha1.fits",
            "origin_url_gz_du1": "http://example.com/obs_du1.fits.gz",
            "origin_url_gz_du2": "http://example.com/obs_du2.fits.gz",
            "origin_url_gz_du3": "http://example.com/obs_du3.fits.gz"
        }
    }
