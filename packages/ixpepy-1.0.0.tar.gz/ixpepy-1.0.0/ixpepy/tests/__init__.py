"""
Test suite for ixpepy package.

This package contains unit tests for all ixpepy modules including:
- Stokes parameter calculations
- Data download utilities
- OGIP spectrum analysis
- Raw data processing
"""
