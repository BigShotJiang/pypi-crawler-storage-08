import os
import matplotlib.pyplot as plt
import numpy as np

from threeML import *

from astromodels.core.polarization import *
try:
    import ixpepy
except RuntimeError:
    print("Oops! ixpepy is not imported!")

from ixpepy.ixpePolarizationCubeLike import ixpePolarizationCubeLike

update_logging_level("DEBUG")

ixpe=ixpePolarizationCubeLike('IXPE')

data_dir='/media/ndilalla/ExtremeSSD/ixpe/ixpeobssim/'
#input_file_basename = 'point_source_pol_xp'
input_file_basename = 'point_source_pol'
ixpe.load_LTCube('%s/%s_du1_ixpesim_recon_simfmt_ltcube.fits' % (data_dir,input_file_basename))
ixpe.load_CMAPCUBE('%s/%s_du1_ixpesim_recon_simfmt_pmapcube.fits' % (data_dir,input_file_basename))
ixpe.set_energy_dispersion(False)
ixpe.set_QU_chromatism(True, 3)
ixpe.plot_PSF_kernel()
ra_src, dec_src = 30. , 45.
ixpe.plot_QU_kernel()

pl_norm  = 10.8
pl_index = -1.91
#KQ       =4.8e-2
#KU       =8.5e-2
KQ       =2.37e-1
KU       =4.0e-1
# KQ = 0
# KU = 0


spectral_model = Powerlaw()
polarization   = StokesPolarization(Q=Constant(), U=Constant())
source1        = PointSource('source1', ra_src, dec_src, spectral_shape=spectral_model, polarization=polarization)
#source2        = PointSource('source2', 30.05, 45.1, spectral_shape=spectral_model, polarization=polarization)

model = Model(source1)
model.source1.spectrum.main.Powerlaw.K     = pl_norm
model.source1.spectrum.main.Powerlaw.index = pl_index

model.source1.spectrum.main.polarization.Q.Constant.k = KQ
model.source1.spectrum.main.polarization.U.Constant.k = KU
model.source1.spectrum.main.polarization.Q.Constant.k.free = True
model.source1.spectrum.main.polarization.U.Constant.k.free = True

model.display(complete=True)

datalist = DataList(ixpe)
like = JointLikelihood(model, datalist, verbose=True)
#like.fit()
ixpe.summaryPlot('source1')
plt.show()
