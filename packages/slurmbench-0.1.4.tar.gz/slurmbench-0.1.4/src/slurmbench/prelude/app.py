"""App prelude."""

# Due to typer usage:
# ruff: noqa: PLC0414

from slurmbench.app import new as new
