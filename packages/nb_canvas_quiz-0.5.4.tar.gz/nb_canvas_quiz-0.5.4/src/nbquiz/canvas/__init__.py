"""
Helpers for Canvas
"""
