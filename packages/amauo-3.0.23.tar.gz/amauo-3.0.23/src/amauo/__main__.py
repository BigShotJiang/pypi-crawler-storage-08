"""Entry point for running amauo as a module."""

from amauo.cli import cli

if __name__ == "__main__":
    cli()
