from enum import Enum


class UserRole(Enum):
    ADMIN = 'admin'
    USER = 'user'