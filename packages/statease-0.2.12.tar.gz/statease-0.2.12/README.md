# statease

**statease** is a Python package to integrate Python with Stat-Ease 360.

## Installation

statease can be installed using `pip`, which will install the dependencies
automatically.

    pip install statease

## Documentation

See https://statease.com/docs/se360/python-integration/.

## License

**statease** is licensed under a proprietary license. Details can be found in the `LICENSE` file.
