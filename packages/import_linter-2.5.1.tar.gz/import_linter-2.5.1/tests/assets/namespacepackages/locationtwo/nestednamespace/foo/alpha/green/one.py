from nestednamespace.foo.alpha.blue import one

from ....bar.beta import orange
