from canonicalwebteam.flask_base import worker

__all__ = ["worker"]
