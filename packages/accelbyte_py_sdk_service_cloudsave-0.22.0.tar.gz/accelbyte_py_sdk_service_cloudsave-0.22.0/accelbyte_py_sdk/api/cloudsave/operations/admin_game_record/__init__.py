# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Cloudsave Service."""

__version__ = "3.27.0"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .admin_delete_game_recor_636983 import AdminDeleteGameRecordHandlerV1
from .admin_get_game_record_h_f6ed3a import AdminGetGameRecordHandlerV1
from .admin_post_game_record__9a2084 import AdminPostGameRecordHandlerV1
from .admin_put_game_record_h_0dd624 import AdminPutGameRecordHandlerV1
from .list_game_records_handler_v1 import ListGameRecordsHandlerV1
