function(keys, values) {
    return sum(values);
}