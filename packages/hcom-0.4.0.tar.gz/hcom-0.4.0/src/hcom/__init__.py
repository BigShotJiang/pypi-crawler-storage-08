"""Claude Hook Comms - Real-time messaging between Claude Code agents."""

__version__ = "0.4.0"