from schemathesis.specs.openapi.types import v3

__all__ = ["v3"]
