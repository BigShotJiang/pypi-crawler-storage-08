# Econometrics extension for OpenBB Platform

This extension provides a set of econometrics tools.

## Installation

To install the extension, run the following command in this folder:

```bash
pip install openbb-econometrics
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
