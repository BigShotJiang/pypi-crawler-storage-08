# -*- coding: utf-8 -*-

from tccli.services.ocr.ocr_client import action_caller
    