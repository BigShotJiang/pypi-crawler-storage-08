The API reference is automatically built from the source code and uploaded
to our [website](https://magnet.gitlabpages.inria.fr/declearn/docs/latest/api).
This file is just a placeholder for the docs that are included as part of
the project's main gitlab repository.

You may build this doc locally: please refer to the dedicated section of
the developers' guide on [building the docs](../devs-guide/docs-build.md).
