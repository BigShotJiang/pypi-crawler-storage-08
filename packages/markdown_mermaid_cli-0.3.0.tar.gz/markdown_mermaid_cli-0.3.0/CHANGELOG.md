# Changelog

## [v0.3.0](https://github.com/hkato/markdown-mermaid-cli/releases/tag/v0.3.0) - 2025-10-09

- `default_format` option by @SpeakinTelnet in #7

## [v0.2.3](https://github.com/hkato/markdown-mermaid-cli/releases/tag/v0.2.3) - 2025-10-07

- Windows OS support by @SpeakinTelnet in #6

## [v0.2.2](https://github.com/hkato/markdown-mermaid-cli/releases/tag/v0.2.2) - 2025-08-15

- Add --disable-gpu to puppeteer-config.json by @noggynoggy in #4

### Changed

- Image format option from 'image' to 'format'

## [v0.2.0](https://github.com/hkato/markdown-mermaid-cli/releases/tag/v0.2.0) - 2025-04-26

### Changed

- Image format option from 'image' to 'format'

### Added

- Add support img tag attributes and mermaid-cli(mmdc) options

- Support [Diagram options](https://docs.kroki.io/kroki/setup/diagram-options/)

## [v0.1.0](https://github.com/hkato/markdown-mermaid-cli/releases/tag/v0.1.0) - 2025-04-20

Initial Release
