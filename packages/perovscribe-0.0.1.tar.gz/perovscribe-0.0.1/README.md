# perovskite-extraction

## Getting started

To use type:
    perovscribe <filepath>
