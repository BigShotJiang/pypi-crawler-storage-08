"""
Insurance Premium Prediction MCP Server

FastMCP 기반 보험료 예측 서버
"""

__version__ = "1.0.0"

from .server import mcp

__all__ = ["mcp"]

