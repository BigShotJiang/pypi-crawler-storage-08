# Hold

A Python library for sending spam emails (for educational purposes only).

## Installation

```bash
pip install Hold
```

## Usage

```python
from Hold import send_spam_email

# Replace with the target email address
target_email = "example@example.com"
send_spam_email(target_email)
```

## Disclaimer

This tool is provided for educational purposes only. Misuse of this tool for illegal activities is strictly prohibited. The author is not responsible for any misuse or damage caused by this software.

