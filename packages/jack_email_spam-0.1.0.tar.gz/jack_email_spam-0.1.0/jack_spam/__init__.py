
from .spam_sender import send_spam_email

