"""
Module containing different pipelines as functions.
"""
from .select_subset_sqlite import run_select_subset_sqlite
