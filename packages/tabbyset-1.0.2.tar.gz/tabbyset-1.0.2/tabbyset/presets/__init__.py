"""
This module contains the presets for the tabbyset package.
"""

from .multiheader_configs import msgtype_multiheader_config
