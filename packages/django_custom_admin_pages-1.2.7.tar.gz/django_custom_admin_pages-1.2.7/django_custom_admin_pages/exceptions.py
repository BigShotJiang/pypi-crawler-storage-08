class CustomAdminImportException(Exception):
    pass
