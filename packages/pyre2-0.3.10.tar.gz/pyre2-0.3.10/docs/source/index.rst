Welcome to the Pyre2 documentation!
===================================

.. toctree::
    :caption: Contents:
    :maxdepth: 3

    README
    api/modules
    CHANGELOG


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
