import torch

class Test:
  def __init__():
    pass