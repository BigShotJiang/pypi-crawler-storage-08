from setuptools import setup, find_packages
#
setup(
    name='pixegami_hello',
    version='0.2',
    packages=find_packages()
)