# Installing

```shell
python3 -m pip install 'grafana_foundation_sdk==1759918510!10.1.0'
```
