---
title: <span class="badge object-type-enum"></span> ResultFormat
---
# <span class="badge object-type-enum"></span> ResultFormat

## Definition

```python
class ResultFormat(enum.StrEnum):
    TABLE = "table"
    TIME_SERIES = "time_series"
    TRACE = "trace"
```
