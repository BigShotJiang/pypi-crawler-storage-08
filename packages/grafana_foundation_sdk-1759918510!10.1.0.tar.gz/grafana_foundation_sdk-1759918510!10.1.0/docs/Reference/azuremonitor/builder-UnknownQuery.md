---
title: <span class="badge builder"></span> UnknownQuery
---
# <span class="badge builder"></span> UnknownQuery

## Constructor

```python
UnknownQuery()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> azuremonitor.UnknownQuery
```

### <span class="badge object-method"></span> raw_query

```python
def raw_query(raw_query: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [UnknownQuery](./object-UnknownQuery.md)
