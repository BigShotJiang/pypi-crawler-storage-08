---
title: <span class="badge builder"></span> SubscriptionsQuery
---
# <span class="badge builder"></span> SubscriptionsQuery

## Constructor

```python
SubscriptionsQuery()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> azuremonitor.SubscriptionsQuery
```

### <span class="badge object-method"></span> raw_query

```python
def raw_query(raw_query: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [SubscriptionsQuery](./object-SubscriptionsQuery.md)
