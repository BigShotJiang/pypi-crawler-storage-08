---
title: <span class="badge builder"></span> BaseGrafanaTemplateVariableQuery
---
# <span class="badge builder"></span> BaseGrafanaTemplateVariableQuery

## Constructor

```python
BaseGrafanaTemplateVariableQuery()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> azuremonitor.BaseGrafanaTemplateVariableQuery
```

### <span class="badge object-method"></span> raw_query

```python
def raw_query(raw_query: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [BaseGrafanaTemplateVariableQuery](./object-BaseGrafanaTemplateVariableQuery.md)
