---
title: <span class="badge object-type-disjunction"></span> GrafanaTemplateVariableQuery
---
# <span class="badge object-type-disjunction"></span> GrafanaTemplateVariableQuery

## Definition

```python
GrafanaTemplateVariableQuery: typing.TypeAlias = typing.Union[azuremonitor.AppInsightsMetricNameQuery, azuremonitor.AppInsightsGroupByQuery, azuremonitor.SubscriptionsQuery, azuremonitor.ResourceGroupsQuery, azuremonitor.ResourceNamesQuery, azuremonitor.MetricNamespaceQuery, azuremonitor.MetricDefinitionsQuery, azuremonitor.MetricNamesQuery, azuremonitor.WorkspacesQuery, azuremonitor.UnknownQuery]
```
