---
title: <span class="badge builder"></span> AppInsightsGroupByQuery
---
# <span class="badge builder"></span> AppInsightsGroupByQuery

## Constructor

```python
AppInsightsGroupByQuery()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> azuremonitor.AppInsightsGroupByQuery
```

### <span class="badge object-method"></span> metric_name

```python
def metric_name(metric_name: str) -> typing.Self
```

### <span class="badge object-method"></span> raw_query

```python
def raw_query(raw_query: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [AppInsightsGroupByQuery](./object-AppInsightsGroupByQuery.md)
