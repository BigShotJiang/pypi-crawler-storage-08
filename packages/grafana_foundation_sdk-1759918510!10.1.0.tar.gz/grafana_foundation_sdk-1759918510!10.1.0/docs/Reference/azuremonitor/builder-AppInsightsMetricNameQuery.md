---
title: <span class="badge builder"></span> AppInsightsMetricNameQuery
---
# <span class="badge builder"></span> AppInsightsMetricNameQuery

## Constructor

```python
AppInsightsMetricNameQuery()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> azuremonitor.AppInsightsMetricNameQuery
```

### <span class="badge object-method"></span> raw_query

```python
def raw_query(raw_query: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [AppInsightsMetricNameQuery](./object-AppInsightsMetricNameQuery.md)
