---
title: <span class="badge object-type-enum"></span> DebugMode
---
# <span class="badge object-type-enum"></span> DebugMode

## Definition

```python
class DebugMode(enum.StrEnum):
    RENDER = "render"
    EVENTS = "events"
    CURSOR = "cursor"
    STATE = "State"
    THROW_ERROR = "ThrowError"
```
