---
title: <span class="badge object-type-enum"></span> QueryFormat
---
# <span class="badge object-type-enum"></span> QueryFormat

## Definition

```python
class QueryFormat(enum.IntEnum):
    TIMESERIES = 0
    TABLE = 1
```
