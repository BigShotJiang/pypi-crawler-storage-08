---
title: <span class="badge object-type-enum"></span> OrderByDirection
---
# <span class="badge object-type-enum"></span> OrderByDirection

## Definition

```python
class OrderByDirection(enum.StrEnum):
    ASC = "ASC"
    DESC = "DESC"
```
