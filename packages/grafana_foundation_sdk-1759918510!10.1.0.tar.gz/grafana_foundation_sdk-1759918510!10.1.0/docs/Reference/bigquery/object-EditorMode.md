---
title: <span class="badge object-type-enum"></span> EditorMode
---
# <span class="badge object-type-enum"></span> EditorMode

## Definition

```python
class EditorMode(enum.StrEnum):
    CODE = "code"
    BUILDER = "builder"
```
