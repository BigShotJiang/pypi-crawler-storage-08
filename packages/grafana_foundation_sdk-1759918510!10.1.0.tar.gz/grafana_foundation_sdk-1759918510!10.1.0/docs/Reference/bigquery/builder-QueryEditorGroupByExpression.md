---
title: <span class="badge builder"></span> QueryEditorGroupByExpression
---
# <span class="badge builder"></span> QueryEditorGroupByExpression

## Constructor

```python
QueryEditorGroupByExpression()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> bigquery.QueryEditorGroupByExpression
```

### <span class="badge object-method"></span> property_val

```python
def property_val(property_val: cogbuilder.Builder[bigquery.QueryEditorProperty]) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [QueryEditorGroupByExpression](./object-QueryEditorGroupByExpression.md)
