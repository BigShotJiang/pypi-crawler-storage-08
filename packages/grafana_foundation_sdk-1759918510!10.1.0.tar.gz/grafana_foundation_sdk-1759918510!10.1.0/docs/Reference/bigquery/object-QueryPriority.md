---
title: <span class="badge object-type-enum"></span> QueryPriority
---
# <span class="badge object-type-enum"></span> QueryPriority

## Definition

```python
class QueryPriority(enum.StrEnum):
    INTERACTIVE = "INTERACTIVE"
    BATCH = "BATCH"
```
