---
title: <span class="badge object-type-enum"></span> QueryEditorPropertyType
---
# <span class="badge object-type-enum"></span> QueryEditorPropertyType

## Definition

```python
class QueryEditorPropertyType(enum.StrEnum):
    STRING = "string"
```
