---
title: <span class="badge object-type-enum"></span> LegendPlacement
---
# <span class="badge object-type-enum"></span> LegendPlacement

TODO docs

## Definition

```python
class LegendPlacement(enum.StrEnum):
    """
    TODO docs
    """

    BOTTOM = "bottom"
    RIGHT = "right"
```
