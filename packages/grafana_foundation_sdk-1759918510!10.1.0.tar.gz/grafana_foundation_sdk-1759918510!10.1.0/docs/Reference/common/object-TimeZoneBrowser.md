---
title: <span class="badge object-type-scalar"></span> TimeZoneBrowser
---
# <span class="badge object-type-scalar"></span> TimeZoneBrowser

Use the timezone defined by end user web browser

## Definition

```python
# Use the timezone defined by end user web browser
TimeZoneBrowser: typing.Literal["browser"] = "browser"
```
