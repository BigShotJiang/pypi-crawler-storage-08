---
title: <span class="badge object-type-map"></span> Labels
---
# <span class="badge object-type-map"></span> Labels

## Definition

```python
Labels: typing.TypeAlias = dict[str, str]
```
