---
title: <span class="badge builder"></span> OptionsWithTextFormatting
---
# <span class="badge builder"></span> OptionsWithTextFormatting

## Constructor

```python
OptionsWithTextFormatting()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> common.OptionsWithTextFormatting
```

### <span class="badge object-method"></span> text

```python
def text(text: cogbuilder.Builder[common.VizTextDisplayOptions]) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [OptionsWithTextFormatting](./object-OptionsWithTextFormatting.md)
