---
title: <span class="badge object-type-enum"></span> GraphTresholdsStyleMode
---
# <span class="badge object-type-enum"></span> GraphTresholdsStyleMode

TODO docs

## Definition

```python
class GraphTresholdsStyleMode(enum.StrEnum):
    """
    TODO docs
    """

    OFF = "off"
    LINE = "line"
    DASHED = "dashed"
    AREA = "area"
    LINE_AND_AREA = "line+area"
    DASHED_AND_AREA = "dashed+area"
    SERIES = "series"
```
