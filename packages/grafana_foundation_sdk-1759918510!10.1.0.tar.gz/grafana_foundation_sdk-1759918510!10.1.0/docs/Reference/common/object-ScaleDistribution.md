---
title: <span class="badge object-type-enum"></span> ScaleDistribution
---
# <span class="badge object-type-enum"></span> ScaleDistribution

TODO docs

## Definition

```python
class ScaleDistribution(enum.StrEnum):
    """
    TODO docs
    """

    LINEAR = "linear"
    LOG = "log"
    ORDINAL = "ordinal"
    SYMLOG = "symlog"
```
