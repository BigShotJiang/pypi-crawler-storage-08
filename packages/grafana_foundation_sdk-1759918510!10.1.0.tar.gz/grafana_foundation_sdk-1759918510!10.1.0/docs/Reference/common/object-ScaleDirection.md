---
title: <span class="badge object-type-enum"></span> ScaleDirection
---
# <span class="badge object-type-enum"></span> ScaleDirection

TODO docs

## Definition

```python
class ScaleDirection(enum.IntEnum):
    """
    TODO docs
    """

    UP = 1
    RIGHT = 1
    DOWN = -1
    LEFT = -1
```
