---
title: <span class="badge object-type-enum"></span> VisibilityMode
---
# <span class="badge object-type-enum"></span> VisibilityMode

TODO docs

## Definition

```python
class VisibilityMode(enum.StrEnum):
    """
    TODO docs
    """

    AUTO = "auto"
    NEVER = "never"
    ALWAYS = "always"
```
