---
title: <span class="badge object-type-enum"></span> BigValueJustifyMode
---
# <span class="badge object-type-enum"></span> BigValueJustifyMode

TODO docs

## Definition

```python
class BigValueJustifyMode(enum.StrEnum):
    """
    TODO docs
    """

    AUTO = "auto"
    CENTER = "center"
```
