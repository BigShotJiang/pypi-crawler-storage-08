---
title: <span class="badge object-type-enum"></span> AxisPlacement
---
# <span class="badge object-type-enum"></span> AxisPlacement

TODO docs

## Definition

```python
class AxisPlacement(enum.StrEnum):
    """
    TODO docs
    """

    AUTO = "auto"
    TOP = "top"
    RIGHT = "right"
    BOTTOM = "bottom"
    LEFT = "left"
    HIDDEN = "hidden"
```
