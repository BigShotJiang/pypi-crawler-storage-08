---
title: <span class="badge builder"></span> ColorDimensionConfig
---
# <span class="badge builder"></span> ColorDimensionConfig

## Constructor

```python
ColorDimensionConfig()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> common.ColorDimensionConfig
```

### <span class="badge object-method"></span> field

fixed: T -- will be added by each element

```python
def field(field: str) -> typing.Self
```

### <span class="badge object-method"></span> fixed

color value

```python
def fixed(fixed: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [ColorDimensionConfig](./object-ColorDimensionConfig.md)
