---
title: <span class="badge builder"></span> OptionsWithLegend
---
# <span class="badge builder"></span> OptionsWithLegend

## Constructor

```python
OptionsWithLegend()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> common.OptionsWithLegend
```

### <span class="badge object-method"></span> legend

```python
def legend(legend: cogbuilder.Builder[common.VizLegendOptions]) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [OptionsWithLegend](./object-OptionsWithLegend.md)
