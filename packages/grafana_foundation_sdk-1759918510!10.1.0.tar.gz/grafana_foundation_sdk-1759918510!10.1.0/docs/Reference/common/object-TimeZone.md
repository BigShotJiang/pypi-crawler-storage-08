---
title: <span class="badge object-type-scalar"></span> TimeZone
---
# <span class="badge object-type-scalar"></span> TimeZone

A specific timezone from https://en.wikipedia.org/wiki/Tz_database

## Definition

```python
# A specific timezone from https://en.wikipedia.org/wiki/Tz_database
TimeZone: typing.TypeAlias = str
```
