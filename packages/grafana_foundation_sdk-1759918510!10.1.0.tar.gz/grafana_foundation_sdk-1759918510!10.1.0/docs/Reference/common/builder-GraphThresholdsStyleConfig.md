---
title: <span class="badge builder"></span> GraphThresholdsStyleConfig
---
# <span class="badge builder"></span> GraphThresholdsStyleConfig

## Constructor

```python
GraphThresholdsStyleConfig()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> common.GraphThresholdsStyleConfig
```

### <span class="badge object-method"></span> mode

```python
def mode(mode: common.GraphTresholdsStyleMode) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [GraphThresholdsStyleConfig](./object-GraphThresholdsStyleConfig.md)
