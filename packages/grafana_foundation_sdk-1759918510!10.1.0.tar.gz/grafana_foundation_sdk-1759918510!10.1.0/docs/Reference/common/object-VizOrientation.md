---
title: <span class="badge object-type-enum"></span> VizOrientation
---
# <span class="badge object-type-enum"></span> VizOrientation

TODO docs

## Definition

```python
class VizOrientation(enum.StrEnum):
    """
    TODO docs
    """

    AUTO = "auto"
    VERTICAL = "vertical"
    HORIZONTAL = "horizontal"
```
