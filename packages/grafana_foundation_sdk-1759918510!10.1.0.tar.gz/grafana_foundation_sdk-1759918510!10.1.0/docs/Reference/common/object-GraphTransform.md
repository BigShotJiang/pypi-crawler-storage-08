---
title: <span class="badge object-type-enum"></span> GraphTransform
---
# <span class="badge object-type-enum"></span> GraphTransform

TODO docs

## Definition

```python
class GraphTransform(enum.StrEnum):
    """
    TODO docs
    """

    CONSTANT = "constant"
    NEGATIVE_Y = "negative-Y"
```
