---
title: <span class="badge object-type-enum"></span> FieldTextAlignment
---
# <span class="badge object-type-enum"></span> FieldTextAlignment

TODO -- should not be table specific!

TODO docs

## Definition

```python
class FieldTextAlignment(enum.StrEnum):
    """
    TODO -- should not be table specific!
    TODO docs
    """

    AUTO = "auto"
    LEFT = "left"
    RIGHT = "right"
    CENTER = "center"
```
