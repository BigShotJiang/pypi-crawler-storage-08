---
title: <span class="badge builder"></span> BaseDimensionConfig
---
# <span class="badge builder"></span> BaseDimensionConfig

## Constructor

```python
BaseDimensionConfig()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> common.BaseDimensionConfig
```

### <span class="badge object-method"></span> field

fixed: T -- will be added by each element

```python
def field(field: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [BaseDimensionConfig](./object-BaseDimensionConfig.md)
