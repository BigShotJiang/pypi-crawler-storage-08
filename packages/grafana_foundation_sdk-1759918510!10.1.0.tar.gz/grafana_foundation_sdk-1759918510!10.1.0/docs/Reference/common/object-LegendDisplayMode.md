---
title: <span class="badge object-type-enum"></span> LegendDisplayMode
---
# <span class="badge object-type-enum"></span> LegendDisplayMode

TODO docs

Note: "hidden" needs to remain as an option for plugins compatibility

## Definition

```python
class LegendDisplayMode(enum.StrEnum):
    """
    TODO docs
    Note: "hidden" needs to remain as an option for plugins compatibility
    """

    LIST = "list"
    TABLE = "table"
    HIDDEN = "hidden"
```
