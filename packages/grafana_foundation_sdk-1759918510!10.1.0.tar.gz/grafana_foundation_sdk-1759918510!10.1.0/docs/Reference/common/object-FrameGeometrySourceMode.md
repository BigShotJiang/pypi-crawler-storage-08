---
title: <span class="badge object-type-enum"></span> FrameGeometrySourceMode
---
# <span class="badge object-type-enum"></span> FrameGeometrySourceMode

## Definition

```python
class FrameGeometrySourceMode(enum.StrEnum):
    AUTO = "auto"
    GEOHASH = "geohash"
    COORDS = "coords"
    LOOKUP = "lookup"
```
