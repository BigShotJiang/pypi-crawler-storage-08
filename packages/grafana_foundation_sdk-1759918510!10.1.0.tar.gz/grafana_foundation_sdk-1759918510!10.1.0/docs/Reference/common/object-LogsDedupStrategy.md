---
title: <span class="badge object-type-enum"></span> LogsDedupStrategy
---
# <span class="badge object-type-enum"></span> LogsDedupStrategy

## Definition

```python
class LogsDedupStrategy(enum.StrEnum):
    NONE = "none"
    EXACT = "exact"
    NUMBERS = "numbers"
    SIGNATURE = "signature"
```
