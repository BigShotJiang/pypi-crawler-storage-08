---
title: <span class="badge object-type-enum"></span> TextDimensionMode
---
# <span class="badge object-type-enum"></span> TextDimensionMode

## Definition

```python
class TextDimensionMode(enum.StrEnum):
    FIXED = "fixed"
    FIELD = "field"
    TEMPLATE = "template"
```
