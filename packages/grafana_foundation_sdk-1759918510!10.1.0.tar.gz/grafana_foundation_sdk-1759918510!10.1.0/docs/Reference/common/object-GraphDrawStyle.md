---
title: <span class="badge object-type-enum"></span> GraphDrawStyle
---
# <span class="badge object-type-enum"></span> GraphDrawStyle

TODO docs

## Definition

```python
class GraphDrawStyle(enum.StrEnum):
    """
    TODO docs
    """

    LINE = "line"
    BARS = "bars"
    POINTS = "points"
```
