---
title: <span class="badge object-type-scalar"></span> TimeZoneUtc
---
# <span class="badge object-type-scalar"></span> TimeZoneUtc

Use UTC/GMT timezone

## Definition

```python
# Use UTC/GMT timezone
TimeZoneUtc: typing.Literal["utc"] = "utc"
```
