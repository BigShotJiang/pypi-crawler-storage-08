---
title: <span class="badge object-type-enum"></span> LogsSortOrder
---
# <span class="badge object-type-enum"></span> LogsSortOrder

## Definition

```python
class LogsSortOrder(enum.StrEnum):
    DESCENDING = "Descending"
    ASCENDING = "Ascending"
```
