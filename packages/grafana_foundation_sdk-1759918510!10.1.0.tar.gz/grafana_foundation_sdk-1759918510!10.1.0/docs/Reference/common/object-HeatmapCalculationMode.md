---
title: <span class="badge object-type-enum"></span> HeatmapCalculationMode
---
# <span class="badge object-type-enum"></span> HeatmapCalculationMode

## Definition

```python
class HeatmapCalculationMode(enum.StrEnum):
    SIZE = "size"
    COUNT = "count"
```
