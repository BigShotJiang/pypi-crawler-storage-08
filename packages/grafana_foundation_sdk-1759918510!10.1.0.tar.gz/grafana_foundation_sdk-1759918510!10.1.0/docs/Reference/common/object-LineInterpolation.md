---
title: <span class="badge object-type-enum"></span> LineInterpolation
---
# <span class="badge object-type-enum"></span> LineInterpolation

TODO docs

## Definition

```python
class LineInterpolation(enum.StrEnum):
    """
    TODO docs
    """

    LINEAR = "linear"
    SMOOTH = "smooth"
    STEP_BEFORE = "stepBefore"
    STEP_AFTER = "stepAfter"
```
