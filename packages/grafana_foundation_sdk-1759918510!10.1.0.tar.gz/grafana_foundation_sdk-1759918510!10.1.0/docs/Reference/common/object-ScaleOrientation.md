---
title: <span class="badge object-type-enum"></span> ScaleOrientation
---
# <span class="badge object-type-enum"></span> ScaleOrientation

TODO docs

## Definition

```python
class ScaleOrientation(enum.IntEnum):
    """
    TODO docs
    """

    HORIZONTAL = 0
    VERTICAL = 1
```
