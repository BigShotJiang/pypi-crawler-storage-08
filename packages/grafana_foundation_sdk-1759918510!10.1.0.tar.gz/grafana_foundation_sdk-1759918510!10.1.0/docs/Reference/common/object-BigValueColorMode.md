---
title: <span class="badge object-type-enum"></span> BigValueColorMode
---
# <span class="badge object-type-enum"></span> BigValueColorMode

TODO docs

## Definition

```python
class BigValueColorMode(enum.StrEnum):
    """
    TODO docs
    """

    VALUE = "value"
    BACKGROUND = "background"
    BACKGROUND_SOLID = "background_solid"
    NONE = "none"
```
