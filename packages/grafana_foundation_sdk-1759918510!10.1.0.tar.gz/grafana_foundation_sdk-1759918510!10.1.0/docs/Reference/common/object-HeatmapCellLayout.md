---
title: <span class="badge object-type-enum"></span> HeatmapCellLayout
---
# <span class="badge object-type-enum"></span> HeatmapCellLayout

## Definition

```python
class HeatmapCellLayout(enum.StrEnum):
    LE = "le"
    GE = "ge"
    UNKNOWN = "unknown"
    AUTO = "auto"
```
