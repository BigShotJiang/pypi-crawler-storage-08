---
title: <span class="badge object-type-enum"></span> BigValueTextMode
---
# <span class="badge object-type-enum"></span> BigValueTextMode

TODO docs

## Definition

```python
class BigValueTextMode(enum.StrEnum):
    """
    TODO docs
    """

    AUTO = "auto"
    VALUE = "value"
    VALUE_AND_NAME = "value_and_name"
    NAME = "name"
    NONE = "none"
```
