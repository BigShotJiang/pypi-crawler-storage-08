---
title: <span class="badge object-type-enum"></span> BarAlignment
---
# <span class="badge object-type-enum"></span> BarAlignment

TODO docs

## Definition

```python
class BarAlignment(enum.IntEnum):
    """
    TODO docs
    """

    BEFORE = -1
    CENTER = 0
    AFTER = 1
```
