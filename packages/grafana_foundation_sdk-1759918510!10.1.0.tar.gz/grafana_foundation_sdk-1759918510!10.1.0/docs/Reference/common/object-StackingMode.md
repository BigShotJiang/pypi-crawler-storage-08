---
title: <span class="badge object-type-enum"></span> StackingMode
---
# <span class="badge object-type-enum"></span> StackingMode

TODO docs

## Definition

```python
class StackingMode(enum.StrEnum):
    """
    TODO docs
    """

    NONE = "none"
    NORMAL = "normal"
    PERCENT = "percent"
```
