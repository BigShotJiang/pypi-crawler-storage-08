---
title: <span class="badge object-type-enum"></span> SortOrder
---
# <span class="badge object-type-enum"></span> SortOrder

TODO docs

## Definition

```python
class SortOrder(enum.StrEnum):
    """
    TODO docs
    """

    ASCENDING = "asc"
    DESCENDING = "desc"
    NONE = "none"
```
