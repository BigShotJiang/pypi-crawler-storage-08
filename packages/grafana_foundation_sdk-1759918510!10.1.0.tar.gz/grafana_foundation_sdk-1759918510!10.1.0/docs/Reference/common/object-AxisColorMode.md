---
title: <span class="badge object-type-enum"></span> AxisColorMode
---
# <span class="badge object-type-enum"></span> AxisColorMode

TODO docs

## Definition

```python
class AxisColorMode(enum.StrEnum):
    """
    TODO docs
    """

    TEXT = "text"
    SERIES = "series"
```
