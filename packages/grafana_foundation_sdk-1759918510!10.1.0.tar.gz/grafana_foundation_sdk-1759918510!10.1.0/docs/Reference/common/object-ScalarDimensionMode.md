---
title: <span class="badge object-type-enum"></span> ScalarDimensionMode
---
# <span class="badge object-type-enum"></span> ScalarDimensionMode

## Definition

```python
class ScalarDimensionMode(enum.StrEnum):
    MOD = "mod"
    CLAMPED = "clamped"
```
