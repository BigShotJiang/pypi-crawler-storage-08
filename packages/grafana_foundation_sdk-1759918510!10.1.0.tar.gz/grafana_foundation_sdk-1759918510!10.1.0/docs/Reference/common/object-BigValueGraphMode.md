---
title: <span class="badge object-type-enum"></span> BigValueGraphMode
---
# <span class="badge object-type-enum"></span> BigValueGraphMode

TODO docs

## Definition

```python
class BigValueGraphMode(enum.StrEnum):
    """
    TODO docs
    """

    NONE = "none"
    LINE = "line"
    AREA = "area"
```
