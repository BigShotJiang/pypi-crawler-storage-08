---
title: <span class="badge object-type-enum"></span> GraphGradientMode
---
# <span class="badge object-type-enum"></span> GraphGradientMode

TODO docs

## Definition

```python
class GraphGradientMode(enum.StrEnum):
    """
    TODO docs
    """

    NONE = "none"
    OPACITY = "opacity"
    HUE = "hue"
    SCHEME = "scheme"
```
