---
title: <span class="badge object-type-enum"></span> ResourceDimensionMode
---
# <span class="badge object-type-enum"></span> ResourceDimensionMode

## Definition

```python
class ResourceDimensionMode(enum.StrEnum):
    FIXED = "fixed"
    FIELD = "field"
    MAPPING = "mapping"
```
