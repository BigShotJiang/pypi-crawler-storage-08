---
title: <span class="badge object-type-enum"></span> TooltipDisplayMode
---
# <span class="badge object-type-enum"></span> TooltipDisplayMode

TODO docs

## Definition

```python
class TooltipDisplayMode(enum.StrEnum):
    """
    TODO docs
    """

    SINGLE = "single"
    MULTI = "multi"
    NONE = "none"
```
