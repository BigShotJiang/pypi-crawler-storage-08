---
title: <span class="badge object-type-enum"></span> ScaleDimensionMode
---
# <span class="badge object-type-enum"></span> ScaleDimensionMode

## Definition

```python
class ScaleDimensionMode(enum.StrEnum):
    LINEAR = "linear"
    QUAD = "quad"
```
