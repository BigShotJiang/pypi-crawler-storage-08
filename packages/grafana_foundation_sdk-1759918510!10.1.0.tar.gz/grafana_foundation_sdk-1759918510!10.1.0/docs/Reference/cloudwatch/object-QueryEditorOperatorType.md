---
title: <span class="badge object-type-disjunction"></span> QueryEditorOperatorType
---
# <span class="badge object-type-disjunction"></span> QueryEditorOperatorType

## Definition

```python
QueryEditorOperatorType: typing.TypeAlias = typing.Union[str, bool, int]
```
