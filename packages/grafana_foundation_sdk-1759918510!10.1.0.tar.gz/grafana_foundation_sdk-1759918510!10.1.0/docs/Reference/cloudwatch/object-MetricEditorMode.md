---
title: <span class="badge object-type-enum"></span> MetricEditorMode
---
# <span class="badge object-type-enum"></span> MetricEditorMode

## Definition

```python
class MetricEditorMode(enum.IntEnum):
    BUILDER = 0
    CODE = 1
```
