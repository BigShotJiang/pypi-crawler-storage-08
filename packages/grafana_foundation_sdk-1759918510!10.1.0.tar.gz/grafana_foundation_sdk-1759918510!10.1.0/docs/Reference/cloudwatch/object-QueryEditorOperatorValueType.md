---
title: <span class="badge object-type-disjunction"></span> QueryEditorOperatorValueType
---
# <span class="badge object-type-disjunction"></span> QueryEditorOperatorValueType

## Definition

```python
QueryEditorOperatorValueType: typing.TypeAlias = typing.Union[str, bool, int, list[cloudwatch.QueryEditorOperatorType]]
```
