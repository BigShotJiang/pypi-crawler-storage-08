---
title: <span class="badge object-type-enum"></span> CloudWatchQueryMode
---
# <span class="badge object-type-enum"></span> CloudWatchQueryMode

## Definition

```python
class CloudWatchQueryMode(enum.StrEnum):
    METRICS = "Metrics"
    LOGS = "Logs"
    ANNOTATIONS = "Annotations"
```
