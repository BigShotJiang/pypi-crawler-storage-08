---
title: <span class="badge builder"></span> QueryEditorFunctionParameterExpression
---
# <span class="badge builder"></span> QueryEditorFunctionParameterExpression

## Constructor

```python
QueryEditorFunctionParameterExpression()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> cloudwatch.QueryEditorFunctionParameterExpression
```

### <span class="badge object-method"></span> name

```python
def name(name: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [QueryEditorFunctionParameterExpression](./object-QueryEditorFunctionParameterExpression.md)
