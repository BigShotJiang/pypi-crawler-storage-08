---
title: <span class="badge object-type-disjunction"></span> CloudWatchQuery
---
# <span class="badge object-type-disjunction"></span> CloudWatchQuery

## Definition

```python
CloudWatchQuery: typing.TypeAlias = typing.Union[cloudwatch.CloudWatchMetricsQuery, cloudwatch.CloudWatchLogsQuery, cloudwatch.CloudWatchAnnotationQuery]
```
