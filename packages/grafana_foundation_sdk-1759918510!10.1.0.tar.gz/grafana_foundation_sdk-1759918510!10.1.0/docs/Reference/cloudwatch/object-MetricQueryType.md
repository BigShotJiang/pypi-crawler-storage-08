---
title: <span class="badge object-type-enum"></span> MetricQueryType
---
# <span class="badge object-type-enum"></span> MetricQueryType

## Definition

```python
class MetricQueryType(enum.IntEnum):
    SEARCH = 0
    QUERY = 1
```
