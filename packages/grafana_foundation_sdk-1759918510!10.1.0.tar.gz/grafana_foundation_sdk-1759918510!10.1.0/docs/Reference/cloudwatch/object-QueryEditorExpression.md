---
title: <span class="badge object-type-disjunction"></span> QueryEditorExpression
---
# <span class="badge object-type-disjunction"></span> QueryEditorExpression

## Definition

```python
QueryEditorExpression: typing.TypeAlias = typing.Union[cloudwatch.QueryEditorArrayExpression, cloudwatch.QueryEditorPropertyExpression, cloudwatch.QueryEditorGroupByExpression, cloudwatch.QueryEditorFunctionExpression, cloudwatch.QueryEditorFunctionParameterExpression, cloudwatch.QueryEditorOperatorExpression]
```
