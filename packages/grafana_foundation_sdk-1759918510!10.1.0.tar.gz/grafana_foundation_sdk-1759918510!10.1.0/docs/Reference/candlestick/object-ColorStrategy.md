---
title: <span class="badge object-type-enum"></span> ColorStrategy
---
# <span class="badge object-type-enum"></span> ColorStrategy

## Definition

```python
class ColorStrategy(enum.StrEnum):
    OPEN_CLOSE = "open-close"
    CLOSE_CLOSE = "close-close"
```
