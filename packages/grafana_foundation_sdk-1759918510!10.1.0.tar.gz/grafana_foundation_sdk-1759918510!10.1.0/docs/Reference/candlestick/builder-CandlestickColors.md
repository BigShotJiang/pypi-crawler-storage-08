---
title: <span class="badge builder"></span> CandlestickColors
---
# <span class="badge builder"></span> CandlestickColors

## Constructor

```python
CandlestickColors()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> candlestick.CandlestickColors
```

### <span class="badge object-method"></span> down

```python
def down(down: str) -> typing.Self
```

### <span class="badge object-method"></span> flat

```python
def flat(flat: str) -> typing.Self
```

### <span class="badge object-method"></span> up

```python
def up(up: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [CandlestickColors](./object-CandlestickColors.md)
