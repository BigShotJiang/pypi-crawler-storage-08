---
title: <span class="badge object-type-enum"></span> CandleStyle
---
# <span class="badge object-type-enum"></span> CandleStyle

## Definition

```python
class CandleStyle(enum.StrEnum):
    CANDLES = "candles"
    OHLC_BARS = "ohlcbars"
```
