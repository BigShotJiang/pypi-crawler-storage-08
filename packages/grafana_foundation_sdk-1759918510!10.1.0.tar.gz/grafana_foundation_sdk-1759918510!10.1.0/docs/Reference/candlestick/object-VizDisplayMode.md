---
title: <span class="badge object-type-enum"></span> VizDisplayMode
---
# <span class="badge object-type-enum"></span> VizDisplayMode

## Definition

```python
class VizDisplayMode(enum.StrEnum):
    CANDLES_VOLUME = "candles+volume"
    CANDLES = "candles"
    VOLUME = "volume"
```
