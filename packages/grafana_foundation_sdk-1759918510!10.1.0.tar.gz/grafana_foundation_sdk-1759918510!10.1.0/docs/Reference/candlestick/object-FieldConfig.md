---
title: <span class="badge object-type-ref"></span> FieldConfig
---
# <span class="badge object-type-ref"></span> FieldConfig

## Definition

```python
FieldConfig: typing.TypeAlias = common.GraphFieldConfig
```
