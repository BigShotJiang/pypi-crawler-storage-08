---
title: <span class="badge object-type-enum"></span> ConnectionPath
---
# <span class="badge object-type-enum"></span> ConnectionPath

## Definition

```python
class ConnectionPath(enum.StrEnum):
    STRAIGHT = "straight"
```
