---
title: <span class="badge object-type-enum"></span> HorizontalConstraint
---
# <span class="badge object-type-enum"></span> HorizontalConstraint

## Definition

```python
class HorizontalConstraint(enum.StrEnum):
    LEFT = "left"
    RIGHT = "right"
    LEFT_RIGHT = "leftright"
    CENTER = "center"
    SCALE = "scale"
```
