---
title: <span class="badge object-type-enum"></span> BackgroundImageSize
---
# <span class="badge object-type-enum"></span> BackgroundImageSize

## Definition

```python
class BackgroundImageSize(enum.StrEnum):
    ORIGINAL = "original"
    CONTAIN = "contain"
    COVER = "cover"
    FILL = "fill"
    TILE = "tile"
```
