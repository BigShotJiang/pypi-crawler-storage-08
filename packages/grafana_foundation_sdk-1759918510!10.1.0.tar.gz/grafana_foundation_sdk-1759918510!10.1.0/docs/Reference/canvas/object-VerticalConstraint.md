---
title: <span class="badge object-type-enum"></span> VerticalConstraint
---
# <span class="badge object-type-enum"></span> VerticalConstraint

## Definition

```python
class VerticalConstraint(enum.StrEnum):
    TOP = "top"
    BOTTOM = "bottom"
    TOP_BOTTOM = "topbottom"
    CENTER = "center"
    SCALE = "scale"
```
