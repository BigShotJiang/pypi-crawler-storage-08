---
title: <span class="badge object-type-enum"></span> FormatOptions
---
# <span class="badge object-type-enum"></span> FormatOptions

## Definition

```python
class FormatOptions(enum.IntEnum):
    TIME_SERIES = 0
    TABLE = 1
    LOGS = 2
```
