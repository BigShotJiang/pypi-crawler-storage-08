---
title: <span class="badge object-type-scalar"></span> DefaultKey
---
# <span class="badge object-type-scalar"></span> DefaultKey

## Definition

```python
DefaultKey: typing.Literal["__default"] = "__default"
```
