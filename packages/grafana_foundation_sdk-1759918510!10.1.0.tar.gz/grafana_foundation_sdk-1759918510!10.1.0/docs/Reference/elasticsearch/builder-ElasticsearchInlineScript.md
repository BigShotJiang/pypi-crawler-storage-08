---
title: <span class="badge builder"></span> ElasticsearchInlineScript
---
# <span class="badge builder"></span> ElasticsearchInlineScript

## Constructor

```python
ElasticsearchInlineScript()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> elasticsearch.ElasticsearchInlineScript
```

### <span class="badge object-method"></span> inline

```python
def inline(inline: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [ElasticsearchInlineScript](./object-ElasticsearchInlineScript.md)
