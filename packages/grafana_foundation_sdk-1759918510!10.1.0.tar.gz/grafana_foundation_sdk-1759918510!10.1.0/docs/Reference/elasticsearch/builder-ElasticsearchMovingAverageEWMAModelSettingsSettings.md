---
title: <span class="badge builder"></span> ElasticsearchMovingAverageEWMAModelSettingsSettings
---
# <span class="badge builder"></span> ElasticsearchMovingAverageEWMAModelSettingsSettings

## Constructor

```python
ElasticsearchMovingAverageEWMAModelSettingsSettings()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> elasticsearch.ElasticsearchMovingAverageEWMAModelSettingsSettings
```

### <span class="badge object-method"></span> alpha

```python
def alpha(alpha: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [ElasticsearchMovingAverageEWMAModelSettingsSettings](./object-ElasticsearchMovingAverageEWMAModelSettingsSettings.md)
