---
title: <span class="badge builder"></span> ElasticsearchMetricAggregationWithMissingSupportSettings
---
# <span class="badge builder"></span> ElasticsearchMetricAggregationWithMissingSupportSettings

## Constructor

```python
ElasticsearchMetricAggregationWithMissingSupportSettings()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> elasticsearch.ElasticsearchMetricAggregationWithMissingSupportSettings
```

### <span class="badge object-method"></span> missing

```python
def missing(missing: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [ElasticsearchMetricAggregationWithMissingSupportSettings](./object-ElasticsearchMetricAggregationWithMissingSupportSettings.md)
