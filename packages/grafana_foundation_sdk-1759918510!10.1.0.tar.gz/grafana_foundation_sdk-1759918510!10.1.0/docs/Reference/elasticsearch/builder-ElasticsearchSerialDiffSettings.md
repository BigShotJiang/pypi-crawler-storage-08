---
title: <span class="badge builder"></span> ElasticsearchSerialDiffSettings
---
# <span class="badge builder"></span> ElasticsearchSerialDiffSettings

## Constructor

```python
ElasticsearchSerialDiffSettings()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> elasticsearch.ElasticsearchSerialDiffSettings
```

### <span class="badge object-method"></span> lag

```python
def lag(lag: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [ElasticsearchSerialDiffSettings](./object-ElasticsearchSerialDiffSettings.md)
