---
title: <span class="badge builder"></span> ElasticsearchRawDocumentSettings
---
# <span class="badge builder"></span> ElasticsearchRawDocumentSettings

## Constructor

```python
ElasticsearchRawDocumentSettings()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> elasticsearch.ElasticsearchRawDocumentSettings
```

### <span class="badge object-method"></span> size

```python
def size(size: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [ElasticsearchRawDocumentSettings](./object-ElasticsearchRawDocumentSettings.md)
