---
title: <span class="badge builder"></span> ElasticsearchRawDataSettings
---
# <span class="badge builder"></span> ElasticsearchRawDataSettings

## Constructor

```python
ElasticsearchRawDataSettings()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> elasticsearch.ElasticsearchRawDataSettings
```

### <span class="badge object-method"></span> size

```python
def size(size: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [ElasticsearchRawDataSettings](./object-ElasticsearchRawDataSettings.md)
