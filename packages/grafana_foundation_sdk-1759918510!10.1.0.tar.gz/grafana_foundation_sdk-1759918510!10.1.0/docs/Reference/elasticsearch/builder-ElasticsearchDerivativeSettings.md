---
title: <span class="badge builder"></span> ElasticsearchDerivativeSettings
---
# <span class="badge builder"></span> ElasticsearchDerivativeSettings

## Constructor

```python
ElasticsearchDerivativeSettings()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> elasticsearch.ElasticsearchDerivativeSettings
```

### <span class="badge object-method"></span> unit

```python
def unit(unit: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [ElasticsearchDerivativeSettings](./object-ElasticsearchDerivativeSettings.md)
