---
title: <span class="badge builder"></span> ElasticsearchMovingAverageHoltModelSettingsSettings
---
# <span class="badge builder"></span> ElasticsearchMovingAverageHoltModelSettingsSettings

## Constructor

```python
ElasticsearchMovingAverageHoltModelSettingsSettings()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> elasticsearch.ElasticsearchMovingAverageHoltModelSettingsSettings
```

### <span class="badge object-method"></span> alpha

```python
def alpha(alpha: str) -> typing.Self
```

### <span class="badge object-method"></span> beta

```python
def beta(beta: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [ElasticsearchMovingAverageHoltModelSettingsSettings](./object-ElasticsearchMovingAverageHoltModelSettingsSettings.md)
