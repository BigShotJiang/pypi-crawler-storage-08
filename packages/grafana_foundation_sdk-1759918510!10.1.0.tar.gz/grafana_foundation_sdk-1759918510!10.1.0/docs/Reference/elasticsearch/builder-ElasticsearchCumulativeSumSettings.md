---
title: <span class="badge builder"></span> ElasticsearchCumulativeSumSettings
---
# <span class="badge builder"></span> ElasticsearchCumulativeSumSettings

## Constructor

```python
ElasticsearchCumulativeSumSettings()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> elasticsearch.ElasticsearchCumulativeSumSettings
```

### <span class="badge object-method"></span> format_val

```python
def format_val(format_val: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [ElasticsearchCumulativeSumSettings](./object-ElasticsearchCumulativeSumSettings.md)
