---
title: <span class="badge object-type-scalar"></span> Duration
---
# <span class="badge object-type-scalar"></span> Duration

Duration in seconds.

## Definition

```python
# Duration in seconds.
Duration: typing.TypeAlias = int
```
