---
title: <span class="badge object-type-scalar"></span> Location
---
# <span class="badge object-type-scalar"></span> Location

## Definition

```python
Location: typing.TypeAlias = str
```
