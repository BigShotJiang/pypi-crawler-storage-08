---
title: <span class="badge object-type-scalar"></span> Provenance
---
# <span class="badge object-type-scalar"></span> Provenance

## Definition

```python
Provenance: typing.TypeAlias = str
```
