---
title: <span class="badge object-type-map"></span> MatchRegexps
---
# <span class="badge object-type-map"></span> MatchRegexps

## Definition

```python
MatchRegexps: typing.TypeAlias = dict[str, alerting.Regexp]
```
