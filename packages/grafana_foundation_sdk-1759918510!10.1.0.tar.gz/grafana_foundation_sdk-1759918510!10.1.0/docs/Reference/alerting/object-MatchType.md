---
title: <span class="badge object-type-enum"></span> MatchType
---
# <span class="badge object-type-enum"></span> MatchType

## Definition

```python
class MatchType(enum.StrEnum):
    EQUAL = "="
    NOT_EQUAL = "!="
    EQUAL_REGEX = "=~"
    NOT_EQUAL_REGEX = "!~"
```
