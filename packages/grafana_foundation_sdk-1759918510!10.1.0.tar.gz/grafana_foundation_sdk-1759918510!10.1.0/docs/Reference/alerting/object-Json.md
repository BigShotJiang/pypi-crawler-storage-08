---
title: <span class="badge object-type-scalar"></span> Json
---
# <span class="badge object-type-scalar"></span> Json

## Definition

```python
Json: typing.TypeAlias = object
```
