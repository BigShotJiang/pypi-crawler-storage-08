---
title: <span class="badge builder"></span> YearRange
---
# <span class="badge builder"></span> YearRange

## Constructor

```python
YearRange()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> alerting.YearRange
```

### <span class="badge object-method"></span> begin

```python
def begin(begin: int) -> typing.Self
```

### <span class="badge object-method"></span> end

```python
def end(end: int) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [YearRange](./object-YearRange.md)
