---
title: <span class="badge builder"></span> AnnotationActions
---
# <span class="badge builder"></span> AnnotationActions

## Constructor

```python
AnnotationActions()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> dashboard.AnnotationActions
```

### <span class="badge object-method"></span> can_add

```python
def can_add(can_add: bool) -> typing.Self
```

### <span class="badge object-method"></span> can_delete

```python
def can_delete(can_delete: bool) -> typing.Self
```

### <span class="badge object-method"></span> can_edit

```python
def can_edit(can_edit: bool) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [AnnotationActions](./object-AnnotationActions.md)
