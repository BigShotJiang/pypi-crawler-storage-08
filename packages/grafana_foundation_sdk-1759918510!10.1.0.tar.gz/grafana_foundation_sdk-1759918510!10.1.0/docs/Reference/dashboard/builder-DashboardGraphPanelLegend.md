---
title: <span class="badge builder"></span> DashboardGraphPanelLegend
---
# <span class="badge builder"></span> DashboardGraphPanelLegend

## Constructor

```python
DashboardGraphPanelLegend()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> dashboard.DashboardGraphPanelLegend
```

### <span class="badge object-method"></span> show

```python
def show(show: bool) -> typing.Self
```

### <span class="badge object-method"></span> sort

```python
def sort(sort: str) -> typing.Self
```

### <span class="badge object-method"></span> sort_desc

```python
def sort_desc(sort_desc: bool) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [DashboardGraphPanelLegend](./object-DashboardGraphPanelLegend.md)
