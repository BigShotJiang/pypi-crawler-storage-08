---
title: <span class="badge builder"></span> GraphPanel
---
# <span class="badge builder"></span> GraphPanel

## Constructor

```python
GraphPanel()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> dashboard.GraphPanel
```

### <span class="badge object-method"></span> legend

@deprecated this is part of deprecated graph panel

```python
def legend(legend: cogbuilder.Builder[dashboard.DashboardGraphPanelLegend]) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [GraphPanel](./object-GraphPanel.md)
