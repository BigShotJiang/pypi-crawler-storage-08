"""Arbitrary limits used by Telegram."""  # pylint: disable=invalid-name

message_caption_length_max = 1024
message_text_length_max = 4096
