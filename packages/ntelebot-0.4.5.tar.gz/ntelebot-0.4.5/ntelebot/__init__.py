"""A simple implementation of https://core.telegram.org/bots/api."""

# pylint: disable=cyclic-import
from ntelebot import bot
from ntelebot import delayqueue
from ntelebot import deeplink
from ntelebot import dispatch
from ntelebot import errors
from ntelebot import invislink
from ntelebot import keyboardutil
from ntelebot import limits
from ntelebot import loop
from ntelebot import preprocess
from ntelebot import requests
