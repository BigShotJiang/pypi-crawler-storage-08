# Templates: Part II

To be added.

## Catching errors

To be added.

## Separate `.jl` files

To be added.

## Some examples

### `HeatPump`

To be added.

### `BESS`

To be added.

### `PV`

To be added.

### `CHP`

To be added.
