# Examples

:::{toctree}
:maxdepth: 2

52 <../notebooks/example_52.ipynb>
53 <../notebooks/example_53.ipynb>
54 <../notebooks/example_54.ipynb>
55 <../notebooks/example_55.ipynb>

:::
