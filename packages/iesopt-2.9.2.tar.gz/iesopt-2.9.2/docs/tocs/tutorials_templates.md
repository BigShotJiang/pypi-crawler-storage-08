# Templates

:::{toctree}
:maxdepth: 2

Part I <../pages/tutorials/templates_1.ipynb>
Part II <../pages/tutorials/templates_2.ipynb>

../pages/tutorials/templates/getter_setter.md
:::
