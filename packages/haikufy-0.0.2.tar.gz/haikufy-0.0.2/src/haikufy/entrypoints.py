from haikufy.app import HaikufyApp


def haikufy():
    app = HaikufyApp()
    app.run()