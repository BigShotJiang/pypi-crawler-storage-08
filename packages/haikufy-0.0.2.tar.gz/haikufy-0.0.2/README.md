# haikufy

[![PyPI - Version](https://img.shields.io/pypi/v/haikufy.svg)](https://pypi.org/project/haikufy)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/haikufy.svg)](https://pypi.org/project/haikufy)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install haikufy
```

## License

`haikufy` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
