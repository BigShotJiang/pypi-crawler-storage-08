# from .make_colors import make_colors, MakeColors, make_color, make, getSort, print, color_map, MakeColor, convert, translate
# from .colors import *
from .make_colors import *
from . import __version__ as version
__version__ 	= version.version
__email__		= "cumulus13@gmail.com"
__author__		= "Hadi Cahyadi"
