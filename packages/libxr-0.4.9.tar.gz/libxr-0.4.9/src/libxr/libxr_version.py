class LibXRInfo:
    COMMIT = '2ac54ed2adf42706cb46d33a579caa757d07d88e'
