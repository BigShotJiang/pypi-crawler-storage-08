=========
linearfit
=========

.. moduleauthor:: Mihai Cara

.. currentmodule:: tweakwcs.linearfit

.. automodule:: tweakwcs.linearfit
   :members:
   :undoc-members:
