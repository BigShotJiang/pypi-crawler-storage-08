======
linalg
======

.. moduleauthor:: Mihai Cara

.. currentmodule:: tweakwcs.linalg

.. automodule:: tweakwcs.linalg
   :members:
   :undoc-members:
