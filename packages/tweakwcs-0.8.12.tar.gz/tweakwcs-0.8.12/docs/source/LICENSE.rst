*******
LICENSE
*******

.. include:: ../../LICENSE.txt
