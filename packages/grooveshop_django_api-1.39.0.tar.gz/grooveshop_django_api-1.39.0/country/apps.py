from django.apps import AppConfig


class CountryConfig(AppConfig):
    name = "country"
