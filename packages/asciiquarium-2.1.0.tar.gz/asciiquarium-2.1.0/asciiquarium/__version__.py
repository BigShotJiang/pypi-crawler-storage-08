"""Version information for asciiquarium"""

__version__ = "2.1.0"
__author__ = "Mohammad Abu Mattar"
__email__ = "info@mkabumattar.com"
__license__ = "GPL-3.0-or-later"
__original_author__ = "Kirk Baucom"
__original_project__ = "http://robobunny.com/projects/asciiquarium"
