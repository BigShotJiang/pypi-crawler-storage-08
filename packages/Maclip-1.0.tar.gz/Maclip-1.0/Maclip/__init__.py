# -*- coding:utf-8 -*-
from . import MAClip
