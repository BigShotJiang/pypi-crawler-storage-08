"""ASCII logo."""

ASCII_LOGO = """
      .o.                       .              .oooooo..o
     .888.                    .o8             d8P'    `Y8
    .8"888.     oooo  oooo  .o888oo  .ooooo.  Y88bo.      oooo  oooo  oooo d8b oooo    ooo  .ooooo.  oooo    ooo
   .8' `888.    `888  `888    888   d88' `88b  `"Y8888o.  `888  `888  `888""8P  `88.  .8'  d88' `88b  `88.  .8'
  .88ooo8888.    888   888    888   888   888      `"Y88b  888   888   888       `88..8'   888ooo888   `88..8'
 .8'     `888.   888   888    888 . 888   888 oo     .d8P  888   888   888        `888'    888    .o    `888'
o88o     o8888o  `V88V"V8P'   "888" `Y8bod8P' 8""88888P'   `V88V"V8P' d888b        `8'     `Y8bod8P'     .8'
                                                                                                     .o..P'
                                                                                                     `Y8P'
"""  # noqa: E501
