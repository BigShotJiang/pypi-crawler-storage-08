"""Test suite for the auto_survey package."""
