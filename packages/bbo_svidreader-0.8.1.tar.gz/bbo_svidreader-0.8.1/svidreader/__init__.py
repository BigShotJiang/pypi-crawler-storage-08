from svidreader.reader import SVidReader
from svidreader.filtergraph import get_reader

__version__ = "0.8.1"
