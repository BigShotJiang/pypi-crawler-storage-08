from .explain import explain_sentence

__all__ = ["explain_sentence"]
