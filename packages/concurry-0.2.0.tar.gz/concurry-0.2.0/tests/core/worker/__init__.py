"""Tests for worker module."""

