Changes
=======

2.6
---

* Dropped support for Python 3.8 and 3.9.
* Python 3.14 compatiblity.

2.5
---

* Python 3.13 compatiblity.

2.4
---

* Added type annotations.

2.3
---

* Fixed publishing wheels for non-Linux platforms.

2.2
---

* Tested with Python 3.9, 3.10, 3.11, and 3.12, no changes needed.
* Dropped support for Python 3.5, 3.6, and 3.7.
* Binary wheels are now available for all supported Python versions.

2.1
---

* Fixed publishing wheels in pypi.org.

2.0
---

* Dropped support for Python 2.

1.3
---

* Changed license to ISC.
* Fixed depreciation warning on Python 3.8.

1.2
---

* Included tests in the pypi package.

1.1
---

* Fixed README enconding.
* Included documentation in the pypi package.

1.0
---

* Stable release.
* Documentation improvements.

0.8
---

* First release under new maintainer.
* Merged two siphashc module implementations.
