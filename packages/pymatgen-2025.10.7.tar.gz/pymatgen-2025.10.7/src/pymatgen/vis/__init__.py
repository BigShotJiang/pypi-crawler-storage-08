"""
The vis package implements various visualization tools. For example, a VTK
Structure viewer.
"""
