"""IO for LAMMPS."""
