""" Default settings for Devilry. """
