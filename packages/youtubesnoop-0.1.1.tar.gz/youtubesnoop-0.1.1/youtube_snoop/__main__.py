"""Entry point for running youtube_snoop as a module."""

from youtube_snoop.cli import main

if __name__ == "__main__":
    main()
