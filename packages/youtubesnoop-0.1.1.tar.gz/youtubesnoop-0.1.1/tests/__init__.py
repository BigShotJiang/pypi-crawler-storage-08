"""Tests for YoutubeSnoop."""
