__all__ = ["SamResource", "SamResourceType"]

from samtranslator.sdk.resource import SamResource, SamResourceType
