---
name: 💡 Feature suggestion
about: What would make this even better?
---

# What is currently missing?



# How could this be improved?



# Is this a feature you would work on yourself?

[ ] I plan to open a pull request for this feature
