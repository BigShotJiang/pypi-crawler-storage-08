---
name: 🐜 Report a bug
about: Spotted a problem? Let us know
---

# What happened?



# What did you expect to happen?



# What else do we need to know?

Include your platform, version, and any other information that seems relevant.

