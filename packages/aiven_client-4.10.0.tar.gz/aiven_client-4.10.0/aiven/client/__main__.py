from .cli import AivenCLI
from typing import NoReturn


def main() -> NoReturn:
    AivenCLI().main()


if __name__ == "__main__":
    main()
