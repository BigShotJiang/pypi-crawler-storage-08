__version__ = "0.16.4"


def get_version() -> str:
    return __version__
