## "lokzzpylib"
my own personal library