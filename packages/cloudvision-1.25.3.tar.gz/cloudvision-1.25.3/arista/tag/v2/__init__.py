# Copyright (c) 2025 Arista Networks, Inc.  All rights reserved.

from arista.tag.v2 import tag_pb2 as models
import arista.tag.v2.services
