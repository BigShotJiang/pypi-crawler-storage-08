# Copyright (c) 2025 Arista Networks, Inc.  All rights reserved.

# pylint: disable=wildcard-import
from arista.syslog.v1.services.gen_pb2 import *
# pylint: disable=wildcard-import
from arista.syslog.v1.services.gen_pb2_grpc import *
