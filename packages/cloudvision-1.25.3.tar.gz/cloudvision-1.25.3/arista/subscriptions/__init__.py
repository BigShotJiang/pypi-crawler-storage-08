# Copyright (c) 2025 Arista Networks, Inc.  All rights reserved.

from arista.subscriptions import subscriptions_pb2 as models
