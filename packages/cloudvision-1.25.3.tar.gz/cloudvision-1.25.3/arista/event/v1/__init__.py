# Copyright (c) 2025 Arista Networks, Inc.  All rights reserved.

from arista.event.v1 import event_pb2 as models
import arista.event.v1.services
