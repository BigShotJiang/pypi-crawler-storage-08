# Copyright (c) 2025 Arista Networks, Inc.  All rights reserved.

from arista.serviceaccount.v1 import serviceaccount_pb2 as models
import arista.serviceaccount.v1.services
