# Copyright (c) 2025 Arista Networks, Inc.  All rights reserved.

from arista.alert.v1 import alert_pb2 as models
import arista.alert.v1.services
