# Copyright (c) 2025 Arista Networks, Inc.  All rights reserved.

from arista.identityprovider.v1 import identityprovider_pb2 as models
import arista.identityprovider.v1.services
