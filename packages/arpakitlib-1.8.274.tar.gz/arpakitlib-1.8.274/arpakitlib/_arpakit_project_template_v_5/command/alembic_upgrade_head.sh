cd ..
poetry run alembic upgrade head
