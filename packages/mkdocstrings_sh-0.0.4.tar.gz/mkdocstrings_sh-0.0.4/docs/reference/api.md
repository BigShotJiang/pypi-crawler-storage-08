---
title: API reference
hide:
- navigation
---

::: mkdocstrings_handlers.sh
    handler: python

