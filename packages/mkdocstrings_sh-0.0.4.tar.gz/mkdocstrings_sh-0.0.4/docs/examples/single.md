# Example with referencing single entity

See also "duplicates".

## Single variable:

```
::: docs/examples/script.sh VARIABLE
```

::: docs/examples/script.sh VARIABLE

## Single function:

```
::: docs/examples/script.sh func
```

::: docs/examples/script.sh func
