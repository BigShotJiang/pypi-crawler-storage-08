# All tags

```
--8<-- "docs/examples/all.sh"
```

::: docs/examples/all.sh
