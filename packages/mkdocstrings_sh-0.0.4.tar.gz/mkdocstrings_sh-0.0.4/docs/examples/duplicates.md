# Example with referencing single entity

## Single variable:

```
::: docs/examples/duplicates.sh VARIABLE variable
```

::: docs/examples/duplicates.sh VARIABLE

## Single function:

```
::: docs/examples/duplicates.sh VARIABLE function
```

::: docs/examples/duplicates.sh VARIABLE

## Single section:

```
::: docs/examples/duplicates.sh VARIABLE section
```

::: docs/examples/duplicates.sh VARIABLE
