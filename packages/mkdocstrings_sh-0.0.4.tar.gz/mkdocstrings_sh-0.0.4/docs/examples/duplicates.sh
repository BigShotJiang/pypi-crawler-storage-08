
# this is a variable named VARIABLE
VARIABLE=1

# This is a function named VARIABLE
function VARIABLE() {}

# @section VARIABLE
# This is a section named VARIABLE
