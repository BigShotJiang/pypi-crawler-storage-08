# Example from readme

```
--8<-- "docs/examples/readme.sh"
```

::: docs/examples/readme.sh
