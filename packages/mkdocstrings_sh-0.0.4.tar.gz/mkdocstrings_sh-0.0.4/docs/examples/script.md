# Script example with section

```
--8<-- "docs/examples/script.sh"
```

::: docs/examples/script.sh
