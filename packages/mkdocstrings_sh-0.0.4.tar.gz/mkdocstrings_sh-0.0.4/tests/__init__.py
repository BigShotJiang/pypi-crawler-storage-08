"""Tests suite for mkdocstrings-sh."""
