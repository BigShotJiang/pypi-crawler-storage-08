Use uv for dependency management and running scripts within the project

