# Changelog

## Unreleased

## 0.10.0 - 2025-09-30

- Use `gpt-4o` for KB reranking model
- Query KB action now returns the matched chunk
- Add the option to give user prompt to schema generation

## 0.8.2 - 2025-09-18

- Fixed PyPI listing
- Added license info and description

## 0.8.1 - 2025-09-18

- First release to PyPI
