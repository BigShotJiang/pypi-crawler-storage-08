"""dragonfly-energy properties."""
