<p align="center">
  <img src="https://github.com/user-attachments/assets/95493b42-6734-42b7-bf93-96987bcf60ad" height=200/>
</p>

# mini-kit

[![image](https://img.shields.io/pypi/v/mini-kit.svg)](https://pypi.python.org/pypi/mini-kit)

Small self-contained micro packages for deep learning codebases.


