# CWPack / Goodies


Goodies contains the following:

**basic_contexts** has contexts for dynamic memory contexts and a set of file contexts.

**dump** presents a msgpack file in human readable form.

**numeric_extensions** use when your Ext data is integer or real.

**objC** Objective-C wrapper.

**swift** Swift wrapper.

**utils** convenience calls and expect api for CWPack.

