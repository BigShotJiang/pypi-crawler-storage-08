from .server import run


def main() -> None:
    run()
