from datetime import timedelta

AUTH_SESSION_TTL = timedelta(days=14)
