.. _changelog:

.. mdinclude:: ../CHANGELOG.md
