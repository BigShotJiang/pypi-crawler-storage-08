"""Implementations of common iCVIs."""
