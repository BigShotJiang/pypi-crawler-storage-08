"""Elementary ART modules which are those ART modules that do not implement an
abstraction layer on top of another module.

These are the most basic clustering methods with the simplest geometries.

"""
