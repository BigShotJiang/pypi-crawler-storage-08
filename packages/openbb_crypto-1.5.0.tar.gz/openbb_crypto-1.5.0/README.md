# Crypto data extension for OpenBB Platform

This extension provides a set of commands for crypto data retrieval.

## Installation

To install the extension, run the following command in this folder:

```bash
pip install openbb-crypto
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
