"""OpenBB Crypto Price Router."""
