"""
Core HTTP Tests

Tests HTTP client operations, retry logic, async support, and networking.
Focuses on the main HTTP functionality and real-world networking scenarios.
"""
