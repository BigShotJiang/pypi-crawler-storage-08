# RobertJN64TemplatePackage

![Tests Badge](https://github.com/RobertJN64/RobertJN64TemplatePackage/actions/workflows/tests.yml/badge.svg)
![Python Version Badge](https://img.shields.io/pypi/pyversions/RobertJN64TemplatePackage)
![License Badge](https://img.shields.io/github/license/RobertJN64/RobertJN64TemplatePackage)


This is a template for the structure of my future projects.

This project was inspired by the [PyPA sample project](https://github.com/pypa/sampleproject)
and [James Murphey's sample project](https://github.com/mCodingLLC/SlapThatLikeButton-TestingStarterProject).
These projects were licensed under the MIT license and the relevant licenses
can be found in the [attributions](/attributions) folder in the project.