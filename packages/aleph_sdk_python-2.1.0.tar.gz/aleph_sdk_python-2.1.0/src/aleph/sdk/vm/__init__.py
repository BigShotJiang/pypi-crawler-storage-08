"""
Aleph.im helpers for apps running inside aleph.im Virtual Machines.
"""
