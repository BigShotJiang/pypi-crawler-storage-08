"""Tests for `ctitools`."""
