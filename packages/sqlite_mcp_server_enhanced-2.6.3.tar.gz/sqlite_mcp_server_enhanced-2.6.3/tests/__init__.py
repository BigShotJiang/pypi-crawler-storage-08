"""Tests for SQLite MCP Server."""
