#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from .crud import CRUDPlus as CRUDPlus
from .types import JoinConfig as JoinConfig

__version__ = '1.12.1'
