# sqlalchemy-crud-plus

基于 SQLAlChemy 2.0 的异步 CRUD 操作

## Download

```shell
pip install sqlalchemy-crud-plus
```

## 文档

[SQLAlchemy CRUD Plus](https://fastapi-practices.github.io/sqlalchemy-crud-plus)

## 互动

[Discord](https://wu-clan.github.io/homepage/)

## 赞助

如果此项目能够帮助到你，你可以赞助作者一些咖啡豆表示鼓励：[:coffee: Sponsor :coffee:](https://wu-clan.github.io/sponsor/)
