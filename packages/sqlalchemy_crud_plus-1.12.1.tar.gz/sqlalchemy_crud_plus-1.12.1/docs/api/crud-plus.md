# CRUDPlus API 参考

`CRUDPlus` 类是执行 CRUD 操作和关系查询的主要接口。

## 类定义

::: sqlalchemy_crud_plus.crud.CRUDPlus
