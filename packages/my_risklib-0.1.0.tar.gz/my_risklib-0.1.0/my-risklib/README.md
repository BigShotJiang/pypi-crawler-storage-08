# my_risklib

[![PyPI - Version](https://img.shields.io/pypi/v/my-risklib.svg)](https://pypi.org/project/my-risklib)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/my-risklib.svg)](https://pypi.org/project/my-risklib)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install my-risklib
```

## License

`my-risklib` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
