from invoke import Collection

from . import module

ns = Collection(module)
