from unittest.mock import Mock


CustomExecutor = Mock()
