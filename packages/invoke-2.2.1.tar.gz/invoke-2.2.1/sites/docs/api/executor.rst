============
``executor``
============

.. autoclass:: invoke.executor.Executor
