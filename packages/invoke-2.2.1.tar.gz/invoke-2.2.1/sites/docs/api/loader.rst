==========
``loader``
==========

.. autoclass:: invoke.loader.Loader
    :special-members:
    :exclude-members: __weakref__

.. autoclass:: invoke.loader.FilesystemLoader
    :special-members:
    :exclude-members: __weakref__
