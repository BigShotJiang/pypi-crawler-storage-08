#ifndef BIND_CONSTS_H
#define BIND_CONSTS_H

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void bind_consts(nb::module_ &);

#endif //BIND_CONSTS_H
