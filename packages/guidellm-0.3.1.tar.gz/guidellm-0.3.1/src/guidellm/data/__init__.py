"""
Required for python < 3.12
https://docs.python.org/3/library/importlib.resources.html#importlib.resources.files
"""
