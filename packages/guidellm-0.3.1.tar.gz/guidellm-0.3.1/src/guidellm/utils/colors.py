__all__ = ["Colors"]


class Colors:
    INFO: str = "light_steel_blue"
    PROGRESS: str = "dark_slate_gray1"
    SUCCESS: str = "chartreuse1"
    ERROR: str = "orange_red1"
