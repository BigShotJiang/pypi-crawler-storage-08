"""Tests for the A2A module."""
