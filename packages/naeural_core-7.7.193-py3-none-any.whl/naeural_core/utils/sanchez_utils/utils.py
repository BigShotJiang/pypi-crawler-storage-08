def negate_color(color):
  r, g, b = color
  return 255 - r, 255 - g, 255 - b