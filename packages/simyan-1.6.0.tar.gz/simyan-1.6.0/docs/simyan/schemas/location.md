# Location

::: simyan.schemas.location.BasicLocation
::: simyan.schemas.location.Location
