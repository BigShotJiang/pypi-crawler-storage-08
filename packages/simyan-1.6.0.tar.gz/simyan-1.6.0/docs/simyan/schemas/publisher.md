# Publisher

::: simyan.schemas.publisher.BasicPublisher
::: simyan.schemas.publisher.Publisher
