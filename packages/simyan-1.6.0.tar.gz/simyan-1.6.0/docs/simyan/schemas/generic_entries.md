# Generic Entries

::: simyan.schemas.generic_entries.AssociatedImage
::: simyan.schemas.generic_entries.GenericCount
::: simyan.schemas.generic_entries.GenericCreator
::: simyan.schemas.generic_entries.GenericEntry
::: simyan.schemas.generic_entries.GenericIssue
::: simyan.schemas.generic_entries.Images
