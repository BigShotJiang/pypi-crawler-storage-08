# Concept

::: simyan.schemas.concept.BasicConcept
::: simyan.schemas.concept.Concept
