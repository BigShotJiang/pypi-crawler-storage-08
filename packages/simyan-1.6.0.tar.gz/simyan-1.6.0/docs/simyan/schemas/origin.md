# Origin

::: simyan.schemas.origin.BasicOrigin
::: simyan.schemas.origin.Origin
