# Story Arc

::: simyan.schemas.story_arc.BasicStoryArc
::: simyan.schemas.story_arc.StoryArc
