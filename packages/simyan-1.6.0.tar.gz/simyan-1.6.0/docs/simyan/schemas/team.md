# Team

::: simyan.schemas.team.BasicTeam
::: simyan.schemas.team.Team
