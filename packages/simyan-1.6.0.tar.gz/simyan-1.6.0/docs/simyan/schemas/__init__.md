# Package Contents

::: simyan.schemas.BaseModel
