# Character

::: simyan.schemas.character.BasicCharacter
::: simyan.schemas.character.Character
