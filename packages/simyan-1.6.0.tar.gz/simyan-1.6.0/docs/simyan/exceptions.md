# Exceptions

::: simyan.exceptions.AuthenticationError
::: simyan.exceptions.ServiceError
