"""Tests for Simyan."""
