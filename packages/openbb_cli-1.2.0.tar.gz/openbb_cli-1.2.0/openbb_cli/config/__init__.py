"""Core config init."""
