# OpenBB Yahoo!Finance Provider

This extension integrates the [Yahoo!Finance](https://finance.yahoo.com/) data provider into the OpenBB Platform.

## Installation

To install the extension:

```bash
pip install openbb-yfinance
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
