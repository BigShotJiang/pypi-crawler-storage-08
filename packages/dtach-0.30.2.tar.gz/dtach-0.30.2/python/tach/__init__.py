from __future__ import annotations

__version__: str = "0.30.2"

__all__ = ["__version__"]
