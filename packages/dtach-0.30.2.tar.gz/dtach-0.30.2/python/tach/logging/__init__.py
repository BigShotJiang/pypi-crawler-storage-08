from __future__ import annotations

from tach.logging.logger import CallInfo, init_logging, logger

__all__ = ["logger", "CallInfo", "init_logging"]
