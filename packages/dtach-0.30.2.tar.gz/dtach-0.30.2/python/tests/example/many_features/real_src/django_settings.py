import django

OTHER_FIELD = "value"

INSTALLED_APPS = [
    "module1",
    "module3",
    "module5",
]