from project.module_two import module_two


def module_one():
    module_two()
