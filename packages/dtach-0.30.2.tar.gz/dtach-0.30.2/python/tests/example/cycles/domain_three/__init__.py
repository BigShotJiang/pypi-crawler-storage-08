from __future__ import annotations

from domain_one import y

x = 3
y

__all__ = ["x"]
