from __future__ import annotations

from domain_two import x

y = 1
x
