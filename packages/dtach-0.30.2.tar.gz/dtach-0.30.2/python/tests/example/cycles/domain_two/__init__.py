from __future__ import annotations

from domain_three import x

__all__ = ["x"]
