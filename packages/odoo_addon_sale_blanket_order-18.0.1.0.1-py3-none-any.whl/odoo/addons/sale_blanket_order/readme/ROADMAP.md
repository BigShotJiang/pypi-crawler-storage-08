- Currently, combo products are not supported in blanket orders nor blanket
  order lines, they are treated as regular products. Future versions of the
  module should include support for these types of products.
