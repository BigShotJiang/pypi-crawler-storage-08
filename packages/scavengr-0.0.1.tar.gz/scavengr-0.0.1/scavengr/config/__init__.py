"""
Este archivo de inicio permite que los subdirectorios se comporten como paquetes Python.

Author: Json Rivera
Date: 2024-09-26
"""