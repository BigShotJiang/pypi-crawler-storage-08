# coding: utf-8

"""Super state machine - package that helps creating state machines."""

__author__ = 'Szczepan Cieślik'
__email__ = 'szczepan.cieslik@gmail.com'
__version__ = '2.0.2'
