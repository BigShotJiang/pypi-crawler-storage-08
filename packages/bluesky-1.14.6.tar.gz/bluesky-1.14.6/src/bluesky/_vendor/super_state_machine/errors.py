"""Errors module."""


class TransitionError(RuntimeError):

    """Raised for situation, when transition is not allowed."""
