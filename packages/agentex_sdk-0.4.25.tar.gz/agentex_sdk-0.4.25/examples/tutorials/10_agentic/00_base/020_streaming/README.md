# [Agentic] Streaming

This tutorial demonstrates how to implement streaming responses in AgentEx agents using the agentic ACP type.

## Official Documentation

[020 Streaming Base Agentic](https://dev.agentex.scale.com/docs/tutorials/agentic/base/streaming/)