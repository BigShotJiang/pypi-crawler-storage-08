"""OpenBB Regulators Extension."""
