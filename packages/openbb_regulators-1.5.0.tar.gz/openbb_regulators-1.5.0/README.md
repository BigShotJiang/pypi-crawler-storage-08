# OpenBB Regulators Extension

This extension provides a structure for data sourced from various global market regulators.

## Installation

To install the extension, run the following command in this folder:

```bash
pip install openbb-regulators
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
