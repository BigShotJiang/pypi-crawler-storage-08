#import core modules so that they can be imported directly
from __future__ import annotations
from aryaxai.core.xai import XAI

xai = XAI()
