
$name = Read-Host "Input File Name"
~/scripts/nano.ps1 $name
