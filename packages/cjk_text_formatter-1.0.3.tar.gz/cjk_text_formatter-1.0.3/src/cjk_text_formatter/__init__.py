"""CJK Text Formatter - A CLI tool for polishing text with Chinese typography rules."""

__version__ = "1.0.3"
