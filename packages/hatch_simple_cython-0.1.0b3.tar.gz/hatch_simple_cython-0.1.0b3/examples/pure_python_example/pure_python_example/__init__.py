"""Example: Compiling .py files to binary extensions."""

from .math_ops import add, multiply, power

__all__ = ["add", "multiply", "power"]
