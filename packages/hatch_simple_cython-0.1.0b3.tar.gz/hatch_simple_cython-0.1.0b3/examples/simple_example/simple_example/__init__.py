"""Simple example package with Cython extensions."""

from simple_example.math_ops import add, multiply

__all__ = ["add", "multiply"]
