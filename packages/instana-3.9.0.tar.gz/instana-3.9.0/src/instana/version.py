# (c) Copyright IBM Corp. 2021
# (c) Copyright Instana Inc. 2020

# Module version file.  Used by setup.py and snapshot reporting.

VERSION = "3.9.0"
