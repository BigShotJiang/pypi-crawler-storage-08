... 1.3.0 being the AWS Fargate Platform version:
https://docs.aws.amazon.com/AmazonECS/latest/developerguide/platform_versions.html