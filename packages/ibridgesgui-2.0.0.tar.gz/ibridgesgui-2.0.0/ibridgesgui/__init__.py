"""iBridges GUI modules."""
