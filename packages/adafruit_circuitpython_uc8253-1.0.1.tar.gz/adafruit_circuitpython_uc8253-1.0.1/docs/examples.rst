Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/uc8253_simpletest.py
    :caption: examples/uc8253_simpletest.py
    :linenos:
