This module add 2 buttons on sale orders (below sale order lines) that:

* Recalculates the prices of the order lines that contain a product in them.
* Reset product descriptions from current product information.

It is launched manually as a button to get the user decide if he/she wants to
recalculate prices when pricelist is changed or after duplicating a sale order
to update or not sales information.
