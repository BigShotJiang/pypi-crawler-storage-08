Inside a sale order, you can click on "Recalculate prices" to launch a
recalculation of all the prices of the lines, losing previous custom prices.

The second "Reset descriptions" will get descriptions from products, losing
custom descriptions.

.. image:: /sale_order_price_recalculation/static/description/sale_order_price_recalculation.png
    :alt: Sale order price recalculation
