# SPDX-FileCopyrightText: 2025-present Ramiro Gómez <code@ramiro.org>
#
# SPDX-License-Identifier: MIT
