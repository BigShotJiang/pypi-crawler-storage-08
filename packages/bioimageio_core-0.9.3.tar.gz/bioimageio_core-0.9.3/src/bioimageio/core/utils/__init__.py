from ._compare import compare as compare
