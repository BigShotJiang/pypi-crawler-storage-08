from node_graph.collection import group

__all__ = [
    'group',
]
