"""
@Author: 馒头 (chocolate)
@Email: neihanshenshou@163.com
@File: __init__.py
@Time: 2024/2/2 21:36
"""
from .OcrFormat import OcrFormat
