import os
from os import access as acc
from math import sqrt
eval("print('hi')")
if os.access("file.txt", os.R_OK): pass
acc("file.txt")
os.path.exists("file.txt")


