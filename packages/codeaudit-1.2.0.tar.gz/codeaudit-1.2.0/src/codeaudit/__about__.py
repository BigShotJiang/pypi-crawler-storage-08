# SPDX-FileCopyrightText: 2025-present Maikel Mardjan <mike@bm-support.org>
#
# SPDX-License-Identifier: GPL-3.0-or-later
__version__ = "1.2.0"
