"""RegScale exceptions"""

from .license_exception import LicenseException
from .validation_exception import ValidationException
