"""Pytekukko tests."""
