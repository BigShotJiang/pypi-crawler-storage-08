# import pygame
def main():
    print("Hello from uv-demo-2!")


if __name__ == "__main__":
    main()
