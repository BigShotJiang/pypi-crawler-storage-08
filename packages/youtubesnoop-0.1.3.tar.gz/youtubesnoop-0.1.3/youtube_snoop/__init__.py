"""YoutubeSnoop - YouTube video/music downloader with metadata tagging."""

__version__ = "0.1.0"
