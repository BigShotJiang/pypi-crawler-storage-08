"""
Masks derived from edge detectors.
"""

from ._1d import *
from ._3x3 import *
from ._5x5 import *
from ._abstract import *
