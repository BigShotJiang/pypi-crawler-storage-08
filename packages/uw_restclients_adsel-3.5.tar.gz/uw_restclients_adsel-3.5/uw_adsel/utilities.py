from commonconf import override_settings


fdao_adsel_override = override_settings(RESTCLIENTS_ADSEL_DAO_CLASS='Mock')
