"""
Contains the custom exceptions used by the Zoom client.
"""
