"""Graph Datasets
"""

__version__ = "1.0.2"

from .load_data import load_data
from .utils import *
