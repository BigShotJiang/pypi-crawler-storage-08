from ._enum_deprecation import allow_deprecation, deprecated

__all__ = ["allow_deprecation", "deprecated"]
