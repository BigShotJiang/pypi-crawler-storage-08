# Release History

## 1.0.1 (2025-10-09)

### Bugs Fixed

- Exclude `generated_samples` and `generated_tests` from wheel

## 1.0.0 (2025-09-04)

### Features Added

  - Client `SiteManagerMgmtClient` added optional signature `cloud_setting` in method `__init__`

### Other Changes

  - First GA

## 1.0.0b1 (2025-05-15)

### Other Changes

  - Initial version
