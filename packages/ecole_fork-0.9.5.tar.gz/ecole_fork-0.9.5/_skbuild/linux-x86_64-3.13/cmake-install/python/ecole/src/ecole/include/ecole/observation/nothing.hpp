#pragma once

#include "ecole/data/none.hpp"

namespace ecole::observation {

using Nothing = data::NoneFunction;

}  // namespace ecole::observation
