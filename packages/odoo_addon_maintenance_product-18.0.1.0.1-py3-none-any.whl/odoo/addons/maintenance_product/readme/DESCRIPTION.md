This module links *Maintenance Equipments* and *Products*, easing
creation of new equipments.
