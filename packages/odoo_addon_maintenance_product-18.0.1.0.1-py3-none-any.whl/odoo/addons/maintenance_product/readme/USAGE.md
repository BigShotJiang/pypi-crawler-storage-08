Equipment Categories:

- Go to *Maintenance \> Configuration \> Equipment Categories* and
  create a new one (or modify an existing one) filling in the new field
  *Product Category*.
- The name of the *Equipment Category* is set to the name of the
  *Product Category*.

Equipment:

- Go to *Maintenance \> Equipments* and create a new one filling in the
  new field *Product*.
- The name of the *Equipment* is set to the name of the *Product*.
- The vendor of the *Equipment* is set to the seller of the *Product*
  (if only one is set).
- The vendor reference of the *Equipment* is set to the seller reference
  of the *Product* (if only one is set).
- The cost of the *Equipment* is set to the standard cost of the
  *Product*.
