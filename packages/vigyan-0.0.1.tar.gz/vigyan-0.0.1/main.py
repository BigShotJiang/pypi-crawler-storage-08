def main():
    print("Hello from vigyan!")


if __name__ == "__main__":
    main()
