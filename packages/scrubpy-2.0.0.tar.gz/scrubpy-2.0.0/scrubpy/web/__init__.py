"""
Modern web interface for ScrubPy with enhanced user experience.
"""

__version__ = "2.0.0"