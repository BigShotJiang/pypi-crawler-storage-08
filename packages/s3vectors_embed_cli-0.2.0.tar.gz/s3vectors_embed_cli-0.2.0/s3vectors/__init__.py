"""S3 Vectors CLI - Standalone tool for vector operations."""

from s3vectors.__version__ import __version__

__author__ = "Vaibhav Sabharwal"
__description__ = "Standalone CLI for S3 Vector operations with Bedrock embeddings"
