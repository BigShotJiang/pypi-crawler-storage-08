"""Configuration module for SAP OData Connector"""
