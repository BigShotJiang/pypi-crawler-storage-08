- Once installed, go to your organization, and set extra settings:

1.  The name of your organization in the author keys of the manifest
    odoo modules (in the **Default Author Text** field)
2.  The URL of the file that contains IDs of your repositories for the
    runbot

![github_organization_form](static/description/github_organization_form.png)

If you had analyzed previously your repositories with the 'github
Connector' module, you should launch again the Analysis Process for all
your Repository Branches.
