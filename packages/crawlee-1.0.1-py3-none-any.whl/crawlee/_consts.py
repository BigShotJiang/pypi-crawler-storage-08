from __future__ import annotations

METADATA_FILENAME = '__metadata__.json'
"""The name of the metadata file for storage clients."""
