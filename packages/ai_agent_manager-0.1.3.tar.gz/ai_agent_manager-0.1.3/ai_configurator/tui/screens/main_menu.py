"""Main menu screen for AI Configurator TUI."""
from textual.app import ComposeResult
from textual.containers import Container, Vertical
from textual.widgets import Header, Footer, Static, Button
from textual.binding import Binding

from ai_configurator.tui.screens.base import BaseScreen
from ai_configurator.services.agent_service import AgentService
from ai_configurator.services.library_service import LibraryService
from ai_configurator.services.registry_service import RegistryService


class MainMenuScreen(BaseScreen):
    """Main menu dashboard with system overview and navigation."""
    
    BINDINGS = [
        Binding("1", "agents", "Agents"),
        Binding("2", "library", "Library"),
        Binding("3", "mcp", "MCP Servers"),
        Binding("4", "settings", "Settings"),
    ]
    
    def compose(self) -> ComposeResult:
        """Build screen layout."""
        yield Header()
        yield Container(
            Static("[bold cyan]AI Configurator v4.0[/bold cyan]\n", id="title"),
            Static(self.get_status_text(), id="status"),
            Vertical(
                Button("1. Agent Management", id="agents", variant="primary"),
                Button("2. Library Management", id="library", variant="primary"),
                Button("3. MCP Servers", id="mcp", variant="primary"),
                Button("4. Settings", id="settings"),
                id="menu"
            ),
            Static("\n[dim]Press Tab to navigate, Enter to select, or use number keys 1-4[/dim]", id="help"),
            id="main-container"
        )
        yield Footer()
    
    def get_status_text(self) -> str:
        """Get system status summary."""
        try:
            from ai_configurator.tui.config import get_agents_dir, get_library_paths, get_registry_dir
            
            agent_service = AgentService(get_agents_dir())
            base_path, personal_path = get_library_paths()
            library_service = LibraryService(base_path, personal_path)
            registry_service = RegistryService(get_registry_dir())
            
            agents = agent_service.list_agents()
            library = library_service.create_library()
            servers = registry_service.get_installed_servers()
            
            file_count = len(library.files)
            
            return f"""
[bold]System Status:[/bold]
  Agents: {len(agents)}
  Library Files: {file_count}
  MCP Servers: {len(servers)}
"""
        except Exception as e:
            return f"[yellow]Status unavailable: {e}[/yellow]"
    
    def refresh_data(self) -> None:
        """Refresh status display."""
        status_widget = self.query_one("#status", Static)
        status_widget.update(self.get_status_text())
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press."""
        button_id = event.button.id
        
        if button_id == "agents":
            self.action_agents()
        elif button_id == "library":
            self.action_library()
        elif button_id == "mcp":
            self.action_mcp()
        elif button_id == "settings":
            self.action_settings()
    
    def action_agents(self) -> None:
        """Navigate to agent management."""
        from ai_configurator.tui.screens.agent_manager import AgentManagerScreen
        self.app.push_screen(AgentManagerScreen())
    
    def action_library(self) -> None:
        """Navigate to library management."""
        from ai_configurator.tui.screens.library_manager import LibraryManagerScreen
        self.app.push_screen(LibraryManagerScreen())
    
    def action_mcp(self) -> None:
        """Navigate to MCP management."""
        from ai_configurator.tui.screens.mcp_manager import MCPManagerScreen
        self.app.push_screen(MCPManagerScreen())
    
    def action_settings(self) -> None:
        """Navigate to settings."""
        from ai_configurator.tui.screens.settings import SettingsScreen
        self.app.push_screen(SettingsScreen())
