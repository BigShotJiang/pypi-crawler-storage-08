# Math Question

What is 2 + 2?