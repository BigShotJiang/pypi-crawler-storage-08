from .concrete_type import ConcreteType

__all__ = ["ConcreteType"]
