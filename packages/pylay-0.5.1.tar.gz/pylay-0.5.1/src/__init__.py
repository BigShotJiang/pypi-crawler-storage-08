"""
pylay - Python type hint と docstrings を利用した
types <-> docs 間の透過的なジェネレータ

このパッケージは、Pythonの型情報とドキュメントを相互変換する機能を提供します。
"""

__version__ = "0.1.0"
