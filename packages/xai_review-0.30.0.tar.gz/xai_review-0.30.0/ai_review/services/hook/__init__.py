from ai_review.services.hook.service import HookService

hook = HookService()

__all__ = ["hook"]
