from .log import create_log_model
