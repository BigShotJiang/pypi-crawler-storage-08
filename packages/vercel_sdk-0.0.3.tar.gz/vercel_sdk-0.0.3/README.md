# vercel-sdk

Python SDK for Vercel.


## Installation

```bash
pip install vercel-sdk
```

## Requirements

- Python 3.9+

## Basic usage

```python
from vercel.functions.headers import get_headers
```

## License

MIT


