class EmailServiceConfigError(RuntimeError):
    pass


class EmailServiceAttachmentError(RuntimeError):
    pass
