"""Class-based emails including a test suite for Django"""

__version__ = "2.7.4"
