django-pony-express
===================

.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   features/introduction.md
   features/configuration.md
   features/factories.md
   features/internal_api.md
   features/tests.md
   features/changelog.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
