# ETF data extension for OpenBB SDK

This extension provides a set of commands for ETF data retrieval.

## Installation

To install the extension, run the following command in this folder:

```bash
pip install openbb-etf
```
