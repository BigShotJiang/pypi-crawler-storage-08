# Llun CLI

Llun CLI is the initial delivery for the Llun tool - a robust cli command suite for scanning your codebases. this tool is moddled after Astrals 'ruff' tool, and is considered the core product offering of Llun.