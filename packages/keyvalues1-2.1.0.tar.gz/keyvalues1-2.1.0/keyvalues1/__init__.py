from .parser import KeyValues1

__all__ = [
    "KeyValues1",
]
