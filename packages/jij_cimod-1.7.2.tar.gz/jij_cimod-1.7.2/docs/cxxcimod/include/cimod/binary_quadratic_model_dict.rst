Binary Quadratic Model Dict
===========================
.. autodoxygenfile:: binary_quadratic_model_dict.hpp
   :project: cimod
