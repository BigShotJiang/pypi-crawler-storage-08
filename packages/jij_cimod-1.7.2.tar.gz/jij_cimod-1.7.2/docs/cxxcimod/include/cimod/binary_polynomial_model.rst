Binarg Polynomial Model
=======================
.. autodoxygenfile:: binary_polynomial_model.hpp
   :project: cimod
