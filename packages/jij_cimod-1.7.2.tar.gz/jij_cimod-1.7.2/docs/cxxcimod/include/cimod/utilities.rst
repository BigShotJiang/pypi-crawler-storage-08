Utilities
======================
.. autodoxygenfile:: utilities.hpp
   :project: cimod
