Binary Quadratic Model
======================
.. autodoxygenfile:: binary_quadratic_model.hpp
   :project: cimod
