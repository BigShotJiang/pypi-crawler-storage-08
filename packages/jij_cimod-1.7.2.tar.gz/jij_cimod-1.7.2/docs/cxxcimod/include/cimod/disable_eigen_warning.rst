Disable Eigen Warning
======================
.. autodoxygenfile:: disable_eigen_warning.hpp
   :project: cimod
