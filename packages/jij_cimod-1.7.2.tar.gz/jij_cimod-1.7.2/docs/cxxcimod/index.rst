:py:mod:`cimod.cxxcimod`
========================

.. automodule:: cimod.cxxcimod
   :members:
   :undoc-members:
   :inherited-members:
