---
version: "1.0.0"
last_updated: "2025-09-02"
author: "Marcelus Fernandes"
template_type: "strategic_report"
used_by: ["agent-5-strategic-report-generator.md"]
purpose: "Structure strategic reports with executive summaries and detailed analysis"
---

# Report Template

## Executive Summary
- **Summary of Findings:**

## Detailed Analysis
- **Section 1:**
  - **Key Points:**

## Conclusions
- **Conclusion 1:** Description

## Appendices
- **Appendix A:** Description
