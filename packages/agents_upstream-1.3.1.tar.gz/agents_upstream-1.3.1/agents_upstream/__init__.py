"""
Agents Upstream - AI-powered research analysis system for product discovery.
"""

__version__ = "1.3.1"
__author__ = "Agents Upstream Contributors"
__license__ = "MIT"

