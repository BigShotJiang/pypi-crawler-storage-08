from .json_store import JSONStore

__version__ = "4.3"

open = JSONStore
