class PGCopySignatureError(ValueError):
    """Signature not match."""


class PGCopyRecordError(ValueError):
    """Record length error."""
