"""CLI adapter for DeltaGlider."""
