class RealType:
    def __init__(self, value=42):
        self.value = value
