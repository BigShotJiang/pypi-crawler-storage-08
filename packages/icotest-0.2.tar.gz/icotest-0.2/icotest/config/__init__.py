"""Configuration support for tests"""

# -- Exports ------------------------------------------------------------------

from .config import ConfigurationUtility, settings
