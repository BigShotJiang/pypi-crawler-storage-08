"""Setup of the python module."""

from setuptools import setup  # pragma: no cover

setup()  # pragma: no cover
