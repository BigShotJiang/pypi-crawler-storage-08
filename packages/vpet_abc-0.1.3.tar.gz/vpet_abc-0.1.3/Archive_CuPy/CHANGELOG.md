// Change History:
// 17/04/2024 - Qinlin (Alistair) Gu - Added other distance functions, and 
//                                     validation mode.
// 15/04/2024 - Qinlin (Alistair) Gu - Correction for discrete convolution 
//                                     approximation errors.
// 26/03/2024 - Qinlin (Alistair) Gu - Initial creation of the header.
