"""django-global-search."""

from importlib.metadata import version

__version__ = version("django-global-search")
