from typing import Literal

Reference = Literal["GRCh37", "GRCh38"]
