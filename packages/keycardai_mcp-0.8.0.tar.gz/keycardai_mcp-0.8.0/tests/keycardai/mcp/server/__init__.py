"""Tests for keycardai.mcp.server package."""
