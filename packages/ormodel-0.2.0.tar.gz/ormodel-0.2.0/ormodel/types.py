# This file can be used for custom type hints if needed later.
# For now, it can remain empty or contain common type aliases.

# from typing import TypeVar
# from sqlmodel import SQLModel

# ModelType = TypeVar("ModelType", bound=SQLModel)
