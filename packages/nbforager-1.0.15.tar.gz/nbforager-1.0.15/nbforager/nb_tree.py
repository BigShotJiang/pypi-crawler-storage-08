"""Tree of Netbox model objects."""

import logging
from copy import deepcopy
from typing import Optional

from pydantic import BaseModel, Field
from vhelpers import vstr

from nbforager import ami
from nbforager.types_ import DiDAny, LStr, DAny, T2Str


class BaseTree(BaseModel):
    """Base for BbTree models."""

    def __repr__(self):
        """__repr__."""
        class_ = self.__class__.__name__
        params = vstr.repr_info(**{s: len(getattr(self, s)) for s in self.models()})
        return f"<{class_}: {params}>"

    def clear(self) -> None:
        """Clear all data in all models."""
        for model in self.models():
            getattr(self, model).clear()

    def count(self) -> int:
        """Count the number of Netbox objects for all models."""
        return sum(len(getattr(self, s)) for s in self.models())

    def models(self) -> LStr:
        """Get all application model names.

        :return: Model names.

        :example:
            NbTree().circuits.models() -> ["circuit_terminations", "circuit_types", ...]
        """
        return list(self.__annotations__)


# noinspection DuplicatedCode
class CircuitsM(BaseTree):
    """Base for Circuits application."""

    circuit_group_assignments: DiDAny = Field(default={})
    circuit_groups: DiDAny = Field(default={})
    circuit_terminations: DiDAny = Field(default={})
    circuit_types: DiDAny = Field(default={})
    circuits: DiDAny = Field(default={})
    provider_accounts: DiDAny = Field(default={})
    provider_networks: DiDAny = Field(default={})
    providers: DiDAny = Field(default={})
    virtual_circuit_terminations: DiDAny = Field(default={})
    virtual_circuit_types: DiDAny = Field(default={})
    virtual_circuits: DiDAny = Field(default={})


class CoreM(BaseTree):
    """Base for Core application."""

    background_queues: DiDAny = Field(default={})
    background_tasks: DiDAny = Field(default={})
    background_workers: DiDAny = Field(default={})
    data_files: DiDAny = Field(default={})
    data_sources: DiDAny = Field(default={})
    jobs: DiDAny = Field(default={})
    object_changes: DiDAny = Field(default={})


class DcimM(BaseTree):
    """Base for DCIM application."""

    cable_terminations: DiDAny = Field(default={})
    cables: DiDAny = Field(default={})
    # connected_device, is not model
    console_port_templates: DiDAny = Field(default={})
    console_ports: DiDAny = Field(default={})
    console_server_port_templates: DiDAny = Field(default={})
    console_server_ports: DiDAny = Field(default={})
    device_bay_templates: DiDAny = Field(default={})
    device_bays: DiDAny = Field(default={})
    device_roles: DiDAny = Field(default={})
    device_types: DiDAny = Field(default={})
    devices: DiDAny = Field(default={})
    front_port_templates: DiDAny = Field(default={})
    front_ports: DiDAny = Field(default={})
    interface_templates: DiDAny = Field(default={})
    interfaces: DiDAny = Field(default={})
    inventory_item_roles: DiDAny = Field(default={})
    inventory_item_templates: DiDAny = Field(default={})
    inventory_items: DiDAny = Field(default={})
    locations: DiDAny = Field(default={})
    mac_addresses: DiDAny = Field(default={})
    manufacturers: DiDAny = Field(default={})
    module_bay_templates: DiDAny = Field(default={})
    module_bays: DiDAny = Field(default={})
    module_type_profiles: DiDAny = Field(default={})
    module_types: DiDAny = Field(default={})
    modules: DiDAny = Field(default={})
    platforms: DiDAny = Field(default={})
    power_feeds: DiDAny = Field(default={})
    power_outlet_templates: DiDAny = Field(default={})
    power_outlets: DiDAny = Field(default={})
    power_panels: DiDAny = Field(default={})
    power_port_templates: DiDAny = Field(default={})
    power_ports: DiDAny = Field(default={})
    rack_reservations: DiDAny = Field(default={})
    rack_roles: DiDAny = Field(default={})
    rack_types: DiDAny = Field(default={})
    racks: DiDAny = Field(default={})
    rear_port_templates: DiDAny = Field(default={})
    rear_ports: DiDAny = Field(default={})
    regions: DiDAny = Field(default={})
    site_groups: DiDAny = Field(default={})
    sites: DiDAny = Field(default={})
    virtual_chassis: DiDAny = Field(default={})
    virtual_device_contexts: DiDAny = Field(default={})


class ExtrasM(BaseTree):
    """Base for extras application."""

    bookmarks: DiDAny = Field(default={})
    config_contexts: DiDAny = Field(default={})
    config_templates: DiDAny = Field(default={})
    content_types: DiDAny = Field(default={})
    custom_field_choice_sets: DiDAny = Field(default={})
    custom_fields: DiDAny = Field(default={})
    custom_links: DiDAny = Field(default={})
    event_rules: DiDAny = Field(default={})
    export_templates: DiDAny = Field(default={})
    image_attachments: DiDAny = Field(default={})
    journal_entries: DiDAny = Field(default={})
    notification_groups: DiDAny = Field(default={})
    notifications: DiDAny = Field(default={})
    object_changes: DiDAny = Field(default={})
    object_types: DiDAny = Field(default={})
    reports: DiDAny = Field(default={})
    saved_filters: DiDAny = Field(default={})
    scripts: DiDAny = Field(default={})
    subscriptions: DiDAny = Field(default={})
    table_configs: DiDAny = Field(default={})
    tagged_objects: DiDAny = Field(default={})
    tags: DiDAny = Field(default={})
    webhooks: DiDAny = Field(default={})


class IpamM(BaseTree):
    """Base for IPAM application."""

    aggregates: DiDAny = Field(default={})
    asn_ranges: DiDAny = Field(default={})
    asns: DiDAny = Field(default={})
    fhrp_group_assignments: DiDAny = Field(default={})
    fhrp_groups: DiDAny = Field(default={})
    ip_addresses: DiDAny = Field(default={})
    ip_ranges: DiDAny = Field(default={})
    l2vpn_terminations: DiDAny = Field(default={})
    l2vpns: DiDAny = Field(default={})
    prefixes: DiDAny = Field(default={})
    rirs: DiDAny = Field(default={})
    roles: DiDAny = Field(default={})
    route_targets: DiDAny = Field(default={})
    service_templates: DiDAny = Field(default={})
    services: DiDAny = Field(default={})
    vlan_groups: DiDAny = Field(default={})
    vlan_translation_policies: DiDAny = Field(default={})
    vlan_translation_rules: DiDAny = Field(default={})
    vlans: DiDAny = Field(default={})
    vrfs: DiDAny = Field(default={})


# noinspection DuplicatedCode
class TenancyM(BaseTree):
    """Base for Tenancy application."""

    contact_assignments: DiDAny = Field(default={})
    contact_groups: DiDAny = Field(default={})
    contact_roles: DiDAny = Field(default={})
    contacts: DiDAny = Field(default={})
    tenant_groups: DiDAny = Field(default={})
    tenants: DiDAny = Field(default={})


class UsersM(BaseTree):
    """Base for Users application."""

    # config: is not DiDAny
    groups: DiDAny = Field(default={})
    permissions: DiDAny = Field(default={})
    tokens: DiDAny = Field(default={})
    users: DiDAny = Field(default={})


class VirtualizationM(BaseTree):
    """Base for Virtualization application."""

    cluster_groups: DiDAny = Field(default={})
    cluster_types: DiDAny = Field(default={})
    clusters: DiDAny = Field(default={})
    interfaces: DiDAny = Field(default={})
    virtual_disks: DiDAny = Field(default={})
    virtual_machines: DiDAny = Field(default={})


class VpnM(BaseTree):
    """Base for Vpn application."""

    ike_policies: DiDAny = Field(default={})
    ike_proposal: DiDAny = Field(default={})
    ipsec_policies: DiDAny = Field(default={})
    ipsec_profiles: DiDAny = Field(default={})
    ipsec_proposals: DiDAny = Field(default={})
    l2vpn_terminations: DiDAny = Field(default={})
    l2vpns: DiDAny = Field(default={})
    tunnel_groups: DiDAny = Field(default={})
    tunnel_terminations: DiDAny = Field(default={})
    tunnels: DiDAny = Field(default={})


class WirelessM(BaseTree):
    """Base for Wireless application."""

    wireless_lan_groups: DiDAny = Field(default={})
    wireless_lans: DiDAny = Field(default={})
    wireless_links: DiDAny = Field(default={})


class NbTree(BaseModel):
    """Structure that holds Netbox objects as dictionaries.

    Model: NbTree.{app}.{model}[id] = data.

    - ``{app}`` - Attribute representing application name.
    - ``{model}`` - Attribute representing model name.
    - ``id`` - Unique identifier of Netbox object.
    - ``data`` - Netbox object data as a dictionary.
    """

    circuits: CircuitsM = Field(default=CircuitsM())
    core: CoreM = Field(default=CoreM())
    dcim: DcimM = Field(default=DcimM())
    extras: ExtrasM = Field(default=ExtrasM())
    ipam: IpamM = Field(default=IpamM())
    # plugins have different model
    tenancy: TenancyM = Field(default=TenancyM())
    users: UsersM = Field(default=UsersM())
    virtualization: VirtualizationM = Field(default=VirtualizationM())
    vpn: VpnM = Field(default=VpnM())
    wireless: WirelessM = Field(default=WirelessM())

    def __repr__(self):
        """__repr__."""
        class_ = self.__class__.__name__
        params = vstr.repr_info(**{s: getattr(self, s).count() for s in self.apps()})
        return f"<{class_}: {params}>"

    def apps(self) -> LStr:
        """Get all application names.

        :return: Application names.

        :example:
            NbTree().apps() -> ["circuit_terminations", "circuit_types", ...]
        """
        return list(self.__annotations__)

    def clear(self) -> None:
        """Clear all data in all models."""
        for app in self.apps():
            getattr(self, app).clear()

    def count(self) -> int:
        """Count the number of Netbox objects for all models."""
        return sum(getattr(self, s).count() for s in self.apps())


ONbTree = Optional[NbTree]


def insert_tree(src: NbTree, dst: NbTree) -> None:
    """Insert the data from the source NbTree object into the destination NbTree object.

    :param src: The source tree from which data will be copied.
    :param dst: The destination tree where data will be inserted.

    :return: None. The data is updated in the destination tree.
    """
    for app in src.apps():
        for model in getattr(src, app).models():
            src_d: dict = getattr(getattr(src, app), model)
            dst_d: dict = getattr(getattr(dst, app), model)
            dst_d.update(src_d)


def join_tree(tree: NbTree) -> NbTree:
    """Assemble Netbox objects in tree within itself.

    The Netbox objects are represented as a multidimensional dictionary.
    :param tree: NbTree object to join the data in.

    :return: NbTree object with the joined data.
    """
    tree = deepcopy(tree)
    for app in tree.apps():  # pylint: disable=R1702
        for model in getattr(tree, app).models():
            objects_d = getattr(getattr(tree, app), model)
            for _, parent in objects_d.items():
                for key, child in parent.items():
                    if isinstance(child, dict):
                        if child_full := _get_child(child=child, tree=tree):
                            parent[key].clear()
                            parent[key].update(child_full)
                    elif isinstance(child, list):
                        for child_ in child:
                            if not isinstance(child_, dict):
                                continue
                            if child_full := _get_child(child=child_, tree=tree):
                                child_.clear()
                                child_.update(child_full)
    return tree


def missed_urls(urls: LStr, tree: NbTree) -> LStr:
    """Return URLs to objects that are missed in the tree.

    :param urls: A list of URLs to filter.
    :param tree: NbTree object to check URLs inside.

    :return: A list of URLs that are missed in the tree.
    """
    urls_: LStr = []
    for url in urls:
        url = url.rstrip("/")
        app, model, digit = url.split("/")[-3:]
        model = ami.model_to_attr(model)
        id_ = int(digit)

        try:
            data: DAny = getattr(getattr(tree, app), model).get(id_)
        except AttributeError as ex:
            logging.error(str(f"{type(ex).__name__}: {ex}"))
            continue

        if not data:
            urls_.append(url)
    return urls_


def object_type_to_am(object_type: str, path: bool = False) -> T2Str:
    """Convert object_type value (used in extras/changelog) to app/model values.

    :param object_type: object_type value.
    :param path: True - model as path with `-` character,
        False - model as attribute with `_` character,
    :return: Tuple of app, model.

    :example:
        object_type_to_ami("ipam.ipaddress") -> "ipam", "ip_addresses"
    """
    app_type, model_type = object_type.split(".")

    if model_type == "vminterface":
        model_type = "interface"

    tree = NbTree()
    for app in tree.apps():
        if app != app_type:
            continue
        models: LStr = getattr(tree, app).models()
        for model in models:
            if model[:2] != model_type[:2]:
                continue

            model_singular = ami.model_singular(model)
            if model_singular == model_type:
                if path:
                    model = model.replace("_", "-")
                return app, model

    raise ValueError(f"{object_type=} is not defined.")


# ============================= helpers ==============================


def _get_child(child: DAny, tree: NbTree) -> DAny:
    """Search child Netbox object in the model data to insert (replace) it in the parent.

    :param child: Netbox object that require dependency update.
    :param tree: NbTree object, contains model data (Netbox objects).

    :return: Child dictionary from the model that needs to be inserted into the parent dictionary.
    """
    if child.get("url"):
        url = str(child["url"]).strip("/")
        app, model, digit = ami.url_to_ami_items(url)
        model = ami.model_to_attr(model)
        if model_d := getattr(getattr(tree, app), model):
            if child_full := model_d.get(int(digit)):
                return child_full

    if child.get("object_id") and child.get("object"):
        if isinstance(child["object"], dict):
            child_full = _get_child(child["object"], tree)
            child["object"].clear()
            child["object"].update(child_full)
            return {}

    return {}
