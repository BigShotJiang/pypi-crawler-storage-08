"""Example modules used in documentation and tests."""
