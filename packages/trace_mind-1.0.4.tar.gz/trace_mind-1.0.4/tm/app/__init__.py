"""App package initialization."""
