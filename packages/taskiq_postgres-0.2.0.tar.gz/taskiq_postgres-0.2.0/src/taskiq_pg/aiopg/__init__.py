from taskiq_pg.aiopg.result_backend import AiopgResultBackend


__all__ = [
    "AiopgResultBackend",
]
