"""
API callbacks!
"""

# ======================================================================================


"""
Simulate publishing something.
"""
def publish():
    print("Publishing...")

#----------------------------------------

"""
Simulate checking status.
"""
def version():
    print("2.2")

#----------------------------------------

"""
Simulate checking status.
"""
def status():
    print("Status: OK")