# SPDX-License-Identifier: Apache-2.0
# Copyright © 2025 Rajeshwar Dhayalan and Contributors

# Define SDK-specific exceptions here as needed.