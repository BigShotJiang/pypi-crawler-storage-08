from .fastembedder import FastEmbedder

__all__ = ["FastEmbedder"]
