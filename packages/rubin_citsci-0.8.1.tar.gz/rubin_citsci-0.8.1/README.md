# CitSci Notebook Core Pipeline

This is intended to be used on the Vera Rubin Observatory's Science Platform (RSP) in the hosted Notebook Aspect at http://data.lsst.cloud. This package will not work in any other environment.