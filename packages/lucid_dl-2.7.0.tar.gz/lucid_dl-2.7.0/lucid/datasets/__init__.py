# TODO: implement per-batch data loading and transformations
from .mnist import *
from .cifar import *
