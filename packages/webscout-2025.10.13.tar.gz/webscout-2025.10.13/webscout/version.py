__version__ = "2025.10.13"
__prog__ = "webscout"
