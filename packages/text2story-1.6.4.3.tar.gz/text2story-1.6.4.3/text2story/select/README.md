A module designed to select a narrative object (event, time, or participant) according given conditions, and return it. 
