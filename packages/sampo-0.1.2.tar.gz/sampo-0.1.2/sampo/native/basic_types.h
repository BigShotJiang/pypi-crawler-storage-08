#pragma once

#include <string>

class Identifiable {
public:
    std::string id;
};

