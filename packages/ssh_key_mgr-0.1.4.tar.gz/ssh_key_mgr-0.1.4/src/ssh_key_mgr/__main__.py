from ssh_key_mgr.cli.app import main

if __name__ == "__main__":
    main()
