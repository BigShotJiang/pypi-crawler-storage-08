"""OpenBB Technical Analysis Extension."""
