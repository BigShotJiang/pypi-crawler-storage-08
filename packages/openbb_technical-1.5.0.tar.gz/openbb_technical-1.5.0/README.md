# OpenBB Technical Analysis Extension

This extension provides Technical Analysis  tools for the OpenBB Platform.

Features of the extension include various indicators and oscillators.

This extension works nicely with a companion `openbb-charting` extension

## Installation

To install the extension, run the following command in this folder:

```bash
pip install openbb-technical
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
