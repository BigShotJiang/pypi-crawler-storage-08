This module does not add any business or technical functionality. It only
contains tests for the `auditlog` module that depend on models from modules
that are not a dependency of `auditlog` itself. Don't install this module on
your database unless you want to run its tests.
