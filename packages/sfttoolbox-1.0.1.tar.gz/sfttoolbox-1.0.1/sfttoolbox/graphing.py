__all__ = ["create_digraph"]

import networkx as nx


def create_digraph():
    return nx.DiGraph()
