"""
Este archivo de inicio permite que los subdirectorios se comporten como paquetes Python.

Author: Json Rivera
Date: 2025-09-26
"""