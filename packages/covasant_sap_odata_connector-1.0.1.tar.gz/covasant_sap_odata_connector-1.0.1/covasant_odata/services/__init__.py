"""Services module for SAP OData Connector"""
