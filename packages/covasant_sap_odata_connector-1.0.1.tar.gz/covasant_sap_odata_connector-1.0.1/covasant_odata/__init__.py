"""
SAP OData Connector - Resilient and high-throughput data ingestion connector
"""

__version__ = "1.0.0"
__author__ = "SAP OData Connector Team"
