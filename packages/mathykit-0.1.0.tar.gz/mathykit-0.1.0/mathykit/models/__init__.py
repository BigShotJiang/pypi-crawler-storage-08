"""Model implementations for MathyKit."""

from .meta_opt import MetaOPT

__all__ = ["MetaOPT"]