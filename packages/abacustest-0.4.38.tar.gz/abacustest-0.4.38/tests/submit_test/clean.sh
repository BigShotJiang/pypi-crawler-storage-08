test -d result && rm -rf result
test -f abacustest.log && rm -rf abacustest.log
