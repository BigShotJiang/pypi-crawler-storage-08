"""Allow ssl_checkup to be executed as a module with -m flag."""

from .main import main

if __name__ == "__main__":
    main()
