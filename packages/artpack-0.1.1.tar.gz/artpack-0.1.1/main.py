def main():
    print("Hello from artpack!")


if __name__ == "__main__":
    main()
