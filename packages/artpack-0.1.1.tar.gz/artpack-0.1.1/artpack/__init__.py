from .palettes import art_pals
from .palettes import pals
