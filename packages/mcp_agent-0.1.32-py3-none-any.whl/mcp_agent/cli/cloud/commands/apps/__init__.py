"""MCP Agent Cloud apps command."""

from .list import list_apps

__all__ = ["list_apps"]
