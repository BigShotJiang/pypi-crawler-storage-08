pathsim.optim.operator module
=============================

.. automodule:: pathsim.optim.operator
   :members:
   :show-inheritance:
   :undoc-members:
