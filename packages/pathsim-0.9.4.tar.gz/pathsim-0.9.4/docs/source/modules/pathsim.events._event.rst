pathsim.events._event module
============================

.. automodule:: pathsim.events._event
   :members:
   :show-inheritance:
   :undoc-members:
