pathsim.utils.realtimeplotter module
====================================

.. automodule:: pathsim.utils.realtimeplotter
   :members:
   :show-inheritance:
   :undoc-members:
