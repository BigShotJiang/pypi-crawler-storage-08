pathsim.optim.numerical module
==============================

.. automodule:: pathsim.optim.numerical
   :members:
   :show-inheritance:
   :undoc-members:
