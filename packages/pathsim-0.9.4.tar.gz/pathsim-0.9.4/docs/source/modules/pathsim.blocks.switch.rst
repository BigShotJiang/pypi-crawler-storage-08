pathsim.blocks.switch module
============================

.. automodule:: pathsim.blocks.switch
   :members:
   :show-inheritance:
   :undoc-members:
