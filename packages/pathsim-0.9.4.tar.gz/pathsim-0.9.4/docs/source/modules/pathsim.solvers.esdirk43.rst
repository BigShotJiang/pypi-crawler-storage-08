pathsim.solvers.esdirk43 module
===============================

.. automodule:: pathsim.solvers.esdirk43
   :members:
   :show-inheritance:
   :undoc-members:
