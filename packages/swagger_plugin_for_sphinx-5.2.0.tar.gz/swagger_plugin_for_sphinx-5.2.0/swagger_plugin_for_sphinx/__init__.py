"""Sphinx Swagger Plugin."""

from __future__ import annotations

from swagger_plugin_for_sphinx._plugin import setup

__all__ = ("setup",)
