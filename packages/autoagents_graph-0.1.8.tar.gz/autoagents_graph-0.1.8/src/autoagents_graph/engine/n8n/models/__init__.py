"""
Models module for n8n.

This module contains data models for N8N platform.
"""

# TODO: Implement N8N data models
# Example: N8NNode, N8NEdge, N8NWorkflow, N8NConfig, etc.

__all__ = []

