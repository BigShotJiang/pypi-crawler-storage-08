"""
xNode Performance Tests
======================

Performance benchmarking and profiling tests for xNode operations.
"""

__version__ = "1.0.0" 