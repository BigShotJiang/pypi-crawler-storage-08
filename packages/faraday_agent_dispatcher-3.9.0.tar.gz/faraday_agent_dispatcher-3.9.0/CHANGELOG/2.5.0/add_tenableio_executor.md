[ADD] Add tenableio executor
