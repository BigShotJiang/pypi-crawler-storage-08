[FIX] Now if a venv is int or float it will convert to string
