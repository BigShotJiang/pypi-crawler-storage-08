[FIX] Make gvm executor compatible with new version of python-gvm
