[ADD] Add new Sonar Qube executor
