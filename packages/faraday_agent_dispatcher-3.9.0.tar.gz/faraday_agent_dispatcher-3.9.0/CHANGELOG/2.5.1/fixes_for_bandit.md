[MOD] Add a fixes for bandit vuln:
- Replace assert return code with a if
- Remove default x_token in nessus executor
