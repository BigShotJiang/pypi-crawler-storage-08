[DEL] Now nuclei doesn't check if the target is an ip
