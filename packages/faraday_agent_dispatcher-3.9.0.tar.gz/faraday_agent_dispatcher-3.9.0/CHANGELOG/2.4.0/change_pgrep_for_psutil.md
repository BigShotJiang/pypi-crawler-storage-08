[MOD] Change pgrep for psutil in zap executor
