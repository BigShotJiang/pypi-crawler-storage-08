[Faraday][faraday] versions: 3.11, 3.11.1, 3.11.2
