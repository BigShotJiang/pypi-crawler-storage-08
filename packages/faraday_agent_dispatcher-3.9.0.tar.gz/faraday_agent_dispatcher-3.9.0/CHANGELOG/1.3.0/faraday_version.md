[Faraday][faraday] versions: 3.12.0
