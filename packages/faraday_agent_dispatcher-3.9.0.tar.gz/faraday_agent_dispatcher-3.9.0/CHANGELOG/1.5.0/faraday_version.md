[Faraday][faraday] versions: 3.14.3, 3.15.0, 3.15.1
