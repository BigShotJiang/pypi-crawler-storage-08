[faraday]: https://github.com/infobyte/faraday
[doc]: https://docs.agents.faradaysec.com
[api]: https://api.faradaysec.com
