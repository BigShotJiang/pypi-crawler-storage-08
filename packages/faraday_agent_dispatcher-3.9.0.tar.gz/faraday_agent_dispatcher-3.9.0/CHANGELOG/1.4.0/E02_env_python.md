Fix bug nmap and nessus executors to execute with the dispatcher environment
