[Faraday][faraday] versions: 3.14.0, 3.14.1, 3.14.2
