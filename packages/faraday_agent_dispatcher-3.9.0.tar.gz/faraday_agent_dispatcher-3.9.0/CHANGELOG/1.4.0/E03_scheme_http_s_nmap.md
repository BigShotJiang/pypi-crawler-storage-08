Fix nmap executor when http(s) scheme passed as target
