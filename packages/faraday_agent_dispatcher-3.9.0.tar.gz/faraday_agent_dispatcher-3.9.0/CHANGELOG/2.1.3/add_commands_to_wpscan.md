Add --api-token --random-user-agent to wpscan
