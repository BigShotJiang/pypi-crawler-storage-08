Move shodan executor to official and change logic to work with plugins
