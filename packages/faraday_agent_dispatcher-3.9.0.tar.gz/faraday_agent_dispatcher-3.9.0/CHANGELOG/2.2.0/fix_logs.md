Fix logs and change .format to fstrings
