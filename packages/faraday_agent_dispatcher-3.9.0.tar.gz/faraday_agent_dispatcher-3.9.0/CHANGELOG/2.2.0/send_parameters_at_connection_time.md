Now faraday-dispatcher send the parameters of the executors when it
connects to faraday server. Also it checks if there are new enviroment
variables defined in the manifest file and warn the user.
