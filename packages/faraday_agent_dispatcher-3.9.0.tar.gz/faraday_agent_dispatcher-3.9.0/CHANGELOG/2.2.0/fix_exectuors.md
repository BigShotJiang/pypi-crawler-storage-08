Nessus now list in the logs the available templates and uses posixpath.join instead of concat strings.
Nikto now uses only requieres TARGET_URL argument.
