Add ignore_info and hostname_resolution options for most executors.
