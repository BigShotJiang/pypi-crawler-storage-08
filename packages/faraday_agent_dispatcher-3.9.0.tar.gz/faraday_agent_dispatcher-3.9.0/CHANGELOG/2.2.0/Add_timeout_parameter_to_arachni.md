Add timeout parameter to arachni's executor
