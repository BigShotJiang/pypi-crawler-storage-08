Remove ws from dispatcher.yaml.
