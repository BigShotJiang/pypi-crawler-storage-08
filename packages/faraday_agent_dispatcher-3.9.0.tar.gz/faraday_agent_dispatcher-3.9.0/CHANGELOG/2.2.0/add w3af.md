Add python2.7, w3af and its dependencies to docker image
