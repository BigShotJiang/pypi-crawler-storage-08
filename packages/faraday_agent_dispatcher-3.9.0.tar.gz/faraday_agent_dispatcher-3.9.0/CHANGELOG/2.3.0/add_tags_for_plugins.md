Add tags for plugins
