Now the api-key from zap is a enviroment variable
