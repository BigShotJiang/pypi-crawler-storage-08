Add installation in docker file for nmap script: vulners
