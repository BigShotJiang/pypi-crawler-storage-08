Now InsighVM's executer will executa a scan if a site_id is provided
