ADD script to nmap logic
