[Faraday][faraday] versions: 3.16.0, 3.16.1, 3.16.2, 3.17.0, 3.17.1, 3.17.2
