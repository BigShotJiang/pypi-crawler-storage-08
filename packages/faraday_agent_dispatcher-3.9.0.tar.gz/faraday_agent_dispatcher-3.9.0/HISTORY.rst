=======
History
=======

0.1 (2019-10-31 🎃)
-------------------

* First release on PyPI.
