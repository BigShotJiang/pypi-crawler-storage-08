import capnp  # noqa

import scaler.protocol.capnp.common_capnp as _common  # noqa
import scaler.protocol.capnp.message_capnp as _message  # noqa
import scaler.protocol.capnp.object_storage_capnp as _object_storage  # noqa
import scaler.protocol.capnp.status_capnp as _status  # noqa
