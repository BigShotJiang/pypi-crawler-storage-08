class IncompatibleOptions(Exception):

    """
    Exception class for simultaneous use of incompatible options.
    """

    pass
