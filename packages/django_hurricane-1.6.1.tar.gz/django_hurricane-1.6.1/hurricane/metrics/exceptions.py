class MetricIdAlreadyRegistered(Exception):

    """
    Exception class for the case, that metric was already registered and should not be registered twice.
    """

    pass
