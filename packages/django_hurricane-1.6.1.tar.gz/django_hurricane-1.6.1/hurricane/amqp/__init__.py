from hurricane.amqp.loggers import logger  # noqa: F401
