from dataclasses import dataclass

@dataclass
class LaserInfo:
    model: str
    serial_no: str
    firmware: str

