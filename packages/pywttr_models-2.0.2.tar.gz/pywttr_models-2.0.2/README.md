# pywttr-models

[![CI](https://github.com/monosans/pywttr-models/actions/workflows/ci.yml/badge.svg)](https://github.com/monosans/pywttr-models/actions/workflows/ci.yml)
[![Downloads](https://static.pepy.tech/badge/pywttr-models)](https://pepy.tech/project/pywttr-models)

Internal library for [pywttr](https://github.com/monosans/pywttr) and [aiopywttr](https://github.com/monosans/aiopywttr).

## License

[MIT](https://github.com/monosans/pywttr-models/blob/main/LICENSE)
