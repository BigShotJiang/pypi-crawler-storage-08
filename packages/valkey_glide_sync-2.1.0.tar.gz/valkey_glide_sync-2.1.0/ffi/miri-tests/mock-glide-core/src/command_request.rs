// Copyright Valkey GLIDE Project Contributors - SPDX Identifier: Apache-2.0

pub use glide_core::command_request::{Routes, SimpleRoutes, SlotTypes};

pub mod routes {
    pub use glide_core::command_request::routes::Value;
}
