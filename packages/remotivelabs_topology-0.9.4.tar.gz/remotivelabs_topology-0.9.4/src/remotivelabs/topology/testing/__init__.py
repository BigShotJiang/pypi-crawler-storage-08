__doc__ = "Functions to help validate asynchronous streams"
