from setuptools import setup, find_packages

setup(
    name='one_step_frames',
    version='1.3.5',
    packages=find_packages(),
)
