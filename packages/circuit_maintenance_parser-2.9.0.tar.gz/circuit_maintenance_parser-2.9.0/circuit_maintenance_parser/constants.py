"""Constants used in the library."""

EMAIL_HEADER_SUBJECT = "email-header-subject"
EMAIL_HEADER_DATE = "email-header-date"
