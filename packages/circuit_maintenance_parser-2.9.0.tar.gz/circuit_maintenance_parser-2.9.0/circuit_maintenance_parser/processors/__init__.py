"""Init module for processors."""
