"""Format tox.ini files."""

from __future__ import annotations

from .version import __version__

__all__ = [
    "__version__",
]
