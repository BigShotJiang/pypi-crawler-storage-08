"""
Pipeline module for orchestrating transformation passes.
"""

from r2morph.pipeline.pipeline import Pipeline

__all__ = ["Pipeline"]
