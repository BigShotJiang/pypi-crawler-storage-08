from tasteful.authz.zitadel.middleware import ZitadelAuthorizationMiddleware


# TODO:  Remove in next release (0.4.0 ?)
ZitadelAuthorizationBackend = ZitadelAuthorizationMiddleware
