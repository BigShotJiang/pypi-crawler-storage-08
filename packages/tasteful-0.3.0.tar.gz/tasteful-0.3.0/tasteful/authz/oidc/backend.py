from tasteful.authz.oidc.middleware import OIDCAuthorizationMiddleware


# TODO: Remove in next release (0.4.0 ?)
OIDCAuthorizationBackend = OIDCAuthorizationMiddleware
