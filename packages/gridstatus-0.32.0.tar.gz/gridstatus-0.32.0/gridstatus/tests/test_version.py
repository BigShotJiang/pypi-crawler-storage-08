from gridstatus import __version__


def test_version():
    assert __version__ == "0.32.0"
