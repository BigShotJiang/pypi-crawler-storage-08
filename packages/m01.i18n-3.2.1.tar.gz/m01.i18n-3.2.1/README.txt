This package provides a i18n aware content base class for Zope3 using the 
mongodb instead of ZODB.
