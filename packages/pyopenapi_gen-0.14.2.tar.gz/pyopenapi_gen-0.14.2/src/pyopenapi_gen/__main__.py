"""Main entry point for the pyopenapi_gen CLI."""

from .cli import app

if __name__ == "__main__":
    app()
