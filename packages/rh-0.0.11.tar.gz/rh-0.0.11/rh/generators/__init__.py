"""
Empty module init
"""
