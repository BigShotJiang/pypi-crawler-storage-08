# blepcord
A framework for interacting with Discord using only the HTTP API.
