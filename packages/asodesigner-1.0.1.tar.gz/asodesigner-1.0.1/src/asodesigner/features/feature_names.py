SENSE_START = 'sense_start'
SENSE_LENGTH = 'sense_length'