# Usage

To use ssbc in a project:

```python
import ssbc
```
