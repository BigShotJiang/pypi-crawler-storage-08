from __future__ import annotations


def function(x: bool, y: int = 1) -> str:
    """
    Function docstring.

    :param x: foo
    :param y: bar
    """
