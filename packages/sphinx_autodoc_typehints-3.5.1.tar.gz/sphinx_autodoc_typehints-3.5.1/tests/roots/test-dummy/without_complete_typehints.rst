:orphan:

Simple Module
=============

.. autofunction:: dummy_module_without_complete_typehints.function_with_some_defaults_and_without_typehints
.. autofunction:: dummy_module_without_complete_typehints.function_with_some_defaults_and_some_typehints
.. autofunction:: dummy_module_without_complete_typehints.function_with_some_defaults_and_more_typehints
.. autofunction:: dummy_module_without_complete_typehints.function_with_defaults_and_some_typehints
