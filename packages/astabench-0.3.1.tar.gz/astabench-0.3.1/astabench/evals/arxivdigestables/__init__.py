from .task import arxivdigestables, arxivdigestables_test, arxivdigestables_validation

__all__ = ["arxivdigestables", "arxivdigestables_test", "arxivdigestables_validation"]
