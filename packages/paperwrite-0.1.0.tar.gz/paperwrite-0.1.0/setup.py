from setuptools import setup, find_packages

setup(
    name='paperwrite',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
    ],
    author='Your name',
    author_email='zhc20150305@sina.com',
    description='你可以在里面写字',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)