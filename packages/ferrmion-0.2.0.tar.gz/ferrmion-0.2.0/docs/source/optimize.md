# Optimizations

## Enumeration

```{eval-rst}
.. automodule:: ferrmion.optimize.enumeration
   :members:
   :undoc-members:
   :show-inheritance:
```

## Ternary Tree

```{eval-rst}
.. automodule:: ferrmion.optimize.rett
   :members:
   :undoc-members:
   :show-inheritance:
```
