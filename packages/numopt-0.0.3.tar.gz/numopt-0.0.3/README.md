**NumOpt is a Numerical Optimization Tool Python package that helps you design and optimize engineered systems.**

```
pip install NumOpt
```