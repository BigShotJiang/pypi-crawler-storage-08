from NumOpt.opti import *
from NumOpt.cprint import *

__version__ = "0.0.3"