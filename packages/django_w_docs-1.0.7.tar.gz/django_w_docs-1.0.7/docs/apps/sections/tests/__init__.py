"""Tests for docs.sections"""
