"""Tests for docs.indexes"""
