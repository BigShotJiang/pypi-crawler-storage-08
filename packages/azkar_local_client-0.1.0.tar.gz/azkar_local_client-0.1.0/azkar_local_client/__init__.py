from .client import get_random_zikr

__version__ = "0.1.0"

