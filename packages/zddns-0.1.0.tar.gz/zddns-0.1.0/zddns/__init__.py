"""ZDDNS - Update Cloudflare DNS records with your network's external IP address."""

__version__ = "0.1.0"
