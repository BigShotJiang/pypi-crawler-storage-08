def cmp_run():
    pass
