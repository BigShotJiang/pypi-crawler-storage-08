from pathlib import Path

# we should make this a proper package that loads examples
# similar how they handle it in xarray:
# https://github.com/pydata/xarray/blob/main/xarray/tutorial.py
# Currently there are simple paths to the examples which are then easily loaded in the notebooks
nordic44_knowledge_graph = Path(__file__).parent / "Knowledge-Graph-Nordic44.xml"
