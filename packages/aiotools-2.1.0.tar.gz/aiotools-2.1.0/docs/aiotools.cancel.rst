Safe Cancellation
=================

.. automodule:: aiotools.cancel
   :members:
