Supervisor
==========

This is a superseding replacement of :class:`PersistentTaskGroup` and recommend to use in new codes.

.. automodule:: aiotools.supervisor
   :members:
