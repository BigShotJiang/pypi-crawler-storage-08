def main():
    print("🔧 Project paths CLI tool – coming soon!")
