# Published at https://pypi.org/project/acryl-datahub-gx-plugin/.
__package_name__ = "acryl-datahub-gx-plugin"
__version__ = "1.2.0.10"
