from ._strip_system import StripSystemDataset

__all__ = ["StripSystemDataset"]
