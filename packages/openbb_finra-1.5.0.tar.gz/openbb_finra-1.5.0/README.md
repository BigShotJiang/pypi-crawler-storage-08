# OpenBB FINRA Provider

This extension integrates the [FINRA](https://finra.org/) data provider into the OpenBB Platform.

## Installation

To install the extension:

```bash
pip install openbb-finra
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
