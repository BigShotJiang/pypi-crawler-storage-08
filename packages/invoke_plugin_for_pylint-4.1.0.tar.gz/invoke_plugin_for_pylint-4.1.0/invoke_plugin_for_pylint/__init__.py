"""Invoke plugin for pylint."""

from __future__ import annotations

from invoke_plugin_for_pylint._plugin import register

__all__ = ("register",)
