"""Claude extension package"""
