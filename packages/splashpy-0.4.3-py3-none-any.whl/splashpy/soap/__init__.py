#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""PySimpleSOAP"""


__author__ = "Mariano Reingart & BadPixxel"
__author_email__ = "reingart@gmail.com"
__copyright__ = "Copyright (C) 2020 Mariano Reingart & BadPixxel"
__license__ = "LGPL 3.0"
__version__ = "1.16.2"

TIMEOUT = 60


from . import client, server, simplexml, transport
