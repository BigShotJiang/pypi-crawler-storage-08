# sage_setup: distribution = sagemath-groups
r"""
Miscellaneous Groups

This is a collection of groups that may not fit into some of the other infinite families described elsewhere.
"""

# Implementation note:
#     When adding a group here make an entry
#     in the  misc_groups_catalog.py module
#     or a more closely-related catalog module
