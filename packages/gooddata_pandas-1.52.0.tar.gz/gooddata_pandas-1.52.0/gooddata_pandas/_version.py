# (C) 2021 GoodData Corporation
from importlib import metadata

__version__: str = metadata.version("gooddata-pandas")
