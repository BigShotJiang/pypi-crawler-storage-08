python\_package package
=======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   python_package.hello_world

Submodules
----------

python\_package.setup module
----------------------------

.. automodule:: python_package.setup
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: python_package
   :members:
   :undoc-members:
   :show-inheritance:
