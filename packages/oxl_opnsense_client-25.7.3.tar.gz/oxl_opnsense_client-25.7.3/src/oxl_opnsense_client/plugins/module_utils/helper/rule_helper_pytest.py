def test_placeholder():
    from plugins.module_utils.helper.rule import \
        validate_values
