# pylint: disable=C0301
# docs as described here: https://docs.ansible.com/ansible/latest/dev_guide/developing_modules_documenting.html#module-format-and-documentation

DOCUMENTATION = r''''

'''

EXAMPLES = r'''

'''

RETURN = r'''

'''
