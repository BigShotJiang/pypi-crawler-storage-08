
def test_placeholder():
    from basic.exceptions import ModuleFailure, ModuleSuccess, ClientFailure
