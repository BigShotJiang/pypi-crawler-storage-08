# sage_setup: distribution = sagemath-macaulay2
# delvewheel: patch

from sage.all__sagemath_modules import *
