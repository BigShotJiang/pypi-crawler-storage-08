# Copyright 2025 George Kontridze

"""red main package."""
