API
===

.. autosummary::
   :toctree: generated
   :recursive:
   :members:
   :undoc-members:
   :show-inheritance:

   cen_detect_hor
