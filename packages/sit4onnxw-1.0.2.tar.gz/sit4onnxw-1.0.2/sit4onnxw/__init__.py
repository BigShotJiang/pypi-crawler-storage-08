#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__version__ = '1.0.2'

from .web_inference import inference

__all__ = ['inference']