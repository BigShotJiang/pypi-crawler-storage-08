from divent.bot import run

run()
