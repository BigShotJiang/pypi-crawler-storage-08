from .altwer import wer
