from django.apps import AppConfig


class ClassifierGrpcConfig(AppConfig):
    name = "weni.grpc.classifier"
