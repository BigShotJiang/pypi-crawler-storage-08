from django.apps import AppConfig


class FlowGrpcConfig(AppConfig):
    name = "weni.grpc.flow"
