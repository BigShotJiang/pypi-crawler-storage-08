from django.apps import AppConfig


class BillingAppConfig(AppConfig):
    name = "weni.grpc.billing"
