default_app_config = "weni.grpc.user.apps.UserGrpcConfig"
