from weni.internal.msgs.tasks import generate_sent_report_messages
