default_app_config = "weni.s3.apps.S3Config"
