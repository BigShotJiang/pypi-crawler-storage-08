COMMON_PROPERTY_MISSPELLINGS = {
    "desciption": "description",
    "descrption": "description",
    "descritption": "description",
    "desscription": "description",
}

COMMON_CONFIG_MISSPELLINGS = {
    "post-hook": "post_hook",
    "pre-hook": "pre_hook"
}