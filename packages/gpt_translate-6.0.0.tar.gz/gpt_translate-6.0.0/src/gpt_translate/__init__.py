from gpt_translate.version import __version__
