# emodeconnection

This package provides an interface to the EMode software from EMode Photonix.

## Installation

`$ pip install emodeconnection`

## Using emodeconnection

See the [guide](https://docs.emodephotonix.com/emodeconnection_python.html) provided by EMode Photonix.

## License

This package is published under the 3-Clause BSD License.
