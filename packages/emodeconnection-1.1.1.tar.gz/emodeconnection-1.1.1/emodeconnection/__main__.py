from . import EModeLogin

if __name__ == "__main__":
    EModeLogin()
