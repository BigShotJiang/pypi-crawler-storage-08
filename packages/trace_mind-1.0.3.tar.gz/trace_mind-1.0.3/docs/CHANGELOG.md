# Changelog

## [Unreleased]
- Add: T-LLM-01 (LLM client + ai.llm_call)
- Add: T-POLICY-02 (MCP policy adapter + fallback)
- Add: T-DOC-03 (documentation & recipes)
- Add: REL-4 (worker retries, DLQ tooling, `tm dlq` CLI)
