# Plugin Verification

Use `tm plugin verify` to check basic exporter compatibility before deployment.

```
$ tm plugin verify trace_mind.exporters example
OK: trace_mind.exporters:example
```
