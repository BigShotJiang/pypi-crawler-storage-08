# Config Reference

## Environment variables (current)
- `FAKE_DELAY_MS`: adds latency (ms) to `FakeProvider` for testing timeouts.

## Planned
- `OPENAI_API_KEY`, `OPENAI_BASE_URL`
- Pricing table path for cost accounting
- Concurrency / rate-limit knobs
