"""App package initialization."""

