# Policy adapters and clients (zero-conflict additions)
