# Changelog

## 1.0.0 (2024-05-09)
- Scaffold v2: `tm init` minimal template runnable out-of-box
- Plugin SDK + entry-point loader; example exporter
- `tm plugin verify` minimal conformance
- Quickstart docs link
