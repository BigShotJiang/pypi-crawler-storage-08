RESOURCE_TYPE = {
    "resource": "📦",
    "datasource": "🌐",
    "guide": "📚",
    "function": "📈",
}
CACHE = "🕓 "
BOOKMARK = "📌 "
