from canvas_sdk.effects.compound_medications.compound_medication import CompoundMedication

__all__ = __exports__ = ("CompoundMedication",)
