"""django-cfdi is a tool for friendly work with CFDI's ."""

__version__ = "2.234"

#from .classes import *
from .classes import CFDI, XmlNewObject, Object
