from setuptools import setup, find_packages

setup(
    name='virus_py',
    version='0.0.2',
    packages=find_packages(),
    author='VIRUS',
    description='Bypass cookies and user agent protection',
    long_description_content_type='text/plain',
    python_requires='>=3.6',
)
