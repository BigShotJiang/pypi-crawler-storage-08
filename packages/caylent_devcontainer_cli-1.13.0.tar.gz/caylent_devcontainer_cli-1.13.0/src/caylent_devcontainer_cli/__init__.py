"""Caylent Devcontainer CLI package."""

__version__ = "1.13.0"
