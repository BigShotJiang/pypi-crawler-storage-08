from .dictsqlite import *

__doc__ = dictsqlite.__doc__
if hasattr(dictsqlite, "__all__"):
    __all__ = dictsqlite.__all__