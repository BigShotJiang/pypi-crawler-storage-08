from collections.abc import Callable

from . import counterpy

main: Callable = counterpy.main
