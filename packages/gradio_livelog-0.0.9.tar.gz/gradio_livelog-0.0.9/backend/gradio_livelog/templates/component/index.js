var sr = Object.defineProperty;
var Ao = (o) => {
  throw TypeError(o);
};
var ur = (o, e, t) => e in o ? sr(o, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : o[e] = t;
var Y = (o, e, t) => ur(o, typeof e != "symbol" ? e + "" : e, t), cr = (o, e, t) => e.has(o) || Ao("Cannot " + t);
var Co = (o, e, t) => e.has(o) ? Ao("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(o) : e.set(o, t);
var pn = (o, e, t) => (cr(o, e, "access private method"), t);
const {
  SvelteComponent: _r,
  append_hydration: Ni,
  assign: dr,
  attr: pe,
  binding_callbacks: fr,
  children: en,
  claim_element: ia,
  claim_space: oa,
  claim_svg_element: ri,
  create_slot: hr,
  detach: Ye,
  element: la,
  empty: So,
  get_all_dirty_from_scope: pr,
  get_slot_changes: mr,
  get_spread_update: gr,
  init: vr,
  insert_hydration: ln,
  listen: Dr,
  noop: br,
  safe_not_equal: wr,
  set_dynamic_element_data: To,
  set_style: G,
  space: aa,
  svg_element: si,
  toggle_class: se,
  transition_in: ra,
  transition_out: sa,
  update_slot_base: yr
} = window.__gradio__svelte__internal;
function xo(o) {
  let e, t, n, i, a;
  return {
    c() {
      e = si("svg"), t = si("line"), n = si("line"), this.h();
    },
    l(l) {
      e = ri(l, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var r = en(e);
      t = ri(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), en(t).forEach(Ye), n = ri(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), en(n).forEach(Ye), r.forEach(Ye), this.h();
    },
    h() {
      pe(t, "x1", "1"), pe(t, "y1", "9"), pe(t, "x2", "9"), pe(t, "y2", "1"), pe(t, "stroke", "gray"), pe(t, "stroke-width", "0.5"), pe(n, "x1", "5"), pe(n, "y1", "9"), pe(n, "x2", "9"), pe(n, "y2", "5"), pe(n, "stroke", "gray"), pe(n, "stroke-width", "0.5"), pe(e, "class", "resize-handle svelte-239wnu"), pe(e, "xmlns", "http://www.w3.org/2000/svg"), pe(e, "viewBox", "0 0 10 10");
    },
    m(l, r) {
      ln(l, e, r), Ni(e, t), Ni(e, n), i || (a = Dr(
        e,
        "mousedown",
        /*resize*/
        o[27]
      ), i = !0);
    },
    p: br,
    d(l) {
      l && Ye(e), i = !1, a();
    }
  };
}
function Fr(o) {
  var p;
  let e, t, n, i, a;
  const l = (
    /*#slots*/
    o[31].default
  ), r = hr(
    l,
    o,
    /*$$scope*/
    o[30],
    null
  );
  let s = (
    /*resizable*/
    o[19] && xo(o)
  ), u = [
    { "data-testid": (
      /*test_id*/
      o[11]
    ) },
    { id: (
      /*elem_id*/
      o[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((p = o[7]) == null ? void 0 : p.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: i = /*rtl*/
      o[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let d = 0; d < u.length; d += 1)
    c = dr(c, u[d]);
  return {
    c() {
      e = la(
        /*tag*/
        o[25]
      ), r && r.c(), t = aa(), s && s.c(), this.h();
    },
    l(d) {
      e = ia(
        d,
        /*tag*/
        (o[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var m = en(e);
      r && r.l(m), t = oa(m), s && s.l(m), m.forEach(Ye), this.h();
    },
    h() {
      To(
        /*tag*/
        o[25]
      )(e, c), se(
        e,
        "hidden",
        /*visible*/
        o[14] === !1
      ), se(
        e,
        "padded",
        /*padding*/
        o[10]
      ), se(
        e,
        "flex",
        /*flex*/
        o[1]
      ), se(
        e,
        "border_focus",
        /*border_mode*/
        o[9] === "focus"
      ), se(
        e,
        "border_contrast",
        /*border_mode*/
        o[9] === "contrast"
      ), se(e, "hide-container", !/*explicit_call*/
      o[12] && !/*container*/
      o[13]), se(
        e,
        "fullscreen",
        /*fullscreen*/
        o[0]
      ), se(
        e,
        "animating",
        /*fullscreen*/
        o[0] && /*preexpansionBoundingRect*/
        o[24] !== null
      ), se(
        e,
        "auto-margin",
        /*scale*/
        o[17] === null
      ), G(
        e,
        "height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*height*/
            o[2]
          )
        )
      ), G(
        e,
        "min-height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*min_height*/
            o[3]
          )
        )
      ), G(
        e,
        "max-height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*max_height*/
            o[4]
          )
        )
      ), G(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].top}px` : "0px"
      ), G(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].left}px` : "0px"
      ), G(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].width}px` : "0px"
      ), G(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].height}px` : "0px"
      ), G(
        e,
        "width",
        /*fullscreen*/
        o[0] ? void 0 : typeof /*width*/
        o[5] == "number" ? `calc(min(${/*width*/
        o[5]}px, 100%))` : (
          /*get_dimension*/
          o[26](
            /*width*/
            o[5]
          )
        )
      ), G(
        e,
        "border-style",
        /*variant*/
        o[8]
      ), G(
        e,
        "overflow",
        /*allow_overflow*/
        o[15] ? (
          /*overflow_behavior*/
          o[16]
        ) : "hidden"
      ), G(
        e,
        "flex-grow",
        /*scale*/
        o[17]
      ), G(e, "min-width", `calc(min(${/*min_width*/
      o[18]}px, 100%))`), G(e, "border-width", "var(--block-border-width)");
    },
    m(d, m) {
      ln(d, e, m), r && r.m(e, null), Ni(e, t), s && s.m(e, null), o[32](e), a = !0;
    },
    p(d, m) {
      var b;
      r && r.p && (!a || m[0] & /*$$scope*/
      1073741824) && yr(
        r,
        l,
        d,
        /*$$scope*/
        d[30],
        a ? mr(
          l,
          /*$$scope*/
          d[30],
          m,
          null
        ) : pr(
          /*$$scope*/
          d[30]
        ),
        null
      ), /*resizable*/
      d[19] ? s ? s.p(d, m) : (s = xo(d), s.c(), s.m(e, null)) : s && (s.d(1), s = null), To(
        /*tag*/
        d[25]
      )(e, c = gr(u, [
        (!a || m[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          d[11]
        ) },
        (!a || m[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          d[6]
        ) },
        (!a || m[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((b = d[7]) == null ? void 0 : b.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!a || m[0] & /*rtl*/
        1048576 && i !== (i = /*rtl*/
        d[20] ? "rtl" : "ltr")) && { dir: i }
      ])), se(
        e,
        "hidden",
        /*visible*/
        d[14] === !1
      ), se(
        e,
        "padded",
        /*padding*/
        d[10]
      ), se(
        e,
        "flex",
        /*flex*/
        d[1]
      ), se(
        e,
        "border_focus",
        /*border_mode*/
        d[9] === "focus"
      ), se(
        e,
        "border_contrast",
        /*border_mode*/
        d[9] === "contrast"
      ), se(e, "hide-container", !/*explicit_call*/
      d[12] && !/*container*/
      d[13]), se(
        e,
        "fullscreen",
        /*fullscreen*/
        d[0]
      ), se(
        e,
        "animating",
        /*fullscreen*/
        d[0] && /*preexpansionBoundingRect*/
        d[24] !== null
      ), se(
        e,
        "auto-margin",
        /*scale*/
        d[17] === null
      ), m[0] & /*fullscreen, height*/
      5 && G(
        e,
        "height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*height*/
            d[2]
          )
        )
      ), m[0] & /*fullscreen, min_height*/
      9 && G(
        e,
        "min-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*min_height*/
            d[3]
          )
        )
      ), m[0] & /*fullscreen, max_height*/
      17 && G(
        e,
        "max-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*max_height*/
            d[4]
          )
        )
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && G(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].top}px` : "0px"
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && G(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].left}px` : "0px"
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && G(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].width}px` : "0px"
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && G(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].height}px` : "0px"
      ), m[0] & /*fullscreen, width*/
      33 && G(
        e,
        "width",
        /*fullscreen*/
        d[0] ? void 0 : typeof /*width*/
        d[5] == "number" ? `calc(min(${/*width*/
        d[5]}px, 100%))` : (
          /*get_dimension*/
          d[26](
            /*width*/
            d[5]
          )
        )
      ), m[0] & /*variant*/
      256 && G(
        e,
        "border-style",
        /*variant*/
        d[8]
      ), m[0] & /*allow_overflow, overflow_behavior*/
      98304 && G(
        e,
        "overflow",
        /*allow_overflow*/
        d[15] ? (
          /*overflow_behavior*/
          d[16]
        ) : "hidden"
      ), m[0] & /*scale*/
      131072 && G(
        e,
        "flex-grow",
        /*scale*/
        d[17]
      ), m[0] & /*min_width*/
      262144 && G(e, "min-width", `calc(min(${/*min_width*/
      d[18]}px, 100%))`);
    },
    i(d) {
      a || (ra(r, d), a = !0);
    },
    o(d) {
      sa(r, d), a = !1;
    },
    d(d) {
      d && Ye(e), r && r.d(d), s && s.d(), o[32](null);
    }
  };
}
function Bo(o) {
  let e;
  return {
    c() {
      e = la("div"), this.h();
    },
    l(t) {
      e = ia(t, "DIV", { class: !0 }), en(e).forEach(Ye), this.h();
    },
    h() {
      pe(e, "class", "placeholder svelte-239wnu"), G(
        e,
        "height",
        /*placeholder_height*/
        o[22] + "px"
      ), G(
        e,
        "width",
        /*placeholder_width*/
        o[23] + "px"
      );
    },
    m(t, n) {
      ln(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && G(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && G(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && Ye(e);
    }
  };
}
function kr(o) {
  let e, t, n, i = (
    /*tag*/
    o[25] && Fr(o)
  ), a = (
    /*fullscreen*/
    o[0] && Bo(o)
  );
  return {
    c() {
      i && i.c(), e = aa(), a && a.c(), t = So();
    },
    l(l) {
      i && i.l(l), e = oa(l), a && a.l(l), t = So();
    },
    m(l, r) {
      i && i.m(l, r), ln(l, e, r), a && a.m(l, r), ln(l, t, r), n = !0;
    },
    p(l, r) {
      /*tag*/
      l[25] && i.p(l, r), /*fullscreen*/
      l[0] ? a ? a.p(l, r) : (a = Bo(l), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null);
    },
    i(l) {
      n || (ra(i, l), n = !0);
    },
    o(l) {
      sa(i, l), n = !1;
    },
    d(l) {
      l && (Ye(e), Ye(t)), i && i.d(l), a && a.d(l);
    }
  };
}
function Er(o, e, t) {
  let { $$slots: n = {}, $$scope: i } = e, { height: a = void 0 } = e, { min_height: l = void 0 } = e, { max_height: r = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: p = "solid" } = e, { border_mode: d = "base" } = e, { padding: m = !0 } = e, { type: b = "normal" } = e, { test_id: D = void 0 } = e, { explicit_call: g = !1 } = e, { container: F = !0 } = e, { visible: h = !0 } = e, { allow_overflow: _ = !0 } = e, { overflow_behavior: v = "auto" } = e, { scale: y = null } = e, { min_width: w = 0 } = e, { flex: A = !1 } = e, { resizable: T = !1 } = e, { rtl: S = !1 } = e, { fullscreen: E = !1 } = e, I = E, O, ie = b === "fieldset" ? "fieldset" : "div", X = 0, M = 0, q = null;
  function z(k) {
    E && k.key === "Escape" && t(0, E = !1);
  }
  const H = (k) => {
    if (k !== void 0) {
      if (typeof k == "number")
        return k + "px";
      if (typeof k == "string")
        return k;
    }
  }, K = (k) => {
    let Q = k.clientY;
    const V = (C) => {
      const Ae = C.clientY - Q;
      Q = C.clientY, t(21, O.style.height = `${O.offsetHeight + Ae}px`, O);
    }, le = () => {
      window.removeEventListener("mousemove", V), window.removeEventListener("mouseup", le);
    };
    window.addEventListener("mousemove", V), window.addEventListener("mouseup", le);
  };
  function j(k) {
    fr[k ? "unshift" : "push"](() => {
      O = k, t(21, O);
    });
  }
  return o.$$set = (k) => {
    "height" in k && t(2, a = k.height), "min_height" in k && t(3, l = k.min_height), "max_height" in k && t(4, r = k.max_height), "width" in k && t(5, s = k.width), "elem_id" in k && t(6, u = k.elem_id), "elem_classes" in k && t(7, c = k.elem_classes), "variant" in k && t(8, p = k.variant), "border_mode" in k && t(9, d = k.border_mode), "padding" in k && t(10, m = k.padding), "type" in k && t(28, b = k.type), "test_id" in k && t(11, D = k.test_id), "explicit_call" in k && t(12, g = k.explicit_call), "container" in k && t(13, F = k.container), "visible" in k && t(14, h = k.visible), "allow_overflow" in k && t(15, _ = k.allow_overflow), "overflow_behavior" in k && t(16, v = k.overflow_behavior), "scale" in k && t(17, y = k.scale), "min_width" in k && t(18, w = k.min_width), "flex" in k && t(1, A = k.flex), "resizable" in k && t(19, T = k.resizable), "rtl" in k && t(20, S = k.rtl), "fullscreen" in k && t(0, E = k.fullscreen), "$$scope" in k && t(30, i = k.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && E !== I && (t(29, I = E), E ? (t(24, q = O.getBoundingClientRect()), t(22, X = O.offsetHeight), t(23, M = O.offsetWidth), window.addEventListener("keydown", z)) : (t(24, q = null), window.removeEventListener("keydown", z))), o.$$.dirty[0] & /*visible*/
    16384 && (h || t(1, A = !1));
  }, [
    E,
    A,
    a,
    l,
    r,
    s,
    u,
    c,
    p,
    d,
    m,
    D,
    g,
    F,
    h,
    _,
    v,
    y,
    w,
    T,
    S,
    O,
    X,
    M,
    q,
    ie,
    H,
    K,
    b,
    I,
    i,
    n,
    j
  ];
}
class $r extends _r {
  constructor(e) {
    super(), vr(
      this,
      e,
      Er,
      kr,
      wr,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function Ki() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let At = Ki();
function ua(o) {
  At = o;
}
const ca = /[&<>"']/, Ar = new RegExp(ca.source, "g"), _a = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Cr = new RegExp(_a.source, "g"), Sr = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Ro = (o) => Sr[o];
function $e(o, e) {
  if (e) {
    if (ca.test(o))
      return o.replace(Ar, Ro);
  } else if (_a.test(o))
    return o.replace(Cr, Ro);
  return o;
}
const Tr = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function xr(o) {
  return o.replace(Tr, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const Br = /(^|[^\[])\^/g;
function Z(o, e) {
  let t = typeof o == "string" ? o : o.source;
  e = e || "";
  const n = {
    replace: (i, a) => {
      let l = typeof a == "string" ? a : a.source;
      return l = l.replace(Br, "$1"), t = t.replace(i, l), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function Io(o) {
  try {
    o = encodeURI(o).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return o;
}
const tn = { exec: () => null };
function Lo(o, e) {
  const t = o.replace(/\|/g, (a, l, r) => {
    let s = !1, u = l;
    for (; --u >= 0 && r[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let i = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; i < n.length; i++)
    n[i] = n[i].trim().replace(/\\\|/g, "|");
  return n;
}
function mn(o, e, t) {
  const n = o.length;
  if (n === 0)
    return "";
  let i = 0;
  for (; i < n && o.charAt(n - i - 1) === e; )
    i++;
  return o.slice(0, n - i);
}
function Rr(o, e) {
  if (o.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < o.length; n++)
    if (o[n] === "\\")
      n++;
    else if (o[n] === e[0])
      t++;
    else if (o[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function qo(o, e, t, n) {
  const i = e.href, a = e.title ? $e(e.title) : null, l = o[1].replace(/\\([\[\]])/g, "$1");
  if (o[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const r = {
      type: "link",
      raw: t,
      href: i,
      title: a,
      text: l,
      tokens: n.inlineTokens(l)
    };
    return n.state.inLink = !1, r;
  }
  return {
    type: "image",
    raw: t,
    href: i,
    title: a,
    text: $e(l)
  };
}
function Ir(o, e) {
  const t = o.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((i) => {
    const a = i.match(/^\s+/);
    if (a === null)
      return i;
    const [l] = a;
    return l.length >= n.length ? i.slice(n.length) : i;
  }).join(`
`);
}
class Bn {
  // set by the lexer
  constructor(e) {
    Y(this, "options");
    Y(this, "rules");
    // set by the lexer
    Y(this, "lexer");
    this.options = e || At;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : mn(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], i = Ir(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: i
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const i = mn(n, "#");
        (this.options.pedantic || !i || / $/.test(i)) && (n = i.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = mn(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const i = this.lexer.state.top;
      this.lexer.state.top = !0;
      const a = this.lexer.blockTokens(n);
      return this.lexer.state.top = i, {
        type: "blockquote",
        raw: t[0],
        tokens: a,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const i = n.length > 1, a = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = i ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = i ? n : "[*+-]");
      const l = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let r = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        r = t[0], e = e.substring(r.length);
        let p = t[2].split(`
`, 1)[0].replace(/^\t+/, (F) => " ".repeat(3 * F.length)), d = e.split(`
`, 1)[0], m = 0;
        this.options.pedantic ? (m = 2, s = p.trimStart()) : (m = t[2].search(/[^ ]/), m = m > 4 ? 1 : m, s = p.slice(m), m += t[1].length);
        let b = !1;
        if (!p && /^ *$/.test(d) && (r += d + `
`, e = e.substring(d.length + 1), c = !0), !c) {
          const F = new RegExp(`^ {0,${Math.min(3, m - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), h = new RegExp(`^ {0,${Math.min(3, m - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), _ = new RegExp(`^ {0,${Math.min(3, m - 1)}}(?:\`\`\`|~~~)`), v = new RegExp(`^ {0,${Math.min(3, m - 1)}}#`);
          for (; e; ) {
            const y = e.split(`
`, 1)[0];
            if (d = y, this.options.pedantic && (d = d.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), _.test(d) || v.test(d) || F.test(d) || h.test(e))
              break;
            if (d.search(/[^ ]/) >= m || !d.trim())
              s += `
` + d.slice(m);
            else {
              if (b || p.search(/[^ ]/) >= 4 || _.test(p) || v.test(p) || h.test(p))
                break;
              s += `
` + d;
            }
            !b && !d.trim() && (b = !0), r += y + `
`, e = e.substring(y.length + 1), p = d.slice(m);
          }
        }
        a.loose || (u ? a.loose = !0 : /\n *\n *$/.test(r) && (u = !0));
        let D = null, g;
        this.options.gfm && (D = /^\[[ xX]\] /.exec(s), D && (g = D[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), a.items.push({
          type: "list_item",
          raw: r,
          task: !!D,
          checked: g,
          loose: !1,
          text: s,
          tokens: []
        }), a.raw += r;
      }
      a.items[a.items.length - 1].raw = r.trimEnd(), a.items[a.items.length - 1].text = s.trimEnd(), a.raw = a.raw.trimEnd();
      for (let c = 0; c < a.items.length; c++)
        if (this.lexer.state.top = !1, a.items[c].tokens = this.lexer.blockTokens(a.items[c].text, []), !a.loose) {
          const p = a.items[c].tokens.filter((m) => m.type === "space"), d = p.length > 0 && p.some((m) => /\n.*\n/.test(m.raw));
          a.loose = d;
        }
      if (a.loose)
        for (let c = 0; c < a.items.length; c++)
          a.items[c].loose = !0;
      return a;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), i = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", a = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: i,
        title: a
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = Lo(t[1]), i = t[2].replace(/^\||\| *$/g, "").split("|"), a = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === i.length) {
      for (const r of i)
        /^ *-+: *$/.test(r) ? l.align.push("right") : /^ *:-+: *$/.test(r) ? l.align.push("center") : /^ *:-+ *$/.test(r) ? l.align.push("left") : l.align.push(null);
      for (const r of n)
        l.header.push({
          text: r,
          tokens: this.lexer.inline(r)
        });
      for (const r of a)
        l.rows.push(Lo(r, l.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: $e(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const l = mn(n.slice(0, -1), "\\");
        if ((n.length - l.length) % 2 === 0)
          return;
      } else {
        const l = Rr(t[2], "()");
        if (l > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let i = t[2], a = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(i);
        l && (i = l[1], a = l[3]);
      } else
        a = t[3] ? t[3].slice(1, -1) : "";
      return i = i.trim(), /^</.test(i) && (this.options.pedantic && !/>$/.test(n) ? i = i.slice(1) : i = i.slice(1, -1)), qo(t, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: a && a.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const i = (n[2] || n[1]).replace(/\s+/g, " "), a = t[i.toLowerCase()];
      if (!a) {
        const l = n[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return qo(n, a, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let i = this.rules.inline.emStrongLDelim.exec(e);
    if (!i || i[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(i[1] || i[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const l = [...i[0]].length - 1;
      let r, s, u = l, c = 0;
      const p = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (p.lastIndex = 0, t = t.slice(-1 * e.length + l); (i = p.exec(t)) != null; ) {
        if (r = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !r)
          continue;
        if (s = [...r].length, i[3] || i[4]) {
          u += s;
          continue;
        } else if ((i[5] || i[6]) && l % 3 && !((l + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const d = [...i[0]][0].length, m = e.slice(0, l + i.index + d + s);
        if (Math.min(l, s) % 2) {
          const D = m.slice(1, -1);
          return {
            type: "em",
            raw: m,
            text: D,
            tokens: this.lexer.inlineTokens(D)
          };
        }
        const b = m.slice(2, -2);
        return {
          type: "strong",
          raw: m,
          text: b,
          tokens: this.lexer.inlineTokens(b)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const i = /[^ ]/.test(n), a = /^ /.test(n) && / $/.test(n);
      return i && a && (n = n.substring(1, n.length - 1)), n = $e(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, i;
      return t[2] === "@" ? (n = $e(t[1]), i = "mailto:" + n) : (n = $e(t[1]), i = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: i,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let i, a;
      if (t[2] === "@")
        i = $e(t[0]), a = "mailto:" + i;
      else {
        let l;
        do
          l = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (l !== t[0]);
        i = $e(t[0]), t[1] === "www." ? a = "http://" + t[0] : a = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: i,
        href: a,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = $e(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Lr = /^(?: *(?:\n|$))+/, qr = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Or = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, an = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Nr = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, da = /(?:[*+-]|\d{1,9}[.)])/, fa = Z(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, da).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Qi = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Mr = /^[^\n]+/, Ji = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Pr = Z(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", Ji).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), zr = Z(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, da).getRegex(), Gn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", eo = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Ur = Z("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", eo).replace("tag", Gn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), ha = Z(Qi).replace("hr", an).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Gn).getRegex(), Hr = Z(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", ha).getRegex(), to = {
  blockquote: Hr,
  code: qr,
  def: Pr,
  fences: Or,
  heading: Nr,
  hr: an,
  html: Ur,
  lheading: fa,
  list: zr,
  newline: Lr,
  paragraph: ha,
  table: tn,
  text: Mr
}, Oo = Z("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", an).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Gn).getRegex(), jr = {
  ...to,
  table: Oo,
  paragraph: Z(Qi).replace("hr", an).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Oo).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Gn).getRegex()
}, Gr = {
  ...to,
  html: Z(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", eo).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: tn,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: Z(Qi).replace("hr", an).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", fa).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, pa = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Vr = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, ma = /^( {2,}|\\)\n(?!\s*$)/, Wr = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, rn = "\\p{P}\\p{S}", Zr = Z(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, rn).getRegex(), Yr = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Xr = Z(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, rn).getRegex(), Kr = Z("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, rn).getRegex(), Qr = Z("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, rn).getRegex(), Jr = Z(/\\([punct])/, "gu").replace(/punct/g, rn).getRegex(), es = Z(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), ts = Z(eo).replace("(?:-->|$)", "-->").getRegex(), ns = Z("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", ts).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Rn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, is = Z(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Rn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), ga = Z(/^!?\[(label)\]\[(ref)\]/).replace("label", Rn).replace("ref", Ji).getRegex(), va = Z(/^!?\[(ref)\](?:\[\])?/).replace("ref", Ji).getRegex(), os = Z("reflink|nolink(?!\\()", "g").replace("reflink", ga).replace("nolink", va).getRegex(), no = {
  _backpedal: tn,
  // only used for GFM url
  anyPunctuation: Jr,
  autolink: es,
  blockSkip: Yr,
  br: ma,
  code: Vr,
  del: tn,
  emStrongLDelim: Xr,
  emStrongRDelimAst: Kr,
  emStrongRDelimUnd: Qr,
  escape: pa,
  link: is,
  nolink: va,
  punctuation: Zr,
  reflink: ga,
  reflinkSearch: os,
  tag: ns,
  text: Wr,
  url: tn
}, ls = {
  ...no,
  link: Z(/^!?\[(label)\]\((.*?)\)/).replace("label", Rn).getRegex(),
  reflink: Z(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Rn).getRegex()
}, Mi = {
  ...no,
  escape: Z(pa).replace("])", "~|])").getRegex(),
  url: Z(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, as = {
  ...Mi,
  br: Z(ma).replace("{2,}", "*").getRegex(),
  text: Z(Mi.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, gn = {
  normal: to,
  gfm: jr,
  pedantic: Gr
}, Wt = {
  normal: no,
  gfm: Mi,
  breaks: as,
  pedantic: ls
};
class Xe {
  constructor(e) {
    Y(this, "tokens");
    Y(this, "options");
    Y(this, "state");
    Y(this, "tokenizer");
    Y(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || At, this.options.tokenizer = this.options.tokenizer || new Bn(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: gn.normal,
      inline: Wt.normal
    };
    this.options.pedantic ? (t.block = gn.pedantic, t.inline = Wt.pedantic) : this.options.gfm && (t.block = gn.gfm, this.options.breaks ? t.inline = Wt.breaks : t.inline = Wt.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: gn,
      inline: Wt
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new Xe(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new Xe(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (r, s, u) => s + "    ".repeat(u.length));
    let n, i, a, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((r) => (n = r.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startBlock) {
          let r = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (r = Math.min(r, u));
          }), r < 1 / 0 && r >= 0 && (a = e.substring(0, r + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(a))) {
          i = t[t.length - 1], l && i.type === "paragraph" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n), l = a.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && i.type === "text" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (e) {
          const r = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(r);
            break;
          } else
            throw new Error(r);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, i, a, l = e, r, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (r = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          c.includes(r[0].slice(r[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (r = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (r = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, r.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (n = c.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, l, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const p = e.slice(1);
          let d;
          this.options.extensions.startInline.forEach((m) => {
            d = m.call({ lexer: this }, p), typeof d == "number" && d >= 0 && (c = Math.min(c, d));
          }), c < 1 / 0 && c >= 0 && (a = e.substring(0, c + 1));
        }
        if (n = this.tokenizer.inlineText(a)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, i = t[t.length - 1], i && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class In {
  constructor(e) {
    Y(this, "options");
    this.options = e || At;
  }
  code(e, t, n) {
    var a;
    const i = (a = (t || "").match(/^\S*/)) == null ? void 0 : a[0];
    return e = e.replace(/\n$/, "") + `
`, i ? '<pre><code class="language-' + $e(i) + '">' + (n ? e : $e(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : $e(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const i = t ? "ol" : "ul", a = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + i + a + `>
` + e + "</" + i + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const i = Io(e);
    if (i === null)
      return n;
    e = i;
    let a = '<a href="' + e + '"';
    return t && (a += ' title="' + t + '"'), a += ">" + n + "</a>", a;
  }
  image(e, t, n) {
    const i = Io(e);
    if (i === null)
      return n;
    e = i;
    let a = `<img src="${e}" alt="${n}"`;
    return t && (a += ` title="${t}"`), a += ">", a;
  }
  text(e) {
    return e;
  }
}
class io {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class Ke {
  constructor(e) {
    Y(this, "options");
    Y(this, "renderer");
    Y(this, "textRenderer");
    this.options = e || At, this.options.renderer = this.options.renderer || new In(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new io();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new Ke(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new Ke(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const a = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const l = a, r = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (r !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          n += r || "";
          continue;
        }
      }
      switch (a.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = a;
          n += this.renderer.heading(this.parseInline(l.tokens), l.depth, xr(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = a;
          n += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = a;
          let r = "", s = "";
          for (let c = 0; c < l.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(l.header[c].tokens), { header: !0, align: l.align[c] });
          r += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < l.rows.length; c++) {
            const p = l.rows[c];
            s = "";
            for (let d = 0; d < p.length; d++)
              s += this.renderer.tablecell(this.parseInline(p[d].tokens), { header: !1, align: l.align[d] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(r, u);
          continue;
        }
        case "blockquote": {
          const l = a, r = this.parse(l.tokens);
          n += this.renderer.blockquote(r);
          continue;
        }
        case "list": {
          const l = a, r = l.ordered, s = l.start, u = l.loose;
          let c = "";
          for (let p = 0; p < l.items.length; p++) {
            const d = l.items[p], m = d.checked, b = d.task;
            let D = "";
            if (d.task) {
              const g = this.renderer.checkbox(!!m);
              u ? d.tokens.length > 0 && d.tokens[0].type === "paragraph" ? (d.tokens[0].text = g + " " + d.tokens[0].text, d.tokens[0].tokens && d.tokens[0].tokens.length > 0 && d.tokens[0].tokens[0].type === "text" && (d.tokens[0].tokens[0].text = g + " " + d.tokens[0].tokens[0].text)) : d.tokens.unshift({
                type: "text",
                text: g + " "
              }) : D += g + " ";
            }
            D += this.parse(d.tokens, u), c += this.renderer.listitem(D, b, !!m);
          }
          n += this.renderer.list(c, r, s);
          continue;
        }
        case "html": {
          const l = a;
          n += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = a;
          n += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = a, r = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; i + 1 < e.length && e[i + 1].type === "text"; )
            l = e[++i], r += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          n += t ? this.renderer.paragraph(r) : r;
          continue;
        }
        default: {
          const l = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const a = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const l = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(a.type)) {
          n += l || "";
          continue;
        }
      }
      switch (a.type) {
        case "escape": {
          const l = a;
          n += t.text(l.text);
          break;
        }
        case "html": {
          const l = a;
          n += t.html(l.text);
          break;
        }
        case "link": {
          const l = a;
          n += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = a;
          n += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = a;
          n += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = a;
          n += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = a;
          n += t.codespan(l.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const l = a;
          n += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = a;
          n += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
}
class nn {
  constructor(e) {
    Y(this, "options");
    this.options = e || At;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
Y(nn, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var $t, Pi, Da;
class rs {
  constructor(...e) {
    Co(this, $t);
    Y(this, "defaults", Ki());
    Y(this, "options", this.setOptions);
    Y(this, "parse", pn(this, $t, Pi).call(this, Xe.lex, Ke.parse));
    Y(this, "parseInline", pn(this, $t, Pi).call(this, Xe.lexInline, Ke.parseInline));
    Y(this, "Parser", Ke);
    Y(this, "Renderer", In);
    Y(this, "TextRenderer", io);
    Y(this, "Lexer", Xe);
    Y(this, "Tokenizer", Bn);
    Y(this, "Hooks", nn);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var i, a;
    let n = [];
    for (const l of e)
      switch (n = n.concat(t.call(this, l)), l.type) {
        case "table": {
          const r = l;
          for (const s of r.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of r.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const r = l;
          n = n.concat(this.walkTokens(r.items, t));
          break;
        }
        default: {
          const r = l;
          (a = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && a[r.type] ? this.defaults.extensions.childTokens[r.type].forEach((s) => {
            const u = r[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : r.tokens && (n = n.concat(this.walkTokens(r.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const i = { ...n };
      if (i.async = this.defaults.async || i.async || !1, n.extensions && (n.extensions.forEach((a) => {
        if (!a.name)
          throw new Error("extension name required");
        if ("renderer" in a) {
          const l = t.renderers[a.name];
          l ? t.renderers[a.name] = function(...r) {
            let s = a.renderer.apply(this, r);
            return s === !1 && (s = l.apply(this, r)), s;
          } : t.renderers[a.name] = a.renderer;
        }
        if ("tokenizer" in a) {
          if (!a.level || a.level !== "block" && a.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[a.level];
          l ? l.unshift(a.tokenizer) : t[a.level] = [a.tokenizer], a.start && (a.level === "block" ? t.startBlock ? t.startBlock.push(a.start) : t.startBlock = [a.start] : a.level === "inline" && (t.startInline ? t.startInline.push(a.start) : t.startInline = [a.start]));
        }
        "childTokens" in a && a.childTokens && (t.childTokens[a.name] = a.childTokens);
      }), i.extensions = t), n.renderer) {
        const a = this.defaults.renderer || new In(this.defaults);
        for (const l in n.renderer) {
          if (!(l in a))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const r = l, s = n.renderer[r], u = a[r];
          a[r] = (...c) => {
            let p = s.apply(a, c);
            return p === !1 && (p = u.apply(a, c)), p || "";
          };
        }
        i.renderer = a;
      }
      if (n.tokenizer) {
        const a = this.defaults.tokenizer || new Bn(this.defaults);
        for (const l in n.tokenizer) {
          if (!(l in a))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const r = l, s = n.tokenizer[r], u = a[r];
          a[r] = (...c) => {
            let p = s.apply(a, c);
            return p === !1 && (p = u.apply(a, c)), p;
          };
        }
        i.tokenizer = a;
      }
      if (n.hooks) {
        const a = this.defaults.hooks || new nn();
        for (const l in n.hooks) {
          if (!(l in a))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const r = l, s = n.hooks[r], u = a[r];
          nn.passThroughHooks.has(l) ? a[r] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(a, c)).then((d) => u.call(a, d));
            const p = s.call(a, c);
            return u.call(a, p);
          } : a[r] = (...c) => {
            let p = s.apply(a, c);
            return p === !1 && (p = u.apply(a, c)), p;
          };
        }
        i.hooks = a;
      }
      if (n.walkTokens) {
        const a = this.defaults.walkTokens, l = n.walkTokens;
        i.walkTokens = function(r) {
          let s = [];
          return s.push(l.call(this, r)), a && (s = s.concat(a.call(this, r))), s;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return Xe.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Ke.parse(e, t ?? this.defaults);
  }
}
$t = new WeakSet(), Pi = function(e, t) {
  return (n, i) => {
    const a = { ...i }, l = { ...this.defaults, ...a };
    this.defaults.async === !0 && a.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const r = pn(this, $t, Da).call(this, !!l.silent, !!l.async);
    if (typeof n > "u" || n === null)
      return r(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return r(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(n) : n).then((s) => e(s, l)).then((s) => l.hooks ? l.hooks.processAllTokens(s) : s).then((s) => l.walkTokens ? Promise.all(this.walkTokens(s, l.walkTokens)).then(() => s) : s).then((s) => t(s, l)).then((s) => l.hooks ? l.hooks.postprocess(s) : s).catch(r);
    try {
      l.hooks && (n = l.hooks.preprocess(n));
      let s = e(n, l);
      l.hooks && (s = l.hooks.processAllTokens(s)), l.walkTokens && this.walkTokens(s, l.walkTokens);
      let u = t(s, l);
      return l.hooks && (u = l.hooks.postprocess(u)), u;
    } catch (s) {
      return r(s);
    }
  };
}, Da = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const i = "<p>An error occurred:</p><pre>" + $e(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(i) : i;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const Ft = new rs();
function W(o, e) {
  return Ft.parse(o, e);
}
W.options = W.setOptions = function(o) {
  return Ft.setOptions(o), W.defaults = Ft.defaults, ua(W.defaults), W;
};
W.getDefaults = Ki;
W.defaults = At;
W.use = function(...o) {
  return Ft.use(...o), W.defaults = Ft.defaults, ua(W.defaults), W;
};
W.walkTokens = function(o, e) {
  return Ft.walkTokens(o, e);
};
W.parseInline = Ft.parseInline;
W.Parser = Ke;
W.parser = Ke.parse;
W.Renderer = In;
W.TextRenderer = io;
W.Lexer = Xe;
W.lexer = Xe.lex;
W.Tokenizer = Bn;
W.Hooks = nn;
W.parse = W;
W.options;
W.setOptions;
W.use;
W.walkTokens;
W.parseInline;
Ke.parse;
Xe.lex;
const ss = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, us = Object.hasOwnProperty;
class ba {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let i = cs(e, t === !0);
    const a = i;
    for (; us.call(n.occurrences, i); )
      n.occurrences[a]++, i = a + "-" + n.occurrences[a];
    return n.occurrences[i] = 0, i;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function cs(o, e) {
  return typeof o != "string" ? "" : (e || (o = o.toLowerCase()), o.replace(ss, "").replace(/ /g, "-"));
}
new ba();
var No = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, _s = { exports: {} };
(function(o) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var i = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, a = 0, l = {}, r = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function h(_) {
          return _ instanceof s ? new s(_.type, h(_.content), _.alias) : Array.isArray(_) ? _.map(h) : _.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(h) {
          return Object.prototype.toString.call(h).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(h) {
          return h.__id || Object.defineProperty(h, "__id", { value: ++a }), h.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function h(_, v) {
          v = v || {};
          var y, w;
          switch (r.util.type(_)) {
            case "Object":
              if (w = r.util.objId(_), v[w])
                return v[w];
              y = /** @type {Record<string, any>} */
              {}, v[w] = y;
              for (var A in _)
                _.hasOwnProperty(A) && (y[A] = h(_[A], v));
              return (
                /** @type {any} */
                y
              );
            case "Array":
              return w = r.util.objId(_), v[w] ? v[w] : (y = [], v[w] = y, /** @type {Array} */
              /** @type {any} */
              _.forEach(function(T, S) {
                y[S] = h(T, v);
              }), /** @type {any} */
              y);
            default:
              return _;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(h) {
          for (; h; ) {
            var _ = i.exec(h.className);
            if (_)
              return _[1].toLowerCase();
            h = h.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(h, _) {
          h.className = h.className.replace(RegExp(i, "gi"), ""), h.classList.add("language-" + _);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (y) {
            var h = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(y.stack) || [])[1];
            if (h) {
              var _ = document.getElementsByTagName("script");
              for (var v in _)
                if (_[v].src == h)
                  return _[v];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(h, _, v) {
          for (var y = "no-" + _; h; ) {
            var w = h.classList;
            if (w.contains(_))
              return !0;
            if (w.contains(y))
              return !1;
            h = h.parentElement;
          }
          return !!v;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(h, _) {
          var v = r.util.clone(r.languages[h]);
          for (var y in _)
            v[y] = _[y];
          return v;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(h, _, v, y) {
          y = y || /** @type {any} */
          r.languages;
          var w = y[h], A = {};
          for (var T in w)
            if (w.hasOwnProperty(T)) {
              if (T == _)
                for (var S in v)
                  v.hasOwnProperty(S) && (A[S] = v[S]);
              v.hasOwnProperty(T) || (A[T] = w[T]);
            }
          var E = y[h];
          return y[h] = A, r.languages.DFS(r.languages, function(I, O) {
            O === E && I != h && (this[I] = A);
          }), A;
        },
        // Traverse a language definition with Depth First Search
        DFS: function h(_, v, y, w) {
          w = w || {};
          var A = r.util.objId;
          for (var T in _)
            if (_.hasOwnProperty(T)) {
              v.call(_, T, _[T], y || T);
              var S = _[T], E = r.util.type(S);
              E === "Object" && !w[A(S)] ? (w[A(S)] = !0, h(S, v, null, w)) : E === "Array" && !w[A(S)] && (w[A(S)] = !0, h(S, v, T, w));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(h, _) {
        r.highlightAllUnder(document, h, _);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(h, _, v) {
        var y = {
          callback: v,
          container: h,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        r.hooks.run("before-highlightall", y), y.elements = Array.prototype.slice.apply(y.container.querySelectorAll(y.selector)), r.hooks.run("before-all-elements-highlight", y);
        for (var w = 0, A; A = y.elements[w++]; )
          r.highlightElement(A, _ === !0, y.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(h, _, v) {
        var y = r.util.getLanguage(h), w = r.languages[y];
        r.util.setLanguage(h, y);
        var A = h.parentElement;
        A && A.nodeName.toLowerCase() === "pre" && r.util.setLanguage(A, y);
        var T = h.textContent, S = {
          element: h,
          language: y,
          grammar: w,
          code: T
        };
        function E(O) {
          S.highlightedCode = O, r.hooks.run("before-insert", S), S.element.innerHTML = S.highlightedCode, r.hooks.run("after-highlight", S), r.hooks.run("complete", S), v && v.call(S.element);
        }
        if (r.hooks.run("before-sanity-check", S), A = S.element.parentElement, A && A.nodeName.toLowerCase() === "pre" && !A.hasAttribute("tabindex") && A.setAttribute("tabindex", "0"), !S.code) {
          r.hooks.run("complete", S), v && v.call(S.element);
          return;
        }
        if (r.hooks.run("before-highlight", S), !S.grammar) {
          E(r.util.encode(S.code));
          return;
        }
        if (_ && n.Worker) {
          var I = new Worker(r.filename);
          I.onmessage = function(O) {
            E(O.data);
          }, I.postMessage(JSON.stringify({
            language: S.language,
            code: S.code,
            immediateClose: !0
          }));
        } else
          E(r.highlight(S.code, S.grammar, S.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(h, _, v) {
        var y = {
          code: h,
          grammar: _,
          language: v
        };
        if (r.hooks.run("before-tokenize", y), !y.grammar)
          throw new Error('The language "' + y.language + '" has no grammar.');
        return y.tokens = r.tokenize(y.code, y.grammar), r.hooks.run("after-tokenize", y), s.stringify(r.util.encode(y.tokens), y.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(h, _) {
        var v = _.rest;
        if (v) {
          for (var y in v)
            _[y] = v[y];
          delete _.rest;
        }
        var w = new p();
        return d(w, w.head, h), c(h, w, _, w.head, 0), b(w);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(h, _) {
          var v = r.hooks.all;
          v[h] = v[h] || [], v[h].push(_);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(h, _) {
          var v = r.hooks.all[h];
          if (!(!v || !v.length))
            for (var y = 0, w; w = v[y++]; )
              w(_);
        }
      },
      Token: s
    };
    n.Prism = r;
    function s(h, _, v, y) {
      this.type = h, this.content = _, this.alias = v, this.length = (y || "").length | 0;
    }
    s.stringify = function h(_, v) {
      if (typeof _ == "string")
        return _;
      if (Array.isArray(_)) {
        var y = "";
        return _.forEach(function(E) {
          y += h(E, v);
        }), y;
      }
      var w = {
        type: _.type,
        content: h(_.content, v),
        tag: "span",
        classes: ["token", _.type],
        attributes: {},
        language: v
      }, A = _.alias;
      A && (Array.isArray(A) ? Array.prototype.push.apply(w.classes, A) : w.classes.push(A)), r.hooks.run("wrap", w);
      var T = "";
      for (var S in w.attributes)
        T += " " + S + '="' + (w.attributes[S] || "").replace(/"/g, "&quot;") + '"';
      return "<" + w.tag + ' class="' + w.classes.join(" ") + '"' + T + ">" + w.content + "</" + w.tag + ">";
    };
    function u(h, _, v, y) {
      h.lastIndex = _;
      var w = h.exec(v);
      if (w && y && w[1]) {
        var A = w[1].length;
        w.index += A, w[0] = w[0].slice(A);
      }
      return w;
    }
    function c(h, _, v, y, w, A) {
      for (var T in v)
        if (!(!v.hasOwnProperty(T) || !v[T])) {
          var S = v[T];
          S = Array.isArray(S) ? S : [S];
          for (var E = 0; E < S.length; ++E) {
            if (A && A.cause == T + "," + E)
              return;
            var I = S[E], O = I.inside, ie = !!I.lookbehind, X = !!I.greedy, M = I.alias;
            if (X && !I.pattern.global) {
              var q = I.pattern.toString().match(/[imsuy]*$/)[0];
              I.pattern = RegExp(I.pattern.source, q + "g");
            }
            for (var z = I.pattern || I, H = y.next, K = w; H !== _.tail && !(A && K >= A.reach); K += H.value.length, H = H.next) {
              var j = H.value;
              if (_.length > h.length)
                return;
              if (!(j instanceof s)) {
                var k = 1, Q;
                if (X) {
                  if (Q = u(z, K, h, ie), !Q || Q.index >= h.length)
                    break;
                  var Ae = Q.index, V = Q.index + Q[0].length, le = K;
                  for (le += H.value.length; Ae >= le; )
                    H = H.next, le += H.value.length;
                  if (le -= H.value.length, K = le, H.value instanceof s)
                    continue;
                  for (var C = H; C !== _.tail && (le < V || typeof C.value == "string"); C = C.next)
                    k++, le += C.value.length;
                  k--, j = h.slice(K, le), Q.index -= K;
                } else if (Q = u(z, 0, j, ie), !Q)
                  continue;
                var Ae = Q.index, st = Q[0], Ct = j.slice(0, Ae), St = j.slice(Ae + st.length), Tt = K + j.length;
                A && Tt > A.reach && (A.reach = Tt);
                var Dt = H.prev;
                Ct && (Dt = d(_, Dt, Ct), K += Ct.length), m(_, Dt, k);
                var ut = new s(T, O ? r.tokenize(st, O) : st, M, st);
                if (H = d(_, Dt, ut), St && d(_, H, St), k > 1) {
                  var ct = {
                    cause: T + "," + E,
                    reach: Tt
                  };
                  c(h, _, v, H.prev, K, ct), A && ct.reach > A.reach && (A.reach = ct.reach);
                }
              }
            }
          }
        }
    }
    function p() {
      var h = { value: null, prev: null, next: null }, _ = { value: null, prev: h, next: null };
      h.next = _, this.head = h, this.tail = _, this.length = 0;
    }
    function d(h, _, v) {
      var y = _.next, w = { value: v, prev: _, next: y };
      return _.next = w, y.prev = w, h.length++, w;
    }
    function m(h, _, v) {
      for (var y = _.next, w = 0; w < v && y !== h.tail; w++)
        y = y.next;
      _.next = y, y.prev = _, h.length -= w;
    }
    function b(h) {
      for (var _ = [], v = h.head.next; v !== h.tail; )
        _.push(v.value), v = v.next;
      return _;
    }
    if (!n.document)
      return n.addEventListener && (r.disableWorkerMessageHandler || n.addEventListener("message", function(h) {
        var _ = JSON.parse(h.data), v = _.language, y = _.code, w = _.immediateClose;
        n.postMessage(r.highlight(y, r.languages[v], v)), w && n.close();
      }, !1)), r;
    var D = r.util.currentScript();
    D && (r.filename = D.src, D.hasAttribute("data-manual") && (r.manual = !0));
    function g() {
      r.manual || r.highlightAll();
    }
    if (!r.manual) {
      var F = document.readyState;
      F === "loading" || F === "interactive" && D && D.defer ? document.addEventListener("DOMContentLoaded", g) : window.requestAnimationFrame ? window.requestAnimationFrame(g) : window.setTimeout(g, 16);
    }
    return r;
  }(e);
  o.exports && (o.exports = t), typeof No < "u" && (No.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(i, a) {
      var l = {};
      l["language-" + a] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[a]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var r = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      r["language-" + a] = {
        pattern: /[\s\S]+/,
        inside: t.languages[a]
      };
      var s = {};
      s[i] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return i;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: r
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, i) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [i, "language-" + i],
                inside: t.languages[i]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var i = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + i.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + i.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + i.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + i.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: i,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var a = n.languages.markup;
    a && (a.tag.addInlined("style", "css"), a.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", i = function(D, g) {
      return "✖ Error " + D + " while fetching file: " + g;
    }, a = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, r = "data-src-status", s = "loading", u = "loaded", c = "failed", p = "pre[data-src]:not([" + r + '="' + u + '"]):not([' + r + '="' + s + '"])';
    function d(D, g, F) {
      var h = new XMLHttpRequest();
      h.open("GET", D, !0), h.onreadystatechange = function() {
        h.readyState == 4 && (h.status < 400 && h.responseText ? g(h.responseText) : h.status >= 400 ? F(i(h.status, h.statusText)) : F(a));
      }, h.send(null);
    }
    function m(D) {
      var g = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(D || "");
      if (g) {
        var F = Number(g[1]), h = g[2], _ = g[3];
        return h ? _ ? [F, Number(_)] : [F, void 0] : [F, F];
      }
    }
    t.hooks.add("before-highlightall", function(D) {
      D.selector += ", " + p;
    }), t.hooks.add("before-sanity-check", function(D) {
      var g = (
        /** @type {HTMLPreElement} */
        D.element
      );
      if (g.matches(p)) {
        D.code = "", g.setAttribute(r, s);
        var F = g.appendChild(document.createElement("CODE"));
        F.textContent = n;
        var h = g.getAttribute("data-src"), _ = D.language;
        if (_ === "none") {
          var v = (/\.(\w+)$/.exec(h) || [, "none"])[1];
          _ = l[v] || v;
        }
        t.util.setLanguage(F, _), t.util.setLanguage(g, _);
        var y = t.plugins.autoloader;
        y && y.loadLanguages(_), d(
          h,
          function(w) {
            g.setAttribute(r, u);
            var A = m(g.getAttribute("data-range"));
            if (A) {
              var T = w.split(/\r\n?|\n/g), S = A[0], E = A[1] == null ? T.length : A[1];
              S < 0 && (S += T.length), S = Math.max(0, Math.min(S - 1, T.length)), E < 0 && (E += T.length), E = Math.max(0, Math.min(E, T.length)), w = T.slice(S, E).join(`
`), g.hasAttribute("data-start") || g.setAttribute("data-start", String(S + 1));
            }
            F.textContent = w, t.highlightElement(F);
          },
          function(w) {
            g.setAttribute(r, c), F.textContent = w;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(g) {
        for (var F = (g || document).querySelectorAll(p), h = 0, _; _ = F[h++]; )
          t.highlightElement(_);
      }
    };
    var b = !1;
    t.fileHighlight = function() {
      b || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), b = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(_s);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(o) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  o.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, o.languages.tex = o.languages.latex, o.languages.context = o.languages.latex;
})(Prism);
(function(o) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  o.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = o.languages.bash;
  for (var i = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], a = n.variable[1].inside, l = 0; l < i.length; l++)
    a[i[l]] = o.languages.bash[i[l]];
  o.languages.sh = o.languages.bash, o.languages.shell = o.languages.bash;
})(Prism);
new ba();
const ds = (o) => {
  const e = {};
  for (let t = 0, n = o.length; t < n; t++) {
    const i = o[t];
    for (const a in i)
      e[a] ? e[a] = e[a].concat(i[a]) : e[a] = i[a];
  }
  return e;
}, fs = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], hs = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], ps = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
ds([
  Object.fromEntries(fs.map((o) => [o, ["*"]])),
  Object.fromEntries(hs.map((o) => [o, ["svg:*"]])),
  Object.fromEntries(ps.map((o) => [o, ["math:*"]]))
]);
const {
  HtmlTagHydration: Ud,
  SvelteComponent: Hd,
  attr: jd,
  binding_callbacks: Gd,
  children: Vd,
  claim_element: Wd,
  claim_html_tag: Zd,
  detach: Yd,
  element: Xd,
  init: Kd,
  insert_hydration: Qd,
  noop: Jd,
  safe_not_equal: ef,
  toggle_class: tf
} = window.__gradio__svelte__internal, { afterUpdate: nf, tick: of, onMount: lf } = window.__gradio__svelte__internal, {
  SvelteComponent: af,
  attr: rf,
  children: sf,
  claim_component: uf,
  claim_element: cf,
  create_component: _f,
  destroy_component: df,
  detach: ff,
  element: hf,
  init: pf,
  insert_hydration: mf,
  mount_component: gf,
  safe_not_equal: vf,
  transition_in: Df,
  transition_out: bf
} = window.__gradio__svelte__internal, {
  SvelteComponent: wf,
  attr: yf,
  check_outros: Ff,
  children: kf,
  claim_component: Ef,
  claim_element: $f,
  claim_space: Af,
  create_component: Cf,
  create_slot: Sf,
  destroy_component: Tf,
  detach: xf,
  element: Bf,
  empty: Rf,
  get_all_dirty_from_scope: If,
  get_slot_changes: Lf,
  group_outros: qf,
  init: Of,
  insert_hydration: Nf,
  mount_component: Mf,
  safe_not_equal: Pf,
  space: zf,
  toggle_class: Uf,
  transition_in: Hf,
  transition_out: jf,
  update_slot_base: Gf
} = window.__gradio__svelte__internal, {
  SvelteComponent: ms,
  append_hydration: ui,
  attr: Ot,
  children: Mo,
  claim_component: gs,
  claim_element: Po,
  claim_space: vs,
  claim_text: Ds,
  create_component: bs,
  destroy_component: ws,
  detach: ci,
  element: zo,
  init: ys,
  insert_hydration: Fs,
  mount_component: ks,
  safe_not_equal: Es,
  set_data: $s,
  space: As,
  text: Cs,
  toggle_class: _t,
  transition_in: Ss,
  transition_out: Ts
} = window.__gradio__svelte__internal;
function xs(o) {
  let e, t, n, i, a, l, r;
  return n = new /*Icon*/
  o[1]({}), {
    c() {
      e = zo("label"), t = zo("span"), bs(n.$$.fragment), i = As(), a = Cs(
        /*label*/
        o[0]
      ), this.h();
    },
    l(s) {
      e = Po(s, "LABEL", {
        for: !0,
        "data-testid": !0,
        dir: !0,
        class: !0
      });
      var u = Mo(e);
      t = Po(u, "SPAN", { class: !0 });
      var c = Mo(t);
      gs(n.$$.fragment, c), c.forEach(ci), i = vs(u), a = Ds(
        u,
        /*label*/
        o[0]
      ), u.forEach(ci), this.h();
    },
    h() {
      Ot(t, "class", "svelte-13ao5pu"), Ot(e, "for", ""), Ot(e, "data-testid", "block-label"), Ot(e, "dir", l = /*rtl*/
      o[5] ? "rtl" : "ltr"), Ot(e, "class", "svelte-13ao5pu"), _t(e, "hide", !/*show_label*/
      o[2]), _t(e, "sr-only", !/*show_label*/
      o[2]), _t(
        e,
        "float",
        /*float*/
        o[4]
      ), _t(
        e,
        "hide-label",
        /*disable*/
        o[3]
      );
    },
    m(s, u) {
      Fs(s, e, u), ui(e, t), ks(n, t, null), ui(e, i), ui(e, a), r = !0;
    },
    p(s, [u]) {
      (!r || u & /*label*/
      1) && $s(
        a,
        /*label*/
        s[0]
      ), (!r || u & /*rtl*/
      32 && l !== (l = /*rtl*/
      s[5] ? "rtl" : "ltr")) && Ot(e, "dir", l), (!r || u & /*show_label*/
      4) && _t(e, "hide", !/*show_label*/
      s[2]), (!r || u & /*show_label*/
      4) && _t(e, "sr-only", !/*show_label*/
      s[2]), (!r || u & /*float*/
      16) && _t(
        e,
        "float",
        /*float*/
        s[4]
      ), (!r || u & /*disable*/
      8) && _t(
        e,
        "hide-label",
        /*disable*/
        s[3]
      );
    },
    i(s) {
      r || (Ss(n.$$.fragment, s), r = !0);
    },
    o(s) {
      Ts(n.$$.fragment, s), r = !1;
    },
    d(s) {
      s && ci(e), ws(n);
    }
  };
}
function Bs(o, e, t) {
  let { label: n = null } = e, { Icon: i } = e, { show_label: a = !0 } = e, { disable: l = !1 } = e, { float: r = !0 } = e, { rtl: s = !1 } = e;
  return o.$$set = (u) => {
    "label" in u && t(0, n = u.label), "Icon" in u && t(1, i = u.Icon), "show_label" in u && t(2, a = u.show_label), "disable" in u && t(3, l = u.disable), "float" in u && t(4, r = u.float), "rtl" in u && t(5, s = u.rtl);
  }, [n, i, a, l, r, s];
}
class Rs extends ms {
  constructor(e) {
    super(), ys(this, e, Bs, xs, Es, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4,
      rtl: 5
    });
  }
}
const {
  SvelteComponent: Is,
  append_hydration: Sn,
  attr: at,
  bubble: Ls,
  check_outros: qs,
  children: zi,
  claim_component: Os,
  claim_element: Ui,
  claim_space: Uo,
  claim_text: Ns,
  construct_svelte_component: Ho,
  create_component: jo,
  create_slot: Ms,
  destroy_component: Go,
  detach: on,
  element: Hi,
  get_all_dirty_from_scope: Ps,
  get_slot_changes: zs,
  group_outros: Us,
  init: Hs,
  insert_hydration: wa,
  listen: js,
  mount_component: Vo,
  safe_not_equal: Gs,
  set_data: Vs,
  set_style: vn,
  space: Wo,
  text: Ws,
  toggle_class: he,
  transition_in: _i,
  transition_out: di,
  update_slot_base: Zs
} = window.__gradio__svelte__internal;
function Zo(o) {
  let e, t;
  return {
    c() {
      e = Hi("span"), t = Ws(
        /*label*/
        o[1]
      ), this.h();
    },
    l(n) {
      e = Ui(n, "SPAN", { class: !0 });
      var i = zi(e);
      t = Ns(
        i,
        /*label*/
        o[1]
      ), i.forEach(on), this.h();
    },
    h() {
      at(e, "class", "svelte-qgco6m");
    },
    m(n, i) {
      wa(n, e, i), Sn(e, t);
    },
    p(n, i) {
      i & /*label*/
      2 && Vs(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && on(e);
    }
  };
}
function Ys(o) {
  let e, t, n, i, a, l, r, s, u = (
    /*show_label*/
    o[2] && Zo(o)
  );
  var c = (
    /*Icon*/
    o[0]
  );
  function p(b, D) {
    return {};
  }
  c && (i = Ho(c, p()));
  const d = (
    /*#slots*/
    o[14].default
  ), m = Ms(
    d,
    o,
    /*$$scope*/
    o[13],
    null
  );
  return {
    c() {
      e = Hi("button"), u && u.c(), t = Wo(), n = Hi("div"), i && jo(i.$$.fragment), a = Wo(), m && m.c(), this.h();
    },
    l(b) {
      e = Ui(b, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var D = zi(e);
      u && u.l(D), t = Uo(D), n = Ui(D, "DIV", { class: !0 });
      var g = zi(n);
      i && Os(i.$$.fragment, g), a = Uo(g), m && m.l(g), g.forEach(on), D.forEach(on), this.h();
    },
    h() {
      at(n, "class", "svelte-qgco6m"), he(
        n,
        "x-small",
        /*size*/
        o[4] === "x-small"
      ), he(
        n,
        "small",
        /*size*/
        o[4] === "small"
      ), he(
        n,
        "large",
        /*size*/
        o[4] === "large"
      ), he(
        n,
        "medium",
        /*size*/
        o[4] === "medium"
      ), e.disabled = /*disabled*/
      o[7], at(
        e,
        "aria-label",
        /*label*/
        o[1]
      ), at(
        e,
        "aria-haspopup",
        /*hasPopup*/
        o[8]
      ), at(
        e,
        "title",
        /*label*/
        o[1]
      ), at(e, "class", "svelte-qgco6m"), he(
        e,
        "pending",
        /*pending*/
        o[3]
      ), he(
        e,
        "padded",
        /*padded*/
        o[5]
      ), he(
        e,
        "highlight",
        /*highlight*/
        o[6]
      ), he(
        e,
        "transparent",
        /*transparent*/
        o[9]
      ), vn(e, "color", !/*disabled*/
      o[7] && /*_color*/
      o[11] ? (
        /*_color*/
        o[11]
      ) : "var(--block-label-text-color)"), vn(e, "--bg-color", /*disabled*/
      o[7] ? "auto" : (
        /*background*/
        o[10]
      ));
    },
    m(b, D) {
      wa(b, e, D), u && u.m(e, null), Sn(e, t), Sn(e, n), i && Vo(i, n, null), Sn(n, a), m && m.m(n, null), l = !0, r || (s = js(
        e,
        "click",
        /*click_handler*/
        o[15]
      ), r = !0);
    },
    p(b, [D]) {
      if (/*show_label*/
      b[2] ? u ? u.p(b, D) : (u = Zo(b), u.c(), u.m(e, t)) : u && (u.d(1), u = null), D & /*Icon*/
      1 && c !== (c = /*Icon*/
      b[0])) {
        if (i) {
          Us();
          const g = i;
          di(g.$$.fragment, 1, 0, () => {
            Go(g, 1);
          }), qs();
        }
        c ? (i = Ho(c, p()), jo(i.$$.fragment), _i(i.$$.fragment, 1), Vo(i, n, a)) : i = null;
      }
      m && m.p && (!l || D & /*$$scope*/
      8192) && Zs(
        m,
        d,
        b,
        /*$$scope*/
        b[13],
        l ? zs(
          d,
          /*$$scope*/
          b[13],
          D,
          null
        ) : Ps(
          /*$$scope*/
          b[13]
        ),
        null
      ), (!l || D & /*size*/
      16) && he(
        n,
        "x-small",
        /*size*/
        b[4] === "x-small"
      ), (!l || D & /*size*/
      16) && he(
        n,
        "small",
        /*size*/
        b[4] === "small"
      ), (!l || D & /*size*/
      16) && he(
        n,
        "large",
        /*size*/
        b[4] === "large"
      ), (!l || D & /*size*/
      16) && he(
        n,
        "medium",
        /*size*/
        b[4] === "medium"
      ), (!l || D & /*disabled*/
      128) && (e.disabled = /*disabled*/
      b[7]), (!l || D & /*label*/
      2) && at(
        e,
        "aria-label",
        /*label*/
        b[1]
      ), (!l || D & /*hasPopup*/
      256) && at(
        e,
        "aria-haspopup",
        /*hasPopup*/
        b[8]
      ), (!l || D & /*label*/
      2) && at(
        e,
        "title",
        /*label*/
        b[1]
      ), (!l || D & /*pending*/
      8) && he(
        e,
        "pending",
        /*pending*/
        b[3]
      ), (!l || D & /*padded*/
      32) && he(
        e,
        "padded",
        /*padded*/
        b[5]
      ), (!l || D & /*highlight*/
      64) && he(
        e,
        "highlight",
        /*highlight*/
        b[6]
      ), (!l || D & /*transparent*/
      512) && he(
        e,
        "transparent",
        /*transparent*/
        b[9]
      ), D & /*disabled, _color*/
      2176 && vn(e, "color", !/*disabled*/
      b[7] && /*_color*/
      b[11] ? (
        /*_color*/
        b[11]
      ) : "var(--block-label-text-color)"), D & /*disabled, background*/
      1152 && vn(e, "--bg-color", /*disabled*/
      b[7] ? "auto" : (
        /*background*/
        b[10]
      ));
    },
    i(b) {
      l || (i && _i(i.$$.fragment, b), _i(m, b), l = !0);
    },
    o(b) {
      i && di(i.$$.fragment, b), di(m, b), l = !1;
    },
    d(b) {
      b && on(e), u && u.d(), i && Go(i), m && m.d(b), r = !1, s();
    }
  };
}
function Xs(o, e, t) {
  let n, { $$slots: i = {}, $$scope: a } = e, { Icon: l } = e, { label: r = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: p = !0 } = e, { highlight: d = !1 } = e, { disabled: m = !1 } = e, { hasPopup: b = !1 } = e, { color: D = "var(--block-label-text-color)" } = e, { transparent: g = !1 } = e, { background: F = "var(--block-background-fill)" } = e;
  function h(_) {
    Ls.call(this, o, _);
  }
  return o.$$set = (_) => {
    "Icon" in _ && t(0, l = _.Icon), "label" in _ && t(1, r = _.label), "show_label" in _ && t(2, s = _.show_label), "pending" in _ && t(3, u = _.pending), "size" in _ && t(4, c = _.size), "padded" in _ && t(5, p = _.padded), "highlight" in _ && t(6, d = _.highlight), "disabled" in _ && t(7, m = _.disabled), "hasPopup" in _ && t(8, b = _.hasPopup), "color" in _ && t(12, D = _.color), "transparent" in _ && t(9, g = _.transparent), "background" in _ && t(10, F = _.background), "$$scope" in _ && t(13, a = _.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty & /*highlight, color*/
    4160 && t(11, n = d ? "var(--color-accent)" : D);
  }, [
    l,
    r,
    s,
    u,
    c,
    p,
    d,
    m,
    b,
    g,
    F,
    n,
    D,
    a,
    i,
    h
  ];
}
class Vn extends Is {
  constructor(e) {
    super(), Hs(this, e, Xs, Ys, Gs, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: Vf,
  append_hydration: Wf,
  attr: Zf,
  binding_callbacks: Yf,
  children: Xf,
  claim_element: Kf,
  create_slot: Qf,
  detach: Jf,
  element: eh,
  get_all_dirty_from_scope: th,
  get_slot_changes: nh,
  init: ih,
  insert_hydration: oh,
  safe_not_equal: lh,
  toggle_class: ah,
  transition_in: rh,
  transition_out: sh,
  update_slot_base: uh
} = window.__gradio__svelte__internal, {
  SvelteComponent: ch,
  append_hydration: _h,
  attr: dh,
  children: fh,
  claim_svg_element: hh,
  detach: ph,
  init: mh,
  insert_hydration: gh,
  noop: vh,
  safe_not_equal: Dh,
  svg_element: bh
} = window.__gradio__svelte__internal, {
  SvelteComponent: wh,
  append_hydration: yh,
  attr: Fh,
  children: kh,
  claim_svg_element: Eh,
  detach: $h,
  init: Ah,
  insert_hydration: Ch,
  noop: Sh,
  safe_not_equal: Th,
  svg_element: xh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bh,
  append_hydration: Rh,
  attr: Ih,
  children: Lh,
  claim_svg_element: qh,
  detach: Oh,
  init: Nh,
  insert_hydration: Mh,
  noop: Ph,
  safe_not_equal: zh,
  svg_element: Uh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hh,
  append_hydration: jh,
  attr: Gh,
  children: Vh,
  claim_svg_element: Wh,
  detach: Zh,
  init: Yh,
  insert_hydration: Xh,
  noop: Kh,
  safe_not_equal: Qh,
  svg_element: Jh
} = window.__gradio__svelte__internal, {
  SvelteComponent: ep,
  append_hydration: tp,
  attr: np,
  children: ip,
  claim_svg_element: op,
  detach: lp,
  init: ap,
  insert_hydration: rp,
  noop: sp,
  safe_not_equal: up,
  svg_element: cp
} = window.__gradio__svelte__internal, {
  SvelteComponent: _p,
  append_hydration: dp,
  attr: fp,
  children: hp,
  claim_svg_element: pp,
  detach: mp,
  init: gp,
  insert_hydration: vp,
  noop: Dp,
  safe_not_equal: bp,
  svg_element: wp
} = window.__gradio__svelte__internal, {
  SvelteComponent: yp,
  append_hydration: Fp,
  attr: kp,
  children: Ep,
  claim_svg_element: $p,
  detach: Ap,
  init: Cp,
  insert_hydration: Sp,
  noop: Tp,
  safe_not_equal: xp,
  svg_element: Bp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rp,
  append_hydration: Ip,
  attr: Lp,
  children: qp,
  claim_svg_element: Op,
  detach: Np,
  init: Mp,
  insert_hydration: Pp,
  noop: zp,
  safe_not_equal: Up,
  svg_element: Hp
} = window.__gradio__svelte__internal, {
  SvelteComponent: jp,
  append_hydration: Gp,
  attr: Vp,
  children: Wp,
  claim_svg_element: Zp,
  detach: Yp,
  init: Xp,
  insert_hydration: Kp,
  noop: Qp,
  safe_not_equal: Jp,
  svg_element: em
} = window.__gradio__svelte__internal, {
  SvelteComponent: tm,
  append_hydration: nm,
  attr: im,
  children: om,
  claim_svg_element: lm,
  detach: am,
  init: rm,
  insert_hydration: sm,
  noop: um,
  safe_not_equal: cm,
  svg_element: _m
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ks,
  append_hydration: Qs,
  attr: Ce,
  children: Yo,
  claim_svg_element: Xo,
  detach: fi,
  init: Js,
  insert_hydration: eu,
  noop: hi,
  safe_not_equal: tu,
  svg_element: Ko
} = window.__gradio__svelte__internal;
function nu(o) {
  let e, t;
  return {
    c() {
      e = Ko("svg"), t = Ko("path"), this.h();
    },
    l(n) {
      e = Xo(n, "svg", {
        width: !0,
        height: !0,
        "stroke-width": !0,
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        color: !0
      });
      var i = Yo(e);
      t = Xo(i, "path", {
        d: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Yo(t).forEach(fi), i.forEach(fi), this.h();
    },
    h() {
      Ce(t, "d", "M5 13L9 17L19 7"), Ce(t, "stroke", "currentColor"), Ce(t, "stroke-width", "1.5"), Ce(t, "stroke-linecap", "round"), Ce(t, "stroke-linejoin", "round"), Ce(e, "width", "100%"), Ce(e, "height", "100%"), Ce(e, "stroke-width", "1.5"), Ce(e, "viewBox", "0 0 24 24"), Ce(e, "fill", "none"), Ce(e, "xmlns", "http://www.w3.org/2000/svg"), Ce(e, "color", "currentColor");
    },
    m(n, i) {
      eu(n, e, i), Qs(e, t);
    },
    p: hi,
    i: hi,
    o: hi,
    d(n) {
      n && fi(e);
    }
  };
}
class Qo extends Ks {
  constructor(e) {
    super(), Js(this, e, null, nu, tu, {});
  }
}
const {
  SvelteComponent: dm,
  append_hydration: fm,
  attr: hm,
  children: pm,
  claim_svg_element: mm,
  detach: gm,
  init: vm,
  insert_hydration: Dm,
  noop: bm,
  safe_not_equal: wm,
  svg_element: ym
} = window.__gradio__svelte__internal, {
  SvelteComponent: iu,
  append_hydration: pi,
  attr: qe,
  children: Dn,
  claim_svg_element: bn,
  detach: Zt,
  init: ou,
  insert_hydration: lu,
  noop: mi,
  safe_not_equal: au,
  set_style: je,
  svg_element: wn
} = window.__gradio__svelte__internal;
function ru(o) {
  let e, t, n, i;
  return {
    c() {
      e = wn("svg"), t = wn("g"), n = wn("path"), i = wn("path"), this.h();
    },
    l(a) {
      e = bn(a, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = Dn(e);
      t = bn(l, "g", { transform: !0 });
      var r = Dn(t);
      n = bn(r, "path", { d: !0, style: !0 }), Dn(n).forEach(Zt), r.forEach(Zt), i = bn(l, "path", { d: !0, style: !0 }), Dn(i).forEach(Zt), l.forEach(Zt), this.h();
    },
    h() {
      qe(n, "d", "M18,6L6.087,17.913"), je(n, "fill", "none"), je(n, "fill-rule", "nonzero"), je(n, "stroke-width", "2px"), qe(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), qe(i, "d", "M4.364,4.364L19.636,19.636"), je(i, "fill", "none"), je(i, "fill-rule", "nonzero"), je(i, "stroke-width", "2px"), qe(e, "width", "100%"), qe(e, "height", "100%"), qe(e, "viewBox", "0 0 24 24"), qe(e, "version", "1.1"), qe(e, "xmlns", "http://www.w3.org/2000/svg"), qe(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), qe(e, "xml:space", "preserve"), qe(e, "stroke", "currentColor"), je(e, "fill-rule", "evenodd"), je(e, "clip-rule", "evenodd"), je(e, "stroke-linecap", "round"), je(e, "stroke-linejoin", "round");
    },
    m(a, l) {
      lu(a, e, l), pi(e, t), pi(t, n), pi(e, i);
    },
    p: mi,
    i: mi,
    o: mi,
    d(a) {
      a && Zt(e);
    }
  };
}
let su = class extends iu {
  constructor(e) {
    super(), ou(this, e, null, ru, au, {});
  }
};
const {
  SvelteComponent: km,
  append_hydration: Em,
  attr: $m,
  children: Am,
  claim_svg_element: Cm,
  detach: Sm,
  init: Tm,
  insert_hydration: xm,
  noop: Bm,
  safe_not_equal: Rm,
  svg_element: Im
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lm,
  append_hydration: qm,
  attr: Om,
  children: Nm,
  claim_svg_element: Mm,
  detach: Pm,
  init: zm,
  insert_hydration: Um,
  noop: Hm,
  safe_not_equal: jm,
  svg_element: Gm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vm,
  append_hydration: Wm,
  attr: Zm,
  children: Ym,
  claim_svg_element: Xm,
  detach: Km,
  init: Qm,
  insert_hydration: Jm,
  noop: eg,
  safe_not_equal: tg,
  svg_element: ng
} = window.__gradio__svelte__internal, {
  SvelteComponent: ig,
  append_hydration: og,
  attr: lg,
  children: ag,
  claim_svg_element: rg,
  detach: sg,
  init: ug,
  insert_hydration: cg,
  noop: _g,
  safe_not_equal: dg,
  svg_element: fg
} = window.__gradio__svelte__internal, {
  SvelteComponent: uu,
  append_hydration: Jo,
  attr: Ge,
  children: gi,
  claim_svg_element: vi,
  detach: yn,
  init: cu,
  insert_hydration: _u,
  noop: Di,
  safe_not_equal: du,
  svg_element: bi
} = window.__gradio__svelte__internal;
function fu(o) {
  let e, t, n;
  return {
    c() {
      e = bi("svg"), t = bi("path"), n = bi("path"), this.h();
    },
    l(i) {
      e = vi(i, "svg", {
        xmlns: !0,
        viewBox: !0,
        color: !0,
        "aria-hidden": !0,
        width: !0,
        height: !0
      });
      var a = gi(e);
      t = vi(a, "path", { fill: !0, d: !0 }), gi(t).forEach(yn), n = vi(a, "path", { fill: !0, d: !0 }), gi(n).forEach(yn), a.forEach(yn), this.h();
    },
    h() {
      Ge(t, "fill", "currentColor"), Ge(t, "d", "M28 10v18H10V10h18m0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2Z"), Ge(n, "fill", "currentColor"), Ge(n, "d", "M4 18H2V4a2 2 0 0 1 2-2h14v2H4Z"), Ge(e, "xmlns", "http://www.w3.org/2000/svg"), Ge(e, "viewBox", "0 0 33 33"), Ge(e, "color", "currentColor"), Ge(e, "aria-hidden", "true"), Ge(e, "width", "100%"), Ge(e, "height", "100%");
    },
    m(i, a) {
      _u(i, e, a), Jo(e, t), Jo(e, n);
    },
    p: Di,
    i: Di,
    o: Di,
    d(i) {
      i && yn(e);
    }
  };
}
class el extends uu {
  constructor(e) {
    super(), cu(this, e, null, fu, du, {});
  }
}
const {
  SvelteComponent: hg,
  append_hydration: pg,
  attr: mg,
  children: gg,
  claim_svg_element: vg,
  detach: Dg,
  init: bg,
  insert_hydration: wg,
  noop: yg,
  safe_not_equal: Fg,
  svg_element: kg
} = window.__gradio__svelte__internal, {
  SvelteComponent: hu,
  append_hydration: pu,
  attr: Nt,
  children: tl,
  claim_svg_element: nl,
  detach: wi,
  init: mu,
  insert_hydration: gu,
  noop: yi,
  safe_not_equal: vu,
  svg_element: il
} = window.__gradio__svelte__internal;
function Du(o) {
  let e, t;
  return {
    c() {
      e = il("svg"), t = il("path"), this.h();
    },
    l(n) {
      e = nl(n, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var i = tl(e);
      t = nl(i, "path", { fill: !0, d: !0 }), tl(t).forEach(wi), i.forEach(wi), this.h();
    },
    h() {
      Nt(t, "fill", "currentColor"), Nt(t, "d", "M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4zm0-10l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10l10-10z"), Nt(e, "xmlns", "http://www.w3.org/2000/svg"), Nt(e, "width", "100%"), Nt(e, "height", "100%"), Nt(e, "viewBox", "0 0 32 32");
    },
    m(n, i) {
      gu(n, e, i), pu(e, t);
    },
    p: yi,
    i: yi,
    o: yi,
    d(n) {
      n && wi(e);
    }
  };
}
class bu extends hu {
  constructor(e) {
    super(), mu(this, e, null, Du, vu, {});
  }
}
const {
  SvelteComponent: Eg,
  append_hydration: $g,
  attr: Ag,
  children: Cg,
  claim_svg_element: Sg,
  detach: Tg,
  init: xg,
  insert_hydration: Bg,
  noop: Rg,
  safe_not_equal: Ig,
  svg_element: Lg
} = window.__gradio__svelte__internal, {
  SvelteComponent: qg,
  append_hydration: Og,
  attr: Ng,
  children: Mg,
  claim_svg_element: Pg,
  detach: zg,
  init: Ug,
  insert_hydration: Hg,
  noop: jg,
  safe_not_equal: Gg,
  svg_element: Vg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wg,
  append_hydration: Zg,
  attr: Yg,
  children: Xg,
  claim_svg_element: Kg,
  detach: Qg,
  init: Jg,
  insert_hydration: e0,
  noop: t0,
  safe_not_equal: n0,
  svg_element: i0
} = window.__gradio__svelte__internal, {
  SvelteComponent: o0,
  append_hydration: l0,
  attr: a0,
  children: r0,
  claim_svg_element: s0,
  detach: u0,
  init: c0,
  insert_hydration: _0,
  noop: d0,
  safe_not_equal: f0,
  svg_element: h0
} = window.__gradio__svelte__internal, {
  SvelteComponent: p0,
  append_hydration: m0,
  attr: g0,
  children: v0,
  claim_svg_element: D0,
  detach: b0,
  init: w0,
  insert_hydration: y0,
  noop: F0,
  safe_not_equal: k0,
  svg_element: E0
} = window.__gradio__svelte__internal, {
  SvelteComponent: $0,
  append_hydration: A0,
  attr: C0,
  children: S0,
  claim_svg_element: T0,
  detach: x0,
  init: B0,
  insert_hydration: R0,
  noop: I0,
  safe_not_equal: L0,
  svg_element: q0
} = window.__gradio__svelte__internal, {
  SvelteComponent: O0,
  append_hydration: N0,
  attr: M0,
  children: P0,
  claim_svg_element: z0,
  detach: U0,
  init: H0,
  insert_hydration: j0,
  noop: G0,
  safe_not_equal: V0,
  svg_element: W0
} = window.__gradio__svelte__internal, {
  SvelteComponent: Z0,
  append_hydration: Y0,
  attr: X0,
  children: K0,
  claim_svg_element: Q0,
  detach: J0,
  init: e1,
  insert_hydration: t1,
  noop: n1,
  safe_not_equal: i1,
  svg_element: o1
} = window.__gradio__svelte__internal, {
  SvelteComponent: l1,
  append_hydration: a1,
  attr: r1,
  children: s1,
  claim_svg_element: u1,
  detach: c1,
  init: _1,
  insert_hydration: d1,
  noop: f1,
  safe_not_equal: h1,
  svg_element: p1
} = window.__gradio__svelte__internal, {
  SvelteComponent: m1,
  append_hydration: g1,
  attr: v1,
  children: D1,
  claim_svg_element: b1,
  detach: w1,
  init: y1,
  insert_hydration: F1,
  noop: k1,
  safe_not_equal: E1,
  svg_element: $1
} = window.__gradio__svelte__internal, {
  SvelteComponent: A1,
  append_hydration: C1,
  attr: S1,
  children: T1,
  claim_svg_element: x1,
  detach: B1,
  init: R1,
  insert_hydration: I1,
  noop: L1,
  safe_not_equal: q1,
  svg_element: O1
} = window.__gradio__svelte__internal, {
  SvelteComponent: N1,
  append_hydration: M1,
  attr: P1,
  children: z1,
  claim_svg_element: U1,
  detach: H1,
  init: j1,
  insert_hydration: G1,
  noop: V1,
  safe_not_equal: W1,
  svg_element: Z1
} = window.__gradio__svelte__internal, {
  SvelteComponent: Y1,
  append_hydration: X1,
  attr: K1,
  children: Q1,
  claim_svg_element: J1,
  detach: ev,
  init: tv,
  insert_hydration: nv,
  noop: iv,
  safe_not_equal: ov,
  svg_element: lv
} = window.__gradio__svelte__internal, {
  SvelteComponent: av,
  append_hydration: rv,
  attr: sv,
  children: uv,
  claim_svg_element: cv,
  detach: _v,
  init: dv,
  insert_hydration: fv,
  noop: hv,
  safe_not_equal: pv,
  svg_element: mv
} = window.__gradio__svelte__internal, {
  SvelteComponent: gv,
  append_hydration: vv,
  attr: Dv,
  children: bv,
  claim_svg_element: wv,
  detach: yv,
  init: Fv,
  insert_hydration: kv,
  noop: Ev,
  safe_not_equal: $v,
  svg_element: Av
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cv,
  append_hydration: Sv,
  attr: Tv,
  children: xv,
  claim_svg_element: Bv,
  detach: Rv,
  init: Iv,
  insert_hydration: Lv,
  noop: qv,
  safe_not_equal: Ov,
  svg_element: Nv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mv,
  append_hydration: Pv,
  attr: zv,
  children: Uv,
  claim_svg_element: Hv,
  detach: jv,
  init: Gv,
  insert_hydration: Vv,
  noop: Wv,
  safe_not_equal: Zv,
  svg_element: Yv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xv,
  append_hydration: Kv,
  attr: Qv,
  children: Jv,
  claim_svg_element: eD,
  detach: tD,
  init: nD,
  insert_hydration: iD,
  noop: oD,
  safe_not_equal: lD,
  svg_element: aD
} = window.__gradio__svelte__internal, {
  SvelteComponent: rD,
  append_hydration: sD,
  attr: uD,
  children: cD,
  claim_svg_element: _D,
  detach: dD,
  init: fD,
  insert_hydration: hD,
  noop: pD,
  safe_not_equal: mD,
  svg_element: gD
} = window.__gradio__svelte__internal, {
  SvelteComponent: vD,
  append_hydration: DD,
  attr: bD,
  children: wD,
  claim_svg_element: yD,
  detach: FD,
  init: kD,
  insert_hydration: ED,
  noop: $D,
  safe_not_equal: AD,
  svg_element: CD
} = window.__gradio__svelte__internal, {
  SvelteComponent: SD,
  append_hydration: TD,
  attr: xD,
  children: BD,
  claim_svg_element: RD,
  detach: ID,
  init: LD,
  insert_hydration: qD,
  noop: OD,
  safe_not_equal: ND,
  svg_element: MD
} = window.__gradio__svelte__internal, {
  SvelteComponent: PD,
  append_hydration: zD,
  attr: UD,
  children: HD,
  claim_svg_element: jD,
  detach: GD,
  init: VD,
  insert_hydration: WD,
  noop: ZD,
  safe_not_equal: YD,
  svg_element: XD
} = window.__gradio__svelte__internal, {
  SvelteComponent: KD,
  append_hydration: QD,
  attr: JD,
  children: eb,
  claim_svg_element: tb,
  detach: nb,
  init: ib,
  insert_hydration: ob,
  noop: lb,
  safe_not_equal: ab,
  svg_element: rb
} = window.__gradio__svelte__internal, {
  SvelteComponent: sb,
  append_hydration: ub,
  attr: cb,
  children: _b,
  claim_svg_element: db,
  detach: fb,
  init: hb,
  insert_hydration: pb,
  noop: mb,
  safe_not_equal: gb,
  svg_element: vb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Db,
  append_hydration: bb,
  attr: wb,
  children: yb,
  claim_svg_element: Fb,
  detach: kb,
  init: Eb,
  insert_hydration: $b,
  noop: Ab,
  safe_not_equal: Cb,
  svg_element: Sb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tb,
  append_hydration: xb,
  attr: Bb,
  children: Rb,
  claim_svg_element: Ib,
  detach: Lb,
  init: qb,
  insert_hydration: Ob,
  noop: Nb,
  safe_not_equal: Mb,
  svg_element: Pb
} = window.__gradio__svelte__internal, {
  SvelteComponent: zb,
  append_hydration: Ub,
  attr: Hb,
  children: jb,
  claim_svg_element: Gb,
  detach: Vb,
  init: Wb,
  insert_hydration: Zb,
  noop: Yb,
  safe_not_equal: Xb,
  svg_element: Kb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qb,
  append_hydration: Jb,
  attr: ew,
  children: tw,
  claim_svg_element: nw,
  detach: iw,
  init: ow,
  insert_hydration: lw,
  noop: aw,
  safe_not_equal: rw,
  set_style: sw,
  svg_element: uw
} = window.__gradio__svelte__internal, {
  SvelteComponent: cw,
  append_hydration: _w,
  attr: dw,
  children: fw,
  claim_svg_element: hw,
  detach: pw,
  init: mw,
  insert_hydration: gw,
  noop: vw,
  safe_not_equal: Dw,
  svg_element: bw
} = window.__gradio__svelte__internal, {
  SvelteComponent: ww,
  append_hydration: yw,
  attr: Fw,
  children: kw,
  claim_svg_element: Ew,
  detach: $w,
  init: Aw,
  insert_hydration: Cw,
  noop: Sw,
  safe_not_equal: Tw,
  svg_element: xw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bw,
  append_hydration: Rw,
  attr: Iw,
  children: Lw,
  claim_svg_element: qw,
  detach: Ow,
  init: Nw,
  insert_hydration: Mw,
  noop: Pw,
  safe_not_equal: zw,
  svg_element: Uw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hw,
  append_hydration: jw,
  attr: Gw,
  children: Vw,
  claim_svg_element: Ww,
  detach: Zw,
  init: Yw,
  insert_hydration: Xw,
  noop: Kw,
  safe_not_equal: Qw,
  svg_element: Jw
} = window.__gradio__svelte__internal, {
  SvelteComponent: ey,
  append_hydration: ty,
  attr: ny,
  children: iy,
  claim_svg_element: oy,
  detach: ly,
  init: ay,
  insert_hydration: ry,
  noop: sy,
  safe_not_equal: uy,
  svg_element: cy
} = window.__gradio__svelte__internal, {
  SvelteComponent: _y,
  append_hydration: dy,
  attr: fy,
  children: hy,
  claim_svg_element: py,
  detach: my,
  init: gy,
  insert_hydration: vy,
  noop: Dy,
  safe_not_equal: by,
  svg_element: wy
} = window.__gradio__svelte__internal, {
  SvelteComponent: yy,
  append_hydration: Fy,
  attr: ky,
  children: Ey,
  claim_svg_element: $y,
  detach: Ay,
  init: Cy,
  insert_hydration: Sy,
  noop: Ty,
  safe_not_equal: xy,
  svg_element: By
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ry,
  append_hydration: Iy,
  attr: Ly,
  children: qy,
  claim_svg_element: Oy,
  detach: Ny,
  init: My,
  insert_hydration: Py,
  noop: zy,
  safe_not_equal: Uy,
  svg_element: Hy
} = window.__gradio__svelte__internal, {
  SvelteComponent: wu,
  append_hydration: dt,
  attr: ee,
  children: ft,
  claim_svg_element: ht,
  claim_text: yu,
  detach: lt,
  init: Fu,
  insert_hydration: ku,
  noop: Fi,
  safe_not_equal: Eu,
  svg_element: pt,
  text: $u
} = window.__gradio__svelte__internal;
function Au(o) {
  let e, t, n, i, a, l, r, s, u;
  return {
    c() {
      e = pt("svg"), t = pt("defs"), n = pt("style"), i = $u(`.cls-1 {
				fill: none;
			}
		`), a = pt("rect"), l = pt("rect"), r = pt("path"), s = pt("rect"), u = pt("rect"), this.h();
    },
    l(c) {
      e = ht(c, "svg", {
        id: !0,
        xmlns: !0,
        viewBox: !0,
        fill: !0,
        width: !0,
        height: !0
      });
      var p = ft(e);
      t = ht(p, "defs", {});
      var d = ft(t);
      n = ht(d, "style", {});
      var m = ft(n);
      i = yu(m, `.cls-1 {
				fill: none;
			}
		`), m.forEach(lt), d.forEach(lt), a = ht(p, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0
      }), ft(a).forEach(lt), l = ht(p, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0
      }), ft(l).forEach(lt), r = ht(p, "path", { d: !0 }), ft(r).forEach(lt), s = ht(p, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0
      }), ft(s).forEach(lt), u = ht(p, "rect", {
        id: !0,
        "data-name": !0,
        class: !0,
        width: !0,
        height: !0
      }), ft(u).forEach(lt), p.forEach(lt), this.h();
    },
    h() {
      ee(a, "x", "12"), ee(a, "y", "12"), ee(a, "width", "2"), ee(a, "height", "12"), ee(l, "x", "18"), ee(l, "y", "12"), ee(l, "width", "2"), ee(l, "height", "12"), ee(r, "d", "M4,6V8H6V28a2,2,0,0,0,2,2H24a2,2,0,0,0,2-2V8h2V6ZM8,28V8H24V28Z"), ee(s, "x", "12"), ee(s, "y", "2"), ee(s, "width", "8"), ee(s, "height", "2"), ee(u, "id", "_Transparent_Rectangle_"), ee(u, "data-name", "<Transparent Rectangle>"), ee(u, "class", "cls-1"), ee(u, "width", "32"), ee(u, "height", "32"), ee(e, "id", "icon"), ee(e, "xmlns", "http://www.w3.org/2000/svg"), ee(e, "viewBox", "0 0 32 32"), ee(e, "fill", "currentColor"), ee(e, "width", "100%"), ee(e, "height", "100%");
    },
    m(c, p) {
      ku(c, e, p), dt(e, t), dt(t, n), dt(n, i), dt(e, a), dt(e, l), dt(e, r), dt(e, s), dt(e, u);
    },
    p: Fi,
    i: Fi,
    o: Fi,
    d(c) {
      c && lt(e);
    }
  };
}
class Cu extends wu {
  constructor(e) {
    super(), Fu(this, e, null, Au, Eu, {});
  }
}
const {
  SvelteComponent: jy,
  append_hydration: Gy,
  attr: Vy,
  children: Wy,
  claim_svg_element: Zy,
  detach: Yy,
  init: Xy,
  insert_hydration: Ky,
  noop: Qy,
  safe_not_equal: Jy,
  svg_element: eF
} = window.__gradio__svelte__internal, {
  SvelteComponent: tF,
  append_hydration: nF,
  attr: iF,
  children: oF,
  claim_svg_element: lF,
  detach: aF,
  init: rF,
  insert_hydration: sF,
  noop: uF,
  safe_not_equal: cF,
  svg_element: _F
} = window.__gradio__svelte__internal, {
  SvelteComponent: dF,
  append_hydration: fF,
  attr: hF,
  children: pF,
  claim_svg_element: mF,
  detach: gF,
  init: vF,
  insert_hydration: DF,
  noop: bF,
  safe_not_equal: wF,
  svg_element: yF
} = window.__gradio__svelte__internal, {
  SvelteComponent: FF,
  append_hydration: kF,
  attr: EF,
  children: $F,
  claim_svg_element: AF,
  detach: CF,
  init: SF,
  insert_hydration: TF,
  noop: xF,
  safe_not_equal: BF,
  svg_element: RF
} = window.__gradio__svelte__internal, {
  SvelteComponent: IF,
  append_hydration: LF,
  attr: qF,
  children: OF,
  claim_svg_element: NF,
  detach: MF,
  init: PF,
  insert_hydration: zF,
  noop: UF,
  safe_not_equal: HF,
  svg_element: jF
} = window.__gradio__svelte__internal, {
  SvelteComponent: GF,
  append_hydration: VF,
  attr: WF,
  children: ZF,
  claim_svg_element: YF,
  detach: XF,
  init: KF,
  insert_hydration: QF,
  noop: JF,
  safe_not_equal: e2,
  svg_element: t2
} = window.__gradio__svelte__internal, {
  SvelteComponent: n2,
  append_hydration: i2,
  attr: o2,
  children: l2,
  claim_svg_element: a2,
  detach: r2,
  init: s2,
  insert_hydration: u2,
  noop: c2,
  safe_not_equal: _2,
  svg_element: d2
} = window.__gradio__svelte__internal, {
  SvelteComponent: f2,
  append_hydration: h2,
  attr: p2,
  children: m2,
  claim_svg_element: g2,
  claim_text: v2,
  detach: D2,
  init: b2,
  insert_hydration: w2,
  noop: y2,
  safe_not_equal: F2,
  svg_element: k2,
  text: E2
} = window.__gradio__svelte__internal, {
  SvelteComponent: $2,
  append_hydration: A2,
  attr: C2,
  children: S2,
  claim_svg_element: T2,
  claim_text: x2,
  detach: B2,
  init: R2,
  insert_hydration: I2,
  noop: L2,
  safe_not_equal: q2,
  svg_element: O2,
  text: N2
} = window.__gradio__svelte__internal, {
  SvelteComponent: M2,
  append_hydration: P2,
  attr: z2,
  children: U2,
  claim_svg_element: H2,
  claim_text: j2,
  detach: G2,
  init: V2,
  insert_hydration: W2,
  noop: Z2,
  safe_not_equal: Y2,
  svg_element: X2,
  text: K2
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q2,
  append_hydration: J2,
  attr: ek,
  children: tk,
  claim_svg_element: nk,
  detach: ik,
  init: ok,
  insert_hydration: lk,
  noop: ak,
  safe_not_equal: rk,
  svg_element: sk
} = window.__gradio__svelte__internal, {
  SvelteComponent: uk,
  append_hydration: ck,
  attr: _k,
  children: dk,
  claim_svg_element: fk,
  detach: hk,
  init: pk,
  insert_hydration: mk,
  noop: gk,
  safe_not_equal: vk,
  svg_element: Dk
} = window.__gradio__svelte__internal, {
  SvelteComponent: bk,
  append_hydration: wk,
  attr: yk,
  children: Fk,
  claim_svg_element: kk,
  detach: Ek,
  init: $k,
  insert_hydration: Ak,
  noop: Ck,
  safe_not_equal: Sk,
  svg_element: Tk
} = window.__gradio__svelte__internal, {
  SvelteComponent: xk,
  append_hydration: Bk,
  attr: Rk,
  children: Ik,
  claim_svg_element: Lk,
  detach: qk,
  init: Ok,
  insert_hydration: Nk,
  noop: Mk,
  safe_not_equal: Pk,
  svg_element: zk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uk,
  append_hydration: Hk,
  attr: jk,
  children: Gk,
  claim_svg_element: Vk,
  detach: Wk,
  init: Zk,
  insert_hydration: Yk,
  noop: Xk,
  safe_not_equal: Kk,
  svg_element: Qk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jk,
  append_hydration: eE,
  attr: tE,
  children: nE,
  claim_svg_element: iE,
  detach: oE,
  init: lE,
  insert_hydration: aE,
  noop: rE,
  safe_not_equal: sE,
  svg_element: uE
} = window.__gradio__svelte__internal, {
  SvelteComponent: cE,
  append_hydration: _E,
  attr: dE,
  children: fE,
  claim_svg_element: hE,
  detach: pE,
  init: mE,
  insert_hydration: gE,
  noop: vE,
  safe_not_equal: DE,
  svg_element: bE
} = window.__gradio__svelte__internal, {
  SvelteComponent: wE,
  append_hydration: yE,
  attr: FE,
  children: kE,
  claim_svg_element: EE,
  detach: $E,
  init: AE,
  insert_hydration: CE,
  noop: SE,
  safe_not_equal: TE,
  svg_element: xE
} = window.__gradio__svelte__internal, Su = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], ol = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Su.reduce(
  (o, { color: e, primary: t, secondary: n }) => ({
    ...o,
    [e]: {
      primary: ol[e][t],
      secondary: ol[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: BE,
  claim_component: RE,
  create_component: IE,
  destroy_component: LE,
  init: qE,
  mount_component: OE,
  safe_not_equal: NE,
  transition_in: ME,
  transition_out: PE
} = window.__gradio__svelte__internal, { createEventDispatcher: zE } = window.__gradio__svelte__internal, {
  SvelteComponent: UE,
  append_hydration: HE,
  attr: jE,
  check_outros: GE,
  children: VE,
  claim_component: WE,
  claim_element: ZE,
  claim_space: YE,
  claim_text: XE,
  create_component: KE,
  destroy_component: QE,
  detach: JE,
  element: e$,
  empty: t$,
  group_outros: n$,
  init: i$,
  insert_hydration: o$,
  mount_component: l$,
  safe_not_equal: a$,
  set_data: r$,
  space: s$,
  text: u$,
  toggle_class: c$,
  transition_in: _$,
  transition_out: d$
} = window.__gradio__svelte__internal, {
  SvelteComponent: f$,
  attr: h$,
  children: p$,
  claim_element: m$,
  create_slot: g$,
  detach: v$,
  element: D$,
  get_all_dirty_from_scope: b$,
  get_slot_changes: w$,
  init: y$,
  insert_hydration: F$,
  safe_not_equal: k$,
  toggle_class: E$,
  transition_in: $$,
  transition_out: A$,
  update_slot_base: C$
} = window.__gradio__svelte__internal, {
  SvelteComponent: S$,
  append_hydration: T$,
  attr: x$,
  check_outros: B$,
  children: R$,
  claim_component: I$,
  claim_element: L$,
  claim_space: q$,
  create_component: O$,
  destroy_component: N$,
  detach: M$,
  element: P$,
  empty: z$,
  group_outros: U$,
  init: H$,
  insert_hydration: j$,
  listen: G$,
  mount_component: V$,
  safe_not_equal: W$,
  space: Z$,
  toggle_class: Y$,
  transition_in: X$,
  transition_out: K$
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tu,
  attr: ll,
  children: xu,
  claim_element: Bu,
  create_slot: Ru,
  detach: al,
  element: Iu,
  get_all_dirty_from_scope: Lu,
  get_slot_changes: qu,
  init: Ou,
  insert_hydration: Nu,
  null_to_empty: rl,
  safe_not_equal: Mu,
  transition_in: Pu,
  transition_out: zu,
  update_slot_base: Uu
} = window.__gradio__svelte__internal;
function Hu(o) {
  let e, t, n;
  const i = (
    /*#slots*/
    o[3].default
  ), a = Ru(
    i,
    o,
    /*$$scope*/
    o[2],
    null
  );
  return {
    c() {
      e = Iu("div"), a && a.c(), this.h();
    },
    l(l) {
      e = Bu(l, "DIV", { class: !0 });
      var r = xu(e);
      a && a.l(r), r.forEach(al), this.h();
    },
    h() {
      ll(e, "class", t = rl(`icon-button-wrapper ${/*top_panel*/
      o[0] ? "top-panel" : ""} ${/*display_top_corner*/
      o[1] ? "display-top-corner" : "hide-top-corner"}`) + " svelte-109se4");
    },
    m(l, r) {
      Nu(l, e, r), a && a.m(e, null), n = !0;
    },
    p(l, [r]) {
      a && a.p && (!n || r & /*$$scope*/
      4) && Uu(
        a,
        i,
        l,
        /*$$scope*/
        l[2],
        n ? qu(
          i,
          /*$$scope*/
          l[2],
          r,
          null
        ) : Lu(
          /*$$scope*/
          l[2]
        ),
        null
      ), (!n || r & /*top_panel, display_top_corner*/
      3 && t !== (t = rl(`icon-button-wrapper ${/*top_panel*/
      l[0] ? "top-panel" : ""} ${/*display_top_corner*/
      l[1] ? "display-top-corner" : "hide-top-corner"}`) + " svelte-109se4")) && ll(e, "class", t);
    },
    i(l) {
      n || (Pu(a, l), n = !0);
    },
    o(l) {
      zu(a, l), n = !1;
    },
    d(l) {
      l && al(e), a && a.d(l);
    }
  };
}
function ju(o, e, t) {
  let { $$slots: n = {}, $$scope: i } = e, { top_panel: a = !0 } = e, { display_top_corner: l = !1 } = e;
  return o.$$set = (r) => {
    "top_panel" in r && t(0, a = r.top_panel), "display_top_corner" in r && t(1, l = r.display_top_corner), "$$scope" in r && t(2, i = r.$$scope);
  }, [a, l, i, n];
}
class Gu extends Tu {
  constructor(e) {
    super(), Ou(this, e, ju, Hu, Mu, { top_panel: 0, display_top_corner: 1 });
  }
}
const {
  SvelteComponent: Q$,
  check_outros: J$,
  claim_component: eA,
  create_component: tA,
  destroy_component: nA,
  detach: iA,
  empty: oA,
  group_outros: lA,
  init: aA,
  insert_hydration: rA,
  mount_component: sA,
  noop: uA,
  safe_not_equal: cA,
  transition_in: _A,
  transition_out: dA
} = window.__gradio__svelte__internal, { createEventDispatcher: fA } = window.__gradio__svelte__internal;
function Pt(o) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; o > 1e3 && t < e.length - 1; )
    o /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(o) ? o : o.toFixed(1)) + n;
}
function Tn() {
}
const ya = typeof window < "u";
let sl = ya ? () => window.performance.now() : () => Date.now(), Fa = ya ? (o) => requestAnimationFrame(o) : Tn;
const Ut = /* @__PURE__ */ new Set();
function ka(o) {
  Ut.forEach((e) => {
    e.c(o) || (Ut.delete(e), e.f());
  }), Ut.size !== 0 && Fa(ka);
}
function Vu(o) {
  let e;
  return Ut.size === 0 && Fa(ka), { promise: new Promise((t) => {
    Ut.add(e = { c: o, f: t });
  }), abort() {
    Ut.delete(e);
  } };
}
const Mt = [];
function Wu(o, e = Tn) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function i(l) {
    if (s = l, ((r = o) != r ? s == s : r !== s || r && typeof r == "object" || typeof r == "function") && (o = l, t)) {
      const u = !Mt.length;
      for (const c of n) c[1](), Mt.push(c, o);
      if (u) {
        for (let c = 0; c < Mt.length; c += 2) Mt[c][0](Mt[c + 1]);
        Mt.length = 0;
      }
    }
    var r, s;
  }
  function a(l) {
    i(l(o));
  }
  return { set: i, update: a, subscribe: function(l, r = Tn) {
    const s = [l, r];
    return n.add(s), n.size === 1 && (t = e(i, a) || Tn), l(o), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function ul(o) {
  return Object.prototype.toString.call(o) === "[object Date]";
}
function ji(o, e, t, n) {
  if (typeof t == "number" || ul(t)) {
    const i = n - t, a = (t - e) / (o.dt || 1 / 60), l = (a + (o.opts.stiffness * i - o.opts.damping * a) * o.inv_mass) * o.dt;
    return Math.abs(l) < o.opts.precision && Math.abs(i) < o.opts.precision ? n : (o.settled = !1, ul(t) ? new Date(t.getTime() + l) : t + l);
  }
  if (Array.isArray(t)) return t.map((i, a) => ji(o, e[a], t[a], n[a]));
  if (typeof t == "object") {
    const i = {};
    for (const a in t) i[a] = ji(o, e[a], t[a], n[a]);
    return i;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function cl(o, e = {}) {
  const t = Wu(o), { stiffness: n = 0.15, damping: i = 0.8, precision: a = 0.01 } = e;
  let l, r, s, u = o, c = o, p = 1, d = 0, m = !1;
  function b(g, F = {}) {
    c = g;
    const h = s = {};
    return o == null || F.hard || D.stiffness >= 1 && D.damping >= 1 ? (m = !0, l = sl(), u = g, t.set(o = c), Promise.resolve()) : (F.soft && (d = 1 / (60 * (F.soft === !0 ? 0.5 : +F.soft)), p = 0), r || (l = sl(), m = !1, r = Vu((_) => {
      if (m) return m = !1, r = null, !1;
      p = Math.min(p + d, 1);
      const v = { inv_mass: p, opts: D, settled: !0, dt: 60 * (_ - l) / 1e3 }, y = ji(v, u, o, c);
      return l = _, u = o, t.set(o = y), v.settled && (r = null), !v.settled;
    })), new Promise((_) => {
      r.promise.then(() => {
        h === s && _();
      });
    }));
  }
  const D = { set: b, update: (g, F) => b(g(c, o), F), subscribe: t.subscribe, stiffness: n, damping: i, precision: a };
  return D;
}
const {
  SvelteComponent: Zu,
  append_hydration: Oe,
  attr: U,
  children: Se,
  claim_element: Yu,
  claim_svg_element: Ne,
  component_subscribe: _l,
  detach: we,
  element: Xu,
  init: Ku,
  insert_hydration: Qu,
  noop: dl,
  safe_not_equal: Ju,
  set_style: Fn,
  svg_element: Me,
  toggle_class: fl
} = window.__gradio__svelte__internal, { onMount: ec } = window.__gradio__svelte__internal;
function tc(o) {
  let e, t, n, i, a, l, r, s, u, c, p, d;
  return {
    c() {
      e = Xu("div"), t = Me("svg"), n = Me("g"), i = Me("path"), a = Me("path"), l = Me("path"), r = Me("path"), s = Me("g"), u = Me("path"), c = Me("path"), p = Me("path"), d = Me("path"), this.h();
    },
    l(m) {
      e = Yu(m, "DIV", { class: !0 });
      var b = Se(e);
      t = Ne(b, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var D = Se(t);
      n = Ne(D, "g", { style: !0 });
      var g = Se(n);
      i = Ne(g, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Se(i).forEach(we), a = Ne(g, "path", { d: !0, fill: !0, class: !0 }), Se(a).forEach(we), l = Ne(g, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Se(l).forEach(we), r = Ne(g, "path", { d: !0, fill: !0, class: !0 }), Se(r).forEach(we), g.forEach(we), s = Ne(D, "g", { style: !0 });
      var F = Se(s);
      u = Ne(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Se(u).forEach(we), c = Ne(F, "path", { d: !0, fill: !0, class: !0 }), Se(c).forEach(we), p = Ne(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Se(p).forEach(we), d = Ne(F, "path", { d: !0, fill: !0, class: !0 }), Se(d).forEach(we), F.forEach(we), D.forEach(we), b.forEach(we), this.h();
    },
    h() {
      U(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), U(i, "fill", "#FF7C00"), U(i, "fill-opacity", "0.4"), U(i, "class", "svelte-43sxxs"), U(a, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), U(a, "fill", "#FF7C00"), U(a, "class", "svelte-43sxxs"), U(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), U(l, "fill", "#FF7C00"), U(l, "fill-opacity", "0.4"), U(l, "class", "svelte-43sxxs"), U(r, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), U(r, "fill", "#FF7C00"), U(r, "class", "svelte-43sxxs"), Fn(n, "transform", "translate(" + /*$top*/
      o[1][0] + "px, " + /*$top*/
      o[1][1] + "px)"), U(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), U(u, "fill", "#FF7C00"), U(u, "fill-opacity", "0.4"), U(u, "class", "svelte-43sxxs"), U(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), U(c, "fill", "#FF7C00"), U(c, "class", "svelte-43sxxs"), U(p, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), U(p, "fill", "#FF7C00"), U(p, "fill-opacity", "0.4"), U(p, "class", "svelte-43sxxs"), U(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), U(d, "fill", "#FF7C00"), U(d, "class", "svelte-43sxxs"), Fn(s, "transform", "translate(" + /*$bottom*/
      o[2][0] + "px, " + /*$bottom*/
      o[2][1] + "px)"), U(t, "viewBox", "-1200 -1200 3000 3000"), U(t, "fill", "none"), U(t, "xmlns", "http://www.w3.org/2000/svg"), U(t, "class", "svelte-43sxxs"), U(e, "class", "svelte-43sxxs"), fl(
        e,
        "margin",
        /*margin*/
        o[0]
      );
    },
    m(m, b) {
      Qu(m, e, b), Oe(e, t), Oe(t, n), Oe(n, i), Oe(n, a), Oe(n, l), Oe(n, r), Oe(t, s), Oe(s, u), Oe(s, c), Oe(s, p), Oe(s, d);
    },
    p(m, [b]) {
      b & /*$top*/
      2 && Fn(n, "transform", "translate(" + /*$top*/
      m[1][0] + "px, " + /*$top*/
      m[1][1] + "px)"), b & /*$bottom*/
      4 && Fn(s, "transform", "translate(" + /*$bottom*/
      m[2][0] + "px, " + /*$bottom*/
      m[2][1] + "px)"), b & /*margin*/
      1 && fl(
        e,
        "margin",
        /*margin*/
        m[0]
      );
    },
    i: dl,
    o: dl,
    d(m) {
      m && we(e);
    }
  };
}
function nc(o, e, t) {
  let n, i;
  var a = this && this.__awaiter || function(m, b, D, g) {
    function F(h) {
      return h instanceof D ? h : new D(function(_) {
        _(h);
      });
    }
    return new (D || (D = Promise))(function(h, _) {
      function v(A) {
        try {
          w(g.next(A));
        } catch (T) {
          _(T);
        }
      }
      function y(A) {
        try {
          w(g.throw(A));
        } catch (T) {
          _(T);
        }
      }
      function w(A) {
        A.done ? h(A.value) : F(A.value).then(v, y);
      }
      w((g = g.apply(m, b || [])).next());
    });
  };
  let { margin: l = !0 } = e;
  const r = cl([0, 0]);
  _l(o, r, (m) => t(1, n = m));
  const s = cl([0, 0]);
  _l(o, s, (m) => t(2, i = m));
  let u;
  function c() {
    return a(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 140]), s.set([-125, -140])]), yield Promise.all([r.set([-125, 140]), s.set([125, -140])]), yield Promise.all([r.set([-125, 0]), s.set([125, -0])]), yield Promise.all([r.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function p() {
    return a(this, void 0, void 0, function* () {
      yield c(), u || p();
    });
  }
  function d() {
    return a(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 0]), s.set([-125, 0])]), p();
    });
  }
  return ec(() => (d(), () => u = !0)), o.$$set = (m) => {
    "margin" in m && t(0, l = m.margin);
  }, [l, n, i, r, s];
}
class ic extends Zu {
  constructor(e) {
    super(), Ku(this, e, nc, tc, Ju, { margin: 0 });
  }
}
const {
  SvelteComponent: oc,
  append_hydration: yt,
  attr: Ue,
  binding_callbacks: hl,
  check_outros: Gi,
  children: Qe,
  claim_component: Ea,
  claim_element: Je,
  claim_space: xe,
  claim_text: te,
  create_component: $a,
  create_slot: Aa,
  destroy_component: Ca,
  destroy_each: Sa,
  detach: R,
  element: et,
  empty: Re,
  ensure_array_like: Ln,
  get_all_dirty_from_scope: Ta,
  get_slot_changes: xa,
  group_outros: Vi,
  init: lc,
  insert_hydration: L,
  mount_component: Ba,
  noop: Wi,
  safe_not_equal: ac,
  set_data: Ie,
  set_style: vt,
  space: Be,
  text: ne,
  toggle_class: Te,
  transition_in: ze,
  transition_out: tt,
  update_slot_base: Ra
} = window.__gradio__svelte__internal, { tick: rc } = window.__gradio__svelte__internal, { onDestroy: sc } = window.__gradio__svelte__internal, { createEventDispatcher: uc } = window.__gradio__svelte__internal, cc = (o) => ({}), pl = (o) => ({}), _c = (o) => ({}), ml = (o) => ({});
function gl(o, e, t) {
  const n = o.slice();
  return n[40] = e[t], n[42] = t, n;
}
function vl(o, e, t) {
  const n = o.slice();
  return n[40] = e[t], n;
}
function dc(o) {
  let e, t, n, i, a = (
    /*i18n*/
    o[1]("common.error") + ""
  ), l, r, s;
  t = new Vn({
    props: {
      Icon: su,
      label: (
        /*i18n*/
        o[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    o[32]
  );
  const u = (
    /*#slots*/
    o[30].error
  ), c = Aa(
    u,
    o,
    /*$$scope*/
    o[29],
    pl
  );
  return {
    c() {
      e = et("div"), $a(t.$$.fragment), n = Be(), i = et("span"), l = ne(a), r = Be(), c && c.c(), this.h();
    },
    l(p) {
      e = Je(p, "DIV", { class: !0 });
      var d = Qe(e);
      Ea(t.$$.fragment, d), d.forEach(R), n = xe(p), i = Je(p, "SPAN", { class: !0 });
      var m = Qe(i);
      l = te(m, a), m.forEach(R), r = xe(p), c && c.l(p), this.h();
    },
    h() {
      Ue(e, "class", "clear-status svelte-17v219f"), Ue(i, "class", "error svelte-17v219f");
    },
    m(p, d) {
      L(p, e, d), Ba(t, e, null), L(p, n, d), L(p, i, d), yt(i, l), L(p, r, d), c && c.m(p, d), s = !0;
    },
    p(p, d) {
      const m = {};
      d[0] & /*i18n*/
      2 && (m.label = /*i18n*/
      p[1]("common.clear")), t.$set(m), (!s || d[0] & /*i18n*/
      2) && a !== (a = /*i18n*/
      p[1]("common.error") + "") && Ie(l, a), c && c.p && (!s || d[0] & /*$$scope*/
      536870912) && Ra(
        c,
        u,
        p,
        /*$$scope*/
        p[29],
        s ? xa(
          u,
          /*$$scope*/
          p[29],
          d,
          cc
        ) : Ta(
          /*$$scope*/
          p[29]
        ),
        pl
      );
    },
    i(p) {
      s || (ze(t.$$.fragment, p), ze(c, p), s = !0);
    },
    o(p) {
      tt(t.$$.fragment, p), tt(c, p), s = !1;
    },
    d(p) {
      p && (R(e), R(n), R(i), R(r)), Ca(t), c && c.d(p);
    }
  };
}
function fc(o) {
  let e, t, n, i, a, l, r, s, u, c = (
    /*variant*/
    o[8] === "default" && /*show_eta_bar*/
    o[18] && /*show_progress*/
    o[6] === "full" && Dl(o)
  );
  function p(_, v) {
    if (
      /*progress*/
      _[7]
    ) return mc;
    if (
      /*queue_position*/
      _[2] !== null && /*queue_size*/
      _[3] !== void 0 && /*queue_position*/
      _[2] >= 0
    ) return pc;
    if (
      /*queue_position*/
      _[2] === 0
    ) return hc;
  }
  let d = p(o), m = d && d(o), b = (
    /*timer*/
    o[5] && yl(o)
  );
  const D = [bc, Dc], g = [];
  function F(_, v) {
    return (
      /*last_progress_level*/
      _[15] != null ? 0 : (
        /*show_progress*/
        _[6] === "full" ? 1 : -1
      )
    );
  }
  ~(a = F(o)) && (l = g[a] = D[a](o));
  let h = !/*timer*/
  o[5] && Sl(o);
  return {
    c() {
      c && c.c(), e = Be(), t = et("div"), m && m.c(), n = Be(), b && b.c(), i = Be(), l && l.c(), r = Be(), h && h.c(), s = Re(), this.h();
    },
    l(_) {
      c && c.l(_), e = xe(_), t = Je(_, "DIV", { class: !0 });
      var v = Qe(t);
      m && m.l(v), n = xe(v), b && b.l(v), v.forEach(R), i = xe(_), l && l.l(_), r = xe(_), h && h.l(_), s = Re(), this.h();
    },
    h() {
      Ue(t, "class", "progress-text svelte-17v219f"), Te(
        t,
        "meta-text-center",
        /*variant*/
        o[8] === "center"
      ), Te(
        t,
        "meta-text",
        /*variant*/
        o[8] === "default"
      );
    },
    m(_, v) {
      c && c.m(_, v), L(_, e, v), L(_, t, v), m && m.m(t, null), yt(t, n), b && b.m(t, null), L(_, i, v), ~a && g[a].m(_, v), L(_, r, v), h && h.m(_, v), L(_, s, v), u = !0;
    },
    p(_, v) {
      /*variant*/
      _[8] === "default" && /*show_eta_bar*/
      _[18] && /*show_progress*/
      _[6] === "full" ? c ? c.p(_, v) : (c = Dl(_), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), d === (d = p(_)) && m ? m.p(_, v) : (m && m.d(1), m = d && d(_), m && (m.c(), m.m(t, n))), /*timer*/
      _[5] ? b ? b.p(_, v) : (b = yl(_), b.c(), b.m(t, null)) : b && (b.d(1), b = null), (!u || v[0] & /*variant*/
      256) && Te(
        t,
        "meta-text-center",
        /*variant*/
        _[8] === "center"
      ), (!u || v[0] & /*variant*/
      256) && Te(
        t,
        "meta-text",
        /*variant*/
        _[8] === "default"
      );
      let y = a;
      a = F(_), a === y ? ~a && g[a].p(_, v) : (l && (Vi(), tt(g[y], 1, 1, () => {
        g[y] = null;
      }), Gi()), ~a ? (l = g[a], l ? l.p(_, v) : (l = g[a] = D[a](_), l.c()), ze(l, 1), l.m(r.parentNode, r)) : l = null), /*timer*/
      _[5] ? h && (Vi(), tt(h, 1, 1, () => {
        h = null;
      }), Gi()) : h ? (h.p(_, v), v[0] & /*timer*/
      32 && ze(h, 1)) : (h = Sl(_), h.c(), ze(h, 1), h.m(s.parentNode, s));
    },
    i(_) {
      u || (ze(l), ze(h), u = !0);
    },
    o(_) {
      tt(l), tt(h), u = !1;
    },
    d(_) {
      _ && (R(e), R(t), R(i), R(r), R(s)), c && c.d(_), m && m.d(), b && b.d(), ~a && g[a].d(_), h && h.d(_);
    }
  };
}
function Dl(o) {
  let e, t = `translateX(${/*eta_level*/
  (o[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = et("div"), this.h();
    },
    l(n) {
      e = Je(n, "DIV", { class: !0 }), Qe(e).forEach(R), this.h();
    },
    h() {
      Ue(e, "class", "eta-bar svelte-17v219f"), vt(e, "transform", t);
    },
    m(n, i) {
      L(n, e, i);
    },
    p(n, i) {
      i[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && vt(e, "transform", t);
    },
    d(n) {
      n && R(e);
    }
  };
}
function hc(o) {
  let e;
  return {
    c() {
      e = ne("processing |");
    },
    l(t) {
      e = te(t, "processing |");
    },
    m(t, n) {
      L(t, e, n);
    },
    p: Wi,
    d(t) {
      t && R(e);
    }
  };
}
function pc(o) {
  let e, t = (
    /*queue_position*/
    o[2] + 1 + ""
  ), n, i, a, l;
  return {
    c() {
      e = ne("queue: "), n = ne(t), i = ne("/"), a = ne(
        /*queue_size*/
        o[3]
      ), l = ne(" |");
    },
    l(r) {
      e = te(r, "queue: "), n = te(r, t), i = te(r, "/"), a = te(
        r,
        /*queue_size*/
        o[3]
      ), l = te(r, " |");
    },
    m(r, s) {
      L(r, e, s), L(r, n, s), L(r, i, s), L(r, a, s), L(r, l, s);
    },
    p(r, s) {
      s[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      r[2] + 1 + "") && Ie(n, t), s[0] & /*queue_size*/
      8 && Ie(
        a,
        /*queue_size*/
        r[3]
      );
    },
    d(r) {
      r && (R(e), R(n), R(i), R(a), R(l));
    }
  };
}
function mc(o) {
  let e, t = Ln(
    /*progress*/
    o[7]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = wl(vl(o, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = Re();
    },
    l(i) {
      for (let a = 0; a < n.length; a += 1)
        n[a].l(i);
      e = Re();
    },
    m(i, a) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(i, a);
      L(i, e, a);
    },
    p(i, a) {
      if (a[0] & /*progress*/
      128) {
        t = Ln(
          /*progress*/
          i[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = vl(i, t, l);
          n[l] ? n[l].p(r, a) : (n[l] = wl(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && R(e), Sa(n, i);
    }
  };
}
function bl(o) {
  let e, t = (
    /*p*/
    o[40].unit + ""
  ), n, i, a = " ", l;
  function r(c, p) {
    return (
      /*p*/
      c[40].length != null ? vc : gc
    );
  }
  let s = r(o), u = s(o);
  return {
    c() {
      u.c(), e = Be(), n = ne(t), i = ne(" | "), l = ne(a);
    },
    l(c) {
      u.l(c), e = xe(c), n = te(c, t), i = te(c, " | "), l = te(c, a);
    },
    m(c, p) {
      u.m(c, p), L(c, e, p), L(c, n, p), L(c, i, p), L(c, l, p);
    },
    p(c, p) {
      s === (s = r(c)) && u ? u.p(c, p) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), p[0] & /*progress*/
      128 && t !== (t = /*p*/
      c[40].unit + "") && Ie(n, t);
    },
    d(c) {
      c && (R(e), R(n), R(i), R(l)), u.d(c);
    }
  };
}
function gc(o) {
  let e = Pt(
    /*p*/
    o[40].index || 0
  ) + "", t;
  return {
    c() {
      t = ne(e);
    },
    l(n) {
      t = te(n, e);
    },
    m(n, i) {
      L(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      128 && e !== (e = Pt(
        /*p*/
        n[40].index || 0
      ) + "") && Ie(t, e);
    },
    d(n) {
      n && R(t);
    }
  };
}
function vc(o) {
  let e = Pt(
    /*p*/
    o[40].index || 0
  ) + "", t, n, i = Pt(
    /*p*/
    o[40].length
  ) + "", a;
  return {
    c() {
      t = ne(e), n = ne("/"), a = ne(i);
    },
    l(l) {
      t = te(l, e), n = te(l, "/"), a = te(l, i);
    },
    m(l, r) {
      L(l, t, r), L(l, n, r), L(l, a, r);
    },
    p(l, r) {
      r[0] & /*progress*/
      128 && e !== (e = Pt(
        /*p*/
        l[40].index || 0
      ) + "") && Ie(t, e), r[0] & /*progress*/
      128 && i !== (i = Pt(
        /*p*/
        l[40].length
      ) + "") && Ie(a, i);
    },
    d(l) {
      l && (R(t), R(n), R(a));
    }
  };
}
function wl(o) {
  let e, t = (
    /*p*/
    o[40].index != null && bl(o)
  );
  return {
    c() {
      t && t.c(), e = Re();
    },
    l(n) {
      t && t.l(n), e = Re();
    },
    m(n, i) {
      t && t.m(n, i), L(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[40].index != null ? t ? t.p(n, i) : (t = bl(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && R(e), t && t.d(n);
    }
  };
}
function yl(o) {
  let e, t = (
    /*eta*/
    o[0] ? `/${/*formatted_eta*/
    o[19]}` : ""
  ), n, i;
  return {
    c() {
      e = ne(
        /*formatted_timer*/
        o[20]
      ), n = ne(t), i = ne("s");
    },
    l(a) {
      e = te(
        a,
        /*formatted_timer*/
        o[20]
      ), n = te(a, t), i = te(a, "s");
    },
    m(a, l) {
      L(a, e, l), L(a, n, l), L(a, i, l);
    },
    p(a, l) {
      l[0] & /*formatted_timer*/
      1048576 && Ie(
        e,
        /*formatted_timer*/
        a[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      a[0] ? `/${/*formatted_eta*/
      a[19]}` : "") && Ie(n, t);
    },
    d(a) {
      a && (R(e), R(n), R(i));
    }
  };
}
function Dc(o) {
  let e, t;
  return e = new ic({
    props: { margin: (
      /*variant*/
      o[8] === "default"
    ) }
  }), {
    c() {
      $a(e.$$.fragment);
    },
    l(n) {
      Ea(e.$$.fragment, n);
    },
    m(n, i) {
      Ba(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*variant*/
      256 && (a.margin = /*variant*/
      n[8] === "default"), e.$set(a);
    },
    i(n) {
      t || (ze(e.$$.fragment, n), t = !0);
    },
    o(n) {
      tt(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Ca(e, n);
    }
  };
}
function bc(o) {
  let e, t, n, i, a, l = `${/*last_progress_level*/
  o[15] * 100}%`, r = (
    /*progress*/
    o[7] != null && Fl(o)
  );
  return {
    c() {
      e = et("div"), t = et("div"), r && r.c(), n = Be(), i = et("div"), a = et("div"), this.h();
    },
    l(s) {
      e = Je(s, "DIV", { class: !0 });
      var u = Qe(e);
      t = Je(u, "DIV", { class: !0 });
      var c = Qe(t);
      r && r.l(c), c.forEach(R), n = xe(u), i = Je(u, "DIV", { class: !0 });
      var p = Qe(i);
      a = Je(p, "DIV", { class: !0 }), Qe(a).forEach(R), p.forEach(R), u.forEach(R), this.h();
    },
    h() {
      Ue(t, "class", "progress-level-inner svelte-17v219f"), Ue(a, "class", "progress-bar svelte-17v219f"), vt(a, "width", l), Ue(i, "class", "progress-bar-wrap svelte-17v219f"), Ue(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      L(s, e, u), yt(e, t), r && r.m(t, null), yt(e, n), yt(e, i), yt(i, a), o[31](a);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? r ? r.p(s, u) : (r = Fl(s), r.c(), r.m(t, null)) : r && (r.d(1), r = null), u[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      s[15] * 100}%`) && vt(a, "width", l);
    },
    i: Wi,
    o: Wi,
    d(s) {
      s && R(e), r && r.d(), o[31](null);
    }
  };
}
function Fl(o) {
  let e, t = Ln(
    /*progress*/
    o[7]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = Cl(gl(o, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = Re();
    },
    l(i) {
      for (let a = 0; a < n.length; a += 1)
        n[a].l(i);
      e = Re();
    },
    m(i, a) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(i, a);
      L(i, e, a);
    },
    p(i, a) {
      if (a[0] & /*progress_level, progress*/
      16512) {
        t = Ln(
          /*progress*/
          i[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = gl(i, t, l);
          n[l] ? n[l].p(r, a) : (n[l] = Cl(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && R(e), Sa(n, i);
    }
  };
}
function kl(o) {
  let e, t, n, i, a = (
    /*i*/
    o[42] !== 0 && wc()
  ), l = (
    /*p*/
    o[40].desc != null && El(o)
  ), r = (
    /*p*/
    o[40].desc != null && /*progress_level*/
    o[14] && /*progress_level*/
    o[14][
      /*i*/
      o[42]
    ] != null && $l()
  ), s = (
    /*progress_level*/
    o[14] != null && Al(o)
  );
  return {
    c() {
      a && a.c(), e = Be(), l && l.c(), t = Be(), r && r.c(), n = Be(), s && s.c(), i = Re();
    },
    l(u) {
      a && a.l(u), e = xe(u), l && l.l(u), t = xe(u), r && r.l(u), n = xe(u), s && s.l(u), i = Re();
    },
    m(u, c) {
      a && a.m(u, c), L(u, e, c), l && l.m(u, c), L(u, t, c), r && r.m(u, c), L(u, n, c), s && s.m(u, c), L(u, i, c);
    },
    p(u, c) {
      /*p*/
      u[40].desc != null ? l ? l.p(u, c) : (l = El(u), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? r || (r = $l(), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, c) : (s = Al(u), s.c(), s.m(i.parentNode, i)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (R(e), R(t), R(n), R(i)), a && a.d(u), l && l.d(u), r && r.d(u), s && s.d(u);
    }
  };
}
function wc(o) {
  let e;
  return {
    c() {
      e = ne(" /");
    },
    l(t) {
      e = te(t, " /");
    },
    m(t, n) {
      L(t, e, n);
    },
    d(t) {
      t && R(e);
    }
  };
}
function El(o) {
  let e = (
    /*p*/
    o[40].desc + ""
  ), t;
  return {
    c() {
      t = ne(e);
    },
    l(n) {
      t = te(n, e);
    },
    m(n, i) {
      L(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && Ie(t, e);
    },
    d(n) {
      n && R(t);
    }
  };
}
function $l(o) {
  let e;
  return {
    c() {
      e = ne("-");
    },
    l(t) {
      e = te(t, "-");
    },
    m(t, n) {
      L(t, e, n);
    },
    d(t) {
      t && R(e);
    }
  };
}
function Al(o) {
  let e = (100 * /*progress_level*/
  (o[14][
    /*i*/
    o[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = ne(e), n = ne("%");
    },
    l(i) {
      t = te(i, e), n = te(i, "%");
    },
    m(i, a) {
      L(i, t, a), L(i, n, a);
    },
    p(i, a) {
      a[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (i[14][
        /*i*/
        i[42]
      ] || 0)).toFixed(1) + "") && Ie(t, e);
    },
    d(i) {
      i && (R(t), R(n));
    }
  };
}
function Cl(o) {
  let e, t = (
    /*p*/
    (o[40].desc != null || /*progress_level*/
    o[14] && /*progress_level*/
    o[14][
      /*i*/
      o[42]
    ] != null) && kl(o)
  );
  return {
    c() {
      t && t.c(), e = Re();
    },
    l(n) {
      t && t.l(n), e = Re();
    },
    m(n, i) {
      t && t.m(n, i), L(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, i) : (t = kl(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && R(e), t && t.d(n);
    }
  };
}
function Sl(o) {
  let e, t, n, i;
  const a = (
    /*#slots*/
    o[30]["additional-loading-text"]
  ), l = Aa(
    a,
    o,
    /*$$scope*/
    o[29],
    ml
  );
  return {
    c() {
      e = et("p"), t = ne(
        /*loading_text*/
        o[9]
      ), n = Be(), l && l.c(), this.h();
    },
    l(r) {
      e = Je(r, "P", { class: !0 });
      var s = Qe(e);
      t = te(
        s,
        /*loading_text*/
        o[9]
      ), s.forEach(R), n = xe(r), l && l.l(r), this.h();
    },
    h() {
      Ue(e, "class", "loading svelte-17v219f");
    },
    m(r, s) {
      L(r, e, s), yt(e, t), L(r, n, s), l && l.m(r, s), i = !0;
    },
    p(r, s) {
      (!i || s[0] & /*loading_text*/
      512) && Ie(
        t,
        /*loading_text*/
        r[9]
      ), l && l.p && (!i || s[0] & /*$$scope*/
      536870912) && Ra(
        l,
        a,
        r,
        /*$$scope*/
        r[29],
        i ? xa(
          a,
          /*$$scope*/
          r[29],
          s,
          _c
        ) : Ta(
          /*$$scope*/
          r[29]
        ),
        ml
      );
    },
    i(r) {
      i || (ze(l, r), i = !0);
    },
    o(r) {
      tt(l, r), i = !1;
    },
    d(r) {
      r && (R(e), R(n)), l && l.d(r);
    }
  };
}
function yc(o) {
  let e, t, n, i, a;
  const l = [fc, dc], r = [];
  function s(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = s(o)) && (n = r[t] = l[t](o)), {
    c() {
      e = et("div"), n && n.c(), this.h();
    },
    l(u) {
      e = Je(u, "DIV", { class: !0 });
      var c = Qe(e);
      n && n.l(c), c.forEach(R), this.h();
    },
    h() {
      Ue(e, "class", i = "wrap " + /*variant*/
      o[8] + " " + /*show_progress*/
      o[6] + " svelte-17v219f"), Te(e, "hide", !/*status*/
      o[4] || /*status*/
      o[4] === "complete" || /*show_progress*/
      o[6] === "hidden" || /*status*/
      o[4] == "streaming"), Te(
        e,
        "translucent",
        /*variant*/
        o[8] === "center" && /*status*/
        (o[4] === "pending" || /*status*/
        o[4] === "error") || /*translucent*/
        o[11] || /*show_progress*/
        o[6] === "minimal"
      ), Te(
        e,
        "generating",
        /*status*/
        o[4] === "generating" && /*show_progress*/
        o[6] === "full"
      ), Te(
        e,
        "border",
        /*border*/
        o[12]
      ), vt(
        e,
        "position",
        /*absolute*/
        o[10] ? "absolute" : "static"
      ), vt(
        e,
        "padding",
        /*absolute*/
        o[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      L(u, e, c), ~t && r[t].m(e, null), o[33](e), a = !0;
    },
    p(u, c) {
      let p = t;
      t = s(u), t === p ? ~t && r[t].p(u, c) : (n && (Vi(), tt(r[p], 1, 1, () => {
        r[p] = null;
      }), Gi()), ~t ? (n = r[t], n ? n.p(u, c) : (n = r[t] = l[t](u), n.c()), ze(n, 1), n.m(e, null)) : n = null), (!a || c[0] & /*variant, show_progress*/
      320 && i !== (i = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Ue(e, "class", i), (!a || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Te(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!a || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && Te(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!a || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Te(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!a || c[0] & /*variant, show_progress, border*/
      4416) && Te(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && vt(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && vt(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      a || (ze(n), a = !0);
    },
    o(u) {
      tt(n), a = !1;
    },
    d(u) {
      u && R(e), ~t && r[t].d(), o[33](null);
    }
  };
}
var Fc = function(o, e, t, n) {
  function i(a) {
    return a instanceof t ? a : new t(function(l) {
      l(a);
    });
  }
  return new (t || (t = Promise))(function(a, l) {
    function r(c) {
      try {
        u(n.next(c));
      } catch (p) {
        l(p);
      }
    }
    function s(c) {
      try {
        u(n.throw(c));
      } catch (p) {
        l(p);
      }
    }
    function u(c) {
      c.done ? a(c.value) : i(c.value).then(r, s);
    }
    u((n = n.apply(o, e || [])).next());
  });
};
let kn = [], ki = !1;
const kc = typeof window < "u", Ia = kc ? window.requestAnimationFrame : (o) => {
};
function Ec(o) {
  return Fc(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (kn.push(e), !ki) ki = !0;
      else return;
      yield rc(), Ia(() => {
        let n = [0, 0];
        for (let i = 0; i < kn.length; i++) {
          const l = kn[i].getBoundingClientRect();
          (i === 0 || l.top + window.scrollY <= n[0]) && (n[0] = l.top + window.scrollY, n[1] = i);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), ki = !1, kn = [];
      });
    }
  });
}
function $c(o, e, t) {
  let n, { $$slots: i = {}, $$scope: a } = e;
  const l = uc();
  let { i18n: r } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: p } = e, { scroll_to_output: d = !1 } = e, { timer: m = !0 } = e, { show_progress: b = "full" } = e, { message: D = null } = e, { progress: g = null } = e, { variant: F = "default" } = e, { loading_text: h = "Loading..." } = e, { absolute: _ = !0 } = e, { translucent: v = !1 } = e, { border: y = !1 } = e, { autoscroll: w } = e, A, T = !1, S = 0, E = 0, I = null, O = null, ie = 0, X = null, M, q = null, z = !0;
  const H = () => {
    t(0, s = t(27, I = t(19, k = null))), t(25, S = performance.now()), t(26, E = 0), T = !0, K();
  };
  function K() {
    Ia(() => {
      t(26, E = (performance.now() - S) / 1e3), T && K();
    });
  }
  function j() {
    t(26, E = 0), t(0, s = t(27, I = t(19, k = null))), T && (T = !1);
  }
  sc(() => {
    T && j();
  });
  let k = null;
  function Q(C) {
    hl[C ? "unshift" : "push"](() => {
      q = C, t(16, q), t(7, g), t(14, X), t(15, M);
    });
  }
  const V = () => {
    l("clear_status");
  };
  function le(C) {
    hl[C ? "unshift" : "push"](() => {
      A = C, t(13, A);
    });
  }
  return o.$$set = (C) => {
    "i18n" in C && t(1, r = C.i18n), "eta" in C && t(0, s = C.eta), "queue_position" in C && t(2, u = C.queue_position), "queue_size" in C && t(3, c = C.queue_size), "status" in C && t(4, p = C.status), "scroll_to_output" in C && t(22, d = C.scroll_to_output), "timer" in C && t(5, m = C.timer), "show_progress" in C && t(6, b = C.show_progress), "message" in C && t(23, D = C.message), "progress" in C && t(7, g = C.progress), "variant" in C && t(8, F = C.variant), "loading_text" in C && t(9, h = C.loading_text), "absolute" in C && t(10, _ = C.absolute), "translucent" in C && t(11, v = C.translucent), "border" in C && t(12, y = C.border), "autoscroll" in C && t(24, w = C.autoscroll), "$$scope" in C && t(29, a = C.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && t(0, s = I), s != null && I !== s && (t(28, O = (performance.now() - S) / 1e3 + s), t(19, k = O.toFixed(1)), t(27, I = s))), o.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, ie = O === null || O <= 0 || !E ? null : Math.min(E / O, 1)), o.$$.dirty[0] & /*progress*/
    128 && g != null && t(18, z = !1), o.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (g != null ? t(14, X = g.map((C) => {
      if (C.index != null && C.length != null)
        return C.index / C.length;
      if (C.progress != null)
        return C.progress;
    })) : t(14, X = null), X ? (t(15, M = X[X.length - 1]), q && (M === 0 ? t(16, q.style.transition = "0", q) : t(16, q.style.transition = "150ms", q))) : t(15, M = void 0)), o.$$.dirty[0] & /*status*/
    16 && (p === "pending" ? H() : j()), o.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && A && d && (p === "pending" || p === "complete") && Ec(A, w), o.$$.dirty[0] & /*status, message*/
    8388624, o.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = E.toFixed(1));
  }, [
    s,
    r,
    u,
    c,
    p,
    m,
    b,
    g,
    F,
    h,
    _,
    v,
    y,
    A,
    X,
    M,
    q,
    ie,
    z,
    k,
    n,
    l,
    d,
    D,
    w,
    S,
    E,
    I,
    O,
    a,
    i,
    Q,
    V,
    le
  ];
}
class Ac extends oc {
  constructor(e) {
    super(), lc(
      this,
      e,
      $c,
      yc,
      ac,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: La,
  setPrototypeOf: Tl,
  isFrozen: Cc,
  getPrototypeOf: Sc,
  getOwnPropertyDescriptor: Tc
} = Object;
let {
  freeze: ve,
  seal: Le,
  create: qa
} = Object, {
  apply: Zi,
  construct: Yi
} = typeof Reflect < "u" && Reflect;
ve || (ve = function(e) {
  return e;
});
Le || (Le = function(e) {
  return e;
});
Zi || (Zi = function(e, t, n) {
  return e.apply(t, n);
});
Yi || (Yi = function(e, t) {
  return new e(...t);
});
const En = De(Array.prototype.forEach), xc = De(Array.prototype.lastIndexOf), xl = De(Array.prototype.pop), Yt = De(Array.prototype.push), Bc = De(Array.prototype.splice), xn = De(String.prototype.toLowerCase), Ei = De(String.prototype.toString), Bl = De(String.prototype.match), Xt = De(String.prototype.replace), Rc = De(String.prototype.indexOf), Ic = De(String.prototype.trim), Pe = De(Object.prototype.hasOwnProperty), ge = De(RegExp.prototype.test), Kt = Lc(TypeError);
function De(o) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
      n[i - 1] = arguments[i];
    return Zi(o, e, n);
  };
}
function Lc(o) {
  return function() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
      t[n] = arguments[n];
    return Yi(o, t);
  };
}
function N(o, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : xn;
  Tl && Tl(o, null);
  let n = e.length;
  for (; n--; ) {
    let i = e[n];
    if (typeof i == "string") {
      const a = t(i);
      a !== i && (Cc(e) || (e[n] = a), i = a);
    }
    o[i] = !0;
  }
  return o;
}
function qc(o) {
  for (let e = 0; e < o.length; e++)
    Pe(o, e) || (o[e] = null);
  return o;
}
function rt(o) {
  const e = qa(null);
  for (const [t, n] of La(o))
    Pe(o, t) && (Array.isArray(n) ? e[t] = qc(n) : n && typeof n == "object" && n.constructor === Object ? e[t] = rt(n) : e[t] = n);
  return e;
}
function Qt(o, e) {
  for (; o !== null; ) {
    const n = Tc(o, e);
    if (n) {
      if (n.get)
        return De(n.get);
      if (typeof n.value == "function")
        return De(n.value);
    }
    o = Sc(o);
  }
  function t() {
    return null;
  }
  return t;
}
const Rl = ve(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), $i = ve(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Ai = ve(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), Oc = ve(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Ci = ve(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), Nc = ve(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Il = ve(["#text"]), Ll = ve(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), Si = ve(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), ql = ve(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), $n = ve(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), Mc = Le(/\{\{[\w\W]*|[\w\W]*\}\}/gm), Pc = Le(/<%[\w\W]*|[\w\W]*%>/gm), zc = Le(/\$\{[\w\W]*/gm), Uc = Le(/^data-[\-\w.\u00B7-\uFFFF]+$/), Hc = Le(/^aria-[\-\w]+$/), Oa = Le(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), jc = Le(/^(?:\w+script|data):/i), Gc = Le(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Na = Le(/^html$/i), Vc = Le(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Ol = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: Hc,
  ATTR_WHITESPACE: Gc,
  CUSTOM_ELEMENT: Vc,
  DATA_ATTR: Uc,
  DOCTYPE_NAME: Na,
  ERB_EXPR: Pc,
  IS_ALLOWED_URI: Oa,
  IS_SCRIPT_OR_DATA: jc,
  MUSTACHE_EXPR: Mc,
  TMPLIT_EXPR: zc
});
const Jt = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, Wc = function() {
  return typeof window > "u" ? null : window;
}, Zc = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let n = null;
  const i = "data-tt-policy-suffix";
  t && t.hasAttribute(i) && (n = t.getAttribute(i));
  const a = "dompurify" + (n ? "#" + n : "");
  try {
    return e.createPolicy(a, {
      createHTML(l) {
        return l;
      },
      createScriptURL(l) {
        return l;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + a + " could not be created."), null;
  }
}, Nl = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Ma() {
  let o = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Wc();
  const e = (B) => Ma(B);
  if (e.version = "3.2.6", e.removed = [], !o || !o.document || o.document.nodeType !== Jt.document || !o.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = o;
  const n = t, i = n.currentScript, {
    DocumentFragment: a,
    HTMLTemplateElement: l,
    Node: r,
    Element: s,
    NodeFilter: u,
    NamedNodeMap: c = o.NamedNodeMap || o.MozNamedAttrMap,
    HTMLFormElement: p,
    DOMParser: d,
    trustedTypes: m
  } = o, b = s.prototype, D = Qt(b, "cloneNode"), g = Qt(b, "remove"), F = Qt(b, "nextSibling"), h = Qt(b, "childNodes"), _ = Qt(b, "parentNode");
  if (typeof l == "function") {
    const B = t.createElement("template");
    B.content && B.content.ownerDocument && (t = B.content.ownerDocument);
  }
  let v, y = "";
  const {
    implementation: w,
    createNodeIterator: A,
    createDocumentFragment: T,
    getElementsByTagName: S
  } = t, {
    importNode: E
  } = n;
  let I = Nl();
  e.isSupported = typeof La == "function" && typeof _ == "function" && w && w.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: O,
    ERB_EXPR: ie,
    TMPLIT_EXPR: X,
    DATA_ATTR: M,
    ARIA_ATTR: q,
    IS_SCRIPT_OR_DATA: z,
    ATTR_WHITESPACE: H,
    CUSTOM_ELEMENT: K
  } = Ol;
  let {
    IS_ALLOWED_URI: j
  } = Ol, k = null;
  const Q = N({}, [...Rl, ...$i, ...Ai, ...Ci, ...Il]);
  let V = null;
  const le = N({}, [...Ll, ...Si, ...ql, ...$n]);
  let C = Object.seal(qa(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), Ae = null, st = null, Ct = !0, St = !0, Tt = !1, Dt = !0, ut = !1, ct = !0, bt = !1, Qn = !1, Jn = !1, xt = !1, un = !1, cn = !1, so = !0, uo = !1;
  const er = "user-content-";
  let ei = !0, jt = !1, Bt = {}, Rt = null;
  const co = N({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let _o = null;
  const fo = N({}, ["audio", "video", "img", "source", "image", "track"]);
  let ti = null;
  const ho = N({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), _n = "http://www.w3.org/1998/Math/MathML", dn = "http://www.w3.org/2000/svg", nt = "http://www.w3.org/1999/xhtml";
  let It = nt, ni = !1, ii = null;
  const tr = N({}, [_n, dn, nt], Ei);
  let fn = N({}, ["mi", "mo", "mn", "ms", "mtext"]), hn = N({}, ["annotation-xml"]);
  const nr = N({}, ["title", "style", "font", "a", "script"]);
  let Gt = null;
  const ir = ["application/xhtml+xml", "text/html"], or = "text/html";
  let re = null, Lt = null;
  const lr = t.createElement("form"), po = function(f) {
    return f instanceof RegExp || f instanceof Function;
  }, oi = function() {
    let f = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Lt && Lt === f)) {
      if ((!f || typeof f != "object") && (f = {}), f = rt(f), Gt = // eslint-disable-next-line unicorn/prefer-includes
      ir.indexOf(f.PARSER_MEDIA_TYPE) === -1 ? or : f.PARSER_MEDIA_TYPE, re = Gt === "application/xhtml+xml" ? Ei : xn, k = Pe(f, "ALLOWED_TAGS") ? N({}, f.ALLOWED_TAGS, re) : Q, V = Pe(f, "ALLOWED_ATTR") ? N({}, f.ALLOWED_ATTR, re) : le, ii = Pe(f, "ALLOWED_NAMESPACES") ? N({}, f.ALLOWED_NAMESPACES, Ei) : tr, ti = Pe(f, "ADD_URI_SAFE_ATTR") ? N(rt(ho), f.ADD_URI_SAFE_ATTR, re) : ho, _o = Pe(f, "ADD_DATA_URI_TAGS") ? N(rt(fo), f.ADD_DATA_URI_TAGS, re) : fo, Rt = Pe(f, "FORBID_CONTENTS") ? N({}, f.FORBID_CONTENTS, re) : co, Ae = Pe(f, "FORBID_TAGS") ? N({}, f.FORBID_TAGS, re) : rt({}), st = Pe(f, "FORBID_ATTR") ? N({}, f.FORBID_ATTR, re) : rt({}), Bt = Pe(f, "USE_PROFILES") ? f.USE_PROFILES : !1, Ct = f.ALLOW_ARIA_ATTR !== !1, St = f.ALLOW_DATA_ATTR !== !1, Tt = f.ALLOW_UNKNOWN_PROTOCOLS || !1, Dt = f.ALLOW_SELF_CLOSE_IN_ATTR !== !1, ut = f.SAFE_FOR_TEMPLATES || !1, ct = f.SAFE_FOR_XML !== !1, bt = f.WHOLE_DOCUMENT || !1, xt = f.RETURN_DOM || !1, un = f.RETURN_DOM_FRAGMENT || !1, cn = f.RETURN_TRUSTED_TYPE || !1, Jn = f.FORCE_BODY || !1, so = f.SANITIZE_DOM !== !1, uo = f.SANITIZE_NAMED_PROPS || !1, ei = f.KEEP_CONTENT !== !1, jt = f.IN_PLACE || !1, j = f.ALLOWED_URI_REGEXP || Oa, It = f.NAMESPACE || nt, fn = f.MATHML_TEXT_INTEGRATION_POINTS || fn, hn = f.HTML_INTEGRATION_POINTS || hn, C = f.CUSTOM_ELEMENT_HANDLING || {}, f.CUSTOM_ELEMENT_HANDLING && po(f.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (C.tagNameCheck = f.CUSTOM_ELEMENT_HANDLING.tagNameCheck), f.CUSTOM_ELEMENT_HANDLING && po(f.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (C.attributeNameCheck = f.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), f.CUSTOM_ELEMENT_HANDLING && typeof f.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (C.allowCustomizedBuiltInElements = f.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), ut && (St = !1), un && (xt = !0), Bt && (k = N({}, Il), V = [], Bt.html === !0 && (N(k, Rl), N(V, Ll)), Bt.svg === !0 && (N(k, $i), N(V, Si), N(V, $n)), Bt.svgFilters === !0 && (N(k, Ai), N(V, Si), N(V, $n)), Bt.mathMl === !0 && (N(k, Ci), N(V, ql), N(V, $n))), f.ADD_TAGS && (k === Q && (k = rt(k)), N(k, f.ADD_TAGS, re)), f.ADD_ATTR && (V === le && (V = rt(V)), N(V, f.ADD_ATTR, re)), f.ADD_URI_SAFE_ATTR && N(ti, f.ADD_URI_SAFE_ATTR, re), f.FORBID_CONTENTS && (Rt === co && (Rt = rt(Rt)), N(Rt, f.FORBID_CONTENTS, re)), ei && (k["#text"] = !0), bt && N(k, ["html", "head", "body"]), k.table && (N(k, ["tbody"]), delete Ae.tbody), f.TRUSTED_TYPES_POLICY) {
        if (typeof f.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw Kt('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof f.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw Kt('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        v = f.TRUSTED_TYPES_POLICY, y = v.createHTML("");
      } else
        v === void 0 && (v = Zc(m, i)), v !== null && typeof y == "string" && (y = v.createHTML(""));
      ve && ve(f), Lt = f;
    }
  }, mo = N({}, [...$i, ...Ai, ...Oc]), go = N({}, [...Ci, ...Nc]), ar = function(f) {
    let $ = _(f);
    (!$ || !$.tagName) && ($ = {
      namespaceURI: It,
      tagName: "template"
    });
    const x = xn(f.tagName), J = xn($.tagName);
    return ii[f.namespaceURI] ? f.namespaceURI === dn ? $.namespaceURI === nt ? x === "svg" : $.namespaceURI === _n ? x === "svg" && (J === "annotation-xml" || fn[J]) : !!mo[x] : f.namespaceURI === _n ? $.namespaceURI === nt ? x === "math" : $.namespaceURI === dn ? x === "math" && hn[J] : !!go[x] : f.namespaceURI === nt ? $.namespaceURI === dn && !hn[J] || $.namespaceURI === _n && !fn[J] ? !1 : !go[x] && (nr[x] || !mo[x]) : !!(Gt === "application/xhtml+xml" && ii[f.namespaceURI]) : !1;
  }, He = function(f) {
    Yt(e.removed, {
      element: f
    });
    try {
      _(f).removeChild(f);
    } catch {
      g(f);
    }
  }, qt = function(f, $) {
    try {
      Yt(e.removed, {
        attribute: $.getAttributeNode(f),
        from: $
      });
    } catch {
      Yt(e.removed, {
        attribute: null,
        from: $
      });
    }
    if ($.removeAttribute(f), f === "is")
      if (xt || un)
        try {
          He($);
        } catch {
        }
      else
        try {
          $.setAttribute(f, "");
        } catch {
        }
  }, vo = function(f) {
    let $ = null, x = null;
    if (Jn)
      f = "<remove></remove>" + f;
    else {
      const ae = Bl(f, /^[\r\n\t ]+/);
      x = ae && ae[0];
    }
    Gt === "application/xhtml+xml" && It === nt && (f = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + f + "</body></html>");
    const J = v ? v.createHTML(f) : f;
    if (It === nt)
      try {
        $ = new d().parseFromString(J, Gt);
      } catch {
      }
    if (!$ || !$.documentElement) {
      $ = w.createDocument(It, "template", null);
      try {
        $.documentElement.innerHTML = ni ? y : J;
      } catch {
      }
    }
    const de = $.body || $.documentElement;
    return f && x && de.insertBefore(t.createTextNode(x), de.childNodes[0] || null), It === nt ? S.call($, bt ? "html" : "body")[0] : bt ? $.documentElement : de;
  }, Do = function(f) {
    return A.call(
      f.ownerDocument || f,
      f,
      // eslint-disable-next-line no-bitwise
      u.SHOW_ELEMENT | u.SHOW_COMMENT | u.SHOW_TEXT | u.SHOW_PROCESSING_INSTRUCTION | u.SHOW_CDATA_SECTION,
      null
    );
  }, li = function(f) {
    return f instanceof p && (typeof f.nodeName != "string" || typeof f.textContent != "string" || typeof f.removeChild != "function" || !(f.attributes instanceof c) || typeof f.removeAttribute != "function" || typeof f.setAttribute != "function" || typeof f.namespaceURI != "string" || typeof f.insertBefore != "function" || typeof f.hasChildNodes != "function");
  }, bo = function(f) {
    return typeof r == "function" && f instanceof r;
  };
  function it(B, f, $) {
    En(B, (x) => {
      x.call(e, f, $, Lt);
    });
  }
  const wo = function(f) {
    let $ = null;
    if (it(I.beforeSanitizeElements, f, null), li(f))
      return He(f), !0;
    const x = re(f.nodeName);
    if (it(I.uponSanitizeElement, f, {
      tagName: x,
      allowedTags: k
    }), ct && f.hasChildNodes() && !bo(f.firstElementChild) && ge(/<[/\w!]/g, f.innerHTML) && ge(/<[/\w!]/g, f.textContent) || f.nodeType === Jt.progressingInstruction || ct && f.nodeType === Jt.comment && ge(/<[/\w]/g, f.data))
      return He(f), !0;
    if (!k[x] || Ae[x]) {
      if (!Ae[x] && Fo(x) && (C.tagNameCheck instanceof RegExp && ge(C.tagNameCheck, x) || C.tagNameCheck instanceof Function && C.tagNameCheck(x)))
        return !1;
      if (ei && !Rt[x]) {
        const J = _(f) || f.parentNode, de = h(f) || f.childNodes;
        if (de && J) {
          const ae = de.length;
          for (let be = ae - 1; be >= 0; --be) {
            const ot = D(de[be], !0);
            ot.__removalCount = (f.__removalCount || 0) + 1, J.insertBefore(ot, F(f));
          }
        }
      }
      return He(f), !0;
    }
    return f instanceof s && !ar(f) || (x === "noscript" || x === "noembed" || x === "noframes") && ge(/<\/no(script|embed|frames)/i, f.innerHTML) ? (He(f), !0) : (ut && f.nodeType === Jt.text && ($ = f.textContent, En([O, ie, X], (J) => {
      $ = Xt($, J, " ");
    }), f.textContent !== $ && (Yt(e.removed, {
      element: f.cloneNode()
    }), f.textContent = $)), it(I.afterSanitizeElements, f, null), !1);
  }, yo = function(f, $, x) {
    if (so && ($ === "id" || $ === "name") && (x in t || x in lr))
      return !1;
    if (!(St && !st[$] && ge(M, $))) {
      if (!(Ct && ge(q, $))) {
        if (!V[$] || st[$]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(Fo(f) && (C.tagNameCheck instanceof RegExp && ge(C.tagNameCheck, f) || C.tagNameCheck instanceof Function && C.tagNameCheck(f)) && (C.attributeNameCheck instanceof RegExp && ge(C.attributeNameCheck, $) || C.attributeNameCheck instanceof Function && C.attributeNameCheck($)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            $ === "is" && C.allowCustomizedBuiltInElements && (C.tagNameCheck instanceof RegExp && ge(C.tagNameCheck, x) || C.tagNameCheck instanceof Function && C.tagNameCheck(x)))
          ) return !1;
        } else if (!ti[$]) {
          if (!ge(j, Xt(x, H, ""))) {
            if (!(($ === "src" || $ === "xlink:href" || $ === "href") && f !== "script" && Rc(x, "data:") === 0 && _o[f])) {
              if (!(Tt && !ge(z, Xt(x, H, "")))) {
                if (x)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, Fo = function(f) {
    return f !== "annotation-xml" && Bl(f, K);
  }, ko = function(f) {
    it(I.beforeSanitizeAttributes, f, null);
    const {
      attributes: $
    } = f;
    if (!$ || li(f))
      return;
    const x = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: V,
      forceKeepAttr: void 0
    };
    let J = $.length;
    for (; J--; ) {
      const de = $[J], {
        name: ae,
        namespaceURI: be,
        value: ot
      } = de, Vt = re(ae), ai = ot;
      let fe = ae === "value" ? ai : Ic(ai);
      if (x.attrName = Vt, x.attrValue = fe, x.keepAttr = !0, x.forceKeepAttr = void 0, it(I.uponSanitizeAttribute, f, x), fe = x.attrValue, uo && (Vt === "id" || Vt === "name") && (qt(ae, f), fe = er + fe), ct && ge(/((--!?|])>)|<\/(style|title)/i, fe)) {
        qt(ae, f);
        continue;
      }
      if (x.forceKeepAttr)
        continue;
      if (!x.keepAttr) {
        qt(ae, f);
        continue;
      }
      if (!Dt && ge(/\/>/i, fe)) {
        qt(ae, f);
        continue;
      }
      ut && En([O, ie, X], ($o) => {
        fe = Xt(fe, $o, " ");
      });
      const Eo = re(f.nodeName);
      if (!yo(Eo, Vt, fe)) {
        qt(ae, f);
        continue;
      }
      if (v && typeof m == "object" && typeof m.getAttributeType == "function" && !be)
        switch (m.getAttributeType(Eo, Vt)) {
          case "TrustedHTML": {
            fe = v.createHTML(fe);
            break;
          }
          case "TrustedScriptURL": {
            fe = v.createScriptURL(fe);
            break;
          }
        }
      if (fe !== ai)
        try {
          be ? f.setAttributeNS(be, ae, fe) : f.setAttribute(ae, fe), li(f) ? He(f) : xl(e.removed);
        } catch {
          qt(ae, f);
        }
    }
    it(I.afterSanitizeAttributes, f, null);
  }, rr = function B(f) {
    let $ = null;
    const x = Do(f);
    for (it(I.beforeSanitizeShadowDOM, f, null); $ = x.nextNode(); )
      it(I.uponSanitizeShadowNode, $, null), wo($), ko($), $.content instanceof a && B($.content);
    it(I.afterSanitizeShadowDOM, f, null);
  };
  return e.sanitize = function(B) {
    let f = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, $ = null, x = null, J = null, de = null;
    if (ni = !B, ni && (B = "<!-->"), typeof B != "string" && !bo(B))
      if (typeof B.toString == "function") {
        if (B = B.toString(), typeof B != "string")
          throw Kt("dirty is not a string, aborting");
      } else
        throw Kt("toString is not a function");
    if (!e.isSupported)
      return B;
    if (Qn || oi(f), e.removed = [], typeof B == "string" && (jt = !1), jt) {
      if (B.nodeName) {
        const ot = re(B.nodeName);
        if (!k[ot] || Ae[ot])
          throw Kt("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (B instanceof r)
      $ = vo("<!---->"), x = $.ownerDocument.importNode(B, !0), x.nodeType === Jt.element && x.nodeName === "BODY" || x.nodeName === "HTML" ? $ = x : $.appendChild(x);
    else {
      if (!xt && !ut && !bt && // eslint-disable-next-line unicorn/prefer-includes
      B.indexOf("<") === -1)
        return v && cn ? v.createHTML(B) : B;
      if ($ = vo(B), !$)
        return xt ? null : cn ? y : "";
    }
    $ && Jn && He($.firstChild);
    const ae = Do(jt ? B : $);
    for (; J = ae.nextNode(); )
      wo(J), ko(J), J.content instanceof a && rr(J.content);
    if (jt)
      return B;
    if (xt) {
      if (un)
        for (de = T.call($.ownerDocument); $.firstChild; )
          de.appendChild($.firstChild);
      else
        de = $;
      return (V.shadowroot || V.shadowrootmode) && (de = E.call(n, de, !0)), de;
    }
    let be = bt ? $.outerHTML : $.innerHTML;
    return bt && k["!doctype"] && $.ownerDocument && $.ownerDocument.doctype && $.ownerDocument.doctype.name && ge(Na, $.ownerDocument.doctype.name) && (be = "<!DOCTYPE " + $.ownerDocument.doctype.name + `>
` + be), ut && En([O, ie, X], (ot) => {
      be = Xt(be, ot, " ");
    }), v && cn ? v.createHTML(be) : be;
  }, e.setConfig = function() {
    let B = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    oi(B), Qn = !0;
  }, e.clearConfig = function() {
    Lt = null, Qn = !1;
  }, e.isValidAttribute = function(B, f, $) {
    Lt || oi({});
    const x = re(B), J = re(f);
    return yo(x, J, $);
  }, e.addHook = function(B, f) {
    typeof f == "function" && Yt(I[B], f);
  }, e.removeHook = function(B, f) {
    if (f !== void 0) {
      const $ = xc(I[B], f);
      return $ === -1 ? void 0 : Bc(I[B], $, 1)[0];
    }
    return xl(I[B]);
  }, e.removeHooks = function(B) {
    I[B] = [];
  }, e.removeAllHooks = function() {
    I = Nl();
  }, e;
}
Ma();
const {
  HtmlTagHydration: hA,
  SvelteComponent: pA,
  add_render_callback: mA,
  append_hydration: gA,
  attr: vA,
  bubble: DA,
  check_outros: bA,
  children: wA,
  claim_component: yA,
  claim_element: FA,
  claim_html_tag: kA,
  claim_space: EA,
  claim_text: $A,
  create_component: AA,
  create_in_transition: CA,
  create_out_transition: SA,
  destroy_component: TA,
  detach: xA,
  element: BA,
  get_svelte_dataset: RA,
  group_outros: IA,
  init: LA,
  insert_hydration: qA,
  listen: OA,
  mount_component: NA,
  run_all: MA,
  safe_not_equal: PA,
  set_data: zA,
  space: UA,
  stop_propagation: HA,
  text: jA,
  toggle_class: GA,
  transition_in: VA,
  transition_out: WA
} = window.__gradio__svelte__internal, { createEventDispatcher: ZA, onMount: YA } = window.__gradio__svelte__internal, {
  SvelteComponent: XA,
  append_hydration: KA,
  attr: QA,
  bubble: JA,
  check_outros: eC,
  children: tC,
  claim_component: nC,
  claim_element: iC,
  claim_space: oC,
  create_animation: lC,
  create_component: aC,
  destroy_component: rC,
  detach: sC,
  element: uC,
  ensure_array_like: cC,
  fix_and_outro_and_destroy_block: _C,
  fix_position: dC,
  group_outros: fC,
  init: hC,
  insert_hydration: pC,
  mount_component: mC,
  noop: gC,
  safe_not_equal: vC,
  set_style: DC,
  space: bC,
  transition_in: wC,
  transition_out: yC,
  update_keyed_each: FC
} = window.__gradio__svelte__internal, {
  SvelteComponent: kC,
  attr: EC,
  children: $C,
  claim_element: AC,
  detach: CC,
  element: SC,
  empty: TC,
  init: xC,
  insert_hydration: BC,
  noop: RC,
  safe_not_equal: IC,
  set_style: LC
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yc,
  append_hydration: Ml,
  attr: ye,
  children: Ti,
  claim_svg_element: xi,
  detach: An,
  init: Xc,
  insert_hydration: Kc,
  noop: Bi,
  safe_not_equal: Qc,
  svg_element: Ri
} = window.__gradio__svelte__internal;
function Jc(o) {
  let e, t, n;
  return {
    c() {
      e = Ri("svg"), t = Ri("polyline"), n = Ri("line"), this.h();
    },
    l(i) {
      e = xi(i, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      });
      var a = Ti(e);
      t = xi(a, "polyline", { points: !0 }), Ti(t).forEach(An), n = xi(a, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), Ti(n).forEach(An), a.forEach(An), this.h();
    },
    h() {
      ye(t, "points", "4 17 10 11 4 5"), ye(n, "x1", "12"), ye(n, "y1", "19"), ye(n, "x2", "20"), ye(n, "y2", "19"), ye(e, "width", "100%"), ye(e, "height", "100%"), ye(e, "viewBox", "0 0 24 24"), ye(e, "fill", "none"), ye(e, "stroke", "currentColor"), ye(e, "stroke-width", "2"), ye(e, "stroke-linecap", "round"), ye(e, "stroke-linejoin", "round");
    },
    m(i, a) {
      Kc(i, e, a), Ml(e, t), Ml(e, n);
    },
    p: Bi,
    i: Bi,
    o: Bi,
    d(i) {
      i && An(e);
    }
  };
}
class e_ extends Yc {
  constructor(e) {
    super(), Xc(this, e, null, Jc, Qc, {});
  }
}
const {
  SvelteComponent: t_,
  claim_component: n_,
  create_component: i_,
  destroy_component: o_,
  init: l_,
  mount_component: a_,
  safe_not_equal: r_,
  transition_in: s_,
  transition_out: u_
} = window.__gradio__svelte__internal, { onDestroy: c_ } = window.__gradio__svelte__internal;
function __(o) {
  let e, t;
  return e = new Vn({
    props: { Icon: (
      /*copied*/
      o[0] ? Qo : el
    ) }
  }), e.$on(
    "click",
    /*handle_copy*/
    o[1]
  ), {
    c() {
      i_(e.$$.fragment);
    },
    l(n) {
      n_(e.$$.fragment, n);
    },
    m(n, i) {
      a_(e, n, i), t = !0;
    },
    p(n, [i]) {
      const a = {};
      i & /*copied*/
      1 && (a.Icon = /*copied*/
      n[0] ? Qo : el), e.$set(a);
    },
    i(n) {
      t || (s_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      u_(e.$$.fragment, n), t = !1;
    },
    d(n) {
      o_(e, n);
    }
  };
}
function d_(o, e, t) {
  var n = this && this.__awaiter || function(u, c, p, d) {
    function m(b) {
      return b instanceof p ? b : new p(function(D) {
        D(b);
      });
    }
    return new (p || (p = Promise))(function(b, D) {
      function g(_) {
        try {
          h(d.next(_));
        } catch (v) {
          D(v);
        }
      }
      function F(_) {
        try {
          h(d.throw(_));
        } catch (v) {
          D(v);
        }
      }
      function h(_) {
        _.done ? b(_.value) : m(_.value).then(g, F);
      }
      h((d = d.apply(u, c || [])).next());
    });
  };
  let i = !1, { value: a } = e, l;
  function r() {
    t(0, i = !0), l && clearTimeout(l), l = setTimeout(
      () => {
        t(0, i = !1);
      },
      2e3
    );
  }
  function s() {
    return n(this, void 0, void 0, function* () {
      "clipboard" in navigator && (yield navigator.clipboard.writeText(a), r());
    });
  }
  return c_(() => {
    l && clearTimeout(l);
  }), o.$$set = (u) => {
    "value" in u && t(2, a = u.value);
  }, [i, s, a];
}
class f_ extends t_ {
  constructor(e) {
    super(), l_(this, e, d_, __, r_, { value: 2 });
  }
}
const { setContext: qC, getContext: h_ } = window.__gradio__svelte__internal, p_ = "WORKER_PROXY_CONTEXT_KEY";
function m_() {
  return h_(p_);
}
const g_ = "lite.local";
function v_(o) {
  return o.host === window.location.host || o.host === "localhost:7860" || o.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  o.host === g_;
}
function D_(o, e) {
  const t = e.toLowerCase();
  for (const [n, i] of Object.entries(o))
    if (n.toLowerCase() === t)
      return i;
}
function b_(o) {
  const e = typeof window < "u";
  if (o == null || !e)
    return !1;
  const t = new URL(o, window.location.href);
  return !(!v_(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
const {
  SvelteComponent: w_,
  assign: qn,
  check_outros: Pa,
  children: za,
  claim_element: Ua,
  compute_rest_props: Pl,
  create_slot: oo,
  detach: Ht,
  element: Ha,
  empty: On,
  exclude_internal_props: y_,
  get_all_dirty_from_scope: lo,
  get_slot_changes: ao,
  get_spread_update: ja,
  group_outros: Ga,
  init: F_,
  insert_hydration: Wn,
  listen: Va,
  prevent_default: k_,
  safe_not_equal: E_,
  set_attributes: Nn,
  set_style: zl,
  toggle_class: Mn,
  transition_in: kt,
  transition_out: Et,
  update_slot_base: ro
} = window.__gradio__svelte__internal, { createEventDispatcher: $_, onMount: OC } = window.__gradio__svelte__internal;
function A_(o) {
  let e, t, n, i, a;
  const l = (
    /*#slots*/
    o[8].default
  ), r = oo(
    l,
    o,
    /*$$scope*/
    o[7],
    null
  );
  let s = [
    { class: "download-link" },
    { href: (
      /*href*/
      o[0]
    ) },
    {
      target: t = typeof window < "u" && window.__is_colab__ ? "_blank" : null
    },
    { rel: "noopener noreferrer" },
    { download: (
      /*download*/
      o[1]
    ) },
    /*$$restProps*/
    o[6]
  ], u = {};
  for (let c = 0; c < s.length; c += 1)
    u = qn(u, s[c]);
  return {
    c() {
      e = Ha("a"), r && r.c(), this.h();
    },
    l(c) {
      e = Ua(c, "A", {
        class: !0,
        href: !0,
        target: !0,
        rel: !0,
        download: !0
      });
      var p = za(e);
      r && r.l(p), p.forEach(Ht), this.h();
    },
    h() {
      Nn(e, u), zl(e, "position", "relative"), Mn(e, "svelte-151nsdd", !0);
    },
    m(c, p) {
      Wn(c, e, p), r && r.m(e, null), n = !0, i || (a = Va(
        e,
        "click",
        /*dispatch*/
        o[3].bind(null, "click")
      ), i = !0);
    },
    p(c, p) {
      r && r.p && (!n || p & /*$$scope*/
      128) && ro(
        r,
        l,
        c,
        /*$$scope*/
        c[7],
        n ? ao(
          l,
          /*$$scope*/
          c[7],
          p,
          null
        ) : lo(
          /*$$scope*/
          c[7]
        ),
        null
      ), Nn(e, u = ja(s, [
        { class: "download-link" },
        (!n || p & /*href*/
        1) && { href: (
          /*href*/
          c[0]
        ) },
        { target: t },
        { rel: "noopener noreferrer" },
        (!n || p & /*download*/
        2) && { download: (
          /*download*/
          c[1]
        ) },
        p & /*$$restProps*/
        64 && /*$$restProps*/
        c[6]
      ])), zl(e, "position", "relative"), Mn(e, "svelte-151nsdd", !0);
    },
    i(c) {
      n || (kt(r, c), n = !0);
    },
    o(c) {
      Et(r, c), n = !1;
    },
    d(c) {
      c && Ht(e), r && r.d(c), i = !1, a();
    }
  };
}
function C_(o) {
  let e, t, n, i;
  const a = [T_, S_], l = [];
  function r(s, u) {
    return (
      /*is_downloading*/
      s[2] ? 0 : 1
    );
  }
  return e = r(o), t = l[e] = a[e](o), {
    c() {
      t.c(), n = On();
    },
    l(s) {
      t.l(s), n = On();
    },
    m(s, u) {
      l[e].m(s, u), Wn(s, n, u), i = !0;
    },
    p(s, u) {
      let c = e;
      e = r(s), e === c ? l[e].p(s, u) : (Ga(), Et(l[c], 1, 1, () => {
        l[c] = null;
      }), Pa(), t = l[e], t ? t.p(s, u) : (t = l[e] = a[e](s), t.c()), kt(t, 1), t.m(n.parentNode, n));
    },
    i(s) {
      i || (kt(t), i = !0);
    },
    o(s) {
      Et(t), i = !1;
    },
    d(s) {
      s && Ht(n), l[e].d(s);
    }
  };
}
function S_(o) {
  let e, t, n, i;
  const a = (
    /*#slots*/
    o[8].default
  ), l = oo(
    a,
    o,
    /*$$scope*/
    o[7],
    null
  );
  let r = [
    /*$$restProps*/
    o[6],
    { href: (
      /*href*/
      o[0]
    ) }
  ], s = {};
  for (let u = 0; u < r.length; u += 1)
    s = qn(s, r[u]);
  return {
    c() {
      e = Ha("a"), l && l.c(), this.h();
    },
    l(u) {
      e = Ua(u, "A", { href: !0 });
      var c = za(e);
      l && l.l(c), c.forEach(Ht), this.h();
    },
    h() {
      Nn(e, s), Mn(e, "svelte-151nsdd", !0);
    },
    m(u, c) {
      Wn(u, e, c), l && l.m(e, null), t = !0, n || (i = Va(e, "click", k_(
        /*wasm_click_handler*/
        o[5]
      )), n = !0);
    },
    p(u, c) {
      l && l.p && (!t || c & /*$$scope*/
      128) && ro(
        l,
        a,
        u,
        /*$$scope*/
        u[7],
        t ? ao(
          a,
          /*$$scope*/
          u[7],
          c,
          null
        ) : lo(
          /*$$scope*/
          u[7]
        ),
        null
      ), Nn(e, s = ja(r, [
        c & /*$$restProps*/
        64 && /*$$restProps*/
        u[6],
        (!t || c & /*href*/
        1) && { href: (
          /*href*/
          u[0]
        ) }
      ])), Mn(e, "svelte-151nsdd", !0);
    },
    i(u) {
      t || (kt(l, u), t = !0);
    },
    o(u) {
      Et(l, u), t = !1;
    },
    d(u) {
      u && Ht(e), l && l.d(u), n = !1, i();
    }
  };
}
function T_(o) {
  let e;
  const t = (
    /*#slots*/
    o[8].default
  ), n = oo(
    t,
    o,
    /*$$scope*/
    o[7],
    null
  );
  return {
    c() {
      n && n.c();
    },
    l(i) {
      n && n.l(i);
    },
    m(i, a) {
      n && n.m(i, a), e = !0;
    },
    p(i, a) {
      n && n.p && (!e || a & /*$$scope*/
      128) && ro(
        n,
        t,
        i,
        /*$$scope*/
        i[7],
        e ? ao(
          t,
          /*$$scope*/
          i[7],
          a,
          null
        ) : lo(
          /*$$scope*/
          i[7]
        ),
        null
      );
    },
    i(i) {
      e || (kt(n, i), e = !0);
    },
    o(i) {
      Et(n, i), e = !1;
    },
    d(i) {
      n && n.d(i);
    }
  };
}
function x_(o) {
  let e, t, n, i, a;
  const l = [C_, A_], r = [];
  function s(u, c) {
    return c & /*href*/
    1 && (e = null), e == null && (e = !!/*worker_proxy*/
    (u[4] && b_(
      /*href*/
      u[0]
    ))), e ? 0 : 1;
  }
  return t = s(o, -1), n = r[t] = l[t](o), {
    c() {
      n.c(), i = On();
    },
    l(u) {
      n.l(u), i = On();
    },
    m(u, c) {
      r[t].m(u, c), Wn(u, i, c), a = !0;
    },
    p(u, [c]) {
      let p = t;
      t = s(u, c), t === p ? r[t].p(u, c) : (Ga(), Et(r[p], 1, 1, () => {
        r[p] = null;
      }), Pa(), n = r[t], n ? n.p(u, c) : (n = r[t] = l[t](u), n.c()), kt(n, 1), n.m(i.parentNode, i));
    },
    i(u) {
      a || (kt(n), a = !0);
    },
    o(u) {
      Et(n), a = !1;
    },
    d(u) {
      u && Ht(i), r[t].d(u);
    }
  };
}
function B_(o, e, t) {
  const n = ["href", "download"];
  let i = Pl(e, n), { $$slots: a = {}, $$scope: l } = e;
  var r = this && this.__awaiter || function(b, D, g, F) {
    function h(_) {
      return _ instanceof g ? _ : new g(function(v) {
        v(_);
      });
    }
    return new (g || (g = Promise))(function(_, v) {
      function y(T) {
        try {
          A(F.next(T));
        } catch (S) {
          v(S);
        }
      }
      function w(T) {
        try {
          A(F.throw(T));
        } catch (S) {
          v(S);
        }
      }
      function A(T) {
        T.done ? _(T.value) : h(T.value).then(y, w);
      }
      A((F = F.apply(b, D || [])).next());
    });
  };
  let { href: s = void 0 } = e, { download: u } = e;
  const c = $_();
  let p = !1;
  const d = m_();
  function m() {
    return r(this, void 0, void 0, function* () {
      if (p)
        return;
      if (c("click"), s == null)
        throw new Error("href is not defined.");
      if (d == null)
        throw new Error("Wasm worker proxy is not available.");
      const D = new URL(s, window.location.href).pathname;
      t(2, p = !0), d.httpRequest({
        method: "GET",
        path: D,
        headers: {},
        query_string: ""
      }).then((g) => {
        if (g.status !== 200)
          throw new Error(`Failed to get file ${D} from the Wasm worker.`);
        const F = new Blob(
          [g.body],
          {
            type: D_(g.headers, "content-type")
          }
        ), h = URL.createObjectURL(F), _ = document.createElement("a");
        _.href = h, _.download = u, _.click(), URL.revokeObjectURL(h);
      }).finally(() => {
        t(2, p = !1);
      });
    });
  }
  return o.$$set = (b) => {
    e = qn(qn({}, e), y_(b)), t(6, i = Pl(e, n)), "href" in b && t(0, s = b.href), "download" in b && t(1, u = b.download), "$$scope" in b && t(7, l = b.$$scope);
  }, [
    s,
    u,
    p,
    c,
    d,
    m,
    i,
    l,
    a
  ];
}
class R_ extends w_ {
  constructor(e) {
    super(), F_(this, e, B_, x_, E_, { href: 0, download: 1 });
  }
}
const {
  SvelteComponent: I_,
  claim_component: Wa,
  create_component: Za,
  destroy_component: Ya,
  init: L_,
  mount_component: Xa,
  noop: q_,
  safe_not_equal: O_,
  transition_in: Ka,
  transition_out: Qa
} = window.__gradio__svelte__internal;
function N_(o) {
  let e, t;
  return e = new Vn({ props: { Icon: bu } }), {
    c() {
      Za(e.$$.fragment);
    },
    l(n) {
      Wa(e.$$.fragment, n);
    },
    m(n, i) {
      Xa(e, n, i), t = !0;
    },
    p: q_,
    i(n) {
      t || (Ka(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Qa(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Ya(e, n);
    }
  };
}
function M_(o) {
  let e, t;
  return e = new R_({
    props: {
      download: "logs.txt",
      href: (
        /*download_value*/
        o[0]
      ),
      $$slots: { default: [N_] },
      $$scope: { ctx: o }
    }
  }), {
    c() {
      Za(e.$$.fragment);
    },
    l(n) {
      Wa(e.$$.fragment, n);
    },
    m(n, i) {
      Xa(e, n, i), t = !0;
    },
    p(n, [i]) {
      const a = {};
      i & /*download_value*/
      1 && (a.href = /*download_value*/
      n[0]), i & /*$$scope*/
      4 && (a.$$scope = { dirty: i, ctx: n }), e.$set(a);
    },
    i(n) {
      t || (Ka(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Qa(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Ya(e, n);
    }
  };
}
function P_(o, e, t) {
  let { value: n } = e, i;
  return o.$$set = (a) => {
    "value" in a && t(1, n = a.value);
  }, o.$$.update = () => {
    o.$$.dirty & /*value*/
    2 && n && t(0, i = URL.createObjectURL(new Blob([n])));
  }, [i, n];
}
class z_ extends I_ {
  constructor(e) {
    super(), L_(this, e, P_, M_, O_, { value: 1 });
  }
}
const {
  SvelteComponent: U_,
  claim_component: H_,
  create_component: j_,
  destroy_component: G_,
  init: V_,
  mount_component: W_,
  noop: Z_,
  safe_not_equal: Y_,
  transition_in: X_,
  transition_out: K_
} = window.__gradio__svelte__internal, { createEventDispatcher: Q_ } = window.__gradio__svelte__internal;
function J_(o) {
  let e, t;
  return e = new Vn({ props: { Icon: Cu } }), e.$on(
    "click",
    /*click_handler*/
    o[1]
  ), {
    c() {
      j_(e.$$.fragment);
    },
    l(n) {
      H_(e.$$.fragment, n);
    },
    m(n, i) {
      W_(e, n, i), t = !0;
    },
    p: Z_,
    i(n) {
      t || (X_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      K_(e.$$.fragment, n), t = !1;
    },
    d(n) {
      G_(e, n);
    }
  };
}
function ed(o) {
  const e = Q_();
  return [e, () => e("click")];
}
class td extends U_ {
  constructor(e) {
    super(), V_(this, e, ed, J_, Y_, {});
  }
}
const {
  SvelteComponent: nd,
  check_outros: Ii,
  claim_component: Zn,
  claim_space: Ul,
  create_component: Yn,
  destroy_component: Xn,
  detach: Li,
  empty: Hl,
  group_outros: qi,
  init: id,
  insert_hydration: Oi,
  mount_component: Kn,
  noop: od,
  safe_not_equal: ld,
  space: jl,
  transition_in: Fe,
  transition_out: Ve
} = window.__gradio__svelte__internal, { createEventDispatcher: ad } = window.__gradio__svelte__internal;
function Gl(o) {
  let e, t;
  return e = new td({}), e.$on(
    "click",
    /*click_handler*/
    o[5]
  ), {
    c() {
      Yn(e.$$.fragment);
    },
    l(n) {
      Zn(e.$$.fragment, n);
    },
    m(n, i) {
      Kn(e, n, i), t = !0;
    },
    p: od,
    i(n) {
      t || (Fe(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ve(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Xn(e, n);
    }
  };
}
function Vl(o) {
  let e, t;
  return e = new f_({ props: { value: (
    /*value*/
    o[0]
  ) } }), {
    c() {
      Yn(e.$$.fragment);
    },
    l(n) {
      Zn(e.$$.fragment, n);
    },
    m(n, i) {
      Kn(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*value*/
      1 && (a.value = /*value*/
      n[0]), e.$set(a);
    },
    i(n) {
      t || (Fe(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ve(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Xn(e, n);
    }
  };
}
function Wl(o) {
  let e, t;
  return e = new z_({ props: { value: (
    /*value*/
    o[0]
  ) } }), {
    c() {
      Yn(e.$$.fragment);
    },
    l(n) {
      Zn(e.$$.fragment, n);
    },
    m(n, i) {
      Kn(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*value*/
      1 && (a.value = /*value*/
      n[0]), e.$set(a);
    },
    i(n) {
      t || (Fe(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ve(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Xn(e, n);
    }
  };
}
function rd(o) {
  let e, t, n, i, a = (
    /*show_clear_button*/
    o[3] && Gl(o)
  ), l = (
    /*show_copy_button*/
    o[2] && Vl(o)
  ), r = (
    /*show_download_button*/
    o[1] && Wl(o)
  );
  return {
    c() {
      a && a.c(), e = jl(), l && l.c(), t = jl(), r && r.c(), n = Hl();
    },
    l(s) {
      a && a.l(s), e = Ul(s), l && l.l(s), t = Ul(s), r && r.l(s), n = Hl();
    },
    m(s, u) {
      a && a.m(s, u), Oi(s, e, u), l && l.m(s, u), Oi(s, t, u), r && r.m(s, u), Oi(s, n, u), i = !0;
    },
    p(s, u) {
      /*show_clear_button*/
      s[3] ? a ? (a.p(s, u), u & /*show_clear_button*/
      8 && Fe(a, 1)) : (a = Gl(s), a.c(), Fe(a, 1), a.m(e.parentNode, e)) : a && (qi(), Ve(a, 1, 1, () => {
        a = null;
      }), Ii()), /*show_copy_button*/
      s[2] ? l ? (l.p(s, u), u & /*show_copy_button*/
      4 && Fe(l, 1)) : (l = Vl(s), l.c(), Fe(l, 1), l.m(t.parentNode, t)) : l && (qi(), Ve(l, 1, 1, () => {
        l = null;
      }), Ii()), /*show_download_button*/
      s[1] ? r ? (r.p(s, u), u & /*show_download_button*/
      2 && Fe(r, 1)) : (r = Wl(s), r.c(), Fe(r, 1), r.m(n.parentNode, n)) : r && (qi(), Ve(r, 1, 1, () => {
        r = null;
      }), Ii());
    },
    i(s) {
      i || (Fe(a), Fe(l), Fe(r), i = !0);
    },
    o(s) {
      Ve(a), Ve(l), Ve(r), i = !1;
    },
    d(s) {
      s && (Li(e), Li(t), Li(n)), a && a.d(s), l && l.d(s), r && r.d(s);
    }
  };
}
function sd(o) {
  let e, t;
  return e = new Gu({
    props: {
      $$slots: { default: [rd] },
      $$scope: { ctx: o }
    }
  }), {
    c() {
      Yn(e.$$.fragment);
    },
    l(n) {
      Zn(e.$$.fragment, n);
    },
    m(n, i) {
      Kn(e, n, i), t = !0;
    },
    p(n, [i]) {
      const a = {};
      i & /*$$scope, value, show_download_button, show_copy_button, show_clear_button*/
      79 && (a.$$scope = { dirty: i, ctx: n }), e.$set(a);
    },
    i(n) {
      t || (Fe(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ve(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Xn(e, n);
    }
  };
}
function ud(o, e, t) {
  let { value: n } = e, { show_download_button: i } = e, { show_copy_button: a } = e, { show_clear_button: l } = e;
  const r = ad(), s = () => r("clear");
  return o.$$set = (u) => {
    "value" in u && t(0, n = u.value), "show_download_button" in u && t(1, i = u.show_download_button), "show_copy_button" in u && t(2, a = u.show_copy_button), "show_clear_button" in u && t(3, l = u.show_clear_button);
  }, [
    n,
    i,
    a,
    l,
    r,
    s
  ];
}
class cd extends nd {
  constructor(e) {
    super(), id(this, e, ud, sd, ld, {
      value: 0,
      show_download_button: 1,
      show_copy_button: 2,
      show_clear_button: 3
    });
  }
}
const {
  SvelteComponent: _d,
  add_flush_callback: dd,
  append_hydration: P,
  attr: me,
  bind: fd,
  binding_callbacks: Ja,
  children: ue,
  claim_component: hd,
  claim_element: ce,
  claim_space: We,
  claim_text: ke,
  create_component: pd,
  destroy_component: md,
  destroy_each: gd,
  detach: oe,
  element: _e,
  ensure_array_like: Zl,
  init: vd,
  insert_hydration: sn,
  mount_component: Dd,
  safe_not_equal: bd,
  set_data: mt,
  set_style: gt,
  space: Ze,
  text: Ee,
  toggle_class: Cn,
  transition_in: wd,
  transition_out: yd
} = window.__gradio__svelte__internal, { afterUpdate: Fd, createEventDispatcher: kd } = window.__gradio__svelte__internal, { tick: Ed } = window.__gradio__svelte__internal;
function Yl(o, e, t) {
  const n = o.slice();
  return n[23] = e[t], n[25] = t, n;
}
function Xl(o) {
  let e, t = (
    /*i*/
    o[25] + 1 + ""
  ), n;
  return {
    c() {
      e = _e("span"), n = Ee(t), this.h();
    },
    l(i) {
      e = ce(i, "SPAN", { class: !0 });
      var a = ue(e);
      n = ke(a, t), a.forEach(oe), this.h();
    },
    h() {
      me(e, "class", "line-number svelte-1nji4lk");
    },
    m(i, a) {
      sn(i, e, a), P(e, n);
    },
    d(i) {
      i && oe(e);
    }
  };
}
function Kl(o) {
  let e, t, n, i = (
    /*log*/
    o[23].content + ""
  ), a, l, r, s = (
    /*line_numbers*/
    o[0] && Xl(o)
  );
  return {
    c() {
      e = _e("div"), s && s.c(), t = Ze(), n = _e("pre"), a = Ee(i), r = Ze(), this.h();
    },
    l(u) {
      e = ce(u, "DIV", { class: !0 });
      var c = ue(e);
      s && s.l(c), t = We(c), n = ce(c, "PRE", { class: !0 });
      var p = ue(n);
      a = ke(p, i), p.forEach(oe), r = We(c), c.forEach(oe), this.h();
    },
    h() {
      me(n, "class", l = "log-content log-level-" + /*log*/
      o[23].level.toLowerCase() + " svelte-1nji4lk"), me(e, "class", "log-line svelte-1nji4lk");
    },
    m(u, c) {
      sn(u, e, c), s && s.m(e, null), P(e, t), P(e, n), P(n, a), P(e, r);
    },
    p(u, c) {
      /*line_numbers*/
      u[0] ? s || (s = Xl(u), s.c(), s.m(e, t)) : s && (s.d(1), s = null), c & /*log_lines*/
      256 && i !== (i = /*log*/
      u[23].content + "") && mt(a, i), c & /*log_lines*/
      256 && l !== (l = "log-content log-level-" + /*log*/
      u[23].level.toLowerCase() + " svelte-1nji4lk") && me(n, "class", l);
    },
    d(u) {
      u && oe(e), s && s.d();
    }
  };
}
function Ql(o) {
  let e, t, n, i = (
    /*progress*/
    o[7].desc + ""
  ), a, l, r, s = (
    /*progress*/
    o[7].rate.toFixed(2) + ""
  ), u, c, p = (
    /*progress*/
    o[7].rate_unit + ""
  ), d, m, b = (
    /*formatted_extra_info*/
    o[11].trim()
  ), D, g, F, h, _, v, y = Math.round(
    /*progress*/
    o[7].percentage
  ) + "", w, A, T, S, E = (
    /*progress*/
    o[7].current + ""
  ), I, O, ie = (
    /*progress*/
    o[7].total + ""
  ), X, M = b && Jl(o);
  return {
    c() {
      e = _e("div"), t = _e("div"), n = _e("span"), a = Ee(i), l = Ze(), r = _e("span"), u = Ee(s), c = Ze(), d = Ee(p), m = Ze(), M && M.c(), D = Ze(), g = _e("div"), F = _e("div"), h = Ze(), _ = _e("div"), v = _e("span"), w = Ee(y), A = Ee("%"), T = Ze(), S = _e("span"), I = Ee(E), O = Ee(" / "), X = Ee(ie), this.h();
    },
    l(q) {
      e = ce(q, "DIV", { class: !0 });
      var z = ue(e);
      t = ce(z, "DIV", { class: !0 });
      var H = ue(t);
      n = ce(H, "SPAN", { class: !0 });
      var K = ue(n);
      a = ke(K, i), K.forEach(oe), l = We(H), r = ce(H, "SPAN", { class: !0 });
      var j = ue(r);
      u = ke(j, s), c = We(j), d = ke(j, p), m = We(j), M && M.l(j), j.forEach(oe), H.forEach(oe), D = We(z), g = ce(z, "DIV", { class: !0 });
      var k = ue(g);
      F = ce(k, "DIV", { class: !0, style: !0 }), ue(F).forEach(oe), k.forEach(oe), h = We(z), _ = ce(z, "DIV", { class: !0 });
      var Q = ue(_);
      v = ce(Q, "SPAN", {});
      var V = ue(v);
      w = ke(V, y), A = ke(V, "%"), V.forEach(oe), T = We(Q), S = ce(Q, "SPAN", {});
      var le = ue(S);
      I = ke(le, E), O = ke(le, " / "), X = ke(le, ie), le.forEach(oe), Q.forEach(oe), z.forEach(oe), this.h();
    },
    h() {
      me(n, "class", "svelte-1nji4lk"), me(r, "class", "rate-info svelte-1nji4lk"), me(t, "class", "progress-label-top svelte-1nji4lk"), me(F, "class", "progress-bar-fill svelte-1nji4lk"), gt(
        F,
        "width",
        /*progress*/
        o[7].percentage.toFixed(1) + "%"
      ), Cn(
        F,
        "success",
        /*progress*/
        o[7].status === "success"
      ), Cn(
        F,
        "error",
        /*progress*/
        o[7].status === "error"
      ), me(g, "class", "progress-bar-background svelte-1nji4lk"), me(_, "class", "progress-label-bottom svelte-1nji4lk"), me(e, "class", "progress-container svelte-1nji4lk");
    },
    m(q, z) {
      sn(q, e, z), P(e, t), P(t, n), P(n, a), P(t, l), P(t, r), P(r, u), P(r, c), P(r, d), P(r, m), M && M.m(r, null), P(e, D), P(e, g), P(g, F), P(e, h), P(e, _), P(_, v), P(v, w), P(v, A), P(_, T), P(_, S), P(S, I), P(S, O), P(S, X);
    },
    p(q, z) {
      z & /*progress*/
      128 && i !== (i = /*progress*/
      q[7].desc + "") && mt(a, i), z & /*progress*/
      128 && s !== (s = /*progress*/
      q[7].rate.toFixed(2) + "") && mt(u, s), z & /*progress*/
      128 && p !== (p = /*progress*/
      q[7].rate_unit + "") && mt(d, p), z & /*formatted_extra_info*/
      2048 && (b = /*formatted_extra_info*/
      q[11].trim()), b ? M ? M.p(q, z) : (M = Jl(q), M.c(), M.m(r, null)) : M && (M.d(1), M = null), z & /*progress*/
      128 && gt(
        F,
        "width",
        /*progress*/
        q[7].percentage.toFixed(1) + "%"
      ), z & /*progress*/
      128 && Cn(
        F,
        "success",
        /*progress*/
        q[7].status === "success"
      ), z & /*progress*/
      128 && Cn(
        F,
        "error",
        /*progress*/
        q[7].status === "error"
      ), z & /*progress*/
      128 && y !== (y = Math.round(
        /*progress*/
        q[7].percentage
      ) + "") && mt(w, y), z & /*progress*/
      128 && E !== (E = /*progress*/
      q[7].current + "") && mt(I, E), z & /*progress*/
      128 && ie !== (ie = /*progress*/
      q[7].total + "") && mt(X, ie);
    },
    d(q) {
      q && oe(e), M && M.d();
    }
  };
}
function Jl(o) {
  let e, t, n, i;
  return {
    c() {
      e = _e("span"), t = Ee("("), n = Ee(
        /*formatted_extra_info*/
        o[11]
      ), i = Ee(")"), this.h();
    },
    l(a) {
      e = ce(a, "SPAN", { class: !0 });
      var l = ue(e);
      t = ke(l, "("), n = ke(
        l,
        /*formatted_extra_info*/
        o[11]
      ), i = ke(l, ")"), l.forEach(oe), this.h();
    },
    h() {
      me(e, "class", "extra-info svelte-1nji4lk");
    },
    m(a, l) {
      sn(a, e, l), P(e, t), P(e, n), P(e, i);
    },
    p(a, l) {
      l & /*formatted_extra_info*/
      2048 && mt(
        n,
        /*formatted_extra_info*/
        a[11]
      );
    },
    d(a) {
      a && oe(e);
    }
  };
}
function $d(o) {
  let e, t, n, i, a, l, r, s, u;
  function c(D) {
    o[18](D);
  }
  let p = {
    show_download_button: (
      /*show_download_button*/
      o[3]
    ),
    show_copy_button: (
      /*show_copy_button*/
      o[4]
    ),
    show_clear_button: (
      /*show_clear_button*/
      o[5]
    )
  };
  /*all_logs_as_text*/
  o[9] !== void 0 && (p.value = /*all_logs_as_text*/
  o[9]), i = new cd({ props: p }), Ja.push(() => fd(i, "value", c)), i.$on(
    "clear",
    /*clear_handler*/
    o[19]
  );
  let d = Zl(
    /*log_lines*/
    o[8]
  ), m = [];
  for (let D = 0; D < d.length; D += 1)
    m[D] = Kl(Yl(o, d, D));
  let b = (
    /*progress*/
    o[7].visible && /*display_mode*/
    (o[2] === "full" || /*display_mode*/
    o[2] === "progress") && Ql(o)
  );
  return {
    c() {
      e = _e("div"), t = _e("div"), n = _e("div"), pd(i.$$.fragment), l = Ze(), r = _e("div");
      for (let D = 0; D < m.length; D += 1)
        m[D].c();
      s = Ze(), b && b.c(), this.h();
    },
    l(D) {
      e = ce(D, "DIV", { class: !0 });
      var g = ue(e);
      t = ce(g, "DIV", { class: !0 });
      var F = ue(t);
      n = ce(F, "DIV", { class: !0 });
      var h = ue(n);
      hd(i.$$.fragment, h), h.forEach(oe), l = We(F), r = ce(F, "DIV", { class: !0, style: !0 });
      var _ = ue(r);
      for (let v = 0; v < m.length; v += 1)
        m[v].l(_);
      _.forEach(oe), F.forEach(oe), s = We(g), b && b.l(g), g.forEach(oe), this.h();
    },
    h() {
      me(n, "class", "header svelte-1nji4lk"), me(r, "class", "log-panel svelte-1nji4lk"), gt(
        r,
        "background-color",
        /*background_color*/
        o[1]
      ), me(t, "class", "log-view-container svelte-1nji4lk"), gt(
        t,
        "display",
        /*display_mode*/
        o[2] === "progress" ? "none" : "flex"
      ), me(e, "class", "panel-container svelte-1nji4lk"), gt(
        e,
        "height",
        /*height_style*/
        o[10]
      );
    },
    m(D, g) {
      sn(D, e, g), P(e, t), P(t, n), Dd(i, n, null), P(t, l), P(t, r);
      for (let F = 0; F < m.length; F += 1)
        m[F] && m[F].m(r, null);
      o[20](r), P(e, s), b && b.m(e, null), u = !0;
    },
    p(D, [g]) {
      const F = {};
      if (g & /*show_download_button*/
      8 && (F.show_download_button = /*show_download_button*/
      D[3]), g & /*show_copy_button*/
      16 && (F.show_copy_button = /*show_copy_button*/
      D[4]), g & /*show_clear_button*/
      32 && (F.show_clear_button = /*show_clear_button*/
      D[5]), !a && g & /*all_logs_as_text*/
      512 && (a = !0, F.value = /*all_logs_as_text*/
      D[9], dd(() => a = !1)), i.$set(F), g & /*log_lines, line_numbers*/
      257) {
        d = Zl(
          /*log_lines*/
          D[8]
        );
        let h;
        for (h = 0; h < d.length; h += 1) {
          const _ = Yl(D, d, h);
          m[h] ? m[h].p(_, g) : (m[h] = Kl(_), m[h].c(), m[h].m(r, null));
        }
        for (; h < m.length; h += 1)
          m[h].d(1);
        m.length = d.length;
      }
      (!u || g & /*background_color*/
      2) && gt(
        r,
        "background-color",
        /*background_color*/
        D[1]
      ), g & /*display_mode*/
      4 && gt(
        t,
        "display",
        /*display_mode*/
        D[2] === "progress" ? "none" : "flex"
      ), /*progress*/
      D[7].visible && /*display_mode*/
      (D[2] === "full" || /*display_mode*/
      D[2] === "progress") ? b ? b.p(D, g) : (b = Ql(D), b.c(), b.m(e, null)) : b && (b.d(1), b = null), g & /*height_style*/
      1024 && gt(
        e,
        "height",
        /*height_style*/
        D[10]
      );
    },
    i(D) {
      u || (wd(i.$$.fragment, D), u = !0);
    },
    o(D) {
      yd(i.$$.fragment, D), u = !1;
    },
    d(D) {
      D && oe(e), md(i), gd(m, D), o[20](null), b && b.d();
    }
  };
}
function Ad(o, e, t) {
  let n;
  var i = this && this.__awaiter || function(E, I, O, ie) {
    function X(M) {
      return M instanceof O ? M : new O(function(q) {
        q(M);
      });
    }
    return new (O || (O = Promise))(function(M, q) {
      function z(j) {
        try {
          K(ie.next(j));
        } catch (k) {
          q(k);
        }
      }
      function H(j) {
        try {
          K(ie.throw(j));
        } catch (k) {
          q(k);
        }
      }
      function K(j) {
        j.done ? M(j.value) : X(j.value).then(z, H);
      }
      K((ie = ie.apply(E, I || [])).next());
    });
  };
  let { value: a = null } = e, { height: l } = e, { autoscroll: r } = e, { line_numbers: s } = e, { background_color: u } = e, { display_mode: c } = e, { show_download_button: p } = e, { show_copy_button: d } = e, { show_clear_button: m } = e;
  const b = kd();
  let D, g = {
    visible: !0,
    current: 0,
    total: 100,
    desc: "",
    percentage: 0,
    rate: 0,
    status: "running",
    rate_unit: "it/s",
    extra_info: {}
  }, F = [], h = "", _, v = "Processing...", y = !1, w;
  Fd(() => {
    y && D && c !== "progress" && (t(6, D.scrollTop = D.scrollHeight, D), y = !1);
  });
  function A(E) {
    h = E, t(9, h), t(13, a), t(15, r), t(6, D), t(17, w), t(22, i), t(8, F), t(16, v), t(2, c), t(7, g);
  }
  const T = () => b("clear");
  function S(E) {
    Ja[E ? "unshift" : "push"](() => {
      D = E, t(6, D);
    });
  }
  return o.$$set = (E) => {
    "value" in E && t(13, a = E.value), "height" in E && t(14, l = E.height), "autoscroll" in E && t(15, r = E.autoscroll), "line_numbers" in E && t(0, s = E.line_numbers), "background_color" in E && t(1, u = E.background_color), "display_mode" in E && t(2, c = E.display_mode), "show_download_button" in E && t(3, p = E.show_download_button), "show_copy_button" in E && t(4, d = E.show_copy_button), "show_clear_button" in E && t(5, m = E.show_clear_button);
  }, o.$$.update = () => {
    o.$$.dirty & /*value, autoscroll, log_container, debounceTimeout, log_lines, initial_desc, display_mode, progress*/
    238020 && a !== null && (r && D && (y = D.scrollHeight - D.scrollTop - D.clientHeight < 20), clearTimeout(w), t(17, w = setTimeout(
      () => i(void 0, void 0, void 0, function* () {
        if (a === null)
          t(8, F = []), t(7, g = {
            visible: !1,
            current: 0,
            total: 100,
            desc: "",
            percentage: 0,
            rate: 0,
            status: "running",
            rate_unit: "it/s",
            extra_info: {}
          }), t(9, h = ""), t(16, v = "Processing...");
        else if (a) {
          if (Array.isArray(a)) {
            t(8, F = []), t(7, g.visible = !1, g);
            for (const E of a)
              E.type === "log" ? t(8, F = [
                ...F,
                {
                  level: E.level || "INFO",
                  content: E.content
                }
              ]) : E.type === "progress" && (t(7, g.visible = !0, g), t(7, g.current = E.current, g), t(7, g.total = E.total || 100, g), E.current === 0 && E.desc && v === "Processing..." && t(16, v = E.desc), t(
                7,
                g.desc = c === "progress" && F.length > 0 ? F[F.length - 1].content : v,
                g
              ), t(7, g.rate = E.rate || 0, g), t(7, g.rate_unit = E.rate_unit || "it/s", g), t(7, g.extra_info = E.extra_info || "", g), t(
                7,
                g.percentage = g.total > 0 ? E.current / g.total * 100 : 0,
                g
              ), t(7, g.status = E.status || "running", g));
          } else typeof a == "object" && a.type && (a.type === "log" ? t(8, F = [
            ...F,
            {
              level: a.level || "INFO",
              content: a.content
            }
          ]) : a.type === "progress" && (t(7, g.visible = !0, g), t(7, g.current = a.current, g), t(7, g.total = a.total || 100, g), a.current === 0 && a.desc && v === "Processing..." && t(16, v = a.desc), t(
            7,
            g.desc = c === "progress" && F.length > 0 ? F[F.length - 1].content : v,
            g
          ), t(7, g.rate = a.rate || 0, g), t(7, g.rate_unit = a.rate_unit || "it/s", g), t(7, g.extra_info = a.extra_info || "", g), t(
            7,
            g.percentage = g.total > 0 ? a.current / a.total * 100 : 0,
            g
          ), t(7, g.status = a.status || "running", g), t(8, F = Array.isArray(a.logs) ? a.logs.map((E) => ({
            level: E.level || "INFO",
            content: E.content
          })) : F)));
          t(9, h = F.map((E) => E.content).join(`
`));
        }
        yield Ed();
      }),
      50
    ))), o.$$.dirty & /*display_mode, progress, height*/
    16516 && (c === "progress" && g.visible ? t(10, _ = "auto") : t(10, _ = typeof l == "number" ? l + "px" : l)), o.$$.dirty & /*progress*/
    128 && t(11, n = [
      g.extra_info.extra_text,
      g.extra_info.eta ? `ETA: ${g.extra_info.eta}` : "",
      g.extra_info.elapsed ? `Elapsed: ${g.extra_info.elapsed}` : ""
    ].filter(Boolean).join(" | "));
  }, [
    s,
    u,
    c,
    p,
    d,
    m,
    D,
    g,
    F,
    h,
    _,
    n,
    b,
    a,
    l,
    r,
    v,
    w,
    A,
    T,
    S
  ];
}
class Cd extends _d {
  constructor(e) {
    super(), vd(this, e, Ad, $d, bd, {
      value: 13,
      height: 14,
      autoscroll: 15,
      line_numbers: 0,
      background_color: 1,
      display_mode: 2,
      show_download_button: 3,
      show_copy_button: 4,
      show_clear_button: 5
    });
  }
}
const {
  SvelteComponent: Sd,
  attr: Td,
  check_outros: xd,
  children: Bd,
  claim_component: Pn,
  claim_element: Rd,
  claim_space: ea,
  create_component: zn,
  destroy_component: Un,
  detach: Hn,
  element: Id,
  group_outros: Ld,
  init: qd,
  insert_hydration: Xi,
  mount_component: jn,
  safe_not_equal: Od,
  space: ta,
  transition_in: wt,
  transition_out: zt
} = window.__gradio__svelte__internal;
function na(o) {
  let e, t, n;
  return t = new Rs({
    props: {
      Icon: e_,
      show_label: (
        /*show_label*/
        o[9]
      ),
      label: (
        /*label*/
        o[2]
      )
    }
  }), {
    c() {
      e = Id("div"), zn(t.$$.fragment), this.h();
    },
    l(i) {
      e = Rd(i, "DIV", { class: !0 });
      var a = Bd(e);
      Pn(t.$$.fragment, a), a.forEach(Hn), this.h();
    },
    h() {
      Td(e, "class", "block-label-wrapper svelte-10ojysx");
    },
    m(i, a) {
      Xi(i, e, a), jn(t, e, null), n = !0;
    },
    p(i, a) {
      const l = {};
      a & /*show_label*/
      512 && (l.show_label = /*show_label*/
      i[9]), a & /*label*/
      4 && (l.label = /*label*/
      i[2]), t.$set(l);
    },
    i(i) {
      n || (wt(t.$$.fragment, i), n = !0);
    },
    o(i) {
      zt(t.$$.fragment, i), n = !1;
    },
    d(i) {
      i && Hn(e), Un(t);
    }
  };
}
function Nd(o) {
  let e, t, n, i, a, l = (
    /*show_label*/
    o[9] && na(o)
  );
  return t = new Ac({
    props: {
      loading_status: (
        /*loading_status*/
        o[17]
      ),
      autoscroll: (
        /*gradio*/
        o[0].autoscroll
      ),
      i18n: (
        /*gradio*/
        o[0].i18n
      )
    }
  }), i = new Cd({
    props: {
      value: (
        /*value*/
        o[1]
      ),
      height: (
        /*height*/
        o[3]
      ),
      autoscroll: (
        /*autoscroll*/
        o[4]
      ),
      line_numbers: (
        /*line_numbers*/
        o[5]
      ),
      background_color: (
        /*background_color*/
        o[6]
      ),
      display_mode: (
        /*display_mode*/
        o[7]
      ),
      show_download_button: (
        /*show_download_button*/
        o[10]
      ),
      show_copy_button: (
        /*show_copy_button*/
        o[11]
      ),
      show_clear_button: (
        /*show_clear_button*/
        o[12]
      )
    }
  }), i.$on(
    "clear",
    /*clear_handler*/
    o[18]
  ), {
    c() {
      l && l.c(), e = ta(), zn(t.$$.fragment), n = ta(), zn(i.$$.fragment);
    },
    l(r) {
      l && l.l(r), e = ea(r), Pn(t.$$.fragment, r), n = ea(r), Pn(i.$$.fragment, r);
    },
    m(r, s) {
      l && l.m(r, s), Xi(r, e, s), jn(t, r, s), Xi(r, n, s), jn(i, r, s), a = !0;
    },
    p(r, s) {
      /*show_label*/
      r[9] ? l ? (l.p(r, s), s & /*show_label*/
      512 && wt(l, 1)) : (l = na(r), l.c(), wt(l, 1), l.m(e.parentNode, e)) : l && (Ld(), zt(l, 1, 1, () => {
        l = null;
      }), xd());
      const u = {};
      s & /*loading_status*/
      131072 && (u.loading_status = /*loading_status*/
      r[17]), s & /*gradio*/
      1 && (u.autoscroll = /*gradio*/
      r[0].autoscroll), s & /*gradio*/
      1 && (u.i18n = /*gradio*/
      r[0].i18n), t.$set(u);
      const c = {};
      s & /*value*/
      2 && (c.value = /*value*/
      r[1]), s & /*height*/
      8 && (c.height = /*height*/
      r[3]), s & /*autoscroll*/
      16 && (c.autoscroll = /*autoscroll*/
      r[4]), s & /*line_numbers*/
      32 && (c.line_numbers = /*line_numbers*/
      r[5]), s & /*background_color*/
      64 && (c.background_color = /*background_color*/
      r[6]), s & /*display_mode*/
      128 && (c.display_mode = /*display_mode*/
      r[7]), s & /*show_download_button*/
      1024 && (c.show_download_button = /*show_download_button*/
      r[10]), s & /*show_copy_button*/
      2048 && (c.show_copy_button = /*show_copy_button*/
      r[11]), s & /*show_clear_button*/
      4096 && (c.show_clear_button = /*show_clear_button*/
      r[12]), i.$set(c);
    },
    i(r) {
      a || (wt(l), wt(t.$$.fragment, r), wt(i.$$.fragment, r), a = !0);
    },
    o(r) {
      zt(l), zt(t.$$.fragment, r), zt(i.$$.fragment, r), a = !1;
    },
    d(r) {
      r && (Hn(e), Hn(n)), l && l.d(r), Un(t, r), Un(i, r);
    }
  };
}
function Md(o) {
  let e, t;
  return e = new $r({
    props: {
      visible: (
        /*visible*/
        o[8]
      ),
      elem_id: (
        /*elem_id*/
        o[13]
      ),
      elem_classes: (
        /*elem_classes*/
        o[14]
      ),
      scale: (
        /*scale*/
        o[15]
      ),
      min_width: (
        /*min_width*/
        o[16]
      ),
      allow_overflow: !1,
      $$slots: { default: [Nd] },
      $$scope: { ctx: o }
    }
  }), {
    c() {
      zn(e.$$.fragment);
    },
    l(n) {
      Pn(e.$$.fragment, n);
    },
    m(n, i) {
      jn(e, n, i), t = !0;
    },
    p(n, [i]) {
      const a = {};
      i & /*visible*/
      256 && (a.visible = /*visible*/
      n[8]), i & /*elem_id*/
      8192 && (a.elem_id = /*elem_id*/
      n[13]), i & /*elem_classes*/
      16384 && (a.elem_classes = /*elem_classes*/
      n[14]), i & /*scale*/
      32768 && (a.scale = /*scale*/
      n[15]), i & /*min_width*/
      65536 && (a.min_width = /*min_width*/
      n[16]), i & /*$$scope, value, height, autoscroll, line_numbers, background_color, display_mode, show_download_button, show_copy_button, show_clear_button, gradio, loading_status, show_label, label*/
      663295 && (a.$$scope = { dirty: i, ctx: n }), e.$set(a);
    },
    i(n) {
      t || (wt(e.$$.fragment, n), t = !0);
    },
    o(n) {
      zt(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Un(e, n);
    }
  };
}
function Pd(o, e, t) {
  let { gradio: n } = e, { value: i = null } = e, { label: a } = e, { height: l } = e, { autoscroll: r } = e, { line_numbers: s } = e, { background_color: u } = e, { display_mode: c } = e, { visible: p = !0 } = e, { show_label: d = !0 } = e, { show_download_button: m } = e, { show_copy_button: b } = e, { show_clear_button: D } = e, { elem_id: g = "" } = e, { elem_classes: F = [] } = e, { scale: h = null } = e, { min_width: _ = void 0 } = e, { loading_status: v } = e;
  const y = () => n.dispatch("clear");
  return o.$$set = (w) => {
    "gradio" in w && t(0, n = w.gradio), "value" in w && t(1, i = w.value), "label" in w && t(2, a = w.label), "height" in w && t(3, l = w.height), "autoscroll" in w && t(4, r = w.autoscroll), "line_numbers" in w && t(5, s = w.line_numbers), "background_color" in w && t(6, u = w.background_color), "display_mode" in w && t(7, c = w.display_mode), "visible" in w && t(8, p = w.visible), "show_label" in w && t(9, d = w.show_label), "show_download_button" in w && t(10, m = w.show_download_button), "show_copy_button" in w && t(11, b = w.show_copy_button), "show_clear_button" in w && t(12, D = w.show_clear_button), "elem_id" in w && t(13, g = w.elem_id), "elem_classes" in w && t(14, F = w.elem_classes), "scale" in w && t(15, h = w.scale), "min_width" in w && t(16, _ = w.min_width), "loading_status" in w && t(17, v = w.loading_status);
  }, [
    n,
    i,
    a,
    l,
    r,
    s,
    u,
    c,
    p,
    d,
    m,
    b,
    D,
    g,
    F,
    h,
    _,
    v,
    y
  ];
}
class NC extends Sd {
  constructor(e) {
    super(), qd(this, e, Pd, Md, Od, {
      gradio: 0,
      value: 1,
      label: 2,
      height: 3,
      autoscroll: 4,
      line_numbers: 5,
      background_color: 6,
      display_mode: 7,
      visible: 8,
      show_label: 9,
      show_download_button: 10,
      show_copy_button: 11,
      show_clear_button: 12,
      elem_id: 13,
      elem_classes: 14,
      scale: 15,
      min_width: 16,
      loading_status: 17
    });
  }
}
export {
  NC as default
};
