"""Zoho platform implementation"""

from .client import ZohoClient

__all__ = ['ZohoClient']