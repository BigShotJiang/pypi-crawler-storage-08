from sphinx_hosting.wildewidgets import SphinxHostingSidebar

# ------------------------------------------------------
# Menus
# ------------------------------------------------------


class MainMenu(SphinxHostingSidebar):
    pass
