# Changelog

## 0.3 (2021-12-03)

- Show stdout/stderr details if a command fails

## 0.2 (2021-12-29)

- Drop 3.6 support and bump linters
- Index URL now ends with `/` to avoid redirect when sending a GET

## 0.1 (2021-06-17)

- First release
