import warnings

warnings.warn(
    "Importing from ert.shared.plugins is deprecated, see "
    "https://ert.readthedocs.io/en/latest/getting_started/howto/plugin_system.html",
    DeprecationWarning,
    stacklevel=1,
)
