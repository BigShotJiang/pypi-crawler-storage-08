#!/usr/bin/env python3

# Copyright 2017-2020 Palantir Technologies, Inc.
# Copyright 2021- Python Language Server Contributors.

from setuptools import setup

if __name__ == "__main__":
    setup(
        name="deepnote-python-lsp-server",  # to allow GitHub dependency tracking work
    )
