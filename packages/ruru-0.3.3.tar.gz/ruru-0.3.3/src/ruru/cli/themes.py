"""Theme management for CLI color schemes.

Contains functions for theme switching, listing, and custom theme management.
"""
