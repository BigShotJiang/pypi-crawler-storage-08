from ptsl.ops import Operation


class GetRecordMode(Operation):
    pass
