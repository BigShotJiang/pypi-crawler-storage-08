from .operation import Operation


class Import(Operation):
    pass
