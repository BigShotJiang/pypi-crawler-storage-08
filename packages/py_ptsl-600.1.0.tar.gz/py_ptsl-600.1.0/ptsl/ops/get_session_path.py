from ptsl.ops import Operation


class GetSessionPath(Operation):
    pass
