from ptsl.ops import Operation


class RefreshAllModifiedAudioFiles(Operation):
    pass
