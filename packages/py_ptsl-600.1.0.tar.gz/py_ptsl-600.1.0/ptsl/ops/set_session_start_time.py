from ptsl.ops import Operation


class SetSessionStartTime(Operation):
    pass
