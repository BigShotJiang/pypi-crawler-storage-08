from .operation import Operation


class CreateFadesBasedOnPreset(Operation):
    pass
