from ptsl.ops import Operation


class GetTimelineSelection(Operation):
    pass


class SetTimelineSelection(Operation):
    pass
