from ptsl.ops import Operation


class GetSessionAudioFormat(Operation):
    pass
