from ptsl.ops import Operation


class SetRecordMode(Operation):
    pass
