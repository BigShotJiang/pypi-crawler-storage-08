from ptsl.ops import Operation


class EditMemoryLocation(Operation):
    pass


class GetMemoryLocations(Operation):
    pass


class CreateMemoryLocation(Operation):
    pass
