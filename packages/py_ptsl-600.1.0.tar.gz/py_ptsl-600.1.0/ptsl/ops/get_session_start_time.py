from ptsl.ops import Operation


class GetSessionStartTime(Operation):
    pass
