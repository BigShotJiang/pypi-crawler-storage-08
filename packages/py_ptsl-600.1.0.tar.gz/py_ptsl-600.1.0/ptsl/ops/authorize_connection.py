from ptsl.ops import Operation


class AuthorizeConnection(Operation):
    pass
