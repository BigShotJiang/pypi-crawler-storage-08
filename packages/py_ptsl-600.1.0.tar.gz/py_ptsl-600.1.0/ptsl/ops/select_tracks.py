from ptsl.ops import Operation


class SelectTracksByName(Operation):
    pass
