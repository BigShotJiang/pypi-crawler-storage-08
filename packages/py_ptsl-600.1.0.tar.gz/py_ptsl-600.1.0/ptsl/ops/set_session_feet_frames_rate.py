from ptsl.ops import Operation


class SetSessionFeetFramesRate(Operation):
    pass
