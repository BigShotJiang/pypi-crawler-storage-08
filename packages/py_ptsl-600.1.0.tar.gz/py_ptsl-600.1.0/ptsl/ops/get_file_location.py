from ptsl.ops import Operation


class GetFileLocation(Operation):
    pass
