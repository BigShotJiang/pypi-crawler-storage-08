from ptsl.ops import Operation


class Spot(Operation):
    pass
