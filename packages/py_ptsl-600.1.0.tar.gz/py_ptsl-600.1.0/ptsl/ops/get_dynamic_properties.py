from ptsl.ops import Operation


class GetDynamicProperties(Operation):
    pass
