from ptsl.ops import Operation


class GetEditTool(Operation):
    pass


class SetEditTool(Operation):
    pass
