from ptsl.ops import Operation


class GetEditMode(Operation):
    pass


class SetEditMode(Operation):
    pass


class GetEditModeOptions(Operation):
    pass


class SetEditModeOptions(Operation):
    pass
