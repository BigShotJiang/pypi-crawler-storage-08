from ptsl.ops import Operation


class ConsolidateClip(Operation):
    pass
