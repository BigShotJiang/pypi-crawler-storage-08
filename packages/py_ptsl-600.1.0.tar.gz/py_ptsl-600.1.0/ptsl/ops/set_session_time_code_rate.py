from ptsl.ops import Operation


class SetSessionTimeCodeRate(Operation):
    pass
