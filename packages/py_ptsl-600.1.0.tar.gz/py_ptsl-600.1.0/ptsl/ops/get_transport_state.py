from ptsl.ops import Operation


class GetTransportState(Operation):
    pass
