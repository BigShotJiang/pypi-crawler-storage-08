from ptsl.ops import Operation


class SelectAllClipsOnTrack(Operation):
    pass
