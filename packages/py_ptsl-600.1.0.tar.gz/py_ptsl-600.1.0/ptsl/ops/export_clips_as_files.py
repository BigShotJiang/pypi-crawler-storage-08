from ptsl.ops import Operation


class ExportClipsAsFiles(Operation):
    pass
