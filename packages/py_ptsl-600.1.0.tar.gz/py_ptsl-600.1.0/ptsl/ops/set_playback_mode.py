from ptsl.ops import Operation


class SetPlaybackMode(Operation):
    pass
