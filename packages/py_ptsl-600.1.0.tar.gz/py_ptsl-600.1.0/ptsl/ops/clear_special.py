from ptsl.ops import Operation


class ClearSpecial(Operation):
    pass
