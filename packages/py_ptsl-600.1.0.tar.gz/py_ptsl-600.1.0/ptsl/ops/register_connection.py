from ptsl.ops import Operation


class RegisterConnection(Operation):
    pass
