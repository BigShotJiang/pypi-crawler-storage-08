from ptsl.ops import Operation


class SaveSession(Operation):
    pass
