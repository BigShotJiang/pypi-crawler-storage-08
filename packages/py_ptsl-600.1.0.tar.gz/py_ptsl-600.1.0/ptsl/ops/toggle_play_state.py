from ptsl.ops import Operation


class TogglePlayState(Operation):
    pass


class ToggleRecordEnable(Operation):
    pass


class PlayHalfSpeed(Operation):
    pass


class RecordHalfSpeed(Operation):
    pass
