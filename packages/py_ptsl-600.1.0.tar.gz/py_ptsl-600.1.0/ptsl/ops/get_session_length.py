from ptsl.ops import Operation


class GetSessionLength(Operation):
    pass
