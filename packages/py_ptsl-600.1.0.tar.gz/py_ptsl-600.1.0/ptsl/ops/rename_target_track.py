from ptsl.ops import Operation


class RenameTargetTrack(Operation):
    pass
