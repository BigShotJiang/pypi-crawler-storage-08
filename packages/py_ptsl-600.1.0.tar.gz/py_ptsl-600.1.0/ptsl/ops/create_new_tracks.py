from ptsl.ops import Operation


class CreateNewTracks(Operation):
    pass
