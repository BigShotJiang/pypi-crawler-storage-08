from ptsl.ops import Operation


class ExportSessionInfoAsText(Operation):
    pass
