from ptsl.ops import Operation


class Clear(Operation):
    pass
