from ptsl.ops import Operation


class CloseSession(Operation):
    pass
