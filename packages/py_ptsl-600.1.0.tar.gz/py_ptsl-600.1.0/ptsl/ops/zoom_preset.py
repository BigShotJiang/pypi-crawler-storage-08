from ptsl.ops import Operation


class RecallZoomPreset(Operation):
    pass
