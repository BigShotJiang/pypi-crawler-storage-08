from ptsl.ops import Operation


class GetPTSLVersion(Operation):
    pass
