from ptsl.ops import Operation


class SetSessionBitDepth(Operation):
    pass
