from ptsl.ops import Operation


class CreateSession(Operation):
    pass
