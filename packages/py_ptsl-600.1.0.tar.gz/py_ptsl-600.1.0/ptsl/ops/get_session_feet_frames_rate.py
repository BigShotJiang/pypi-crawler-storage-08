from ptsl.ops import Operation


class GetSessionFeetFramesRate(Operation):
    pass
