from ptsl.ops import Operation


class CutSpecial(Operation):
    pass
