from ptsl.ops import Operation


class SetSessionLength(Operation):
    pass
