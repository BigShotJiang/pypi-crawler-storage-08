from ptsl.ops import Operation


class HostReadyCheck(Operation):
    pass
