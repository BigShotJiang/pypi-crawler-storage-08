from ptsl.ops import Operation


class GetSessionName(Operation):
    pass
