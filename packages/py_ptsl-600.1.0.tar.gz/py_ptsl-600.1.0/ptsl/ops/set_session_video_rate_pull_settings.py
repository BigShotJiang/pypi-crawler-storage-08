from ptsl.ops import Operation


class SetSessionVideoRatePullSettings(Operation):
    pass
