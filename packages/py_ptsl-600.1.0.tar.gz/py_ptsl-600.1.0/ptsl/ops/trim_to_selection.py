from ptsl.ops import Operation


class TrimToSelection(Operation):
    pass
