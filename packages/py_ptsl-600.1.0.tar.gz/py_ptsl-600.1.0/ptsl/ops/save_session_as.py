from ptsl.ops import Operation


class SaveSessionAs(Operation):
    pass
