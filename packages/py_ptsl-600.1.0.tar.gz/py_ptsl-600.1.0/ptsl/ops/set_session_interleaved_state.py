from ptsl.ops import Operation


class SetSessionInterleavedState(Operation):
    pass
