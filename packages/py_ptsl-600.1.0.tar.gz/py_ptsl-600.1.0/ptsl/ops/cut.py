from ptsl.ops import Operation


class Cut(Operation):
    pass
