from ptsl.ops import Operation


class GetSessionBitDepth(Operation):
    pass
