from ptsl.ops import Operation


class CopySpecial(Operation):
    pass
