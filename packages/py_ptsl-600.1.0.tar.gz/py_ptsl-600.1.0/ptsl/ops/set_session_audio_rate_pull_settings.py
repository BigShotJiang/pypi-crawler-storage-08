from ptsl.ops import Operation


class SetSessionAudioRatePullSettings(Operation):
    pass
