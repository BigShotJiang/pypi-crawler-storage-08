from ptsl.ops import Operation


class RefreshTargetAudioFiles(Operation):
    pass
