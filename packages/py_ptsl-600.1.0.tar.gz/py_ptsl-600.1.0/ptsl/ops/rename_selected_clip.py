from ptsl.ops import Operation


class RenameSelectedClip(Operation):
    pass
