from ptsl.ops import Operation


class ExportSelectedTracksAsAAFOMF(Operation):
    pass
