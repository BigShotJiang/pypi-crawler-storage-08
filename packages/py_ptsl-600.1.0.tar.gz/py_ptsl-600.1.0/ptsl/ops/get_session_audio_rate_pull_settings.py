from ptsl.ops import Operation


class GetSessionAudioRatePullSettings(Operation):
    pass
