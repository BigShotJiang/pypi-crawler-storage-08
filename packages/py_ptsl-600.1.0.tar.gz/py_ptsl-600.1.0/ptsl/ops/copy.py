from ptsl.ops import Operation


class Copy(Operation):
    pass
