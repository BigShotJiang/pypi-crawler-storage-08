from ptsl.ops import Operation


class GetTaskStatus(Operation):
    pass
