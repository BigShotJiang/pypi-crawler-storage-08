from .operation import Operation


class ExtendSelectionToTargetTracks(Operation):
    pass
