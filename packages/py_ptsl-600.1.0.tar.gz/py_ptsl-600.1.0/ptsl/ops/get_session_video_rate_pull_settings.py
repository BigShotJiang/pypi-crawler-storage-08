from ptsl.ops import Operation


class GetSessionVideoRatePullSettings(Operation):
    pass
