from ptsl.ops import Operation


class RenameTargetClip(Operation):
    pass
