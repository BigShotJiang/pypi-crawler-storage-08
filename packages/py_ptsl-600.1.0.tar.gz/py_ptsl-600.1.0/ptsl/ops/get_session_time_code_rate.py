from ptsl.ops import Operation


class GetSessionTimeCodeRate(Operation):
    pass
