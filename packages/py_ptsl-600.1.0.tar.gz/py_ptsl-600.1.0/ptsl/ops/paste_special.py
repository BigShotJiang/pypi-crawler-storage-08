from ptsl.ops import Operation


class PasteSpecial(Operation):
    pass
