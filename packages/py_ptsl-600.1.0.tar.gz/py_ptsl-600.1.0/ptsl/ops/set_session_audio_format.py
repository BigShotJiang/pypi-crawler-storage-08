from ptsl.ops import Operation


class SetSessionAudioFormat(Operation):
    pass
