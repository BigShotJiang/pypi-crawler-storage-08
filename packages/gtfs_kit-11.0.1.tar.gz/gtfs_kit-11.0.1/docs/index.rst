.. GTFS Toolkit documentation master file, created by
   sphinx-quickstart on Mon Jun 23 15:19:33 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

GTFS Kit |version| Documentation
========================================

.. toctree::
   :maxdepth: 2

   introduction
   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

