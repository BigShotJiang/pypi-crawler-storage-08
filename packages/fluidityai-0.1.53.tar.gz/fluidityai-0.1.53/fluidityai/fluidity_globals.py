def minPostcodeLen(p):
    if len(p) >= 5:
        return True
    
    return False

