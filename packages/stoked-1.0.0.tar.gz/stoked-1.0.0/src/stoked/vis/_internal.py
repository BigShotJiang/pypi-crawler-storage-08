from collections import namedtuple

import numpy as np

patches = namedtuple("patches", ["patches_type", "args", "size"])


def atleast(array, dim, length, dtype=None):
    """Given an n-dimensional array, return either an n or n+1 dimensional repeated array
    array      input array (or scalar)
    dim        dimension of the returned array (must be n or n+1)
    dtype      array datatype (default None).
    """
    ret = np.asarray(np.atleast_1d(array), dtype=dtype)
    if dim not in (ret.ndim, ret.ndim + 1):
        raise ValueError(f"dim = {dim} is invalid with input dim = {ret.ndim}")

    if len(ret.shape) == dim and ret.shape[0] != length:
        ret = np.repeat(ret, length)
    elif len(ret.shape) != dim:
        ret = np.array([ret] * length)

    return ret
