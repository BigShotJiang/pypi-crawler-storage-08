from typing import List

__version__ = "2.16.0"
version_info = [int(x) for x in __version__.split(".")]

__all__: List[str] = []
