string = "\z"  # [syntax-error]
