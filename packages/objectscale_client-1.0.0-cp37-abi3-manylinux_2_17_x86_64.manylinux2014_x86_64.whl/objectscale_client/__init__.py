from .objectscale_client import *

__doc__ = objectscale_client.__doc__
if hasattr(objectscale_client, "__all__"):
    __all__ = objectscale_client.__all__