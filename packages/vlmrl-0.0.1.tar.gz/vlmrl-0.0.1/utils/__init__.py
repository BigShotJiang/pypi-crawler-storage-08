"""Utility modules for training and evaluation."""
