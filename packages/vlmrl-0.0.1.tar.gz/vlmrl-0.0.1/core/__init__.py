"""Core training and sampling modules."""
