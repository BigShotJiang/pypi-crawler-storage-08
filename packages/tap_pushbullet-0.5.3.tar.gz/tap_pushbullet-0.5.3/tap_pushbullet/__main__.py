"""Tap executable."""

from __future__ import annotations

from tap_pushbullet.tap import TapPushbullet

TapPushbullet.cli()
