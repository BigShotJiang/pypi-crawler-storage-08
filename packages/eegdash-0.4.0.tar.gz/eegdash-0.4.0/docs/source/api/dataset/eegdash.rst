eegdash package
===============

.. automodule:: eegdash
   :members:
   :noindex:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   eegdash.dataset
   eegdash.features
   eegdash.hbn

Submodules
----------

.. toctree::
   :maxdepth: 4

   eegdash.api
   eegdash.bids_eeg_metadata
   eegdash.const
   eegdash.data_utils
   eegdash.downloader
   eegdash.logging
   eegdash.mongodb
   eegdash.paths
   eegdash.utils
