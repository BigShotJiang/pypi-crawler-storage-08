..
   This file is auto-generated during the Sphinx build.
   Do not edit by hand; changes will be overwritten.

eegdash.dataset.DS004844
========================

.. currentmodule:: eegdash.dataset

.. autoclass:: eegdash.dataset.DS004844
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :member-order: bysource

Dataset Information
-------------------

- **Dataset ID:** ``DS004844``
- **Summary:** Modality: Multisensory | Type: Decision-making
- **Number of Subjects:** 17
- **Number of Recordings:** 68
- **Number of Tasks:** 1
- **Number of Channels:** 64
- **Sampling Frequencies:** 1024
- **Total Duration (hours):** 21.252
- **Dataset Size:** 22.33 GB
- **OpenNeuro:** `ds004844 <https://openneuro.org/datasets/ds004844>`__
- **NeMAR:** `ds004844 <https://nemar.org/dataexplorer/detail?dataset_id=ds004844>`__

=========  =======  =======  ==========  ==========  =============  ========
dataset      #Subj    #Chan    #Classes    Freq(Hz)    Duration(H)  Size
=========  =======  =======  ==========  ==========  =============  ========
ds004844        17       64           1        1024         21.252  22.33 GB
=========  =======  =======  ==========  ==========  =============  ========


Usage Example
-------------

.. code-block:: python

   from eegdash.dataset import DS004844

   dataset = DS004844(cache_dir="./data")

   print(f"Number of recordings: {len(dataset)}")

   if len(dataset):
       recording = dataset[0]
       raw = recording.load()
       print(f"Sampling rate: {raw.info['sfreq']} Hz")
       print(f"Channels: {len(raw.ch_names)}")


See Also
--------

* :class:`eegdash.dataset.EEGDashDataset`
* :mod:`eegdash.dataset`
* `OpenNeuro dataset page <https://openneuro.org/datasets/ds004844>`__
* `NeMAR dataset page <https://nemar.org/dataexplorer/detail?dataset_id=ds004844>`__

