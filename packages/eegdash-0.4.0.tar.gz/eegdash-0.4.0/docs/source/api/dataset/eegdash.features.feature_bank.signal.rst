eegdash.features.feature\_bank.signal module
============================================

.. automodule:: eegdash.features.feature_bank.signal
   :members:
   :noindex:
   :show-inheritance:
   :undoc-members:
