..
   This file is auto-generated during the Sphinx build.
   Do not edit by hand; changes will be overwritten.

eegdash.dataset.DS003574
========================

.. currentmodule:: eegdash.dataset

.. autoclass:: eegdash.dataset.DS003574
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :member-order: bysource

Dataset Information
-------------------

- **Dataset ID:** ``DS003574``
- **Summary:** Modality: Visual | Type: Affect | Subjects: Healthy
- **Number of Subjects:** 18
- **Number of Recordings:** 18
- **Number of Tasks:** 1
- **Number of Channels:** 64
- **Sampling Frequencies:** 500
- **Total Duration (hours):** 0.0
- **Dataset Size:** 14.79 GB
- **OpenNeuro:** `ds003574 <https://openneuro.org/datasets/ds003574>`__
- **NeMAR:** `ds003574 <https://nemar.org/dataexplorer/detail?dataset_id=ds003574>`__

=========  =======  =======  ==========  ==========  =============  ========
dataset      #Subj    #Chan    #Classes    Freq(Hz)    Duration(H)  Size
=========  =======  =======  ==========  ==========  =============  ========
ds003574        18       64           1         500              0  14.79 GB
=========  =======  =======  ==========  ==========  =============  ========


Usage Example
-------------

.. code-block:: python

   from eegdash.dataset import DS003574

   dataset = DS003574(cache_dir="./data")

   print(f"Number of recordings: {len(dataset)}")

   if len(dataset):
       recording = dataset[0]
       raw = recording.load()
       print(f"Sampling rate: {raw.info['sfreq']} Hz")
       print(f"Channels: {len(raw.ch_names)}")


See Also
--------

* :class:`eegdash.dataset.EEGDashDataset`
* :mod:`eegdash.dataset`
* `OpenNeuro dataset page <https://openneuro.org/datasets/ds003574>`__
* `NeMAR dataset page <https://nemar.org/dataexplorer/detail?dataset_id=ds003574>`__

