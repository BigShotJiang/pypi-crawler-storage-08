eegdash.hbn.windows module
==========================

.. automodule:: eegdash.hbn.windows
   :members:
   :noindex:
   :show-inheritance:
   :undoc-members:
