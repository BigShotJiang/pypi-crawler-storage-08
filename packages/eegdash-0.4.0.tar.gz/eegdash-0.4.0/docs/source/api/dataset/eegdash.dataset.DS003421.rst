..
   This file is auto-generated during the Sphinx build.
   Do not edit by hand; changes will be overwritten.

eegdash.dataset.DS003421
========================

.. currentmodule:: eegdash.dataset

.. autoclass:: eegdash.dataset.DS003421
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :member-order: bysource

Dataset Information
-------------------

- **Dataset ID:** ``DS003421``
- **Summary:** Modality: Multisensory | Type: Decision-making | Subjects: Healthy
- **Number of Subjects:** 20
- **Number of Recordings:** 80
- **Number of Tasks:** 1
- **Number of Channels:** 257
- **Sampling Frequencies:** 1000
- **Total Duration (hours):** 11.604
- **Dataset Size:** 76.77 GB
- **OpenNeuro:** `ds003421 <https://openneuro.org/datasets/ds003421>`__
- **NeMAR:** `ds003421 <https://nemar.org/dataexplorer/detail?dataset_id=ds003421>`__

=========  =======  =======  ==========  ==========  =============  ========
dataset      #Subj    #Chan    #Classes    Freq(Hz)    Duration(H)  Size
=========  =======  =======  ==========  ==========  =============  ========
ds003421        20      257           1        1000         11.604  76.77 GB
=========  =======  =======  ==========  ==========  =============  ========


Usage Example
-------------

.. code-block:: python

   from eegdash.dataset import DS003421

   dataset = DS003421(cache_dir="./data")

   print(f"Number of recordings: {len(dataset)}")

   if len(dataset):
       recording = dataset[0]
       raw = recording.load()
       print(f"Sampling rate: {raw.info['sfreq']} Hz")
       print(f"Channels: {len(raw.ch_names)}")


See Also
--------

* :class:`eegdash.dataset.EEGDashDataset`
* :mod:`eegdash.dataset`
* `OpenNeuro dataset page <https://openneuro.org/datasets/ds003421>`__
* `NeMAR dataset page <https://nemar.org/dataexplorer/detail?dataset_id=ds003421>`__

