..
   This file is auto-generated during the Sphinx build.
   Do not edit by hand; changes will be overwritten.

eegdash.dataset.DS002680
========================

.. currentmodule:: eegdash.dataset

.. autoclass:: eegdash.dataset.DS002680
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :member-order: bysource

Dataset Information
-------------------

- **Dataset ID:** ``DS002680``
- **Summary:** Modality: Visual | Type: Motor | Subjects: Healthy
- **Number of Subjects:** 14
- **Number of Recordings:** 350
- **Number of Tasks:** 1
- **Number of Channels:** 31
- **Sampling Frequencies:** 1000
- **Total Duration (hours):** 21.244
- **Dataset Size:** 9.22 GB
- **OpenNeuro:** `ds002680 <https://openneuro.org/datasets/ds002680>`__
- **NeMAR:** `ds002680 <https://nemar.org/dataexplorer/detail?dataset_id=ds002680>`__

=========  =======  =======  ==========  ==========  =============  =======
dataset      #Subj    #Chan    #Classes    Freq(Hz)    Duration(H)  Size
=========  =======  =======  ==========  ==========  =============  =======
ds002680        14       31           1        1000         21.244  9.22 GB
=========  =======  =======  ==========  ==========  =============  =======


Usage Example
-------------

.. code-block:: python

   from eegdash.dataset import DS002680

   dataset = DS002680(cache_dir="./data")

   print(f"Number of recordings: {len(dataset)}")

   if len(dataset):
       recording = dataset[0]
       raw = recording.load()
       print(f"Sampling rate: {raw.info['sfreq']} Hz")
       print(f"Channels: {len(raw.ch_names)}")


See Also
--------

* :class:`eegdash.dataset.EEGDashDataset`
* :mod:`eegdash.dataset`
* `OpenNeuro dataset page <https://openneuro.org/datasets/ds002680>`__
* `NeMAR dataset page <https://nemar.org/dataexplorer/detail?dataset_id=ds002680>`__

