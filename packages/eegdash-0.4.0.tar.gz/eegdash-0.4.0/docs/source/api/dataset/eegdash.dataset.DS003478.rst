..
   This file is auto-generated during the Sphinx build.
   Do not edit by hand; changes will be overwritten.

eegdash.dataset.DS003478
========================

.. currentmodule:: eegdash.dataset

.. autoclass:: eegdash.dataset.DS003478
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :member-order: bysource

Dataset Information
-------------------

- **Dataset ID:** ``DS003478``
- **Summary:** Modality: Resting State | Type: Resting state | Subjects: Healthy
- **Number of Subjects:** 122
- **Number of Recordings:** 243
- **Number of Tasks:** 1
- **Number of Channels:** 64
- **Sampling Frequencies:** 500
- **Total Duration (hours):** 23.57
- **Dataset Size:** 10.65 GB
- **OpenNeuro:** `ds003478 <https://openneuro.org/datasets/ds003478>`__
- **NeMAR:** `ds003478 <https://nemar.org/dataexplorer/detail?dataset_id=ds003478>`__

=========  =======  =======  ==========  ==========  =============  ========
dataset      #Subj    #Chan    #Classes    Freq(Hz)    Duration(H)  Size
=========  =======  =======  ==========  ==========  =============  ========
ds003478       122       64           1         500          23.57  10.65 GB
=========  =======  =======  ==========  ==========  =============  ========


Usage Example
-------------

.. code-block:: python

   from eegdash.dataset import DS003478

   dataset = DS003478(cache_dir="./data")

   print(f"Number of recordings: {len(dataset)}")

   if len(dataset):
       recording = dataset[0]
       raw = recording.load()
       print(f"Sampling rate: {raw.info['sfreq']} Hz")
       print(f"Channels: {len(raw.ch_names)}")


See Also
--------

* :class:`eegdash.dataset.EEGDashDataset`
* :mod:`eegdash.dataset`
* `OpenNeuro dataset page <https://openneuro.org/datasets/ds003478>`__
* `NeMAR dataset page <https://nemar.org/dataexplorer/detail?dataset_id=ds003478>`__

