﻿eegdash.api
===========

.. automodule:: eegdash.api
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   
   .. rubric:: Classes

   .. autosummary::
   
      EEGDash
      EEGDashDataset
   
