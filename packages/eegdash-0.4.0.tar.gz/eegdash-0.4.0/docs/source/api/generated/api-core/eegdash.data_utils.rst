﻿eegdash.data\_utils
===================

.. automodule:: eegdash.data_utils
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   
   .. rubric:: Classes

   .. autosummary::
   
      EEGDashBaseDataset
      EEGBIDSDataset
      EEGDashBaseRaw
   
