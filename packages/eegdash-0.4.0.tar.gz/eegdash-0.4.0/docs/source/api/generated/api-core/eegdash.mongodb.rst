﻿eegdash.mongodb
===============

.. automodule:: eegdash.mongodb
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   
   .. rubric:: Classes

   .. autosummary::
   
      MongoConnectionManager
   
