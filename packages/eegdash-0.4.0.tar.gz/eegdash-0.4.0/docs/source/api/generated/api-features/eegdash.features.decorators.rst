﻿eegdash.features.decorators
===========================

.. automodule:: eegdash.features.decorators
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   
   .. rubric:: Functions

   .. autosummary::
   
      bivariate_feature
   
   .. rubric:: Classes

   .. autosummary::
   
      BivariateFeature
      Callable
      DirectedBivariateFeature
      FeatureExtractor
      FeatureKind
      FeaturePredecessor
      MultivariateFeature
      UnivariateFeature
   
