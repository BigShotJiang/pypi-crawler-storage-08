﻿eegdash.features.serialization
==============================

.. automodule:: eegdash.features.serialization
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   
   .. rubric:: Functions

   .. autosummary::
   
      delayed
      load_features_concat_dataset
      read_info
   
   .. rubric:: Classes

   .. autosummary::
   
      FeaturesConcatDataset
      FeaturesDataset
      Parallel
      Path
   
