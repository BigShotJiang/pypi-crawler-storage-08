﻿eegdash.features.datasets
=========================

.. automodule:: eegdash.features.datasets
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   
   .. rubric:: Functions

   .. autosummary::
   
      delayed
   
   .. rubric:: Classes

   .. autosummary::
   
      BaseConcatDataset
      Callable
      EEGWindowsDataset
      FeaturesConcatDataset
      FeaturesDataset
      Parallel
   
