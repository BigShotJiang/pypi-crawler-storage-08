﻿eegdash.features.extractors
===========================

.. automodule:: eegdash.features.extractors
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   
   .. rubric:: Functions

   .. autosummary::
   
      abstractmethod
   
   .. rubric:: Classes

   .. autosummary::
   
      ABC
      BivariateFeature
      Callable
      DirectedBivariateFeature
      Dispatcher
      FeatureExtractor
      MultivariateFeature
      TrainableFeature
      UnivariateFeature
      partial
   
