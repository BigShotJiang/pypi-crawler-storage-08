.. title:: Dataset landscape

.. rubric:: Dataset landscape

.. raw:: html

   <figure class="eegdash-figure" style="margin: 0 0 1.25rem 0;">

.. raw:: html
   :file: ../_static/dataset_generated/dataset_bubble.html

.. raw:: html

   <figcaption class="eegdash-caption">
     Figure: Dataset landscape. Each bubble represents a dataset: x-axis shows the number of records,
     y-axis the number of subjects, bubble area encodes on-disk size, and color indicates dominant modality.
     Hover for details and use the legend to highlight modality groups.
   </figcaption>
   </figure>
