"""
Test suite for frappeye - comprehensive testing for all components.

Provides unit tests, integration tests, and performance benchmarks
to ensure frappeye operates correctly and efficiently.
"""