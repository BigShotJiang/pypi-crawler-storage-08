# from typing import Optional

# from vllm.v1.worker.gpu_input_batch import CachedRequestState, InputBatch

# from ..sampling import NNsightSamplingMetadata, NNsightSamplingParams


# class NNsightInputBatch(InputBatch):
    
    
    
#     def add_request(self, request: CachedRequestState, req_index: Optional[int] = None) -> None:
#         print("add_request")
#         super().add_request(request, req_index)        
#     def _make_sampling_metadata(self) -> NNsightSamplingMetadata:
#         print("make_sampling_metadata")
#         return super()._make_sampling_metadata()
        
        