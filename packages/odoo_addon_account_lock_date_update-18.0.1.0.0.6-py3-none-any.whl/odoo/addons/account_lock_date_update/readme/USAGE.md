To use this module, you need to be a Billing Administrator and go to:

- Invoicing -\> Accounting -\> Lock Dates
- Change values and click on **Update** button
