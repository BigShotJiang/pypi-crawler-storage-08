Allow an Account adviser to update accounting lock dates.
