from forestadmin.datasource_toolkit.exceptions import ForestException


class AgentToolkitException(ForestException):
    STATUS = 500
