from forestadmin.agent_toolkit.exceptions import AgentToolkitException


class CollectionResourceException(AgentToolkitException):
    STATUS = 400
