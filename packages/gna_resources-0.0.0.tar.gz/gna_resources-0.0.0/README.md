# gna_resources\nA dummy Python package version of gna_resources.
