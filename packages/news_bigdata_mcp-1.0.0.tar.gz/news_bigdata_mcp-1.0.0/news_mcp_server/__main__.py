"""News MCP Server 主入口"""

from news_mcp_server.server import main

if __name__ == "__main__":
    main()

