"""News MCP Server - 舆情大数据 MCP 服务"""

__version__ = "1.0.0"

