from .pkg import *  # Import everything from pkg.py
# OR be more specific:
# from .pkg import YourMainClass, your_main_function

__version__ = "1.0.0"