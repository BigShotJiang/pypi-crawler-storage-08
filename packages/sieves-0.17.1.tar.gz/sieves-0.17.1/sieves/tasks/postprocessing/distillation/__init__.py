"""Distillation."""

from .types import DistillationFramework, DistillationFrameworkLiteral

__all__ = ["DistillationFramework", "DistillationFrameworkLiteral"]
