from .getcounterproxymetrics import getcounterproxymetricsMethods

class MetricsMethods(
	getcounterproxymetricsMethods
):
	pass
