from .list import listMethods

class ProxyProvidersMethods(
	listMethods
):
	pass
