from .get import getMethods

class CountersMethods(
	getMethods
):
	pass
