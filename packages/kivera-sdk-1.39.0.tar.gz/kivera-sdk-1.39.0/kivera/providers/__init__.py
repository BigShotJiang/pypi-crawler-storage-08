from .get import getMethods
from .list import listMethods

class ProvidersMethods(
	getMethods,
	listMethods
):
	pass
