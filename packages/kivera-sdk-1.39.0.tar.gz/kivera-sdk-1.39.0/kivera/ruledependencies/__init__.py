from .attach import attachMethods
from .get import getMethods

class RuleDependenciesMethods(
	attachMethods,
	getMethods
):
	pass
