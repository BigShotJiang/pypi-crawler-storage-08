from .get import getMethods

class RuleDependencyResourcesMethods(
	getMethods
):
	pass
