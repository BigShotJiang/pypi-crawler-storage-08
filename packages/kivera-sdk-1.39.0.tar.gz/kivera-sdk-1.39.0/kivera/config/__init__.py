from .get import getMethods

class ConfigMethods(
	getMethods
):
	pass
