from .list import listMethods

class ProviderVersionsMethods(
	listMethods
):
	pass
