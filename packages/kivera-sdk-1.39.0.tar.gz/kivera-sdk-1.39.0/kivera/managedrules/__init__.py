from .list import listMethods

class ManagedRulesMethods(
	listMethods
):
	pass
