from .list import listMethods

class PlansMethods(
	listMethods
):
	pass
