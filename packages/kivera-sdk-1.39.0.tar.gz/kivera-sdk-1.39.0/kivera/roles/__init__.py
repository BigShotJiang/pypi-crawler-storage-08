from .list import listMethods

class RolesMethods(
	listMethods
):
	pass
