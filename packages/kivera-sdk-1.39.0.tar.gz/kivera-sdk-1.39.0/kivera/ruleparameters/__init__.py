from .get import getMethods

class RuleParametersMethods(
	getMethods
):
	pass
