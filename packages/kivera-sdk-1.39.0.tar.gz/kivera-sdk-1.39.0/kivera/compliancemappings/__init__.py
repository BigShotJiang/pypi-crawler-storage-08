from .list import listMethods

class ComplianceMappingsMethods(
	listMethods
):
	pass
