from .list import listMethods

class GlobalServicesMethods(
	listMethods
):
	pass
