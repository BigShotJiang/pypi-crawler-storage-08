"""
The overall effort's name is
`Boring Math <https://pypi.org/project/boring-math/>`_.

- it is a collection of my mathematical hobby projects
- each project's PyPI and GitHub names begin with *"boring-math-"*
- each project implements a top-level package in the ``boring_math`` Python namespace
- for links to all the Boring Math project PyPI and GitHub repos `click here
  <https://github.com/grscheller/boring-math/blob/main/README.md>`_

"""
