# Ideas

For future directions.

## Connecting the dots

Fitting data to a discrete set of points.

### Extending "any" function over ℕ to ℝ

- Using forward differences
- See this [YouTube](https://www.youtube.com/watch?v=hkn9zeRuzHs)

### Extending a function over ℕ to ℝ preserving a property

- like the gamma function
- using preliminary ideas from preceding topic

### Splines

- need to research more
