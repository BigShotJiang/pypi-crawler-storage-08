#!/usr/bin/env python
"""
Tests for the `openedx-authz` models module.
"""

import pytest


@pytest.mark.skip(
    reason="Placeholder to allow pytest to succeed before real tests are in place."
)
def test_placeholder():
    """
    TODO: Delete this test once there are real tests.
    """
