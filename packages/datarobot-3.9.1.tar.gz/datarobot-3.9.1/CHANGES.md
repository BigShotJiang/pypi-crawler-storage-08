# Python client changelog

## 3.9.1

### New features

- Added {class}`CustomApplication <datarobot.models.custom_application.CustomApplication>` to manage custom applications with detailed resource information and operational controls.
- Added {class}`CustomApplicationSource <datarobot.models.custom_application_source.CustomApplicationSource>` to manage custom application sources (templates for creating custom applications).
- Added optional parameter `version_id=None` to {meth}`Files.download <datarobot.models.Files.download>` and {meth}`Files.list_contained_files <datarobot.models.Files.list_contained_files>` to allow non-blocking upload.
- Promoted {class}`FilesStage <datarobot.models.FilesStage>` out of experimental.
- Added {meth}`Files.clone <datarobot.models.Files.clone>`, {meth}`Files.create_stage <datarobot.models.Files.create_stage>`, {meth}`Files.apply_stage <datarobot.models.Files.apply_stage>` and {meth}`Files.copy <datarobot.models.Files.copy>`, which were previously experimental.
- Added {class}`DataRobotAppFrameworkBaseSettings <datarobot.utils.config.DataRobotAppFrameworkBaseSettings>` as a [Pydantic Settings](https://docs.pydantic.dev/latest/concepts/pydantic_settings/)  class for managing configurations for agentic workflows and applications.

### Enhancements

- Improved the string representation of {class}`RESTClientObject <datarobot.rest.RESTClientObject>` to include endpoint and client version.

## 3.9.0

### New features

- Added {class}`OtelMetricConfig <datarobot.models.otel.metric_config.OtelMetricConfig>` to manage and control the display of OpenTelemetry metric configurations for an entity.
- Added {class}`OtelLogEntry <datarobot.models.otel.logs.OtelLogEntry>` to list the OpenTelemetry logs associated with an entity.
- Added {class}`OtelMetricSummary <datarobot.models.otel.metric_summary.OtelMetricSummary>` to list the reported OpenTelemetry metrics associated with an entity.
- Added {class}`OtelMetricValue <datarobot.models.otel.metric_values.OtelMetricValue>` to list the OpenTelemetry metric values associated with an entity.
- Added {class}`LLMGatewayCatalog <datarobot.models.genai.llm_gateway_catalog>` to get available LLMs from the LLM Gateway.
- Added {class}`ResourceBundle <datarobot.models.resource_bundle.ResourceBundle>` to list defined resource bundles.

### Enhancements

- Added {meth}`CustomTemplate.create <datarobot.models.custom_template.CustomTemplate.create>` to allow users to create a new `CustomTemplate`.
- Updated {meth}`CustomTemplate.list <datarobot.models.custom_template.CustomTemplate.list>` to accept additional parameters for `publisher`, `category`, and `show_hidden` for improved queries.
- Updated {meth}`CustomTemplate.update <datarobot.models.custom_template.CustomTemplate.update>` to accept additional parameters for `file`, `enabled`, and `is_hidden` to set additional fields.
- Added `is_hidden` member to {class}`CustomTemplate <datarobot.models.custom_template.CustomTemplate>` to align with server data.
- Added `custom_metric_metadata` member to {class}`TemplateMetadata <datarobot.models.custom_template.TemplateMetadata>` to allow creating custom-metric templates using APIObjects.
- Added {meth}`CustomTemplate.download_content <datarobot.models.custom_template.CustomTemplate.download_content>` to allow users to download content associated with an `items` file.
- Added new attribute `spark_instance_size`  to {class}`RecipeSettings <datarobot.models.RecipeSettings>`.
- Added `set_default_credential` to {meth}`DataStore.test <datarobot.models.DataStore.test>` to set the provided credential as default when the connection test is successful.
- Added optional parameter `data_type` to {meth}`Connector.list <datarobot.models.Connector.list>` to list connectors which support specified data type.
- Added optional parameter `data_type` to {meth}`DataStore.list <datarobot.models.DataStore.list>` to list data stores which support specified data type.
- Added optional parameters `retrieval_mode` and `maximal_marginal_relevance_lambda` to {class}`VectorDatabaseSettings <datarobot.models.genai.llm_blueprint.VectorDatabaseSettings>` to select the retrieval mode.
- Added optional parameter `wait_for_completion=True` to {meth}`Files.upload <datarobot.models.Files.upload>` and {meth}`Files.create_from_url <datarobot.models.Files.create_from_url>` to allow non-blocking upload.
- Added support for `file` to {meth}`UseCase.add <datarobot.UseCase.add>` and {meth}`UseCase.remove <datarobot.UseCase.remove>`.
- Added {class}`GridSearchArguments <datarobot.models.advanced_tuning.GridSearchArguments>` with {meth}`GridSearchArguments.to_api_payload <GridSearchArguments.to_api_payload>` for creating grid search arguments for advanced tuning jobs.
- Added {class}`GridSearchSearchType <datarobot.enums.GridSearchSearchType>`. An enum to define supported grid search types.
- Added {class}`GridSearchAlgorithm <datarobot.enums.GridSearchAlgorithm>`. An enum to define supported grid search algorithms.
- Added optional parameters `include_agentic`, `is_agentic`, `for_playground`, and `for_production` to {meth}`ModerationTemplate.list <datarobot.models.moderation.template.ModerationTemplate>` to include/filter for agentic templates and to fetch templates specific to playground or production.
- Improved equality comparison for {class}`APIObject <datarobot.models.api_object.APIObject>` to only look at API related fields.
- Added optional parameters `tag_keys` and `tag_values` to {meth}`Deployment.list <datarobot.Deployment.list>` to filter search results by tags.

### Bugfixes

- Fixed validator errors in {class}`EvaluationDatasetMetricAggregation <datarobot.models.genai.evaluation_dataset_metric_aggregation.EvaluationDatasetMetricAggregation>`.
- Fixed {meth}`Files.download` to download a correct file from the files container.
- Fixed the enum values of {class}`ModerationGuardOotbType <datarobot.enums.ModerationGuardOotbType>`.
- Fixed a bug where {meth}`ModerationTemplate.find <datarobot.models.moderation.template.ModerationTemplate>` was unable to find a template when given a name.
- Fixed a bug where {meth}`OverallModerationConfig.find <datarobot.models.moderation.overall.OverallModerationConfig>` was unable to find a given entity's overall moderation config.

### Documentation changes

- Added OCREngineSpecificParameters, DataRobotOCREngineType and DataRobotArynOutputFormat to OCR job resources section

## 3.8.0

This release adds support for Notebooks and Codespaces and unstructured data in the Data Registry, and the Chunking Service v2. There are improvements related to playgrounds, vector databases, agentic workflows, incremental learning, and datasets. This release focuses heavily on file management capabilities.

There are two new package extras: `auth` and `auth-authlib`. The `auth` extra provides OAuth2 support, while the `auth-authlib` extra provides OAuth2 support using the Authlib library.

### New features

#### GenAI

- Added `AGENTIC_WORKFLOW` target type.
- Added {meth}`VectorDatabase.send_to_custom_model_workshop <datarobot.models.genai.vector_database.VectorDatabas.send_to_custom_model_workshop>` to create a new custom model from a vector database.
- Added {meth}`VectorDatabase.deploy <datarobot.models.genai.vector_database.VectorDatabas.deploye>` to create a new deployment from a vector database.
- Added optional parameters `vector_database_default_prediction_server_id`, `vector_database_prediction_environment_id`, `vector_database_maximum_memory`, `vector_database_resource_bundle_id`, `vector_database_replicas`, and `vector_database_network_egress_policy` to {meth}`LLMBlueprint.register_custom_model <datarobot.models.genai.llm_blueprint.LLMBlueprint.register_custom_model>` to allow specifying resources in cases where we automatically deploy a vector database when this function is called.
- Added {class}`ReferenceToolCall <datarobot.models.genai.agent.reference_tool_call.ReferenceToolCall>` for creating tool calls in the evaluation dataset.
- Added {class}`ReferenceToolCalls <datarobot.models.genai.agent.reference_tool_call_configuration.ReferenceToolCalls>` to represent a list of tool calls in the evaluation dataset.
- Added {meth}`VectorDatabase.update_connected <datarobot.models.genai.vector_database.VectorDatabase.update_connected>` to add a dataset and optional additional metadata to a connected vector database.

#### Notebooks and Codespaces

The Notebook and Codespace APIs are now GA and the related classes have been promoted to the stable client.

- Changed name of the {class}`Notebook <datarobot.models.notebooks.notebook.Notebook>` `run()` method to be {meth}`Notebook.run_as_job <datarobot.models.notebooks.notebook.Notebook.run_as_job>`.
- Added support for Codespaces to the {meth}`Notebook.is_finished_executing <datarobot.models.notebooks.notebook.Notebook.is_finished_executing>` method.
- Added the {meth}`NotebookKernel.get <datarobot.models.notebooks.kernel.NotebookKernel.get>` method.
- Added the {meth}`NotebookScheduledJob.cancel <datarobot.models.notebooks.scheduled_job.NotebookScheduledJob.cancel>` method.
- Added the {meth}`NotebookScheduledJob.list <datarobot.models.notebooks.scheduled_job.NotebookScheduledJob.list>` method.
- Added the {meth}`Notebook.list_schedules <datarobot.models.notebooks.notebook.Notebook.list_schedules>` method.

#### Unstructured Data

The client now supports unstructured data in the Data Registry.

- Added the {class}`Files <datarobot.Files>` class to manage files on the DataRobot platform. The class supports file metadata including the description, creation date, and creator information.
  - Use {meth}`Files.get <datarobot.Files.get>` to retrieve file information.
  - Use {meth}`Files.upload <datarobot.Files.upload>` as a convenient facade method to upload files from URLs, file paths, or file objects (does not support DataFrames).
  - Use {meth}`Files.create_from_url <datarobot.Files.create_from_url>` to upload a new file from a URL.
  - Use {meth}`Files.create_from_file <datarobot.Files.create_from_file>` to upload a new file from a local file or file-like object.
  - Use {meth}`Files.create_from_data_source <datarobot.Files.create_from_data_source>` to create a new file from a DataSource.
  - Use {meth}`Files.list_files <datarobot.Files.list_files>` to retrieve all individual files contained within a Files object. This is useful for `Files` objects ingested from archives that contain multiple files.
  - Use {meth}`Files.download <datarobot.Files.download>` to download a file's contents.
  - Use {meth}`Files.modify <datarobot.Files.modify>` to update a file's name, description, and/or tags.
  - Use {meth}`Files.update <datarobot.Files.update>` to refresh a file object with the latest information from the server.
  - Use {meth}`Files.delete <datarobot.Files.delete>` to soft-delete a file.
  - Use {meth}`Files.un_delete <datarobot.Files.un_delete>` to restore a previously deleted file.
  - Use {meth}`Files.search_catalog <datarobot.Files.search_catalog>` to search for files in the catalog based on name, tags, or other criteria.
- Added the {class}`FilesCatalogSearch <datarobot.FilesCatalogSearch>` class to represent file catalog search results with metadata such as catalog name, creator, and tags.
- Added the {class}`File <datarobot.Files.File>` class to represent individual files within a Files archive. The class provides information about individual files such as name, size, and path within the archive.

#### OAuth

The client provides better support for OAuth2 authorization workflows in applications using the DataRobot platform. These features are available in the datarobot.auth module.

- Added the methods {meth}`set_authorization_context <datarobot.models.genai.agent.auth.set_authorization_context>` and {meth}`get_authorization_context <datarobot.models.genai.agent.auth.get_authorization_context>` to handle context needed for OAuth access token management.
- Added the decorator {meth}`datarobot_tool_auth <datarobot.models.genai.agent.auth.datarobot_tool_auth>` to inject OAuth access tokens into the agent tool functions.

#### Other Features

- Introduced support for Chunking Service V2. The `chunking_service_v2` classes have been moved out of the experimental directory and are now available to all users.
- Added {meth}`Model.continue_incremental_learning_from_incremental_model <datarobot.models.Model.continue_incremental_learning_from_incremental_model>` to continue training of the incremental learning model.
- Added optional parameter `chunk_definition_id` in {meth}`Model.start_incremental_learning_from_sample <datarobot.models.Model.start_incremental_learning_from_sample>` to begin training using new chunking service.
- Added a new attribute `snapshot_policy` to {class}`datarobot.models.RecipeDatasetInput` to specify the snapshot policy to use.
- Added a new attribute `dataset_id` to {class}`datarobot.models.JDBCTableDataSourceInput` to specify the exact dataset ID to use.
- Added {meth}`Dataset.create_version_from_recipe <datarobot.models.Dataset.create_version_from_recipe>` to create a new dataset version based on the Recipe.

### Enhancements

- Added the `use_tcp_keepalive` parameter to {class}`Client <datarobot.client.Client>` to enable TCP keep-alive packets when connections are timing out, enabled by default.
- Enabled {class}`Playground <datarobot.models.genai.playground.Playground>` to create agentic playgrounds via input param `playground_type=PlaygroundType.AGENTIC`.
- Extended {meth}`PlaygroundOOTBMetricConfiguration.create <datarobot.models.genai.ootb_metric_configuration.PlaygroundOOTBMetricConfiguration.create>` with additional reference column names for agentic metrics.
- Updated {meth}`CustomTemplate.list <datarobot.models.custom_template.CustomTemplate.list>` to return all custom templates when no offset is specified.
- Extended {meth}`MetricInsights.list <datarobot.models.genai.metric_insights.MetricInsights.list>` with the option to pass `llm_blueprint_ids`.
- Extended {class}`OOTBMetricConfigurationRequest <datarobot.models.genai.ootb_metric_configuration.OOTBMetricConfigurationRequest>` and {class}`OOTBMetricConfigurationResponse <datarobot.models.genai.ootb_metric_configuration.OOTBMetricConfigurationResponse>` with support for `extra_metric_settings`, which provides an additional configuration option for the Tool Call Accuracy metric.
- Extended {meth}`VectorDatabase.create <datarobot.models.genai.vector_database.VectorDatabase.create>` to support creation of connected vector databases via input param `external_vector_database_connection`.
- Extended {meth}`VectorDatabase.create <datarobot.models.genai.vector_database.VectorDatabase.create>` to support an additional metadata dataset via input params `metadata_dataset_id` and `metadata_combination_strategy`.
- Extended {meth}`VectorDatabase.update <datarobot.models.genai.vector_database.VectorDatabase.update>` to support updating the credential used to access a connected vector database via input param `credential_id`.
- Extended {meth}`VectorDatabase.download_text_and_embeddings_asset <datarobot.models.genai.vector_database.VectorDatabase.download_text_and_embeddings_asset>` to support downloading additional files via input param `part`.
- Added a new attribute `engine_specific_parameters` to {class}`datarobot.models.OCRJobResource` to specify OCR engine specific parameters.
- Added `docker_image_uri` to {class}`datarobot.ExecutionEnvironmentVersion`.
- Added optional parameter `docker_image_uri` to {meth}`ExecutionEnvironmentVersion.create <datarobot.ExecutionEnvironment.create>`.
- Changed parameter `docker_context_path` in {meth}`ExecutionEnvironmentVersion.create <datarobot.ExecutionEnvironment.create>` to be optional.
- Added a new attribute `image_id` to {class}`datarobot.ExecutionEnvironmentVersion`.

### Bugfixes

- Fixed {meth}`PlaygroundOOTBMetricConfiguration.create <datarobot.models.genai.ootb_metric_configuration.PlaygroundOOTBMetricConfiguration.create>` by using the right payload for `customModelLLMValidationId` instead of `customModelLlmValidationId`.
- Fixed {class}`datarobot.models.RecipeDatasetInput` to use correct fields for `to_api`.
- Fixed {meth}`EvaluationDatasetConfiguration.create <datarobot.models.genai.evaluation_dataset_configuration.EvaluationDatasetConfiguration.create>` to use the correct payload for `is_synthetic_dataset`.

### Deprecation summary

- Remove unreleased Insight configuration routes.  These were replaced with the new {class}`MetricInsights <datarobot.models.genai.metric_insights.MetricInsights>` class, and insight specific configurations.
- `Deployment.create_from_learning_model <datarobot.models.deployment.Deployment.create_from_learning_model>` method is deprecated. Please first register the leaderboard model with `RegisteredModelVersion.create_for_leaderboard_item <datarobot.models.model_registry.registered_model_version.RegisteredModelVersion.create_for_leaderboard_item>`, then create a deployment with `Deployment.create_from_registered_model_version <datarobot.models.deployment.Deployment.create_from_registered_model_version>`.

### Documentation changes

- Updated the example for GenAI to show creation of a metric aggregation job.

### Experimental changes

- Added {class}`VectorDatabase <datarobot._experimental.models.genai.vector_database.>` with a new attribute `external_vector_database_connection` added to the {meth}`VectorDatabase.create` method.
- Added attribute `version` to {class}`DatasetInfo <datarobot._experimental.models.chunking_service_v2.DatasetInfo>` to identify the analysis version.
- Added attribute `dataset_definition_info_version` to {class}`ChunkDefinition <datarobot._experimental.models.chunking_service_v2.ChunkDefinition>` to identify the analysis information version.
- Added a `version` query parameter to the {class}`DatasetDefinition <datarobot._experimental.models.chunking_service_v2.DatasetDefinition>` class, allowing users to specify the analysis version in the `get` method.
- Added {class}`DatasetDefinitionInfoHistory <datarobot._experimental.models.chunking_service_v2.DatasetDefinitionInfoHistory>` with the {meth}`DatasetDefinitionInfoHistory.list <datarobot._experimental.models.chunking_service_v2.DatasetDefinitionInfoHistory.list>` method to retrieve a list of dataset information history records.
- Added the {meth}`DatasetDefinitionInfoHistory.list_versions <datarobot._experimental.models.chunking_service_v2.DatasetDefinitionInfoHistory.list_versions>` method to retrieve a list of dataset information records.

## 3.7.0

### New features

- The DataRobot Python Client now supports Python 3.12 and Python 3.13.
- Added {meth}`Deployment.get_retraining_settings <datarobot.models.Deployment.get_retraining_settings>` to retrieve retraining settings.
- Added {meth}`Deployment.update_retraining_settings <datarobot.models.Deployment.update_retraining_settings>` to update retraining settings.
- Updated {class}`RESTClientObject <datarobot.rest.RESTClientObject>` to retry requests when the server returns a 104 connection reset error.
- Added support for `datasphere` as an intake and output type in batch predictions.
- Added {meth}`Deployment.get_accuracy_metrics_settings <datarobot.models.Deployment.get_accuracy_metrics_settings>` to retrieve accuracy metrics settings.
- Added {meth}`Deployment.update_accuracy_metrics_settings <datarobot.models.Deployment.update_accuracy_metrics_settings>` to update accuracy metrics settings.
- Added {class}`CustomMetricValuesOverSpace <datarobot.models.deployment.custom_metrics.CustomMetricValuesOverSpace>` to retrieve custom metric values over space.
- Added {meth}`CustomMetric.get_values_over_space <datarobot.models.deployment.custom_metrics.CustomMetric.get_values_over_space>` to retrieve custom metric values over space.
- Created {class}`ComplianceDocTemplateProjectType <datarobot.enums.ComplianceDocTemplateProjectType>`, an enum to define project type supported by the compliance documentation custom template.
- Added attribute `project_type` to {class}`ComplianceDocTemplate <datarobot.models.compliance_doc_template.ComplianceDocTemplate>` to identify the template supported project type.
- Added optional parameter `project_type` in {meth}`ComplianceDocTemplate.get_default <datarobot.models.compliance_doc_template.ComplianceDocTemplate.get_default>` to retrieve the project type's default template.
- Added optional parameter `project_type` in {meth}`ComplianceDocTemplate.create <datarobot.models.compliance_doc_template.ComplianceDocTemplate.create>` to specify the project type supported by the template to create.
- Added optional parameter `project_type` in {meth}`ComplianceDocTemplate.create_from_json_file <datarobot.models.compliance_doc_template.ComplianceDocTemplate.create_from_json_file>` to specify the project type supported by the template to create.
- Added optional parameter `project_type` in {meth}`ComplianceDocTemplate.update <datarobot.models.compliance_doc_template.ComplianceDocTemplate.update>` to allow updating an existing template's project type.
- Added optional parameter `project_type` in {meth}`ComplianceDocTemplate.list <datarobot.models.compliance_doc_template.ComplianceDocTemplate.list>` to allow to filtering/searching by template's project type.
- Added {meth}`ShapMatrix.get_as_csv <datarobot.insights.shap_matrix.ShapMatrix.get_as_csv>` to retrieve SHAP matrix results as a CSV file.
- Added {meth}`ShapMatrix.get_as_dataframe <datarobot.insights.shap_matrix.ShapMatrix.get_as_dataframe>` to retrieve SHAP matrix results as a dataframe.
- Added a new class {class}`LiftChart <datarobot.insights.lift_chart.LiftChart>` to interact with lift chart insights.
- Added a new class {class}`RocCurve <datarobot.insights.roc_curve.RocCurve>` to interact with ROC curve insights.
- Added a new class {class}`Residuals <datarobot.insights.residuals.Residuals>` to interact with residuals insights.
- Added {meth}`Project.create_from_recipe <datarobot.models.Project.create_from_recipe>` to create Feature Discovery projects using recipes.
- Added an optional parameter `recipe_type` to {meth}`datarobot.models.Recipe.from_dataset` to create Wrangling recipes.
- Added an optional parameter `recipe_type` to {meth}`datarobot.models.Recipe.from_data_store` to create Wrangling recipes.
- Added {meth}`Recipe.set_recipe_metadata <datarobot.models.Recipe.set_recipe_metadata>` to update recipe metadata.
- Added an optional parameter `snapshot_policy` to {meth}`datarobot.models.Recipe.from_dataset` to specify the snapshot policy to use.
- Added new attributes `prediction_point`, `relationships_configuration_id` and `feature_discovery_supervised_feature_reduction` to {class}`RecipeSettings <datarobot.models.Recipe>`.
- Added several optional parameters to {class}`ExecutionEnvironment <datarobot.ExecutionEnvironment>` for `list`, `create` and `update` methods.
- Added optional parameter `metadata_filter` to {meth}`ComparisonPrompt.create <datarobot.models.genai.comparison_prompt.ComparisonPrompt.create>`.
- Added {meth}`CustomInferenceModel.share <datarobot.CustomInferenceModel.share>` to update access control settings for a custom model.
- Added {meth}`CustomInferenceModel.get_access_list <datarobot.CustomInferenceModel.get_access_list>` to retrieve access control settings for a custom model.
- Added new attribute `latest_successful_version` to {class}`ExecutionEnvironment <datarobot.ExecutionEnvironment>`.
- Added {meth}`Dataset.create_from_project <datarobot.models.Dataset.create_from_project>` to create datasets from project data.
- Added {meth}`ExecutionEnvironment.share <datarobot.ExecutionEnvironment.share>` to update access control settings for an execution environment.
- Added {meth}`ExecutionEnvironment.get_access_list <datarobot.ExecutionEnvironment.get_access_list>` to retrieve access control settings an execution environment.
- Created {class}`ModerationTemplate <datarobot.models.moderation.template.ModerationTemplate>` to interact with LLM moderation templates.
- Created {class}`ModerationConfiguration <datarobot.models.moderation.template.ModerationConfiguration>` to interact with LLM moderation configuration.
- Created {class}`CustomTemplate <datarobot.models.custom_templates.CustomTemplate>` to interact with custom-templates elements.
- Extended the advanced options available when setting a target to include parameter: 'feature_engineering_prediction_point'(part of the AdvancedOptions object).
- Added optional parameter `substitute_url_parameters` to {class}`DataStore <datarobot.models.DataStore` for `list` and `get` methods.
- Added {meth}`Model.start_incremental_learning_from_sample <datarobot.models.Model.start_incremental_learning_from_sample>` to initialize the incremental learning model and begin training using the chunking service. Requires the "Project Creation from a Dataset Sample" feature flag.
- Added {class}`NonChatAwareCustomModelValidation <datarobot.models.genai.custom_model_validation.NonChatAwareCustomModelValidation>` as the base class for {class}`CustomModelVectorDatabaseValidation <datarobot.models.genai.vector_database.CustomModelVectorDatabaseValidation>` and {class}`CustomModelEmbeddingValidation <datarobot.models.genai.custom_model_embedding_validation.CustomModelEmbeddingValidation>`.
  In contrast, {class}`CustomModelLLMValidation <datarobot.models.genai.custom_model_llm_validation.CustomModelLLMValidation>` now implements the `create` and `update` methods differently to interact with the deployments that support the chat completion API.
- Added optional parameter `chat_model_id` to {meth}`CustomModelLLMValidation.create <datarobot.models.genai.custom_model_llm_validation.CustomModelLLMValidation.create>` and {meth}`CustomModelLLMValidation.update <datarobot.models.genai.custom_model_llm_validation.CustomModelLLMValidation.update>` to allow adding deployed LLMs that support the chat completion API.
- Fixed {class}`ComparisonPrompt <datarobot.models.genai.comparison_prompt.ComparisonPrompt>` not being able to load errored comparison prompt results.
- Added optional parameters `retirement_date`, `is_deprecated`, and `is_active` to {class}`LLMDefinition <datarobot.models.genai.llm.LLMDefinition>` and added an optional parameter `llm_is_deprecated` to the {class}`MetricMetadata <datarobot.models.genai.chat_prompt.MetricMetadata>` to expose LLM deprecation and retirement-related information.

### Enhancements

- Added {meth}`Deployment.share <datarobot.models.Deployment.share>` as an alias for {meth}`Deployment.update_shared_roles <datarobot.models.Deployment.update_shared_roles>`.
- Internally use the existing input argument `max_wait` in `CustomModelVersion.clean_create <datarobot.CustomModelVersion.create_clean>`, to set the READ request timeout.

### Bugfixes

- Made `user_id` and `username` fields in `management_meta` optional for {class}`PredictionEnvironment <datarobot.models.PredictionEnvironment>` to support API responses without these fields.
- Fixed the enum values of {class}`ComplianceDocTemplateType <datarobot.enums.ComplianceDocTemplateType>`.
- Fixed the enum values of {class}`WranglingOperations <datarobot.enums.WranglingOperations>`.
- Fixed the enum values of {class}`DataWranglingDialect <datarobot.enums.DataWranglingDialect>`.
- Playground id parameter is no longer optional in {meth}`EvaluationDatasetConfiguration.list <datarobot.models.genai.evaluation_dataset_configuration.EvaluationDatasetConfiguration.list>`
- Copy insights path fixed in {meth}`MetricInsights.copy_to_playground <datarobot.models.genai.metric_insights.MetricInsights.copy_to_playground>`
- Missing fields for prompt_type and warning were added to {class}`PromptTrace <datarobot.models.genai.prompt_trace.PromptTrace>`.
- Fixed a query parameter name in {meth}`SidecarModelMetricValidation.list <datarobot.models.genai.sidecar_model_metric.SidecarModelMetricValidation.list>`.
- Fix typo in attribute {class}`VectorDatabase <datarobot.models.genai.vector_database.VectorDatabase>`: `metadata_columns` which was `metada_columns`
- Do not camelCase `metadata_filter` dict in {meth}`ChatPrompt.create <datarobot.models.genai.chat_prompt.ChatPrompt.create>`
- Fixed a Use Case query parameter name in {meth}`CustomModelLLMValidation.list <datarobot.models.genai.custom_model_llm_validation.CustomModelLLMValidation.list>`, {meth}`CustomModelEmbeddingValidation.list <datarobot.models.genai.custom_model_embedding_validation.CustomModelEmbeddingValidation.list>`, and {meth}`CustomModelVectorDatabaseValidation.list <datarobot.models.genai.vector_database.CustomModelVectorDatabaseValidation.list>`.
- Fixed `featureDiscoverySettings` parameter name in {meth}`RelationshipsConfiguration.create <datarobot.models.relationships_configuration.RelationshipsConfiguration>` and {meth}`RelationshipsConfiguration.replace <datarobot.models.relationships_configuration.RelationshipsConfiguration>`.

### API changes

- Method {meth}`CustomModelLLMValidation.create <datarobot.models.genai.custom_model_llm_validation.CustomModelLLMValidation.create>` no longer requires the `prompt_column_name` and `target_column_name` parameters, and can accept an optional `chat_model_id` parameter. The parameter order has changed. If the custom model LLM deployment supports the chat completion API, it is recommended to use `chat_model_id` now instead of (or in addition to) specifying the column names.

### Deprecation summary

- Removed the deprecated `capabilities` attribute of {class}`Deployment <datarobot.models.Deployment>`.
- Method {meth}`Model.request_lift_chart <datarobot.models.Model.request_lift_chart>` is deprecated and will be removed in favor of {meth}`LiftChart.compute <datarobot.insights.lift_chart.LiftChart.compute>`.
- Method {meth}`Model.get_lift_chart <datarobot.models.Model.get_lift_chart>` is deprecated and will be removed in favor of {meth}`LiftChart.get <datarobot.insights.lift_chart.LiftChart.get>`.
- Method {meth}`Model.get_all_lift_charts <datarobot.models.Model.get_all_lift_charts>` is deprecated and will be removed in favor of {meth}`LiftChart.list <datarobot.insights.lift_chart.LiftChart.list>`.
- Method {meth}`Model.request_roc_curve <datarobot.models.Model.request_roc_curve>` is deprecated and will be removed in favor of {meth}`RocCurve.compute <datarobot.insights.roc_curve.RocCurve.compute>`.
- Method {meth}`Model.get_roc_curve <datarobot.models.Model.get_roc_curve>` is deprecated and will be removed in favor of {meth}`RocCurve.get <datarobot.insights.roc_curve.RocCurve.get>`.
- Method {meth}`Model.get_all_roc_curves <datarobot.models.Model.get_all_roc_curves>` is deprecated and will be removed in favor of {meth}`RocCurve.list <datarobot.insights.roc_curve.RocCurve.list>`.
- Method {meth}`Model.request_residuals_chart <datarobot.models.Model.request_residuals_chart>` is deprecated and will be removed in favor of {meth}`Residuals.compute <datarobot.insights.residuals.Residuals.compute>`.
- Method {meth}`Model.get_residuals_chart <datarobot.models.Model.get_residuals_chart>` is deprecated and will be removed in favor of {meth}`Residuals.get <datarobot.insights.residuals.Residuals.get>`.
- Method {meth}`Model.get_all_residuals_charts <datarobot.models.Model.get_all_residuals_charts>` is deprecated and will be removed in favor of {meth}`Residuals.list <datarobot.insights.residuals.Residuals.list>`.

### Documentation changes

- Starting with this release, Python client documentation will be available at <https://docs.datarobot.com/> as well as on ReadTheDocs. Content has been reorganized to support this change.
- Removed `numpydoc` as a dependency. Docstring parsing has been handled by `sphinx.ext.napoleon` since 3.6.0.
- Fix issues with how the Table of Contents is rendered on ReadTheDocs. `sphinx-external-toc` is now a dev dependency.
- Fix minor issues with formatting across the ReadTheDocs site.
- Updated docs on Anomaly Assessment objects to remove duplicate information.

### Experimental changes

- Added `use_case` and `deployment_id` properties to {class}`RetrainingPolicy <datarobot._experimental.models.retraining.RetrainingPolicy>` class.
- Added `create` and `update_use_case` methods to {class}`RetrainingPolicy <datarobot._experimental.models.retraining.RetrainingPolicy>` class.
- Renamed the method 'train_first_incremental_from_sample' to 'start_incremental_learning_from_sample'.
  Added new parameters : 'early_stopping_rounds' and 'first_iteration_only'.
- Added the `credentials_id` parameter to the `create` method in {class}`ChunkDefinition <datarobot._experimental.models.chunking_service_v2.DatasetDefinition>`.
- Bugfix the `next_run_time` property of the {class}`NotebookScheduledJob <datarobot.models.notebooks.NotebookScheduledJob>` class to be nullable.
- Added the `highlight_whitespace` property to the {class}`NotebookSettings <datarobot.models.notebooks.NotebookSettings>`.
- Create new directory specifically for notebooks in the experimental portion of the client.
- Added methods to the {class}`Notebook <datarobot.models.notebooks.notebook.Notebook>` class to work with session: `start_session()`, `stop_session()`, `get_session_status()`, `is_running()`.
- Added methods to the {class}`Notebook <datarobot.models.notebooks.notebook.Notebook>` in order to execute and check related execution status: `execute()`, `get_execution_status()`, `is_finished_executing()`.
- Added {meth}`Notebook.create_revision <datarobot.models.notebooks.notebook.Notebook.create_revision>` to the Notebook class in order to create revisions.
- Moved `ModerationTemplate` class to {class}`ModerationTemplate <datarobot.models.moderation.template.ModerationTemplate>`.
- Moved `ModerationConfiguration` class to {class}`ModerationConfiguration <datarobot.models.moderation.template.ModerationConfiguration>` to interact with LLM moderation configuration.
- Updates to {meth}`Notebook.run <datarobot.models.notebooks.notebook.Notebook.run>` method in the Notebook class in order to encourage proper usage as well as add more descriptive TypedDict as annotation.
- Added {meth}`NotebookScheduledJob.get_most_recent_run <datarobot.models.notebooks.scheduled_job.NotebookScheduledJob.get_most_recent_run>` to the NotebookScheduledJob class to aid in more idiomatic code when dealing with manual runs.
- Updates to {meth}`Notebook.run <datarobot.models.notebooks.notebook.Notebook.execute>` method in the Notebook class in order to support Codespace Notebook execution as well as multiple related new classes and methods to expand API coverage which is needed for the underlying execution.
- Added {meth}`ExecutionEnvironment.assign_environment <datarobot.models.notebooks.execution_environment.ExecutionEnvironment.assign_environment>` to the ExecutionEnvironment class, which gives the ability to assign or update a notebook's environment.
- Removed deprecated experimental method `Model.get_incremental_learning_metadata`.
- Removed deprecated experimental method `Model.start_incremental_learning`.

## 3.6.0

### New features

- Added {class}`OCRJobResource <datarobot.models.ocr_job_resource.OCRJobResource>` for running OCR jobs.
- Added new Jina V2 embedding model in VectorDatabaseEmbeddingModel.
- Added new Small MultiLingual Embedding Model in VectorDatabaseEmbeddingModel.
- Added {meth}`Deployment.get_segment_attributes <datarobot.models.Deployment.get_segment_attributes>` to retrieve segment attributes.
- Added {meth}`Deployment.get_segment_values <datarobot.models.Deployment.get_segment_values>` to retrieve segment values.
- Added {meth}`AutomatedDocument.list_all_available_document_types <datarobot.models.automated_documentation.AutomatedDocument.list_all_available_document_types>` to return a list of document types.
- Added {meth}`Model.request_per_class_fairness_insights <datarobot.models.Model.request_per_class_fairness_insights>` to return per-class bias & fairness insights.
- Added {class}`MLOpsEvent <datarobot.mlops.events.MLOpsEvent>` to report MLOps Events.  Currently supporting `moderation` MLOps events only
- Added {meth}`Deployment.get_moderation_events <datarobot.models.Deployment.get_moderation_events>` to retrieve moderation events for that deployment.
- Extended the advanced options available when setting a target to include new
  parameter: 'number_of_incremental_learning_iterations_before_best_model_selection'(part of the AdvancedOptions object).
  This parameter allows you to specify how long top 5 models will run for prior to best model selection.
- Add support for 'connector_type' in :meth:\` Connector.create \<datarobot.models.Connector.create>\`.
- Deprecate file_path for :meth:\` Connector.create \<datarobot.models.Connector.create>\` and :meth:\` Connector.update \<datarobot.models.Connector.update>\`.
- Added {class}`DataQualityExport <datarobot.models.deployment.data_exports.DataQualityExport>` and {meth}`Deployment.list_data_quality_exports <datarobot.models.Deployment.list_data_quality_exports>` to retrieve a list of data quality records.
- Added secure config support for Azure Service Principal credentials.
- Added support for categorical custom metrics in {class}`CustomMetric <datarobot.models.deployment.custom_metrics.CustomMetric>`.
- Added {class}`NemoConfiguration <datarobot.models.genai.nemo_configuration.NemoConfiguration>` to manage Nemo configurations.
- Added {meth}`NemoConfiguration.create <datarobot.models.genai.nemo_configuration.NemoConfiguration.upsert>` to create or update a Nemo configuration.
- Added {meth}`NemoConfiguration.get <datarobot.models.genai.nemo_configuration.NemoConfiguration.get>` to retrieve a Nemo configuration.
- Added a new class {class}`ShapDistributions <datarobot.insights.ShapDistributions>` to interact with SHAP distribution insights.
- Added the `MODEL_COMPLIANCE_GEN_AI` value to the attribute `document_type` from {class}`DocumentOption <datarobot.models.automated_documentation.DocumentOption>` to generate compliance documentation for LLMs in the Registry.
- Added new attribute `prompts_count` to {class}`Chat <datarobot.models.genai.chat.Chat>`.
- Added {class}`Recipe <datarobot.models.recipe.Recipe>` modules for Data Wrangling.
- Added :class: `RecipeOperation <datarobot.models.recipe_operation.RecipeOperation>` and a set of subclasses to represent a single `Recipe.operations` operation.
- Added new attribute `similarity_score` to {class}`Citation <datarobot.models.genai.chat_prompt.Citation>`.
- Added new attributes `retriever` and `add_neighbor_chunks` to {class}`VectorDatabaseSettings <datarobot.models.genai.llm_blueprint.VectorDatabaseSettings>`.
- Added new attribute `metadata` to {class}`Citation <datarobot.models.genai.chat_prompt.Citation>`.
- Added new attribute `metadata_filter` to {class}`ChatPrompt <datarobot.models.genai.chat_prompt.ChatPrompt>`.
- Added new attribute `metadata_filter` to {class}`ComparisonPrompt <datarobot.models.genai.comparison_prompt.ComparisonPrompt>`.
- Added new attribute `custom_chunking` to {class}`ChunkingParameters <datarobot.models.genai.vector_database.ChunkingParameters>`.
- Added new attribute `custom_chunking` to {class}`VectorDatabase <datarobot.models.genai.vector_database.VectorDatabase>`.
- Added a new class {class}`LLMTestConfiguration <datarobot.models.genai.llm_test_configuration.LLMTestConfiguration>` for LLM test configurations.
  {meth}`LLMTestConfiguration.get <datarobot.models.genai.llm_test_configuration.LLMTestConfiguration.get>` to retrieve a hosted LLM test configuration.
  {meth}`LLMTestConfiguration.list <datarobot.models.genai.llm_test_configuration.LLMTestConfiguration.list>` to list hosted LLM test configurations.
  {meth}`LLMTestConfiguration.create <datarobot.models.genai.llm_test_configuration.LLMTestConfiguration.create>` to create an LLM test configuration.
  {meth}`LLMTestConfiguration.update <datarobot.models.genai.llm_test_configuration.LLMTestConfiguration.update>` to update an LLM test configuration.
  {meth}`LLMTestConfiguration.delete <datarobot.models.genai.llm_test_configuration.LLMTestConfiguration.delete>` to delete an LLM test configuration.
- Added a new class {class}`LLMTestConfigurationSupportedInsights <datarobot.models.genai.llm_test_configuration.LLMTestConfigurationSupportedInsights>` for LLM test configuration supported insights.
  {meth}`LLMTestConfigurationSupportedInsights.list <datarobot.models.genai.llm_test_configuration.LLMTestConfigurationSupportedInsights.list>` to list hosted LLM test configuration supported insights.
- Added a new class {class}`LLMTestResult <datarobot.models.genai.llm_test_result.LLMTestResult>` for LLM test results.
  {meth}`LLMTestResult.get <datarobot.models.genai.llm_test_result.LLMTestResult.get>` to retrieve a hosted LLM test result.
  {meth}`LLMTestResult.list <datarobot.models.genai.llm_test_result.LLMTestResult.list>` to list hosted LLM test results.
  {meth}`LLMTestResult.create <datarobot.models.genai.llm_test_result.LLMTestResult.create>` to create an LLM test result.
  {meth}`LLMTestResult.delete <datarobot.models.genai.llm_test_result.LLMTestResult.delete>` to delete an LLM test result.
- Added new attribute `dataset_name` to {class}`OOTBDatasetDict <datarobot.models.genai.llm_test_configuration.OOTBDatasetDict>`.
- Added new attribute `rows_count` to {class}`OOTBDatasetDict <datarobot.models.genai.llm_test_configuration.OOTBDatasetDict>`.
- Added new attribute `max_num_prompts` to {class}`DatasetEvaluationDict <datarobot.models.genai.llm_test_configuration.DatasetEvaluationDict>`.
- Added new attribute `prompt_sampling_strategy` to {class}`DatasetEvaluationDict <datarobot.models.genai.llm_test_configuration.DatasetEvaluationDict>`.
- Added a new class {class}`DatasetEvaluationRequestDict <datarobot.models.genai.llm_test_configuration.DatasetEvaluationRequestDict>` for Dataset Evaluations in create/edit requests.
- Added new attribute `evaluation_dataset_name` to {class}`InsightEvaluationResult <datarobot.models.genai.llm_test_result.InsightEvaluationResult>`.
- Added new attribute `chat_name` to {class}`InsightEvaluationResult <datarobot.models.genai.llm_test_result.InsightEvaluationResult>`.
- Added new attribute `llm_test_configuration_name` to {class}`LLMTestResult <datarobot.models.genai.llm_test_result.LLMTestResult>`.
- Added new attribute `creation_user_name` to {class}`LLMTestResult <datarobot.models.genai.llm_test_result.LLMTestResult>`.
- Added new attribute `pass_percentage` to {class}`LLMTestResult <datarobot.models.genai.llm_test_result.LLMTestResult>`.
- Added new attribute `evaluation_dataset_name` to {class}`DatasetEvaluation <datarobot.models.genai.llm_test_configuration.DatasetEvaluation>`.
- Added new attribute `datasets_compatibility` to {class}`LLMTestConfigurationSupportedInsights <datarobot.models.genai.llm_test_configuration.LLMTestConfigurationSupportedInsights>`.
- Added a new class {class}`NonOOTBDataset <datarobot.models.genai.llm_test_configuration.NonOOTBDataset>` for non out-of-the-box (OOTB) dataset entities.
  {meth}`NonOOTBDataset.list <datarobot.models.genai.llm_test_configuration.NonOOTBDataset.list>` to retrieve non OOTB datasets for compliance testing.
- Added a new class {class}`OOTBDataset <datarobot.models.genai.llm_test_configuration.OOTBDataset>` for OOTB dataset entities.
  {meth}`OOTBDataset.list <datarobot.models.genai.llm_test_configuration.OOTBDataset.list>` to retrieve OOTB datasets for compliance testing.
- Added a new class {class}`TraceMetadata <datarobot.models.genai.prompt_trace.TraceMetadata>` to retrieve trace metadata.
- Add new attributes to {class}`VectorDatabase <datarobot.models.genai.vector_database.VectorDatabase>`: `parent_id`, `family_id`, `metadata_columns`, `added_dataset_ids`, `added_dataset_names`,  and\`version\`.
  {meth}`VectorDatabase.get_supported_retrieval_settings <datarobot.models.genai.vector_database.VectorDatabase.get_supported_retrieval_settings>` to retrieve supported retrieval settings.
  {meth}`VectorDatabase.submit_export_dataset_job <datarobot.models.genai.vector_database.VectorDatabase.submit_export_dataset_job>` to submit the vector database as dataset to the AI catalog.
- Updated the method {meth}`VectorDatabase.create <datarobot.models.genai.vector_database.VectorDatabase.create>` to create a new vector database version.
- Added a new class {class}`SupportedRetrievalSettings <datarobot.models.genai.vector_database.SupportedRetrievalSettings>` for supported vector database retrieval settings.
- Added a new class {class}`SupportedRetrievalSetting <datarobot.models.genai.vector_database.SupportedRetrievalSetting>` for supported vector database retrieval setting.
- Added a new class {class}`VectorDatabaseDatasetExportJob <datarobot.models.genai.vector_database.VectorDatabaseDatasetExportJob>` for vector database dataset export jobs.
- Added new attribute `playground_id` to {class}`CostMetricConfiguration <datarobot.models.genai.cost_metric_configurations.CostMetricConfiguration>`.
- Added new attribute `name` to {class}`CostMetricConfiguration <datarobot.models.genai.cost_metric_configurations.CostMetricConfiguration>`.
- Added a new class {class}`SupportedInsights <datarobot.models.genai.insights_configuration.SupportedInsights>` to support lists.
  : {meth}`SupportedInsights.list <datarobot.models.genai.insights_configuration.SupportedInsights.list>` to list supported insights.
- Added a new class {class}`MetricInsights <datarobot.models.genai.metric_insights.MetricInsights>` for the new metric insights routes.
  : {meth}`MetricInsights.list <datarobot.models.genai.metric_insights.MetricInsights.list>` to list metric insights.
    {meth}`MetricInsights.copy_to_playground <datarobot.models.genai.metric_insights.MetricInsights.copy_to_playground>` to copy metrics to another playground.
- Added a new class {class}`PlaygroundOOTBMetricConfiguration <datarobot.models.genai.ootb_metric_configuration.PlaygroundOOTBMetricConfiguration>` for OOTB metric configurations.
- Updated the schema for {class}`EvaluationDatasetMetricAggregation <datarobot.models.genai.evaluation_dataset_metric_aggregation.EvaluationDatasetMetricAggregation>` to include the new attributes `ootb_dataset_name`, `dataset_id` and `dataset_name`.
- Updated the method {meth}`EvaluationDatasetMetricAggregation.list <datarobot.models.genai.evaluation_dataset_metric_aggregation.EvaluationDatasetMetricAggregation.list>` with additional optional filter parameters.
- Added new attribute `warning` to {class}`OOTBDataset <datarobot.models.genai.llm_test_configuration.OOTBDataset>`.
- Added new attribute `warning` to {class}`OOTBDatasetDict <datarobot.models.genai.llm_test_configuration.OOTBDatasetDict>`.
- Added new attribute `warnings` to {class}`LLMTestConfiguration <datarobot.models.genai.llm_test_configuration.LLMTestConfiguration>`.
- Added a new parameter `playground_id` to {meth}`SidecarModelMetricValidation.create <datarobot.models.genai.sidecar_model_metric.SidecarModelMetricValidation.create>` to support sidecar model metrics transition to playground.
- Updated the schema for {class}`NemoConfiguration <datarobot.models.genai.nemo_configuration.NemoConfiguration>` to include the new attributes `prompt_pipeline_template_id` and `response_pipeline_template_id`.
- Added new attributes to {class}`EvaluationDatasetConfiguration <datarobot.models.genai.evaluation_dataset_configuration.EvaluationDatasetConfiguration>`: `rows_count`, `playground_id`.
- Fix retrieving `shap_remaining_total` when requesting predictions with SHAP insights. This should return the remaining shap values when present.

### API changes

- Updated `ServerError`'s `exc_message` to be constructed with a request ID to help with debugging.
- Added method {meth}`Deployment.get_capabilities <datarobot.models.Deployment.get_capabilities>` to retrieve a list of :class: `Capability <datarobot.models.deployment.Capability>` objects containing capability details.
- Advanced options parameters: `modelGroupId`, `modelRegimeId`, and `modelBaselines` were renamed into `seriesId`, `forecastDistance`, and `forecastOffsets`.
- Added the parameter `use_sample_from_dataset` from {meth}`Project.create_from_dataset<datarobot.models.Project.create_from_dataset>`. This parameter, when set, uses the EDA sample of the dataset to start the project.
- Added the parameter `quick_compute` to functions in the classes {class}`ShapMatrix <datarobot.insights.ShapMatrix>`, {class}`ShapImpact <datarobot.insights.ShapImpact>`, and {class}`ShapPreview <datarobot.insights.ShapPreview>`.
- Added the parameter `copy_insights` to {meth}`Playground.create <datarobot.models.genai.playground.Playground.create>` to copy the insights from existing Playground to the new one.
- Added the parameter `llm_test_configuration_ids`, {meth}`LLMBlueprint.register_custom_model <datarobot.models.genai.llm_blueprint.LLMBlueprint.register_custom_model>`, to run LLM compliance tests when a blueprint is sent to the custom model workshop.

### Enhancements

- Added standard pagination parameters (e.g. `limit`, `offset`) to {meth}`Deployment.list <datarobot.models.Deployment.list>`, allowing you to get deployment data in smaller chunks.
- Added the parameter `base_path` to {meth}`get_encoded_file_contents_from_paths <datarobot.helpers.binary_data_utils.get_encoded_file_contents_from_paths>` and {meth}`get_encoded_image_contents_from_paths <datarobot.helpers.binary_data_utils.get_encoded_image_contents_from_paths>`, allowing you to better control script behavior when using relative file paths.

### Bugfixes

- Fixed field in {class}`CustomTaskVersion <datarobot.models.custom_task_version.CustomTaskVersion>`
  for controlling network policies. This is changed from `outgoing_network_policy` to `outbound_network_policy`.
  When performing a `GET` action, this field was incorrect and always resolved to `None`. When attempting
  a `POST` or `PATCH` action, the incorrect field would result in a 422.
  Also changed the name of `datarobot.enums.CustomTaskOutgoingNetworkPolicy` to
  {class}`datarobot.enums.CustomTaskOutboundNetworkPolicy` to reflect the proper field name.
- Fixed schema for {class}`DataSliceSizeInfo <datarobot.models.data_slice.DataSliceSizeInfo>`, so it
  now allows an empty list for the `messages` field.

### Deprecation summary

- Removed the parameter `in_use` from {meth}`ImageAugmentationList.create<datarobot.models.visualai.ImageAugmentationList.create>`. This parameter was deprecated in v3.1.0.
- Deprecated {meth}`AutomatedDocument.list_available_document_types <datarobot.models.automated_documentation.AutomatedDocument.list_available_document_types>`. Please use {meth}`AutomatedDocument.list_all_available_document_types <datarobot.models.automated_documentation.AutomatedDocument.list_all_available_document_types>` instead.
- Deprecated {meth}`Model.request_fairness_insights <datarobot.models.Model.request_fairness_insights>`. Please use {meth}`Model.request_per_class_fairness_insights <datarobot.models.Model.request_per_class_fairness_insights>` instead, to return `StatusCheckJob` instead of `status_id`.
- Deprecated {meth}`Model.get_prime_eligibility <datarobot.models.Model.get_prime_eligibility>`. Prime models are no longer supported.
- `eligibleForPrime` field will no longer be returned from {meth}`Model.get_supported_capabilities<datarobot.models.Model.get_supported_capabilities>` and will be removed after version 3.8 is released.
- Deprecated the property `ShapImpact.row_count <datarobot.insights.ShapImpact.row_count>` and it will be removed after version 3.7 is released.
- Advanced options parameters: `modelGroupId`, `modelRegimeId`, and `modelBaselines` were renamed into `seriesId`, `forecastDistance`, and `forecastOffsets` and are deprecated and they will be removed after version 3.6 is released.
- Renamed `datarobot.enums.CustomTaskOutgoingNetworkPolicy` to {class}`datarobot.enums.CustomTaskOutboundNetworkPolicy` to reflect bug fix changes. The original enum was unusable.
- Removed parameter `user_agent_suffix` in `datarobot.Client`. Please use `trace_context` instead.
- Removed deprecated method `DataStore.get_access_list`. Please use {meth}`DataStore.get_shared_roles <datarobot.DataStore.get_shared_roles>` instead.
- Removed support for `SharingAccess` instances in {meth}`DataStore.update_access_list <datarobot.DataStore.share>`. Please use `SharingRole` instances instead.

### Configuration changes

- Removed upper bound pin on `urllib3` package to allow versions 2.0.2 and above.
- Upgraded the `Pillow` library to version 10.3.0. Users installing DataRobot with the "images" extra (`pip install datarobot[images]`) should note that this is a required library.

### Documentation changes

- The {ref}`API Reference page<pysdk-api-reference>` has been split into multiple sections for better usability.
- Fixed docs for {meth}`Project.refresh <datarobot.models.Project.refresh>` to clarify that it does not return a value.
- Fixed code example for {class}`ExternalScores <datarobot.models.external_dataset_scores_insights.external_scores.ExternalScores>`.
- Added copy button to code examples in ReadTheDocs documentation, for convenience.
- Removed the outdated 'examples' section from the documentation. Please refer to [DataRobot's API Documentation Home](https://docs.datarobot.com/en/docs/api/index.html) for more examples.
- Removed the duplicate 'getting started' section from the documentation.
- Updated to Sphinx RTD Theme v3.
- Updated the description for the parameter: 'number_of_incremental_learning_iterations_before_best_model_selection' (part of the AdvancedOptions object).

### Experimental changes

- Added the `force_update` parameter to the `update` method in {class}`ChunkDefinition <datarobot._experimental.models.chunking_service_v2.ChunkDefinition>`.
- Removed attribute `select_columns` from {class}`ChunkDefinition <datarobot._experimental.models.chunking_service_v2.ChunkDefinition>`
- Added initial experimental support for Chunking Service V2
  -{class}`DatasetDefinition <datarobot._experimental.models.chunking_service_v2.DatasetDefinition>`
  -{class}`DatasetProps <datarobot._experimental.models.chunking_service_v2.DatasetProps>`
  -{class}`DatasetInfo <datarobot._experimental.models.chunking_service_v2.DatasetInfo>`
  -{class}`DynamicDatasetProps <datarobot._experimental.models.chunking_service_v2.DynamicDatasetProps>`
  -{class}`RowsChunkDefinition <datarobot._experimental.models.chunking_service_v2.RowsChunkDefinition>`
  -{class}`FeaturesChunkDefinition <datarobot._experimental.models.chunking_service_v2.FeaturesChunkDefinition>`
  -{class}`ChunkDefinitionStats <datarobot._experimental.models.chunking_service_v2.ChunkDefinitionStats>`
  -{class}`ChunkDefinition <datarobot._experimental.models.chunking_service_v2.ChunkDefinition>`
- Added new method `update` to {class}`ChunkDefinition <datarobot._experimental.models.chunking_service_v2.ChunkDefinition>
- Added experimental support for time series wrangling, including usage template:
  - `datarobot._experimental.models.time_series_wrangling_template.user_flow_template`
    Experimental changes offer automated time series feature engineering for the data in Snowflake or Postgres.
- Added the ability to use the Spark dialect when creating a recipe, allowing data wrangling support for files.
- Added new attribute `warning` to {class}`Chat <datarobot.models.genai.chat.Chat>`.
- Moved all modules from `datarobot._experimental.models.genai` to `datarobot.models.genai`.
- Added a new method 'Model.train_first_incremental_from_sample' that will train first incremental learning iteration from existing sample model. Requires "Project Creation from a Dataset Sample" feature flag.

## 3.5.0

### New features

- Added support for BYO LLMs using serverless predictions in {class}`CustomModelLLMValidation <datarobot.models.genai.custom_model_llm_validation.CustomModelLLMValidation>`.

- Added attribute `creation_user_name` to {class}`LLMBlueprint <datarobot.models.genai.llm_blueprint.LLMBlueprint>`.

- Added a new class {class}`HostedCustomMetricTemplate <datarobot.models.deployment.custom_metrics.HostedCustomMetricTemplate>` for hosted custom metrics templates.
  {meth}`HostedCustomMetricTemplate.get <datarobot.models.deployment.custom_metrics.HostedCustomMetricTemplate.get>` to retrieve a hosted custom metric template.
  {meth}`HostedCustomMetricTemplate.list <datarobot.models.deployment.custom_metrics.HostedCustomMetricTemplate.list>` to list hosted custom metric templates.

- Added {meth}`Job.create_from_custom_metric_gallery_template <datarobot.models.registry.job.Job.create_from_custom_metric_gallery_template>` to create a job from a custom metric gallery template.

- Added a new class {class}`HostedCustomMetricTemplate <datarobot.models.deployment.custom_metrics.HostedCustomMetric>` for hosted custom metrics.
  : {meth}`HostedCustomMetric.list <datarobot.models.deployment.custom_metrics.HostedCustomMetric.list>` to list hosted custom metrics.
    {meth}`HostedCustomMetric.update <datarobot.models.deployment.custom_metrics.HostedCustomMetric.update>` to update a hosted custom metrics.
    {meth}`HostedCustomMetric.delete <datarobot.models.deployment.custom_metrics.HostedCustomMetric.delete>` to delete a hosted custom metric.
    {meth}`HostedCustomMetric.create_from_custom_job <datarobot.models.deployment.custom_metrics.HostedCustomMetric.create_from_custom_job>` to create a hosted custom metric from existing custom job.
    {meth}`HostedCustomMetric.create_from_template <datarobot.models.deployment.custom_metrics.HostedCustomMetric.create_from_template>` to create hosted custom metric from template.

- Added a new class {class}`datarobot.models.deployment.custom_metrics.HostedCustomMetricBlueprint` for hosted custom metric blueprints.
  : {meth}`HostedCustomMetricBlueprint.get <datarobot.models.deployment.custom_metrics.HostedCustomMetricBlueprint.get>` to get a hosted custom metric blueprint.
    {meth}`HostedCustomMetricBlueprint.create <datarobot.models.deployment.custom_metrics.HostedCustomMetricBlueprint.create>` to create a hosted custom metric blueprint.
    {meth}`HostedCustomMetricBlueprint.update <datarobot.models.deployment.custom_metrics.HostedCustomMetricBlueprint.update>` to update a hosted custom metric blueprint.

- Added {meth}`Job.list_schedules <datarobot.models.registry.job.Job.create_from_custom_metric_gallery_template>` to list job schedules.

- Added a new class {class}`JobSchedule <datarobot.models.registry.job.JobSchedule>` for the registry job schedule.
  : {meth}`JobSchedule.create <datarobot.models.registry.job.JobSchedule.create>` to create a job schedule.
    {meth}`JobSchedule.update <datarobot.models.registry.job.JobSchedule.update>` to update a job schedule.
    {meth}`JobSchedule.delete <datarobot.models.registry.job.JobSchedule.delete>` to delete a job schedule.

- Added attribute `credential_type` to {class}`RuntimeParameter <datarobot.models.custom_model_version.RuntimeParameter>`.

- Added a new class `EvaluationDatasetConfiguration <datarobot._experimental.models.genai.evaluation_dataset_configuration.EvaluationDatasetConfiguration>` for configuration of evaluation datasets.
  `EvaluationDatasetConfiguration.get <datarobot._experimental.models.genai.evaluation_dataset_configuration.EvaluationDatasetConfiguration.get>` to get an evaluation dataset configuration.
  `EvaluationDatasetConfiguration.list <datarobot._experimental.models.genai.evaluation_dataset_configuration.EvaluationDatasetConfiguration.list>` to list the evaluation dataset configurations for a Use Case.
  `EvaluationDatasetConfiguration.create <datarobot._experimental.models.genai.evaluation_dataset_configuration.EvaluationDatasetConfiguration.create>` to create an evaluation dataset configuration.
  `EvaluationDatasetConfiguration.update <datarobot._experimental.models.genai.evaluation_dataset_configuration.EvaluationDatasetConfiguration.update>` to update an evaluation dataset configuration.
  `EvaluationDatasetConfiguration.delete <datarobot._experimental.models.genai.evaluation_dataset_configuration.EvaluationDatasetConfiguration.delete>` to delete an evaluation dataset configuration.

- Added a new class `EvaluationDatasetMetricAggregation <datarobot._experimental.models.genai.evaluation_dataset_metric_aggregation.EvaluationDatasetMetricAggregation>` for metric aggregation results.
  `EvaluationDatasetMetricAggregation.list <datarobot._experimental.models.genai.evaluation_dataset_metric_aggregation.EvaluationDatasetMetricAggregation.list>` to get the metric aggregation results.
  `EvaluationDatasetMetricAggregation.create <datarobot._experimental.models.genai.evaluation_dataset_metric_aggregation.EvaluationDatasetMetricAggregation.create>` to create the metric aggregation job.
  `EvaluationDatasetMetricAggregation.delete <datarobot._experimental.models.genai.evaluation_dataset_metric_aggregation.EvaluationDatasetMetricAggregation.delete>` to delete metric aggregation results.

- Added a new class `SyntheticEvaluationDataset <datarobot._experimental.models.genai.synthetic_evaluation_dataset_generation.SyntheticEvaluationDataset>` for synthetic dataset generation.
  Use `SyntheticEvaluationDataset.create <datarobot._experimental.models.genai.synthetic_evaluation_dataset_generation.SyntheticEvaluationDataset.create>` to create a synthetic evaluation dataset.

- Added a new class `SidecarModelMetricValidation <datarobot._experimental.models.genai.sidecar_model_metric.SidecarModelMetricValidation>` for sidecar model metric validations.
  `SidecarModelMetricValidation.create <datarobot._experimental.models.genai.sidecar_model_metric.SidecarModelMetricValidation.create>` to create a sidecar model metric validation.
  `SidecarModelMetricValidation.list <datarobot._experimental.models.genai.sidecar_model_metric.SidecarModelMetricValidation.list>` to list sidecar model metric validations.
  `SidecarModelMetricValidation.get <datarobot._experimental.models.genai.sidecar_model_metric.SidecarModelMetricValidation.get>` to get a sidecar model metric validation.
  `SidecarModelMetricValidation.revalidate <datarobot._experimental.models.genai.sidecar_model_metric.SidecarModelMetricValidation.revalidate>` to rerun a sidecar model metric validation.
  `SidecarModelMetricValidation.update <datarobot._experimental.models.genai.sidecar_model_metric.SidecarModelMetricValidation.update>` to update a sidecar model metric validation.
  `SidecarModelMetricValidation.delete <datarobot._experimental.models.genai.sidecar_model_metric.SidecarModelMetricValidation.delete>` to delete a sidecar model metric validation.

- Added experimental support for Chunking Service:

  - Added a new attribute, `is_descending_order` to:

    - {class}`DatasourceDefinition <datarobot._experimental.models.chunking_service.DatasourceDefinition>`
    - {class}`DatasourceAICatalogInfo <datarobot._experimental.models.chunking_service.DatasourceAICatalogInfo>`
    - {class}`DatasourceDataWarehouseInfo <datarobot._experimental.models.chunking_service.DatasourceDataWarehouseInfo>`

### Bugfixes

- Updated the trafaret column `prediction` from {class}`TrainingPredictionsIterator <datarobot.models.training_predictions.TrainingPredictionsIterator>` for
  supporting extra list of strings.

### Configuration changes

- Updated black version to 23.1.0.
- Removes dependency on package [mock](https://pypi.org/project/mock/), since it is part of the standard library.

### Documentation changes

- Removed incorrect can_share parameters in Use Case sharing example
- Added usage of `external_llm_context_size` in `llm_settings` in `genai_example.rst`.
- Updated doc string for `llm_settings` to include attribute `external_llm_context_size` for external LLMs.
- Updated `genai_example.rst` to link to DataRobot doc pages for external vector database and external LLM deployment creation.

### API changes

- Remove `ImportedModel` object since it was API for SSE (standalone scoring engine) which is not part of DataRobot anymore.
- Added `number_of_clusters` parameter to {meth}`Project.get_model_records <datarobot.models.Project.get_model_records>`
  to filter models by number of clusters in unsupervised clustering projects.
- Remove an unsupported `NETWORK_EGRESS_POLICY.DR_API_ACCESS` value for custom models. This value
  was used by a feature that was never released as a GA and is not supported in the current API.
- Implemented support for `dr-connector-v1` to `DataStore <datarobot.models.DataStore>` and `DataSource <datarobot.models.DataStore>`.
- Added a new parameter `name` to {meth}`DataStore.list <datarobot.DataStore.list>` for searching data stores by name.
- Added a new parameter `entity_type` to the `compute` and `create` methods of the classes {class}`ShapMatrix <datarobot.insights.shap_matrix.ShapMatrix>`, {class}`ShapImpact <datarobot.insights.shap_impact.ShapImpact>`, {class}`ShapPreview <datarobot.insights.shap_preview.ShapPreview>`. Insights can be computed for custom models if the parameter `entity_type="customModel"` is passed. See also the User Guide: :ref:`SHAP insights overview<shap_insights_overview>`.

### Experimental changes

- Added experimental api support for Data Wrangling. See {class}`Recipe <datarobot.models.recipe.Recipe>`.
  {meth}`Recipe.from_data_store <datarobot.models.recipe.Recipe.from_data_store>` to create a Recipe from data store.
  {meth}`Recipe.retrieve_preview <datarobot.models.recipe.Recipe.retrieve_preview>` to get a sample of the data after recipe is applied.
  {meth}`Recipe.set_inputs <datarobot.models.recipe.Recipe.set_inputs>` to set inputs to the recipe.
  {meth}`Recipe.set_operations <datarobot.models.recipe.Recipe.set_operations>` to set operations to the recipe.
- Added new experimental {class}`DataStore <datarobot.models.data_store.DataStore>` that adds
  `get_spark_session` for Databricks `databricks-v1` data stores to get a Spark session.
- Added attribute `chunking_type` to {class}`DatasetChunkDefinition <datarobot._experimental.models.chunking_service.DatasetChunkDefinition>`.
- Added OTV attributes to {class}`DatasourceDefinition <datarobot._experimental.models.chunking_service.DatasourceDefinition>`.
- Added {meth}`DatasetChunkDefinition.patch_validation_dates <datarobot._experimental.models.chunking_service.DatasetChunkDefinition.patch_validation_dates>` to patch validation dates of OTV datasource definitions after sampling job.

## 3.4.1

### New features

### Enhancements

### Bugfixes

- Updated the validation logic of `RelationshipsConfiguration` to work with native database connections

### API changes

### Deprecation summary

### Configuration changes

### Documentation changes

### Experimental changes

## 3.4.0

### New features

- Added the following classes for generative AI. Importing these from `datarobot._experimental.models.genai` is deprecated and will be removed by the release of DataRobot 10.1 and API Client 3.5.
  \- {class}`Playground <datarobot.models.genai.playground.Playground>` to manage generative AI playgrounds.
  \- {class}`LLMDefinition <datarobot.models.genai.llm.LLMDefinition>` to get information about supported LLMs.
  \- {class}`LLMBlueprint <datarobot.models.genai.llm_blueprint.LLMBlueprint>` to manage LLM blueprints.
  \- {class}`Chat <datarobot.models.genai.chat.Chat>` to manage chats for LLM blueprints.
  \- {class}`ChatPrompt <datarobot.models.genai.chat_prompt.ChatPrompt>` to submit prompts within a chat.
  \- {class}`ComparisonChat <datarobot.models.genai.comparison_chat.ComparisonChat>` to manage comparison chats across multiple LLM blueprints within a playground.
  \- {class}`ComparisonPrompt <datarobot.models.genai.comparison_prompt.ComparisonPrompt>` to submit a prompt to multiple LLM blueprints within a comparison chat.
  \- {class}`VectorDatabase <datarobot.models.genai.vector_database.VectorDatabase>` to create vector databases from datasets in the AI Catalog for retrieval augmented generation with an LLM blueprint.
  \- {class}`CustomModelVectorDatabaseValidation <datarobot.models.genai.vector_database.CustomModelVectorDatabaseValidation>` to validate a deployment for use as a vector database.
  \- {class}`CustomModelLLMValidation <datarobot.models.genai.custom_model_llm_validation.CustomModelLLMValidation>` to validate a deployment for use as an LLM.
  \- {class}`UserLimits <datarobot.models.genai.user_limits.UserLimits>` to get counts of vector databases and LLM requests for a user.

- Extended the advanced options available when setting a target to include new
  parameter: `incrementalLearningEarlyStoppingRounds` (part of the AdvancedOptions object).
  This parameter allows you to specify when to stop for incremental learning automation.

- Added experimental support for Chunking Service:

  - {class}`DatasetChunkDefinition <datarobot._experimental.models.chunking_service.DatasetChunkDefinition>` for defining how chunks are created from a data source.

    - {meth}`DatasetChunkDefinition.create <datarobot._experimental.models.chunking_service.DatasetChunkDefinition.create>` to create a new dataset chunk definition.
    - {meth}`DatasetChunkDefinition.get <datarobot._experimental.models.chunking_service.DatasetChunkDefinition.get>` to get a specific dataset chunk definition.
    - {meth}`DatasetChunkDefinition.list <datarobot._experimental.models.chunking_service.DatasetChunkDefinition.get>` to list all dataset chunk definitions.
    - {meth}`DatasetChunkDefinition.get_datasource_definition <datarobot._experimental.models.chunking_service.DatasetChunkDefinition.get_datasource_definition>` to retrieve the data source definition.
    - {meth}`DatasetChunkDefinition.get_chunk <datarobot._experimental.models.chunking_service.DatasetChunkDefinition.get_chunk>` to get specific chunk metadata belonging to a dataset chunk definition.
    - {meth}`DatasetChunkDefinition.list_chunks <datarobot._experimental.models.chunking_service.DatasetChunkDefinition.list_chunks>` to list all chunk metadata belonging to a dataset chunk definition.
    - {meth}`DatasetChunkDefinition.create_chunk <datarobot._experimental.models.chunking_service.DatasetChunkDefinition.create_chunk>` to submit a job to retrieve the data from the origin data source.
    - {meth}`DatasetChunkDefinition.create_chunk_by_index <datarobot._experimental.models.chunking_service.DatasetChunkDefinition.create_chunk_by_index>` to submit a job to retrieve data from the origin data source by index.

  - {class}`OriginStorageType <datarobot._experimental.models.chunking_service.OriginStorageType>`

  - {class}`Chunk <datarobot._experimental.models.chunking_service.Chunk>`

  - {class}`ChunkStorageType <datarobot._experimental.models.chunking_service.ChunkStorageType>`

  - {class}`ChunkStorage <datarobot._experimental.models.chunking_service.ChunkStorage>`

  - {class}`DatasourceDefinition <datarobot._experimental.models.chunking_service.DatasourceDefinition>`

  - {class}`DatasourceAICatalogInfo <datarobot._experimental.models.chunking_service.DatasourceAICatalogInfo>` to define the datasource AI catalog information to create a new dataset chunk definition.

  - {class}`DatasourceDataWarehouseInfo <datarobot._experimental.models.chunking_service.DatasourceDataWarehouseInfo>` to define the datasource data warehouse (snowflake, big query, etc) information to create a new dataset chunk definition.

  - {class}`RuntimeParameter <datarobot.models.custom_model_version.RuntimeParameter>` for retrieving runtime parameters assigned to {class}`CustomModelVersion <datarobot.CustomModelVersion>`.

  - {class}`RuntimeParameterValue <datarobot.models.custom_model_version.RuntimeParameterValue>` to define runtime parameter override value, to be assigned to {class}`CustomModelVersion <datarobot.CustomModelVersion>`.

- Added Snowflake Key Pair authentication for uploading datasets from Snowflake or creating a project from Snowflake data

- Added {meth}`Project.get_model_records <datarobot.models.Project.get_model_records>` to retrieve models.
  Method {meth}`Project.get_models <datarobot.models.Project.get_models>` is deprecated and will be removed soon in favour of {meth}`Project.get_model_records <datarobot.models.Project.get_model_records>`.

- Extended the advanced options available when setting a target to include new
  parameter: `chunkDefinitionId` (part of the AdvancedOptions object). This parameter allows you to specify the chunking definition needed for incremental learning automation.

- Extended the advanced options available when setting a target to include new Autopilot
  parameters: `incrementalLearningOnlyMode` and `incrementalLearningOnBestModel` (part of the AdvancedOptions object). These parameters allow you to specify how Autopilot is performed with the chunking service.

- Added a new method {meth}`DatetimeModel.request_lift_chart<datarobot.models.DatetimeModel.request_lift_chart>` to support Lift Chart calculations for datetime partitioned projects with support of Sliced Insights.

- Added a new method {meth}`DatetimeModel.get_lift_chart<datarobot.models.DatetimeModel.get_lift_chart>` to support Lift chart retrieval for datetime partitioned projects with support of Sliced Insights.

- Added a new method {meth}`DatetimeModel.request_roc_curve<datarobot.models.DatetimeModel.request_roc_curve>` to support ROC curve calculation for datetime partitioned projects with support of Sliced Insights.

- Added a new method {meth}`DatetimeModel.get_roc_curve<datarobot.models.DatetimeModel.get_roc_curve>` to support ROC curve retrieval for datetime partitioned projects with support of Sliced Insights.

- Update method {meth}`DatetimeModel.request_feature_impact<datarobot.models.DatetimeModel.request_feature_impact>` to support use of Sliced Insights.

- Update method {meth}`DatetimeModel.get_feature_impact<datarobot.models.DatetimeModel.get_feature_impact>` to support use of Sliced Insights.

- Update method {meth}`DatetimeModel.get_or_request_feature_impact<datarobot.models.DatetimeModel.get_or_request_feature_impact>` to support use of Sliced Insights.

- Update method {meth}`DatetimeModel.request_feature_effect<datarobot.models.DatetimeModel.request_feature_effect>` to support use of Sliced Insights.

- Update method {meth}`DatetimeModel.get_feature_effect<datarobot.models.DatetimeModel.get_feature_effect>` to support use of Sliced Insights.

- Update method {meth}`DatetimeModel.get_or_request_feature_effect<datarobot.models.DatetimeModel.get_or_request_feature_effect>` to support use of Sliced Insights.

- Added a new method {meth}`FeatureAssociationMatrix.create<datarobot.models.FeatureAssociationMatrix.create>` to support the creation of FeatureAssociationMatricies for Featurelists.

- Introduced a new method {meth}`Deployment.perform_model_replace<datarobot.models.Deployment.perform_model_replace>` as a replacement for {meth}`Deployment.replace_model<datarobot.models.Deployment.replace_model>`.

- Introduced a new property, `model_package`, which provides an overview of the currently used model package in {class}`datarobot.models.Deployment`.

- Added new parameter `prediction_threshold` to {meth}`BatchPredictionJob.score_with_leaderboard_model <datarobot.models.BatchPredictionJob.score_with_leaderboard_model>`
  and {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score>` that automatically assigns the positive class label to any prediction exceeding the threshold.

- Added two new enum values to  :class: `datarobot.models.data_slice.DataSlicesOperators`, "BETWEEN" and "NOT_BETWEEN", which are used to allow slicing.

- Added a new class {class}`Challenger <datarobot.models.deployment.challenger.Challenger>` for interacting with DataRobot challengers to support the following methods:
  {meth}`Challenger.get <datarobot.models.deployment.challenger.Challenger.get>` to retrieve challenger objects by ID.
  {meth}`Challenger.list <datarobot.models.deployment.challenger.Challenger.list>` to list all challengers.
  {meth}`Challenger.create <datarobot.models.deployment.challenger.Challenger.create>` to create a new challenger.
  {meth}`Challenger.update <datarobot.models.deployment.challenger.Challenger.update>` to update a challenger.
  {meth}`Challenger.delete <datarobot.models.deployment.challenger.Challenger.delete>` to delete a challenger.

- Added a new method {meth}`Deployment.get_challenger_replay_settings <datarobot.models.Deployment.get_challenger_replay_settings>` to retrieve the challenger replay settings of a deployment.

- Added a new method {meth}`Deployment.list_challengers <datarobot.models.Deployment.list_challengers>` to retrieve the challengers of a deployment.

- Added a new method {meth}`Deployment.get_champion_model_package <datarobot.models.Deployment.get_champion_model_package>` to retrieve the champion model package from a deployment.

- Added a new method {meth}`Deployment.list_prediction_data_exports <datarobot.models.Deployment.list_prediction_data_exports>` to retrieve deployment prediction data exports.

- Added a new method {meth}`Deployment.list_actuals_data_exports <datarobot.models.Deployment.list_actuals_data_exports>` to retrieve deployment actuals data exports.

- Added a new method {meth}`Deployment.list_training_data_exports <datarobot.models.Deployment.list_training_data_exports>` to retrieve deployment training data exports.

- Manage deployment health settings with the following methods:
  \- Get health settings {meth}`Deployment.get_health_settings <datarobot.models.Deployment.get_health_settings>`
  \- Update health settings {meth}`Deployment.update_health_settings <datarobot.models.Deployment.update_health_settings>`
  \- Get default health settings {meth}`Deployment.get_default_health_settings <datarobot.models.Deployment.get_default_health_settings>`

- Added new enum value to `datarobot.enums._SHARED_TARGET_TYPE` to support Text Generation use case.

- Added new enum value `datarobotServerless` to `datarobot.enums.PredictionEnvironmentPlatform` to support DataRobot Serverless prediction environments.

- Added new enum value `notApplicable` to `datarobot.enums.PredictionEnvironmentHealthType` to support new health status from DataRobot API.

- Added new enum value to `datarobot.enums.TARGET_TYPE` and `datarobot.enums.CUSTOM_MODEL_TARGET_TYPE` to support text generation custom inference models.

- Updated `datarobot.CustomModel` to support the creation of text generation custom models.

- Added a new class {class}`CustomMetric <datarobot.models.deployment.custom_metrics.CustomMetric>` for interacting with DataRobot custom metrics to support the following methods:
  {meth}`CustomMetric.get <datarobot.models.deployment.custom_metrics.CustomMetric.get>` to retrieve a custom metric object by ID from a given deployment.
  {meth}`CustomMetric.list <datarobot.models.deployment.custom_metrics.CustomMetric.list>` to list all custom metrics from a given deployment.
  {meth}`CustomMetric.create <datarobot.models.deployment.custom_metrics.CustomMetric.create>` to create a new custom metric for a given deployment.
  {meth}`CustomMetric.update <datarobot.models.deployment.custom_metrics.CustomMetric.update>` to update a custom metric for a given deployment.
  {meth}`CustomMetric.delete <datarobot.models.deployment.custom_metrics.CustomMetric.delete>` to delete a custom metric for a given deployment.
  {meth}`CustomMetric.unset_baseline <datarobot.models.deployment.custom_metrics.CustomMetric.unset_baseline>` to remove baseline for a given custom metric.
  {meth}`CustomMetric.submit_values <datarobot.models.deployment.custom_metrics.CustomMetric.submit_values>` to submit aggregated custom metrics values from code. The provided data should be in the form of a dict or a Pandas DataFrame.
  {meth}`CustomMetric.submit_single_value <datarobot.models.deployment.custom_metrics.CustomMetric.submit_single_value>` to submit a single custom metric value.
  {meth}`CustomMetric.submit_values_from_catalog <datarobot.models.deployment.custom_metrics.CustomMetric.submit_values_from_catalog>` to submit aggregated custom metrics values from a dataset via the AI Catalog.
  {meth}`CustomMetric.get_values_over_time <datarobot.models.deployment.custom_metrics.CustomMetric.get_values_over_time>` to retrieve values of a custom metric over a time period.
  {meth}`CustomMetric.get_summary <datarobot.models.deployment.custom_metrics.CustomMetric.get_summary>` to retrieve the summary of a custom metric over a time period.
  {meth}`CustomMetric.get_values_over_batch <datarobot.models.deployment.custom_metrics.CustomMetric.get_values_over_batch>` to retrieve values of a custom metric over batches.
  {meth}`CustomMetric.get_batch_summary <datarobot.models.deployment.custom_metrics.CustomMetric.get_batch_summary>` to retrieve the summary of a custom metric over batches.

- Added {class}`CustomMetricValuesOverTime <datarobot.models.deployment.custom_metrics.CustomMetricValuesOverTime>` to retrieve custom metric over time information.

- Added {class}`CustomMetricSummary <datarobot.models.deployment.custom_metrics.CustomMetricSummary>` to retrieve custom metric over time summary.

- Added {class}`CustomMetricValuesOverBatch <datarobot.models.deployment.custom_metrics.CustomMetricValuesOverBatch>` to retrieve custom metric over batch information.

- Added {class}`CustomMetricBatchSummary <datarobot.models.deployment.custom_metrics.CustomMetricBatchSummary>` to retrieve custom metric batch summary.

- Added {class}`Job <datarobot.models.registry.job.Job>` and  {class}`JobRun <datarobot.models.registry.job_run.JobRun>`  to create, read, update, run, and delete jobs in the Registry.

- Added {class}`KeyValue <datarobot.models.key_values.KeyValue>` to create, read, update, and delete key values.

- Added a new class {class}`PredictionDataExport <datarobot.models.deployment.data_exports.PredictionDataExport>` for interacting with DataRobot deployment data export to support the following methods:
  {meth}`PredictionDataExport.get <datarobot.models.deployment.data_exports.PredictionDataExport.get>` to retrieve a prediction data export object by ID from a given deployment.
  {meth}`PredictionDataExport.list <datarobot.models.deployment.data_exports.PredictionDataExport.list>` to list all prediction data exports from a given deployment.
  {meth}`PredictionDataExport.create <datarobot.models.deployment.data_exports.PredictionDataExport.create>` to create a new prediction data export for a given deployment.
  {meth}`PredictionDataExport.fetch_data <datarobot.models.deployment.data_exports.PredictionDataExport.fetch_data>` to retrieve a prediction export data as a DataRobot dataset.

- Added a new class {class}`ActualsDataExport <datarobot.models.deployment.data_exports.ActualsDataExport>` for interacting with DataRobot deployment data export to support the following methods:
  {meth}`ActualsDataExport.get <datarobot.models.deployment.data_exports.ActualsDataExport.get>` to retrieve an actuals data export object by ID from a given deployment.
  {meth}`ActualsDataExport.list <datarobot.models.deployment.data_exports.ActualsDataExport.list>` to list all actuals data exports from a given deployment.
  {meth}`ActualsDataExport.create <datarobot.models.deployment.data_exports.ActualsDataExport.create>` to create a new actuals data export for a given deployment.
  {meth}`ActualsDataExport.fetch_data <datarobot.models.deployment.data_exports.ActualsDataExport.fetch_data>` to retrieve an actuals export data  as a DataRobot dataset.

- Added a new class {class}`TrainingDataExport <datarobot.models.deployment.data_exports.TrainingDataExport>` for interacting with DataRobot deployment data export to support the following methods:
  {meth}`TrainingDataExport.get <datarobot.models.deployment.data_exports.TrainingDataExport.get>` to retrieve a training data export object by ID from a given deployment.
  {meth}`TrainingDataExport.list <datarobot.models.deployment.data_exports.TrainingDataExport.list>` to list all training data exports from a given deployment.
  {meth}`TrainingDataExport.create <datarobot.models.deployment.data_exports.TrainingDataExport.create>` to create a new training data export for a given deployment.
  {meth}`TrainingDataExport.fetch_data <datarobot.models.deployment.data_exports.TrainingDataExport.fetch_data>` to retrieve a training export data as a DataRobot dataset.

- Added a new parameter `base_environment_version_id` to {meth}`CustomModelVersion.create_clean <datarobot.CustomModelVersion.create_clean>` for overriding the default environment version selection behavior.

- Added a new parameter `base_environment_version_id` to {meth}`CustomModelVersion.create_from_previous <datarobot.CustomModelVersion.create_from_previous>` for overriding the default environment version selection behavior.

- Added a new class `PromptTrace <datarobot._experimental.models.genai.prompt_trace.PromptTrace>` for interacting with DataRobot prompt trace to support the following methods:
  `PromptTrace.list <datarobot._experimental.models.genai.prompt_trace.PromptTrace.list>` to list all prompt traces from a given playground.
  `PromptTrace.export_to_ai_catalog <datarobot._experimental.models.genai.prompt_trace.PromptTrace.export_to_ai_catalog>` to export prompt traces for the playground to AI catalog.

- Added a new class `InsightsConfiguration <datarobot._experimental.models.genai.insights_configuration.InsightsConfiguration>` for describing available insights and configured insights for a playground.
  `InsightsConfiguration.list <datarobot._experimental.models.genai.insights_configuration.InsightsConfiguration.list>` to list the insights that are available to be configured.

- Added a new class `Insights <datarobot._experimental.models.genai.insights_configuration.Insights>` for configuring insights for a playground.
  `Insights.get <datarobot._experimental.models.genai.insights_configuration.Insights.get>` to get the current insights configuration for a playground.
  `Insights.create <datarobot._experimental.models.genai.insights_configuration.Insights.create>` to create or update the insights configuration for a playground.

- Added a new class :class: `CostMetricConfiguration <datarobot._experimental.models.genai.cost_metric_configurations.CostMetricConfiguration>` for describing available cost metrics and configured cost metrics for a Use Case.
  `CostMetricConfiguration.get <datarobot._experimental.models.genai.cost_metric_configurations.CostMetricConfiguration.get>` to get the cost metric configuration.
  `CostMetricConfiguration.create <datarobot._experimental.models.genai.cost_metric_configurations.CostMetricConfiguration.create>` to create a cost metric configuration.
  `CostMetricConfiguration.update <datarobot._experimental.models.genai.cost_metric_configurations.CostMetricConfiguration.update>` to update the cost metric configuration.
  `CostMetricConfiguration.delete <datarobot._experimental.models.genai.cost_metric_configurations.CostMetricConfiguration.delete>` to delete the cost metric configuration.Key

- Added a new class `LLMCostConfiguration <datarobot._experimental.models.genai.cost_metric_configurations.LLMCostConfiguration>` for the cost configuration of a specific llm within a Use Case.

- Added new classes {class}`ShapMatrix <datarobot.insights.shap_matrix.ShapMatrix>`, {class}`ShapImpact <datarobot.insights.shap_impact.ShapImpact>`, {class}`ShapPreview <datarobot.insights.shap_preview.ShapPreview>` to interact with SHAP-based insights. See also the User Guide: :ref:`SHAP insights overview<shap_insights_overview>`

### API changes

- Parameter Overrides: Users can now override most of the previously set configuration values directly through parameters when initializing the Client. Exceptions: The endpoint and token values must be initialized from one source (client params, environment, or config file) and cannot be overridden individually, for security and consistency reasons. The new configuration priority is as follows:
  1\.  Client Params
  2\.  Client config_path param
  3\.  Environment Variables
  4\.  Default to reading YAML config file from `~/.config/datarobot/drconfig.yaml`
- `DATAROBOT_API_CONSUMER_TRACKING_ENABLED` now always defaults to `True`.
- Added Databricks personal access token and service principal (also shared credentials via secure config) authentication for uploading datasets from Databricks or creating a project from Databricks data.
- Added secure config support for AWS long term credentials.
- Implemented support for `dr-database-v1` to `DataStore <datarobot.models.DataStore>`, `DataSource <datarobot.models.DataStore>`, and  `DataDriver <datarobot.models.DataDriver>.` Added enum classes to support the changes.
- You can retrieve the canonical URI for a Use Case using {meth}`UseCase.get_uri <datarobot.UseCase.get_uri>`.
- You can open a Use Case in a browser using {meth}`UseCase.open_in_browser <datarobot.UseCase.open_in_browser>`.

### Enhancements

- Added a new parameter to {meth}`Dataset.create_from_url <datarobot.models.Dataset.create_from_url>` to support fast dataset registration:
  \- `sample_size`
- Added a new parameter to {meth}`Dataset.create_from_data_source <datarobot.models.Dataset.create_from_data_source>` to support fast dataset registration:
  \- `sample_size`
- {meth}`Job.get_result_when_complete <datarobot.models.Job.get_result_when_complete>`
  returns {class}`datarobot.models.DatetimeModel` instead of the {class}`datarobot.models.Model`
  if a datetime model was trained.
- {meth}`Dataset.get_as_dataframe <datarobot.models.Dataset.get_as_dataframe>` can handle
  downloading parquet files as well as csv files.
- Implement support for `dr-database-v1` in `DataStore <datarobot.models.DataStore>`
- Added two new parameters to {meth}`BatchPredictionJobDefinition.list <datarobot.models.BatchPredictionJobDefinition.list>` for paginating long job definitions lists:
  \- `offset`
  \- `limit`
- Added two new parameters to {meth}`BatchPredictionJobDefinition.list <datarobot.models.BatchPredictionJobDefinition.list>` for filtering the job definitions:
  \- `deployment_id`
  \- `search_name`
- Added new parameter to {meth}`Deployment.validate_replacement_model<datarobot.models.Deployment.validate_replacement_model>` to support replacement validation based on model package ID:
  \- `new_registered_model_version_id`
- Added support for Native Connectors to `Connector <datarobot.models.Connector>` for everything other than :meth:\` Connector.create \<datarobot.models.Connector.create>\` and :meth:\` Connector.update \<datarobot.models.Connector.update>\`

### Deprecation summary

- Removed `Model.get_leaderboard_ui_permalink` and `Model.open_model_browser`
- Deprecated {meth}`Project.get_models <datarobot.models.Project.get_models>` in favour of {meth}`Project.get_model_records <datarobot.models.Project.get_model_records>`.
- {meth}`BatchPredictionJobDefinition.list <datarobot.models.BatchPredictionJobDefinition.list>` will no longer return all job definitions after version 3.6 is released.
  To preserve current behavior please pass limit=0.
- `new_model_id` parameter in {meth}`Deployment.validate_replacement_model<datarobot.models.Deployment.validate_replacement_model>` will be removed after version 3.6 is released.
- {meth}`Deployment.replace_model<datarobot.models.Deployment.replace_model>` will be removed after version 3.6 is released.
  Method {meth}`Deployment.perform_model_replace<datarobot.models.Deployment.perform_model_replace>` should be used instead.
- {meth}`CustomInferenceModel.assign_training_data <datarobot.CustomInferenceModel.assign_training_data>` was marked as deprecated in v3.2. The deprecation period has been extended, and the feature will now be removed in v3.5.
  Use {meth}`CustomModelVersion.create_clean <datarobot.CustomModelVersion.create_clean>` and {meth}`CustomModelVersion.create_from_previous <datarobot.CustomModelVersion.create_from_previous>` instead.

### Documentation changes

- Updated `genai_example.rst` to utilize latest genAI features and methods introduced most recently in the API client.

### Experimental changes

- Added new attribute, `prediction_timeout` to {class}`CustomModelValidation <datarobot.models.genai.custom_model_validation.CustomModelValidation>`.
- Added new attributes, `feedback_result`, `metrics`, and `final_prompt` to `ResultMetadata <datarobot._experimental.models.genai.chat_prompt.ResultMetadata>`.
- Added `use_case_id` to {class}`CustomModelValidation <datarobot.models.genai.custom_model_validation.CustomModelValidation>`.
- Added `llm_blueprints_count` and `user_name` to {class}`Playground <datarobot.models.genai.playground.Playground>`.
- Added `custom_model_embedding_validations` to `SupportedEmbeddings <datarobot._experimental.models.genai.vector_database.SupportedEmbeddings>`.
- Added `embedding_validation_id` and `is_separator_regex` to `VectorDatabase <datarobot._experimental.models.genai.vector_database.VectorDatabase>`.
- Added optional parameters, `use_case`, `name`, and `model` to {meth}`CustomModelValidation.create <datarobot.models.genai.custom_model_validation.CustomModelValidation.create>`.
- Added a method {meth}`CustomModelValidation.list <datarobot.models.genai.custom_model_validation.CustomModelValidation.list>`, to list custom model validations available to a user with several optional parameters to filter the results.
- Added a method {meth}`CustomModelValidation.update <datarobot.models.genai.custom_model_validation.CustomModelValidation.update>`, to update a custom model validation.
- Added an optional parameter, `use_case`, to {meth}`LLMDefinition.list <datarobot.models.genai.llm.LLMDefinition.list>`,
  to include in the returned LLMs the external LLMs available for the specified `use_case` as well.
- Added optional parameter, `playground` to {meth}`VectorDatabase.list <datarobot.models.genai.vector_database.VectorDatabase.list>`
  to list vector databases by playground.
- Added optional parameter, `comparison_chat`, to {meth}`ComparisonPrompt.list <datarobot.models.genai.comparison_prompt.ComparisonPrompt.list>`, to list comparison prompts by comparison chat.
- Added optional parameter, `comparison_chat`, to {meth}`ComparisonPrompt.create <datarobot.models.genai.comparison_prompt.ComparisonPrompt.create>`, to specify the comparison chat to create the comparison prompt in.
- Added optional parameter, `feedback_result`, to `ComparisonPrompt.update <datarobot._experimental.models.genai.comparison_prompt.ComparisonPrompt.update>`, to update a comparison prompt with feedback.
- Added optional parameters, `is_starred` to {meth}`LLMBlueprint.update <datarobot.models.genai.llm_blueprint.LLMBlueprint.update>`
  to update the LLM blueprint's starred status.
- Added optional parameters, `is_starred` to {meth}`LLMBlueprint.list <datarobot.models.genai.llm_blueprint.LLMBlueprint.list>`
  to filter the returned LLM blueprints to those matching `is_starred`.
- Added a new enum PromptType, {class}`PromptType <datarobot.enums.PromptType>` to identify the LLMBlueprint's prompting type.
- Added optional parameters, `prompt_type` to {meth}`LLMBlueprint.create <datarobot.models.genai.llm_blueprint.LLMBlueprint.create>`,
  to specify the LLM blueprint's prompting type. This can be set with {class}`PromptType <datarobot.enums.PromptType>`.
- Added optional parameters, `prompt_type` to {meth}`LLMBlueprint.update <datarobot.models.genai.llm_blueprint.LLMBlueprint.update>`,
  to specify the updated LLM blueprint's prompting type. This can be set with {class}`PromptType <datarobot.enums.PromptType>`.
- Added a new class, {class}`ComparisonChat <datarobot.models.genai.comparison_chat.ComparisonChat>`, for interacting with DataRobot generative AI comparison chats.
  {meth}`ComparisonChat.get <datarobot.models.genai.comparison_chat.ComparisonChat.get>` retrieves a comparison chat object by ID.
  {meth}`ComparisonChat.list <datarobot.models.genai.comparison_chat.ComparisonChat.list>` lists all comparison chats available to the user.
  {meth}`ComparisonChat.create <datarobot.models.genai.comparison_chat.ComparisonChat.create>` creates a new comparison chat.
  {meth}`ComparisonChat.update <datarobot.models.genai.comparison_chat.ComparisonChat.update>` updates the name of a comparison chat.
  {meth}`ComparisonChat.delete <datarobot.models.genai.comparison_chat.ComparisonChat.delete>` deletes a single comparison chat.
- Added optional parameters, `playground` and `chat` to {meth}`ChatPrompt.list <datarobot.models.genai.chat_prompt.ChatPrompt.list>`, to list chat prompts by playground and chat.
- Added optional parameter, `chat` to {meth}`ChatPrompt.create <datarobot.models.genai.chat_prompt.ChatPrompt.create>`, to specify the chat to create the chat prompt in.
- Added a new method, `ChatPrompt.update <datarobot._experimental.models.genai.chat_prompt.ChatPrompt.update>`, to update a chat prompt with custom metrics and feedback.
- Added a new class, {class}`Chat <datarobot.models.genai.chat.Chat>`, for interacting with DataRobot generative AI chats.
  {meth}`Chat.get <datarobot.models.genai.chat.Chat.get>` retrieves a chat object by ID.
  {meth}`Chat.list <datarobot.models.genai.chat.Chat.list>` lists all chats available to the user.
  {meth}`Chat.create <datarobot.models.genai.chat.Chat.create>` creates a new chat.
  {meth}`Chat.update <datarobot.models.genai.chat.Chat.update>` updates the name of a chat.
  {meth}`Chat.delete <datarobot.models.genai.chat.Chat.delete>` deletes a single chat.
- Removed the `model_package` module. Use {class}`RegisteredModelVersion <datarobot.models.RegisteredModelVersion>` instead.
- Added new class {class}`UserLimits <datarobot.models.genai.user_limits.UserLimits>`
  \- Added support to get the count of users' LLM API requests. {meth}`UserLimits.get_llm_requests_count <datarobot.models.genai.user_limits.UserLimits.get_llm_requests_count>`
  \- Added support to get the count of users' vector databases. {meth}`UserLimits.get_vector_database_count <datarobot.models.genai.user_limits.UserLimits.get_vector_database_count>`
- Added new methods to the class {class}`Notebook <datarobot.models.notebooks.Notebook>` which includes {meth}`Notebook.run <datarobot.models.notebooks.Notebook.run>` and {meth}`Notebook.download_revision <datarobot.models.notebooks.Notebook.download_revision>`. See the documentation for example usage.
- Added new class {class}`NotebookScheduledJob <datarobot.models.notebooks.NotebookScheduledJob>`.
- Added new class {class}`NotebookScheduledRun <datarobot.models.notebooks.NotebookScheduledRun>`.
- Added a new method {meth}`Model.get_incremental_learning_metadata <datarobot._experimental.models.model.Model.get_incremental_learning_metadata>` that retrieves incremental learning metadata for a model.
- Added a new method {meth}`Model.start_incremental_learning <datarobot._experimental.models.model.Model.start_incremental_learning>` that starts incremental learning for a model.
- Updated the API endpoint prefix for all GenerativeAI routes to align with the publicly documented routes.

### Bugfixes

- Fixed how async url is build in {meth}`Model.get_or_request_feature_impact <datarobot.models.Model.get_or_request_feature_impact>`
- Fixed setting ssl_verify by env variables.
- Resolved a problem related to tilde-based paths in the Client's 'config_path' attribute.
- Changed the force_size default of {class}`ImageOptions <datarobot.helpers.image_utils.ImageOptions>` to apply the same transformations by default, which are applied when image archive datasets are uploaded to DataRobot.

## 3.3.0

### New features

- Added support for Python 3.11.
- Added new library `strenum` to add `StrEnum` support while maintaining backwards compatibility with Python 3.7-3.10. DataRobot does not use the native `StrEnum` class in Python 3.11.
- Added a new class {class}`PredictionEnvironment <datarobot.models.PredictionEnvironment>` for interacting with DataRobot Prediction environments.
- Extended the advanced options available when setting a target to include new
  parameters: `modelGroupId`, `modelRegimeId`, and `modelBaselines` (part of the AdvancedOptions object). These parameters allow you to specify the user columns required to run time series models without feature derivation in OTV projects.
- Added a new method {meth}`PredictionExplanations.create_on_training_data <datarobot.PredictionExplanations.create_on_training_data>`, for computing prediction explanation on training data.
- Added a new class {class}`RegisteredModel <datarobot.models.RegisteredModel>` for interacting with DataRobot registered models to support the following methods:
  {meth}`RegisteredModel.get <datarobot.models.RegisteredModel.get>` to retrieve RegisteredModel object by ID.
  {meth}`RegisteredModel.list <datarobot.models.RegisteredModel.list>` to list all registered models.
  {meth}`RegisteredModel.archive <datarobot.models.RegisteredModel.archive>` to permanently archive registered model.
  {meth}`RegisteredModel.update <datarobot.models.RegisteredModel.update>` to update registered model.
  {meth}`RegisteredModel.get_shared_roles <datarobot.models.RegisteredModel.get_shared_roles>` to retrieve access control information for registered model.
  {meth}`RegisteredModel.share <datarobot.models.RegisteredModel.share>` to share a registered model.
  {meth}`RegisteredModel.get_version <datarobot.models.RegisteredModel.get_version>` to retrieve RegisteredModelVersion object by ID.
  {meth}`RegisteredModel.list_versions <datarobot.models.RegisteredModel.list_versions>` to list registered model versions.
  {meth}`RegisteredModel.list_associated_deployments <datarobot.models.RegisteredModel.list_associated_deployments>` to list deployments associated with a registered model.
- Added a new class {class}`RegisteredModelVersion <datarobot.models.RegisteredModelVersion>` for interacting with DataRobot registered model versions (also known as model packages) to support the following methods:
  {meth}`RegisteredModelVersion.create_for_external <datarobot.models.RegisteredModelVersion.create_for_external>` to create a new registered model version from an external model.
  {meth}`RegisteredModelVersion.list_associated_deployments <datarobot.models.RegisteredModelVersion.list_associated_deployments>` to list deployments associated with a registered model version.
  {meth}`RegisteredModelVersion.create_for_leaderboard_item <datarobot.models.RegisteredModelVersion.create_for_leaderboard_item>` to create a new registered model version from a Leaderboard model.
  {meth}`RegisteredModelVersion.create_for_custom_model_version <datarobot.models.RegisteredModelVersion.create_for_custom_model_version>` to create a new registered model version from a custom model version.
- Added a new method {meth}`Deployment.create_from_registered_model_version<datarobot.models.Deployment.create_from_registered_model_version>` to support creating deployments from registered model version.
- Added a new method {meth}`Deployment.download_model_package_file<datarobot.models.Deployment.download_model_package_file>` to support downloading model package files (.mlpkg) of the currently deployed model.
- Added support for retrieving document thumbnails:
  \- {class}`DocumentThumbnail <datarobot.models.documentai.document.DocumentThumbnail>`
  \- {class}`DocumentPageFile <datarobot.models.documentai.document.DocumentPageFile>`
- Added support to retrieve document text extraction samples using:
  \- {class}`DocumentTextExtractionSample <datarobot.models.documentai.document.DocumentTextExtractionSample>`
  \- {class}`DocumentTextExtractionSamplePage <datarobot.models.documentai.document.DocumentTextExtractionSamplePage>`
  \- {class}`DocumentTextExtractionSampleDocument <datarobot.models.documentai.document.DocumentTextExtractionSampleDocument>`
- Added new fields to {class}`CustomTaskVersion <datarobot.models.custom_task_version.CustomTaskVersion>`
  for controlling network policies. The new fields were also added to the response. This can be set with
  `datarobot.enums.CustomTaskOutgoingNetworkPolicy`.
- Added a new method {meth}`BatchPredictionJob.score_with_leaderboard_model <datarobot.models.BatchPredictionJob.score_with_leaderboard_model>` to run batch predictions using a Leaderboard model instead of a deployment.
- Set {class}`IntakeSettings <datarobot.models.batch_job.IntakeSettings>` and {class}`OutputSettings <datarobot.models.batch_job.OutputSettings>` to use `IntakeAdapters` and `OutputAdapters` enum values respectively for the property `type`.
- Added method meth:`Deployment.get_predictions_vs_actuals_over_time <datarobot.models.Deployment.get_predictions_vs_actuals_over_time>` to retrieve a deployment's predictions vs actuals over time data.

### Bugfixes

- Payload property `subset` renamed to `source` in {meth}`Model.request_feature_effect <datarobot.models.Model.request_feature_effect>`
- Fixed an issue where Context.trace_context was not being set from environment variables or DR config files.
- {meth}`Project.refresh <datarobot.models.Project.refresh>` no longer sets `Project.advanced_options` to a dictionary.
- Fixed {meth}`Dataset.modify <datarobot.models.Dataset.modify>` to clarify behavior of when to preserve or clear categories.
- Fixed an issue with enums in f-strings resulting in the enum class and property being printed instead of the enum property's value in Python 3.11 environments.

### Deprecation summary

- {meth}`Project.refresh <datarobot.models.Project.refresh>` will no longer set `Project.advanced_options` to a dictionary after version 3.5 is released.
  : All interactions with `Project.advanced_options` should be expected to be through the {class}`AdvancedOptions <datarobot.helpers.AdvancedOptions>` class.

### Experimental changes

- Added a new class, {class}`VectorDatabase <datarobot.models.genai.vector_database.VectorDatabase>`, for interacting with DataRobot vector databases.
  {meth}`VectorDatabase.get <datarobot.models.genai.vector_database.VectorDatabase.get>` retrieves a VectorDatabase object by ID.
  {meth}`VectorDatabase.list <datarobot.models.genai.vector_database.VectorDatabase.list>` lists all VectorDatabases available to the user.
  {meth}`VectorDatabase.create <datarobot.models.genai.vector_database.VectorDatabase.create>` creates a new VectorDatabase.
  {meth}`VectorDatabase.create <datarobot.models.genai.vector_database.VectorDatabase.create_from_custom_model>` allows you to use a validated deployment of a custom model as your own Vector Database.
  {meth}`VectorDatabase.update <datarobot.models.genai.vector_database.VectorDatabase.update>` updates the name of a VectorDatabase.
  {meth}`VectorDatabase.delete <datarobot.models.genai.vector_database.VectorDatabase.delete>` deletes a single VectorDatabase.
  {meth}`VectorDatabase.get_supported_embeddings <datarobot.models.genai.vector_database.VectorDatabase.get_supported_embeddings>` retrieves all supported embedding models.
  {meth}`VectorDatabase.get_supported_text_chunkings <datarobot.models.genai.vector_database.VectorDatabase.get_supported_text_chunkings>` retrieves all supported text chunking configurations.
  {meth}`VectorDatabase.download_text_and_embeddings_asset <datarobot.models.genai.vector_database.VectorDatabase.download_text_and_embeddings_asset>` download a parquet file with internal vector database data.
- Added a new class, {class}`CustomModelVectorDatabaseValidation <datarobot.models.genai.vector_database.CustomModelVectorDatabaseValidation>`, for validating custom model deployments for use as a vector database.
  {meth}`CustomModelVectorDatabaseValidation.get <datarobot.models.genai.custom_model_validation.CustomModelValidation.get>` retrieves a CustomModelVectorDatabaseValidation object by ID.
  {meth}`CustomModelVectorDatabaseValidation.get_by_values <datarobot.models.genai.custom_model_validation.CustomModelValidation.get_by_values>` retrieves a CustomModelVectorDatabaseValidation object by field values.
  {meth}`CustomModelVectorDatabaseValidation.create <datarobot.models.genai.custom_model_validation.CustomModelValidation.create>` starts validation of the deployment.
  {meth}`CustomModelVectorDatabaseValidation.revalidate <datarobot.models.genai.custom_model_validation.CustomModelValidation.revalidate>` repairs an unlinked external vector database.
- Added a new class, {class}`Playground <datarobot.models.genai.playground.Playground>`, for interacting with DataRobot generative AI playgrounds.
  {meth}`Playground.get <datarobot.models.genai.playground.Playground.get>` retrieves a playground object by ID.
  {meth}`Playground.list <datarobot.models.genai.playground.Playground.list>` lists all playgrounds available to the user.
  {meth}`Playground.create <datarobot.models.genai.playground.Playground.create>` creates a new playground.
  {meth}`Playground.update <datarobot.models.genai.playground.Playground.update>` updates the name and description of a playground.
  {meth}`Playground.delete <datarobot.models.genai.playground.Playground.delete>` deletes a single playground.
- Added a new class, {class}`LLMDefinition <datarobot.models.genai.llm.LLMDefinition>`, for interacting with DataRobot generative AI LLMs.
  {meth}`LLMDefinition.list <datarobot.models.genai.llm.LLMDefinition.list>` lists all LLMs available to the user.
- Added a new class, {class}`LLMBlueprint <datarobot.models.genai.llm_blueprint.LLMBlueprint>`, for interacting with DataRobot generative AI LLM blueprints.
  {meth}`LLMBlueprint.get <datarobot.models.genai.llm_blueprint.LLMBlueprint.get>` retrieves an LLM blueprint object by ID.
  {meth}`LLMBlueprint.list <datarobot.models.genai.llm_blueprint.LLMBlueprint.list>` lists all LLM blueprints available to the user.
  {meth}`LLMBlueprint.create <datarobot.models.genai.llm_blueprint.LLMBlueprint.create>` creates a new LLM blueprint.
  {meth}`LLMBlueprint.create_from_llm_blueprint <datarobot.models.genai.llm_blueprint.LLMBlueprint.create_from_llm_blueprint>` creates a new LLM blueprint from an existing one.
  {meth}`LLMBlueprint.update <datarobot.models.genai.llm_blueprint.LLMBlueprint.update>` updates an LLM blueprint.
  {meth}`LLMBlueprint.delete <datarobot.models.genai.llm_blueprint.LLMBlueprint.delete>` deletes a single LLM blueprint.
- Added a new class, {class}`ChatPrompt <datarobot.models.genai.chat_prompt.ChatPrompt>`, for interacting with DataRobot generative AI chat prompts.
  {meth}`ChatPrompt.get <datarobot.models.genai.chat_prompt.ChatPrompt.get>` retrieves a chat prompt object by ID.
  {meth}`ChatPrompt.list <datarobot.models.genai.chat_prompt.ChatPrompt.list>` lists all chat prompts available to the user.
  {meth}`ChatPrompt.create <datarobot.models.genai.chat_prompt.ChatPrompt.create>` creates a new chat prompt.
  {meth}`ChatPrompt.delete <datarobot.models.genai.chat_prompt.ChatPrompt.delete>` deletes a single chat prompt.
- Added a new class, {class}`CustomModelLLMValidation <datarobot.models.genai.custom_model_llm_validation.CustomModelLLMValidation>`, for validating custom model deployments for use as a custom model LLM.
  {meth}`CustomModelLLMValidation.get <datarobot.models.genai.custom_model_validation.CustomModelValidation.get>` retrieves a CustomModelLLMValidation object by ID.
  {meth}`CustomModelLLMValidation.get_by_values <datarobot.models.genai.custom_model_validation.CustomModelValidation.get_by_values>` retrieves a CustomModelLLMValidation object by field values.
  {meth}`CustomModelLLMValidation.create <datarobot.models.genai.custom_model_validation.CustomModelValidation.create>` starts validation of the deployment.
  {meth}`CustomModelLLMValidation.revalidate <datarobot.models.genai.custom_model_validation.CustomModelValidation.revalidate>` repairs an unlinked external custom model LLM.
- Added a new class, {class}`ComparisonPrompt <datarobot.models.genai.comparison_prompt.ComparisonPrompt>`, for interacting with DataRobot generative AI comparison prompts.
  {meth}`ComparisonPrompt.get <datarobot.models.genai.comparison_prompt.ComparisonPrompt.get>` retrieves a comparison prompt object by ID.
  {meth}`ComparisonPrompt.list <datarobot.models.genai.comparison_prompt.ComparisonPrompt.list>` lists all comparison prompts available to the user.
  {meth}`ComparisonPrompt.create <datarobot.models.genai.comparison_prompt.ComparisonPrompt.create>` creates a new comparison prompt.
  {meth}`ComparisonPrompt.update <datarobot.models.genai.comparison_prompt.ComparisonPrompt.update>` updates a comparison prompt.
  {meth}`ComparisonPrompt.delete <datarobot.models.genai.comparison_prompt.ComparisonPrompt.delete>` deletes a single comparison prompt.
- Extended {class}`UseCase <datarobot.UseCase>`, adding two new fields to represent the count of vector databases and playgrounds.
- Added a new method, {meth}`ChatPrompt.create_llm_blueprint <datarobot.models.genai.chat_prompt.ChatPrompt.create_llm_blueprint>`, to create an LLM blueprint from a chat prompt.
- Added a new method, {meth}`CustomModelLLMValidation.delete <datarobot.models.genai.custom_model_validation.CustomModelValidation.delete>`, to delete a custom model LLM validation record.
- Added a new method, {meth}`LLMBlueprint.register_custom_model <datarobot.models.genai.llm_blueprint.LLMBlueprint.register_custom_model>`, for registering a custom model from a generative AI LLM blueprint.

## 3.2.0

### New features

- Added new methods to trigger batch monitoring jobs without providing a job definition.
  {meth}`BatchMonitoringJob.run <datarobot.models.BatchMonitoringJob.run>`
  {meth}`BatchMonitoringJob.get_status <datarobot.models.BatchMonitoringJob.get_status>`
  {meth}`BatchMonitoringJob.cancel <datarobot.models.BatchMonitoringJob.cancel>`
  {meth}`BatchMonitoringJob.download <datarobot.models.BatchMonitoringJob.download>`

- Added {meth}`Deployment.submit_actuals_from_catalog_async<datarobot.models.Deployment.submit_actuals_from_catalog_async>` to submit actuals from the AI Catalog.

- Added a new class {class}`StatusCheckJob <datarobot.models.StatusCheckJob>` which represents a job for a status check of submitted async jobs.

- Added a new class {class}`JobStatusResult <datarobot.models.JobStatusResult>` represents the result for a status check job of a submitted async task.

- Added {meth}`DatetimePartitioning.datetime_partitioning_log_retrieve <datarobot.DatetimePartitioning.datetime_partitioning_log_retrieve>` to download the datetime partitioning log.

- Added method {meth}`DatetimePartitioning.datetime_partitioning_log_list <datarobot.DatetimePartitioning.datetime_partitioning_log_list>` to list the datetime partitioning log.

- Added {meth}`DatetimePartitioning.get_input_data <datarobot.DatetimePartitioning.get_input_data>` to retrieve the input data used to create an optimized datetime partitioning.

- Added {class}`DatetimePartitioningId <datarobot.helpers.partitioning_methods.DatetimePartitioningId>`, which can be passed as a `partitioning_method` to {meth}`Project.analyze_and_model <datarobot.models.Project.analyze_and_model>`.

- Added the ability to share deployments. See :ref:`deployment sharing <deployment_sharing>` for more information on sharing deployments.

- Added new methods get_bias_and_fairness_settings and update_bias_and_fairness_settings to retrieve or update bias and fairness settings.
  {meth}`Deployment.get_bias_and_fairness_settings<datarobot.models.Deployment.get_bias_and_fairness_settings>`
  {meth}`Deployment.update_bias_and_fairness_settings<datarobot.models.Deployment.update_bias_and_fairness_settings>`

- Added a new class {class}`UseCase <datarobot.UseCase>` for interacting with the DataRobot Use Cases API.

- Added a new class {class}`Application <datarobot.Application>` for retrieving DataRobot Applications available to the user.

- Added a new class {class}`SharingRole <datarobot.models.sharing.SharingRole>` to hold user or organization access rights.

- Added a new class {class}`BatchMonitoringJob <datarobot.models.BatchMonitoringJob>` for interacting with batch monitoring jobs.

- Added a new class {class}`BatchMonitoringJobDefinition <datarobot.models.BatchMonitoringJobDefinition>` for interacting with batch monitoring jobs definitions.

- Added a new methods for handling monitoring job definitions: list, get, create, update, delete, run_on_schedule and run_once
  {meth}`BatchMonitoringJobDefinition.list <datarobot.models.BatchMonitoringJobDefinition.list>`
  {meth}`BatchMonitoringJobDefinition.get <datarobot.models.BatchMonitoringJobDefinition.get>`
  {meth}`BatchMonitoringJobDefinition.create <datarobot.models.BatchMonitoringJobDefinition.create>`
  {meth}`BatchMonitoringJobDefinition.update <datarobot.models.BatchMonitoringJobDefinition.update>`
  {meth}`BatchMonitoringJobDefinition.delete <datarobot.models.BatchMonitoringJobDefinition.delete>`
  {meth}`BatchMonitoringJobDefinition.run_on_schedule <datarobot.models.BatchMonitoringJobDefinition.run_on_schedule>`
  {meth}`BatchMonitoringJobDefinition.run_once <datarobot.models.BatchMonitoringJobDefinition.run_once>`

- Added a new method to retrieve a monitoring job
  {meth}`BatchMonitoringJob.get <datarobot.models.BatchMonitoringJob.get>`

- Added the ability to filter return objects by a Use Case ID passed to the following methods:
  {meth}`Dataset.list <datarobot.models.Dataset.list>`
  {meth}`Project.list <datarobot.models.Project.list>`

- Added the ability to automatically add a newly created dataset or project to a Use Case by passing a UseCase, list of UseCase objects, UseCase ID or list of UseCase IDs using the keyword argument `use_cases` to the following methods:
  {meth}`Dataset.create_from_file <datarobot.models.Dataset.create_from_file>`
  {meth}`Dataset.create_from_in_memory_data <datarobot.models.Dataset.create_from_in_memory_data>`
  {meth}`Dataset.create_from_url <datarobot.models.Dataset.create_from_url>`
  {meth}`Dataset.create_from_data_source <datarobot.models.Dataset.create_from_data_source>`
  {meth}`Dataset.create_from_query_generator <datarobot.models.Dataset.create_from_query_generator>`
  {meth}`Dataset.create_project <datarobot.models.Dataset.create_project>`
  {meth}`Project.create <datarobot.models.Project.create>`
  {meth}`Project.create_from_data_source <datarobot.models.Project.create_from_data_source>`
  {meth}`Project.create_from_dataset <datarobot.models.Project.create_from_dataset>`
  {meth}`Project.create_segmented_project_from_clustering_model <datarobot.models.Project.create_segmented_project_from_clustering_model>`
  {meth}`Project.start <datarobot.models.Project.start>`

- Added the ability to set a default {class}`UseCase <datarobot.UseCase>` for requests. It can be set in several ways.

  - If the user configures the client via `Client(...)`, then invoke `Client(..., default_use_case = <id>)`.
  - If the user configures the client via dr.config.yaml, then add the property `default_use_case: <id>`.
  - If the user configures the client via env vars, then set the env var `DATAROBOT_DEFAULT_USE_CASE`.
  - The default use case can also be set programmatically as a context manager via `with UseCase.get(<id>):`.

- Added the ability to configure the collection of client usage metrics to send to DataRobot. Note that this feature only tracks which DataRobot package methods are called and does not collect any user data. You can configure collection with the following settings:

  - If the user configures the client via `Client(...)`, then invoke `Client(..., enable_api_consumer_tracking = <True/False>)`.
  - If the user configures the client via dr.config.yaml, then add the property `enable_api_consumer_tracking: <True/False>`.
  - If the user configures the client via env vars, then set the env var `DATAROBOT_API_CONSUMER_TRACKING_ENABLED`.

  Currently the default value for `enable_api_consumer_tracking` is `True`.

- Added method meth:`Deployment.get_predictions_over_time <datarobot.models.Deployment.get_predictions_over_time>` to retrieve deployment predictions over time data.

- Added a new class {class}`FairnessScoresOverTime <datarobot.models.deployment.bias_and_fairness.FairnessScoresOverTime>` to retrieve fairness over time information.

- Added a new method {meth}`Deployment.get_fairness_scores_over_time <datarobot.models.Deployment.get_fairness_scores_over_time>` to retrieve fairness scores over time of a deployment.

- Added a new `use_gpu` parameter to the method {meth}`Project.analyze_and_model<datarobot.models.Project.analyze_and_model>` to set whether the project should allow usage of GPU

- Added a new `use_gpu` parameter to the class {class}`Project <datarobot.models.Project>` with information whether project allows usage of GPU

- Added a new class {class}`TrainingData <datarobot.models.custom_model_version.TrainingData>` for retrieving TrainingData assigned to {class}`CustomModelVersion <datarobot.CustomModelVersion>`.

- Added a new class {class}`HoldoutData <datarobot.models.custom_model_version.HoldoutData>` for retrieving HoldoutData assigned to {class}`CustomModelVersion <datarobot.CustomModelVersion>`.

- Added the ability to retrieve the model and blueprint json using the following methods:
  {meth}`Model.get_model_blueprint_json <datarobot.models.Model.get_model_blueprint_json>`
  {meth}`Blueprint.get_json <datarobot.models.Blueprint.get_json>`

- Added {meth}`Credential.update <datarobot.models.Credential.update>` which allows you to update existing credential resources.

- Added a new optional parameter `trace_context` to `datarobot.Client` to provide additional information on the DataRobot code being run. This parameter defaults to `None`.

- Updated methods in {class}`Model <datarobot.models.model.Model>` to support use of Sliced Insights:
  {meth}`Model.get_feature_effect <datarobot.models.Model.get_feature_effect>`
  {meth}`Model.request_feature_effect <datarobot.models.Model.request_feature_effect>`
  {meth}`Model.get_or_request_feature_effect <datarobot.models.Model.get_or_request_feature_effect>`
  {meth}`Model.get_lift_chart <datarobot.models.Model.get_lift_chart>`
  {meth}`Model.get_all_lift_charts <datarobot.models.Model.get_all_lift_charts>`
  {meth}`Model.get_residuals_chart <datarobot.models.Model.get_residuals_chart>`
  {meth}`Model.get_all_residuals_charts <datarobot.models.Model.get_all_residuals_charts>`
  {meth}`Model.request_lift_chart <datarobot.models.Model.request_lift_chart>`
  {meth}`Model.request_residuals_chart <datarobot.models.Model.request_residuals_chart>`
  {meth}`Model.get_roc_curve<datarobot.models.Model.get_roc_curve>`
  {meth}`Model.get_feature_impact <datarobot.models.Model.get_feature_impact>`
  {meth}`Model.request_feature_impact <datarobot.models.Model.request_feature_impact>`
  {meth}`Model.get_or_request_feature_impact <datarobot.models.Model.get_or_request_feature_impact>`

- Added support for {class}`SharingRole <datarobot.models.sharing.SharingRole>` to the following methods:
  \- {meth}`DataStore.share <datarobot.DataStore.share>`

- Added new methods for retrieving {class}`SharingRole <datarobot.models.sharing.SharingRole>` information for the following classes:
  \- {meth}`DataStore.get_shared_roles <datarobot.DataStore.get_shared_roles>`

- Added new method for calculating sliced roc curve {meth}`Model.request_roc_curve <datarobot.models.Model.request_roc_curve>`

- Added new {class}`DataSlice <datarobot.models.data_slice.DataSlice>` to support the following slices methods:
  {meth}`DataSlice.list <datarobot.models.data_slice.DataSlice.list>` to retrieve all data slices in a project.
  {meth}`DataSlice.create <datarobot.models.data_slice.DataSlice.create>` to create a new data slice.
  {meth}`DataSlice.delete <datarobot.models.data_slice.DataSlice.delete>` to delete the data slice calling this method.
  {meth}`DataSlice.request_size <datarobot.models.data_slice.DataSlice.request_size>` to submit a request to calculate a data slice size on a source.
  {meth}`DataSlice.get_size_info <datarobot.models.data_slice.DataSlice.get_size_info>` to get the data slice's info when applied to a source.
  {meth}`DataSlice.get <datarobot.models.data_slice.DataSlice.get>` to retrieve a specific data slice.

- Added new {class}`DataSliceSizeInfo <datarobot.models.data_slice.DataSliceSizeInfo>` to define the result of a data slice applied to a source.

- Added new method for retrieving all available feature impacts for the model {meth}`Model.get_all_feature_impacts <datarobot.models.Model.get_all_feature_impacts>`.

- Added new method for StatusCheckJob to wait and return the completed object once it is generated {meth}`datarobot.models.StatusCheckJob.get_result_when_complete`

### Enhancements

- Improve error message of {meth}`SampleImage.list<datarobot.models.visualai.SampleImage.list>`
  to clarify that a selected parameter cannot be used when a project has not proceeded to the
  correct stage prior to calling this method.
- Extended {meth}`SampleImage.list<datarobot.models.visualai.SampleImage.list>` by two parameters
  to filter for a target value range in regression projects.
- Added text explanations data to {meth}`PredictionExplanations <datarobot.PredictionExplanations>` and made sure it is returned in both {py:meth}`datarobot.PredictionExplanations.get_all_as_dataframe`  and {py:meth}`datarobot.PredictionExplanations.get_rows` method.
- Added two new parameters to {meth}`Project.upload_dataset_from_catalog <datarobot.models.Project.upload_dataset_from_catalog>`:
  : - `credential_id`
    - `credential_data`
- Implemented training and holdout data assignment for Custom Model Version creation APIs:
  : - {meth}`CustomModelVersion.create_clean <datarobot.CustomModelVersion.create_clean>`
    - {meth}`CustomModelVersion.create_from_previous <datarobot.CustomModelVersion.create_from_previous>`

    The parameters added to both APIs are:
    : - `training_dataset_id`
      - `partition_column`
      - `holdout_dataset_id`
      - `keep_training_holdout_data`
      - `max_wait`
- Extended {meth}`CustomInferenceModel.create <datarobot.CustomInferenceModel.create>` and {meth}`CustomInferenceModel.update <datarobot.CustomInferenceModel.update>`
  with the parameter `is_training_data_for_versions_permanently_enabled`.
- Added value `DR_API_ACCESS` to the `NETWORK_EGRESS_POLICY` enum.
- Added new parameter `low_memory` to {meth}`Dataset.get_as_dataframe <datarobot.models.Dataset.get_as_dataframe>` to allow a low memory mode for larger datasets
- Added two new parameters to {meth}`Project.list <datarobot.models.Project.list>` for paginating long project lists:
  : - `offset`
    - `limit`

### Bugfixes

- Fixed incompatibilities with Pandas 2.0 in {meth}`DatetimePartitioning.to_dataframe <datarobot.DatetimePartitioning.to_dataframe>`.
- Fixed a crash when using non-"latin-1" characters in Panda's DataFrame used as prediction data in {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score>`.
- Fixed an issue where failed authentication when invoking `datarobot.client.Client()` raises a misleading error about client-server compatibility.
- Fixed incompatibilities with Pandas 2.0 in {meth}`AccuracyOverTime.get_as_dataframe <datarobot.models.deployment.AccuracyOverTime.get_as_dataframe>`. The method will now throw a `ValueError` if an empty list is passed to the parameter `metrics`.

### API changes

- Added parameter `unsupervised_type` to the class {class}`DatetimePartitioning <datarobot.DatetimePartitioning>`.
- The sliced insight API endpoint `GET: api/v2/insights/<insight_name>/` returns a paginated response. This means that it returns an empty response if no insights data is found, unlike `GET: api/v2/projects/<pid>/models/<lid>/<insight_name>/`, which returns 404 NOT FOUND in this case. To maintain backwards-compatibility, all methods that retrieve insights data raise 404 NOT FOUND if the insights API returns an empty response.

### Deprecation summary

- `Model.get_feature_fit_metadata` has been removed.
  Use {meth}`Model.get_feature_effect_metadata <datarobot.models.Model.get_feature_effect_metadata>` instead.
- `DatetimeModel.get_feature_fit_metadata` has been removed.
  Use {meth}`DatetimeModel.get_feature_effect_metadata <datarobot.models.DatetimeModel.get_feature_effect_metadata>` instead.
- `Model.request_feature_fit` has been removed.
  Use {meth}`Model.request_feature_effect <datarobot.models.Model.request_feature_effect>` instead.
- `DatetimeModel.request_feature_fit` has been removed.
  Use {meth}`DatetimeModel.request_feature_effect <datarobot.models.DatetimeModel.request_feature_effect>` instead.
- `Model.get_feature_fit` has been removed.
  Use {meth}`Model.get_feature_effect <datarobot.models.Model.get_feature_effect>` instead.
- `DatetimeModel.get_feature_fit` has been removed.
  Use {meth}`DatetimeModel.get_feature_effect <datarobot.models.DatetimeModel.get_feature_effect>` instead.
- `Model.get_or_request_feature_fit` has been removed.
  Use {meth}`Model.get_or_request_feature_effect <datarobot.models.Model.get_or_request_feature_effect>` instead.
- `DatetimeModel.get_or_request_feature_fit` has been removed.
  Use {meth}`DatetimeModel.get_or_request_feature_effect <datarobot.models.DatetimeModel.get_or_request_feature_effect>` instead.
- Deprecated the use of {class}`SharingAccess <datarobot.models.sharing.SharingAccess>` in favor of {class}`SharingRole <datarobot.models.sharing.SharingRole>` for sharing in the following classes:
  \- {meth}`DataStore.share <datarobot.DataStore.share>`
- Deprecated the following methods for retrieving {class}`SharingAccess <datarobot.models.sharing.SharingAccess>` information.
  \- `DataStore.get_access_list`. Please use {meth}`DataStore.get_shared_roles <datarobot.DataStore.get_shared_roles>` instead.
- {meth}`CustomInferenceModel.assign_training_data <datarobot.CustomInferenceModel.assign_training_data>` was marked as deprecated and will be removed in v3.4.
  Use {meth}`CustomModelVersion.create_clean <datarobot.CustomModelVersion.create_clean>` and {meth}`CustomModelVersion.create_from_previous <datarobot.CustomModelVersion.create_from_previous>` instead.

### Configuration changes

- Pins dependency on package [urllib3](https://pypi.org/project/urllib3/)  to be less than version 2.0.0.

### Deprecation summary

- Deprecated parameter `user_agent_suffix` in `datarobot.Client`. `user_agent_suffix` will be removed in v3.4. Please use `trace_context` instead.

### Documentation changes

- Fixed in-line documentation of `DataRobotClientConfig`.
- Fixed documentation around client configuration from environment variables or config file.

### Experimental changes

- Added experimental support for data matching:

  - {class}`DataMatching <datarobot._experimental.models.data_matching.DataMatching>`
  - {class}`DataMatchingQuery <datarobot._experimental.models.data_matching.DataMatchingQuery>`

- Added new method {meth}`DataMatchingQuery.get_result <datarobot._experimental.models.data_matching.DataMatchingQuery.get_result>` for returning data matching query results as pandas dataframes to {class}`DataMatchingQuery <datarobot._experimental.models.data_matching.DataMatchingQuery>` .

- Changed behavior for returning results in the {class}`DataMatching <datarobot._experimental.models.data_matching.DataMatching>`. Instead of saving the results as a file, a pandas dataframe will be returned in the following methods:
  : - {meth}`DataMatching.get_closest_data <datarobot._experimental.models.data_matching.DataMatching.get_closest_data>`
    - {meth}`DataMatching.get_closest_data_for_model <datarobot._experimental.models.data_matching.DataMatching.get_closest_data_for_model>`
    - {meth}`DataMatching.get_closest_data_for_featurelist <datarobot._experimental.models.data_matching.DataMatching.get_closest_data_for_featurelist>`

- Added experimental support for model lineage: {class}`ModelLineage <datarobot._experimental.models.model_lineage.ModelLineage>`

- Changed behavior for methods that search for the closest data points in {class}`DataMatching <datarobot._experimental.models.data_matching.DataMatching>`. If the index is missing, instead of throwing the error, methods try to create the index and then query it. This is enabled by default, but if this is not the intended behavior it can be changed by passing `False` to the new `build_index` parameter added to the methods:
  : - {meth}`DataMatching.get_closest_data <datarobot._experimental.models.data_matching.DataMatching.get_closest_data>`
    - {meth}`DataMatching.get_closest_data_for_model <datarobot._experimental.models.data_matching.DataMatching.get_closest_data_for_model>`
    - {meth}`DataMatching.get_closest_data_for_featurelist <datarobot._experimental.models.data_matching.DataMatching.get_closest_data_for_featurelist>`

- Added a new class {class}`Notebook <datarobot.models.notebooks.Notebook>` for retrieving DataRobot Notebooks available to the user.

- Added experimental support for data wrangling:

  - {class}`Recipe <datarobot.models.recipe.Recipe>`

## 3.1.1

### Configuration changes

- Removes dependency on package [contextlib2](https://pypi.org/project/contextlib2/)  since the package is Python 3.7+.
- Update [typing-extensions](https://pypi.org/project/typing-extensions/) to be inclusive of versions from 4.3.0 to \< 5.0.0.

## 3.1.0

### Enhancements

- Added new methods {meth}`BatchPredictionJob.apply_time_series_data_prep_and_score<datarobot.models.BatchPredictionJob.apply_time_series_data_prep_and_score>`
  and {meth}`BatchPredictionJob.apply_time_series_data_prep_and_score_to_file<datarobot.models.BatchPredictionJob.apply_time_series_data_prep_and_score_to_file>`
  that apply time series data prep to a file or dataset and make batch predictions with a deployment.
- Added new methods {meth}`DataEngineQueryGenerator.prepare_prediction_dataset<datarobot.DataEngineQueryGenerator.prepare_prediction_dataset>`
  and {meth}`DataEngineQueryGenerator.prepare_prediction_dataset_from_catalog<datarobot.DataEngineQueryGenerator.prepare_prediction_dataset_from_catalog>`
  that apply time series data prep to a file or catalog dataset and upload the prediction dataset to a
  project.
- Added new `max_wait` parameter to method {meth}`Project.create_from_dataset<datarobot.models.Project.create_from_dataset>`.
  Values larger than the default can be specified to avoid timeouts when creating a project from Dataset.
- Added new method for creating a segmented modeling project from an existing clustering project and model
  {meth}`Project.create_segmented_project_from_clustering_model<datarobot.models.Project.create_segmented_project_from_clustering_model>`.
  Please switch to this function if you are previously using ModelPackage for segmented modeling purposes.
- Added new method is_unsupervised_clustering_or_multiclass for checking whether the clustering or multiclass parameters are used, quick and efficient without extra API calls.
  {meth}`PredictionExplanations.is_unsupervised_clustering_or_multiclass <datarobot.PredictionExplanations.is_unsupervised_clustering_or_multiclass>`
- Retry idempotent requests which result in HTTP 502 and HTTP 504 (in addition to the previous HTTP 413, HTTP 429 and HTTP 503)
- Added value PREPARED_FOR_DEPLOYMENT to the RECOMMENDED_MODEL_TYPE enum
- Added two new methods to the ImageAugmentationList class:
  {meth}`ImageAugmentationList.list<datarobot.models.visualai.ImageAugmentationList.list>`,
  {meth}`ImageAugmentationList.update<datarobot.models.visualai.ImageAugmentationList.update>`

### Bugfixes

- Added `format` key to Batch Prediction intake and output settings for S3, GCP and Azure

### API changes

- The method {meth}`PredictionExplanations.is_multiclass <datarobot.PredictionExplanations.is_multiclass>` now adds an additional API call to check for multiclass target validity, which adds a small delay.
- {class}`AdvancedOptions <datarobot.helpers.AdvancedOptions>` parameter `blend_best_models` defaults to false
- {class}`AdvancedOptions <datarobot.helpers.AdvancedOptions>` parameter `consider_blenders_in_recommendation` defaults to false
- {class}`DatetimePartitioning <datarobot.DatetimePartitioning>` has parameter `unsupervised_mode`

### Deprecation summary

- Deprecated method {meth}`Project.create_from_hdfs<datarobot.models.Project.create_from_hdfs>`.
- Deprecated method {meth}`DatetimePartitioning.generate <datarobot.DatetimePartitioning.generate>`.
- Deprecated parameter `in_use` from {meth}`ImageAugmentationList.create<datarobot.models.visualai.ImageAugmentationList.create>` as DataRobot will take care of it automatically.
- Deprecated property `Deployment.capabilities` from {class}`Deployment <datarobot.models.Deployment>`.
- `ImageAugmentationSample.compute` was removed in v3.1. You
  can get the same information with the method `ImageAugmentationList.compute_samples`.
- `sample_id` parameter removed from `ImageAugmentationSample.list`. Please use `auglist_id` instead.

### Documentation changes

- Update the documentation to suggest that setting `use_backtest_start_end_format` of {py:meth}`DatetimePartitioning.to_specification <datarobot.DatetimePartitioning.to_specification>` to `True` will mirror the same behavior as the Web UI.
- Update the documentation to suggest setting `use_start_end_format` of {py:meth}`Backtest.to_specification <datarobot.helpers.partitioning_methods.Backtest.to_specification>` to `True` will mirror the same behavior as the Web UI.

## 3.0.3

### Bugfixes

- Fixed an issue affecting backwards compatibility in {class}`datarobot.models.DatetimeModel`, where an unexpected keyword from the DataRobot API would break class deserialization.

## 3.0.2

### Bugfixes

- Restored `Model.get_leaderboard_ui_permalink`, `Model.open_model_browser`,
  These methods were accidentally removed instead of deprecated.
- Fix for ipykernel \< 6.0.0 which does not persist contextvars across cells

### Deprecation summary

- Deprecated method `Model.get_leaderboard_ui_permalink`. Please use {meth}`Model.get_uri <datarobot.models.Model.get_uri>` instead.
- Deprecated method `Model.open_model_browser`. Please use {meth}`Model.open_in_browser <datarobot.models.Model.open_in_browser>` instead.

## 3.0.1

### Bugfixes

- Added `typing-extensions` as a required dependency for the DataRobot Python API client.

## 3.0.0

### New features

- Version 3.0 of the Python client does not support Python 3.6 and earlier versions. Version 3.0 currently supports Python 3.7+.

- The default Autopilot mode for {meth}`project.start_autopilot <datarobot.models.Project.start_autopilot>` has changed to Quick mode.

- For datetime-aware models, you can now calculate and retrieve feature impact for backtests other than zero and holdout:

  - {meth}`DatetimeModel.get_feature_impact <datarobot.models.DatetimeModel.get_feature_impact>`
  - {meth}`DatetimeModel.request_feature_impact <datarobot.models.DatetimeModel.request_feature_impact>`
  - {meth}`DatetimeModel.get_or_request_feature_impact <datarobot.models.DatetimeModel.get_or_request_feature_impact>`

- Added a `backtest` field to feature impact metadata: {meth}`Model.get_or_request_feature_impact <datarobot.models.Model.get_feature_impact>`. This field is null for non-datetime-aware models and greater than or equal to zero for holdout in datetime-aware models.

- You can use a new method to retrieve the canonical URI for a project, model, deployment, or dataset:

  - {meth}`Project.get_uri <datarobot.models.Project.get_uri>`
  - {meth}`Model.get_uri <datarobot.models.Model.get_uri>`
  - {meth}`Deployment.get_uri <datarobot.models.Deployment.get_uri>`
  - {meth}`Dataset.get_uri <datarobot.models.Dataset.get_uri>`

- You can use a new method to open a class in a browser based on their URI (project, model, deployment, or dataset):

  - {meth}`Project.open_in_browser <datarobot.models.Project.open_in_browser>`
  - {meth}`Model.open_in_browser <datarobot.models.Model.open_in_browser>`
  - {meth}`Deployment.open_in_browser <datarobot.models.Deployment.open_in_browser>`
  - {meth}`Dataset.open_in_browser <datarobot.models.Dataset.open_in_browser>`

- Added a new method for opening DataRobot in a browser: {meth}`datarobot.rest.RESTClientObject.open_in_browser`. Invoke the method via `dr.Client().open_in_browser()`.

- Altered method {meth}`Project.create_featurelist <datarobot.models.Project.create_featurelist>` to accept five new parameters (please see documentation for information about usage):

  - `starting_featurelist`
  - `starting_featurelist_id`
  - `starting_featurelist_name`
  - `features_to_include`
  - `features_to_exclude`

- Added a new method to retrieve a feature list by name: {meth}`Project.get_featurelist_by_name <datarobot.models.Project.get_featurelist_by_name>`.

- Added a new convenience method to create datasets: {meth}`Dataset.upload <datarobot.models.Dataset.upload>`.

- Altered the method {meth}`Model.request_predictions <datarobot.models.Model.request_predictions>` to accept four new parameters:

  - `dataset`
  - `file`
  - `file_path`
  - `dataframe`
  - Note that the method already supports the parameter `dataset_id` and all data source parameters are mutually exclusive.

- Added a new method to {class}`datarobot.models.Dataset`, {meth}`Dataset.get_as_dataframe <datarobot.models.Dataset.get_as_dataframe>`, which retrieves all the originally uploaded data in a pandas DataFrame.

- Added a new method to {class}`datarobot.models.Dataset`, {meth}`Dataset.share <datarobot.models.Dataset.share>`, which allows the sharing of a dataset with another user.

- Added new convenience methods to {class}`datarobot.models.Project` for dealing with partition classes. Both methods should be called before {meth}`Project.analyze_and_model <datarobot.models.Project.analyze_and_model>`.
  \- {meth}`Project.set_partitioning_method <datarobot.models.Project.set_partitioning_method>` intelligently creates the correct partition class for a regular project, based on input arguments.
  \- {meth}`Project.set_datetime_partitioning <datarobot.models.Project.set_datetime_partitioning>` creates the correct partition class for a time series project.

- Added a new method to {class}`datarobot.models.Project` {meth}`Project.get_top_model <datarobot.models.Project.get_top_model>` which returns the highest scoring model for a metric of your choice.

- Use the new method {meth}`Deployment.predict_batch <datarobot.models.Deployment.predict_batch>` to pass a file, file path, or DataFrame to {class}`datarobot.models.Deployment` to easily make batch predictions and return the results as a DataFrame.

- Added support for passing in a credentials ID or credentials data to {meth}`Project.create_from_data_source <datarobot.models.Project.create_from_data_source>` as an alternative to providing a username and password.

- You can now pass in a `max_wait` value to {meth}`AutomatedDocument.generate <datarobot.models.automated_documentation.AutomatedDocument.generate>`.

- Added a new method to {class}`datarobot.models.Project` {meth}`Project.get_dataset <datarobot.models.Project.get_dataset>` which retrieves the dataset used during creation of a project.

- Added two new properties to {class}`datarobot.models.Project`:
  \- `catalog_id`
  \- `catalog_version_id`

- Added a new Autopilot method to {class}`datarobot.models.Project` {meth}`Project.analyze_and_model <datarobot.models.Project.analyze_and_model>` which allows you to initiate Autopilot or data analysis against data uploaded to DataRobot.

- Added a new convenience method to {class}`datarobot.models.Project` {meth}`Project.set_options <datarobot.models.Project.set_options>` which allows you to save {py:class}`AdvancedOptions <datarobot.helpers.AdvancedOptions>` values for use in modeling.

- Added a new convenience method to {class}`datarobot.models.Project` {meth}`Project.get_options <datarobot.models.Project.get_options>` which allows you to retrieve saved modeling options.

### Enhancements

- Refactored the global singleton client connection ({meth}`datarobot.client.Client`) to use ContextVar instead of a global variable for better concurrency support.
- Added support for creating monotonic feature lists for time series projects. Set `skip_datetime_partition_column` to
  True to create monotonic feature list. For more information see {meth}`datarobot.models.Project.create_modeling_featurelist`.
- Added information about vertex to advanced tuning parameters {meth}`datarobot.models.Model.get_advanced_tuning_parameters`.
- Added the ability to automatically use saved {py:class}`AdvancedOptions <datarobot.helpers.AdvancedOptions>` set using {meth}`Project.set_options <datarobot.models.Project.set_options>` in {meth}`Project.analyze_and_model <datarobot.models.Project.analyze_and_model>`.

### Bugfixes

- {meth}`Dataset.list <datarobot.models.Dataset.list>` no longer throws errors when listing datasets with no owner.
- Fixed an issue with the creation of `BatchPredictionJobDefinitions` containing a schedule.
- Fixed error handling in `datarobot.helpers.partitioning_methods.get_class`.
- Fixed issue with portions of the payload not using camelCasing in {meth}`Project.upload_dataset_from_catalog<datarobot.models.Project.upload_dataset_from_catalog>`.

### API changes

- The Python client now outputs a `DataRobotProjectDeprecationWarning` when you attempt to access certain resources (projects, models, deployments, etc.) that are deprecated or disabled as a result of the DataRobot platform's migration to Python 3.
- The Python client now raises a `TypeError` when you try to retrieve a labelwise ROC on a binary model or a binary ROC on a multilabel model.
- The method {meth}`Dataset.create_from_data_source<datarobot.models.Dataset.create_from_data_source>` now raises `InvalidUsageError` if `username` and `password` are not passed as a pair together.

### Deprecation summary

- `Model.get_leaderboard_ui_permalink` has been removed.
  Use {meth}`Model.get_uri <datarobot.models.Model.get_uri>` instead.
- `Model.open_model_browser` has been removed.
  Use {meth}`Model.open_in_browser <datarobot.models.Model.open_in_browser>` instead.
- `Project.get_leaderboard_ui_permalink` has been removed.
  Use {meth}`Project.get_uri <datarobot.models.Project.get_uri>` instead.
- `Project.open_leaderboard_browser` has been removed.
  Use {meth}`Project.open_in_browser <datarobot.models.Project.open_in_browser>` instead.
- Enum `VARIABLE_TYPE_TRANSFORM.CATEGORICAL` has been removed
- Instantiation of {class}`Blueprint <datarobot.models.Blueprint>` using a dict has been removed. Use {meth}`Blueprint.from_data <datarobot.models.Blueprint.from_data>` instead.
- Specifying an environment to use for testing with {class}`CustomModelTest <datarobot.CustomModelTest>` has been removed.
- {class}`CustomModelVersion <datarobot.CustomModelVersion>`'s `required_metadata` parameter has been removed. Use `required_metadata_values` instead.
- {class}`CustomTaskVersion <datarobot.CustomTaskVersion>`'s `required_metadata` parameter has been removed. Use `required_metadata_values` instead.
- Instantiation of {class}`Feature <datarobot.models.Feature>` using a dict has been removed. Use {meth}`Feature.from_data <datarobot.models.Feature.from_data>` instead.
- Instantiation of {class}`Featurelist <datarobot.models.Featurelist>` using a dict has been removed. Use {meth}`Featurelist.from_data <datarobot.models.Featurelist.from_data>` instead.
- Instantiation of {class}`Model <datarobot.models.Model>` using a dict, tuple, or the `data` parameter has been removed. Use {meth}`Model.from_data <datarobot.models.Model.from_data>` instead.
- Instantiation of {class}`Project <datarobot.models.Project>` using a dict has been removed. Use {meth}`Project.from_data <datarobot.models.Project.from_data>` instead.
- {class}`Project <datarobot.models.Project>`'s `quickrun` parameter has been removed. Pass `AUTOPILOT_MODE.QUICK` as the `mode` instead.
- {class}`Project <datarobot.models.Project>`'s `scaleout_max_train_pct` and `scaleout_max_train_rows` parameters have been removed.
- `ComplianceDocumentation` has been removed. Use {class}`AutomatedDocument <datarobot.models.automated_documentation.AutomatedDocument>` instead.
- The {class}`Deployment <datarobot.models.Deployment>` method `create_from_custom_model_image` was removed. Use {meth}`Deployment.create_from_custom_model_version <datarobot.models.Deployment.create_from_custom_model_version>` instead.
- `PredictJob.create` has been removed. Use {meth}`Model.request_predictions <datarobot.models.Model.request_predictions>` instead.
- `Model.fetch_resource_data` has been removed. Use {meth}`Model.get <datarobot.models.Model.get>` instead.
- The class `CustomInferenceImage` was removed. Use {class}`CustomModelVersion <datarobot.CustomModelVersion>` with `base_environment_id` instead.
- `Project.set_target` has been deprecated. Use {meth}`Project.analyze_and_model <datarobot.models.Project.analyze_and_model>` instead.

### Configuration changes

- Added a context manager {meth}`client_configuration <datarobot.client.client_configuration>` that can be used to change the connection configuration temporarily, for use in asynchronous or multithreaded code.
- Upgraded the `Pillow` library to version 9.2.0. Users installing DataRobot with the "images" extra (`pip install datarobot[images]`) should note that this is a required library.

### Experimental changes

- Added experimental support for retrieving document thumbnails:

  - {class}`DocumentThumbnail <datarobot.models.documentai.document.DocumentThumbnail>`
  - {class}`DocumentPageFile <datarobot.models.documentai.document.DocumentPageFile>`

- Added experimental support to retrieve document text extraction samples using:
  \- {class}`DocumentTextExtractionSample <datarobot.models.documentai.document.DocumentTextExtractionSample>`
  \- {class}`DocumentTextExtractionSamplePage <datarobot.models.documentai.document.DocumentTextExtractionSamplePage>`
  \- {class}`DocumentTextExtractionSampleDocument <datarobot.models.documentai.document.DocumentTextExtractionSampleDocument>`

- Added experimental deployment improvements:
  \- {class}`RetrainingPolicy <datarobot._experimental.models.retraining.RetrainingPolicy>` can be used to manage retraining policies associated with a deployment.

- Added an experimental deployment improvement:
  \- Use {class}`RetrainingPolicyRun <datarobot._experimental.models.retraining.RetrainingPolicyRun>` to manage retraining policies run for a retraining policy associated with a deployment.

- Added new methods to {class}`RetrainingPolicy <datarobot._experimental.models.retraining.RetrainingPolicy>`:
  \- Use {meth}`RetrainingPolicy.get <datarobot._experimental.models.retraining.RetrainingPolicy.get>` to get a retraining policy associated with a deployment.
  \-  Use {meth}`RetrainingPolicy.delete <datarobot._experimental.models.retraining.RetrainingPolicy.delete>` to delete a retraining policy associated with a deployment.

## 2.29.0

### New features

- Added support to pass `max_ngram_explanations` parameter in batch predictions that will trigger the
  compute of text prediction explanations.

  - {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score>`

- Added support to pass calculation mode to prediction explanations
  (`mode` parameter in {meth}`PredictionExplanations.create <datarobot.PredictionExplanations.create>`)
  as well as batch scoring
  (`explanations_mode` in {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score>`)
  for multiclass models. Supported modes:

  - {class}`TopPredictionsMode <datarobot.models.TopPredictionsMode>`
  - {class}`ClassListMode <datarobot.models.ClassListMode>`

- Added method {meth}`datarobot.CalendarFile.create_calendar_from_dataset` to the calendar file that allows us
  to create a calendar from a dataset.

- Added experimental support for `n_clusters` parameter in
  {meth}`Model.train_datetime <datarobot.models.Model.train_datetime>` and
  {meth}`DatetimeModel.retrain <datarobot.models.DatetimeModel.retrain>`
  that allows to specify number of clusters when creating models in Time Series Clustering project.

- Added new parameter `clone` to {meth}`datarobot.CombinedModel.set_segment_champion` that allows to
  set a new champion model in a cloned model instead of the original one, leaving latter unmodified.

- Added new property `is_active_combined_model` to {class}`datarobot.CombinedModel` that indicates
  if the selected combined model is currently the active one in the segmented project.

- Added new {meth}`datarobot.models.Project.get_active_combined_model` that allows users to get
  the currently active combined model in the segmented project.

- Added new parameters `read_timeout` to method `ShapMatrix.get_as_dataframe`.
  Values larger than the default can be specified to avoid timeouts when requesting large files.
  {meth}`ShapMatrix.get_as_dataframe <datarobot.models.ShapMatrix.get_as_dataframe>`

- Added support for bias mitigation with the following methods
  \- {meth}`Project.get_bias_mitigated_models <datarobot.models.Project.get_bias_mitigated_models>`
  \- {meth}`Project.apply_bias_mitigation <datarobot.models.Project.apply_bias_mitigation>`
  \- {meth}`Project.request_bias_mitigation_feature_info <datarobot.models.Project.request_bias_mitigation_feature_info>`
  \- {meth}`Project.get_bias_mitigation_feature_info <datarobot.models.Project.get_bias_mitigation_feature_info>`
  and by adding new bias mitigation params
  \- bias_mitigation_feature_name
  \- bias_mitigation_technique
  \- include_bias_mitigation_feature_as_predictor_variable
  to the existing method
  \- {meth}`Project.start <datarobot.models.Project.start>`
  and by adding this enum to supply params to some of the above functionality `datarobot.enums.BiasMitigationTechnique`

- Added new property `status` to {class}`datarobot.models.Deployment` that represents model deployment status.

- Added new {meth}`Deployment.activate <datarobot.models.Deployment.activate>`
  and {meth}`Deployment.deactivate <datarobot.models.Deployment.deactivate>`
  that allows deployment activation and deactivation

- Added new {meth}`Deployment.delete_monitoring_data <datarobot.models.Deployment.delete_monitoring_data>` to delete deployment monitoring data.

### Enhancements

- Added support for specifying custom endpoint URLs for S3 access in batch predictions:

  - {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score>`
  - {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score_s3>`

  See: `endpoint_url` parameter.

- Added guide on :ref:`working with binary data <binary_data>`

- Added multithreading support to binary data helper functions.

- Binary data helpers image defaults aligned with application's image preprocessing.

- Added the following accuracy metrics to be retrieved for a deployment - TPR, PPV, F1 and MCC :ref:`Deployment monitoring <deployment_monitoring>`

### Bugfixes

- Don't include holdout start date, end date, or duration in datetime partitioning payload when
  holdout is disabled.
- Removed ICE Plot capabilities from Feature Fit.
- Handle undefined calendar_name in CalendarFile.create_calendar_from_dataset
- Raise ValueError for submitted calendar names that are not strings

### API changes

- `version` field is removed from `ImportedModel` object

### Deprecation summary

- Reason Codes objects deprecated in 2.13 version were removed.
  Please use Prediction Explanations instead.

### Configuration changes

- The upper version constraint on pandas has been removed.

### Documentation changes

- Fixed a minor typo in the example for Dataset.create_from_data_source.
- Update the documentation to suggest that `feature_derivation_window_end` of {py:class}`datarobot.DatetimePartitioningSpecification` class should be a negative or zero.

## 2.28.0

### New features

- Added new parameter `upload_read_timeout` to {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score>`
  and {meth}`BatchPredictionJob.score_to_file <datarobot.models.BatchPredictionJob.score_to_file>` to indicate how many seconds to wait
  until intake dataset uploads to server. Default value 600s.

- Added the ability to turn off supervised feature reduction for Time Series projects. Option
  `use_supervised_feature_reduction` can be set in {py:class}`AdvancedOptions <datarobot.helpers.AdvancedOptions>`.

- Allow `maximum_memory` to be input for custom tasks versions. This will be used for setting the limit
  to which a custom task prediction container memory can grow.

- Added method {meth}`datarobot.models.Project.get_multiseries_names` to the project service which will
  return all the distinct entries in the multiseries column

- Added new `segmentation_task_id` attribute to {meth}`datarobot.models.Project.set_target` that allows to
  start project as Segmented Modeling project.

- Added new property `is_segmented` to {class}`datarobot.models.Project` that indicates if project is a
  regular one or Segmented Modeling project.

- Added method {meth}`datarobot.models.Project.restart_segment` to the project service that allows to
  restart single segment that hasn\'t reached modeling phase.

- Added the ability to interact with Combined Models in Segmented Modeling projects.
  Available with new class: {class}`datarobot.CombinedModel`.

  Functionality:
  : - {meth}`datarobot.CombinedModel.get`
    - {meth}`datarobot.CombinedModel.get_segments_info`
    - {meth}`datarobot.CombinedModel.get_segments_as_dataframe`
    - {meth}`datarobot.CombinedModel.get_segments_as_csv`
    - {meth}`datarobot.CombinedModel.set_segment_champion`

- Added the ability to create and retrieve segmentation tasks used in Segmented Modeling projects.
  Available with new class: {class}`datarobot.SegmentationTask`.

  Functionality:
  : - {meth}`datarobot.SegmentationTask.create`
    - {meth}`datarobot.SegmentationTask.list`
    - {meth}`datarobot.SegmentationTask.get`

- Added new class: {class}`datarobot.SegmentInfo` that allows to get information on all segments of
  Segmented modeling projects, i.e. segment project ID, model counts, autopilot status.

  Functionality:
  : - {meth}`datarobot.SegmentInfo.list`

- Added new methods to base `APIObject` to assist with dictionary and json serialization of child objects.

  Functionality:
  : - `APIObject.to_dict`
    - `APIObject.to_json`

- Added new methods to `ImageAugmentationList` for interacting with image augmentation samples.

  Functionality:
  : - `ImageAugmentationList.compute_samples`
    - `ImageAugmentationList.retrieve_samples`

- Added the ability to set a prediction threshold when creating a deployment from a learning model.

- Added support for governance, owners, predictionEnvironment, and fairnessHealth fields when querying for a Deployment object.

- Added helper methods for working with files, images and documents. Methods support conversion of
  file contents into base64 string representations. Methods for images provide also image resize and
  transformation support.

  Functionality:
  : - {meth}`get_encoded_file_contents_from_urls <datarobot.helpers.binary_data_utils.get_encoded_file_contents_from_urls>`
    - {meth}`get_encoded_file_contents_from_paths <datarobot.helpers.binary_data_utils.get_encoded_file_contents_from_paths>`
    - {meth}`get_encoded_image_contents_from_paths <datarobot.helpers.binary_data_utils.get_encoded_image_contents_from_paths>`
    - {meth}`get_encoded_image_contents_from_urls <datarobot.helpers.binary_data_utils.get_encoded_image_contents_from_urls>`

### Enhancements

- Requesting metadata instead of actual data of {class}`datarobot.PredictionExplanations` to reduce the amount of data transfer

### Bugfixes

- Fix a bug in {meth}`Job.get_result_when_complete <datarobot.models.Job.get_result_when_complete>` for Prediction Explanations job type to
  populate all attribute of of {class}`datarobot.PredictionExplanations` instead of just one
- Fix a bug in {class}`datarobot.models.ShapImpact` where `row_count` was not optional
- Allow blank value for schema and catalog in `RelationshipsConfiguration` response data
- Fix a bug where credentials were incorrectly formatted in
  {meth}`Project.upload_dataset_from_catalog <datarobot.models.Project.upload_dataset_from_catalog>`
  and
  {meth}`Project.upload_dataset_from_data_source <datarobot.models.Project.upload_dataset_from_data_source>`
- Rejecting downloads of Batch Prediction data that was not written to the localfile output adapter
- Fix a bug in {meth}`datarobot.models.BatchPredictionJobDefinition.create` where `schedule` was not optional for all cases

### API changes

- User can include ICE plots data in the response when requesting Feature Effects/Feature Fit. Extended methods are
  : - {meth}`Model.get_feature_effect <datarobot.models.Model.get_feature_effect>`,
    - `Model.get_feature_fit <datarobot.models.Model.get_feature_fit>`,
    - {meth}`DatetimeModel.get_feature_effect <datarobot.models.DatetimeModel.get_feature_effect>` and
    - `DatetimeModel.get_feature_fit <datarobot.models.DatetimeModel.get_feature_fit>`.

### Deprecation summary

- `attrs` library is removed from library dependencies
- `ImageAugmentationSample.compute` was marked as deprecated and will be removed in v2.30. You
  can get the same information with newly introduced method `ImageAugmentationList.compute_samples`
- `ImageAugmentationSample.list` using `sample_id`
- Deprecating scaleout parameters for projects / models. Includes `scaleout_modeling_mode`,
  `scaleout_max_train_pct`, and `scaleout_max_train_rows`

### Configuration changes

- `pandas` upper version constraint is updated to include version 1.3.5.

### Documentation changes

- Fixed "from datarobot.enums" import in Unsupervised Clustering example provided in docs.

## 2.27.0

### New features

- {class}`datarobot.UserBlueprint` is now mature with full support of functionality. Users
  are encouraged to use the [Blueprint Workshop](https://blueprint-workshop.datarobot.com) instead of
  this class directly.

- Added the arguments attribute in {class}`datarobot.CustomTaskVersion`.

- Added the ability to retrieve detected errors in the potentially multicategorical feature types that prevented the
  feature to be identified as multicategorical.
  {meth}`Project.download_multicategorical_data_format_errors<datarobot.models.Project.download_multicategorical_data_format_errors>`

- Added the support of listing/updating user roles on one custom task.
  : - {meth}`datarobot.CustomTask.get_access_list`
    - {meth}`datarobot.CustomTask.share`

- Added a method {meth}`datarobot.models.Dataset.create_from_query_generator`. This creates a dataset
  in the AI catalog from a `datarobot.DataEngineQueryGenerator`.

- Added the new functionality of creating a user blueprint with a custom task version id.
  {meth}`datarobot.UserBlueprint.create_from_custom_task_version_id`.

- The DataRobot Python Client is no longer published under the Apache-2.0 software license, but rather under the terms
  of the DataRobot Tool and Utility Agreement.

- Added a new class: {class}`datarobot.DataEngineQueryGenerator`. This class generates a Spark
  SQL query to apply time series data prep to a dataset in the AI catalog.

  Functionality:
  : - {meth}`datarobot.DataEngineQueryGenerator.create`
    - {meth}`datarobot.DataEngineQueryGenerator.get`
    - {meth}`datarobot.DataEngineQueryGenerator.create_dataset`

  See the :ref:`time series data prep documentation <time_series_data_prep>` for more information.

- Added the ability to upload a prediction dataset into a project from the AI catalog
  {meth}`Project.upload_dataset_from_catalog<datarobot.models.Project.upload_dataset_from_catalog>`.

- Added the ability to specify the number of training rows to use in SHAP based Feature Impact computation. Extended
  method:

  > - {meth}`ShapImpact.create <datarobot.models.ShapImpact.create>`

- Added the ability to retrieve and restore features that have been reduced using the time series feature generation and
  reduction functionality. The functionality comes with a new
  class: {class}`datarobot.models.restore_discarded_features.DiscardedFeaturesInfo`.

  Functionality:
  : - {meth}`datarobot.models.restore_discarded_features.DiscardedFeaturesInfo.retrieve`
    - {meth}`datarobot.models.restore_discarded_features.DiscardedFeaturesInfo.restore`

- Added the ability to control class mapping aggregation in multiclass projects via
  {class}`ClassMappingAggregationSettings <datarobot.helpers.ClassMappingAggregationSettings>` passed as a parameter to
  {meth}`Project.set_target <datarobot.models.Project.set_target>`

- Added support for :ref:`unsupervised clustering projects<unsupervised_clustering>`

- Added the ability to compute and retrieve Feature Effects for a Multiclass model using
  {meth}`datarobot.models.Model.request_feature_effects_multiclass`,
  {meth}`datarobot.models.Model.get_feature_effects_multiclass` or
  {meth}`datarobot.models.Model.get_or_request_feature_effects_multiclass` methods. For datetime models use following
  methods {meth}`datarobot.models.DatetimeModel.request_feature_effects_multiclass`,
  {meth}`datarobot.models.DatetimeModel.get_feature_effects_multiclass` or
  {meth}`datarobot.models.DatetimeModel.get_or_request_feature_effects_multiclass` with `backtest_index` specified

- Added the ability to get and update challenger model settings for deployment
  class: {class}`datarobot.models.Deployment`

  Functionality:
  : - {meth}`datarobot.models.Deployment.get_challenger_models_settings`
    - {meth}`datarobot.models.Deployment.update_challenger_models_settings`

- Added the ability to get and update segment analysis settings for deployment
  class: {class}`datarobot.models.Deployment`

  Functionality:
  : - {meth}`datarobot.models.Deployment.get_segment_analysis_settings`
    - {meth}`datarobot.models.Deployment.update_segment_analysis_settings`

- Added the ability to get and update predictions by forecast date settings for deployment
  class: {class}`datarobot.models.Deployment`

  Functionality:
  : - {meth}`datarobot.models.Deployment.get_predictions_by_forecast_date_settings`
    - {meth}`datarobot.models.Deployment.update_predictions_by_forecast_date_settings`

- Added the ability to specify multiple feature derivation windows when creating a Relationships Configuration using
  {meth}`RelationshipsConfiguration.create <datarobot.models.RelationshipsConfiguration.create>`

- Added the ability to manipulate a legacy conversion for a custom inference model, using the
  class: {class}`CustomModelVersionConversion <datarobot.models.CustomModelVersionConversion>`

  Functionality:
  : - {meth}`CustomModelVersionConversion.run_conversion <datarobot.models.CustomModelVersionConversion.run_conversion>`
    - {meth}`CustomModelVersionConversion.stop_conversion <datarobot.models.CustomModelVersionConversion.stop_conversion>`
    - {meth}`CustomModelVersionConversion.get <datarobot.models.CustomModelVersionConversion.get>`
    - {meth}`CustomModelVersionConversion.get_latest <datarobot.models.CustomModelVersionConversion.get_latest>`
    - {meth}`CustomModelVersionConversion.list <datarobot.models.CustomModelVersionConversion.list>`

### Enhancements

- {meth}`Project.get <datarobot.models.Project.get>` returns the query_generator_id used for time series data prep when applicable.

- Feature Fit & Feature Effects can return `datetime` instead of `numeric` for `feature_type` field for
  numeric features that are derived from dates.

- These methods now provide additional field `rowCount` in SHAP based Feature Impact results.

  > - {meth}`ShapImpact.create <datarobot.models.ShapImpact.create>`
  > - {meth}`ShapImpact.get <datarobot.models.ShapImpact.get>`

- Improved performance when downloading prediction dataframes for Multilabel projects using:
  : - {meth}`Predictions.get_all_as_dataframe <datarobot.models.Predictions.get_all_as_dataframe>`
    - {meth}`PredictJob.get_predictions <datarobot.models.PredictJob.get_predictions>`
    - {meth}`Job.get_result <datarobot.models.Job.get_result>`

### Bugfixes

- fix {class}`datarobot.CustomTaskVersion` and {class}`datarobot.CustomModelVersion` to correctly format `required_metadata_values`
  before sending them via API
- Fixed response validation that could cause `DataError` when using {class}`datarobot.models.Dataset` for a dataset with a description that is an empty string.

### API changes

- {meth}`RelationshipsConfiguration.create <datarobot.models.RelationshipsConfiguration.create>` will include a
  new key `data_source_id` in `data_source` field when applicable

### Deprecation summary

- `Model.get_all_labelwise_roc_curves` has been removed.
  You can get the same information with multiple calls of
  {meth}`Model.get_labelwise_roc_curves <datarobot.models.Model.get_labelwise_roc_curves>`, one per data source.
- `Model.get_all_multilabel_lift_charts` has been removed.
  You can get the same information with multiple calls of
  {meth}`Model.get_multilabel_lift_charts <datarobot.models.Model.get_multilabel_lift_charts>`, one per data source.

### Documentation changes

- This release introduces a new documentation organization. The organization has been modified to better reflect the end-to-end modeling workflow. The new "Tutorials" section has 5 major topics that outline the major components of modeling: Data, Modeling, Predictions, MLOps, and Administration.
- The Getting Started workflow is now hosted at [DataRobot's API Documentation Home](https://docs.datarobot.com/en/docs/api/index.html).
- Added an example of how to set up optimized datetime partitioning for time series projects.

## 2.26.0

### New features

- Added the ability to use external baseline predictions for time series project. External
  dataset can be validated using {meth}`datarobot.models.Project.validate_external_time_series_baseline`.
  Option can be set in {py:class}`AdvancedOptions <datarobot.helpers.AdvancedOptions>` to scale
  datarobot models' accuracy performance using external dataset's accuracy performance.
  See the :ref:`external baseline predictions documentation <external_baseline_predictions>`
  for more information.

- Added the ability to generate exponentially weighted moving average features for time series
  project. Option can be set in {py:class}`AdvancedOptions <datarobot.helpers.AdvancedOptions>`
  and controls the alpha parameter used in exponentially weighted moving average operation.

- Added the ability to request a specific model be prepared for deployment using
  {meth}`Project.start_prepare_model_for_deployment<datarobot.models.Project.start_prepare_model_for_deployment>`.

- Added a new class: {class}`datarobot.CustomTask`. This class is a custom task that you can use
  as part (or all) of your blue print for training models. It needs
  {class}`datarobot.CustomTaskVersion` before it can properly be used.

  Functionality:
  : - Create, copy, update or delete:
      : - {meth}`datarobot.CustomTask.create`
        - {meth}`datarobot.CustomTask.copy`
        - {meth}`datarobot.CustomTask.update`
        - {meth}`datarobot.CustomTask.delete`
    - list, get and refresh current tasks:
      : - {meth}`datarobot.CustomTask.get`
        - {meth}`datarobot.CustomTask.list`
        - {meth}`datarobot.CustomTask.refresh`
    - Download the latest {class}`datarobot.CustomTaskVersion` of the {class}`datarobot.CustomTask`
      : - {meth}`datarobot.CustomTask.download_latest_version`

- Added a new class: {class}`datarobot.CustomTaskVersion`. This class
  is for management of specific versions of a custom task.

  Functionality:
  : - Create new custom task versions:
      : - {meth}`datarobot.CustomTaskVersion.create_clean`
        - {meth}`datarobot.CustomTaskVersion.create_from_previous`
    - list, get and refresh current available versions:
      : - {meth}`datarobot.CustomTaskVersion.list`
        - {meth}`datarobot.CustomTaskVersion.get`
        - {meth}`datarobot.CustomTaskVersion.refresh`
    - {meth}`datarobot.CustomTaskVersion.download`
      will download a tarball of the files used to create the custom task
    - {meth}`datarobot.CustomTaskVersion.update`
      updates the metadata for a custom task.

- Added the ability compute batch predictions for an in-memory DataFrame using
  {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score_pandas>`

- Added the ability to specify feature discovery settings when creating a Relationships Configuration using
  {meth}`RelationshipsConfiguration.create <datarobot.models.RelationshipsConfiguration.create>`

### Enhancements

- Improved performance when downloading prediction dataframes using:
  : - {meth}`Predictions.get_all_as_dataframe <datarobot.models.Predictions.get_all_as_dataframe>`
    - {meth}`PredictJob.get_predictions <datarobot.models.PredictJob.get_predictions>`
    - {meth}`Job.get_result <datarobot.models.Job.get_result>`
- Added new `max_wait` parameter to methods:
  : - {meth}`Dataset.create_from_url<datarobot.models.Dataset.create_from_url>`
    - {meth}`Dataset.create_from_in_memory_data<datarobot.models.Dataset.create_from_in_memory_data>`
    - {meth}`Dataset.create_from_data_source<datarobot.models.Dataset.create_from_data_source>`
    - {meth}`Dataset.create_version_from_in_memory_data<datarobot.models.Dataset.create_version_from_in_memory_data>`
    - {meth}`Dataset.create_version_from_url<datarobot.models.Dataset.create_version_from_url>`
    - {meth}`Dataset.create_version_from_data_source<datarobot.models.Dataset.create_version_from_data_source>`

### Bugfixes

- {meth}`Model.get<datarobot.models.Model.get>` will return a `DatetimeModel` instead of `Model`
  whenever the project is datetime partitioned. This enables the
  {meth}`ModelRecommendation.get_model<datarobot.models.ModelRecommendation.get_model>` to return
  a `DatetimeModel` instead of `Model` whenever the project is datetime partitioned.
- Try to read Feature Impact result if existing jobId is None in
  {meth}`Model.get_or_request_feature_impact <datarobot.models.Model.get_or_request_feature_impact>`.
- Set upper version constraints for pandas.
- {meth}`RelationshipsConfiguration.create <datarobot.models.RelationshipsConfiguration.create>` will return a `catalog`
  in `data_source` field
- Argument `required_metadata_keys` was not properly being sent in the update and create requests for
  {class}`datarobot.ExecutionEnvironment`.
- Fix issue with {class}`datarobot.ExecutionEnvironment` create method failing when used against older versions of the application
- {class}`datarobot.CustomTaskVersion` was not properly handling `required_metadata_values` from the API response

### API changes

- Updated {meth}`Project.start <datarobot.models.Project.start>` to use `AUTOPILOT_MODE.QUICK` when the
  `autopilot_on` param is set to True. This brings it in line with {meth}`Project.set_target
  <datarobot.models.Project.set_target>`.
- Updated {meth}`project.start_autopilot <datarobot.models.Project.start_autopilot>` to accept
  the following new GA parameters that are already in the public API: `consider_blenders_in_recommendation`,
  `run_leakage_removed_feature_list`

### Deprecation summary

- The `required_metadata` property of {class}`datarobot.CustomModelVersion` has been deprecated.
  `required_metadata_values` should be used instead.
- The `required_metadata` property of {class}`datarobot.CustomTaskVersion` has been deprecated.
  `required_metadata_values` should be used instead.

### Configuration changes

- Now requires dependency on package [scikit-learn](https://pypi.org/project/scikit-learn/)  rather than
  [sklearn](https://pypi.org/project/scikit-learn/). Note: This dependency is only used in example code. See
  [this scikit-learn issue](https://github.com/scikit-learn/scikit-learn/issues/8215) for more information.
- Now permits dependency on package [attrs](https://pypi.org/project/attrs/)  to be less than version 21. This
  fixes compatibility with apache-airflow.
- Allow to setup `Authorization: <type> <token>` type header for OAuth2 Bearer tokens.

### Documentation changes

- Update the documentation with respect to the permission that controls AI Catalog dataset snapshot behavior.

## 2.25.0

### New features

- There is a new {class}`AnomalyAssessmentRecord<datarobot.models.anomaly_assessment.AnomalyAssessmentRecord>` object that
  implements public API routes to work with anomaly assessment insight. This also adds explanations
  and predictions preview classes. The insight is available for anomaly detection models in time
  series unsupervised projects which also support calculation of Shapley values.

  > - {class}`AnomalyAssessmentPredictionsPreview<datarobot.models.anomaly_assessment.AnomalyAssessmentPredictionsPreview>`
  > - {class}`AnomalyAssessmentExplanations<datarobot.models.anomaly_assessment.AnomalyAssessmentExplanations>`

  Functionality:

  > - Initialize an anomaly assessment insight for the specified subset.
  >
  >   > - {meth}`DatetimeModel.initialize_anomaly_assessment<datarobot.models.DatetimeModel.initialize_anomaly_assessment>`
  >
  > - Get anomaly assessment records, shap explanations, predictions preview:
  >
  >   > - {meth}`DatetimeModel.get_anomaly_assessment_records<datarobot.models.DatetimeModel.get_anomaly_assessment_records>` list available records
  >   > - {meth}`AnomalyAssessmentRecord.get_predictions_preview<datarobot.models.anomaly_assessment.AnomalyAssessmentRecord.get_predictions_preview>` get predictions preview for the record
  >   > - {meth}`AnomalyAssessmentRecord.get_latest_explanations<datarobot.models.anomaly_assessment.AnomalyAssessmentRecord.get_latest_explanations>` get latest predictions along with shap explanations for the most anomalous records.
  >   > - {meth}`AnomalyAssessmentRecord.get_explanations<datarobot.models.anomaly_assessment.AnomalyAssessmentRecord.get_explanations>` get predictions along with shap explanations for the most anomalous records for the specified range.
  >
  > - Delete anomaly assessment record:
  >
  >   > - {meth}`AnomalyAssessmentRecord.delete<datarobot.models.anomaly_assessment.AnomalyAssessmentRecord.delete>` delete record

- Added an ability to calculate and retrieve Datetime trend plots for {meth}`DatetimeModel<datarobot.models.DatetimeModel>`.
  This includes Accuracy over Time, Forecast vs Actual, and Anomaly over Time.

  Plots can be calculated using a common method:

  > - {meth}`DatetimeModel.compute_datetime_trend_plots<datarobot.models.DatetimeModel.compute_datetime_trend_plots>`

  Metadata for plots can be retrieved using the following methods:

  > - {meth}`DatetimeModel.get_accuracy_over_time_plots_metadata<datarobot.models.DatetimeModel.get_accuracy_over_time_plots_metadata>`
  > - {meth}`DatetimeModel.get_forecast_vs_actual_plots_metadata<datarobot.models.DatetimeModel.get_forecast_vs_actual_plots_metadata>`
  > - {meth}`DatetimeModel.get_anomaly_over_time_plots_metadata<datarobot.models.DatetimeModel.get_anomaly_over_time_plots_metadata>`

  Plots can be retrieved using the following methods:

  > - {meth}`DatetimeModel.get_accuracy_over_time_plot<datarobot.models.DatetimeModel.get_accuracy_over_time_plot>`
  > - {meth}`DatetimeModel.get_forecast_vs_actual_plot<datarobot.models.DatetimeModel.get_forecast_vs_actual_plot>`
  > - {meth}`DatetimeModel.get_anomaly_over_time_plot<datarobot.models.DatetimeModel.get_anomaly_over_time_plot>`

  Preview plots can be retrieved using the following methods:

  > - {meth}`DatetimeModel.get_accuracy_over_time_plot_preview<datarobot.models.DatetimeModel.get_accuracy_over_time_plot_preview>`
  > - {meth}`DatetimeModel.get_forecast_vs_actual_plot_preview<datarobot.models.DatetimeModel.get_forecast_vs_actual_plot_preview>`
  > - {meth}`DatetimeModel.get_anomaly_over_time_plot_preview<datarobot.models.DatetimeModel.get_anomaly_over_time_plot_preview>`

- Support for Batch Prediction Job Definitions has now been added through the following class:
  {class}`BatchPredictionJobDefinition<datarobot.models.BatchPredictionJobDefinition>`.
  You can create, update, list and delete definitions using the following methods:

  > - {meth}`BatchPredictionJobDefinition.list <datarobot.models.BatchPredictionJobDefinition.list>`
  > - {meth}`BatchPredictionJobDefinition.create <datarobot.models.BatchPredictionJobDefinition.create>`
  > - {meth}`BatchPredictionJobDefinition.update <datarobot.models.BatchPredictionJobDefinition.update>`
  > - {meth}`BatchPredictionJobDefinition.delete <datarobot.models.BatchPredictionJobDefinition.delete>`

### Enhancements

- Added a new helper function to create Dataset Definition, Relationship and Secondary Dataset used by
  Feature Discovery Project. They are accessible via
  {py:class}`DatasetDefinition <datarobot.helpers.feature_discovery.DatasetDefinition>`
  {py:class}`Relationship <datarobot.helpers.feature_discovery.Relationship>`
  {py:class}`SecondaryDataset <datarobot.helpers.feature_discovery.SecondaryDataset>`
- Added new helper function to projects to retrieve the recommended model.
  {meth}`Project.recommended_model <datarobot.models.Project.recommended_model>`
- Added method to download feature discovery recipe SQLs (limited beta feature).
  {meth}`Project.download_feature_discovery_recipe_sqls<datarobot.models.Project.download_feature_discovery_recipe_sqls>`.
- Added `docker_context_size` and `docker_image_size` to {class}`datarobot.ExecutionEnvironmentVersion`

### Bugfixes

- Remove the deprecation warnings when using with latest versions of urllib3.
- {meth}`FeatureAssociationMatrix.get <datarobot.models.FeatureAssociationMatrix.get>` is now using correct query param
  name when `featurelist_id` is specified.
- Handle scalar values in `shapBaseValue` while converting a predictions response to a data frame.
- Ensure that if a configured endpoint ends in a trailing slash, the resulting full URL does
  not end up with double slashes in the path.
- {meth}`Model.request_frozen_datetime_model <datarobot.models.Model.request_frozen_datetime_model>` is now implementing correct
  validation of input parameter `training_start_date`.

### API changes

- Arguments `secondary_datasets` now accept {py:class}`SecondaryDataset <datarobot.helpers.feature_discovery.SecondaryDataset>`
  to create secondary dataset configurations
  \- {meth}`SecondaryDatasetConfigurations.create <datarobot.models.SecondaryDatasetConfigurations.create>`
- Arguments `dataset_definitions` and `relationships` now accept {py:class}`DatasetDefinition <datarobot.helpers.feature_discovery.DatasetDefinition>` {py:class}`Relationship <datarobot.helpers.feature_discovery.Relationship>`
  to create and replace relationships configuration
  \- {meth}`RelationshipsConfiguration.create <datarobot.models.RelationshipsConfiguration.create>` creates a new relationships configuration between datasets
  \- {meth}`RelationshipsConfiguration.retrieve <datarobot.models.RelationshipsConfiguration.get>` retrieve the requested relationships
  configuration
- Argument `required_metadata_keys` has been added to {class}`datarobot.ExecutionEnvironment`.  This should be used to
  define a list of {py:class}`RequiredMetadataKey <datarobot.models.execution_environment.RequiredMetadataKey>`.
  {class}`datarobot.CustomModelVersion` that use a base environment with `required_metadata_keys` must define
  values for these fields in their respective `required_metadata`
- Argument `required_metadata` has been added to {class}`datarobot.CustomModelVersion`.  This should be set with
  relevant values defined by the base environment's `required_metadata_keys`

## 2.24.0

### New features

- Partial history predictions can be made with time series time series multiseries models using the
  `allow_partial_history_time_series_predictions` attribute of the
  {py:class}`datarobot.DatetimePartitioningSpecification
  <datarobot.DatetimePartitioningSpecification>`.
  See the :ref:`Time Series <time_series>` documentation for more info.
- Multicategorical Histograms are now retrievable. They are accessible via
  {class}`MulticategoricalHistogram <datarobot.models.MulticategoricalHistogram>` or
  {meth}`Feature.get_multicategorical_histogram <datarobot.models.Feature.get_multicategorical_histogram>`.
- Add methods to retrieve per-class lift chart data for multilabel models:
  {meth}`Model.get_multilabel_lift_charts <datarobot.models.Model.get_multilabel_lift_charts>` and
  `Model.get_all_multilabel_lift_charts`.
- Add methods to retrieve labelwise ROC curves for multilabel models:
  {meth}`Model.get_labelwise_roc_curves <datarobot.models.Model.get_labelwise_roc_curves>` and
  `Model.get_all_labelwise_roc_curves`.
- Multicategorical Pairwise Statistics are now retrievable. They are accessible via
  {class}`PairwiseCorrelations <datarobot.models.PairwiseCorrelations>`,
  {class}`PairwiseJointProbabilities <datarobot.models.PairwiseJointProbabilities>` and
  {class}`PairwiseConditionalProbabilities <datarobot.models.PairwiseConditionalProbabilities>` or
  {meth}`Feature.get_pairwise_correlations <datarobot.models.Feature.get_pairwise_correlations>`,
  {meth}`Feature.get_pairwise_joint_probabilities <datarobot.models.Feature.get_pairwise_joint_probabilities>` and
  {meth}`Feature.get_pairwise_conditional_probabilities <datarobot.models.Feature.get_pairwise_conditional_probabilities>`.
- Add methods to retrieve prediction results of a deployment:
  : - {meth}`Deployment.get_prediction_results<datarobot.models.Deployment.get_prediction_results>`
    - {meth}`Deployment.download_prediction_results<datarobot.models.Deployment.download_prediction_results>`
- Add method to download scoring code of a deployment using {meth}`Deployment.download_scoring_code<datarobot.models.Deployment.download_scoring_code>`.
- Added Automated Documentation: now you can automatically generate documentation about various
  entities within the platform, such as specific models or projects. Check out the
  :ref:`Automated Documentation overview<automated_documentation_overview>` and also refer to
  the :ref:`API Reference<automated_documentation_api>` for more details.
- Create a new Dataset version for a given dataset by uploading from a file, URL or in-memory datasource.
  : - {meth}`Dataset.create_version_from_file<datarobot.models.Dataset.create_version_from_file>`
    - {meth}`Dataset.create_version_from_in_memory_data<datarobot.models.Dataset.create_version_from_in_memory_data>`
    - {meth}`Dataset.create_version_from_url<datarobot.models.Dataset.create_version_from_url>`
    - {meth}`Dataset.create_version_from_data_source<datarobot.models.Dataset.create_version_from_data_source>`

### Enhancements

- Added a new `status` called `FAILED` to from {class}`BatchPredictionJob <datarobot.models.BatchPredictionJob>` as
  this is a new status coming to Batch Predictions in an upcoming version of DataRobot.
- Added `base_environment_version_id` to {class}`datarobot.CustomModelVersion`.
- Support for downloading feature discovery training or prediction dataset using
  {meth}`Project.download_feature_discovery_dataset<datarobot.models.Project.download_feature_discovery_dataset>`.
- Added {class}`datarobot.models.FeatureAssociationMatrix`, {class}`datarobot.models.FeatureAssociationMatrixDetails`
  and {class}`datarobot.models.FeatureAssociationFeaturelists` that can be used to retrieve feature associations
  data as an alternative to {meth}`Project.get_associations <datarobot.models.Project.get_associations>`,
  {meth}`Project.get_association_matrix_details <datarobot.models.Project.get_association_matrix_details>` and
  {meth}`Project.get_association_featurelists <datarobot.models.Project.get_association_featurelists>` methods.

### Bugfixes

- Fixed response validation that could cause `DataError` when using
  {meth}`TrainingPredictions.list <datarobot.models.training_predictions.TrainingPredictions.list>` and
  {meth}`TrainingPredictions.get_all_as_dataframe <datarobot.models.training_predictions.TrainingPredictions.get_all_as_dataframe>`
  methods if there are training predictions computed with `explanation_algorithm`.

### API changes

- Remove `desired_memory` param from the following classes: {class}`datarobot.CustomInferenceModel`,
  {class}`datarobot.CustomModelVersion`, {class}`datarobot.CustomModelTest`
- Remove `desired_memory` param from the following methods:
  {meth}`CustomInferenceModel.create <datarobot.CustomInferenceModel.create>`,
  {meth}`CustomModelVersion.create_clean <datarobot.CustomModelVersion.create_clean>`,
  {meth}`CustomModelVersion.create_from_previous <datarobot.CustomModelVersion.create_from_previous>`,
  {meth}`CustomModelTest.create <datarobot.CustomModelTest.create>` and
  {meth}`CustomModelTest.create <datarobot.CustomModelTest.create>`

### Deprecation summary

- class `ComplianceDocumentation`
  will be deprecated in v2.24 and will be removed entirely in v2.27. Use
  {class}`AutomatedDocument<datarobot.models.automated_documentation.AutomatedDocument>`
  instead. To start off, see the
  :ref:`Automated Documentation overview<automated_documentation_overview>` for details.

### Documentation changes

- Remove reference to S3 for {meth}`Project.upload_dataset <datarobot.models.Project.upload_dataset>` since it is not supported by the server

## 2.23.0

### New features

- Calendars for time series projects can now be automatically generated by providing a country code to the method
  {meth}`CalendarFile.create_calendar_from_country_code<datarobot.CalendarFile.create_calendar_from_country_code>`.
  A list of allowed country codes can be retrieved using {meth}`CalendarFile.get_allowed_country_codes<datarobot.CalendarFile.get_allowed_country_codes>`
  For more information, see the :ref:`calendar documentation <preloaded_calendar_files>`.
- Added `` calculate_all_series` `` param to
  {meth}`DatetimeModel.compute_series_accuracy<datarobot.models.DatetimeModel.compute_series_accuracy>`.
  This option allows users to compute series accuracy for all available series at once,
  while by default it is computed for first 1000 series only.
- Added ability to specify sampling method when setting target of OTV project. Option can be set
  in {py:class}`AdvancedOptions <datarobot.helpers.AdvancedOptions>` and changes a way training data
  is defined in autopilot steps.
- Add support for custom inference model k8s resources management. This new feature enables
  users to control k8s resources allocation for their executed model in the k8s cluster.
  It involves in adding the following new parameters: `network_egress_policy`, `desired_memory`,
  `maximum_memory`, `replicas` to the following classes: {class}`datarobot.CustomInferenceModel`,
  {class}`datarobot.CustomModelVersion`, {class}`datarobot.CustomModelTest`
- Add support for multiclass custom inference and training models. This enables users to create
  classification custom models with more than two class labels. The {class}`datarobot.CustomInferenceModel`
  class can now use `datarobot.TARGET_TYPE.MULTICLASS` for their `target_type` parameter. Class labels for inference models
  can be set/updated using either a file or as a list of labels.
- Support for Listing all the secondary dataset configuration for a given project:
  : - {meth}`SecondaryDatasetConfigurations.list<datarobot.models.SecondaryDatasetConfigurations>`
- Add support for unstructured custom inference models. The {class}`datarobot.CustomInferenceModel`
  class can now use `datarobot.TARGET_TYPE.UNSTRUCTURED` for its `target_type` parameter.
  `target_name` parameter is optional for `UNSTRUCTURED` target type.
- All per-class lift chart data is now available for multiclass models using
  {meth}`Model.get_multiclass_lift_chart <datarobot.models.Model.get_all_multiclass_lift_charts>`.
- `AUTOPILOT_MODE.COMPREHENSIVE`, a new `mode`, has been added to
  {meth}`Project.set_target <datarobot.models.Project.set_target>`.
- Add support for anomaly detection custom inference models. The {class}`datarobot.CustomInferenceModel`
  class can now use `datarobot.TARGET_TYPE.ANOMALY` for its `target_type` parameter.
  `target_name` parameter is optional for `ANOMALY` target type.
- Support for Updating and retrieving the secondary dataset configuration for a Feature discovery deployment:
  : - {meth}`Deployment.update_secondary_dataset_config<datarobot.models.Deployment.update_secondary_dataset_config>`
    - {meth}`Deployment.get_secondary_dataset_config<datarobot.models.Deployment.get_secondary_dataset_config>`
- Add support for starting and retrieving Feature Impact information for {class}`datarobot.CustomModelVersion`
- Search for interaction features and Supervised Feature reduction for feature discovery project can now be specified
  : in {py:class}`AdvancedOptions <datarobot.helpers.AdvancedOptions>`.
- Feature discovery projects can now be created using the {meth}`Project.start <datarobot.models.Project.start>`
  method by providing `relationships_configuration_id`.
- Actions applied to input data during automated feature discovery can now be retrieved using {meth}`FeatureLineage.get <datarobot.models.FeatureLineage.get>`
  Corresponding feature lineage id is available as a new {class}`datarobot.models.Feature` field `feature_lineage_id`.
- Lift charts and ROC curves are now calculated for backtests 2+ in time series and OTV models.
  The data can be retrieved for individual backtests using {meth}`Model.get_lift_chart <datarobot.models.Model.get_lift_chart>`
  and {meth}`Model.get_roc_curve <datarobot.models.Model.get_roc_curve>`.
- The following methods now accept a new argument called credential_data, the credentials to authenticate with the database, to use instead of user/password or credential ID:
  : - {meth}`Dataset.create_from_data_source<datarobot.models.Dataset.create_from_data_source>`
    - {meth}`Dataset.create_project<datarobot.models.Dataset.create_project>`
    - {meth}`Project.create_from_dataset<datarobot.models.Project.create_from_dataset>`
- Add support for DataRobot Connectors, {class}`datarobot.Connector` provides a simple implementation to interface with connectors.

### Enhancements

- Running Autopilot on Leakage Removed feature list can now be specified in {py:class}`AdvancedOptions <datarobot.helpers.AdvancedOptions>`.
  By default, Autopilot will always run on Informative Features - Leakage Removed feature list if it exists. If the parameter
  `run_leakage_removed_feature_list` is set to False, then Autopilot will run on Informative Features or available custom feature list.
- Method {py:meth}`Project.upload_dataset <datarobot.models.Project.upload_dataset>`
  and {py:meth}`Project.upload_dataset_from_data_source <datarobot.models.Project.upload_dataset_from_data_source>`
  support new optional parameter `secondary_datasets_config_id` for Feature discovery project.

### Bugfixes

- added `disable_holdout` param in {class}`datarobot.DatetimePartitioning`
- Using {meth}`Credential.create_gcp<datarobot.models.Credential.create_gcp>` produced an incompatible credential
- `SampleImage.list` now supports Regression & Multilabel projects
- Using {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.download>` could in some circumstances
  result in a crash from trying to abort the job if it fails to start
- Using {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.download>` or
  {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score_to_file>` would produce incomplete
  results in case a job was aborted while downloading. This will now raise an exception.

### API changes

- New `sampling_method` param in {meth}`Model.train_datetime <datarobot.models.Model.train_datetime>`,
  {meth}`Project.train_datetime <datarobot.models.Project.train_datetime>`,
  {meth}`Model.train_datetime <datarobot.models.Model.request_frozen_datetime_model>` and
  {meth}`Model.train_datetime <datarobot.models.Model.retrain>`.
- New `target_type` param in {class}`datarobot.CustomInferenceModel`
- New arguments `secondary_datasets`, `name`, `creator_full_name`, `creator_user_id`, `created`,
  : `featurelist_id`, `credentials_ids`, `project_version` and `is_default` in {class}`datarobot.models.SecondaryDatasetConfigurations`
- New arguments `secondary_datasets`, `name`, `featurelist_id` to
  : {meth}`SecondaryDatasetConfigurations.create <datarobot.models.SecondaryDatasetConfigurations.create>`
- Class `FeatureEngineeringGraph` has been removed. Use {class}`datarobot.models.RelationshipsConfiguration` instead.
- Param `feature_engineering_graphs` removed from {meth}`Project.set_target<datarobot.models.Project.set_target>`.
- Param `config` removed from {meth}`SecondaryDatasetConfigurations.create<datarobot.models.SecondaryDatasetConfigurations.create>`.

### Deprecation summary

- `supports_binary_classification` and  `supports_regression` are deprecated
  : for {class}`datarobot.CustomInferenceModel` and will be removed in v2.24
- Argument `config` and  `supports_regression` are deprecated
  : for {class}`datarobot.models.SecondaryDatasetConfigurations` and will be removed in v2.24
- `CustomInferenceImage` has been deprecated and will be removed in v2.24.
  : {class}`datarobot.CustomModelVersion` with base_environment_id should be used in their place.
- `environment_id` and `environment_version_id` are deprecated for {meth}`CustomModelTest.create<datarobot.CustomModelTest.create>`

### Documentation changes

- `feature_lineage_id` is added as a new parameter in the response for retrieval of a {class}`datarobot.models.Feature` created by automated feature discovery or time series feature derivation.
  This id is required to retrieve a {class}`datarobot.models.FeatureLineage` instance.

## 2.22.1

### New features

- Batch Prediction jobs now support :ref:`dataset <batch_predictions-intake-types-dataset>` as intake settings for
  {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score>`.

- Create a Dataset from DataSource:

  > - {meth}`Dataset.create_from_data_source<datarobot.models.Dataset.create_from_data_source>`
  > - {meth}`DataSource.create_dataset<datarobot.DataSource.create_dataset>`

- Added support for Custom Model Dependency Management.  Please see :ref:`custom model documentation<custom_models>`.
  New features added:

  > - Added new argument `base_environment_id` to methods
  >   {meth}`CustomModelVersion.create_clean<datarobot.CustomModelVersion.create_clean>`
  >   and {meth}`CustomModelVersion.create_from_previous<datarobot.CustomModelVersion.create_from_previous>`
  > - New fields `base_environment_id` and `dependencies` to class
  >   {class}`datarobot.CustomModelVersion`
  > - New class {class}`datarobot.CustomModelVersionDependencyBuild`
  >   to prepare custom model versions with dependencies.
  > - Made argument `environment_id` of
  >   {meth}`CustomModelTest.create<datarobot.CustomModelTest.create>` optional to enable using
  >   custom model versions with dependencies
  > - New field `image_type` added to class
  >   {class}`datarobot.CustomModelTest`
  > - {meth}`Deployment.create_from_custom_model_version<datarobot.models.Deployment.create_from_custom_model_version>` can be used to create a deployment from a custom model version.

- Added new parameters for starting and re-running Autopilot with customizable settings within
  {meth}`Project.start_autopilot<datarobot.models.Project.start_autopilot>`.

- Added a new method to trigger Feature Impact calculation for a Custom Inference Image:
  `CustomInferenceImage.calculate_feature_impact`

- Added new method to retrieve number of iterations trained for early stopping models. Currently supports only tree-based models.
  {meth}`Model.get_num_iterations_trained <datarobot.models.Model.get_num_iterations_trained>`.

### Enhancements

- A description can now be added or updated for a project.
  {meth}`Project.set_project_description <datarobot.models.Project.set_project_description>`.
- Added new parameters `read_timeout` and `max_wait` to method {meth}`Dataset.create_from_file<datarobot.models.Dataset.create_from_file>`.
  Values larger than the default can be specified for both to avoid timeouts when uploading large files.
- Added new parameter `metric` to {class}`datarobot.models.deployment.TargetDrift`, {class}`datarobot.models.deployment.FeatureDrift`,
  {meth}`Deployment.get_target_drift<datarobot.models.Deployment.get_target_drift>`
  and {meth}`Deployment.get_feature_drift<datarobot.models.Deployment.get_feature_drift>`.
- Added new parameter `timeout` to {meth}`BatchPredictionJob.download <datarobot.models.BatchPredictionJob.download>` to indicate
  how many seconds to wait for the download to start (in case the job doesn\'t start processing immediately).
  Set to `-1` to disable.
  This parameter can also be sent as `download_timeout` to {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score>`
  and {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score_to_file>`.
  If the timeout occurs, the pending job will be aborted.
- Added new parameter `read_timeout` to {meth}`BatchPredictionJob.download <datarobot.models.BatchPredictionJob.download>` to indicate
  how many seconds to wait between each downloaded chunk.
  This parameter can also be sent as `download_read_timeout` to {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score>`
  and {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score_to_file>`.
- Added parameter `catalog` to {meth}`BatchPredictionJob <datarobot.models.BatchPredictionJob.score>` to both intake
  and output adapters for type `jdbc`.
- Consider blenders in recommendation can now be specified in {py:class}`AdvancedOptions <datarobot.helpers.AdvancedOptions>`.
  Blenders will be included when autopilot chooses a model to prepare and recommend for deployment.
- Added optional parameter `max_wait` to {meth}`Deployment.replace_model <datarobot.models.Deployment.replace_model>` to indicate
  the maximum time to wait for model replacement job to complete before erroring.

### Bugfixes

- Handle `null` values in `predictionExplanationMetadata["shapRemainingTotal"]` while converting a predictions
  response to a data frame.
- Handle `null` values in `customModel["latestVersion"]`
- Removed an extra column `status` from {class}`BatchPredictionJob <datarobot.models.BatchPredictionJob>` as
  it caused issues with never version of Trafaret validation.
- Make `predicted_vs_actual` optional in Feature Effects data because a feature may have insufficient qualified samples.
- Make `jdbc_url` optional in Data Store data because some data stores will not have it.
- The method {meth}`Project.get_datetime_models<datarobot.models.Project.get_datetime_models>` now correctly returns all
  `DatetimeModel` objects for the project, instead of just the first 100.
- Fixed a documentation error related to snake_case vs camelCase in the JDBC settings payload.
- Make trafaret validator for datasets use a syntax that works properly with a wider range of trafaret versions.
- Handle extra keys in CustomModelTests and CustomModelVersions
- `ImageEmbedding` and `ImageActivationMap` now supports regression projects.

### API changes

- The default value for the `mode` param in {meth}`Project.set_target
  <datarobot.models.Project.set_target>` has been changed from `AUTOPILOT_MODE.FULL_AUTO`
  to `AUTOPILOT_MODE.QUICK`

### Documentation changes

- Added links to classes with duration parameters such as `validation_duration` and `holdout_duration` to
  provide duration string examples to users.
- The :ref:`models documentation <models>` has been revised to include section on how to train a new model and how to run cross-validation
  or backtesting for a model.

## 2.21.0

### New features

- Added new arguments `explanation_algorithm` and `max_explanations` to method
  {meth}`Model.request_training_predictions <datarobot.models.Model.request_training_predictions>`.
  New fields `explanation_algorithm`, `max_explanations` and `shap_warnings` have been added to class
  {class}`TrainingPredictions <datarobot.models.training_predictions.TrainingPredictions>`.
  New fields `prediction_explanations` and `shap_metadata` have been added to class
  {class}`TrainingPredictionsIterator <datarobot.models.training_predictions.TrainingPredictionsIterator>` that is
  returned by method
  {meth}`TrainingPredictions.iterate_rows <datarobot.models.training_predictions.TrainingPredictions.iterate_rows>`.

- Added new arguments `explanation_algorithm` and `max_explanations` to method
  {meth}`Model.request_predictions <datarobot.models.Model.request_predictions>`. New fields `explanation_algorithm`,
  `max_explanations` and `shap_warnings` have been added to class
  {class}`Predictions <datarobot.models.Predictions>`. Method
  {meth}`Predictions.get_all_as_dataframe <datarobot.models.Predictions.get_all_as_dataframe>` has new argument
  `serializer` that specifies the retrieval and results validation method (`json` or `csv`) for the predictions.

- Added possibility to compute {meth}`ShapImpact.create <datarobot.models.ShapImpact.create>` and request
  {meth}`ShapImpact.get <datarobot.models.ShapImpact.get>` SHAP impact scores for features in a model.

- Added support for accessing Visual AI images and insights. See the DataRobot
  Python Package documentation, Visual AI Projects, section for details.

- User can specify custom row count when requesting Feature Effects. Extended methods are
  {meth}`Model.request_feature_effect <datarobot.models.Model.request_feature_effect>` and
  {meth}`Model.get_or_request_feature_effect <datarobot.models.Model.get_or_request_feature_effect>`.

- Users can request SHAP based predictions explanations for a models that support SHAP scores using
  {meth}`ShapMatrix.create <datarobot.models.ShapMatrix.create>`.

- Added two new methods to {class}`Dataset<datarobot.models.Dataset>` to lazily retrieve paginated
  responses.

  > - {meth}`Dataset.iterate<datarobot.models.Dataset.iterate>` returns an iterator of the datasets
  >   that a user can view.
  > - {meth}`Dataset.iterate_all_features<datarobot.models.Dataset.iterate_all_features>` returns an
  >   iterator of the features of a dataset.

- It's possible to create an Interaction feature by combining two categorical features together using
  {meth}`Project.create_interaction_feature<datarobot.models.Project.create_interaction_feature>`.
  Operation result represented by {class}`models.InteractionFeature.<datarobot.models.InteractionFeature>`.
  Specific information about an interaction feature may be retrieved by its name using
  {meth}`models.InteractionFeature.get<datarobot.models.InteractionFeature.get>`

- Added the {class}`DatasetFeaturelist<datarobot.DatasetFeaturelist>` class to support featurelists
  on datasets in the AI Catalog. DatasetFeaturelists can be updated or deleted. Two new methods were
  also added to {class}`Dataset<datarobot.models.Dataset>` to interact with DatasetFeaturelists. These are
  {meth}`Dataset.get_featurelists<datarobot.models.Dataset.get_featurelists>` and
  {meth}`Dataset.create_featurelist<datarobot.models.Dataset.create_featurelist>` which list existing
  featurelists and create new featurelists on a dataset, respectively.

- Added `model_splits` to {class}`DatetimePartitioningSpecification<datarobot.DatetimePartitioningSpecification>` and
  to {class}`DatetimePartitioning<datarobot.DatetimePartitioning>`. This will allow users to control the
  jobs per model used when building models. A higher number of `model_splits`  will result in less downsampling,
  allowing the use of more post-processed data.

- Added support for :ref:`unsupervised projects<unsupervised_anomaly>`.

- Added support for external test set. Please see :ref:`testset documentation<external_testset>`

- A new workflow is available for assessing models on external test sets in time series unsupervised projects.
  More information can be found in the :ref:`documentation<unsupervised_external_dataset>`.

  - {meth}`Project.upload_dataset<datarobot.models.Project.upload_dataset>` and
    {meth}`Model.request_predictions<datarobot.models.Model.request_predictions>` now accept
    `actual_value_column` - name of the actual value column, can be passed only with date range.

  - {class}`PredictionDataset<datarobot.models.PredictionDataset>` objects now contain the following
    new fields:

    - `actual_value_column`: Actual value column which was selected for this dataset.
    - `detected_actual_value_column`: A list of detected actual value column info.

  - New warning is added to `data_quality_warnings` of {class}`datarobot.models.PredictionDataset`: `single_class_actual_value_column`.

  - Scores and insights on external test sets can be retrieved using
    {class}`ExternalScores<datarobot.ExternalScores>`, {class}`ExternalLiftChart<datarobot.ExternalLiftChart>`, {class}`ExternalRocCurve<datarobot.ExternalRocCurve>`.

- Users can create payoff matrices for generating profit curves for binary classification projects
  using {meth}`PayoffMatrix.create <datarobot.models.PayoffMatrix.create>`.

- Deployment Improvements:

  - {class}`datarobot.models.deployment.TargetDrift` can be used to retrieve target drift information.
  - {class}`datarobot.models.deployment.FeatureDrift` can be used to retrieve feature drift information.
  - {meth}`Deployment.submit_actuals<datarobot.models.Deployment.submit_actuals>` will submit actuals in batches if the total number of actuals exceeds the limit of one single request.
  - `Deployment.create_from_custom_model_image` can be used to create a deployment from a custom model image.
  - Deployments now support predictions data collection that enables prediction requests and results to be saved in Predictions Data Storage. See
    {meth}`Deployment.get_predictions_data_collection_settings<datarobot.models.Deployment.get_predictions_data_collection_settings>`
    and {meth}`Deployment.update_predictions_data_collection_settings<datarobot.models.Deployment.update_predictions_data_collection_settings>` for usage.

- New arguments `send_notification` and `include_feature_discovery_entities` are added to {meth}`Project.share<datarobot.models.Project.share>`.

- Now it is possible to specify the number of training rows to use in feature impact computation on supported project
  types (that is everything except unsupervised, multi-class, time-series). This does not affect SHAP based feature
  impact. Extended methods:

  > - {meth}`Model.request_feature_impact <datarobot.models.Model.request_feature_impact>`
  > - {meth}`Model.get_or_request_feature_impact <datarobot.models.Model.get_or_request_feature_impact>`

- A new class {class}`FeatureImpactJob <datarobot.models.FeatureImpactJob>` is added to retrieve Feature Impact
  records with metadata. The regular {class}`Job <datarobot.models.Job>` still works as before.

- Added support for custom models. Please see :ref:`custom model documentation<custom_models>`.
  Classes added:

  > - {class}`datarobot.ExecutionEnvironment` and {class}`datarobot.ExecutionEnvironmentVersion` to create and manage
  >   custom model executions environments
  > - {class}`datarobot.CustomInferenceModel` and {class}`datarobot.CustomModelVersion`
  >   to create and manage custom inference models
  > - {class}`datarobot.CustomModelTest` to perform testing of custom models

- Batch Prediction jobs now support forecast and historical Time Series predictions using the new
  argument `timeseries_settings` for {meth}`BatchPredictionJob.score <datarobot.models.BatchPredictionJob.score>`.

- Batch Prediction jobs now support scoring to Azure and Google Cloud Storage with methods
  {meth}`BatchPredictionJob.score_azure <datarobot.models.BatchPredictionJob.score_azure>` and
  {meth}`BatchPredictionJob.score_gcp <datarobot.models.BatchPredictionJob.score_gcp>`.

- Now it's possible to create Relationships Configurations to introduce secondary datasets to projects. A configuration specifies additional datasets to be included to a project and how these datasets are related to each other, and the primary dataset. When a relationships configuration is specified for a project, Feature Discovery will create features automatically from these datasets.
  : - {meth}`RelationshipsConfiguration.create <datarobot.models.RelationshipsConfiguration.create>` creates a new relationships configuration between datasets
    - {meth}`RelationshipsConfiguration.retrieve <datarobot.models.RelationshipsConfiguration.get>` retrieve the requested relationships configuration
    - {meth}`RelationshipsConfiguration.replace <datarobot.models.RelationshipsConfiguration.replace>` replace the relationships configuration details with new one
    - {meth}`RelationshipsConfiguration.delete <datarobot.models.RelationshipsConfiguration.delete>` delete the relationships configuration

### Enhancements

- Made creating projects from a dataset easier through the new
  {meth}`Dataset.create_project<datarobot.models.Dataset.create_project>`.

- These methods now provide additional metadata fields in Feature Impact results if called with
  `with_metadata=True`. Fields added: `rowCount`, `shapBased`, `ranRedundancyDetection`,
  `count`.

  > - {meth}`Model.get_feature_impact <datarobot.models.Model.get_feature_impact>`
  > - {meth}`Model.request_feature_impact <datarobot.models.Model.request_feature_impact>`
  > - {meth}`Model.get_or_request_feature_impact <datarobot.models.Model.get_or_request_feature_impact>`

- Secondary dataset configuration retrieve and deletion is easier now though new
  {meth}`SecondaryDatasetConfigurations.delete<datarobot.models.SecondaryDatasetConfigurations>` soft deletes a Secondary dataset configuration.
  {meth}`SecondaryDatasetConfigurations.get<datarobot.models.SecondaryDatasetConfigurations>` retrieve a Secondary dataset configuration.

- Retrieve relationships configuration which is applied on the given feature discovery project using
  {meth}`Project.get_relationships_configuration<datarobot.models.Project.get_relationships_configuration>`.

### Bugfixes

- An issue with input validation of the Batch Prediction module
- parent_model_id was not visible for all frozen models
- Batch Prediction jobs that used other output types than `local_file` failed when using `.wait_for_completion()`
- A race condition in the Batch Prediction file scoring logic

### API changes

- Three new fields were added to the {class}`Dataset<datarobot.models.Dataset>` object. This reflects the
  updated fields in the public API routes at `api/v2/datasets/`. The added fields are:

  > - processing_state: Current ingestion process state of the dataset
  > - row_count: The number of rows in the dataset.
  > - size: The size of the dataset as a CSV in bytes.

### Deprecation summary

- `datarobot.enums.VARIABLE_TYPE_TRANSFORM.CATEGORICAL` for is deprecated for the following and will be removed in  v2.22.
  : - meth:`Project.batch_features_type_transform`
    - meth:`Project.create_type_transform_feature`

## 2.20.0

### New features

- There is a new {class}`Dataset<datarobot.models.Dataset>` object that implements some of the
  public API routes at `api/v2/datasets/`. This also adds two new feature classes and a details
  class.

  > - {class}`DatasetFeature<datarobot.models.DatasetFeature>`
  > - {class}`DatasetFeatureHistogram<datarobot.models.DatasetFeatureHistogram>`
  > - {class}`DatasetDetails<datarobot.DatasetDetails>`

  Functionality:

  > - Create a Dataset by uploading from a file, URL or in-memory datasource.
  >
  >   > - {meth}`Dataset.create_from_file<datarobot.models.Dataset.create_from_file>`
  >   > - {meth}`Dataset.create_from_in_memory_data<datarobot.models.Dataset.create_from_in_memory_data>`
  >   > - {meth}`Dataset.create_from_url<datarobot.models.Dataset.create_from_url>`
  >
  > - Get Datasets or elements of Dataset with:
  >
  >   > - {meth}`Dataset.list<datarobot.models.Dataset.list>` lists available Datasets
  >   > - {meth}`Dataset.get<datarobot.models.Dataset.get>` gets a specified Dataset
  >   > - {meth}`Dataset.update<datarobot.models.Dataset.get>` updates the Dataset with the latest server information.
  >   > - {meth}`Dataset.get_details<datarobot.models.Dataset.get_details>` gets the DatasetDetails of the Dataset.
  >   > - {meth}`Dataset.get_all_features<datarobot.models.Dataset.get_all_features>` gets a list of the Dataset's Features.
  >   > - {meth}`Dataset.get_file<datarobot.models.Dataset.get_file>` downloads the Dataset as a csv file.
  >   > - {meth}`Dataset.get_projects<datarobot.models.Dataset.get_projects>` gets a list of Projects that use the Dataset.
  >
  > - Modify, delete or un-delete a Dataset:
  >
  >   > - {meth}`Dataset.modify<datarobot.models.Dataset.modify>` Changes the name and categories of the Dataset
  >   > - {meth}`Dataset.delete<datarobot.models.Dataset.delete>` soft deletes a Dataset.
  >   > - {meth}`Dataset.un_delete<datarobot.models.Dataset.un_delete>` un-deletes the Dataset. You cannot retrieve the
  >   >   IDs of deleted Datasets, so if you want to un-delete a Dataset, you need to store its ID before deletion.
  >
  > - You can also create a Project using a `Dataset` with:
  >
  >   > - {meth}`Project.create_from_dataset<datarobot.models.Project.create_from_dataset>`

- It is possible to create an alternative configuration for the secondary dataset which can be used during the prediction

  > - {meth}`SecondaryDatasetConfigurations.create <datarobot.models.SecondaryDatasetConfigurations.create>` allow to create secondary dataset configuration

- You can now filter the deployments returned by the {meth}`Deployment.list <datarobot.models.Deployment.list>` command. You can do this by passing an instance of the {class}`~datarobot.models.deployment.DeploymentListFilters` class to the `filters` keyword argument. The currently supported filters are:

  > - `role`
  > - `service_health`
  > - `model_health`
  > - `accuracy_health`
  > - `execution_environment_type`
  > - `materiality`

- A new workflow is available for making predictions in time series projects. To that end,
  {class}`PredictionDataset<datarobot.models.PredictionDataset>` objects now contain the following
  new fields:

  > - `forecast_point_range`: The start and end date of the range of dates available for use as the forecast point,
  >   detected based on the uploaded prediction dataset
  > - `data_start_date`: A datestring representing the minimum primary date of the prediction dataset
  > - `data_end_date`: A datestring representing the maximum primary date of the prediction dataset
  > - `max_forecast_date`: A datestring representing the maximum forecast date of this prediction dataset

  Additionally, users no longer need to specify a `forecast_point` or `predictions_start_date` and
  `predictions_end_date` when uploading datasets for predictions in time series projects. More information can be
  found in the :ref:`time series predictions<new_pred_ux>` documentation.

- Per-class lift chart data is now available for multiclass models using
  {meth}`Model.get_multiclass_lift_chart <datarobot.models.Model.get_multiclass_lift_chart>`.

- Unsupervised projects can now be created using the {meth}`Project.start <datarobot.models.Project.start>`
  and {meth}`Project.set_target <datarobot.models.Project.set_target>` methods by providing `unsupervised_mode=True`,
  provided that the user has access to unsupervised machine learning functionality. Contact support for more information.

- A new boolean attribute `unsupervised_mode` was added to {py:class}`datarobot.DatetimePartitioningSpecification <datarobot.DatetimePartitioningSpecification>`.
  When it is set to True, datetime partitioning for unsupervised time series projects will be constructed for
  nowcasting: `forecast_window_start=forecast_window_end=0`.

- Users can now configure the start and end of the training partition as well as the end of the validation partition for
  backtests in a datetime-partitioned project. More information and example usage can be found in the
  :ref:`backtesting documentation <backtest_configuration>`.

### Enhancements

- Updated the user agent header to show which python version.
- {meth}`Model.get_frozen_child_models <datarobot.models.Model.get_frozen_child_models>` can be used to retrieve models that are frozen from a given model
- Added `datarobot.enums.TS_BLENDER_METHOD` to make it clearer which blender methods are allowed for use in time
  series projects.

### Bugfixes

- An issue where uploaded CSV's would loose quotes during serialization causing issues when columns containing line terminators where loaded in a dataframe, has been fixed
- {meth}`Project.get_association_featurelists <datarobot.models.Project.get_association_featurelists>` is now using the correct endpoint name, but the old one will continue to work
- Python API {class}`PredictionServer<datarobot.PredictionServer>` supports now on-premise format of API response.

## 2.19.0

### New features

- Projects can be cloned using {meth}`Project.clone_project <datarobot.models.Project.clone_project>`

- Calendars used in time series projects now support having series-specific events, for instance if a holiday only affects some stores. This can be controlled by using new argument of the {meth}`CalendarFile.create <datarobot.CalendarFile.create>` method.
  If multiseries id columns are not provided, calendar is considered to be single series and all events are applied to all series.

- We have expanded prediction intervals availability to the following use-cases:

  > - Time series model deployments now support prediction intervals. See
  >   {meth}`Deployment.get_prediction_intervals_settings<datarobot.models.Deployment.get_prediction_intervals_settings>`
  >   and {meth}`Deployment.update_prediction_intervals_settings<datarobot.models.Deployment.update_prediction_intervals_settings>` for usage.
  > - Prediction intervals are now supported for model exports for time series. To that end, a new optional parameter
  >   `prediction_intervals_size` has been added to `Model.request_transferable_export <datarobot.models.Model.request_transferable_export>`.

  More details on prediction intervals can be found in the :ref:`prediction intervals documentation <prediction_intervals>`.

- Allowed pairwise interaction groups can now be specified in {py:class}`AdvancedOptions <datarobot.helpers.AdvancedOptions>`.
  They will be used in GAM models during training.

- New deployments features:

  > - Update the label and description of a deployment using {meth}`Deployment.update<datarobot.models.Deployment.update>`.
  > - :ref:`Association ID setting<deployment_association_id>` can be retrieved and updated.
  > - Regression deployments now support :ref:`prediction warnings<deployment_prediction_warning>`.

- For multiclass models now it's possible to get feature impact for each individual target class using
  {meth}`Model.get_multiclass_feature_impact <datarobot.models.Model.get_multiclass_feature_impact>`

- Added support for new :ref:`Batch Prediction API <batch_predictions>`.

- It is now possible to create and retrieve basic, oauth and s3 credentials with
  {py:class}`Credential <datarobot.models.Credential>`.

- It's now possible to get feature association statuses for featurelists using
  {meth}`Project.get_association_featurelists <datarobot.models.Project.get_association_featurelists>`

- You can also pass a specific featurelist_id into
  {meth}`Project.get_associations <datarobot.models.Project.get_associations>`

### Enhancements

- Added documentation to {meth}`Project.get_metrics <datarobot.models.Project.get_metrics>` to detail the new `ascending` field that
  indicates how a metric should be sorted.

- Retraining of a model is processed asynchronously and returns a  `ModelJob` immediately.

- Blender models can be retrained on a different set of data or a different feature list.

- Word cloud ngrams now has `variable` field representing the source of the ngram.

- Method {meth}`WordCloud.ngrams_per_class <datarobot.models.word_cloud.WordCloud.ngrams_per_class>` can be used to
  split ngrams for better usability in multiclass projects.

- Method {meth}`Project.set_target <datarobot.models.Project.set_target>` support new optional parameters `featureEngineeringGraphs` and `credentials`.

- Method {py:meth}`Project.upload_dataset <datarobot.models.Project.upload_dataset>` and {py:meth}`Project.upload_dataset_from_data_source <datarobot.models.Project.upload_dataset_from_data_source>` support new optional parameter `credentials`.

- Series accuracy retrieval methods ({meth}`DatetimeModel.get_series_accuracy_as_dataframe <datarobot.models.DatetimeModel.get_series_accuracy_as_dataframe>`
  and {meth}`DatetimeModel.download_series_accuracy_as_csv <datarobot.models.DatetimeModel.download_series_accuracy_as_csv>`)
  for multiseries time series projects now support additional parameters for specifying what data to retrieve, including:

  > - `metric`: Which metric to retrieve scores for
  > - `multiseries_value`: Only returns series with a matching multiseries ID
  > - `order_by`: An attribute by which to sort the results

### Bugfixes

- An issue when using {meth}`Feature.get <datarobot.models.Feature.get>` and {meth}`ModelingFeature.get <datarobot.models.ModelingFeature.get>` to retrieve summarized categorical feature has been fixed.

### API changes

- The datarobot package is now no longer a
  [namespace package](https://packaging.python.org/guides/packaging-namespace-packages/).
- `datarobot.enums.BLENDER_METHOD.FORECAST_DISTANCE` is removed (deprecated in 2.18.0).

### Documentation changes

- Updated :ref:`Residuals charts <residuals_chart>` documentation to reflect that the data rows include row numbers from the source dataset for projects
  created in DataRobot 5.3 and newer.

## 2.18.0

### New features

- :ref:`Residuals charts <residuals_chart>` can now be retrieved for non-time-aware regression models.
- :ref:`Deployment monitoring <deployment_monitoring>` can now be used to retrieve service stats, service health, accuracy info, permissions, and feature lists for deployments.
- :ref:`Time series <time_series>` projects now support the Average by Forecast Distance blender, configured with more than one Forecast Distance. The blender blends the selected models, selecting the best three models based on the backtesting score for each Forecast Distance and averaging their predictions. The new blender method `FORECAST_DISTANCE_AVG` has been added to `datarobot.enums.BLENDER_METHOD`.
- {py:meth}`Deployment.submit_actuals <datarobot.models.Deployment.submit_actuals>` can now be used to submit data about actual results from a deployed model, which can be used to calculate accuracy metrics.

### Enhancements

- Monotonic constraints are now supported for OTV projects. To that end, the parameters `monotonic_increasing_featurelist_id` and `monotonic_decreasing_featurelist_id` can be specified in calls to {meth}`Model.train_datetime <datarobot.models.Model.train_datetime>` or {meth}`Project.train_datetime <datarobot.models.Project.train_datetime>`.
- When {py:meth}`retrieving information about features <datarobot.models.Feature.get>`, information about summarized categorical variables is now available in a new `keySummary`.
- For {py:class}`Word Clouds <datarobot.models.word_cloud.WordCloud>` in multiclass projects, values of the target class for corresponding word or ngram can now be passed using the new `class` parameter.
- Listing deployments using {py:meth}`Deployment.list <datarobot.models.Deployment.list>` now support sorting and searching the results using the new `order_by` and `search` parameters.
- You can now get the model associated with a model job by getting the `model` variable on the {py:class}`model job object <datarobot.models.ModelJob>`.
- The {class}`Blueprint <datarobot.models.Blueprint>` class can now retrieve the `recommended_featurelist_id`, which indicates which feature list is recommended for this blueprint. If the field is not present, then there is no recommended feature list for this blueprint.
- The {class}`Model <datarobot.models.Model>` class now can be used to retrieve the `model_number`.
- The method {py:meth}`Model.get_supported_capabilities <datarobot.models.Model.get_supported_capabilities>` now has an extra field `supportsCodeGeneration` to explain whether the model supports code generation.
- Calls to {py:meth}`Project.start <datarobot.models.Project.start>` and {py:meth}`Project.upload_dataset <datarobot.models.Project.upload_dataset>` now support uploading data via S3 URI and `pathlib.Path` objects.
- Errors upon connecting to DataRobot are now clearer when an incorrect API Token is used.
- The datarobot package is now a [namespace package](https://packaging.python.org/guides/packaging-namespace-packages/).

### Deprecation summary

- `datarobot.enums.BLENDER_METHOD.FORECAST_DISTANCE` is deprecated and will be removed in 2.19. Use `FORECAST_DISTANCE_ENET` instead.

### Documentation changes

- Various typo and wording issues have been addressed.
- A new notebook showing regression-specific features is now been added to the examples_index.
- Documentation for :ref:`Access lists <sharing>` has been added.

## 2.17.0

### New features

- :ref:`Deployments <deployments_overview>` can now be managed via the API by using the new {py:class}`Deployment <datarobot.models.Deployment>` class.
- Users can now list available prediction servers using {meth}`PredictionServer.list <datarobot.PredictionServer.list>`.
- When {class}`specifying datetime partitioning <datarobot.DatetimePartitioningSpecification>` settings , :ref:`time series <time_series>` projects can now mark individual features as excluded from feature derivation using the
  {py:class}`FeatureSettings.do_not_derive <datarobot.FeatureSettings>` attribute. Any features not specified will be assigned according to the {py:class}`DatetimePartitioningSpecification.default_to_do_not_derive <datarobot.DatetimePartitioning>` value.
- Users can now submit multiple feature type transformations in a single batch request using {py:meth}`Project.batch_features_type_transform <datarobot.models.Project.batch_features_type_transform>`.
- :ref:`Advanced Tuning <advanced_tuning>` for non-Eureqa models (beta feature) is now enabled by default for all users.
  As of v2.17, all models are now supported other than blenders, open source, prime, scaleout, baseline and user-created.
- Information on feature clustering and the association strength between pairs of numeric or categorical features is now available.
  {py:meth}`Project.get_associations <datarobot.models.Project.get_associations>` can be used to retrieve pairwise feature association statistics and
  {py:meth}`Project.get_association_matrix_details <datarobot.models.Project.get_association_matrix_details>` can be used to get a sample of the actual values used to measure association strength.

### Enhancements

- `number_of_do_not_derive_features` has been added to the {py:class}`datarobot.DatetimePartitioning <datarobot.DatetimePartitioning>` class to specify the number of features that are marked as excluded from derivation.
- Users with PyYAML>=5.1 will no longer receive a warning when using the `datarobot` package
- It is now possible to use files with unicode names for creating projects and prediction jobs.
- Users can now embed DataRobot-generated content in a {class}`ComplianceDocTemplate <datarobot.models.compliance_doc_template.ComplianceDocTemplate>` using keyword tags. :ref:`See here <automated_documentation_overview>` for more details.
- The field `calendar_name` has been added to {py:class}`datarobot.DatetimePartitioning <datarobot.DatetimePartitioning>` to display the name of the calendar used for a project.
- :ref:`Prediction intervals <prediction_intervals>` are now supported for start-end retrained models in a time series project.
- Previously, all backtests had to be run before :ref:`prediction intervals <prediction_intervals>` for a time series project could be requested with predictions.
  Now, backtests will be computed automatically if needed when prediction intervals are requested.

### Bugfixes

- An issue affecting time series project creation for irregularly spaced dates has been fixed.
- {class}`ComplianceDocTemplate <datarobot.models.compliance_doc_template.ComplianceDocTemplate>` now supports empty text blocks in user sections.
- An issue when using {meth}`Predictions.get <datarobot.models.Predictions.get>` to retrieve predictions metadata has been fixed.

### Documentation changes

- An overview on working with class `ComplianceDocumentation` and {class}`ComplianceDocTemplate <datarobot.models.compliance_doc_template.ComplianceDocTemplate>` has been created. :ref:`See here <automated_documentation_overview>` for more details.

## 2.16.0

### New features

- Three new methods for Series Accuracy have been added to the {class}`DatetimeModel <datarobot.models.DatetimeModel>` class.

  > - Start a request to calculate Series Accuracy with
  >   {meth}`DatetimeModel.compute_series_accuracy <datarobot.models.DatetimeModel.compute_series_accuracy>`
  > - Once computed, Series Accuracy can be retrieved as a pandas.DataFrame using
  >   {meth}`DatetimeModel.get_series_accuracy_as_dataframe <datarobot.models.DatetimeModel.get_series_accuracy_as_dataframe>`
  > - Or saved as a CSV using
  >   {meth}`DatetimeModel.download_series_accuracy_as_csv <datarobot.models.DatetimeModel.download_series_accuracy_as_csv>`

- Users can now access :ref:`prediction intervals <prediction_intervals>` data for each prediction with a {class}`DatetimeModel <datarobot.models.DatetimeModel>`.
  For each model, prediction intervals estimate the range of values DataRobot expects actual values of the target to fall within.
  They are similar to a confidence interval of a prediction, but are based on the residual errors measured during the
  backtesting for the selected model.

### Enhancements

- Information on the effective feature derivation window is now available for :ref:`time series projects <time_series>` to specify the full span of historical data
  required at prediction time. It may be longer than the feature derivation window of the project depending on the differencing settings used.

  Additionally, more of the project partitioning settings are also available on the
  {class}`DatetimeModel <datarobot.models.DatetimeModel>` class.  The new attributes are:

  > - `effective_feature_derivation_window_start`
  > - `effective_feature_derivation_window_end`
  > - `forecast_window_start`
  > - `forecast_window_end`
  > - `windows_basis_unit`

- Prediction metadata is now included in the return of {meth}`Predictions.get <datarobot.models.Predictions.get>`

### Documentation changes

- Various typo and wording issues have been addressed.
- The example data that was meant to accompany the Time Series examples has been added to the
  zip file of the download in the examples_index.

## 2.15.1

### Enhancements

- {meth}`CalendarFile.get_access_list <datarobot.CalendarFile.get_access_list>` has been added to the {class}`CalendarFile <datarobot.CalendarFile>` class to return a list of users with access to a calendar file.
- A `role` attribute has been added to the {class}`CalendarFile <datarobot.CalendarFile>` class to indicate the access level a current user has to a calendar file. For more information on the specific access levels, see the :ref:`sharing <sharing>` documentation.

### Bugfixes

- Previously, attempting to retrieve the `calendar_id` of a project without a set target would result in an error.
  This has been fixed to return `None` instead.

## 2.15.0

### New features

- Previously available for only Eureqa models, Advanced Tuning methods and objects, including
  {meth}`Model.start_advanced_tuning_session <datarobot.models.Model.start_advanced_tuning_session>`,
  {meth}`Model.get_advanced_tuning_parameters <datarobot.models.Model.get_advanced_tuning_parameters>`,
  {meth}`Model.advanced_tune <datarobot.models.Model.advanced_tune>`, and
  {class}`AdvancedTuningSession <datarobot.models.advanced_tuning.AdvancedTuningSession>`,
  now support all models other than blender, open source, and user-created models.  Use of
  Advanced Tuning via API for non-Eureqa models is in beta and not available by default, but can be
  enabled.
- Calendar Files for time series projects can now be created and managed through the {class}`CalendarFile <datarobot.CalendarFile>` class.

### Enhancements

- The dataframe returned from
  {py:meth}`datarobot.PredictionExplanations.get_all_as_dataframe` will now have
  each class label `class_X` be the same from row to row.
- The client is now more robust to networking issues by default. It will retry on more errors and respects `Retry-After` headers in HTTP 413, 429, and 503 responses.
- Added Forecast Distance blender for Time-Series projects configured with more than one Forecast
  Distance. It blends the selected models creating separate linear models for each Forecast Distance.
- {py:class}`Project <datarobot.models.Project>` can now be :ref:`shared <sharing>` with other users.
- {py:meth}`Project.upload_dataset <datarobot.models.Project.upload_dataset>` and {py:meth}`Project.upload_dataset_from_data_source <datarobot.models.Project.upload_dataset_from_data_source>` will return a {py:class}`PredictionDataset <datarobot.models.PredictionDataset>` with `data_quality_warnings` if potential problems exist around the uploaded dataset.
- `relax_known_in_advance_features_check` has been added to {py:meth}`Project.upload_dataset <datarobot.models.Project.upload_dataset>` and {py:meth}`Project.upload_dataset_from_data_source <datarobot.models.Project.upload_dataset_from_data_source>` to allow missing values from the known in advance features in the forecast window at prediction time.
- `cross_series_group_by_columns` has been added to {py:class}`datarobot.DatetimePartitioning <datarobot.DatetimePartitioning>` to allow users the ability to indicate how to further split series into related groups.
- Information retrieval for {py:class}`ROC Curve <datarobot.models.roc_curve.RocCurve>` has been extended to include `fraction_predicted_as_positive`, `fraction_predicted_as_negative`, `lift_positive` and `lift_negative`

### Bugfixes

- Fixes an issue where the client would not be usable if it could not be sure it was compatible with the configured
  server

### API changes

- Methods for creating {py:class}`datarobot.models.Project`: `create_from_mysql`, `create_from_oracle`, and `create_from_postgresql`, deprecated in 2.11, have now been removed.
  Use {py:meth}`datarobot.models.Project.create_from_data_source` instead.
- {py:class}`datarobot.FeatureSettings <datarobot.FeatureSettings>` attribute `apriori`, deprecated in 2.11, has been removed.
  Use {py:class}`datarobot.FeatureSettings.known_in_advance <datarobot.FeatureSettings>` instead.
- {py:class}`datarobot.DatetimePartitioning <datarobot.DatetimePartitioning>` attribute `default_to_a_priori`, deprecated in 2.11, has been removed. Use
  {py:class}`datarobot.DatetimePartitioning.known_in_advance <datarobot.DatetimePartitioning>` instead.
- {py:class}`datarobot.DatetimePartitioningSpecification <datarobot.DatetimePartitioning>` attribute `default_to_a_priori`, deprecated in 2.11, has been removed.
  Use {py:class}`datarobot.DatetimePartitioningSpecification.known_in_advance <datarobot.DatetimePartitioning>`
  instead.

### Configuration changes

- Now requires dependency on package [requests](https://pypi.org/project/requests/)  to be at least version 2.21.
- Now requires dependency on package [urllib3](https://pypi.org/project/urllib3/)  to be at least version 1.24.

### Documentation changes

- Advanced model insights notebook extended to contain information on visualization of cumulative gains and lift charts.

## 2.14.2

### Bugfixes

- Fixed an issue where searches of the HTML documentation would sometimes hang indefinitely

### Documentation changes

- Python3 is now the primary interpreter used to build the docs (this does not affect the ability to use the
  package with Python2)

## 2.14.1

### Documentation changes

> - Documentation for the Model Deployment interface has been removed after the corresponding interface was removed in 2.13.0.

## 2.14.0

### New features

- The new method {meth}`Model.get_supported_capabilities <datarobot.models.Model.get_supported_capabilities>`
  retrieves a summary of the capabilities supported by a particular model,
  such as whether it is eligible for Prime and whether it has word cloud data available.
- New class for working with model compliance documentation feature of DataRobot:
  class `ComplianceDocumentation`
- New class for working with compliance documentation templates:
  {class}`ComplianceDocTemplate <datarobot.models.compliance_doc_template.ComplianceDocTemplate>`
- New class {py:class}`FeatureHistogram <datarobot.models.FeatureHistogram>` has been added to
  retrieve feature histograms for a requested maximum bin count
- Time series projects now support binary classification targets.
- Cross series features can now be created within time series multiseries projects using the
  `use_cross_series_features` and `aggregation_type` attributes of the
  {py:class}`datarobot.DatetimePartitioningSpecification
  <datarobot.DatetimePartitioningSpecification>`.
  See the :ref:`Time Series <time_series>` documentation for more info.

### Enhancements

- Client instantiation now checks the endpoint configuration and provides more informative error messages.
  It also automatically corrects HTTP to HTTPS if the server responds with a redirect to HTTPS.
- {meth}`Project.upload_dataset <datarobot.models.Project.upload_dataset>` and {meth}`Project.create <datarobot.models.Project.create>`
  now accept an optional parameter of `dataset_filename` to specify a file name for the dataset.
  This is ignored for url and file path sources.
- New optional parameter `fallback_to_parent_insights` has been added to {meth}`Model.get_lift_chart <datarobot.models.Model.get_lift_chart>`,
  {meth}`Model.get_all_lift_charts <datarobot.models.Model.get_all_lift_charts>`, {meth}`Model.get_confusion_chart <datarobot.models.Model.get_confusion_chart>`,
  {meth}`Model.get_all_confusion_charts <datarobot.models.Model.get_all_confusion_charts>`, {meth}`Model.get_roc_curve <datarobot.models.Model.get_roc_curve>`,
  and {meth}`Model.get_all_roc_curves <datarobot.models.Model.get_all_roc_curves>`.  When `True`, a frozen model with
  missing insights will attempt to retrieve the missing insight data from its parent model.
- New `number_of_known_in_advance_features` attribute has been added to the
  {py:class}`datarobot.DatetimePartitioning <datarobot.DatetimePartitioning>` class.
  The attribute specifies number of features that are marked as known in advance.
- {meth}`Project.set_worker_count <datarobot.models.Project.set_worker_count>` can now update the worker count on
  a project to the maximum number available to the user.
- :ref:`Recommended Models API <recommended_models>` can now be used to retrieve
  model recommendations for datetime partitioned projects
- Timeseries projects can now accept feature derivation and forecast windows intervals in terms of
  number of the rows rather than a fixed time unit. {class}`DatetimePartitioningSpecification <datarobot.DatetimePartitioningSpecification>`
  and {meth}`Project.set_target <datarobot.models.Project.set_target>` support new optional parameter `windowsBasisUnit`, either 'ROW' or detected time unit.
- Timeseries projects can now accept feature derivation intervals, forecast windows, forecast points and prediction start/end dates in milliseconds.
- {class}`DataSources <datarobot.DataSource>` and {class}`DataStores <datarobot.DataStore>` can now
  be :ref:`shared <sharing>` with other users.
- Training predictions for datetime partitioned projects now support the new data subset
  `dr.enums.DATA_SUBSET.ALL_BACKTESTS` for requesting the predictions for all backtest validation
  folds.

### API changes

- The model recommendation type "Recommended" (deprecated in version 2.13.0) has been removed.

### Documentation changes

- Example notebooks have been updated:
  : - Notebooks now work in Python 2 and Python 3
    - A notebook illustrating time series capability has been added
    - The financial data example has been replaced with an updated introductory example.
- To supplement the embedded Python notebooks in both the PDF and HTML docs bundles, the notebook files and supporting data can now be downloaded from the HTML docs bundle.
- Fixed a minor typo in the code sample for `get_or_request_feature_impact`

## 2.13.0

### New features

- The new method {meth}`Model.get_or_request_feature_impact <datarobot.models.Model.get_or_request_feature_impact>` functionality will attempt to request feature impact
  and return the newly created feature impact object or the existing object so two calls are no longer required.
- New methods and objects, including
  {meth}`Model.start_advanced_tuning_session <datarobot.models.Model.start_advanced_tuning_session>`,
  {meth}`Model.get_advanced_tuning_parameters <datarobot.models.Model.get_advanced_tuning_parameters>`,
  {meth}`Model.advanced_tune <datarobot.models.Model.advanced_tune>`, and
  {class}`AdvancedTuningSession <datarobot.models.advanced_tuning.AdvancedTuningSession>`,
  were added to support the setting of Advanced Tuning parameters. This is currently supported for
  Eureqa models only.
- New `is_starred` attribute has been added to the {py:class}`Model <datarobot.models.Model>` class. The attribute
  specifies whether a model has been marked as starred by user or not.
- Model can be marked as starred or being unstarred with {meth}`Model.star_model <datarobot.models.Model.star_model>` and {meth}`Model.unstar_model <datarobot.models.Model.unstar_model>`.
- When listing models with {meth}`Project.get_models <datarobot.models.Project.get_models>`, the model list can now be filtered by the `is_starred` value.
- A custom prediction threshold may now be configured for each model via {meth}`Model.set_prediction_threshold <datarobot.models.Model.set_prediction_threshold>`.  When making
  predictions in binary classification projects, this value will be used when deciding between the positive and negative classes.
- {meth}`Project.check_blendable <datarobot.models.Project.check_blendable>` can be used to confirm if a particular group of models are eligible for blending as
  some are not, e.g. scaleout models and datetime models with different training lengths.
- Individual cross validation scores can be retrieved for new models using {meth}`Model.get_cross_validation_scores <datarobot.models.Model.get_cross_validation_scores>`.

### Enhancements

- Python 3.7 is now supported.
- Feature impact now returns not only the impact score for the features but also whether they were
  detected to be redundant with other high-impact features.
- A new `is_blocked` attribute has been added to the {py:class}`Job <datarobot.models.Job>`
  class, specifying whether a job is blocked from execution because one or more dependencies are not
  yet met.
- The {py:class}`Featurelist <datarobot.models.Featurelist>` object now has new attributes reporting
  its creation time, whether it was created by a user or by DataRobot, and the number of models
  using the featurelist, as well as a new description field.
- Featurelists can now be renamed and have their descriptions updated with
  {py:meth}`Featurelist.update <datarobot.models.Featurelist.update>` and
  {py:meth}`ModelingFeaturelist.update <datarobot.models.ModelingFeaturelist.update>`.
- Featurelists can now be deleted with
  {py:meth}`Featurelist.delete <datarobot.models.Featurelist.delete>`
  and {py:meth}`ModelingFeaturelist.delete <datarobot.models.ModelingFeaturelist.delete>`.
- {meth}`ModelRecommendation.get <datarobot.models.ModelRecommendation.get>` now accepts an optional
  parameter of type `datarobot.enums.RECOMMENDED_MODEL_TYPE` which can be used to get a specific
  kind of recommendation.
- Previously computed predictions can now be listed and retrieved with the
  {class}`Predictions <datarobot.models.Predictions>` class, without requiring a
  reference to the original {py:class}`PredictJob <datarobot.models.PredictJob>`.

### Bugfixes

- The Model Deployment interface which was previously visible in the client has been removed to
  allow the interface to mature, although the raw API is available as a "beta" API without full
  backwards compatibility support.

### API changes

- Added support for retrieving the Pareto Front of a Eureqa model. See
  {py:class}`ParetoFront <datarobot.models.pareto_front.ParetoFront>`.
- A new recommendation type "Recommended for Deployment" has been added to
  {py:class}`ModelRecommendation <datarobot.models.ModelRecommendation>` which is now returns as the
  default recommended model when available. See :ref:`model_recommendation`.

### Deprecation summary

- The feature previously referred to as "Reason Codes" has been renamed to "Prediction
  Explanations", to provide increased clarity and accessibility. The old
  ReasonCodes interface has been deprecated and replaced with
  {py:class}`PredictionExplanations <datarobot.PredictionExplanations>`.
- The recommendation type "Recommended" is deprecated and  will no longer be returned
  in v2.14 of the API.

### Documentation changes

- Added a new documentation section :ref:`model_recommendation`.
- Time series projects support multiseries as well as single series data. They are now documented in
  the :ref:`Time Series Projects <time_series>` documentation.

## 2.12.0

### New features

- Some models now have Missing Value reports allowing users with access to uncensored blueprints to
  retrieve a detailed breakdown of how numeric imputation and categorical converter tasks handled
  missing values. See the :ref:`documentation <missing_values_report>` for more information on the
  report.

## 2.11.0

### New features

- The new `ModelRecommendation` class can be used to retrieve the recommended models for a
  project.
- A new helper method cross_validate was added to class Model. This method can be used to request
  Model's Cross Validation score.
- Training a model with monotonic constraints is now supported. Training with monotonic
  constraints allows users to force models to learn monotonic relationships with respect to some features and the target. This helps users create accurate models that comply with regulations (e.g. insurance, banking). Currently, only certain blueprints (e.g. xgboost) support this feature, and it is only supported for regression and binary classification projects.
- DataRobot now supports "Database Connectivity", allowing databases to be used
  as the source of data for projects and prediction datasets. The feature works
  on top of the JDBC standard, so a variety of databases conforming to that standard are available;
  a list of databases with tested support for DataRobot is available in the user guide
  in the web application. See :ref:`Database Connectivity <database_connectivity_overview>`
  for details.
- Added a new feature to retrieve feature logs for time series projects. Check
  {py:meth}`datarobot.DatetimePartitioning.feature_log_list` and
  {py:meth}`datarobot.DatetimePartitioning.feature_log_retrieve` for details.

### API changes

- New attributes supporting monotonic constraints have been added to the
  {py:class}`AdvancedOptions <datarobot.helpers.AdvancedOptions>`,
  {py:class}`Project <datarobot.models.Project>`,
  {py:class}`Model <datarobot.models.Model>`, and {py:class}`Blueprint <datarobot.models.Blueprint>`
  classes. See :ref:`monotonic constraints<monotonic_constraints>` for more information on how to
  configure monotonic constraints.
- New parameters `predictions_start_date` and `predictions_end_date` added to
  {py:meth}`Project.upload_dataset <datarobot.models.Project.upload_dataset>` to support bulk
  predictions upload for time series projects.

### Deprecation summary

- Methods for creating {py:class}`datarobot.models.Project`: `create_from_mysql`, `create_from_oracle`, and `create_from_postgresql`, have been deprecated and will be removed in 2.14.
  Use {py:meth}`datarobot.models.Project.create_from_data_source` instead.
- {py:class}`datarobot.FeatureSettings <datarobot.FeatureSettings>` attribute `apriori`, has been deprecated and will be removed in 2.14.
  Use {py:class}`datarobot.FeatureSettings.known_in_advance <datarobot.FeatureSettings>` instead.
- {py:class}`datarobot.DatetimePartitioning <datarobot.DatetimePartitioning>` attribute `default_to_a_priori`, has been deprecated and will be removed in 2.14.
  {py:class}`datarobot.DatetimePartitioning.known_in_advance <datarobot.DatetimePartitioning>` instead.
- {py:class}`datarobot.DatetimePartitioningSpecification <datarobot.DatetimePartitioning>` attribute `default_to_a_priori`, has been deprecated and will be removed in 2.14.
  Use {py:class}`datarobot.DatetimePartitioningSpecification.known_in_advance <datarobot.DatetimePartitioning>`
  instead.

### Configuration changes

- Retry settings compatible with those offered by urllib3\'s [Retry](https://urllib3.readthedocs.io/en/latest/reference/urllib3.util.html#urllib3.util.retry.Retry)
  interface can now be configured. By default, we will now retry connection errors that prevented requests from arriving at the server.

### Documentation changes

- "Advanced Model Insights" example has been updated to properly handle bin weights when rebinning.

## 2.9.0

### New features

- New `ModelDeployment` class can be used to track status and health of models deployed for
  predictions.

### Enhancements

- DataRobot API now supports creating 3 new blender types - Random Forest, TensorFlow, LightGBM.
- Multiclass projects now support blenders creation for 3 new blender types as well as Average
  and ENET blenders.
- Models can be trained by requesting a particular row count using the new `training_row_count`
  argument with `Project.train`, `Model.train` and `Model.request_frozen_model` in non-datetime
  partitioned projects, as an alternative to the previous option of specifying a desired
  percentage of the project dataset. Specifying model size by row count is recommended when
  the float precision of `sample_pct` could be problematic, e.g. when training on a small
  percentage of the dataset or when training up to partition boundaries.
- New attributes `max_train_rows`, `scaleout_max_train_pct`, and `scaleout_max_train_rows`
  have been added to {py:class}`Project <datarobot.models.Project>`. `max_train_rows` specified the equivalent
  value to the existing `max_train_pct` as a row count. The scaleout fields can be used to see how
  far scaleout models can be trained on projects, which for projects taking advantage of scalable
  ingest may exceed the limits on the data available to non-scaleout blueprints.
- Individual features can now be marked as a priori or not a priori using the new `feature_settings`
  attribute when setting the target or specifying datetime partitioning settings on time
  series projects. Any features not specified in the `feature_settings` parameter will be
  assigned according to the `default_to_a_priori` value.
- Three new options have been made available in the
  {py:class}`datarobot.DatetimePartitioningSpecification` class to fine-tune how time-series projects
  derive modeling features. `treat_as_exponential` can control whether data is analyzed as
  an exponential trend and transformations like log-transform are applied.
  `differencing_method` can control which differencing method to use for stationary data.
  `periodicities` can be used to specify periodicities occurring within the data.
  All are optional and defaults will be chosen automatically if they are unspecified.

### API changes

- Now `training_row_count` is available on non-datetime models as well as `rowCount` based
  datetime models. It reports the number of rows used to train the model (equivalent to
  `sample_pct`).
- Features retrieved from `Feature.get` now include `target_leakage`.

## 2.8.1

### Bugfixes

- The documented default connect_timeout will now be correctly set for all configuration mechanisms,
  so that requests that fail to reach the DataRobot server in a reasonable amount of time will now
  error instead of hanging indefinitely. If you observe that you have started seeing
  `ConnectTimeout` errors, please configure your connect_timeout to a larger value.
- Version of `trafaret` library this package depends on is now pinned to `trafaret>=0.7,<1.1`
  since versions outside that range are known to be incompatible.

## 2.8.0

### New features

- The DataRobot API supports the creation, training, and predicting of multiclass classification
  projects. DataRobot, by default, handles a dataset with a numeric target column as regression.
  If your data has a numeric cardinality of fewer than 11 classes, you can override this behavior to
  instead create a multiclass classification project from the data. To do so, use the set_target
  function, setting target_type='Multiclass'. If DataRobot recognizes your data as categorical, and
  it has fewer than 11 classes, using multiclass will create a project that classifies which label
  the data belongs to.
- The DataRobot API now includes Rating Tables. A rating table is an exportable csv representation
  of a model. Users can influence predictions by modifying them and creating a new model with the
  modified table. See the :ref:`documentation<rating_table>` for more information on how to use
  rating tables.
- `scaleout_modeling_mode` has been added to the `AdvancedOptions` class
  used when setting a project target. It can be used to control whether
  scaleout models appear in the autopilot and/or available blueprints.
  Scaleout models are only supported in the Hadoop environment with
  the corresponding user permission set.
- A new premium add-on product, Time Series, is now available. New projects can be created as time series
  projects which automatically derive features from past data and forecast the future. See the
  :ref:`time series documentation<time_series>` for more information.
- The `Feature` object now returns the EDA summary statistics (i.e., mean, median, minimum, maximum,
  and standard deviation) for features where this is available (e.g., numeric, date, time,
  currency, and length features). These summary statistics will be formatted in the same format
  as the data it summarizes.
- The DataRobot API now supports Training Predictions workflow. Training predictions are made by a
  model for a subset of data from original dataset. User can start a job which will make those
  predictions and retrieve them. See the :ref:`documentation<predictions>`
  for more information on how to use training predictions.
- DataRobot now supports retrieving a :ref:`model blueprint chart<model_blueprint_chart>` and a
  :ref:`model blueprint docs<model_blueprint_doc>`.
- With the introduction of Multiclass Classification projects, DataRobot needed a better way to
  explain the performance of a multiclass model so we created a new Confusion Chart. The API
  now supports retrieving and interacting with confusion charts.

### Enhancements

- `DatetimePartitioningSpecification` now includes the optional `disable_holdout` flag that can
  be used to disable the holdout fold when creating a project with datetime partitioning.
- When retrieving reason codes on a project using an exposure column, predictions that are adjusted
  for exposure can be retrieved.
- File URIs can now be used as sourcedata when creating a project or uploading a prediction dataset.
  The file URI must refer to an allowed location on the server, which is configured as described in
  the user guide documentation.
- The advanced options available when setting the target have been extended to include the new
  parameter 'events_count' as a part of the AdvancedOptions object to allow specifying the
  events count column. See the user guide documentation in the webapp for more information
  on events count.
- PredictJob.get_predictions now returns predicted probability for each class in the dataframe.
- PredictJob.get_predictions now accepts prefix parameter to prefix the classes name returned in the
  predictions dataframe.

### API changes

- Add `target_type` parameter to set_target() and start(), used to override the project default.

## 2.7.2

### Documentation changes

- Updated link to the publicly hosted documentation.

## 2.7.1

### Documentation changes

- Online documentation hosting has migrated from PythonHosted to Read The Docs. Minor code changes
  have been made to support this.

## 2.7.0

### New features

- Lift chart data for models can be retrieved using the `Model.get_lift_chart` and
  `Model.get_all_lift_charts` methods.
- ROC curve data for models in classification projects can be retrieved using the
  `Model.get_roc_curve` and `Model.get_all_roc_curves` methods.
- Semi-automatic autopilot mode is removed.
- Word cloud data for text processing models can be retrieved using `Model.get_word_cloud` method.
- Scoring code JAR file can be downloaded for models supporting code generation.

### Enhancements

- A `__repr__` method has been added to the `PredictionDataset` class to improve readability when
  using the client interactively.
- `Model.get_parameters` now includes an additional key in the derived features it includes,
  showing the coefficients for individual stages of multistage models (e.g. Frequency-Severity
  models).
- When training a `DatetimeModel` on a window of data, a `time_window_sample_pct` can be specified
  to take a uniform random sample of the training data instead of using all data within the window.
- Installing of DataRobot package now has an "Extra Requirements" section that will install all of
  the dependencies needed to run the example notebooks.

### Documentation changes

- A new example notebook describing how to visualize some of the newly available model insights
  including lift charts, ROC curves, and word clouds has been added to the examples section.
- A new section for `Common Issues` has been added to `Getting Started` to help debug issues related to client installation and usage.

## 2.6.1

### Bugfixes

- Fixed a bug with `Model.get_parameters` raising an exception on some valid parameter values.

### Documentation changes

- Fixed sorting order in Feature Impact example code snippet.

## 2.6.0

### New features

- A new partitioning method (datetime partitioning) has been added. The recommended workflow is to
  preview the partitioning by creating a `DatetimePartitioningSpecification` and passing it into
  `DatetimePartitioning.generate`, inspect the results and adjust as needed for the specific project
  dataset by adjusting the `DatetimePartitioningSpecification` and re-generating, and then set the
  target by passing the final `DatetimePartitioningSpecification` object to the partitioning_method
  parameter of `Project.set_target`.
- When interacting with datetime partitioned projects, `DatetimeModel` can be used to access more
  information specific to models in datetime partitioned projects. See
  :ref:`the documentation<datetime_modeling_workflow>` for more information on differences in the
  modeling workflow for datetime partitioned projects.
- The advanced options available when setting the target have been extended to include the new
  parameters 'offset' and 'exposure' (part of the AdvancedOptions object) to allow specifying
  offset and exposure columns to apply to predictions generated by models within the project.
  See the user guide documentation in the webapp for more information on offset
  and exposure columns.
- Blueprints can now be retrieved directly by project_id and blueprint_id via `Blueprint.get`.
- Blueprint charts can now be retrieved directly by project_id and blueprint_id via
  `BlueprintChart.get`. If you already have an instance of `Blueprint` you can retrieve its
  chart using `Blueprint.get_chart`.
- Model parameters can now be retrieved using `ModelParameters.get`. If you already have an
  instance of `Model` you can retrieve its parameters using `Model.get_parameters`.
- Blueprint documentation can now be retrieved using `Blueprint.get_documents`. It will contain
  information about the task, its parameters and (when available) links and references to
  additional sources.
- The DataRobot API now includes Reason Codes. You can now compute reason codes for prediction
  datasets. You are able to specify thresholds on which rows to compute reason codes for to speed
  up computation by skipping rows based on the predictions they generate. See the reason codes
  :ref:`documentation<reason_codes>` for more information.

### Enhancements

- A new parameter has been added to the `AdvancedOptions` used with `Project.set_target`. By
  specifying `accuracyOptimizedMb=True` when creating `AdvancedOptions`, longer-running models
  that may have a high accuracy will be included in the autopilot and made available to run
  manually.
- A new option for `Project.create_type_transform_feature` has been added which explicitly
  truncates data when casting numerical data as categorical data.
- Added 2 new blenders for projects that use MAD or Weighted MAD as a metric. The MAE blender uses
  BFGS optimization to find linear weights for the blender that minimize mean absolute error
  (compared to the GLM blender, which finds linear weights that minimize RMSE), and the MAEL1
  blender uses BFGS optimization to find linear weights that minimize MAE + a L1 penalty on the
  coefficients (compared to the ENET blender, which minimizes RMSE + a combination of the L1 and L2
  penalty on the coefficients).

### Bugfixes

- Fixed a bug (affecting Python 2 only) with printing any model (including frozen and prime models)
  whose model_type is not ascii.
- FrozenModels were unable to correctly use methods inherited from Model. This has been fixed.
- When calling `get_result` for a Job, ModelJob, or PredictJob that has errored, `AsyncProcessUnsuccessfulError` will now be raised instead of `JobNotFinished`, consistently with the behavior of `get_result_when_complete`.

### Deprecation summary

- Support for the experimental Recommender Problems projects has been removed. Any code relying on
  `RecommenderSettings` or the `recommender_settings` argument of `Project.set_target` and
  `Project.start` will error.
- `Project.update`, deprecated in v2.2.32, has been removed in favor of specific updates:
  `rename`, `unlock_holdout`, `set_worker_count`.

### Documentation changes

- The link to Configuration from the Quickstart page has been fixed.

## 2.5.1

### Bugfixes

- Fixed a bug (affecting Python 2 only) with printing blueprints  whose names are
  not ascii.
- Fixed an issue where the weights column (for weighted projects) did not appear
  in the `advanced_options` of a `Project`.

## 2.5.0

### New features

- Methods to work with blender models have been added. Use `Project.blend` method to create new blenders,
  `Project.get_blenders` to get the list of existing blenders and `BlenderModel.get` to retrieve a model
  with blender-specific information.
- Projects created via the API can now use smart downsampling when setting the target by passing
  `smart_downsampled` and `majority_downsampling_rate` into the `AdvancedOptions` object used with
  `Project.set_target`. The smart sampling options used with an existing project will be available
  as part of `Project.advanced_options`.
- Support for frozen models, which use tuning parameters from a parent model for more efficient
  training, has been added. Use `Model.request_frozen_model` to create a new frozen model,
  `Project.get_frozen_models` to get the list of existing frozen models and `FrozenModel.get` to
  retrieve a particular frozen model.

### Enhancements

- The inferred date format (e.g. "%Y-%m-%d %H:%M:%S") is now included in the Feature object. For
  non-date features, it will be None.
- When specifying the API endpoint in the configuration, the client will now behave correctly for
  endpoints with and without trailing slashes.

## 2.4.0

### New features

- The premium add-on product `DataRobot Prime` has been added. You can now approximate a model
  on the leaderboard and download executable code for it. See documentation for further details, or
  talk to your account representative if the feature is not available on your account.
- (Only relevant for on-premise users with a Standalone Scoring cluster.) Methods
  (`request_transferable_export` and `download_export`) have been added to the `Model` class for exporting models (which will only work if model export is turned on). There is a new class `ImportedModel` for managing imported models on a Standalone
  Scoring cluster.
- It is now possible to create projects from a WebHDFS, PostgreSQL, Oracle or MySQL data source. For more information see the
  documentation for the relevant `Project` classmethods: `create_from_hdfs`, `create_from_postgresql`,
  `create_from_oracle` and `create_from_mysql`.
- `Job.wait_for_completion`, which waits for a job to complete without returning anything, has been added.

### Enhancements

- The client will now check the API version offered by the server specified in configuration, and
  give a warning if the client version is newer than the server version. The DataRobot server is
  always backwards compatible with old clients, but new clients may have functionality that is
  not implemented on older server versions. This issue mainly affects users with on-premise deployments
  of DataRobot.

### Bugfixes

- Fixed an issue where `Model.request_predictions` might raise an error when predictions finished
  very quickly instead of returning the job.

### API changes

- To set the target with quickrun autopilot, call `Project.set_target` with `mode=AUTOPILOT_MODE.QUICK` instead of
  specifying `quickrun=True`.

### Deprecation summary

- Semi-automatic mode for autopilot has been deprecated and will be removed in 3.0.
  Use manual or fully automatic instead.
- Use of the `quickrun` argument in `Project.set_target` has been deprecated and will be removed in
  3.0. Use `mode=AUTOPILOT_MODE.QUICK` instead.

### Configuration changes

- It is now possible to control the SSL certificate verification by setting the parameter
  `ssl_verify` in the config file.

### Documentation changes

- The "Modeling Airline Delay" example notebook has been updated to work with the new 2.3
  enhancements.
- Documentation for the generic `Job` class has been added.
- Class attributes are now documented in the `API Reference` section of the documentation.
- The changelog now appears in the documentation.
- There is a new section dedicated to configuration, which lists all of the configuration
  options and their meanings.

## 2.3.0

### New features

- The DataRobot API now includes Feature Impact, an approach to measuring the relevance of each feature
  that can be applied to any model. The `Model` class now includes methods `request_feature_impact`
  (which creates and returns a feature impact job) and `get_feature_impact` (which can retrieve completed feature impact results).
- A new improved workflow for predictions now supports first uploading a dataset via `Project.upload_dataset`,
  then requesting predictions via `Model.request_predictions`. This allows us to better support predictions on
  larger datasets and non-ascii files.
- Datasets previously uploaded for predictions (represented by the `PredictionDataset` class) can be listed from
  `Project.get_datasets` and retrieve and deleted via `PredictionDataset.get` and `PredictionDataset.delete`.
- You can now create a new feature by re-interpreting the type of an existing feature in a project by
  using the `Project.create_type_transform_feature` method.
- The `Job` class now includes a `get` method for retrieving a job and a `cancel` method for
  canceling a job.
- All of the jobs classes (`Job`, `ModelJob`, `PredictJob`) now include the following new methods:
  `refresh` (for refreshing the data in the job object), `get_result` (for getting the
  completed resource resulting from the job), and `get_result_when_complete` (which waits until the job
  is complete and returns the results, or times out).
- A new method `Project.refresh` can be used to update
  `Project` objects with the latest state from the server.
- A new function `datarobot.async.wait_for_async_resolution` can be
  used to poll for the resolution of any generic asynchronous operation
  on the server.

### Enhancements

- The `JOB_TYPE` enum now includes `FEATURE_IMPACT`.
- The `QUEUE_STATUS` enum now includes `ABORTED` and `COMPLETED`.
- The `Project.create` method now has a `read_timeout` parameter which can be used to
  keep open the connection to DataRobot while an uploaded file is being processed.
  For very large files this time can be substantial. Appropriately raising this value
  can help avoid timeouts when uploading large files.
- The method `Project.wait_for_autopilot` has been enhanced to error if
  the project enters a state where autopilot may not finish. This avoids
  a situation that existed previously where users could wait
  indefinitely on their project that was not going to finish. However,
  users are still responsible to make sure a project has more than
  zero workers, and that the queue is not paused.
- Feature.get now supports retrieving features by feature name. (For backwards compatibility,
  feature IDs are still supported until 3.0.)
- File paths that have unicode directory names can now be used for
  creating projects and PredictJobs. The filename itself must still
  be ascii, but containing directory names can have other encodings.
- Now raises more specific JobAlreadyRequested exception when we refuse a model fitting request as a duplicate.
  Users can explicitly catch this exception if they want it to be ignored.
- A `file_name` attribute has been added to the `Project` class, identifying the file name
  associated with the original project dataset. Note that if the project was created from
  a data frame, the file name may not be helpful.
- The connect timeout for establishing a connection to the server can now be set directly. This can be done in the
  yaml configuration of the client, or directly in the code. The default timeout has been lowered from 60 seconds
  to 6 seconds, which will make detecting a bad connection happen much quicker.

### Bugfixes

- Fixed a bug (affecting Python 2 only) with printing features and featurelists whose names are
  not ascii.

### API changes

- Job class hierarchy is rearranged to better express the relationship between these objects. See
  documentation for `datarobot.models.job` for details.
- `Featurelist` objects now have a `project_id` attribute to indicate which project they belong
  to. Directly accessing the `project` attribute of a `Featurelist` object is now deprecated
- Support INI-style configuration, which was deprecated in v2.1, has been removed. yaml is the only supported
  configuration format.
- The method `Project.get_jobs` method, which was deprecated in v2.1, has been removed. Users should use
  the `Project.get_model_jobs` method instead to get the list of model jobs.

### Deprecation summary

- `PredictJob.create` has been deprecated in favor of the alternate workflow using `Model.request_predictions`.
- Feature.converter (used internally for object construction) has been made private.
- Model.fetch_resource_data has been deprecated and will be removed in 3.0. To fetch a model from
  : its ID, use Model.get.
- The ability to use Feature.get with feature IDs (rather than names) is deprecated and will
  be removed in 3.0.
- Instantiating a `Project`, `Model`, `Blueprint`, `Featurelist`, or `Feature` instance from a `dict`
  of data is now deprecated. Please use the `from_data` classmethod of these classes instead. Additionally,
  instantiating a `Model` from a tuple or by using the keyword argument `data` is also deprecated.
- Use of the attribute `Featurelist.project` is now deprecated. You can use the `project_id`
  attribute of a `Featurelist` to instantiate a `Project` instance using `Project.get`.
- Use of the attributes `Model.project`, `Model.blueprint`, and `Model.featurelist` are all deprecated now
  to avoid use of partially instantiated objects. Please use the ids of these objects instead.
- Using a `Project` instance as an argument in `Featurelist.get` is now deprecated.
  Please use a project_id instead. Similarly, using a `Project` instance in `Model.get` is also deprecated,
  and a project_id should be used in its place.

### Configuration changes

- Previously it was possible (though unintended) that the client configuration could be mixed through
  environment variables, configuration files, and arguments to `datarobot.Client`. This logic is now
  simpler - please see the `Getting Started` section of the documentation for more information.

## 2.2.33

### Bugfixes

- Fixed a bug with non-ascii project names using the package with Python 2.
- Fixed an error that occurred when printing projects that had been constructed from an ID only or
  printing printing models that had been constructed from a tuple (which impacted printing PredictJobs).
- Fixed a bug with project creation from non-ascii file names. Project creation from non-ascii file names
  is not supported, so this now raises a more informative exception. The project name is no longer used as
  the file name in cases where we do not have a file name, which prevents non-ascii project names from
  causing problems in those circumstances.
- Fixed a bug (affecting Python 2 only) with printing projects, features, and featurelists whose names are
  not ascii.

## 2.2.32

### New features

- `Project.get_features` and `Feature.get` methods have been added for feature retrieval.
- A generic `Job` entity has been added for use in retrieving the entire queue at once. Calling
  `Project.get_all_jobs` will retrieve all (appropriately filtered) jobs from the queue. Those
  can be cancelled directly as generic jobs, or transformed into instances of the specific
  job class using `ModelJob.from_job` and `PredictJob.from_job`, which allow all functionality
  previously available via the ModelJob and PredictJob interfaces.
- `Model.train` now supports `featurelist_id` and `scoring_type` parameters, similar to
  `Project.train`.

### Enhancements

- Deprecation warning filters have been updated. By default, a filter will be added ensuring that
  usage of deprecated features will display a warning once per new usage location. In order to
  hide deprecation warnings, a filter like
  `warnings.filterwarnings('ignore', category=DataRobotDeprecationWarning)`
  can be added to a script so no such warnings are shown. Watching for deprecation warnings
  to avoid reliance on deprecated features is recommended.
- If your client is misconfigured and does not specify an endpoint, the cloud production server is
  no longer used as the default as in many cases this is not the correct default.
- This changelog is now included in the distributable of the client.

### Bugfixes

- Fixed an issue where updating the global client would not affect existing objects with cached clients.
  Now the global client is used for every API call.
- An issue where mistyping a filepath for use in a file upload has been resolved. Now an error will be
  raised if it looks like the raw string content for modeling or predictions is just one single line.

### API changes

- Use of username and password to authenticate is no longer supported - use an API token instead.
- Usage of `start_time` and `finish_time` parameters in `Project.get_models` is not
  supported both in filtering and ordering of models
- Default value of `sample_pct` parameter of `Model.train` method is now `None` instead of `100`.
  If the default value is used, models will be trained with all of the available *training* data based on
  project configuration, rather than with entire dataset including holdout for the previous default value
  of `100`.
- `order_by` parameter of `Project.list` which was deprecated in v2.0 has been removed.
- `recommendation_settings` parameter of `Project.start` which was deprecated in v0.2 has been removed.
- `Project.status` method which was deprecated in v0.2 has been removed.
- `Project.wait_for_aim_stage` method which was deprecated in v0.2 has been removed.
- `Delay`, `ConstantDelay`, `NoDelay`, `ExponentialBackoffDelay`, `RetryManager`
  classes from `retry` module which were deprecated in v2.1 were removed.
- Package renamed to `datarobot`.

### Deprecation summary

- `Project.update` deprecated in favor of specific updates:
  `rename`, `unlock_holdout`, `set_worker_count`.

### Documentation changes

- A new use case involving financial data has been added to the `examples` directory.
- Added documentation for the partition methods.

## 2.1.31

### Bugfixes

- In Python 2, using a unicode token to instantiate the client will
  now work correctly.

## 2.1.30

### Bugfixes

- The minimum required version of `trafaret` has been upgraded to 0.7.1
  to get around an incompatibility between it and `setuptools`.

## 2.1.29

### Enhancements

- Minimal used version of `requests_toolbelt` package changed from 0.4 to 0.6

## 2.1.28

### New features

- Default to reading YAML config file from `~/.config/datarobot/drconfig.yaml`
- Allow `config_path` argument to client
- `wait_for_autopilot` method added to Project. This method can be used to
  block execution until autopilot has finished running on the project.
- Support for specifying which featurelist to use with initial autopilot in
  `Project.set_target`
- `Project.get_predict_jobs` method has been added, which looks up all prediction jobs for a
  project
- `Project.start_autopilot` method has been added, which starts autopilot on
  specified featurelist
- The schema for `PredictJob` in DataRobot API v2.1 now includes a `message`. This attribute has
  been added to the PredictJob class.
- `PredictJob.cancel` now exists to cancel prediction jobs, mirroring `ModelJob.cancel`
- `Project.from_async` is a new classmethod that can be used to wait for an async resolution
  in project creation. Most users will not need to know about it as it is used behind the scenes
  in `Project.create` and `Project.set_target`, but power users who may run
  into periodic connection errors will be able to catch the new ProjectAsyncFailureError
  and decide if they would like to resume waiting for async process to resolve

### Enhancements

- `AUTOPILOT_MODE` enum now uses string names for autopilot modes instead of numbers

### Deprecation summary

- `ConstantDelay`, `NoDelay`, `ExponentialBackoffDelay`, and `RetryManager` utils are now deprecated
- INI-style config files are now deprecated (in favor of YAML config files)
- Several functions in the `utils` submodule are now deprecated (they are
  being moved elsewhere and are not considered part of the public interface)
- `Project.get_jobs` has been renamed `Project.get_model_jobs` for clarity and deprecated
- Support for the experimental date partitioning has been removed in DataRobot API,
  so it is being removed from the client immediately.

### API changes

- In several places where `AppPlatformError` was being raised, now `TypeError`, `ValueError` or
  `InputNotUnderstoodError` are now used. With this change, one can now safely assume that when
  catching an `AppPlatformError` it is because of an unexpected response from the server.
- `AppPlatformError` has gained a two new attributes, `status_code` which is the HTTP status code
  of the unexpected response from the server, and `error_code` which is a DataRobot-defined error
  code. `error_code` is not used by any routes in DataRobot API 2.1, but will be in the future.
  In cases where it is not provided, the instance of `AppPlatformError` will have the attribute
  `error_code` set to `None`.
- Two new subclasses of `AppPlatformError` have been introduced, `ClientError` (for 400-level
  response status codes) and `ServerError` (for 500-level response status codes). These will make
  it easier to build automated tooling that can recover from periodic connection issues while polling.
- If a `ClientError` or `ServerError` occurs during a call to `Project.from_async`, then a
  `ProjectAsyncFailureError` (a subclass of AsyncFailureError) will be raised. That exception will
  have the status_code of the unexpected response from the server, and the location that was being
  polled to wait for the asynchronous process to resolve.

## 2.0.27

### New features

- `PredictJob` class was added to work with prediction jobs
- `wait_for_async_predictions` function added to `predict_job` module

### Deprecation summary

- The `order_by` parameter of the `Project.list` is now deprecated.

## 0.2.26

### Enhancements

- `Projet.set_target` will re-fetch the project data after it succeeds,
  keeping the client side in sync with the state of the project on the
  server
- `Project.create_featurelist` now throws `DuplicateFeaturesError`
  exception if passed list of features contains duplicates
- `Project.get_models` now supports snake_case arguments to its
  order_by keyword

### Deprecation summary

- `Project.wait_for_aim_stage` is now deprecated, as the REST Async
  flow is a more reliable method of determining that project creation has
  completed successfully
- `Project.status` is deprecated in favor of `Project.get_status`
- `recommendation_settings` parameter of `Project.start` is
  deprecated in favor of `recommender_settings`

### Bugfixes

- `Project.wait_for_aim_stage` changed to support Python 3
- Fixed incorrect value of `SCORING_TYPE.cross_validation`
- Models returned by `Project.get_models` will now be correctly
  ordered when the order_by keyword is used

## 0.2.25

- Pinned versions of required libraries

## 0.2.24

Official release of v0.2

## 0.1.24

- Updated documentation
- Renamed parameter `name` of `Project.create` and `Project.start` to `project_name`
- Removed `Model.predict` method
- `wait_for_async_model_creation` function added to `modeljob` module
- `wait_for_async_status_service` of `Project` class renamed to `_wait_for_async_status_service`
- Can now use auth_token in config file to configure API Client

## 0.1.23

- Fixes a method that pointed to a removed route

## 0.1.22

- Added `featurelist_id` attribute to `ModelJob` class

## 0.1.21

- Removes `model` attribute from `ModelJob` class

## 0.1.20

- Project creation raises `AsyncProjectCreationError` if it was unsuccessful
- Removed `Model.list_prime_rulesets` and `Model.get_prime_ruleset` methods
- Removed `Model.predict_batch` method
- Removed `Project.create_prime_model` method
- Removed `PrimeRuleSet` model
- Adds backwards compatibility bridge for ModelJob async
- Adds ModelJob.get and ModelJob.get_model

## 0.1.19

- Minor bugfixes in `wait_for_async_status_service`

## 0.1.18

- Removes `submit_model` from Project until server-side implementation is improved
- Switches training URLs for new resource-based route at /projects/\<project_id>/models/
- Job renamed to ModelJob, and using modelJobs route
- Fixes an inconsistency in argument order for `train` methods

## 0.1.17

- `wait_for_async_status_service` timeout increased from 60s to 600s

## 0.1.16

- `Project.create` will now handle both async/sync project creation

## 0.1.15

- All routes pluralized to sync with changes in API
- `Project.get_jobs` will request all jobs when no param specified
- dataframes from `predict` method will have pythonic names
- `Project.get_status` created, `Project.status` now deprecated
- `Project.unlock_holdout` created.
- Added `quickrun` parameter to `Project.set_target`
- Added `modelCategory` to Model schema
- Add `permalinks` feature to Project and Model objects.
- `Project.create_prime_model` created

## 0.1.14

- `Project.set_worker_count` fix for compatibility with API change in project update.

## 0.1.13

- Add positive class to `set_target`.
- Change attributes names of `Project`, `Model`, `Job` and `Blueprint`
  : - `features` in `Model`, `Job` and `Blueprint` are now `processes`
    - `dataset_id` and `dataset_name` migrated to `featurelist_id` and `featurelist_name`.
    - `samplepct` -> `sample_pct`
- `Model` has now `blueprint`, `project`, and `featurlist` attributes.
- Minor bugfixes.

## 0.1.12

- Minor fixes regarding rename `Job` attributes. `features` attributes now named `processes`, `samplepct` now is `sample_pct`.

## 0.1.11

(May 27, 2015)

- Minor fixes regarding migrating API from under_score names to camelCase.

## 0.1.10

(May 20, 2015)

- Remove `Project.upload_file`, `Project.upload_file_from_url` and `Project.attach_file` methods. Moved all logic that uploading file to `Project.create` method.

## 0.1.9

(May 15, 2015)

- Fix uploading file causing a lot of memory usage. Minor bugfixes.
