"""Invoice management module."""
