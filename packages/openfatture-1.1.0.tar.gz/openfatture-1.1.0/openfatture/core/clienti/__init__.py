"""Client management module."""
