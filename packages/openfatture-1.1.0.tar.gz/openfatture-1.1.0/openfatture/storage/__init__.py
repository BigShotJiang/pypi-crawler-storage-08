"""Data storage and persistence."""
