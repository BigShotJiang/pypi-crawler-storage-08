"""LLM prompt templates."""
