"""FatturaPA XML generation."""
