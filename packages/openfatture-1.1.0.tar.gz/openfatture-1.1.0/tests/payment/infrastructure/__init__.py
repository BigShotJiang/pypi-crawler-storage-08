"""Infrastructure layer tests."""
