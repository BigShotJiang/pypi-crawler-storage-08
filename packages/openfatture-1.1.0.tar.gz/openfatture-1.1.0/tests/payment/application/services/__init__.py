"""Application services tests."""
