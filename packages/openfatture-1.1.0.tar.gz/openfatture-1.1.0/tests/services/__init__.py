"""Tests for OpenFatture services."""
