"""Test suite for OpenFatture."""
