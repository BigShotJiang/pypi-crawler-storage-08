"""Integration tests for OpenFatture."""
