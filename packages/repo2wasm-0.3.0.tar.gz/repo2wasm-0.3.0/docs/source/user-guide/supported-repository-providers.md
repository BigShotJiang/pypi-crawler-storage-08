(supported-repository-providers)=

# Supported repository providers

[`jupyter-repo2docker`]'s implementation of repository providers are used here.

## Local directory

![Static Badge](https://img.shields.io/badge/status-implemented-green)
![Static Badge](https://img.shields.io/badge/version-0.3.0-blue)

## Git repository

![Static Badge](https://img.shields.io/badge/status-implemented-green)
![Static Badge](https://img.shields.io/badge/version-0.3.0-blue)

## Mercurial repository

![Static Badge](https://img.shields.io/badge/status-implemented-green)
![Static Badge](https://img.shields.io/badge/version-0.3.0-blue)

## Zenodo DOI

![Static Badge](https://img.shields.io/badge/status-implemented-green)
![Static Badge](https://img.shields.io/badge/version-0.3.0-blue)

## Figshare DOI

![Static Badge](https://img.shields.io/badge/status-implemented-green)
![Static Badge](https://img.shields.io/badge/version-0.3.0-blue)

## Dataverse DOI

![Static Badge](https://img.shields.io/badge/status-implemented-green)
![Static Badge](https://img.shields.io/badge/version-0.3.0-blue)

## SoftWare Heritage persistent IDentifiers (SWHIDs)

![Static Badge](https://img.shields.io/badge/status-implemented-green)
![Static Badge](https://img.shields.io/badge/version-0.3.0-blue)

## CKAN dataset

![Static Badge](https://img.shields.io/badge/status-implemented-green)
![Static Badge](https://img.shields.io/badge/version-0.3.0-blue)

[`jupyter-repo2docker`]: https://github.com/jupyterhub/repo2docker