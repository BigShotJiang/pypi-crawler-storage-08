# Architecture

`repo2wasm` follows a similar architecture as [`jupyter-repo2docker`], i.e. the configuration file provided by the user are incorporated into a [Conda](https://docs.conda.io/en/latest/index.html) environment.

[`jupyter-repo2docker`]: https://github.com/jupyterhub/repo2docker