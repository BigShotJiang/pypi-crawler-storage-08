# Contributor guide

```{toctree}
:maxdepth: 2
:caption: Table of Contents

architecture.md
```