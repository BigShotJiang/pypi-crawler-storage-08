"""A simple Hello World package."""
__version__ = "0.2.0"

def test_print():
    """Print Hello World to the console."""
    print("Hello CL")