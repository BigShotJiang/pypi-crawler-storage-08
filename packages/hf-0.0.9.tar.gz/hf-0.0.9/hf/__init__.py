"""Huggingface interface"""

from hf.base import HfDatasets, HfModels, HfSpaces, HfPapers, HfMapping
