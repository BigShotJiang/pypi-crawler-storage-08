"""Module containing version information for the version_builder package.

Defines the current version of the package as a semantic version string.
"""

VERSION: str = "0.5.1"
