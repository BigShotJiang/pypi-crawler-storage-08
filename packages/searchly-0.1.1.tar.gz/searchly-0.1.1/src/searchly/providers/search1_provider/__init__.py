"""Search1 API client."""
