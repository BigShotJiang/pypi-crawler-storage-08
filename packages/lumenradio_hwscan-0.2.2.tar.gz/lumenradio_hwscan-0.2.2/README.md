# hwscan

Detects attached hardware (TriLightSense FTDI, STLINK-V3, Espressif USB JTAG/serial, host info) on Linux via sysfs.

## Install

```bash
pip install lumenradio-hwscan
```

## Usage
```bash
hwscan --pretty
```