Create Equipments when the purchase is validated.
