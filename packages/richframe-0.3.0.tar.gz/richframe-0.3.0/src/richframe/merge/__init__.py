"""Cell merging utilities for richframe tables."""
from .engine import apply_merges

__all__ = ["apply_merges"]
