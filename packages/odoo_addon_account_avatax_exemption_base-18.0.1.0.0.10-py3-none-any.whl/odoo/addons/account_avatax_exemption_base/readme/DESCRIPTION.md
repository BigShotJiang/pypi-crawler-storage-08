This module is a component of the Avatax Exemption Integration with odoo
app and it is used as an anchor module for account_avatax_exemption to
add support for odoo enterprise module such as sign and document
extension.
