- Sodexis
  - Atchuthan Ubendran \<<atchuthan@sodexis.com>\>
  - Stephan Keller \<<skeller@sodexis.com>\>
  - SodexisTeam \<<dev@sodexis.com>\>

- Open Source Integrators (<https://opensourceintegrators.com>)
  - Nikul Chaudhary \<<nchaudhary@opensourceintegrators.com>\>

- Kencove (<https://kencove.com>)
  - Don Kendall \<<kendall@donkendall.com>\>
  - Mohamed Alkobrosli \<<malkobrosly@kencove.com>\>
  - Wai-Lun Lin \<<wlin@kencove.com>\>
