- Go to the Purchase Request Lines from the menu entry 'Purchase
  Requests', and also from the 'Purchase' menu.
- Select the lines that you wish to initiate the Purchase Agreement for,
  then go to 'More' and press 'Create Purchase Agreement'. You can
  choose to select an existing Draft Call for Bids or create a new one.
- The application attempts to consolidate the lines in the Purchase
  Agreement in in as few lines as possible, for the same product, UoM
  and analytic account.
