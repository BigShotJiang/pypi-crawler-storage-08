from .null_reader import NullReader
from .null_writer import NullWriter
