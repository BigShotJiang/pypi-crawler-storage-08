"""
Copyright (c) 2025 SKA-Low Commissioning Team. All rights reserved.

SKA-Low Commissioning Tools: SKA-Low Commissioning Tools
"""

from __future__ import annotations

from ._version import version as __version__

__all__ = ["__version__"]
