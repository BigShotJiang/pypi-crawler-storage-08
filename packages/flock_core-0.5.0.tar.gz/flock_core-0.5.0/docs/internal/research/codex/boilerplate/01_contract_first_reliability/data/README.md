Artifacts for data.
