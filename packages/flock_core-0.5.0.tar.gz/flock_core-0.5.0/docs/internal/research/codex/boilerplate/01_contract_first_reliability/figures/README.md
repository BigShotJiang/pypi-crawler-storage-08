Artifacts for figures.
