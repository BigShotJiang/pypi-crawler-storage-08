"""Default Websocket Server Implementation."""
