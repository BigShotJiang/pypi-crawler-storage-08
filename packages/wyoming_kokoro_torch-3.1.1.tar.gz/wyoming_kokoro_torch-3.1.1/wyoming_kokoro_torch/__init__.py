"""Wyoming server for kokoro."""

from importlib.metadata import version

__version__ = version("wyoming_kokoro_torch")

__all__ = ["__version__"]
