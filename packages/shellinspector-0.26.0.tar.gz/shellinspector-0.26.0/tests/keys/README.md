These are test keys used only in automated testing in docker containers in
private networks. Not on any production machine.

Nothing to see here. Move along.
