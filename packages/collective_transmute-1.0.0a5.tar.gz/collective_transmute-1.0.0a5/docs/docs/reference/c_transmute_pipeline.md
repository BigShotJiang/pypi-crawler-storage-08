---
myst:
  html_meta:
    "description": "collective.transmute Reference"
    "property=og:description": "collective.transmute Reference"
    "property=og:title": "collective.transmute Reference"
    "keywords": "Plone, collective.transmute, reference"
---

# `collective.transmute.pipeline`

```{eval-rst}
.. automodule:: collective.transmute.pipeline
    :members:
    :private-members:
```

## `collective.transmute.pipeline.pipeline`

```{eval-rst}
.. automodule:: collective.transmute.pipeline.pipeline
    :members:
    :private-members:
```

## `collective.transmute.pipeline.prepare`

```{eval-rst}
.. automodule:: collective.transmute.pipeline.prepare
    :members:
    :private-members:
```

## `collective.transmute.pipeline.report`

```{eval-rst}
.. automodule:: collective.transmute.pipeline.report
    :members:
    :private-members:
```
