# Changes

<!-- towncrier release notes start -->

## 1.0.0a1 (2025-09-16)


### Feature

- Generate a redirects.json file. @ericof, @jnptk [#23](https://github.com/collective/collective.transmute/issues/23)
- Initial implementation of collective.transmute [@ericof] 
- Use collective.html2blocks version 1.0.0a2. @ericof 


### Bugfix

- Fix Topics ordering not being migrated. @ericof [#9](https://github.com/collective/collective.transmute/issues/9)


### Internal

- Implement GHA workflows. @ericof 


### Documentation

- Deploy package documentation to https://collective.github.io/collective.transmute @ericof
