---
myst:
  html_meta:
    "description": "Create a new pipeline step in collective.transmute"
    "property=og:description": "Create a new pipeline step in collective.transmute"
    "property=og:title": "Create a new pipeline step in collective.transmute"
    "keywords": "Plone, collective.transmute, create, pipeline, step, guides"
---

# Create pipeline step

If you want, in your package, to create a new pipeline step...
