def get_printable_number(num: float):
    return '{:.9g}'.format(num)
