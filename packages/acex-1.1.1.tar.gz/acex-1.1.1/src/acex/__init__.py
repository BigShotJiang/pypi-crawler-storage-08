
# Fast startup - no heavy imports at module level
# Users can import these explicitly when needed:
# from acex.automation_engine import AutomationEngine
# from acex.inventory import Inventory
