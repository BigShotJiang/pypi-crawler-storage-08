
from .base_component import ConfigComponent