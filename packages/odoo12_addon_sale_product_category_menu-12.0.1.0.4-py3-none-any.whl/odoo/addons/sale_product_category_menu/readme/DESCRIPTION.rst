This module shows 'Product Categories' menu item in Sale > Configuration > Products.
