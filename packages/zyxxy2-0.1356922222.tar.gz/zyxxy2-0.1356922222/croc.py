import sys; sys.path.append('src')
from zyxxy2 import *

example_animated_croc()