Truncation
================
TODO
