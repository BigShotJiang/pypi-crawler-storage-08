Allow frontend users to edit their fiscal code from their *details*
page.
