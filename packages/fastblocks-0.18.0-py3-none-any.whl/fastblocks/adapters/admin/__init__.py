"""FastBlocks admin adapters."""
