"""FastBlocks font adapters."""
