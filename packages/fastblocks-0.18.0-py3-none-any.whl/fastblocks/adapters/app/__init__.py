"""FastBlocks app adapters."""
