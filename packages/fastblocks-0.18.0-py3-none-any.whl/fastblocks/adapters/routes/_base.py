from acb.config import AdapterBase, Settings


class RoutesBaseSettings(Settings): ...  # type: ignore[misc]


class RoutesBase(AdapterBase): ...  # type: ignore[misc]
