from . import generated_stubs # noqa: F403
from .generated_stubs.waymo import open_dataset as waymo

__all__ = ['waymo']