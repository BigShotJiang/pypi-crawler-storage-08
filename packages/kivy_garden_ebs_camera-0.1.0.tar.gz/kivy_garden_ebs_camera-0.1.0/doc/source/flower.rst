.. _flower-api:

******
Flower
******

:mod:`kivy_garden.flower`
=============================

.. automodule:: kivy_garden.flower
   :members:
   :undoc-members:
   :show-inheritance:
