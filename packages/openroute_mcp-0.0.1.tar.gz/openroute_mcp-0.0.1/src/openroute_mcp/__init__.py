"""MCP server to build routes."""

__version__ = "0.0.1"
