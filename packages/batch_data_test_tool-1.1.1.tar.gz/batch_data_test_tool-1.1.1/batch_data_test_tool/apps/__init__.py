"""
应用程序模块

包含主要的用户界面和应用程序逻辑。
"""

from .cola import cola_start

__all__ = ["cola_start"]
