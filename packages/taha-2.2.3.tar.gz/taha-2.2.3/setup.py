from setuptools import setup

setup(
    name='taha',
    version='2.2.3',
    py_modules=['taha'],
    author='T_programmer',
    description='it is the great library you can find right or left click and select color and open GIF or TEXT or change format it do you want to USE IT??__________ اين يه کتابخانه است براي تو ميتوني باهاش تغيير فرمت بدي و يا کليک ها را تشخيص بدي و کلي کار ديگه نظرت چيه ؟؟',
    python_requires='>=3.6',
)
