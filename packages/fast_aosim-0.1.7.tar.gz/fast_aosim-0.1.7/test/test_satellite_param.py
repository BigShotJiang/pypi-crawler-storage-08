p_simu = {
    
    'satellite_name' : None,
    'telescop_lat' : +28.7572,
    'telescop_lon' : -17.8850,  

    'N_sample' : 3,
    't0_research' : None,
    'research_window' : 10,
    'altitude_min' : 5,
    'altitude_max' : 90,
    'zenith_stop' : False

}