import fast
import numpy

sim = fast.Fast("test_params.py")

sim.run()