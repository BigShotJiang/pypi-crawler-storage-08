#exonware/xwsystem/tests/core/utils/__init__.py
"""
Utils Core Tests Package

Tests for XSystem utility functions including lazy loading,
path utilities, and common utilities.
"""
