# Getting started

## Installation

```
pip install python_dms
```