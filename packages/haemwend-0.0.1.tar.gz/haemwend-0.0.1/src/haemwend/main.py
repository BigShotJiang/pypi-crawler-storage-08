from structlog.stdlib import get_logger

logger = get_logger(__name__)


def main():
    logger.info("Hello, World!")
