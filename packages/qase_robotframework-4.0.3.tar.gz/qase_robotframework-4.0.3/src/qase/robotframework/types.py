STATUSES = {
    "PASS": "passed",
    "FAIL": "failed",
    "SKIP": "skipped",
    "NOT RUN": "skipped",
    "NOT_SET": "skipped"
}
