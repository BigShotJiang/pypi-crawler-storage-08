Gmusic Plugin
=============

The ``gmusic`` plugin interfaced beets to Google Play Music. It has been removed
after the shutdown of this service.
