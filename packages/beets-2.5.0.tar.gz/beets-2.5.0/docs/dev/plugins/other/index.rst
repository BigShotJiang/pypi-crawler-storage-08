Further Reading
===============

For more information on writing plugins, feel free to check out the following
resources:

.. toctree::
    :maxdepth: 2

    config
    templates
    mediafile
    import
    fields
    logging
    prompts
