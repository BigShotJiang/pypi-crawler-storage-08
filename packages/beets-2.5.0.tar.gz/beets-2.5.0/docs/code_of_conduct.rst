.. code_of_conduct:

.. include:: ../CODE_OF_CONDUCT.rst
