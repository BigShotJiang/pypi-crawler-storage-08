Plugins
=======

.. currentmodule:: beets.plugins

.. autosummary::
    :toctree: generated/

    BeetsPlugin

.. currentmodule:: beets.metadata_plugins

.. autosummary::
    :toctree: generated/

    MetadataSourcePlugin
    SearchApiMetadataSourcePlugin
