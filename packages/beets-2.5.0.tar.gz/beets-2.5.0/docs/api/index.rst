API Reference
=============

.. toctree::
    :maxdepth: 2
    :titlesonly:

    plugins
    database
