# Make python -m testall.py work.
