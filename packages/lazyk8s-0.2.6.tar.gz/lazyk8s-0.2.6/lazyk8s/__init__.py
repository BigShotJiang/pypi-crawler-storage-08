"""lazyk8s - The lazier way to manage Kubernetes"""

__version__ = "0.1.0"
