"""Indexing pipeline components for discovering, chunking, and indexing code."""


