shiboken_library_soversion = "6.10"

version = "6.10.0"
version_info = (6, 10, 0, "", "")

__build_date__ = '2025-10-06T11:18:30+00:00'




__setup_py_package_version__ = '6.10.0'
__qt_macos_min_deployment_target__ = '13'
