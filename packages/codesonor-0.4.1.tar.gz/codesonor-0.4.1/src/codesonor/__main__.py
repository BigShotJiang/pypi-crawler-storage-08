"""Allow running codesonor as a module: python -m codesonor"""

from codesonor.cli import cli

if __name__ == "__main__":
    cli()
