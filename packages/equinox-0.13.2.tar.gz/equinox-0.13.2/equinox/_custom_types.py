from typing import Any

from ._doc_utils import doc_repr


sentinel: Any = doc_repr(object(), "sentinel")
