* support missing formats
* add empty fields
