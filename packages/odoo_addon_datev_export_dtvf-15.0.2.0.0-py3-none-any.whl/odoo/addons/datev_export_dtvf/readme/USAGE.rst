To use this module, you need to:

#. Go to `Invoicing` / `Reporting` / `DATEV export`
#. Create an export, choose a date range to use as fiscal year, and ranges to export
#. Click ``Generate``
