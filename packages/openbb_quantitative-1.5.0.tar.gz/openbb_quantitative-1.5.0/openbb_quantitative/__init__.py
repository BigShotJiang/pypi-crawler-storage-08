"""Quantitative analysis extension for OpenBB Platform."""
