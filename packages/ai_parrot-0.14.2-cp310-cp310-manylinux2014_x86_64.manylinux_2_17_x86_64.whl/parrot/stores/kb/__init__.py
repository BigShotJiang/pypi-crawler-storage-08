from .abstract import AbstractKnowledgeBase

__all__ = (
    'AbstractKnowledgeBase',
)
