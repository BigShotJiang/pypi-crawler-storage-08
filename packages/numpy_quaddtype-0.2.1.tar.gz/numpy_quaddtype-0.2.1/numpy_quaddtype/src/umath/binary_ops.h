#ifndef _QUADDTYPE_BINARY_OPS_H
#define _QUADDTYPE_BINARY_OPS_H

#include <Python.h>

int
init_quad_binary_ops(PyObject *numpy);

#endif