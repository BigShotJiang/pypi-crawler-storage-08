#ifndef _QUADDTYPE_UMATH_H
#define _QUADDTYPE_UMATH_H

#ifdef __cplusplus
extern "C" {
#endif

int
init_quad_umath(void);

#ifdef __cplusplus
}
#endif

#endif