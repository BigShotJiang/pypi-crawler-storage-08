#ifndef _QUADDTYPE_UNARY_PROPS_H
#define _QUADDTYPE_UNARY_PROPS_H

#include <Python.h>

int
init_quad_unary_props(PyObject *numpy);

#endif
