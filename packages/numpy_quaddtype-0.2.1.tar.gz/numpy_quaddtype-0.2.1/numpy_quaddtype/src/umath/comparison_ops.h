#ifndef _QUADDTYPE_COMPARISON_OPS_H
#define _QUADDTYPE_COMPARISON_OPS_H

#include <Python.h>

int
init_quad_comps(PyObject *numpy);

#endif