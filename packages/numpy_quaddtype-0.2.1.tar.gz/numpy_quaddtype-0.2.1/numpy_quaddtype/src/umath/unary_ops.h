#ifndef _QUADDTYPE_UNARY_OPS_H
#define _QUADDTYPE_UNARY_OPS_H

#include <Python.h>

int
init_quad_unary_ops(PyObject *numpy);

#endif
