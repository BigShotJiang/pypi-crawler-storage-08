#ifndef _QUADDTYPE_COMMON_H
#define _QUADDTYPE_COMMON_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    BACKEND_INVALID = -1,
    BACKEND_SLEEF,
    BACKEND_LONGDOUBLE
} QuadBackendType;

#ifdef __cplusplus
}
#endif

#endif