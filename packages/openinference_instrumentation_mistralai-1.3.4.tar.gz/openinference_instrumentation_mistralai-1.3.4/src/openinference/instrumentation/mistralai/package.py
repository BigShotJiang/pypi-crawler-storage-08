_instruments = ("mistralai",)
_supports_metrics = False
