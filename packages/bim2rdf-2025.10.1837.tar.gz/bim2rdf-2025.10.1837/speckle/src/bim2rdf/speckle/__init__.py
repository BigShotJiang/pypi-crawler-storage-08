from bim2rdf.core import __version__


