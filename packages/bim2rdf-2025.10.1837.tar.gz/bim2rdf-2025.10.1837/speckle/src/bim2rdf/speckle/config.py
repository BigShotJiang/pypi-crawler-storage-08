class defaults:
    server = 'app.speckle.systems'
