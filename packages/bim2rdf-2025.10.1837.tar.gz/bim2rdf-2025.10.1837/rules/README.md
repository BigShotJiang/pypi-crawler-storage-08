generic rules engine

this can be kept quite 'pure'.
