import pyprojroot 
root = project_root_dir = project_root = root_dir = pyprojroot.find_root(pyprojroot.has_file('.here'))
