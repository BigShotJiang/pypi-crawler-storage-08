from .tasks.config import *

if __name__ == '__main__':
    import fire
    fire.Fire(config)