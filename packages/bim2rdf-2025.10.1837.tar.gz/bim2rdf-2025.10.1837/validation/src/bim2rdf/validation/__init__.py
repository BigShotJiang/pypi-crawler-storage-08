from pathlib import Path
included_dir = Path(__file__).parent / 'queries'