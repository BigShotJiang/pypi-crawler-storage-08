Installation: `pip install git+https://github.com/placesHQ/payd`
