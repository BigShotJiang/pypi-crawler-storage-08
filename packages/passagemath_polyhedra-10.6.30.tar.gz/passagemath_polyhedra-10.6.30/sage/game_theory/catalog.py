# sage_setup: distribution = sagemath-polyhedra
r"""
Catalog Of Games
"""

from . import catalog_normal_form_games as normal_form_games
