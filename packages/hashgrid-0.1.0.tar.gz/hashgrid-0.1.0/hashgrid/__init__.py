"""
Hashgrid package.

A simple Python package for hashgrid functionality.
"""

__version__ = "0.1.0"
__author__ = "Lucian Bicsi"
__email__ = "lucian@hashgrid.ai"
