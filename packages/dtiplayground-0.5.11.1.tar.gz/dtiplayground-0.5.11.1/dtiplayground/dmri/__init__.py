
class DMRIXInput(object):  ## standard data
  def __init__(*args,**kwargs):
    self.inputs = []
    pass


class DMRIPlayground(object):
  def __init__(*args,**kwargs):
    pass


  def initialize(self):
    pass

  def preprocess(self):
    pass

  def process(self):
    pass

  def postprocess(self):
    pass