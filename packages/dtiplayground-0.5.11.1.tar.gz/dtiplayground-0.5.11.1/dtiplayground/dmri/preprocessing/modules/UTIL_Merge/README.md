### UTIL_Merge

##### Introduction

UTIL_Merge will merge 2 images to one image

##### Protocol Parameters

- TestParam is a string parameter with a default value of null, This is the Test parameter


##### Examples


##### Author(s)

