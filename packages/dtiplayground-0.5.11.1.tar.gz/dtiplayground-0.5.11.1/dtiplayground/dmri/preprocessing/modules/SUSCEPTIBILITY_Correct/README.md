### SUSCEPTIBILITY_Correct

##### Introduction

SUSCEPTIBILITY_Correct.py will correct all the susceptiblity artefacts due to the local magnetical field in the diffusion images by using the FSL's method

##### Protocol Parameters

- phaseEncodingAxis is a list of axis index of phase encoding, its default value is 1 

- phaseEncodingValue is a float, its default value is 0.0924, it characterizes the phase encoding value

- configurationFilePath is a string with the default value of $CONFIG_DIR/parameters/fsl/fsl_regb02b0.cnf, it is the file path of the FSL topup configuration 

##### Examples


##### Author(s)

