import dtiplayground.dmri.common.module as module

DTIPrepModule = module.DTIPrepModule
