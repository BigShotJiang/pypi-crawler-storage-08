### MANUAL_Exclude

##### Introduction
MANUAL_Exclude.py will help to exclude weird, false gradients manually from the diffusion images

##### Protocol Parameters

- gradientsToExclude is an object-array, it will exclude all the gradients which are in the list from the image. It's default value is an empty list


##### Examples


##### Author(s)

