### QC_Report

##### Introduction

QC_Report will generate a report of the Quality Control treatment

##### Protocol Parameters

- generatePDF is a boolean parameter that indicates if the PDF report will be generated

- generateCSV is a boolean parameter that indicates if the CSV report will be generated


##### Examples


##### Author(s)


