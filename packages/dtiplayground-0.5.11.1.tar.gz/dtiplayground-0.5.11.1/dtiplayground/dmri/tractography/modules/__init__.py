import dtiplayground.dmri.common.module as module

DTITractographyModule = module.DTIPlaygroundModule
