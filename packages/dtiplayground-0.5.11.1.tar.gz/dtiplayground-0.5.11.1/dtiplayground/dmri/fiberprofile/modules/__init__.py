import dtiplayground.dmri.common.module as module

DTIFiberProfileModule = module.DTIPlaygroundModule
