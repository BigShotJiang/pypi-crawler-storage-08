"""fal.ai MCP server powered by MCP."""

from .server import get_server, run_server

__all__ = ["get_server", "run_server"]
