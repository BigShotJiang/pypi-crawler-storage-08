# SPDX-License-Identifier: MPL-2.0
# Copyright (c) 2025 Daniel Schmidt

import nac_validate.cli.main

if __name__ == "__main__":
    nac_validate.cli.main.app()
