"""Version information for PolicyStack CLI."""

__version__ = "0.1.0"
