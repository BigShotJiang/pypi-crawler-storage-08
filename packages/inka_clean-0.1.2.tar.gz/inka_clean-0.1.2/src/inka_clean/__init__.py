"""inka-clean: Remove inka2 metadata from markdown files."""

__version__ = "0.1.2"
