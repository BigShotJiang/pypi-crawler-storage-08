"""Standard SEG-Y field definitions."""
