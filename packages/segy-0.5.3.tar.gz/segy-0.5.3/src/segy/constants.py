"""Constant values used in SEG_Y."""

REV1_BASE16 = 0x01_00  # hex -> int = 256
