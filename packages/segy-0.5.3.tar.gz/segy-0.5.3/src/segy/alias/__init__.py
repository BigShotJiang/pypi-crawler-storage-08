"""Module to support aliases in header field names."""
