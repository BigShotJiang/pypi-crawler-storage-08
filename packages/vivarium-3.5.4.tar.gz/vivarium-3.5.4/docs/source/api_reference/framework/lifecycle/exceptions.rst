.. automodule:: vivarium.framework.lifecycle.exceptions
