.. automodule:: vivarium.framework.lifecycle.manager
