.. automodule:: vivarium.framework.lifecycle.entities
