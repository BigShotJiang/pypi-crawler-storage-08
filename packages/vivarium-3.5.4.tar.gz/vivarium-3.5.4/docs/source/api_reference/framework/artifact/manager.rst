.. automodule:: vivarium.framework.artifact.manager
