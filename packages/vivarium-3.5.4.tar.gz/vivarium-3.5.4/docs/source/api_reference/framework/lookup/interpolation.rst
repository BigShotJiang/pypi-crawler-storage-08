.. automodule:: vivarium.framework.lookup.interpolation
