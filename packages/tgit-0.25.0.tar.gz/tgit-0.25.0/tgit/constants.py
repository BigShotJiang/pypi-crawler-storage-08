"""Global constants used across the TGIT project."""

DEFAULT_MODEL = "gpt-5-mini"
REASONING_MODEL_HINTS = ("-reasoning", "o1", "o3", "gpt-5")
