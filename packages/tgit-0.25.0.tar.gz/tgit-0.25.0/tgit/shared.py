from tgit.types import TGitSettings
from tgit.utils import load_settings

settings: TGitSettings = load_settings()
