from __future__ import annotations

from textualicious.log_widget.widget_handler import WidgetHandler
from textualicious.log_widget.log_widget import LoggingWidget

__all__ = ["LoggingWidget", "WidgetHandler"]
