.. role:: hidden
    :class: hidden-section

gpytorch.Module
===================================

.. currentmodule:: gpytorch.Module


.. autoclass:: gpytorch.Module
   :members:
