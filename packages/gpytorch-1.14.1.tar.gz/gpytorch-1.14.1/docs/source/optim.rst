.. role:: hidden
    :class: hidden-section

gpytorch.optim
===================================

.. automodule:: gpytorch.optim
.. currentmodule:: gpytorch.optim


NGD
----------------

.. autoclass:: NGD
   :members:
