# Best Dev Utils

A package with useful utilities for Python developers.

## Установка

```bash
pip install best_dev_utilsssss