## aiSSEMBLE&trade; Foundation Core Python

[![PyPI](https://img.shields.io/pypi/v/aissemble-foundation-core-python?logo=python&logoColor=gold)](https://pypi.org/project/aissemble-foundation-core-python/)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/aissemble-foundation-core-python?logo=python&logoColor=gold)
![PyPI - Wheel](https://img.shields.io/pypi/wheel/aissemble-foundation-core-python?logo=python&logoColor=gold)

This package includes authorization and authentication for Python based applications as well as code for metadata