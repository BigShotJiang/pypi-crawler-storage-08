###
# #%L
# aiSSEMBLE Foundation::aiSSEMBLE Core (Python)
# %%
# Copyright (C) 2021 Booz Allen
# %%
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# #L%
###
from krausening.properties import PropertyManager


class MessagingConfig:
    """
    Configurations for messaging connections
    """

    def __init__(self) -> None:
        self.properties = PropertyManager.get_instance().get_properties(
            "messaging.properties"
        )

    def server(self) -> str:
        """
        Server address
        """
        return self.properties.getProperty("server", "kafka-cluster:9093")

    def metadata_topic(self) -> str:
        """
        Topic for metadata
        """
        return self.properties.getProperty("metadata_topic", "metadata-ingest")
