"""Configuration module for Arbitrium Framework."""

from .loader import Config

__all__ = ["Config"]
