.. contributing:

.. include:: ../CONTRIBUTING.rst
