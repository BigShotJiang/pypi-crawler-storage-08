from .imgproxy import ImgProxy  # noqa:F401
