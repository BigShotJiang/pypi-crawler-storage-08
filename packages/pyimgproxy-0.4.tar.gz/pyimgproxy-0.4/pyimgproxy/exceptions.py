class ConfigurationError(Exception):
    """pyimgproxy is improperly configured"""
