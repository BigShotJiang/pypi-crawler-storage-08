# pyimgproxy

Python library for [imgproxy](https://imgproxy.net/).


## Installation

Using [pip](https://pip.pypa.io/):

```console
$ pip install pyimgproxy
```
