"""High-level type resolution services."""

from .type_service import UnifiedTypeService

__all__ = ["UnifiedTypeService"]
