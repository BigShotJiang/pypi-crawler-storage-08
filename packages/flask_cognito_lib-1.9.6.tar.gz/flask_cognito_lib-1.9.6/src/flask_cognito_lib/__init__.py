__version__ = "1.9.6"

from .plugin import CognitoAuth

__all__ = ["CognitoAuth"]
