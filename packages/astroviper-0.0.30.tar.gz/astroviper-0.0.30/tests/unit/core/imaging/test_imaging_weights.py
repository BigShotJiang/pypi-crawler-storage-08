from astroviper.core.imaging.calculate_imaging_weights import calculate_imaging_weights
from astroviper.core.imaging.imaging_weighting.briggs_weighting import (
    calculate_briggs_params,
)


def test_calculate_briggs_params():
    pass


if __name__ == "__main__":
    test_calculate_briggs_params()
