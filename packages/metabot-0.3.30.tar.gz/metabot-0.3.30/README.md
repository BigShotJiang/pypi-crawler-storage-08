# metabot
Modularized, multi-account bot.

## Quickstart
```
python3 -m venv mymetabot
cd mymetabot
source bin/activate
pip install metabot
metabot
```

## Plugins
- [Google Calendar loader](https://pypi.org/project/metabot.calendars.google/): `pip install metabot.calendars.google`
