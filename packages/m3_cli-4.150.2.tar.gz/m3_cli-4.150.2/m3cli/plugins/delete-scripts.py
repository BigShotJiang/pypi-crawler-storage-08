"""
The custom logic for the command m3 delete-scripts.
This logic is created to convert parameters from the Human readable format to
appropriate for M3 SDK API request.
"""


def create_custom_request(request):
    return request


def create_custom_response(request, response):
    return response
