from geo_skeletons import GriddedSkeleton, PointSkeleton


def test_initial():
    poitns = PointSkeleton(x=0, y=0)
