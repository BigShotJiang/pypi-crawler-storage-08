"""
The core utilities of `hojichar`.
"""
