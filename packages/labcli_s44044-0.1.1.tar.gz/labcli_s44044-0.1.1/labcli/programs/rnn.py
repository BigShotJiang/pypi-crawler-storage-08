def rnn_demo():
    print('RNN placeholder - demo only')

if __name__ == '__main__':
    rnn_demo()

