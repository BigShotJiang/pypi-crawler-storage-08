def hello_world(name: str = "world") -> str:
    """返回一个问候字符串。"""
    return f"Hello, {name}!"

