from .ml_api import to_platform
from .ml_api import HAS_TORCH

if HAS_TORCH:
    from .interface_torch import TorchLayer
