from tequila.hamiltonian.qubit_hamiltonian import PauliString, QubitHamiltonian
from tequila.hamiltonian import paulis
