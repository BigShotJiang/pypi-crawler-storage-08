# zap-cdk

Create zap automation yaml using the awscdk constructs

# Introduction

This is in {{draft}} mode as there is plenty things to fix but i wanted to get the ball rolling.

# WATCH-THIS-SPACE

Now added nuget
