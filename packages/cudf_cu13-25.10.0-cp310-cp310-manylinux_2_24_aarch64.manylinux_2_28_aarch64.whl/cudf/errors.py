# Copyright (c) 2020-2023, NVIDIA CORPORATION.


class UnsupportedCUDAError(Exception):
    pass


class MixedTypeError(TypeError):
    pass
