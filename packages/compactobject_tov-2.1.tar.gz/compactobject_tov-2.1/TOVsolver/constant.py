c = 3e10
G = 6.67428e-8
Msun = 1.989e33
m_w = 3.96544
m_rho = 3.86662
dyncm2_to_MeVfm3 = 1./(1.6022e33)
gcm3_to_MeVfm3 = 1./(1.7827e12)
oneoverfm_MeV = 197.33