from yaml import YAMLError
class EmptyYAMLError(YAMLError):
    pass