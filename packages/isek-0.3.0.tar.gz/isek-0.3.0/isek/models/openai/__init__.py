from isek.models.openai.openai import OpenAIModel

__all__ = [
    "OpenAIModel",
]
