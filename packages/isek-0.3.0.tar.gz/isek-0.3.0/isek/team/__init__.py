from .isek_team import IsekTeam

__all__ = [
    "IsekTeam",
]

__version__ = "1.0.0"
