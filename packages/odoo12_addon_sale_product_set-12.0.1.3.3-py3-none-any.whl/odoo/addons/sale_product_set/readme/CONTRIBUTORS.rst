* Clovis Nzouendjou <clovis@anybox.fr>
* Pierre Verkest <pverkest@anybox.fr>
* Denis Leemann <denis.leemann@camptocamp.com>
* Simone Orsi <simone.orsi@camptocamp.com>
* Souheil Bejaoui <souheil.bejaoui@acsone.eu>
* Adria Gil Sorribes <adria.gil@eficent.com>
