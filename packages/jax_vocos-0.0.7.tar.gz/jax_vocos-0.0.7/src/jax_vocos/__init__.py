from .infer import load_model
from .models import Vocos
__version__ = '0.0.7'