"""
SEED Platform (TM), Copyright (c) Alliance for Sustainable Energy, LLC, and other contributors.
See also https://github.com/SEED-platform/building-data-utilities/blob/main/LICENSE.md
"""

import warnings

warnings.warn(
    ("Importing 'building_data_utilities' is deprecated and will be removed in a future release."), DeprecationWarning, stacklevel=2
)
