import os
import json
import re
from pathlib import Path

import requests
import typer

app = typer.Typer(
    add_completion=False,
    help="Scaffold prism-mockserver service folders from an OpenAPI URL.",
)

SANITISE_RE = re.compile(r"[^a-zA-Z0-9_-]")


def _sanitise_service(name: str) -> str:
    return SANITISE_RE.sub("", name.strip())


def _fail(msg: str, code: int = 1) -> None:
    typer.secho(msg, fg=typer.colors.RED, err=True)
    raise typer.Exit(code)


@app.command()
def main(
    service: str = typer.Argument(
        ..., help="Service folder name under prism/, e.g. 'some-new-service'"
    ),
    openapi_url: str = typer.Argument(..., help="URL to fetch openapi.json from"),
    root: Path = typer.Option(
        "prism", "--root", "-r", help="Root directory for prism services"
    ),
    force: bool = typer.Option(
        False, "--force", "-f", help="Overwrite existing openapi.base.json if present"
    ),
    timeout: float = typer.Option(20.0, "--timeout", help="HTTP timeout (seconds)"),
    create_overlay_hint: bool = typer.Option(
        True, "--overlay-hint/--no-overlay-hint", help="Create overlays/README.md"
    ),
    port: int = typer.Option(4010, "--port", "-p", help="Mock server port"),
):
    """
    Create prism/<service>/ structure and download openapi.base.json from <openapi_url>.
    """
    trimmed = service.strip()
    sanitised = _sanitise_service(trimmed)
    if not trimmed:
        _fail("Service name cannot be empty.")
    if not sanitised:
        _fail(
            "Service name is invalid after sanitisation; allowed characters: a-z A-Z 0-9 _ -."
        )
    if sanitised != trimmed:
        _fail(
            f"Service name contains invalid characters: '{service}'. Try: '{sanitised}'"
        )

    svc_dir = root / sanitised
    base_path = svc_dir / "openapi.base.json"
    overlays_dir = svc_dir / "overlays"

    # Create directories
    overlays_dir.mkdir(parents=True, exist_ok=True)

    # Fetch spec
    typer.secho(f"[get] {openapi_url}", fg=typer.colors.CYAN)
    try:
        resp = requests.get(
            openapi_url,
            timeout=timeout,
            headers={"User-Agent": "create-prism-mockserver/1.0"},
        )
        resp.raise_for_status()
    except requests.RequestException as e:
        _fail(f"Failed to download: {e}")

    # Validate JSON
    try:
        _ = resp.json()
    except json.JSONDecodeError as e:
        _fail(f"Downloaded content is not valid JSON: {e}")

    # Write file
    if base_path.exists() and not force:
        _fail(
            f"{base_path.as_posix()} already exists. Use --force to overwrite.", code=2
        )

    base_path.write_bytes(resp.content)
    typer.secho(f"[write] {base_path.as_posix()}", fg=typer.colors.GREEN)

    # Overlay hint
    if create_overlay_hint:
        hint = overlays_dir / "README.md"
        if not hint.exists():
            hint.write_text(
                "Place overlay fragments here (e.g. openapi.health.json).\n"
                "These patch openapi.base.json without being lost on regeneration.\n",
                encoding="utf-8",
            )
            typer.secho(f"[hint] {hint.as_posix()}", fg=typer.colors.BLUE)

    # POSIX-style relative path for docker-compose (always forward slashes)
    rel_path_posix = Path(os.path.relpath(svc_dir, Path.cwd())).as_posix()
    if not rel_path_posix.startswith(("./", "../", "/")):
        rel_path_posix = f"./{rel_path_posix}"
    abs_path = svc_dir.resolve()
    host_path = str(abs_path)  # keep native separators for Windows

    typer.echo("")
    typer.secho("Done. Next steps:", fg=typer.colors.YELLOW)
    typer.echo(f"  - Add overlay fragments under {overlays_dir.as_posix()}")
    typer.echo(f"  - Run your prism-mockserver container mounting {host_path}")
    typer.echo("  - Example docker run (absolute host path):")
    typer.echo(
        f"docker run --rm -e SERVICE={sanitised} -e SERVICE_PORT={port} "
        f'-v "{abs_path}:/app/prism/{sanitised}" -p {port}:{port} mattcoulter7/prism-mockserver:latest'
    )

    # docker-compose service snippet (uses POSIX-style relative host path)
    typer.echo("")
    typer.secho("docker-compose service:", fg=typer.colors.CYAN)

    compose_yaml = f"""services:
  {sanitised}-mock:
    image: mattcoulter7/prism-mockserver:latest
    environment:
      SERVICE: {sanitised}
      SERVICE_PORT: {port}
    volumes:
      - "{rel_path_posix}:/app/prism/{sanitised}"
    ports:
      - "{port}:{port}"
    restart: unless-stopped
    container_name: {sanitised}-mock
"""
    typer.echo(compose_yaml)


if __name__ == "__main__":
    app()
