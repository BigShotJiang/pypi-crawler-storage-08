"""Georeferencer package for achieving subpixel georeferencing accuracy and related utilities."""
