"""Function used by :mod:`urnc.convert` for generating student versions of notebooks"""
