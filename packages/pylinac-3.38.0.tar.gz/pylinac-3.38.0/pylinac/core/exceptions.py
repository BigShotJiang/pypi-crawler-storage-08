class NotAnalyzed(ValueError):
    pass
