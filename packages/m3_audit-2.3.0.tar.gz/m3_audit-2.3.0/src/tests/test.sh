#!/bin/sh
python ./prepare_env.py
python ./manage.py test
