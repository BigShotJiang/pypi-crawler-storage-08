#coding:utf-8
'''
Пакет тестов для Платформы М3.

Тесты запускаются командой

* все тесты: 
  python manage.py test
  
* тесты конкретного приложения: 
  python manage.py test tests.data.caching_tests

* тесты нескольких конкретных приложений:
  python manage.py test tests.data.caching_tests tests.data.mie_tests
'''

