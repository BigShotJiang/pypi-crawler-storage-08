#coding:utf-8
'''
Created on 06.09.2011

@author: akvarats
'''

from __future__ import absolute_import
import json

from django.test import TestCase

class SomeTests(TestCase):
    '''
    Тесты для источников данных
    '''
    def test1(self):   
        pass
