#coding:utf-8

__version__ = '1.2dev'
__appname__ = u'Аудит операций в прикладной системе'

__require__ = {
}
