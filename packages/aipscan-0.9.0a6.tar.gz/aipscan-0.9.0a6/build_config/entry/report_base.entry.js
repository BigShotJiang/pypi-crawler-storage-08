import $ from "jquery";

window.$ = window.jQuery = $;

import "/AIPscan/static/js/report.js";
