Extends Account Financial Risk to manage payments returns.

If any limit is exceed the partner gets forbidden to confirm sale
orders.
