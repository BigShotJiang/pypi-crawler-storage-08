To use this module, you need to:

1.  Go to *Customers \> Financial Risk*
2.  Set limits and choose options to compute in credit limit.
3.  Create an invoice and pay it.
4.  Create a payment return.
5.  Go to *Invoicing/Accounting \> Customers \> Invoices* and create new
    customer invoices.
6.  Test the restriction trying to create an invoice for the partner for
    an amount higher of the limit you have set.
