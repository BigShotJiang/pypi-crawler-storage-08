---
myst:
  html_meta:
    "description": "collective.transmute CLI reference"
    "property=og:description": "collective.transmute CLI reference"
    "property=og:title": "collective.transmute CLI reference"
    "keywords": "Plone, collective.transmute, CLI, reference"
---

# `collective.transmute.cli`

```{eval-rst}
.. automodule:: collective.transmute.cli
    :members:
    :private-members:

.. autofunction:: collective.transmute.cli.main
```
