---
myst:
  html_meta:
    "description": "collective.transmute layout API reference"
    "property=og:description": "collective.transmute layout API reference"
    "property=og:title": "collective.transmute layout API reference"
    "keywords": "Plone, collective.transmute, layout, API, reference"
---

# `collective.transmute.layout`

```{eval-rst}
.. automodule:: collective.transmute.layout
    :members:
    :private-members:
```
