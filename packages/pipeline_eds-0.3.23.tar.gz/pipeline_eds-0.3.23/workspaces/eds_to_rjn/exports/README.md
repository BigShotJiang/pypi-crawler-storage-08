# Exports: export_eds_points_all.txt
Among other future possibilities, the export_eds_points_all.txt is stored here by the pipeline.api.eds demo_eds_save_point_export() function.
The point export can be called like this:
```
poetry run python -m pipeline.api.eds demo-points-export
```
The export_eds_points_all.txt file is registered in the .gitignore for security.
