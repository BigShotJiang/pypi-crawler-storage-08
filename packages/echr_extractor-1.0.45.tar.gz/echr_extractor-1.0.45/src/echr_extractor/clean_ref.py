'''
This module contains the list of patterns for reference lookup in metadata
'''

clean_pattern = ['EUR. COURT H.R.',
                 'JUDGMENT OF.*',
                 ' DU.*'
                 ]
