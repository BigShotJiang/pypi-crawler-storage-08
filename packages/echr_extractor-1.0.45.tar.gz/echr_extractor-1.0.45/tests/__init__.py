"""Tests package for ECHR extractor."""
