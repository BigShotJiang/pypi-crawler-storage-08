"""
Agents Upstream - AI-powered research analysis system for product discovery.
"""

__version__ = "1.4.0"
__author__ = "Agents Upstream Contributors"
__license__ = "MIT"

