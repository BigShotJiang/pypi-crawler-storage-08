---
version: "1.0.0"
last_updated: "2025-09-02"
author: "Marcelus Fernandes"
template_type: "journey_mapping"
used_by: ["agent-3-asis-journey-mapper.md"]
purpose: "Structure As-Is journey mapping with stages, tools, pain points, and opportunities"
---

# Journey Mapping Template

## Stage Overview
- **Stage Name:**
- **Objective:**

## Tools Involved
- **Tool 1:** Description

## Pain Points
- **Pain Point 1:** Description

## Needs
- **Need 1:** Description

## Opportunities
- **Opportunity 1:** Description
