# 安装
运行build.bat, 生成dist文件夹，然后运行upload.bat, 上传到pypi