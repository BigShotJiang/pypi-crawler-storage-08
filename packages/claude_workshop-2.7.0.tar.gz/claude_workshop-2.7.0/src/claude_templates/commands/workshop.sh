#!/bin/bash

# Workshop slash command wrapper
# Usage: /workshop <subcommand> [args...]

workshop "$@"
