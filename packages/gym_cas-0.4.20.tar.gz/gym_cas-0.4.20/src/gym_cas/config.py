# from spb.defaults import cfg


def _configure_spb():
    pass
    # cfg["matplotlib"]["axis_center"] = "auto"
