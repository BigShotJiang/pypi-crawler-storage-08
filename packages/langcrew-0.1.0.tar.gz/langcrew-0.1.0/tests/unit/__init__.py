"""
Unit tests for LangCrew components.

These tests focus on testing individual components in isolation,
using mocks and stubs for external dependencies.
"""
