"""
Context package unit tests.

This module contains comprehensive unit tests for the langcrew.context package,
including configuration management, hooks, compression tools, and context building.
"""