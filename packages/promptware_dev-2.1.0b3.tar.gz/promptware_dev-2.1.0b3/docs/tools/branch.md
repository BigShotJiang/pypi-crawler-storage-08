# Branch Tool

Select a branch based on value/cases mapping.
