# Conditional Tool

Evaluate simple conditions (==, !=, regex).
