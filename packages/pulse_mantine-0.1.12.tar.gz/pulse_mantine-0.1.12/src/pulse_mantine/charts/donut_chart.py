from typing import Optional
import pulse as ps


@ps.react_component("DonutChart", "@mantine/charts")
def DonutChart(key: Optional[str] = None, **props): ...

