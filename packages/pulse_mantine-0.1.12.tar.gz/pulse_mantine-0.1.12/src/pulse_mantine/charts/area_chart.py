from typing import Optional
import pulse as ps


@ps.react_component("AreaChart", "@mantine/charts")
def AreaChart(key: Optional[str] = None, **props): ...

