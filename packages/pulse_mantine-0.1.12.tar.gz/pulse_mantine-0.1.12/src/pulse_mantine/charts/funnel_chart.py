from typing import Optional
import pulse as ps


@ps.react_component("FunnelChart", "@mantine/charts")
def FunnelChart(key: Optional[str] = None, **props): ...

