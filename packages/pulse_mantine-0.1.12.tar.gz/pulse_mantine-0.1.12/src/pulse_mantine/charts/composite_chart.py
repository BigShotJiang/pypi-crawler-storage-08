from typing import Optional
import pulse as ps


@ps.react_component("CompositeChart", "@mantine/charts")
def CompositeChart(key: Optional[str] = None, **props): ...

