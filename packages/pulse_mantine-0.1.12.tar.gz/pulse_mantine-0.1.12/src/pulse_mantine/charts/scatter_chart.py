from typing import Optional
import pulse as ps


@ps.react_component("ScatterChart", "@mantine/charts")
def ScatterChart(key: Optional[str] = None, **props): ...

