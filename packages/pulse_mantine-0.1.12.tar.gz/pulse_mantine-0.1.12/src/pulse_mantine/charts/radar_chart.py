from typing import Optional
import pulse as ps


@ps.react_component("RadarChart", "@mantine/charts")
def RadarChart(key: Optional[str] = None, **props): ...

