from typing import Optional
import pulse as ps


@ps.react_component("RadialBarChart", "@mantine/charts")
def RadialBarChart(key: Optional[str] = None, **props): ...

