from typing import Optional
import pulse as ps


@ps.react_component("Sparkline", "@mantine/charts")
def Sparkline(key: Optional[str] = None, **props): ...

