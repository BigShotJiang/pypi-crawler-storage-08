from typing import Optional
import pulse as ps


@ps.react_component("Transition", "@mantine/core")
def Transition(*children: ps.Child, key: Optional[str] = None, **props): ...

