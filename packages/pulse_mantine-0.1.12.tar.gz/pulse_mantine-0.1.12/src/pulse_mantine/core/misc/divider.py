from typing import Optional
import pulse as ps


@ps.react_component("Divider", "@mantine/core")
def Divider(key: Optional[str] = None, **props): ...

