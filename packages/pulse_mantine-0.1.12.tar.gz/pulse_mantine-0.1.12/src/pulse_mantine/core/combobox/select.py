from typing import Optional
import pulse as ps


@ps.react_component("Select", "pulse-mantine")
def Select(key: Optional[str] = None, **props): ...
