from typing import Optional
import pulse as ps


@ps.react_component("TagsInput", "@mantine/core")
def TagsInput(key: Optional[str] = None, **props): ...

