from typing import Optional
import pulse as ps


@ps.react_component("Code", "@mantine/core")
def Code(*children: ps.Child, key: Optional[str] = None, **props): ...

