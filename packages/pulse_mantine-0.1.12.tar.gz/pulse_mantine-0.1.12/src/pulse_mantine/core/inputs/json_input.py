from typing import Optional
import pulse as ps


@ps.react_component("JsonInput", "pulse-mantine")
def JsonInput(key: Optional[str] = None, **props): ...
