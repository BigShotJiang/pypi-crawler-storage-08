from typing import Optional
import pulse as ps


@ps.react_component("ColorPicker", "pulse-mantine")
def ColorPicker(key: Optional[str] = None, **props): ...
