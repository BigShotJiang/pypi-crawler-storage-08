from typing import Optional
import pulse as ps


@ps.react_component("ColorInput", "pulse-mantine")
def ColorInput(key: Optional[str] = None, **props): ...
