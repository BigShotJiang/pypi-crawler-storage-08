from typing import Optional
import pulse as ps


@ps.react_component("PinInput", "pulse-mantine")
def PinInput(key: Optional[str] = None, **props): ...
