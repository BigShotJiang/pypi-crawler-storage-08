from typing import Optional
import pulse as ps


@ps.react_component("FileInput", "pulse-mantine")
def FileInput(*children: ps.Child, key: Optional[str] = None, **props): ...
