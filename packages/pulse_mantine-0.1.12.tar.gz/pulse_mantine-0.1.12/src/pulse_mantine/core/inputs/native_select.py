from typing import Optional
import pulse as ps


@ps.react_component("NativeSelect", "pulse-mantine")
def NativeSelect(*children: ps.Child, key: Optional[str] = None, **props): ...
