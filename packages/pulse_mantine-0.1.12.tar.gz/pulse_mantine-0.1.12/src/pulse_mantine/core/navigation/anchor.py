from typing import Optional
import pulse as ps


@ps.react_component("Anchor", "@mantine/core")
def Anchor(*children: ps.Child, key: Optional[str] = None, **props): ...

