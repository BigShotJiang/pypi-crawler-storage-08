from typing import Optional
import pulse as ps


@ps.react_component("ColorSwatch", "@mantine/core")
def ColorSwatch(*children: ps.Child, key: Optional[str] = None, **props): ...

