from typing import Optional
import pulse as ps


@ps.react_component("NumberFormatter", "@mantine/core")
def NumberFormatter(key: Optional[str] = None, **props): ...

