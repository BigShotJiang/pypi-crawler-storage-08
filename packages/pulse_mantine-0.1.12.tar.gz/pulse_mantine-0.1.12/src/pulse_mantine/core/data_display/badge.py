from typing import Optional
import pulse as ps


@ps.react_component("Badge", "@mantine/core")
def Badge(*children: ps.Child, key: Optional[str] = None, **props): ...

