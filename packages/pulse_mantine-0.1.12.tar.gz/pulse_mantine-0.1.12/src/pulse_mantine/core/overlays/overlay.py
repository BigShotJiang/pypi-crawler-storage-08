from typing import Optional
import pulse as ps


@ps.react_component("Overlay", "@mantine/core")
def Overlay(key: Optional[str] = None, **props): ...

