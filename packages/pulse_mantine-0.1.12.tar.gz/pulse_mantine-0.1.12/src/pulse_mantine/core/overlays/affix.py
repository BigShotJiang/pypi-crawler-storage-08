from typing import Optional
import pulse as ps


@ps.react_component("Affix", "@mantine/core")
def Affix(*children: ps.Child, key: Optional[str] = None, **props): ...

