from typing import Optional
import pulse as ps


@ps.react_component("CloseButton", "@mantine/core")
def CloseButton(key: Optional[str] = None, **props): ...

