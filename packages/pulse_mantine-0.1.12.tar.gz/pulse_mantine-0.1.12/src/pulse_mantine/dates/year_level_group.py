from typing import Optional
import pulse as ps


@ps.react_component("YearLevelGroup", "pulse-mantine")
def YearLevelGroup(key: Optional[str] = None, **props): ...

