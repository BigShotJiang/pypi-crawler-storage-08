from typing import Optional
import pulse as ps


@ps.react_component("DecadeLevel", "pulse-mantine")
def DecadeLevel(key: Optional[str] = None, **props): ...

