from typing import Optional
import pulse as ps


@ps.react_component("PickerControl", "pulse-mantine")
def PickerControl(*children: ps.Child, key: Optional[str] = None, **props): ...

