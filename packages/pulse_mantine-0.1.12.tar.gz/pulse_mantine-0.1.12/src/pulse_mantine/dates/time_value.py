from typing import Optional
import pulse as ps


@ps.react_component("TimeValue", "pulse-mantine")
def TimeValue(key: Optional[str] = None, **props): ...

