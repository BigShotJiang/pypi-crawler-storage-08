from typing import Optional
import pulse as ps


@ps.react_component("MonthLevel", "pulse-mantine")
def MonthLevel(key: Optional[str] = None, **props): ...

