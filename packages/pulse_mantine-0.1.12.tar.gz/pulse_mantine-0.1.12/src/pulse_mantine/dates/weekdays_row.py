from typing import Optional
import pulse as ps


@ps.react_component("WeekdaysRow", "pulse-mantine")
def WeekdaysRow(key: Optional[str] = None, **props): ...

