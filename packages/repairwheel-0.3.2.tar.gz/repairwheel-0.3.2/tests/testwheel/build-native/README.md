I don't have access to a Windows machine, so this package uses `zig cc` to build cross-platform test wheels.

Use it like

```
./build.py --target all --output ..
```

It requires a recent version of `zig`.
