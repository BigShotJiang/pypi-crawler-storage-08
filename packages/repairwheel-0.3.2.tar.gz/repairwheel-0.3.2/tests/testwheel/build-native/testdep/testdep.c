#include "testdep.h"

EXPORTED int get_answer() {
    return 42;
}
