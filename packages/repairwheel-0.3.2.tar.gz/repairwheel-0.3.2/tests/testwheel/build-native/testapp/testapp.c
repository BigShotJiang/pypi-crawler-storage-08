#import <stdio.h>
#import "testdep.h"

int main() {
    printf("Answer = %d\n", get_answer());
    return 0;
}
