"""A test wheel."""


def get_answer() -> int:
    return 42
