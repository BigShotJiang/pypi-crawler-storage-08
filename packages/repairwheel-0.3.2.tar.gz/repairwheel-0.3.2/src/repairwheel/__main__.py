# SPDX-License-Identifier: MIT
from .repair import main

main()
