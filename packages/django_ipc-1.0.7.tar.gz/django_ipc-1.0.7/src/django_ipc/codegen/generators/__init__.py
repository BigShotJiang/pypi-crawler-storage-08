"""Code generators for different client types."""
