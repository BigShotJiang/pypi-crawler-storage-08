"""TypeScript WebSocket client generator."""

from .generator import TypeScriptWebSocketGenerator

__all__ = ['TypeScriptWebSocketGenerator']
