"""Python WebSocket client generator."""

from .generator import PythonWebSocketGenerator

__all__ = ['PythonWebSocketGenerator']
