


string = """This is for making noise in the code review."""

algo = 20

class Something:
    pass


b = Something()
