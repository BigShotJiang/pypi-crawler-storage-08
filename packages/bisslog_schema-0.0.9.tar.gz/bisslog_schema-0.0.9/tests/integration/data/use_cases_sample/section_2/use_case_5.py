from bisslog import use_case


@use_case
async def use_case_5():
    """Just a use case."""
    print("Hello from use_case_5")
