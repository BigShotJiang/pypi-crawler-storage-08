Resolutions
===========

Free and graded resolutions are tools for commutative algebra and algebraic
geometry.

.. toctree::
   :maxdepth: 1

   sage/homology/free_resolution
   sage/homology/graded_resolution

.. include:: ../footer.txt
