"""
DeltaFQ - 专业的Python量化交易库

Setup configuration for backward compatibility.
All modern configuration is in pyproject.toml.
"""

from setuptools import setup

# 所有配置都在 pyproject.toml 中
# setup.py 仅为了向后兼容
setup()
