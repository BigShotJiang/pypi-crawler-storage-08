"""工具函数模块"""

from deltafq.utils.time import is_trading_day, get_trading_dates

__all__ = ["is_trading_day", "get_trading_dates"]

