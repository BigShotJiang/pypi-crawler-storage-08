"""策略框架模块"""

from deltafq.strategy.base import Strategy

__all__ = ["Strategy"]

