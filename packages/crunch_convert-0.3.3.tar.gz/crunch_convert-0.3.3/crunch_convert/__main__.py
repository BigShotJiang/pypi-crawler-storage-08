from crunch_convert.cli import cli

cli()
