## cdf 

### Improved

- Faster downloading of instances when you run `cdf purge space`. 

## templates

No changes.