class nikil_test_math:
    @staticmethod
    def add(a, b):
        """Add two values."""
        return a + b

    @staticmethod
    def subtract(a, b, c):
        """Subtract three values (a - b - c)."""
        return a - b - c

    @staticmethod
    def multiply(a, b):
        """Multiply two values."""
        return a * b