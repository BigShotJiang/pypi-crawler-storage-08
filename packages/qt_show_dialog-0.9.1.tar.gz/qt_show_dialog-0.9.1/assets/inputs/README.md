# `/assets/inputs` folder
Contains sample inputs for `ShowDialog`.

To be used with the `--inputs-file` argument.

Used by the `inputs.Inputs` class.
