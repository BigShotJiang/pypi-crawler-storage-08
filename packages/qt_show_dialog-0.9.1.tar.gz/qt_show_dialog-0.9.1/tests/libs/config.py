from pathlib import Path

TESTS_ROOT = Path(__file__).parents[1]
TEST_ASSETS_DIR = TESTS_ROOT / 'assets'
