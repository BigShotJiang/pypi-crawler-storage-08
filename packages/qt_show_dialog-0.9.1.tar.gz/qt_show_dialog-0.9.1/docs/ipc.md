# Inter-Process Communication

## Purpose
TODO

## How to use it
### Server
TODO

### Client
TODO
