#ifndef GLOBALS_H
#define GLOBALS_H

namespace LoopCGAL
{
    extern bool verbose; // Declaration of the module-wide verbose flag
    void set_verbose(bool value); // Declaration of the set_verbose function
}

#endif // GLOBALS_H