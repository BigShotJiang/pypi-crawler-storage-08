
Plant Schema
------------

.. raw:: html
        :file: ../_static/plant_schema.html

        
