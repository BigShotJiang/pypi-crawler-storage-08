from .df2tables import *
__version__ = "0.1.7"
__author__ = "Tomasz Slugocki"
__license__ = "MIT"

