from function_tools.general import (
    RunnableObject as EduRunnableObject,
)
