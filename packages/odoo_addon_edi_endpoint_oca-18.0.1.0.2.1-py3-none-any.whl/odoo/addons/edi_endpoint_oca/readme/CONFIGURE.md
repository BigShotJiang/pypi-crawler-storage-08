Go to "EDI -\> Config -\> Endpoints".
