import typing
if typing.TYPE_CHECKING:
	import shoggoth.main as main

app: 'main.ShoggothApp' = None
