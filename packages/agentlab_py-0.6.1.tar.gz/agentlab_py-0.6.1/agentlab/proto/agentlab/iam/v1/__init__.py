"""IAM service v1 protobuf definitions."""
