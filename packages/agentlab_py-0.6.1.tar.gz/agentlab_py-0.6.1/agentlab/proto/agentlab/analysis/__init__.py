"""Analysis service protobuf definitions."""
