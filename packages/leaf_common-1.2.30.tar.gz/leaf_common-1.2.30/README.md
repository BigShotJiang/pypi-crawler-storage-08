Utility code used across various software projects in Cognizant AI Labs (CAIL, nee LEAF).
