APPOINTMENT = "APPOINTMENT"
APPOINTMENT_VIEW = "APPOINTMENT_VIEW"
APPOINTMENT_EXPORT = "APPOINTMENT_EXPORT"

codenames = [
    "edc_appointment.add_appointment",
    "edc_appointment.change_appointment",
    "edc_appointment.view_appointment",
    "edc_appointment.view_historicalappointment",
]
