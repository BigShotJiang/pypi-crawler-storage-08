from edc_form_validators import FormValidator


class AeSusarFormValidator(FormValidator):
    pass
