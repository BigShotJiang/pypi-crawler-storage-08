print("Script is loading...".center(100))
