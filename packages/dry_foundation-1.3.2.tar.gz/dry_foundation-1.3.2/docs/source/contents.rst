.. toctree::
   :maxdepth: 1
   :caption: Contents:

   Home <index>
   API <api/modules>
   Changelog <CHANGELOG>
