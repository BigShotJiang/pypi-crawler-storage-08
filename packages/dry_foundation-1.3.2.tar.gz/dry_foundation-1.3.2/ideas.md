# Ideas

- [ ] Allow GUnicorn options to be passed to the modes/launcher via the configuration file
