"""titiler.application"""

__version__ = "0.24.1"
