"""Volumes command group - manage persistent storage volumes for GPU tasks.

Provides creation, deletion, listing, and bulk operations for volumes used by
GPU tasks.

Command Usage:
    flow volumes SUBCOMMAND [OPTIONS]

Subcommands:
    list        List all volumes with region and interface info
    create      Create a new volume
    delete      Delete a volume by ID or name
    delete-all  Delete multiple volumes

Examples:
    List all volumes:
        $ flow volumes list

    Create a 100GB block volume:
        $ flow volumes create --size 100

    Create a named file storage volume:
        $ flow volumes create --size 50 --name training-data --interface file

    Delete by volume ID:
        $ flow volumes delete vol_abc123def456

    Delete by volume name (exact or partial match):
        $ flow volumes delete training-data
        $ flow volumes delete training  # Works if only one match

    Delete without confirmation:
        $ flow volumes delete training-data --yes

    Delete all volumes (with confirmation):
        $ flow volumes delete-all

    Delete volumes matching pattern:
        $ flow volumes delete-all --pattern "test-*"

    Preview deletion without executing:
        $ flow volumes delete-all --dry-run

Volume properties:
- ID: Unique identifier (e.g., vol_abc123...)
- Name: Optional human-readable name (can be used instead of ID)
- Region: Where the volume is located (must match task region)
- Size: Storage capacity in GB
- Interface: Storage type (block or file)
- Status: Available or attached (with count)
- Created: Timestamp of creation

The commands will:
- Support both volume IDs and names for operations
- Show region constraints for better planning
- Validate size limits per region
- Handle volume lifecycle operations
- Manage volume attachments to tasks

Note:
    Volumes can only be deleted when not attached to running tasks.
    Volumes must be in the same region as the tasks that use them.
    Both volume IDs and names can be used in task configurations.

    Name Resolution:
    - You can use either volume ID (vol_xxx) or volume name in commands
    - Exact name matches are preferred over partial matches
    - If multiple volumes match a name, you'll be prompted to use the ID
    - Partial name matching works if there's only one match
"""

import click
from datetime import datetime

from flow import Flow
from flow.cli.commands.base import BaseCommand, console
from flow.cli.utils.animated_progress import AnimatedEllipsisProgress
from flow.cli.utils.table_styles import (
    add_centered_column,
    add_left_aligned_column,
    add_right_aligned_column,
    create_flow_table,
    wrap_table_in_panel,
)
from flow.cli.utils.terminal_adapter import TerminalAdapter
from flow.cli.utils.theme_manager import theme_manager
from flow.cli.utils.volume_index_cache import VolumeIndexCache
from flow.cli.utils.volume_operations import VolumeOperations
from flow.cli.utils.volume_resolver import get_volume_display_name, resolve_volume_identifier
from flow.errors import AuthenticationError


class VolumesCommand(BaseCommand):
    """Manage storage volumes."""

    @property
    def name(self) -> str:
        return "volumes"

    @property
    def help(self) -> str:
        return "Manage persistent storage volumes - create, list, delete"

    def _build_instance_task_map(self, flow_client: Flow) -> dict[str, tuple[str, str]]:
        """Build mapping of instance_id -> (task_name, task_id).

        Returns empty dict on error to gracefully degrade.
        """
        try:
            # Fetch recent tasks to find volume associations
            tasks = flow_client.list_tasks(limit=500)
            instance_map = {}
            for task in tasks:
                # Map each instance to its task
                for instance_id in task.instances:
                    instance_map[instance_id] = (task.name, task.task_id)
            return instance_map
        except Exception:
            # Graceful degradation - volumes still display without task info
            return {}

    def get_command(self) -> click.Group:
        """Return the volumes command group."""

        # from flow.cli.utils.mode import demo_aware_command

        @click.group(name=self.name, help=self.help, invoke_without_command=True)
        @click.option("--verbose", "-v", is_flag=True, help="Show detailed volume management guide")
        # @demo_aware_command()
        @click.pass_context
        def volumes(ctx, verbose: bool):
            """Manage storage volumes.

            \b
            Examples:
                flow volumes list            # List all volumes
                flow volumes create --size 100  # Create 100GB volume
                flow volumes delete vol-123  # Delete volume

            Use 'flow volumes --verbose' for comprehensive storage guide.
            """
            if verbose:
                console.print("\n[bold]Storage Volume Management:[/bold]\n")
                console.print("Volume types:")
                console.print("  • block - High-performance block storage (default)")
                console.print("  • file  - Shared file storage (NFS-like)\n")

                console.print("Creating volumes:")
                console.print(
                    "  flow volumes create --size 100                # 100GB block volume"
                )
                console.print(
                    "  flow volumes create --size 50 --interface file # 50GB file storage"
                )
                console.print("  flow volumes create --size 200 --name datasets # Named volume")
                console.print("  flow volumes create --size 500 --region us-west-2\n")

                console.print("Listing and filtering:")
                console.print("  flow volumes list                    # All volumes")
                console.print("  flow volumes list --details          # Show task attachments")
                console.print("  flow volumes list | grep available   # Filter by status\n")

                console.print("Deleting volumes:")
                console.print("  flow volumes delete vol_abc123       # By ID")
                console.print("  flow volumes delete training-data    # By name")
                console.print("  flow volumes delete-all --pattern 'test-*'  # Pattern matching")
                console.print("  flow volumes delete-all --dry-run    # Preview deletions\n")

                console.print("Using volumes in tasks:")
                console.print("  # In YAML config:")
                console.print("  volumes:")
                console.print("    - volume_id: vol_abc123")
                console.print("      mount_path: /data")
                console.print("  # Or by name:")
                console.print("    - volume_name: training-data")
                console.print("      mount_path: /datasets\n")

                console.print("Important constraints:")
                console.print("  • Volumes are region-specific")
                console.print("  • Can't delete volumes attached to running tasks")
                console.print("  • Size limits vary by region (check provider docs)")
                console.print("  • File volumes support multiple concurrent attachments\n")

                console.print("Common workflows:")
                console.print("  # Create and use dataset volume")
                console.print("  flow volumes create --size 500 --name imagenet")
                console.print("  flow run train.yaml  # References volume by name")
                console.print("  ")
                console.print("  # Share data between tasks")
                console.print("  flow mount shared-data task1")
                console.print("  flow mount shared-data task2\n")
            # If no subcommand was provided and verbose wasn't requested, provide a gentle hint
            if ctx.invoked_subcommand is None and not verbose:
                console.print(
                    "\n[yellow]No subcommand provided.[/yellow] Try:"
                )
                console.print("  • flow volumes list")
                console.print("  • flow volumes create --size 100")
                console.print("  • flow volumes delete <name-or-id>")
                console.print(
                    "\nFor more details: [accent]flow volumes --help[/accent] or [accent]flow volumes --verbose[/accent]"
                )
                return

        # Add subcommands
        volumes.add_command(self._list_command())
        volumes.add_command(self._create_command())
        volumes.add_command(self._delete_command())
        volumes.add_command(self._delete_all_command())

        # Lightweight alias: `flow volumes mount <vol> <task>` delegates to top-level `flow mount`
        try:
            import click as _click
            from flow.cli.commands.mount import command as _mount_cmd_obj  # type: ignore

            # Get the underlying click command from our BaseCommand wrapper
            mount_click_command = _mount_cmd_obj.get_command()

            @_click.command(name="mount", help="Alias for 'flow mount' – attach a volume to a task")
            @_click.argument("volume_identifier", required=False)
            @_click.argument("task_identifier", required=False)
            @_click.pass_context
            def volumes_mount(ctx, volume_identifier: str | None, task_identifier: str | None):
                # Re-invoke the top-level mount command, relying on its default options
                args: list[str] = []
                if volume_identifier:
                    args.append(volume_identifier)
                if task_identifier:
                    args.append(task_identifier)
                # Use click's command re-entry to preserve option defaults
                try:
                    return mount_click_command.main(args=args, standalone_mode=False)
                except SystemExit as e:  # pragma: no cover - click control flow
                    # Propagate click's intended exit codes in CLI context
                    if e.code not in (0, None):
                        raise
                    return None

            volumes.add_command(volumes_mount)
        except Exception:
            # If mount command is unavailable for any reason, skip alias silently
            pass

        return volumes

    def _list_command(self) -> click.Command:
        @click.command(name="list")
        @click.option("--details", "-d", is_flag=True, help="Show which tasks use each volume")
        @click.option("--region", "region", help="Filter volumes by region (default: all)")
        def volumes_list(details: bool, region: str | None):
            """List all volumes."""
            try:
                flow_client = Flow(auto_init=True)

                with AnimatedEllipsisProgress(console, "Fetching volumes") as progress:
                    # If region filter is requested and provider supports it,
                    # fetch and filter via provider; otherwise filter client-side.
                    volumes = flow_client.list_volumes()
                    if region:
                        try:
                            volumes = [v for v in volumes if getattr(v, "region", None) == region]
                        except Exception:
                            pass

                # Sort by creation time (newest first) for consistent, useful ordering
                try:
                    volumes = sorted(
                        volumes,
                        key=lambda v: getattr(v, "created_at", None) or datetime.min,
                        reverse=True,
                    )
                except Exception:
                    # If sorting fails for any reason, fall back to provider order
                    pass

                if not volumes:
                    console.print("\nNo volumes found.")
                    self.show_next_actions(
                        [
                            "Create a new volume: [accent]flow volumes create --size 100[/accent] [dim]# size in GB[/dim]",
                            "Create a named volume: [accent]flow volumes create --size 50 --name training-data[/accent] [dim]# size in GB[/dim]",
                            "Create file storage: [accent]flow volumes create --size 200 --interface file[/accent] [dim]# size in GB[/dim]",
                        ]
                    )
                    return

                # Build instance-to-task mapping if details requested
                instance_task_map = {}
                if details:
                    with AnimatedEllipsisProgress(
                        console, "Fetching task associations"
                    ) as progress:
                        instance_task_map = self._build_instance_task_map(flow_client)

                # Get terminal width for responsive layout
                terminal_width = TerminalAdapter.get_terminal_width()

                # Create table with Flow standard styling
                table = create_flow_table(
                    show_borders=False,
                    expand=False,
                )  # No borders since we'll wrap in panel

                # Always show core columns: center-align everything except Name
                add_centered_column(table, "#", width=3)

                # Show additional columns based on terminal width
                show_interface = terminal_width >= 80
                show_status = terminal_width >= 90
                show_created = terminal_width >= 100

                # Move Status next to index for quick scanning
                if show_status:
                    add_centered_column(table, "Status", width=14)

                add_left_aligned_column(
                    table,
                    "Name",
                    style=theme_manager.get_color("task.name"),
                    ratio=1,  # Gets remaining space
                    overflow="ellipsis",
                    min_width=20,  # Ensure reasonable minimum
                )
                add_centered_column(
                    table,
                    "Region",
                    style=theme_manager.get_color("accent"),
                    width=15,  # Fixed width for regions like "us-central1-b"
                    overflow="crop",  # Never wrap
                )
                add_centered_column(
                    table,
                    "Size\n(GB)",
                    width=10,  # Enough for header and values like "10000"
                )

                if show_interface:
                    add_centered_column(
                        table,
                        "Interface",
                        style=theme_manager.get_color("muted"),
                        width=9,  # Fixed for "block"/"file"
                    )
                if show_created:
                    add_right_aligned_column(
                        table,
                        "Created",
                        style=theme_manager.get_color("task.time"),
                        width=16,  # Fixed for "2025-07-29 20:32"
                    )

                for idx, volume in enumerate(volumes, start=1):
                    # Format status with color
                    status_color_available = theme_manager.get_color("status.running")
                    status_color_attached = theme_manager.get_color("status.pending")
                    status = f"[{status_color_available}]● available[/{status_color_available}]"
                    task_names = []

                    if hasattr(volume, "attached_to") and volume.attached_to:
                        # Collect task names if details requested
                        if details and instance_task_map:
                            for instance_id in volume.attached_to:
                                if instance_id in instance_task_map:
                                    task_name, _ = instance_task_map[instance_id]
                                    task_names.append(task_name)

                        # Format status based on whether we have task details
                        if task_names and details:
                            # Show task names (limit to 2 for space)
                            task_list = ", ".join(task_names[:2])
                            if len(task_names) > 2:
                                task_list += f" +{len(task_names) - 2}"
                            status = f"[{status_color_attached}]● {task_list}[/{status_color_attached}]"
                        else:
                            status = f"[{status_color_attached}]● attached ({len(volume.attached_to)})[/{status_color_attached}]"

                    # Get interface type
                    interface = getattr(volume, "interface", "block")
                    if hasattr(interface, "value"):
                        interface = interface.value

                    # Use volume ID as name if no name is set
                    display_name = volume.name or volume.volume_id

                    # Build row data based on visible columns in order: #, Status?, Name, Region, Size, Interface?, Created?
                    row_data = [str(idx)]
                    if show_status:
                        row_data.append(status)
                    row_data.append(display_name)
                    row_data.append(volume.region)
                    row_data.append(str(volume.size_gb))

                    if show_interface:
                        row_data.append(interface)
                    if show_created:
                        row_data.append(
                            volume.created_at.strftime("%Y-%m-%d %H:%M")
                            if volume.created_at
                            else "-"
                        )

                    table.add_row(*row_data)

                    # Add detail rows if requested and volume has attachments
                    if details and task_names and terminal_width >= 100:
                        for i, (instance_id, task_name) in enumerate(
                            (inst_id, instance_task_map.get(inst_id, ("Unknown", ""))[0])
                            for inst_id in volume.attached_to
                            if inst_id in instance_task_map
                        ):
                            if i >= 3:  # Limit detail rows
                                remaining = len(volume.attached_to) - 3
                                # Order: #, Status?, Name, Region, Size, Interface?, Created?
                                detail_row = [""]
                                if show_status:
                                    detail_row.append(f"[dim]+{remaining} more[/dim]")
                                detail_row += ["  └─ ...", "", ""]
                                if show_interface:
                                    detail_row.append("")
                                if show_created:
                                    detail_row.append("")
                                table.add_row(*detail_row)
                                break

                            task_id = instance_task_map[instance_id][1]
                            # Order: #, Status?, Name, Region, Size, Interface?, Created?
                            detail_row = [""]
                            if show_status:
                                detail_row.append(f"[dim]{task_id[:8]}[/dim]")
                            detail_row += [f"  └─ {task_name}", "", ""]
                            if show_interface:
                                detail_row.append("")
                            if show_created:
                                detail_row.append("")
                            table.add_row(*detail_row)

                # Save indices for quick reference
                cache = VolumeIndexCache()
                cache.save_indices(volumes)

                # Wrap in panel like flow status does
                panel_title = f"Volumes ({len(volumes)} total)" if not region else f"Volumes [{region}] ({len(volumes)} total)"
                wrap_table_in_panel(table, panel_title, console)

                # Post-table legend and tips (mirrors flow status structure)
                try:
                    dim = theme_manager.get_color("task.time")
                    console.print(
                        f"[{dim}]Legend: available = not attached · attached = in-use (shows task names with --details)[/{dim}]"
                    )
                    console.print(
                        f"[{dim}]Tip: Index shortcuts (1, 1-3; ':1' also works) are valid for 5 minutes after this view.[/{dim}]"
                    )
                    console.print(f"[{dim}]Re-run 'flow volumes list' to refresh indices.[/{dim}]")
                except Exception:
                    pass

                # Show next actions with index support
                volume_count = min(len(volumes), 5)  # Show up to 5 index examples
                index_help = f"1-{volume_count}" if volume_count > 1 else "1"

                self.show_next_actions(
                    [
                        "Create a new volume: [accent]flow volumes create --size 100[/accent] [dim]# size in GB[/dim]",
                        f"Delete a volume: [accent]flow volumes delete <volume-name-or-id>[/accent] or [accent]flow volumes delete {index_help}[/accent]",
                    ]
                )

            except AuthenticationError:
                self.handle_auth_error()
            except Exception as e:
                self.handle_error(e)

        return volumes_list

    def _create_command(self) -> click.Command:
        @click.command(name="create")
        @click.option("--size", "-s", type=int, required=True, help="Volume size in GB")
        @click.option("--name", "-n", help="Optional name for the volume")
        @click.option(
            "--interface",
            "-i",
            type=click.Choice(["block", "file"]),
            default="block",
            help="Storage interface type",
        )
        @click.option("--region", help="Region to create the volume in (overrides default)")
        def volumes_create(size: int, name: str | None, interface: str, region: str | None):
            """Create a new volume."""
            try:
                flow_client = Flow(auto_init=True)

                from flow.cli.utils.step_progress import StepTimeline

                timeline = StepTimeline(console, title="flow volumes", title_animation="auto")
                timeline.start()
                step_suffix = f" in {region}" if region else ""
                step_idx = timeline.add_step(
                    f"Creating {size}GB {interface} volume{step_suffix}", show_bar=False
                )
                timeline.start_step(step_idx)
                try:
                    volume = flow_client.create_volume(size_gb=size, name=name, interface=interface, region=region)
                    timeline.complete_step()
                except Exception as e:
                    # Include request ID in the step failure when available
                    message = str(e)
                    try:
                        req_id = getattr(e, "request_id", None)
                        if req_id:
                            from rich.markup import escape as _escape
                            message = f"{message}\nRequest ID: {_escape(str(req_id))}"
                    except Exception:
                        pass
                    timeline.fail_step(message)
                    timeline.finish()
                    raise
                finally:
                    try:
                        timeline.finish()
                    except Exception:
                        pass

                console.print(
                    f"[green]✓[/green] Volume created: [accent]{volume.volume_id}[/accent]"
                )
                if name:
                    console.print(f"Name: {name}")
                try:
                    if getattr(volume, "region", None):
                        console.print(f"Region: {getattr(volume, 'region')}")
                except Exception:
                    pass

                # Show next actions
                self.show_next_actions(
                    [
                        "List all volumes: [accent]flow volumes list[/accent]",
                        "All sizes are specified in GB (gigabytes)",
                        "Use in task config: Add to YAML under storage.volumes",
                        "Submit task with volume: [accent]flow run task.yaml[/accent]",
                    ]
                )

                # Invalidate and refresh volumes cache after creation
                try:
                    from flow.cli.utils.prefetch import (
                        invalidate_cache_for_current_context,
                        refresh_volumes_cache,
                    )
                    # Also clear index cache so :N mappings refresh next list
                    try:
                        from flow.cli.utils.volume_index_cache import VolumeIndexCache

                        VolumeIndexCache().clear()
                    except Exception:
                        pass

                    invalidate_cache_for_current_context(
                        ["volumes_list"]
                    )  # ensure fresh list on next view
                    import threading

                    threading.Thread(target=refresh_volumes_cache, daemon=True).start()
                except Exception:
                    pass

            except AuthenticationError:
                self.handle_auth_error()
            except Exception as e:
                # Check if provider supports capability discovery
                if "not available" in str(e) or "maximum" in str(e).lower():
                    # Show storage capabilities if available
                    try:
                        caps = (
                            flow_client.provider.get_storage_capabilities()
                            if hasattr(flow_client.provider, "get_storage_capabilities")
                            else None
                        )
                        if caps:
                            console.print("\n[yellow]Available storage options:[/yellow]")
                            for region, cap in caps.items():
                                if cap.get("available", False):
                                    types = ", ".join(cap.get("types", []))
                                    max_gb = cap.get("max_gb", 0)
                                    console.print(
                                        f"  [accent]{region}[/accent]: {types} (up to {max_gb:,}GB)"
                                    )
                    except Exception:
                        pass  # Don't fail if capability discovery fails

                self.handle_error(e)

        return volumes_create

    def _delete_command(self) -> click.Command:
        # Import completion function
        from flow.cli.utils.shell_completion import complete_volume_ids

        @click.command(name="delete")
        @click.argument("volume_identifier", shell_complete=complete_volume_ids)
        @click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
        def volumes_delete(volume_identifier: str, yes: bool):
            """Delete a volume by ID, name, or 'all'.

            \b
            Examples:
                flow volumes delete vol_abc123def456
                flow volumes delete training-data
                flow volumes delete 1
                flow volumes delete all
                flow volumes delete training --yes
            """
            try:
                flow_client = Flow(auto_init=True)

                # Special handling for "all"
                if volume_identifier.lower() == "all":
                    volumes = flow_client.list_volumes()
                    if not volumes:
                        console.print("No volumes found.")
                        return

                    console.print(f"Found {len(volumes)} volume(s) to delete:")
                    for volume in volumes:
                        display_name = get_volume_display_name(volume)
                        console.print(f"  - {display_name}")

                    if not yes:
                        confirm = click.confirm(f"\nDelete all {len(volumes)} volume(s)?")
                        if not confirm:
                            console.print("Cancelled")
                            return

                    # Delete all volumes
                    from flow.cli.utils.step_progress import StepTimeline

                    deleted_count = 0
                    total = len(volumes)
                    timeline = StepTimeline(console, title="flow volumes", title_animation="auto")
                    timeline.start()
                    step_idx = timeline.add_step(
                        f"Deleting {total} volume(s)", show_bar=True, estimated_seconds=None
                    )
                    timeline.start_step(step_idx)
                    for i, volume in enumerate(volumes):
                        volume_name = get_volume_display_name(volume)
                        try:
                            flow_client.delete_volume(volume.volume_id)
                            deleted_count += 1
                        except Exception as e:
                            from rich.markup import escape
                            console.print(
                                f"[red]✗[/red] Failed to delete {volume_name}: {escape(str(e))}"
                            )
                        finally:
                            pct = (i + 1) / float(total)
                            timeline.update_active(
                                percent=pct, message=f"{i + 1}/{total} – {volume_name}"
                            )
                    timeline.complete_step(note=f"Deleted {deleted_count}/{total}")
                    timeline.finish()
                    console.print(f"\nDeleted {deleted_count} volume(s)")
                else:
                    # Resolve volume identifier to actual volume
                    volume, error = resolve_volume_identifier(flow_client, volume_identifier)
                    if error:
                        console.print(f"[red]Error:[/red] {error}")
                        return

                    # Get display name for confirmation
                    display_name = get_volume_display_name(volume)

                    if not yes:
                        confirm = click.confirm(f"Delete volume {display_name}?")
                        if not confirm:
                            console.print("Cancelled")
                            return

                    from flow.cli.utils.step_progress import StepTimeline

                    timeline = StepTimeline(console, title="flow volumes", title_animation="auto")
                    timeline.start()
                    step_idx = timeline.add_step(
                        f"Deleting volume {display_name}", show_bar=False
                    )
                    timeline.start_step(step_idx)
                    try:
                        flow_client.delete_volume(volume.volume_id)
                        timeline.complete_step()
                    except Exception as e:
                        # Include request ID when available
                        message = str(e)
                        try:
                            req_id = getattr(e, "request_id", None)
                            if req_id:
                                from rich.markup import escape as _escape
                                message = f"{message}\nRequest ID: {_escape(str(req_id))}"
                        except Exception:
                            pass
                        timeline.fail_step(message)
                        timeline.finish()
                        raise
                    finally:
                        try:
                            timeline.finish()
                        except Exception:
                            pass
                    console.print(f"[green]✓[/green] Volume {display_name} deleted")

                # Show next actions
                self.show_next_actions(
                    [
                        "List remaining volumes: [accent]flow volumes list[/accent]",
                        "Create a new volume: [accent]flow volumes create --size 100[/accent]",
                    ]
                )

                # Invalidate and refresh volumes cache after deletion
                try:
                    from flow.cli.utils.prefetch import (
                        invalidate_cache_for_current_context,
                        refresh_volumes_cache,
                    )
                    # Also clear index cache so :N mappings refresh next list
                    try:
                        from flow.cli.utils.volume_index_cache import VolumeIndexCache

                        VolumeIndexCache().clear()
                    except Exception:
                        pass

                    invalidate_cache_for_current_context(
                        ["volumes_list"]
                    )  # ensure fresh list on next view
                    import threading

                    threading.Thread(target=refresh_volumes_cache, daemon=True).start()
                except Exception:
                    pass

            except AuthenticationError:
                self.handle_auth_error()
            except Exception as e:
                self.handle_error(e)

        return volumes_delete

    def _delete_all_command(self) -> click.Command:
        @click.command(name="delete-all")
        @click.option("--pattern", "-p", help="Only delete volumes matching pattern")
        @click.option("--dry-run", is_flag=True, help="Show what would be deleted")
        @click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
        def volumes_delete_all(pattern: str | None, dry_run: bool, yes: bool):
            """Delete all volumes (with optional pattern matching)."""
            try:
                flow_client = Flow(auto_init=True)
                volume_ops = VolumeOperations(flow_client)

                # Find volumes matching pattern
                matching_volumes, _ = volume_ops.find_volumes_by_pattern(pattern)

                if not matching_volumes:
                    if pattern:
                        console.print(f"No volumes found matching pattern: {pattern}")
                    else:
                        console.print("No volumes found.")
                    return

                # Show what will be deleted
                console.print(f"Found {len(matching_volumes)} volume(s) to delete:")
                for volume_str in volume_ops.format_volume_summary(matching_volumes):
                    console.print(f"  - {volume_str}")

                if dry_run:
                    console.print("\n[yellow]Dry run - no volumes deleted[/yellow]")
                    return

                # Confirm deletion
                if not yes:
                    confirm = click.confirm(f"\nDelete {len(matching_volumes)} volume(s)?")
                    if not confirm:
                        console.print("Cancelled")
                        return

                # Delete volumes with progress callback
                def progress_callback(result):
                    if result.success:
                        console.print(f"[green]✓[/green] Deleted {result.volume_id}")
                    else:
                        console.print(
                            f"[red]✗[/red] Failed to delete {result.volume_id}: {result.error}"
                        )

                results = volume_ops.delete_volumes(matching_volumes, progress_callback)

                # Summary
                console.print(f"\nDeleted {results.succeeded} volume(s)")
                if results.failed > 0:
                    console.print(f"[red]Failed to delete {results.failed} volume(s)[/red]")

                # Show next actions
                self.show_next_actions(
                    [
                        "List remaining volumes: [accent]flow volumes list[/accent]",
                        "Create a new volume: [accent]flow volumes create --size 100[/accent]",
                    ]
                )

                # Invalidate and refresh volumes cache after bulk deletion
                try:
                    from flow.cli.utils.prefetch import (
                        invalidate_cache_for_current_context,
                        refresh_volumes_cache,
                    )
                    # Also clear index cache so :N mappings refresh next list
                    try:
                        from flow.cli.utils.volume_index_cache import VolumeIndexCache

                        VolumeIndexCache().clear()
                    except Exception:
                        pass

                    invalidate_cache_for_current_context(
                        ["volumes_list"]
                    )  # ensure fresh list on next view
                    import threading

                    threading.Thread(target=refresh_volumes_cache, daemon=True).start()
                except Exception:
                    pass

            except AuthenticationError:
                self.handle_auth_error()
            except Exception as e:
                self.handle_error(str(e))

        return volumes_delete_all


# Export command instance
command = VolumesCommand()
