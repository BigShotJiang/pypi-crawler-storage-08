"""Handles code synchronization (rsync) for the dev command."""

import logging
from pathlib import Path

from flow import Flow
from flow.api.models import Task
from flow.cli.commands.base import console
from flow.cli.utils.step_progress import StepTimeline, UploadProgressReporter

logger = logging.getLogger(__name__)


class DevUploadManager:
    """Handles synchronization of local code to the dev VM."""

    def __init__(self, flow_client: Flow, vm_task: Task, timeline: StepTimeline):
        self.flow_client = flow_client
        self.vm_task = vm_task
        self.timeline = timeline
        self.provider = flow_client.provider

    def upload(self, upload_path: str, env_name: str) -> None:
        """Validates the path and uploads code."""
        upload_path_resolved = Path(upload_path).resolve()
        if not upload_path_resolved.exists():
            console.print(f"[red]Error: Upload path does not exist: {upload_path}[/red]")
            raise SystemExit(1)

        if not upload_path_resolved.is_dir():
            console.print(f"[red]Error: Upload path must be a directory: {upload_path}[/red]")
            raise SystemExit(1)

        try:
            if env_name == "default":
                self._upload_to_default(upload_path_resolved)
            else:
                self._upload_to_env(upload_path_resolved, env_name)
        except Exception as e:
            self._handle_upload_error(e)

    def _upload_to_default(self, source_dir: Path) -> None:
        from flow.cli.utils.step_progress import build_sync_check_hint

        step_idx_upload = self.timeline.add_step("Checking for changes", show_bar=False)
        self.timeline.start_step(step_idx_upload)
        try:
            self.timeline.set_active_hint_text(build_sync_check_hint())
        except Exception:
            pass

        def _flip_to_upload():
            try:
                self.timeline.complete_step()
                new_idx = self.timeline.add_step("Uploading code", show_bar=True, estimated_seconds=20)
                self.timeline.start_step(new_idx)
                nonlocal upload_reporter
                upload_reporter = UploadProgressReporter(self.timeline, new_idx)
            except Exception:
                pass

        upload_reporter = UploadProgressReporter(self.timeline, step_idx_upload, on_start=_flip_to_upload)
        result = self.provider.upload_code_to_task(
            task_id=self.vm_task.task_id,
            source_dir=source_dir,
            timeout=600,
            console=None,
            target_dir="~",
            progress_reporter=upload_reporter,
        )
        try:
            if getattr(result, "files_transferred", 0) == 0 and getattr(result, "bytes_transferred", 0) == 0:
                try:
                    self.timeline.complete_step(note="No changes")
                except Exception:
                    pass
        except Exception:
            pass

    def _upload_to_env(self, source_dir: Path, env_name: str) -> None:
        from flow.cli.utils.step_progress import build_sync_check_hint

        # Create environment directory
        remote_ops = self.flow_client.get_remote_operations()
        env_target_dir = f"/envs/{env_name}"
        setup_cmd = f"mkdir -p {env_target_dir}"
        remote_ops.execute_command(self.vm_task.task_id, setup_cmd)

        # Upload to home directory first (provider default)
        step_idx_upload = self.timeline.add_step("Checking for changes", show_bar=False)
        self.timeline.start_step(step_idx_upload)
        try:
            self.timeline.set_active_hint_text(build_sync_check_hint())
        except Exception:
            pass

        def _flip_to_upload2():
            try:
                self.timeline.complete_step()
                new_idx = self.timeline.add_step("Uploading code", show_bar=True, estimated_seconds=20)
                self.timeline.start_step(new_idx)
                nonlocal upload_reporter
                upload_reporter = UploadProgressReporter(self.timeline, new_idx)
            except Exception:
                pass

        upload_reporter = UploadProgressReporter(self.timeline, step_idx_upload, on_start=_flip_to_upload2)
        result = self.provider.upload_code_to_task(
            task_id=self.vm_task.task_id,
            source_dir=source_dir,
            timeout=1500,
            console=None,
            target_dir="~",
            progress_reporter=upload_reporter,
        )
        try:
            if getattr(result, "files_transferred", 0) == 0 and getattr(result, "bytes_transferred", 0) == 0:
                try:
                    self.timeline.complete_step(note="No changes")
                except Exception:
                    pass
        except Exception:
            pass

        # Copy to environment directory with a brief spinner
        copy_cmd = f"rsync -av \"$HOME/\" {env_target_dir}/ --exclude='/envs/'"
        step_idx_env = self.timeline.add_step(f"Environment '{env_name}'", show_bar=False)
        self.timeline.start_step(step_idx_env)
        remote_ops.execute_command(self.vm_task.task_id, copy_cmd)
        self.timeline.complete_step()

    def _handle_upload_error(self, e: Exception) -> None:
        console.print(f"[red]Error uploading code: {e}[/red]")
        if "rsync" in str(e).lower() or "command not found" in str(e):
            console.print("\n[yellow]Install rsync to enable code upload:[/yellow]")
            console.print("  • macOS: [accent]brew install rsync[/accent]")
            console.print("  • Ubuntu/Debian: [accent]sudo apt-get install rsync[/accent]")
            console.print("  • RHEL/CentOS: [accent]sudo yum install rsync[/accent]")


