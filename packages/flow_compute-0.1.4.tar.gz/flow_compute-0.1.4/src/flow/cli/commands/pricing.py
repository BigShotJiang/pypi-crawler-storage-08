"""Pricing visibility command.

Shows current pricing defaults and any user overrides, and explains how to
customize pricing via ~/.flow/config.yaml.
"""

from typing import Any

import click

from flow._internal import pricing as pricing_core
from flow._internal.config import Config
from flow.cli.commands.base import BaseCommand, console
from flow.cli.utils.theme_manager import theme_manager
from flow.cli.utils.table_styles import create_flow_table, wrap_table_in_panel
from flow.links import DocsLinks, WebLinks, MarketingLinks


class PricingCommand(BaseCommand):
    @property
    def name(self) -> str:
        return "pricing"

    @property
    def help(self) -> str:
        return "Show current pricing defaults and how to customize overrides"

    def get_command(self) -> click.Command:
        @click.command(name=self.name, help=self.help)
        @click.option(
            "--compact",
            is_flag=True,
            help="Compact output (fewer hints)",
        )
        @click.option(
            "--market",
            is_flag=True,
            help="Show current market spot prices by region and instance type",
        )
        @click.option(
            "--region",
            help="Filter market pricing by region (e.g., us-central1-b)",
        )
        def pricing(compact: bool = False, market: bool = False, region: str | None = None):
            """Display merged pricing table and configuration guidance."""
            # Header
            try:
                accent = theme_manager.get_color("accent")
                console.print(f"[bold {accent}]Flow Pricing[/bold {accent}]")
            except Exception:
                pass

            # Market view: live spot prices and availability
            if market:
                try:
                    from flow import Flow

                    client = Flow()
                    requirements: dict[str, Any] = {}
                    if region:
                        requirements["region"] = region
                    # Fetch up to 100 current auctions converted to AvailableInstance
                    instances = client.find_instances(requirements, limit=100)

                    # Build table
                    table = create_flow_table(title=None, show_borders=True, padding=1, expand=False)
                    table.add_column(
                        "Region", style=theme_manager.get_color("accent"), no_wrap=True
                    )
                    table.add_column("Type", no_wrap=True)
                    table.add_column("Price/inst", justify="right")
                    table.add_column("Price/GPU", justify="right")
                    table.add_column("GPUs", justify="right")
                    table.add_column("Avail", justify="right")

                    def _per_gpu_price(inst) -> str:
                        try:
                            g = int(inst.gpu_count or 0)
                            if g > 0 and inst.price_per_hour:
                                return f"${inst.price_per_hour / g:.2f}/hr"
                        except Exception:
                            pass
                        return "-"

                    # Normalize/format values with fallbacks
                    def _fmt_gpus(inst) -> str:
                        try:
                            if inst.gpu_count:
                                return str(int(inst.gpu_count))
                            # Derive from instance_type like '8xa100'
                            it = (inst.instance_type or "").lower()
                            if "x" in it:
                                prefix, _ = it.split("x", 1)
                                return str(int(prefix))
                        except Exception:
                            pass
                        return "-"

                    def _fmt_avail(inst) -> str:
                        # We expect AvailableInstance.available_quantity to be computed by provider
                        try:
                            if inst.available_quantity is not None:
                                return str(int(inst.available_quantity))
                        except Exception:
                            pass
                        return "-"

                    # Sort by region then price
                    instances.sort(key=lambda i: (i.region or "", i.price_per_hour))
                    for inst in instances:
                        table.add_row(
                            inst.region or "",
                            inst.instance_type,
                            f"${inst.price_per_hour:.2f}/hr",
                            _per_gpu_price(inst),
                            _fmt_gpus(inst),
                            _fmt_avail(inst),
                        )

                    wrap_table_in_panel(
                        table,
                        f"Current spot prices{' • ' + region if region else ''}",
                        console,
                    )

                    # Show provider-specific console link when Mithril is active
                    import os as _os
                    if (_os.environ.get("FLOW_PROVIDER") or "mithril").lower() == "mithril":
                        console.print(
                            f"More details and price graphs: {WebLinks.price_chart()}\n"
                        )
                    else:
                        console.print(
                            "More details and price graphs are available in your provider console\n"
                        )
                except Exception as e:
                    console.print(f"[red]Failed to fetch market prices:[/red] {e}")
                return

            # Resolve overrides from config, merge with defaults (default view)
            try:
                cfg = Config.from_env(require_auth=False)
                overrides = None
                if cfg and isinstance(cfg.provider_config, dict):
                    overrides = cfg.provider_config.get("limit_prices")
                merged = pricing_core.get_pricing_table(overrides)
                have_overrides = bool(overrides)
            except Exception:
                merged = pricing_core.DEFAULT_PRICING
                have_overrides = False

            # Build table of prices (focus on h100 and a100 for clarity)
            table = create_flow_table(title=None, show_borders=True, padding=1, expand=False)
            table.add_column("GPU", style=theme_manager.get_color("accent"), no_wrap=True)
            table.add_column("Low", justify="right")
            table.add_column("Med", justify="right")
            table.add_column("High", justify="right")

            # Only show key GPUs commonly used: h100 and a100; include 'default' last if present
            preferred: list[str] = [k for k in ("h100", "a100") if k in merged]
            extras: list[str] = []
            if "default" in merged:
                extras = ["default"]
            keys: list[str] = preferred + extras
            for gpu in keys:
                prices: dict[str, float] = merged.get(gpu, {})
                low = prices.get("low")
                med = prices.get("med")
                high = prices.get("high")
                table.add_row(
                    gpu,
                    f"${low:.2f}/hr" if isinstance(low, (int, float)) else "-",
                    f"${med:.2f}/hr" if isinstance(med, (int, float)) else "-",
                    f"${high:.2f}/hr" if isinstance(high, (int, float)) else "-",
                )

            wrap_table_in_panel(table, "Spot limit prices (per GPU per hour)", console)

            # Links and context
            def link_label(label: str, url: str) -> str:
                try:
                    from flow.cli.utils.hyperlink_support import hyperlink_support

                    if hyperlink_support.is_supported():
                        return hyperlink_support.create_link(label, url)
                except Exception:
                    pass
                return f"{label}: {url}"

            console.print(
                f"Pricing page: {link_label('mithril.ai/pricing', MarketingLinks.pricing())}"
            )
            console.print(
                f"Spot bids: {link_label('docs.mithril.ai/spot-bids', DocsLinks.spot_bids())}"
            )
            console.print(
                f"Price charts: {link_label('app.mithril.ai/price-chart', WebLinks.price_chart())}\n"
            )

            # Source info
            if have_overrides:
                console.print(
                    "Using merged pricing: Flow defaults + your overrides in ~/.flow/config.yaml under [bold]mithril.limit_prices[/bold].\n"
                )
            else:
                console.print(
                    "Flow sets default limit prices by priority tier. You can change them in ~/.flow/config.yaml under [bold]mithril.limit_prices[/bold].\n"
                )

            if not compact:
                console.print("[dim]About pricing & bids:[/dim]")
                console.print(
                    "  • Flow picks default [bold]limit prices[/bold] from priority (low/med/high). You pay the market spot price, never above your limit."
                )
                console.print(
                    "  • Per‑GPU limit × GPU count = per‑instance limit."
                )
                console.print(
                    f"  • Learn more: {link_label('Spot bids', DocsLinks.spot_bids())}\n"
                )

                # YAML guidance
                console.print(
                    "Edit [bold]~/.flow/config.yaml[/bold] to set your limit tiers (values below are examples):\n"
                )
                yaml_snippet = (
                    "provider: mithril\n"
                    "mithril:\n"
                    "  project: my-project\n"
                    "  region: us-central1-b\n"
                    "  limit_prices:\n"
                    "    h100:\n"
                    "      low: 3.50   # lower than Flow default (4.00)\n"
                    "      med: 8.00   # same as Flow default (8.00)\n"
                    "      high: 18.00  # higher than Flow default (16.00)\n"
                    "    a100:\n"
                    "      low: 1.50   # lower than Flow default (2.00)\n"
                    "      med: 3.00   # same as Flow default (4.00)\n"
                    "      high: 13.00  # higher than Flow default (8.00)\n"
                )
                console.print(f"[dim]\n--- YAML ---\n[/dim]{yaml_snippet}[dim]---\n[/dim]")

                console.print("Tips:")
                console.print(
                    "  • Partial overrides are fine; unspecified tiers fall back to Flow defaults"
                )
                console.print(
                    "  • Per‑run override: 'flow run task.yaml -p high' or '--max-price-per-hour 24'\n"
                )

            # Next steps
            try:
                actions = [
                    "See market prices: [accent]flow pricing --market[/accent]",
                    "Run with high priority: [accent]flow run task.yaml -p high[/accent]",
                    "Edit pricing tiers: [accent]~/.flow/config.yaml[/accent]",
                ]
                self.show_next_actions(actions)
            except Exception:
                pass

        return pricing


# Export command instance
command = PricingCommand()
