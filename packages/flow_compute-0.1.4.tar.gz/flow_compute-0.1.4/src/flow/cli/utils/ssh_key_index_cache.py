"""SSH Key index cache for quick key references.

Stores ephemeral index-based key references (e.g., 1, :1) for the last shown
SSH key list. We store lightweight refs that can be resolved to a platform ID
or local path when used by commands.
"""

from __future__ import annotations

import json
import time
from pathlib import Path


class SSHKeyIndexCache:
    """Manages ephemeral SSH key index mappings.

    Each entry stores a minimal reference dict, e.g.:
      {"ref": "sshkey_ABC", "type": "platform_id"}
      {"ref": "/Users/me/.ssh/id_ed25519", "type": "local"}
      {"ref": "_auto_", "type": "sentinel"}
    """

    CACHE_TTL_SECONDS = 300  # 5 minutes

    def _current_context(self) -> str | None:
        try:
            from flow.cli.utils.prefetch import _context_prefix  # type: ignore

            return _context_prefix()
        except Exception:
            return None

    def __init__(self, cache_dir: Path | None = None):
        self.cache_dir = cache_dir or Path.home() / ".flow"
        self.cache_file = self.cache_dir / "ssh_key_indices.json"

    def save_indices(self, refs: list[dict[str, str]]) -> None:
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        if not refs:
            self.clear()
            return
        cache_data = {
            "indices": {str(i + 1): refs[i] for i in range(len(refs))},
            "timestamp": time.time(),
            "count": len(refs),
            "context": self._current_context(),
        }
        tmp = self.cache_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(cache_data, indent=2))
        tmp.replace(self.cache_file)

    def resolve_index(self, index_str: str) -> tuple[dict | None, str | None]:
        # Accept ":N" or "N"
        raw = index_str[1:] if index_str.startswith(":") else index_str
        try:
            index = int(raw)
        except ValueError:
            return None, f"Invalid index format: {index_str}"
        if index < 1:
            return None, "Index must be positive"
        data = self._load_cache()
        if not data:
            return None, "No recent SSH key list. Run 'flow ssh-keys list' first"
        age = time.time() - data.get("timestamp", 0)
        if age > self.CACHE_TTL_SECONDS:
            return None, "SSH key indices expired. Run 'flow ssh-keys list' to refresh"
        ref = data.get("indices", {}).get(str(index))
        if not ref:
            max_index = data.get("count", 0)
            return None, f"Index {index} out of range (1-{max_index})"
        return dict(ref), None

    def _load_cache(self) -> dict | None:
        if not self.cache_file.exists():
            return None
        try:
            data = json.loads(self.cache_file.read_text())
            try:
                saved_ctx = data.get("context")
                curr_ctx = self._current_context()
                if saved_ctx is not None and curr_ctx is not None and saved_ctx != curr_ctx:
                    return None
            except Exception:
                pass
            return data
        except (json.JSONDecodeError, KeyError):
            return None

    def clear(self) -> None:
        if self.cache_file.exists():
            self.cache_file.unlink()


