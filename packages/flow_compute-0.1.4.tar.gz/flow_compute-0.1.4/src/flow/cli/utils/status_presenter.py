"""Status presenter (core default UI).

Coordinates fetching, formatting, table rendering, header summary, tip bar,
and index cache saving for the default status UI.
"""

from __future__ import annotations

from dataclasses import dataclass

from rich.console import Console

from flow import Flow
from flow.api.models import Task
from flow.cli.utils.owner_resolver import OwnerResolver
from flow.cli.utils.status_table_renderer import StatusTableRenderer
from flow.cli.utils.task_fetcher import TaskFetcher
from flow.cli.utils.task_index_cache import TaskIndexCache
from flow.cli.utils.theme_manager import theme_manager
from flow.cli.utils.time_formatter import TimeFormatter
from flow.cli.utils.next_steps import (
    build_status_recommendations,
    render_next_steps_panel,
)


@dataclass
class StatusDisplayOptions:
    show_all: bool = False
    limit: int = 20
    group_by_origin: bool = True
    # When set, indicates the list is filtered by a specific status (e.g., "completed")
    status_filter: str | None = None


class StatusPresenter:
    def __init__(self, console: Console | None = None, flow_client: Flow | None = None) -> None:
        self.console = console or theme_manager.create_console()
        self.flow = flow_client or Flow()
        self.fetcher = TaskFetcher(self.flow)
        self.time_fmt = TimeFormatter()
        self.table = StatusTableRenderer(self.console)
        self.owner_resolver = OwnerResolver(self.flow)

    def present(self, options: StatusDisplayOptions, tasks: list[Task] | None = None) -> None:
        if tasks is None:
            # Fast path: perform a single provider call to detect empty state
            try:
                tasks = self.flow.list_tasks(limit=options.limit)
            except Exception:
                # Fall back to fetcher on provider issues
                tasks = None
            if tasks is None:
                tasks = self.fetcher.fetch_for_display(
                    show_all=options.show_all, status_filter=None, limit=options.limit
                )
        if not tasks:
            self.console.print("[dim]No tasks found[/dim]")
            return

        # Pre-table summary will be computed after filters are applied for clarity

        me = self.owner_resolver.get_me()
        owner_map = self.owner_resolver.get_teammates_map()

        # Apply the same 24h time-window filtering in grouped view to keep behavior consistent
        # with the non-grouped path. When show_all is set, skip time filtering.
        tasks_for_display = list(tasks)
        if (not options.show_all) and (not options.status_filter):
            try:
                from flow.cli.utils.task_filter import TaskFilter as _TF

                tasks_for_display = _TF.filter_by_time_window(
                    tasks_for_display, hours=24, include_active=True
                )
            except Exception:
                # Fallback: keep original tasks on any error
                tasks_for_display = list(tasks)

        # Apply status filter client-side when requested (covers provider gaps like 'preempting')
        if options.status_filter:
            try:
                from flow.api.models import TaskStatus as _TS
                from flow.cli.utils.task_filter import TaskFilter as _TF

                status_enum = _TS(options.status_filter)
                tasks_for_display = _TF.filter_by_status(tasks_for_display, status_enum)
            except Exception:
                # If conversion fails, leave list unchanged
                pass

        # Summary line (based on filtered/time-windowed list for clarity)
        try:
            running = sum(
                1 for t in tasks_for_display if getattr(t.status, "value", str(t.status)) == "running"
            )
            pending = sum(
                1 for t in tasks_for_display if getattr(t.status, "value", str(t.status)) == "pending"
            )
            parts: list[str] = []
            if running:
                parts.append(f"{running} running")
            if pending:
                parts.append(f"{pending} pending")
            if parts:
                self.console.print("[dim]" + " · ".join(parts) + "[/dim]\n")
        except Exception:
            pass

        # Optional grouping by origin (Flow vs Other) using provider metadata
        if options.group_by_origin:
            flow_tasks: list[Task] = []
            other_tasks: list[Task] = []
            for t in tasks_for_display:
                try:
                    meta = getattr(t, "provider_metadata", {}) or {}
                    origin = str(meta.get("origin", "")).lower()
                    if origin in ("flow-cli", "flow-compute"):
                        flow_tasks.append(t)
                    else:
                        other_tasks.append(t)
                except Exception:
                    other_tasks.append(t)

            displayed_tasks: list[Task] = []

            # Compute a unified GPU column width across groups for visual alignment
            forced_gpu_width: int | None = None
            try:
                from flow.cli.utils.gpu_formatter import GPUFormatter as _GF
                desired = 0
                for group in (flow_tasks, other_tasks):
                    for t in group:
                        ni = getattr(t, "num_instances", 1)
                        try:
                            ni = max(1, int(ni))
                        except Exception:
                            ni = 1
                        s = _GF.format_ultra_compact(getattr(t, "instance_type", "") or "", ni)
                        desired = max(desired, len(s))
                # Match renderer's clamp logic (min width respected inside)
                forced_gpu_width = desired
            except Exception:
                forced_gpu_width = None

            if flow_tasks:
                title_flow = "Flow"
                panel_flow = self.table.render(
                    flow_tasks,
                    me=me,
                    owner_map=owner_map,
                    title=title_flow,
                    wide=False,
                    start_index=1,
                    return_renderable=True,
                    forced_gpu_width=forced_gpu_width,
                )
                self.console.print(panel_flow)
                displayed_tasks.extend(flow_tasks)

            if other_tasks:
                # Add spacing if both groups present
                if flow_tasks:
                    self.console.print("")
                title_other = "External"
                panel_other = self.table.render(
                    other_tasks,
                    me=me,
                    owner_map=owner_map,
                    title=title_other,
                    wide=False,
                    start_index=(len(flow_tasks) + 1),
                    return_renderable=True,
                    forced_gpu_width=forced_gpu_width,
                )
                self.console.print(panel_other)
                displayed_tasks.extend(other_tasks)

            if not flow_tasks and not other_tasks:
                self.console.print("[dim]No tasks found[/dim]")
        else:
            if not options.show_all:
                title = f"Tasks (showing up to {options.limit}, last 24 hours)"
            else:
                title = f"Tasks (showing up to {options.limit})"
            displayed_tasks = list(tasks)
            panel = self.table.render(
                tasks,
                me=me,
                owner_map=owner_map,
                title=title,
                wide=False,
                start_index=1,
                return_renderable=True,
            )
            self.console.print(panel)

        if options.group_by_origin:
            legend = "External = other sources (e.g., provider console)"
            try:
                provider_name = getattr(getattr(self.flow, "config", None), "provider", None) or ""
                if not provider_name:
                    import os as _os

                    provider_name = (_os.environ.get("FLOW_PROVIDER") or "").lower()
                if (provider_name or "").lower() == "mithril":
                    legend = "External = other sources (e.g., Mithril Console)"
            except Exception:
                pass
            self.console.print(f"\n[dim]Legend: Flow = Flow (CLI/SDK) · {legend}[/dim]")
        # Post-table context note: only show the active-only hint when not filtered by status
        if (not options.show_all) and not options.status_filter:
            self.console.print("[dim]Showing active tasks only. Use --all to see all tasks.[/dim]")
        elif options.status_filter:
            # Provide a concise filter acknowledgement for clarity
            self.console.print(f"[dim]Filtered by status: {options.status_filter}[/dim]")
        self.console.print(
            "[dim]Tip: Index shortcuts (1, 1-3; ':1' also works) are valid for 5 minutes after this view.[/dim]"
        )
        self.console.print("[dim]Re-run 'flow status' to refresh indices.[/dim]")

        # Save indices in the order displayed so shortcuts match UI numbering
        # Be resilient when tasks are mocks (tests) and may not be JSON serializable
        try:
            cache = TaskIndexCache()
            cache.save_indices(displayed_tasks)
        except Exception:
            # Skip caching silently; indices will not be available but display is intact
            pass

        count = min(len(displayed_tasks), options.limit)
        if count >= 7:
            multi_example = "1-3,5,7"
            range_example = "1-3"
        elif count >= 5:
            multi_example = "1-3,5"
            range_example = "1-3"
        elif count >= 3:
            multi_example = "1-3"
            range_example = "1-3"
        elif count == 2:
            multi_example = "1-2"
            range_example = "1-2"
        else:
            multi_example = "1"
            range_example = "1"

        # Dynamic, context-aware next steps
        index_example_single = "1"
        recommendations = build_status_recommendations(
            displayed_tasks,
            max_count=3,
            index_example_single=index_example_single,
            index_example_multi=multi_example,
        )
        if recommendations:
            render_next_steps_panel(self.console, recommendations)
