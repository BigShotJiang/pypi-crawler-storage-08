"""Owner resolver and formatter (core).

Resolves current user (me) once per run; formats Owner column per spec.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict

from flow import Flow


@dataclass
class Me:
    user_id: str
    username: str | None = None
    email: str | None = None


class OwnerResolver:
    def __init__(self, flow: Flow | None = None) -> None:
        self.flow = flow or Flow()
        self._me: Me | None = None
        self._owner_map: Dict[str, str] | None = None

    def get_me(self) -> Me | None:
        if self._me is not None:
            return self._me
        # Use provider http to query /v2/me if available
        try:
            provider = self.flow.provider
            http = getattr(provider, "http", None)
            if http is None:
                return None
            resp = http.request(method="GET", url="/v2/me")
            data = resp.get("data", resp) if isinstance(resp, dict) else None
            if not isinstance(data, dict):
                return None
            user_id = data.get("fid") or data.get("id") or data.get("user_id")
            username = data.get("username") or data.get("user_name")
            email = data.get("email")
            if not user_id:
                return None
            self._me = Me(user_id=user_id, username=username, email=email)
            return self._me
        except Exception:
            return None

    def get_teammates_map(self) -> dict[str, str]:
        """Return mapping of teammate user_id -> friendly label.

        Uses v1 IAM endpoint: GET /users/{user_id}/teammates (not under /v2).
        Falls back to empty mapping on error.
        """
        if self._owner_map is not None:
            return self._owner_map
        self._owner_map = {}
        me = self.get_me()
        if me is None or not me.user_id:
            return self._owner_map
        try:
            provider = self.flow.provider
            # Prefer public provider method; fallback to raw HTTP for non-Mithril
            if hasattr(provider, "get_user_teammates"):
                resp = provider.get_user_teammates(me.user_id)  # type: ignore[attr-defined]
            else:
                http = getattr(provider, "http", None)
                if http is None:
                    return self._owner_map
                # v1 IAM path for providers that share Mithril IAM stack
                from flow.providers.mithril.core.constants import V1_USERS_TEAMMATES_PATH_TEMPLATE

                path = V1_USERS_TEAMMATES_PATH_TEMPLATE.format(user_id=me.user_id)
                resp = http.request(method="GET", url=path)
            data = resp.get("data", resp) if isinstance(resp, dict) else None
            items = data if isinstance(data, list) else []

            # Add current user label mapping for robust self-resolution
            try:
                self_label = None
                if me.email and "@" in me.email:
                    local = me.email.split("@")[0]
                    self_label = (local.split(".")[0].split("_")[0].split("-")[0] or "").lower()
                if not self_label and me.username:
                    self_label = (
                        str(me.username).split()[0].split(".")[0].split("_")[0].split("-")[0] or ""
                    ).lower()
                if not self_label:
                    self_label = str(me.user_id).replace("user_", "")[:8]
                # Index multiple normalized keys for self
                def _norm_tokens(v: str) -> list[str]:
                    low = v.lower()
                    stripped = re.sub(r"^user_", "", low)
                    alnum = re.sub(r"[^a-z0-9]", "", low)
                    tokens = {low, stripped, alnum, alnum[:8], re.sub(r"[^a-z0-9]", "", stripped)[:8]}
                    return [t for t in tokens if t]

                for key in _norm_tokens(str(me.user_id)):
                    self._owner_map[key] = self_label
            except Exception:
                pass
            for user in items:
                try:
                    uid = (
                        user.get("fid")
                        or user.get("id")
                        or user.get("user_id")
                        or None
                    )
                    if not uid:
                        continue
                    email = user.get("email")
                    username = user.get("username") or user.get("user_name")
                    display_name = user.get("name") or user.get("display_name")
                    label = None
                    if email and "@" in email:
                        local = email.split("@")[0]
                        import re as _re

                        first = _re.split(r"[._-]+", local)[0]
                        label = first.lower() if first else None
                    if not label and username:
                        import re as _re

                        first = _re.split(r"[\s._-]+", str(username))[0]
                        label = first.lower() if first else None
                    if not label and display_name:
                        label = str(display_name).split()[0].lower()
                    if not label:
                        label = str(uid).replace("user_", "")[:8]
                    # Index multiple normalized keys for teammate id and username
                    def _norm_tokens(v: str) -> list[str]:
                        low = v.lower()
                        stripped = re.sub(r"^user_", "", low)
                        alnum = re.sub(r"[^a-z0-9]", "", low)
                        tokens = {low, stripped, alnum, alnum[:8], re.sub(r"[^a-z0-9]", "", stripped)[:8]}
                        return [t for t in tokens if t]

                    for key in _norm_tokens(str(uid)):
                        self._owner_map[key] = label
                    if username:
                        for key in _norm_tokens(str(username)):
                            self._owner_map[key] = label
                except Exception:
                    continue
        except Exception:
            # Non-fatal; return whatever we have
            pass
        return self._owner_map

    @staticmethod
    def format_owner(created_by: str | None, me: Me | None, owner_map: dict[str, str] | None = None) -> str:
        # Resolve via teammates map first when available
        if owner_map and created_by:
            try:
               # Case-insensitive lookups across normalized token forms
                key = str(created_by).lower()
                label = owner_map.get(key)
                if label:
                    return label
                # Try additional normalized forms
                stripped = re.sub(r"^user_", "", key)
                alnum = re.sub(r"[^a-z0-9]", "", key)
                for tok in (stripped, alnum, alnum[:8], re.sub(r"[^a-z0-9]", "", stripped)[:8]):
                    if tok and tok in owner_map:
                        return owner_map[tok]
            except Exception:
                pass
        # Prefer current user's friendly name when the creator matches the current user
        if me and created_by:
            try:
                # Normalize inputs (case-insensitive, strip common prefixes)
                created_by_str = str(created_by)
                me_user_id = str(me.user_id or "")
                me_username = str(me.username or "")
                me_email = str(me.email or "")

                # Direct equality first (exact provider IDs)
                if created_by_str == me_user_id:
                    pass  # treat as same user
                else:
                    # Normalize common ID formats to handle provider differences
                    # Examples:
                    #   created_by: "ClUS4619" vs me.user_id: "user_ClUS4619AbCdEf"
                    #   created_by: "user_kfV4CCaapLiqCNlv" vs me.user_id: "user_kfV4CCaapLiqCNlv"
                    created_token = re.sub(r"^user_", "", created_by_str)
                    me_token = re.sub(r"^user_", "", me_user_id)
                    # Lowercase and strip non-alphanumerics to tolerate formatting
                    created_token_l = re.sub(r"[^a-z0-9]", "", created_token.lower())
                    me_token_l = re.sub(r"[^a-z0-9]", "", me_token.lower())
                    # Consider a match if one token starts with the other (handles short IDs)
                    is_same_user = False
                    if created_token_l and me_token_l:
                        if (
                            created_token_l == me_token_l
                            or me_token_l.startswith(created_token_l)
                            or created_token_l.startswith(me_token_l)
                        ):
                            is_same_user = True
                        else:
                            # Also compare first 8 chars which are commonly displayed
                            is_same_user = created_token_l[:8] == me_token_l[:8]
                    # Also consider username-based identity commonly shown in external systems
                    if not is_same_user and me_username:
                        ct = created_by_str.lower()
                        un = me_username.lower()
                        if ct == un or ct.startswith(un) or un.startswith(ct):
                            is_same_user = True
                    # And finally compare against email local part (before @)
                    if not is_same_user and me_email and "@" in me_email:
                        local = me_email.split("@")[0].lower()
                        ct = created_by_str.lower()
                        if ct == local or ct.startswith(local) or local.startswith(ct):
                            is_same_user = True
                    if not is_same_user:
                        raise ValueError("not same user")
                # Derive a first-name style label from email (e.g., jared@ → jared, john.doe@ → john)
                if me_email and "@" in me_email:
                    local = me_email.split("@")[0]
                    # Split on common separators and take the first segment
                    first = re.split(r"[._-]+", local)[0]
                    return first.lower() if first else "-"
                # Fallback to username if available
                if me_username:
                    # Use first token of username and normalize to lowercase
                    first = re.split(r"[\s._-]+", me_username)[0]
                    return first.lower() if first else "-"
                # No personal info available
                return "-"
            except Exception:
                # Fall through to compact FID formatting below
                pass
        # Compact FID for other users
        if created_by:
            return created_by.replace("user_", "")[:8]
        # Unknown owner
        return "-"
