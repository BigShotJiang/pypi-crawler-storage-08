"""Compatibility shim for refactored Mithril remote operations.

This module preserves the original import path `flow.providers.mithril.remote_operations`
by re-exporting the new implementation from `flow.providers.mithril.remote`.
"""

from flow.providers.mithril.remote import (  # noqa: F401
    MithrilRemoteOperations,
    RemoteExecutionError,
    TaskNotFoundError,
)


