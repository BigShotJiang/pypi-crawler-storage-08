from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from flow.api.ssh_utils import SSHNotReadyError, wait_for_task_ssh_info
from flow.core.ssh_stack import SshStack
from flow.providers.mithril.core.constants import (
    EXPECTED_PROVISION_MINUTES,
    SSH_QUICK_RETRY_ATTEMPTS,
    SSH_QUICK_RETRY_MAX_SECONDS,
)

from flow.providers.mithril.remote.errors import make_error, SshConnectionError


logger = logging.getLogger(__name__)


@dataclass
class ConnectionDetails:
    """Holds resolved and validated SSH connection details."""

    user: str
    host: str
    port: int
    key_path: Path
    cache_key: Optional[tuple] = None
    task: Optional[object] = None


class SshConnectionManager:
    """Centralizes SSH setup, validation, retries, and caching."""

    def __init__(self, provider):
        self.provider = provider
        self._ssh_last_success: dict[tuple, float] = {}

    # Cache helpers --------------------------------------------------------
    def _build_cache_key(self, task_id: str, task, node: Optional[int]) -> Optional[tuple]:
        try:
            try:
                project_id = self.provider.project_id
            except Exception:
                project_id = "default"
            return (
                project_id,
                task_id,
                int(node or -1),
                getattr(task, "ssh_host"),
                int(getattr(task, "ssh_port", 22)),
            )
        except Exception:
            return None

    # Public wrapper used by callers to avoid using a private method
    def build_cache_key(self, task_id: str, task, node: Optional[int]) -> Optional[tuple]:
        return self._build_cache_key(task_id, task, node)

    def check_recent_success(self, cache_key: Optional[tuple], ttl_seconds: float = 60.0) -> bool:
        if cache_key is None:
            return False
        try:
            ts = self._ssh_last_success.get(cache_key)
            return ts is not None and (time.time() - ts) < ttl_seconds
        except Exception:
            return False

    def mark_success(self, cache_key: Optional[tuple]) -> None:
        if cache_key is None:
            return
        try:
            self._ssh_last_success[cache_key] = time.time()
        except Exception:
            pass

    def bust_cache(self, cache_key: Optional[tuple]) -> None:
        if cache_key is None:
            return
        try:
            self._ssh_last_success.pop(cache_key, None)
        except Exception:
            pass

    # Core establishment ---------------------------------------------------
    def establish_connection(
        self,
        task_id: str,
        request_id: str,
        timeout_seconds: int,
        node: Optional[int] = None,
        quick_ready: bool = False,
    ) -> ConnectionDetails:
        """Resolve SSH details and ensure the remote host is ready."""
        task = self._resolve_endpoint(task_id, node, request_id)

        # Ensure SSH info exists
        try:
            task = wait_for_task_ssh_info(
                task=task,
                provider=self.provider,
                timeout=SSH_QUICK_RETRY_MAX_SECONDS * 2 if quick_ready else timeout_seconds,
                show_progress=False,
            )
        except SSHNotReadyError as e:
            raise make_error(
                f"No SSH access for task {task_id}: {str(e)}",
                request_id,
                suggestions=e.suggestions,
                cls=SshConnectionError,
            ) from e

        # Ensure SSH key path
        key_path = self._resolve_ssh_key(task_id, request_id)

        # Wait for SSH service readiness
        self._ensure_ssh_ready(task, key_path, request_id)

        cache_key = self._build_cache_key(task_id, task, node)
        return ConnectionDetails(
            user=getattr(task, "ssh_user", "ubuntu"),
            host=getattr(task, "ssh_host"),
            port=int(getattr(task, "ssh_port", 22)),
            key_path=Path(key_path),
            cache_key=cache_key,
            task=task,
        )

    # Internal helpers -----------------------------------------------------
    def _resolve_endpoint(self, task_id: str, node: Optional[int], request_id: str):
        task = self.provider.get_task(task_id)

        # Fresh resolve endpoint; handle multi-node selection
        try:
            host, port = self.provider.resolve_ssh_endpoint(task_id, node=node)
            setattr(task, "ssh_host", host)
            try:
                setattr(task, "ssh_port", int(port or 22))
            except Exception:
                setattr(task, "ssh_port", 22)
        except Exception as e:
            if not getattr(task, "ssh_host", None):
                raise make_error(str(e), request_id)

        if node is not None and getattr(task, "instances", None):
            try:
                instances = self.provider.get_task_instances(task_id)
                if node < 0 or node >= len(instances):
                    raise make_error(
                        f"Invalid node index {node}; task has {len(instances)} nodes",
                        request_id,
                        cls=SshConnectionError,
                    )
                selected = instances[node]
                if getattr(selected, "ssh_host", None):
                    setattr(task, "ssh_host", selected.ssh_host)
            except Exception as e:
                raise make_error(str(e), request_id, cls=SshConnectionError)

        return task

    def _resolve_ssh_key(self, task_id: str, request_id: str) -> Path:
        # Ensure SSH key manager has project scoping
        try:
            if getattr(self.provider, "ssh_key_manager", None) is not None and getattr(
                self.provider.ssh_key_manager, "project_id", None
            ) is None:
                self.provider.ssh_key_manager.project_id = self.provider.project_id
        except Exception:
            pass

        ssh_key_path, error_msg = self.provider.get_task_ssh_connection_info(task_id)
        if not ssh_key_path:
            raise make_error(f"SSH key resolution failed: {error_msg}", request_id, cls=SshConnectionError)
        return Path(ssh_key_path)

    def _ensure_ssh_ready(self, task, key_path: Path, request_id: str) -> None:
        if SshStack.is_ssh_ready(
            user=getattr(task, "ssh_user", "ubuntu"),
            host=getattr(task, "ssh_host"),
            port=getattr(task, "ssh_port", 22),
            key_path=Path(key_path),
        ):
            return

        start_time = time.time()
        for attempt in range(SSH_QUICK_RETRY_ATTEMPTS):
            elapsed = time.time() - start_time
            if elapsed > SSH_QUICK_RETRY_MAX_SECONDS:
                break

            time.sleep(2 * (attempt + 1))
            if SshStack.is_ssh_ready(
                user=getattr(task, "ssh_user", "ubuntu"),
                host=getattr(task, "ssh_host"),
                port=getattr(task, "ssh_port", 22),
                key_path=Path(key_path),
            ):
                return

        # Build nuanced error messaging based on instance status/age
        try:
            instance_age_seconds = float(getattr(task, "instance_age_seconds", 0) or 0)
        except Exception:
            instance_age_seconds = 0.0
        capped_seconds = max(0.0, min(instance_age_seconds, 7 * 24 * 3600))
        instance_age_minutes = int(capped_seconds // 60)

        instance_status = getattr(task, "instance_status", None)

        if instance_status == "STATUS_STARTING":
            raise make_error(
                "Instance is starting up. SSH will be available once startup completes. "
                "Please try again in a moment or check 'flow status' for current state.",
                request_id,
                cls=SshConnectionError,
            )
        elif instance_age_minutes < EXPECTED_PROVISION_MINUTES:
            raise make_error(
                f"Instance is still starting up ({instance_age_minutes} minutes elapsed). "
                f"SSH startup can take up to {EXPECTED_PROVISION_MINUTES} minutes. "
                f"Please try again in a moment.",
                request_id,
                cls=SshConnectionError,
            )
        else:
            raise make_error(
                f"SSH service on {getattr(task, 'ssh_host', 'host')} is not responding. "
                f"The instance may still be starting up (can take up to {EXPECTED_PROVISION_MINUTES} minutes). "
                f"Please try again in a moment.",
                request_id,
                cls=SshConnectionError,
            )


