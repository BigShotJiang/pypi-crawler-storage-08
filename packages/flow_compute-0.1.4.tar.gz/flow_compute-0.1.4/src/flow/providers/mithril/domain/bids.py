"""Bid submission and selection facade.

Unifies region selection, instance type resolution, and bid submission behind a
single service used by the provider facade.
"""

from __future__ import annotations

from typing import Any

from flow.api.models import TaskConfig
from flow.errors import ResourceNotAvailableError
from flow.providers.mithril.api.client import MithrilApiClient
from flow.providers.mithril.bidding.builder import BidBuilder
from flow.providers.mithril.core.models import Auction
from flow.providers.mithril.domain.pricing import PricingService
from flow.providers.mithril.domain.region import RegionSelector


class BidsService:
    def __init__(
        self,
        api: MithrilApiClient,
        region_selector: RegionSelector,
        pricing: PricingService,
        resolve_instance_type: callable,
        get_project_id: callable,
    ) -> None:
        self._api = api
        self._region_selector = region_selector
        self._pricing = pricing
        self._resolve_instance_type = resolve_instance_type
        self._get_project_id = get_project_id

    def select_region_and_instance(
        self, config: TaskConfig, instance_type: str
    ) -> tuple[str, str, Auction | None]:
        # Resolve candidate instance type IDs. For generic H100 requests, consider
        # both SXM and PCIe 8x variants to allow region-specific availability.
        candidate_type_ids: list[str] = []
        it_lower = (instance_type or "").lower()
        try:
            primary_id = self._resolve_instance_type(instance_type)
            candidate_type_ids.append(primary_id)
        except Exception:
            # Continue; alternatives may still resolve
            pass

        try:
            if any(t in it_lower for t in ("h100", "xh100")):
                for alt in ("h100-80gb.sxm.8x", "h100-80gb.pcie.8x"):
                    try:
                        alt_id = self._resolve_instance_type(alt)
                        if alt_id not in candidate_type_ids:
                            candidate_type_ids.append(alt_id)
                    except Exception:
                        pass
        except Exception:
            pass

        # Fallback: if nothing resolved, raise gracefully
        if not candidate_type_ids:
            raise ResourceNotAvailableError(
                f"Unsupported or unknown instance type: {instance_type}",
                suggestions=[
                    "Use 'flow catalog' to list available instance types",
                    "Try a specific size like '8xh100' or '4xa100'",
                ],
            )

        # Check availability for all candidate instance types and combine by cheapest per region
        combined: dict[str, Auction] = {}
        type_for_region: dict[str, str] = {}
        regions_seen: set[str] = set()
        for fid in candidate_type_ids:
            availability = self._region_selector.check_availability(fid)
            for region, auction in availability.items():
                regions_seen.add(region)
                try:
                    price = self._pricing.parse_price(auction.last_instance_price)
                except Exception:
                    price = float("inf")
                if region not in combined:
                    combined[region] = auction
                    type_for_region[region] = fid
                else:
                    try:
                        existing_price = self._pricing.parse_price(
                            combined[region].last_instance_price
                        )
                    except Exception:
                        existing_price = float("inf")
                    if price < existing_price:
                        combined[region] = auction
                        type_for_region[region] = fid

        # Select best region, honoring explicit preference when present
        selected_region = self._region_selector.select_best_region(combined, config.region)
        if not selected_region:
            regions_checked = sorted(regions_seen)
            raise ResourceNotAvailableError(
                f"No available regions for instance type {instance_type}",
                suggestions=[
                    f"Checked regions: {', '.join(regions_checked) if regions_checked else 'none'}",
                    "Try a different instance type",
                    "Increase your max price limit",
                    "Check back later for availability",
                ],
            )

        auction = combined.get(selected_region)
        instance_type_id = type_for_region.get(selected_region, candidate_type_ids[0])
        return selected_region, instance_type_id, auction

    def submit_bid(
        self,
        config: TaskConfig,
        *,
        region: str,
        instance_type_id: str,
        project_id: str | None = None,
        ssh_keys: list[str] | None = None,
        startup_script: str | None = None,
        volume_attachments: list[dict[str, Any]] | None = None,
        auction_id: str | None = None,
    ) -> Any:
        bid_spec = BidBuilder.build_specification(
            config=config,
            project_id=project_id or self._get_project_id(),
            region=region,
            auction_id=auction_id,
            instance_type_id=instance_type_id,
            ssh_keys=ssh_keys or [],
            startup_script=startup_script,
            volume_attachments=volume_attachments or [],
        )
        return self._api.create_bid(bid_spec.to_api_payload())
