"""A Dakota optimizer plugin for ropt."""
