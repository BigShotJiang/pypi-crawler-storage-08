"""Act I spells package — register available spells for the act."""
