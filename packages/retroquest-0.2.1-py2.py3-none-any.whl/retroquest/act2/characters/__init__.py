"""
Characters for Act II: Greendale & The Forest Edge

This module contains all character classes for Act II, including:
- Sir Cedric (Knight seeking redemption)
- Master Healer Lyria (Healing mentor)
- Nyx (Forest sprite and ultimate teacher)
- Innkeeper Marcus & Barmaid Elena (Cursed family)
- Various merchants, guards, and forest spirits
"""
