"""
Act II: Greendale & The Forest Edge

This package contains all the components for Act II of RetroQuest, including
characters, items, quests, rooms, and spells specific to the Greendale and
Enchanted Forest storyline.
"""
