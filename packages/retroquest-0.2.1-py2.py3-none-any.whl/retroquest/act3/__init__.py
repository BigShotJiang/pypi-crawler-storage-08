"""Act 3: The Awakening - Final act of RetroQuest."""

from .Act3 import Act3

__all__ = ["Act3"]
