"""Top-level package for retroquest."""

__author__ = """Henrik Kurelid"""
__email__ = 'henrik@kurelid.se'
__version__ = '0.1.0'
