"""Textual-based UI components for RetroQuest (panels, controller, app shell)."""
