"""Prompt-based UI components for RetroQuest terminal interface."""
