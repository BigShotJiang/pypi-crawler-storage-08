__Dataset__
: collection of _files_. Described by metadata that follows its project's conventions.

__Facet__
: basic element of a dataset's _metadata_. Pair of strings in the form `name:value`, equivalent to a python dictionary's item.

__Plugin__
: custom code that extends `esgpull` functionality by responding to specific events.
