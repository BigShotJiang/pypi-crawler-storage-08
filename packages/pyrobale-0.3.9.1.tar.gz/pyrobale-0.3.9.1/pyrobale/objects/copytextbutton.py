class CopyTextButton:
    """Represents a copy text button."""

    def __init__(self, text: str, **kwargs):
        self.text = text
