class WebAppData:
    def __init__(self, data: str):
        self.data = data
