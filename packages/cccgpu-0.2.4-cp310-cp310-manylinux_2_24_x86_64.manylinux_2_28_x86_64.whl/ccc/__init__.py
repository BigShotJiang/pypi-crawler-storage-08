from __future__ import annotations

# Remember to change also setup.py with the version here
__version__ = "0.2.2"
