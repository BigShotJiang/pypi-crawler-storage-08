from .router import UIBase
class pages(UIBase): pass