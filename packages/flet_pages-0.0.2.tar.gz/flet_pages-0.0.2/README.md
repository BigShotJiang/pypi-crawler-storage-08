# Flet-Pages
基于Flet的应用程序开发框架

## 运行测试应用

要运行位于 `flet_pages/tests/` 目录下的测试应用，请使用以下命令：

```bash
flet run flet_pages/tests/main.py
```
