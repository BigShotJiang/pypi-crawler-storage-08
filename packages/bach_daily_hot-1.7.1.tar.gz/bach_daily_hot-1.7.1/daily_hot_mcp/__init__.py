"""Daily Hot MCP - 基于 Model Context Protocol 协议的全网热点趋势一站式聚合服务"""

__version__ = "1.6.3" 