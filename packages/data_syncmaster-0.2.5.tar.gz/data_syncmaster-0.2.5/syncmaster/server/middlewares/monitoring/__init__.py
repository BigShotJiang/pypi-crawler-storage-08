# SPDX-FileCopyrightText: 2023-2024 MTS PJSC
# SPDX-License-Identifier: Apache-2.0
from syncmaster.server.middlewares.monitoring.metrics import (
    apply_monitoring_metrics_middleware,
)

__all__ = ["apply_monitoring_metrics_middleware"]
