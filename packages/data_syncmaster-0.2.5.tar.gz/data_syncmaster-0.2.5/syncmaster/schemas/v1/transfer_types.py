# SPDX-FileCopyrightText: 2023-2024 MTS PJSC
# SPDX-License-Identifier: Apache-2.0
from typing import Literal

FULL_TYPE = Literal["full"]
INCREMENTAL_TYPE = Literal["incremental"]
