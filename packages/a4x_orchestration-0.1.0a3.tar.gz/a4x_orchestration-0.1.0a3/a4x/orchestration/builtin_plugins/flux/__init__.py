# Copyright 2025 Global Computing Lab.
# See top-level COPYRIGHT file for details.
# 
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception

from a4x.orchestration.builtin_plugins.flux.flux_plugin import FluxPlugin
