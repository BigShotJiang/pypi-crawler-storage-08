.. py:currentmodule:: rubin_scheduler.scheduler

.. _fbs-api-schedulers:

Schedulers
^^^^^^^^^^

.. automodule:: rubin_scheduler.scheduler.schedulers
    :imported-members:
    :members:
    :show-inheritance:
