class FileExistsError(Exception):
    pass
