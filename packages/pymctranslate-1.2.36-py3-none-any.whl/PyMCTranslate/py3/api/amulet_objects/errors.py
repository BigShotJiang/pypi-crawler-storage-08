class BlockException(Exception):
    pass


class ChunkLoadError(Exception):
    pass
