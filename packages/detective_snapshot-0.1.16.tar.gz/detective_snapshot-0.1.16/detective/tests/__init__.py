"""Test suite for detective-snapshot package."""
