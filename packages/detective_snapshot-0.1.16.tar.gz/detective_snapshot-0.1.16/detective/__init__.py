"""
detective-snapshot
~~~~~~~~~~~~~~~~

A Python package for capturing and comparing function input/output snapshots.
"""

from .snapshot import snapshot

__version__ = "0.1.0"
__all__ = ["snapshot"]
