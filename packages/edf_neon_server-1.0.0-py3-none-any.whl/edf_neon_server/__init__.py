"""Neon server module"""
