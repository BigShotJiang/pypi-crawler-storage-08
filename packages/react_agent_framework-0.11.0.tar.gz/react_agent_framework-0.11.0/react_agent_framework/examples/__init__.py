"""
Exemplos de uso do ReAct Agent Framework
"""
