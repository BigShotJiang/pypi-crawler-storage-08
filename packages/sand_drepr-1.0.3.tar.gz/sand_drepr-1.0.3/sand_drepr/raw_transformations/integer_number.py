try:
    value = value.strip()
    return int(value)
except:
    return value
