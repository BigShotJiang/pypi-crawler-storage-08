Note: this directory contains only type hints for Pedalboard's native C++ bindings.
The contents of this directory are automatically updated by running:

```
python3 -m scripts.generate_type_stubs_and_docs
```
