from packg.paths import print_all_environment_variables


def main():
    print_all_environment_variables()


if __name__ == "__main__":
    main()
