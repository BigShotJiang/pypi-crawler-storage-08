"""
Tests for microtrax
"""
