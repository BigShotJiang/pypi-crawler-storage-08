# QA Tool

quality assurance tool by EMPA for ACTRIS

https://voc-qc.nilu.no/

## API

```{eval-rst}
.. autofunction:: avoca.bindings.qa_tool.export_EmpaQATool
```
