"""Tests for core HTTP clients."""
