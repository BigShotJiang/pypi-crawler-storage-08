"""Core HTTP client functionality."""

from pytentacle.core.base import BaseClient

__all__ = ["BaseClient"]
