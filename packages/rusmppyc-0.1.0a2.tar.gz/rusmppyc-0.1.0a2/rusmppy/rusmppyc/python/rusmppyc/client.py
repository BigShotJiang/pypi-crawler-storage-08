# rusmppyc/client.py

from .rusmppyc import Client  # type: ignore

__all__ = ["Client"]
