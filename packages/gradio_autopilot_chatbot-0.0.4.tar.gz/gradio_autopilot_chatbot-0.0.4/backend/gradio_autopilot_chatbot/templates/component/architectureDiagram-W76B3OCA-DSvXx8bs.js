import { _ as dt, H as ke, V as Ze, l as Re, b as qe, a as Qe, p as Je, q as Ke, g as je, s as _e, y as tr, D as er, E as rr, F as ir, c as ye, ak as Ee, aI as ve, i as ar, d as nr, aJ as or, aK as sr } from "./mermaid.core-CmzLYPfL.js";
import { p as hr } from "./chunk-4BX2VUAB-DwVPPsbL.js";
import { p as lr } from "./treemap-75Q7IDZK-Cuy31_WJ.js";
import { c as Se } from "./cytoscape.esm-ZmItrg9y.js";
import { c as me, g as fr } from "./Index-BpWUvslZ.js";
var Fe = { exports: {} }, ue = { exports: {} }, de = { exports: {} }, we;
function cr() {
  return we || (we = 1, function(I, D) {
    (function(P, N) {
      I.exports = N();
    })(me, function() {
      return (
        /******/
        function(A) {
          var P = {};
          function N(u) {
            if (P[u])
              return P[u].exports;
            var l = P[u] = {
              /******/
              i: u,
              /******/
              l: !1,
              /******/
              exports: {}
              /******/
            };
            return A[u].call(l.exports, l, l.exports, N), l.l = !0, l.exports;
          }
          return N.m = A, N.c = P, N.i = function(u) {
            return u;
          }, N.d = function(u, l, a) {
            N.o(u, l) || Object.defineProperty(u, l, {
              /******/
              configurable: !1,
              /******/
              enumerable: !0,
              /******/
              get: a
              /******/
            });
          }, N.n = function(u) {
            var l = u && u.__esModule ? (
              /******/
              function() {
                return u.default;
              }
            ) : (
              /******/
              function() {
                return u;
              }
            );
            return N.d(l, "a", l), l;
          }, N.o = function(u, l) {
            return Object.prototype.hasOwnProperty.call(u, l);
          }, N.p = "", N(N.s = 28);
        }([
          /* 0 */
          /***/
          function(A, P, N) {
            function u() {
            }
            u.QUALITY = 1, u.DEFAULT_CREATE_BENDS_AS_NEEDED = !1, u.DEFAULT_INCREMENTAL = !1, u.DEFAULT_ANIMATION_ON_LAYOUT = !0, u.DEFAULT_ANIMATION_DURING_LAYOUT = !1, u.DEFAULT_ANIMATION_PERIOD = 50, u.DEFAULT_UNIFORM_LEAF_NODE_SIZES = !1, u.DEFAULT_GRAPH_MARGIN = 15, u.NODE_DIMENSIONS_INCLUDE_LABELS = !1, u.SIMPLE_NODE_SIZE = 40, u.SIMPLE_NODE_HALF_SIZE = u.SIMPLE_NODE_SIZE / 2, u.EMPTY_COMPOUND_NODE_SIZE = 40, u.MIN_EDGE_LENGTH = 1, u.WORLD_BOUNDARY = 1e6, u.INITIAL_WORLD_BOUNDARY = u.WORLD_BOUNDARY / 1e3, u.WORLD_CENTER_X = 1200, u.WORLD_CENTER_Y = 900, A.exports = u;
          },
          /* 1 */
          /***/
          function(A, P, N) {
            var u = N(2), l = N(8), a = N(9);
            function e(f, i, g) {
              u.call(this, g), this.isOverlapingSourceAndTarget = !1, this.vGraphObject = g, this.bendpoints = [], this.source = f, this.target = i;
            }
            e.prototype = Object.create(u.prototype);
            for (var r in u)
              e[r] = u[r];
            e.prototype.getSource = function() {
              return this.source;
            }, e.prototype.getTarget = function() {
              return this.target;
            }, e.prototype.isInterGraph = function() {
              return this.isInterGraph;
            }, e.prototype.getLength = function() {
              return this.length;
            }, e.prototype.isOverlapingSourceAndTarget = function() {
              return this.isOverlapingSourceAndTarget;
            }, e.prototype.getBendpoints = function() {
              return this.bendpoints;
            }, e.prototype.getLca = function() {
              return this.lca;
            }, e.prototype.getSourceInLca = function() {
              return this.sourceInLca;
            }, e.prototype.getTargetInLca = function() {
              return this.targetInLca;
            }, e.prototype.getOtherEnd = function(f) {
              if (this.source === f)
                return this.target;
              if (this.target === f)
                return this.source;
              throw "Node is not incident with this edge";
            }, e.prototype.getOtherEndInGraph = function(f, i) {
              for (var g = this.getOtherEnd(f), t = i.getGraphManager().getRoot(); ; ) {
                if (g.getOwner() == i)
                  return g;
                if (g.getOwner() == t)
                  break;
                g = g.getOwner().getParent();
              }
              return null;
            }, e.prototype.updateLength = function() {
              var f = new Array(4);
              this.isOverlapingSourceAndTarget = l.getIntersection(this.target.getRect(), this.source.getRect(), f), this.isOverlapingSourceAndTarget || (this.lengthX = f[0] - f[2], this.lengthY = f[1] - f[3], Math.abs(this.lengthX) < 1 && (this.lengthX = a.sign(this.lengthX)), Math.abs(this.lengthY) < 1 && (this.lengthY = a.sign(this.lengthY)), this.length = Math.sqrt(this.lengthX * this.lengthX + this.lengthY * this.lengthY));
            }, e.prototype.updateLengthSimple = function() {
              this.lengthX = this.target.getCenterX() - this.source.getCenterX(), this.lengthY = this.target.getCenterY() - this.source.getCenterY(), Math.abs(this.lengthX) < 1 && (this.lengthX = a.sign(this.lengthX)), Math.abs(this.lengthY) < 1 && (this.lengthY = a.sign(this.lengthY)), this.length = Math.sqrt(this.lengthX * this.lengthX + this.lengthY * this.lengthY);
            }, A.exports = e;
          },
          /* 2 */
          /***/
          function(A, P, N) {
            function u(l) {
              this.vGraphObject = l;
            }
            A.exports = u;
          },
          /* 3 */
          /***/
          function(A, P, N) {
            var u = N(2), l = N(10), a = N(13), e = N(0), r = N(16), f = N(5);
            function i(t, s, o, c) {
              o == null && c == null && (c = s), u.call(this, c), t.graphManager != null && (t = t.graphManager), this.estimatedSize = l.MIN_VALUE, this.inclusionTreeDepth = l.MAX_VALUE, this.vGraphObject = c, this.edges = [], this.graphManager = t, o != null && s != null ? this.rect = new a(s.x, s.y, o.width, o.height) : this.rect = new a();
            }
            i.prototype = Object.create(u.prototype);
            for (var g in u)
              i[g] = u[g];
            i.prototype.getEdges = function() {
              return this.edges;
            }, i.prototype.getChild = function() {
              return this.child;
            }, i.prototype.getOwner = function() {
              return this.owner;
            }, i.prototype.getWidth = function() {
              return this.rect.width;
            }, i.prototype.setWidth = function(t) {
              this.rect.width = t;
            }, i.prototype.getHeight = function() {
              return this.rect.height;
            }, i.prototype.setHeight = function(t) {
              this.rect.height = t;
            }, i.prototype.getCenterX = function() {
              return this.rect.x + this.rect.width / 2;
            }, i.prototype.getCenterY = function() {
              return this.rect.y + this.rect.height / 2;
            }, i.prototype.getCenter = function() {
              return new f(this.rect.x + this.rect.width / 2, this.rect.y + this.rect.height / 2);
            }, i.prototype.getLocation = function() {
              return new f(this.rect.x, this.rect.y);
            }, i.prototype.getRect = function() {
              return this.rect;
            }, i.prototype.getDiagonal = function() {
              return Math.sqrt(this.rect.width * this.rect.width + this.rect.height * this.rect.height);
            }, i.prototype.getHalfTheDiagonal = function() {
              return Math.sqrt(this.rect.height * this.rect.height + this.rect.width * this.rect.width) / 2;
            }, i.prototype.setRect = function(t, s) {
              this.rect.x = t.x, this.rect.y = t.y, this.rect.width = s.width, this.rect.height = s.height;
            }, i.prototype.setCenter = function(t, s) {
              this.rect.x = t - this.rect.width / 2, this.rect.y = s - this.rect.height / 2;
            }, i.prototype.setLocation = function(t, s) {
              this.rect.x = t, this.rect.y = s;
            }, i.prototype.moveBy = function(t, s) {
              this.rect.x += t, this.rect.y += s;
            }, i.prototype.getEdgeListToNode = function(t) {
              var s = [], o = this;
              return o.edges.forEach(function(c) {
                if (c.target == t) {
                  if (c.source != o) throw "Incorrect edge source!";
                  s.push(c);
                }
              }), s;
            }, i.prototype.getEdgesBetween = function(t) {
              var s = [], o = this;
              return o.edges.forEach(function(c) {
                if (!(c.source == o || c.target == o)) throw "Incorrect edge source and/or target";
                (c.target == t || c.source == t) && s.push(c);
              }), s;
            }, i.prototype.getNeighborsList = function() {
              var t = /* @__PURE__ */ new Set(), s = this;
              return s.edges.forEach(function(o) {
                if (o.source == s)
                  t.add(o.target);
                else {
                  if (o.target != s)
                    throw "Incorrect incidency!";
                  t.add(o.source);
                }
              }), t;
            }, i.prototype.withChildren = function() {
              var t = /* @__PURE__ */ new Set(), s, o;
              if (t.add(this), this.child != null)
                for (var c = this.child.getNodes(), h = 0; h < c.length; h++)
                  s = c[h], o = s.withChildren(), o.forEach(function(T) {
                    t.add(T);
                  });
              return t;
            }, i.prototype.getNoOfChildren = function() {
              var t = 0, s;
              if (this.child == null)
                t = 1;
              else
                for (var o = this.child.getNodes(), c = 0; c < o.length; c++)
                  s = o[c], t += s.getNoOfChildren();
              return t == 0 && (t = 1), t;
            }, i.prototype.getEstimatedSize = function() {
              if (this.estimatedSize == l.MIN_VALUE)
                throw "assert failed";
              return this.estimatedSize;
            }, i.prototype.calcEstimatedSize = function() {
              return this.child == null ? this.estimatedSize = (this.rect.width + this.rect.height) / 2 : (this.estimatedSize = this.child.calcEstimatedSize(), this.rect.width = this.estimatedSize, this.rect.height = this.estimatedSize, this.estimatedSize);
            }, i.prototype.scatter = function() {
              var t, s, o = -e.INITIAL_WORLD_BOUNDARY, c = e.INITIAL_WORLD_BOUNDARY;
              t = e.WORLD_CENTER_X + r.nextDouble() * (c - o) + o;
              var h = -e.INITIAL_WORLD_BOUNDARY, T = e.INITIAL_WORLD_BOUNDARY;
              s = e.WORLD_CENTER_Y + r.nextDouble() * (T - h) + h, this.rect.x = t, this.rect.y = s;
            }, i.prototype.updateBounds = function() {
              if (this.getChild() == null)
                throw "assert failed";
              if (this.getChild().getNodes().length != 0) {
                var t = this.getChild();
                if (t.updateBounds(!0), this.rect.x = t.getLeft(), this.rect.y = t.getTop(), this.setWidth(t.getRight() - t.getLeft()), this.setHeight(t.getBottom() - t.getTop()), e.NODE_DIMENSIONS_INCLUDE_LABELS) {
                  var s = t.getRight() - t.getLeft(), o = t.getBottom() - t.getTop();
                  this.labelWidth && (this.labelPosHorizontal == "left" ? (this.rect.x -= this.labelWidth, this.setWidth(s + this.labelWidth)) : this.labelPosHorizontal == "center" && this.labelWidth > s ? (this.rect.x -= (this.labelWidth - s) / 2, this.setWidth(this.labelWidth)) : this.labelPosHorizontal == "right" && this.setWidth(s + this.labelWidth)), this.labelHeight && (this.labelPosVertical == "top" ? (this.rect.y -= this.labelHeight, this.setHeight(o + this.labelHeight)) : this.labelPosVertical == "center" && this.labelHeight > o ? (this.rect.y -= (this.labelHeight - o) / 2, this.setHeight(this.labelHeight)) : this.labelPosVertical == "bottom" && this.setHeight(o + this.labelHeight));
                }
              }
            }, i.prototype.getInclusionTreeDepth = function() {
              if (this.inclusionTreeDepth == l.MAX_VALUE)
                throw "assert failed";
              return this.inclusionTreeDepth;
            }, i.prototype.transform = function(t) {
              var s = this.rect.x;
              s > e.WORLD_BOUNDARY ? s = e.WORLD_BOUNDARY : s < -e.WORLD_BOUNDARY && (s = -e.WORLD_BOUNDARY);
              var o = this.rect.y;
              o > e.WORLD_BOUNDARY ? o = e.WORLD_BOUNDARY : o < -e.WORLD_BOUNDARY && (o = -e.WORLD_BOUNDARY);
              var c = new f(s, o), h = t.inverseTransformPoint(c);
              this.setLocation(h.x, h.y);
            }, i.prototype.getLeft = function() {
              return this.rect.x;
            }, i.prototype.getRight = function() {
              return this.rect.x + this.rect.width;
            }, i.prototype.getTop = function() {
              return this.rect.y;
            }, i.prototype.getBottom = function() {
              return this.rect.y + this.rect.height;
            }, i.prototype.getParent = function() {
              return this.owner == null ? null : this.owner.getParent();
            }, A.exports = i;
          },
          /* 4 */
          /***/
          function(A, P, N) {
            var u = N(0);
            function l() {
            }
            for (var a in u)
              l[a] = u[a];
            l.MAX_ITERATIONS = 2500, l.DEFAULT_EDGE_LENGTH = 50, l.DEFAULT_SPRING_STRENGTH = 0.45, l.DEFAULT_REPULSION_STRENGTH = 4500, l.DEFAULT_GRAVITY_STRENGTH = 0.4, l.DEFAULT_COMPOUND_GRAVITY_STRENGTH = 1, l.DEFAULT_GRAVITY_RANGE_FACTOR = 3.8, l.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = 1.5, l.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION = !0, l.DEFAULT_USE_SMART_REPULSION_RANGE_CALCULATION = !0, l.DEFAULT_COOLING_FACTOR_INCREMENTAL = 0.3, l.COOLING_ADAPTATION_FACTOR = 0.33, l.ADAPTATION_LOWER_NODE_LIMIT = 1e3, l.ADAPTATION_UPPER_NODE_LIMIT = 5e3, l.MAX_NODE_DISPLACEMENT_INCREMENTAL = 100, l.MAX_NODE_DISPLACEMENT = l.MAX_NODE_DISPLACEMENT_INCREMENTAL * 3, l.MIN_REPULSION_DIST = l.DEFAULT_EDGE_LENGTH / 10, l.CONVERGENCE_CHECK_PERIOD = 100, l.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = 0.1, l.MIN_EDGE_LENGTH = 1, l.GRID_CALCULATION_CHECK_PERIOD = 10, A.exports = l;
          },
          /* 5 */
          /***/
          function(A, P, N) {
            function u(l, a) {
              l == null && a == null ? (this.x = 0, this.y = 0) : (this.x = l, this.y = a);
            }
            u.prototype.getX = function() {
              return this.x;
            }, u.prototype.getY = function() {
              return this.y;
            }, u.prototype.setX = function(l) {
              this.x = l;
            }, u.prototype.setY = function(l) {
              this.y = l;
            }, u.prototype.getDifference = function(l) {
              return new DimensionD(this.x - l.x, this.y - l.y);
            }, u.prototype.getCopy = function() {
              return new u(this.x, this.y);
            }, u.prototype.translate = function(l) {
              return this.x += l.width, this.y += l.height, this;
            }, A.exports = u;
          },
          /* 6 */
          /***/
          function(A, P, N) {
            var u = N(2), l = N(10), a = N(0), e = N(7), r = N(3), f = N(1), i = N(13), g = N(12), t = N(11);
            function s(c, h, T) {
              u.call(this, T), this.estimatedSize = l.MIN_VALUE, this.margin = a.DEFAULT_GRAPH_MARGIN, this.edges = [], this.nodes = [], this.isConnected = !1, this.parent = c, h != null && h instanceof e ? this.graphManager = h : h != null && h instanceof Layout && (this.graphManager = h.graphManager);
            }
            s.prototype = Object.create(u.prototype);
            for (var o in u)
              s[o] = u[o];
            s.prototype.getNodes = function() {
              return this.nodes;
            }, s.prototype.getEdges = function() {
              return this.edges;
            }, s.prototype.getGraphManager = function() {
              return this.graphManager;
            }, s.prototype.getParent = function() {
              return this.parent;
            }, s.prototype.getLeft = function() {
              return this.left;
            }, s.prototype.getRight = function() {
              return this.right;
            }, s.prototype.getTop = function() {
              return this.top;
            }, s.prototype.getBottom = function() {
              return this.bottom;
            }, s.prototype.isConnected = function() {
              return this.isConnected;
            }, s.prototype.add = function(c, h, T) {
              if (h == null && T == null) {
                var d = c;
                if (this.graphManager == null)
                  throw "Graph has no graph mgr!";
                if (this.getNodes().indexOf(d) > -1)
                  throw "Node already in graph!";
                return d.owner = this, this.getNodes().push(d), d;
              } else {
                var v = c;
                if (!(this.getNodes().indexOf(h) > -1 && this.getNodes().indexOf(T) > -1))
                  throw "Source or target not in graph!";
                if (!(h.owner == T.owner && h.owner == this))
                  throw "Both owners must be this graph!";
                return h.owner != T.owner ? null : (v.source = h, v.target = T, v.isInterGraph = !1, this.getEdges().push(v), h.edges.push(v), T != h && T.edges.push(v), v);
              }
            }, s.prototype.remove = function(c) {
              var h = c;
              if (c instanceof r) {
                if (h == null)
                  throw "Node is null!";
                if (!(h.owner != null && h.owner == this))
                  throw "Owner graph is invalid!";
                if (this.graphManager == null)
                  throw "Owner graph manager is invalid!";
                for (var T = h.edges.slice(), d, v = T.length, L = 0; L < v; L++)
                  d = T[L], d.isInterGraph ? this.graphManager.remove(d) : d.source.owner.remove(d);
                var S = this.nodes.indexOf(h);
                if (S == -1)
                  throw "Node not in owner node list!";
                this.nodes.splice(S, 1);
              } else if (c instanceof f) {
                var d = c;
                if (d == null)
                  throw "Edge is null!";
                if (!(d.source != null && d.target != null))
                  throw "Source and/or target is null!";
                if (!(d.source.owner != null && d.target.owner != null && d.source.owner == this && d.target.owner == this))
                  throw "Source and/or target owner is invalid!";
                var C = d.source.edges.indexOf(d), G = d.target.edges.indexOf(d);
                if (!(C > -1 && G > -1))
                  throw "Source and/or target doesn't know this edge!";
                d.source.edges.splice(C, 1), d.target != d.source && d.target.edges.splice(G, 1);
                var S = d.source.owner.getEdges().indexOf(d);
                if (S == -1)
                  throw "Not in owner's edge list!";
                d.source.owner.getEdges().splice(S, 1);
              }
            }, s.prototype.updateLeftTop = function() {
              for (var c = l.MAX_VALUE, h = l.MAX_VALUE, T, d, v, L = this.getNodes(), S = L.length, C = 0; C < S; C++) {
                var G = L[C];
                T = G.getTop(), d = G.getLeft(), c > T && (c = T), h > d && (h = d);
              }
              return c == l.MAX_VALUE ? null : (L[0].getParent().paddingLeft != null ? v = L[0].getParent().paddingLeft : v = this.margin, this.left = h - v, this.top = c - v, new g(this.left, this.top));
            }, s.prototype.updateBounds = function(c) {
              for (var h = l.MAX_VALUE, T = -l.MAX_VALUE, d = l.MAX_VALUE, v = -l.MAX_VALUE, L, S, C, G, K, X = this.nodes, Q = X.length, O = 0; O < Q; O++) {
                var rt = X[O];
                c && rt.child != null && rt.updateBounds(), L = rt.getLeft(), S = rt.getRight(), C = rt.getTop(), G = rt.getBottom(), h > L && (h = L), T < S && (T = S), d > C && (d = C), v < G && (v = G);
              }
              var n = new i(h, d, T - h, v - d);
              h == l.MAX_VALUE && (this.left = this.parent.getLeft(), this.right = this.parent.getRight(), this.top = this.parent.getTop(), this.bottom = this.parent.getBottom()), X[0].getParent().paddingLeft != null ? K = X[0].getParent().paddingLeft : K = this.margin, this.left = n.x - K, this.right = n.x + n.width + K, this.top = n.y - K, this.bottom = n.y + n.height + K;
            }, s.calculateBounds = function(c) {
              for (var h = l.MAX_VALUE, T = -l.MAX_VALUE, d = l.MAX_VALUE, v = -l.MAX_VALUE, L, S, C, G, K = c.length, X = 0; X < K; X++) {
                var Q = c[X];
                L = Q.getLeft(), S = Q.getRight(), C = Q.getTop(), G = Q.getBottom(), h > L && (h = L), T < S && (T = S), d > C && (d = C), v < G && (v = G);
              }
              var O = new i(h, d, T - h, v - d);
              return O;
            }, s.prototype.getInclusionTreeDepth = function() {
              return this == this.graphManager.getRoot() ? 1 : this.parent.getInclusionTreeDepth();
            }, s.prototype.getEstimatedSize = function() {
              if (this.estimatedSize == l.MIN_VALUE)
                throw "assert failed";
              return this.estimatedSize;
            }, s.prototype.calcEstimatedSize = function() {
              for (var c = 0, h = this.nodes, T = h.length, d = 0; d < T; d++) {
                var v = h[d];
                c += v.calcEstimatedSize();
              }
              return c == 0 ? this.estimatedSize = a.EMPTY_COMPOUND_NODE_SIZE : this.estimatedSize = c / Math.sqrt(this.nodes.length), this.estimatedSize;
            }, s.prototype.updateConnected = function() {
              var c = this;
              if (this.nodes.length == 0) {
                this.isConnected = !0;
                return;
              }
              var h = new t(), T = /* @__PURE__ */ new Set(), d = this.nodes[0], v, L, S = d.withChildren();
              for (S.forEach(function(O) {
                h.push(O), T.add(O);
              }); h.length !== 0; ) {
                d = h.shift(), v = d.getEdges();
                for (var C = v.length, G = 0; G < C; G++) {
                  var K = v[G];
                  if (L = K.getOtherEndInGraph(d, this), L != null && !T.has(L)) {
                    var X = L.withChildren();
                    X.forEach(function(O) {
                      h.push(O), T.add(O);
                    });
                  }
                }
              }
              if (this.isConnected = !1, T.size >= this.nodes.length) {
                var Q = 0;
                T.forEach(function(O) {
                  O.owner == c && Q++;
                }), Q == this.nodes.length && (this.isConnected = !0);
              }
            }, A.exports = s;
          },
          /* 7 */
          /***/
          function(A, P, N) {
            var u, l = N(1);
            function a(e) {
              u = N(6), this.layout = e, this.graphs = [], this.edges = [];
            }
            a.prototype.addRoot = function() {
              var e = this.layout.newGraph(), r = this.layout.newNode(null), f = this.add(e, r);
              return this.setRootGraph(f), this.rootGraph;
            }, a.prototype.add = function(e, r, f, i, g) {
              if (f == null && i == null && g == null) {
                if (e == null)
                  throw "Graph is null!";
                if (r == null)
                  throw "Parent node is null!";
                if (this.graphs.indexOf(e) > -1)
                  throw "Graph already in this graph mgr!";
                if (this.graphs.push(e), e.parent != null)
                  throw "Already has a parent!";
                if (r.child != null)
                  throw "Already has a child!";
                return e.parent = r, r.child = e, e;
              } else {
                g = f, i = r, f = e;
                var t = i.getOwner(), s = g.getOwner();
                if (!(t != null && t.getGraphManager() == this))
                  throw "Source not in this graph mgr!";
                if (!(s != null && s.getGraphManager() == this))
                  throw "Target not in this graph mgr!";
                if (t == s)
                  return f.isInterGraph = !1, t.add(f, i, g);
                if (f.isInterGraph = !0, f.source = i, f.target = g, this.edges.indexOf(f) > -1)
                  throw "Edge already in inter-graph edge list!";
                if (this.edges.push(f), !(f.source != null && f.target != null))
                  throw "Edge source and/or target is null!";
                if (!(f.source.edges.indexOf(f) == -1 && f.target.edges.indexOf(f) == -1))
                  throw "Edge already in source and/or target incidency list!";
                return f.source.edges.push(f), f.target.edges.push(f), f;
              }
            }, a.prototype.remove = function(e) {
              if (e instanceof u) {
                var r = e;
                if (r.getGraphManager() != this)
                  throw "Graph not in this graph mgr";
                if (!(r == this.rootGraph || r.parent != null && r.parent.graphManager == this))
                  throw "Invalid parent node!";
                var f = [];
                f = f.concat(r.getEdges());
                for (var i, g = f.length, t = 0; t < g; t++)
                  i = f[t], r.remove(i);
                var s = [];
                s = s.concat(r.getNodes());
                var o;
                g = s.length;
                for (var t = 0; t < g; t++)
                  o = s[t], r.remove(o);
                r == this.rootGraph && this.setRootGraph(null);
                var c = this.graphs.indexOf(r);
                this.graphs.splice(c, 1), r.parent = null;
              } else if (e instanceof l) {
                if (i = e, i == null)
                  throw "Edge is null!";
                if (!i.isInterGraph)
                  throw "Not an inter-graph edge!";
                if (!(i.source != null && i.target != null))
                  throw "Source and/or target is null!";
                if (!(i.source.edges.indexOf(i) != -1 && i.target.edges.indexOf(i) != -1))
                  throw "Source and/or target doesn't know this edge!";
                var c = i.source.edges.indexOf(i);
                if (i.source.edges.splice(c, 1), c = i.target.edges.indexOf(i), i.target.edges.splice(c, 1), !(i.source.owner != null && i.source.owner.getGraphManager() != null))
                  throw "Edge owner graph or owner graph manager is null!";
                if (i.source.owner.getGraphManager().edges.indexOf(i) == -1)
                  throw "Not in owner graph manager's edge list!";
                var c = i.source.owner.getGraphManager().edges.indexOf(i);
                i.source.owner.getGraphManager().edges.splice(c, 1);
              }
            }, a.prototype.updateBounds = function() {
              this.rootGraph.updateBounds(!0);
            }, a.prototype.getGraphs = function() {
              return this.graphs;
            }, a.prototype.getAllNodes = function() {
              if (this.allNodes == null) {
                for (var e = [], r = this.getGraphs(), f = r.length, i = 0; i < f; i++)
                  e = e.concat(r[i].getNodes());
                this.allNodes = e;
              }
              return this.allNodes;
            }, a.prototype.resetAllNodes = function() {
              this.allNodes = null;
            }, a.prototype.resetAllEdges = function() {
              this.allEdges = null;
            }, a.prototype.resetAllNodesToApplyGravitation = function() {
              this.allNodesToApplyGravitation = null;
            }, a.prototype.getAllEdges = function() {
              if (this.allEdges == null) {
                var e = [], r = this.getGraphs();
                r.length;
                for (var f = 0; f < r.length; f++)
                  e = e.concat(r[f].getEdges());
                e = e.concat(this.edges), this.allEdges = e;
              }
              return this.allEdges;
            }, a.prototype.getAllNodesToApplyGravitation = function() {
              return this.allNodesToApplyGravitation;
            }, a.prototype.setAllNodesToApplyGravitation = function(e) {
              if (this.allNodesToApplyGravitation != null)
                throw "assert failed";
              this.allNodesToApplyGravitation = e;
            }, a.prototype.getRoot = function() {
              return this.rootGraph;
            }, a.prototype.setRootGraph = function(e) {
              if (e.getGraphManager() != this)
                throw "Root not in this graph mgr!";
              this.rootGraph = e, e.parent == null && (e.parent = this.layout.newNode("Root node"));
            }, a.prototype.getLayout = function() {
              return this.layout;
            }, a.prototype.isOneAncestorOfOther = function(e, r) {
              if (!(e != null && r != null))
                throw "assert failed";
              if (e == r)
                return !0;
              var f = e.getOwner(), i;
              do {
                if (i = f.getParent(), i == null)
                  break;
                if (i == r)
                  return !0;
                if (f = i.getOwner(), f == null)
                  break;
              } while (!0);
              f = r.getOwner();
              do {
                if (i = f.getParent(), i == null)
                  break;
                if (i == e)
                  return !0;
                if (f = i.getOwner(), f == null)
                  break;
              } while (!0);
              return !1;
            }, a.prototype.calcLowestCommonAncestors = function() {
              for (var e, r, f, i, g, t = this.getAllEdges(), s = t.length, o = 0; o < s; o++) {
                if (e = t[o], r = e.source, f = e.target, e.lca = null, e.sourceInLca = r, e.targetInLca = f, r == f) {
                  e.lca = r.getOwner();
                  continue;
                }
                for (i = r.getOwner(); e.lca == null; ) {
                  for (e.targetInLca = f, g = f.getOwner(); e.lca == null; ) {
                    if (g == i) {
                      e.lca = g;
                      break;
                    }
                    if (g == this.rootGraph)
                      break;
                    if (e.lca != null)
                      throw "assert failed";
                    e.targetInLca = g.getParent(), g = e.targetInLca.getOwner();
                  }
                  if (i == this.rootGraph)
                    break;
                  e.lca == null && (e.sourceInLca = i.getParent(), i = e.sourceInLca.getOwner());
                }
                if (e.lca == null)
                  throw "assert failed";
              }
            }, a.prototype.calcLowestCommonAncestor = function(e, r) {
              if (e == r)
                return e.getOwner();
              var f = e.getOwner();
              do {
                if (f == null)
                  break;
                var i = r.getOwner();
                do {
                  if (i == null)
                    break;
                  if (i == f)
                    return i;
                  i = i.getParent().getOwner();
                } while (!0);
                f = f.getParent().getOwner();
              } while (!0);
              return f;
            }, a.prototype.calcInclusionTreeDepths = function(e, r) {
              e == null && r == null && (e = this.rootGraph, r = 1);
              for (var f, i = e.getNodes(), g = i.length, t = 0; t < g; t++)
                f = i[t], f.inclusionTreeDepth = r, f.child != null && this.calcInclusionTreeDepths(f.child, r + 1);
            }, a.prototype.includesInvalidEdge = function() {
              for (var e, r = [], f = this.edges.length, i = 0; i < f; i++)
                e = this.edges[i], this.isOneAncestorOfOther(e.source, e.target) && r.push(e);
              for (var i = 0; i < r.length; i++)
                this.remove(r[i]);
              return !1;
            }, A.exports = a;
          },
          /* 8 */
          /***/
          function(A, P, N) {
            var u = N(12);
            function l() {
            }
            l.calcSeparationAmount = function(a, e, r, f) {
              if (!a.intersects(e))
                throw "assert failed";
              var i = new Array(2);
              this.decideDirectionsForOverlappingNodes(a, e, i), r[0] = Math.min(a.getRight(), e.getRight()) - Math.max(a.x, e.x), r[1] = Math.min(a.getBottom(), e.getBottom()) - Math.max(a.y, e.y), a.getX() <= e.getX() && a.getRight() >= e.getRight() ? r[0] += Math.min(e.getX() - a.getX(), a.getRight() - e.getRight()) : e.getX() <= a.getX() && e.getRight() >= a.getRight() && (r[0] += Math.min(a.getX() - e.getX(), e.getRight() - a.getRight())), a.getY() <= e.getY() && a.getBottom() >= e.getBottom() ? r[1] += Math.min(e.getY() - a.getY(), a.getBottom() - e.getBottom()) : e.getY() <= a.getY() && e.getBottom() >= a.getBottom() && (r[1] += Math.min(a.getY() - e.getY(), e.getBottom() - a.getBottom()));
              var g = Math.abs((e.getCenterY() - a.getCenterY()) / (e.getCenterX() - a.getCenterX()));
              e.getCenterY() === a.getCenterY() && e.getCenterX() === a.getCenterX() && (g = 1);
              var t = g * r[0], s = r[1] / g;
              r[0] < s ? s = r[0] : t = r[1], r[0] = -1 * i[0] * (s / 2 + f), r[1] = -1 * i[1] * (t / 2 + f);
            }, l.decideDirectionsForOverlappingNodes = function(a, e, r) {
              a.getCenterX() < e.getCenterX() ? r[0] = -1 : r[0] = 1, a.getCenterY() < e.getCenterY() ? r[1] = -1 : r[1] = 1;
            }, l.getIntersection2 = function(a, e, r) {
              var f = a.getCenterX(), i = a.getCenterY(), g = e.getCenterX(), t = e.getCenterY();
              if (a.intersects(e))
                return r[0] = f, r[1] = i, r[2] = g, r[3] = t, !0;
              var s = a.getX(), o = a.getY(), c = a.getRight(), h = a.getX(), T = a.getBottom(), d = a.getRight(), v = a.getWidthHalf(), L = a.getHeightHalf(), S = e.getX(), C = e.getY(), G = e.getRight(), K = e.getX(), X = e.getBottom(), Q = e.getRight(), O = e.getWidthHalf(), rt = e.getHeightHalf(), n = !1, m = !1;
              if (f === g) {
                if (i > t)
                  return r[0] = f, r[1] = o, r[2] = g, r[3] = X, !1;
                if (i < t)
                  return r[0] = f, r[1] = T, r[2] = g, r[3] = C, !1;
              } else if (i === t) {
                if (f > g)
                  return r[0] = s, r[1] = i, r[2] = G, r[3] = t, !1;
                if (f < g)
                  return r[0] = c, r[1] = i, r[2] = S, r[3] = t, !1;
              } else {
                var p = a.height / a.width, E = e.height / e.width, y = (t - i) / (g - f), R = void 0, M = void 0, F = void 0, W = void 0, x = void 0, Z = void 0;
                if (-p === y ? f > g ? (r[0] = h, r[1] = T, n = !0) : (r[0] = c, r[1] = o, n = !0) : p === y && (f > g ? (r[0] = s, r[1] = o, n = !0) : (r[0] = d, r[1] = T, n = !0)), -E === y ? g > f ? (r[2] = K, r[3] = X, m = !0) : (r[2] = G, r[3] = C, m = !0) : E === y && (g > f ? (r[2] = S, r[3] = C, m = !0) : (r[2] = Q, r[3] = X, m = !0)), n && m)
                  return !1;
                if (f > g ? i > t ? (R = this.getCardinalDirection(p, y, 4), M = this.getCardinalDirection(E, y, 2)) : (R = this.getCardinalDirection(-p, y, 3), M = this.getCardinalDirection(-E, y, 1)) : i > t ? (R = this.getCardinalDirection(-p, y, 1), M = this.getCardinalDirection(-E, y, 3)) : (R = this.getCardinalDirection(p, y, 2), M = this.getCardinalDirection(E, y, 4)), !n)
                  switch (R) {
                    case 1:
                      W = o, F = f + -L / y, r[0] = F, r[1] = W;
                      break;
                    case 2:
                      F = d, W = i + v * y, r[0] = F, r[1] = W;
                      break;
                    case 3:
                      W = T, F = f + L / y, r[0] = F, r[1] = W;
                      break;
                    case 4:
                      F = h, W = i + -v * y, r[0] = F, r[1] = W;
                      break;
                  }
                if (!m)
                  switch (M) {
                    case 1:
                      Z = C, x = g + -rt / y, r[2] = x, r[3] = Z;
                      break;
                    case 2:
                      x = Q, Z = t + O * y, r[2] = x, r[3] = Z;
                      break;
                    case 3:
                      Z = X, x = g + rt / y, r[2] = x, r[3] = Z;
                      break;
                    case 4:
                      x = K, Z = t + -O * y, r[2] = x, r[3] = Z;
                      break;
                  }
              }
              return !1;
            }, l.getCardinalDirection = function(a, e, r) {
              return a > e ? r : 1 + r % 4;
            }, l.getIntersection = function(a, e, r, f) {
              if (f == null)
                return this.getIntersection2(a, e, r);
              var i = a.x, g = a.y, t = e.x, s = e.y, o = r.x, c = r.y, h = f.x, T = f.y, d = void 0, v = void 0, L = void 0, S = void 0, C = void 0, G = void 0, K = void 0, X = void 0, Q = void 0;
              return L = s - g, C = i - t, K = t * g - i * s, S = T - c, G = o - h, X = h * c - o * T, Q = L * G - S * C, Q === 0 ? null : (d = (C * X - G * K) / Q, v = (S * K - L * X) / Q, new u(d, v));
            }, l.angleOfVector = function(a, e, r, f) {
              var i = void 0;
              return a !== r ? (i = Math.atan((f - e) / (r - a)), r < a ? i += Math.PI : f < e && (i += this.TWO_PI)) : f < e ? i = this.ONE_AND_HALF_PI : i = this.HALF_PI, i;
            }, l.doIntersect = function(a, e, r, f) {
              var i = a.x, g = a.y, t = e.x, s = e.y, o = r.x, c = r.y, h = f.x, T = f.y, d = (t - i) * (T - c) - (h - o) * (s - g);
              if (d === 0)
                return !1;
              var v = ((T - c) * (h - i) + (o - h) * (T - g)) / d, L = ((g - s) * (h - i) + (t - i) * (T - g)) / d;
              return 0 < v && v < 1 && 0 < L && L < 1;
            }, l.findCircleLineIntersections = function(a, e, r, f, i, g, t) {
              var s = (r - a) * (r - a) + (f - e) * (f - e), o = 2 * ((a - i) * (r - a) + (e - g) * (f - e)), c = (a - i) * (a - i) + (e - g) * (e - g) - t * t, h = o * o - 4 * s * c;
              if (h >= 0) {
                var T = (-o + Math.sqrt(o * o - 4 * s * c)) / (2 * s), d = (-o - Math.sqrt(o * o - 4 * s * c)) / (2 * s), v = null;
                return T >= 0 && T <= 1 ? [T] : d >= 0 && d <= 1 ? [d] : v;
              } else return null;
            }, l.HALF_PI = 0.5 * Math.PI, l.ONE_AND_HALF_PI = 1.5 * Math.PI, l.TWO_PI = 2 * Math.PI, l.THREE_PI = 3 * Math.PI, A.exports = l;
          },
          /* 9 */
          /***/
          function(A, P, N) {
            function u() {
            }
            u.sign = function(l) {
              return l > 0 ? 1 : l < 0 ? -1 : 0;
            }, u.floor = function(l) {
              return l < 0 ? Math.ceil(l) : Math.floor(l);
            }, u.ceil = function(l) {
              return l < 0 ? Math.floor(l) : Math.ceil(l);
            }, A.exports = u;
          },
          /* 10 */
          /***/
          function(A, P, N) {
            function u() {
            }
            u.MAX_VALUE = 2147483647, u.MIN_VALUE = -2147483648, A.exports = u;
          },
          /* 11 */
          /***/
          function(A, P, N) {
            var u = /* @__PURE__ */ function() {
              function i(g, t) {
                for (var s = 0; s < t.length; s++) {
                  var o = t[s];
                  o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(g, o.key, o);
                }
              }
              return function(g, t, s) {
                return t && i(g.prototype, t), s && i(g, s), g;
              };
            }();
            function l(i, g) {
              if (!(i instanceof g))
                throw new TypeError("Cannot call a class as a function");
            }
            var a = function(g) {
              return { value: g, next: null, prev: null };
            }, e = function(g, t, s, o) {
              return g !== null ? g.next = t : o.head = t, s !== null ? s.prev = t : o.tail = t, t.prev = g, t.next = s, o.length++, t;
            }, r = function(g, t) {
              var s = g.prev, o = g.next;
              return s !== null ? s.next = o : t.head = o, o !== null ? o.prev = s : t.tail = s, g.prev = g.next = null, t.length--, g;
            }, f = function() {
              function i(g) {
                var t = this;
                l(this, i), this.length = 0, this.head = null, this.tail = null, g != null && g.forEach(function(s) {
                  return t.push(s);
                });
              }
              return u(i, [{
                key: "size",
                value: function() {
                  return this.length;
                }
              }, {
                key: "insertBefore",
                value: function(t, s) {
                  return e(s.prev, a(t), s, this);
                }
              }, {
                key: "insertAfter",
                value: function(t, s) {
                  return e(s, a(t), s.next, this);
                }
              }, {
                key: "insertNodeBefore",
                value: function(t, s) {
                  return e(s.prev, t, s, this);
                }
              }, {
                key: "insertNodeAfter",
                value: function(t, s) {
                  return e(s, t, s.next, this);
                }
              }, {
                key: "push",
                value: function(t) {
                  return e(this.tail, a(t), null, this);
                }
              }, {
                key: "unshift",
                value: function(t) {
                  return e(null, a(t), this.head, this);
                }
              }, {
                key: "remove",
                value: function(t) {
                  return r(t, this);
                }
              }, {
                key: "pop",
                value: function() {
                  return r(this.tail, this).value;
                }
              }, {
                key: "popNode",
                value: function() {
                  return r(this.tail, this);
                }
              }, {
                key: "shift",
                value: function() {
                  return r(this.head, this).value;
                }
              }, {
                key: "shiftNode",
                value: function() {
                  return r(this.head, this);
                }
              }, {
                key: "get_object_at",
                value: function(t) {
                  if (t <= this.length()) {
                    for (var s = 1, o = this.head; s < t; )
                      o = o.next, s++;
                    return o.value;
                  }
                }
              }, {
                key: "set_object_at",
                value: function(t, s) {
                  if (t <= this.length()) {
                    for (var o = 1, c = this.head; o < t; )
                      c = c.next, o++;
                    c.value = s;
                  }
                }
              }]), i;
            }();
            A.exports = f;
          },
          /* 12 */
          /***/
          function(A, P, N) {
            function u(l, a, e) {
              this.x = null, this.y = null, l == null && a == null && e == null ? (this.x = 0, this.y = 0) : typeof l == "number" && typeof a == "number" && e == null ? (this.x = l, this.y = a) : l.constructor.name == "Point" && a == null && e == null && (e = l, this.x = e.x, this.y = e.y);
            }
            u.prototype.getX = function() {
              return this.x;
            }, u.prototype.getY = function() {
              return this.y;
            }, u.prototype.getLocation = function() {
              return new u(this.x, this.y);
            }, u.prototype.setLocation = function(l, a, e) {
              l.constructor.name == "Point" && a == null && e == null ? (e = l, this.setLocation(e.x, e.y)) : typeof l == "number" && typeof a == "number" && e == null && (parseInt(l) == l && parseInt(a) == a ? this.move(l, a) : (this.x = Math.floor(l + 0.5), this.y = Math.floor(a + 0.5)));
            }, u.prototype.move = function(l, a) {
              this.x = l, this.y = a;
            }, u.prototype.translate = function(l, a) {
              this.x += l, this.y += a;
            }, u.prototype.equals = function(l) {
              if (l.constructor.name == "Point") {
                var a = l;
                return this.x == a.x && this.y == a.y;
              }
              return this == l;
            }, u.prototype.toString = function() {
              return new u().constructor.name + "[x=" + this.x + ",y=" + this.y + "]";
            }, A.exports = u;
          },
          /* 13 */
          /***/
          function(A, P, N) {
            function u(l, a, e, r) {
              this.x = 0, this.y = 0, this.width = 0, this.height = 0, l != null && a != null && e != null && r != null && (this.x = l, this.y = a, this.width = e, this.height = r);
            }
            u.prototype.getX = function() {
              return this.x;
            }, u.prototype.setX = function(l) {
              this.x = l;
            }, u.prototype.getY = function() {
              return this.y;
            }, u.prototype.setY = function(l) {
              this.y = l;
            }, u.prototype.getWidth = function() {
              return this.width;
            }, u.prototype.setWidth = function(l) {
              this.width = l;
            }, u.prototype.getHeight = function() {
              return this.height;
            }, u.prototype.setHeight = function(l) {
              this.height = l;
            }, u.prototype.getRight = function() {
              return this.x + this.width;
            }, u.prototype.getBottom = function() {
              return this.y + this.height;
            }, u.prototype.intersects = function(l) {
              return !(this.getRight() < l.x || this.getBottom() < l.y || l.getRight() < this.x || l.getBottom() < this.y);
            }, u.prototype.getCenterX = function() {
              return this.x + this.width / 2;
            }, u.prototype.getMinX = function() {
              return this.getX();
            }, u.prototype.getMaxX = function() {
              return this.getX() + this.width;
            }, u.prototype.getCenterY = function() {
              return this.y + this.height / 2;
            }, u.prototype.getMinY = function() {
              return this.getY();
            }, u.prototype.getMaxY = function() {
              return this.getY() + this.height;
            }, u.prototype.getWidthHalf = function() {
              return this.width / 2;
            }, u.prototype.getHeightHalf = function() {
              return this.height / 2;
            }, A.exports = u;
          },
          /* 14 */
          /***/
          function(A, P, N) {
            var u = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(a) {
              return typeof a;
            } : function(a) {
              return a && typeof Symbol == "function" && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a;
            };
            function l() {
            }
            l.lastID = 0, l.createID = function(a) {
              return l.isPrimitive(a) ? a : (a.uniqueID != null || (a.uniqueID = l.getString(), l.lastID++), a.uniqueID);
            }, l.getString = function(a) {
              return a == null && (a = l.lastID), "Object#" + a;
            }, l.isPrimitive = function(a) {
              var e = typeof a > "u" ? "undefined" : u(a);
              return a == null || e != "object" && e != "function";
            }, A.exports = l;
          },
          /* 15 */
          /***/
          function(A, P, N) {
            function u(o) {
              if (Array.isArray(o)) {
                for (var c = 0, h = Array(o.length); c < o.length; c++)
                  h[c] = o[c];
                return h;
              } else
                return Array.from(o);
            }
            var l = N(0), a = N(7), e = N(3), r = N(1), f = N(6), i = N(5), g = N(17), t = N(29);
            function s(o) {
              t.call(this), this.layoutQuality = l.QUALITY, this.createBendsAsNeeded = l.DEFAULT_CREATE_BENDS_AS_NEEDED, this.incremental = l.DEFAULT_INCREMENTAL, this.animationOnLayout = l.DEFAULT_ANIMATION_ON_LAYOUT, this.animationDuringLayout = l.DEFAULT_ANIMATION_DURING_LAYOUT, this.animationPeriod = l.DEFAULT_ANIMATION_PERIOD, this.uniformLeafNodeSizes = l.DEFAULT_UNIFORM_LEAF_NODE_SIZES, this.edgeToDummyNodes = /* @__PURE__ */ new Map(), this.graphManager = new a(this), this.isLayoutFinished = !1, this.isSubLayout = !1, this.isRemoteUse = !1, o != null && (this.isRemoteUse = o);
            }
            s.RANDOM_SEED = 1, s.prototype = Object.create(t.prototype), s.prototype.getGraphManager = function() {
              return this.graphManager;
            }, s.prototype.getAllNodes = function() {
              return this.graphManager.getAllNodes();
            }, s.prototype.getAllEdges = function() {
              return this.graphManager.getAllEdges();
            }, s.prototype.getAllNodesToApplyGravitation = function() {
              return this.graphManager.getAllNodesToApplyGravitation();
            }, s.prototype.newGraphManager = function() {
              var o = new a(this);
              return this.graphManager = o, o;
            }, s.prototype.newGraph = function(o) {
              return new f(null, this.graphManager, o);
            }, s.prototype.newNode = function(o) {
              return new e(this.graphManager, o);
            }, s.prototype.newEdge = function(o) {
              return new r(null, null, o);
            }, s.prototype.checkLayoutSuccess = function() {
              return this.graphManager.getRoot() == null || this.graphManager.getRoot().getNodes().length == 0 || this.graphManager.includesInvalidEdge();
            }, s.prototype.runLayout = function() {
              this.isLayoutFinished = !1, this.tilingPreLayout && this.tilingPreLayout(), this.initParameters();
              var o;
              return this.checkLayoutSuccess() ? o = !1 : o = this.layout(), l.ANIMATE === "during" ? !1 : (o && (this.isSubLayout || this.doPostLayout()), this.tilingPostLayout && this.tilingPostLayout(), this.isLayoutFinished = !0, o);
            }, s.prototype.doPostLayout = function() {
              this.incremental || this.transform(), this.update();
            }, s.prototype.update2 = function() {
              if (this.createBendsAsNeeded && (this.createBendpointsFromDummyNodes(), this.graphManager.resetAllEdges()), !this.isRemoteUse) {
                for (var o = this.graphManager.getAllEdges(), c = 0; c < o.length; c++)
                  o[c];
                for (var h = this.graphManager.getRoot().getNodes(), c = 0; c < h.length; c++)
                  h[c];
                this.update(this.graphManager.getRoot());
              }
            }, s.prototype.update = function(o) {
              if (o == null)
                this.update2();
              else if (o instanceof e) {
                var c = o;
                if (c.getChild() != null)
                  for (var h = c.getChild().getNodes(), T = 0; T < h.length; T++)
                    update(h[T]);
                if (c.vGraphObject != null) {
                  var d = c.vGraphObject;
                  d.update(c);
                }
              } else if (o instanceof r) {
                var v = o;
                if (v.vGraphObject != null) {
                  var L = v.vGraphObject;
                  L.update(v);
                }
              } else if (o instanceof f) {
                var S = o;
                if (S.vGraphObject != null) {
                  var C = S.vGraphObject;
                  C.update(S);
                }
              }
            }, s.prototype.initParameters = function() {
              this.isSubLayout || (this.layoutQuality = l.QUALITY, this.animationDuringLayout = l.DEFAULT_ANIMATION_DURING_LAYOUT, this.animationPeriod = l.DEFAULT_ANIMATION_PERIOD, this.animationOnLayout = l.DEFAULT_ANIMATION_ON_LAYOUT, this.incremental = l.DEFAULT_INCREMENTAL, this.createBendsAsNeeded = l.DEFAULT_CREATE_BENDS_AS_NEEDED, this.uniformLeafNodeSizes = l.DEFAULT_UNIFORM_LEAF_NODE_SIZES), this.animationDuringLayout && (this.animationOnLayout = !1);
            }, s.prototype.transform = function(o) {
              if (o == null)
                this.transform(new i(0, 0));
              else {
                var c = new g(), h = this.graphManager.getRoot().updateLeftTop();
                if (h != null) {
                  c.setWorldOrgX(o.x), c.setWorldOrgY(o.y), c.setDeviceOrgX(h.x), c.setDeviceOrgY(h.y);
                  for (var T = this.getAllNodes(), d, v = 0; v < T.length; v++)
                    d = T[v], d.transform(c);
                }
              }
            }, s.prototype.positionNodesRandomly = function(o) {
              if (o == null)
                this.positionNodesRandomly(this.getGraphManager().getRoot()), this.getGraphManager().getRoot().updateBounds(!0);
              else
                for (var c, h, T = o.getNodes(), d = 0; d < T.length; d++)
                  c = T[d], h = c.getChild(), h == null || h.getNodes().length == 0 ? c.scatter() : (this.positionNodesRandomly(h), c.updateBounds());
            }, s.prototype.getFlatForest = function() {
              for (var o = [], c = !0, h = this.graphManager.getRoot().getNodes(), T = !0, d = 0; d < h.length; d++)
                h[d].getChild() != null && (T = !1);
              if (!T)
                return o;
              var v = /* @__PURE__ */ new Set(), L = [], S = /* @__PURE__ */ new Map(), C = [];
              for (C = C.concat(h); C.length > 0 && c; ) {
                for (L.push(C[0]); L.length > 0 && c; ) {
                  var G = L[0];
                  L.splice(0, 1), v.add(G);
                  for (var K = G.getEdges(), d = 0; d < K.length; d++) {
                    var X = K[d].getOtherEnd(G);
                    if (S.get(G) != X)
                      if (!v.has(X))
                        L.push(X), S.set(X, G);
                      else {
                        c = !1;
                        break;
                      }
                  }
                }
                if (!c)
                  o = [];
                else {
                  var Q = [].concat(u(v));
                  o.push(Q);
                  for (var d = 0; d < Q.length; d++) {
                    var O = Q[d], rt = C.indexOf(O);
                    rt > -1 && C.splice(rt, 1);
                  }
                  v = /* @__PURE__ */ new Set(), S = /* @__PURE__ */ new Map();
                }
              }
              return o;
            }, s.prototype.createDummyNodesForBendpoints = function(o) {
              for (var c = [], h = o.source, T = this.graphManager.calcLowestCommonAncestor(o.source, o.target), d = 0; d < o.bendpoints.length; d++) {
                var v = this.newNode(null);
                v.setRect(new Point(0, 0), new Dimension(1, 1)), T.add(v);
                var L = this.newEdge(null);
                this.graphManager.add(L, h, v), c.add(v), h = v;
              }
              var L = this.newEdge(null);
              return this.graphManager.add(L, h, o.target), this.edgeToDummyNodes.set(o, c), o.isInterGraph() ? this.graphManager.remove(o) : T.remove(o), c;
            }, s.prototype.createBendpointsFromDummyNodes = function() {
              var o = [];
              o = o.concat(this.graphManager.getAllEdges()), o = [].concat(u(this.edgeToDummyNodes.keys())).concat(o);
              for (var c = 0; c < o.length; c++) {
                var h = o[c];
                if (h.bendpoints.length > 0) {
                  for (var T = this.edgeToDummyNodes.get(h), d = 0; d < T.length; d++) {
                    var v = T[d], L = new i(v.getCenterX(), v.getCenterY()), S = h.bendpoints.get(d);
                    S.x = L.x, S.y = L.y, v.getOwner().remove(v);
                  }
                  this.graphManager.add(h, h.source, h.target);
                }
              }
            }, s.transform = function(o, c, h, T) {
              if (h != null && T != null) {
                var d = c;
                if (o <= 50) {
                  var v = c / h;
                  d -= (c - v) / 50 * (50 - o);
                } else {
                  var L = c * T;
                  d += (L - c) / 50 * (o - 50);
                }
                return d;
              } else {
                var S, C;
                return o <= 50 ? (S = 9 * c / 500, C = c / 10) : (S = 9 * c / 50, C = -8 * c), S * o + C;
              }
            }, s.findCenterOfTree = function(o) {
              var c = [];
              c = c.concat(o);
              var h = [], T = /* @__PURE__ */ new Map(), d = !1, v = null;
              (c.length == 1 || c.length == 2) && (d = !0, v = c[0]);
              for (var L = 0; L < c.length; L++) {
                var S = c[L], C = S.getNeighborsList().size;
                T.set(S, S.getNeighborsList().size), C == 1 && h.push(S);
              }
              var G = [];
              for (G = G.concat(h); !d; ) {
                var K = [];
                K = K.concat(G), G = [];
                for (var L = 0; L < c.length; L++) {
                  var S = c[L], X = c.indexOf(S);
                  X >= 0 && c.splice(X, 1);
                  var Q = S.getNeighborsList();
                  Q.forEach(function(n) {
                    if (h.indexOf(n) < 0) {
                      var m = T.get(n), p = m - 1;
                      p == 1 && G.push(n), T.set(n, p);
                    }
                  });
                }
                h = h.concat(G), (c.length == 1 || c.length == 2) && (d = !0, v = c[0]);
              }
              return v;
            }, s.prototype.setGraphManager = function(o) {
              this.graphManager = o;
            }, A.exports = s;
          },
          /* 16 */
          /***/
          function(A, P, N) {
            function u() {
            }
            u.seed = 1, u.x = 0, u.nextDouble = function() {
              return u.x = Math.sin(u.seed++) * 1e4, u.x - Math.floor(u.x);
            }, A.exports = u;
          },
          /* 17 */
          /***/
          function(A, P, N) {
            var u = N(5);
            function l(a, e) {
              this.lworldOrgX = 0, this.lworldOrgY = 0, this.ldeviceOrgX = 0, this.ldeviceOrgY = 0, this.lworldExtX = 1, this.lworldExtY = 1, this.ldeviceExtX = 1, this.ldeviceExtY = 1;
            }
            l.prototype.getWorldOrgX = function() {
              return this.lworldOrgX;
            }, l.prototype.setWorldOrgX = function(a) {
              this.lworldOrgX = a;
            }, l.prototype.getWorldOrgY = function() {
              return this.lworldOrgY;
            }, l.prototype.setWorldOrgY = function(a) {
              this.lworldOrgY = a;
            }, l.prototype.getWorldExtX = function() {
              return this.lworldExtX;
            }, l.prototype.setWorldExtX = function(a) {
              this.lworldExtX = a;
            }, l.prototype.getWorldExtY = function() {
              return this.lworldExtY;
            }, l.prototype.setWorldExtY = function(a) {
              this.lworldExtY = a;
            }, l.prototype.getDeviceOrgX = function() {
              return this.ldeviceOrgX;
            }, l.prototype.setDeviceOrgX = function(a) {
              this.ldeviceOrgX = a;
            }, l.prototype.getDeviceOrgY = function() {
              return this.ldeviceOrgY;
            }, l.prototype.setDeviceOrgY = function(a) {
              this.ldeviceOrgY = a;
            }, l.prototype.getDeviceExtX = function() {
              return this.ldeviceExtX;
            }, l.prototype.setDeviceExtX = function(a) {
              this.ldeviceExtX = a;
            }, l.prototype.getDeviceExtY = function() {
              return this.ldeviceExtY;
            }, l.prototype.setDeviceExtY = function(a) {
              this.ldeviceExtY = a;
            }, l.prototype.transformX = function(a) {
              var e = 0, r = this.lworldExtX;
              return r != 0 && (e = this.ldeviceOrgX + (a - this.lworldOrgX) * this.ldeviceExtX / r), e;
            }, l.prototype.transformY = function(a) {
              var e = 0, r = this.lworldExtY;
              return r != 0 && (e = this.ldeviceOrgY + (a - this.lworldOrgY) * this.ldeviceExtY / r), e;
            }, l.prototype.inverseTransformX = function(a) {
              var e = 0, r = this.ldeviceExtX;
              return r != 0 && (e = this.lworldOrgX + (a - this.ldeviceOrgX) * this.lworldExtX / r), e;
            }, l.prototype.inverseTransformY = function(a) {
              var e = 0, r = this.ldeviceExtY;
              return r != 0 && (e = this.lworldOrgY + (a - this.ldeviceOrgY) * this.lworldExtY / r), e;
            }, l.prototype.inverseTransformPoint = function(a) {
              var e = new u(this.inverseTransformX(a.x), this.inverseTransformY(a.y));
              return e;
            }, A.exports = l;
          },
          /* 18 */
          /***/
          function(A, P, N) {
            function u(t) {
              if (Array.isArray(t)) {
                for (var s = 0, o = Array(t.length); s < t.length; s++)
                  o[s] = t[s];
                return o;
              } else
                return Array.from(t);
            }
            var l = N(15), a = N(4), e = N(0), r = N(8), f = N(9);
            function i() {
              l.call(this), this.useSmartIdealEdgeLengthCalculation = a.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION, this.gravityConstant = a.DEFAULT_GRAVITY_STRENGTH, this.compoundGravityConstant = a.DEFAULT_COMPOUND_GRAVITY_STRENGTH, this.gravityRangeFactor = a.DEFAULT_GRAVITY_RANGE_FACTOR, this.compoundGravityRangeFactor = a.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR, this.displacementThresholdPerNode = 3 * a.DEFAULT_EDGE_LENGTH / 100, this.coolingFactor = a.DEFAULT_COOLING_FACTOR_INCREMENTAL, this.initialCoolingFactor = a.DEFAULT_COOLING_FACTOR_INCREMENTAL, this.totalDisplacement = 0, this.oldTotalDisplacement = 0, this.maxIterations = a.MAX_ITERATIONS;
            }
            i.prototype = Object.create(l.prototype);
            for (var g in l)
              i[g] = l[g];
            i.prototype.initParameters = function() {
              l.prototype.initParameters.call(this, arguments), this.totalIterations = 0, this.notAnimatedIterations = 0, this.useFRGridVariant = a.DEFAULT_USE_SMART_REPULSION_RANGE_CALCULATION, this.grid = [];
            }, i.prototype.calcIdealEdgeLengths = function() {
              for (var t, s, o, c, h, T, d, v = this.getGraphManager().getAllEdges(), L = 0; L < v.length; L++)
                t = v[L], s = t.idealLength, t.isInterGraph && (c = t.getSource(), h = t.getTarget(), T = t.getSourceInLca().getEstimatedSize(), d = t.getTargetInLca().getEstimatedSize(), this.useSmartIdealEdgeLengthCalculation && (t.idealLength += T + d - 2 * e.SIMPLE_NODE_SIZE), o = t.getLca().getInclusionTreeDepth(), t.idealLength += s * a.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR * (c.getInclusionTreeDepth() + h.getInclusionTreeDepth() - 2 * o));
            }, i.prototype.initSpringEmbedder = function() {
              var t = this.getAllNodes().length;
              this.incremental ? (t > a.ADAPTATION_LOWER_NODE_LIMIT && (this.coolingFactor = Math.max(this.coolingFactor * a.COOLING_ADAPTATION_FACTOR, this.coolingFactor - (t - a.ADAPTATION_LOWER_NODE_LIMIT) / (a.ADAPTATION_UPPER_NODE_LIMIT - a.ADAPTATION_LOWER_NODE_LIMIT) * this.coolingFactor * (1 - a.COOLING_ADAPTATION_FACTOR))), this.maxNodeDisplacement = a.MAX_NODE_DISPLACEMENT_INCREMENTAL) : (t > a.ADAPTATION_LOWER_NODE_LIMIT ? this.coolingFactor = Math.max(a.COOLING_ADAPTATION_FACTOR, 1 - (t - a.ADAPTATION_LOWER_NODE_LIMIT) / (a.ADAPTATION_UPPER_NODE_LIMIT - a.ADAPTATION_LOWER_NODE_LIMIT) * (1 - a.COOLING_ADAPTATION_FACTOR)) : this.coolingFactor = 1, this.initialCoolingFactor = this.coolingFactor, this.maxNodeDisplacement = a.MAX_NODE_DISPLACEMENT), this.maxIterations = Math.max(this.getAllNodes().length * 5, this.maxIterations), this.displacementThresholdPerNode = 3 * a.DEFAULT_EDGE_LENGTH / 100, this.totalDisplacementThreshold = this.displacementThresholdPerNode * this.getAllNodes().length, this.repulsionRange = this.calcRepulsionRange();
            }, i.prototype.calcSpringForces = function() {
              for (var t = this.getAllEdges(), s, o = 0; o < t.length; o++)
                s = t[o], this.calcSpringForce(s, s.idealLength);
            }, i.prototype.calcRepulsionForces = function() {
              var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0, s = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1, o, c, h, T, d = this.getAllNodes(), v;
              if (this.useFRGridVariant)
                for (this.totalIterations % a.GRID_CALCULATION_CHECK_PERIOD == 1 && t && this.updateGrid(), v = /* @__PURE__ */ new Set(), o = 0; o < d.length; o++)
                  h = d[o], this.calculateRepulsionForceOfANode(h, v, t, s), v.add(h);
              else
                for (o = 0; o < d.length; o++)
                  for (h = d[o], c = o + 1; c < d.length; c++)
                    T = d[c], h.getOwner() == T.getOwner() && this.calcRepulsionForce(h, T);
            }, i.prototype.calcGravitationalForces = function() {
              for (var t, s = this.getAllNodesToApplyGravitation(), o = 0; o < s.length; o++)
                t = s[o], this.calcGravitationalForce(t);
            }, i.prototype.moveNodes = function() {
              for (var t = this.getAllNodes(), s, o = 0; o < t.length; o++)
                s = t[o], s.move();
            }, i.prototype.calcSpringForce = function(t, s) {
              var o = t.getSource(), c = t.getTarget(), h, T, d, v;
              if (this.uniformLeafNodeSizes && o.getChild() == null && c.getChild() == null)
                t.updateLengthSimple();
              else if (t.updateLength(), t.isOverlapingSourceAndTarget)
                return;
              h = t.getLength(), h != 0 && (T = t.edgeElasticity * (h - s), d = T * (t.lengthX / h), v = T * (t.lengthY / h), o.springForceX += d, o.springForceY += v, c.springForceX -= d, c.springForceY -= v);
            }, i.prototype.calcRepulsionForce = function(t, s) {
              var o = t.getRect(), c = s.getRect(), h = new Array(2), T = new Array(4), d, v, L, S, C, G, K;
              if (o.intersects(c)) {
                r.calcSeparationAmount(o, c, h, a.DEFAULT_EDGE_LENGTH / 2), G = 2 * h[0], K = 2 * h[1];
                var X = t.noOfChildren * s.noOfChildren / (t.noOfChildren + s.noOfChildren);
                t.repulsionForceX -= X * G, t.repulsionForceY -= X * K, s.repulsionForceX += X * G, s.repulsionForceY += X * K;
              } else
                this.uniformLeafNodeSizes && t.getChild() == null && s.getChild() == null ? (d = c.getCenterX() - o.getCenterX(), v = c.getCenterY() - o.getCenterY()) : (r.getIntersection(o, c, T), d = T[2] - T[0], v = T[3] - T[1]), Math.abs(d) < a.MIN_REPULSION_DIST && (d = f.sign(d) * a.MIN_REPULSION_DIST), Math.abs(v) < a.MIN_REPULSION_DIST && (v = f.sign(v) * a.MIN_REPULSION_DIST), L = d * d + v * v, S = Math.sqrt(L), C = (t.nodeRepulsion / 2 + s.nodeRepulsion / 2) * t.noOfChildren * s.noOfChildren / L, G = C * d / S, K = C * v / S, t.repulsionForceX -= G, t.repulsionForceY -= K, s.repulsionForceX += G, s.repulsionForceY += K;
            }, i.prototype.calcGravitationalForce = function(t) {
              var s, o, c, h, T, d, v, L;
              s = t.getOwner(), o = (s.getRight() + s.getLeft()) / 2, c = (s.getTop() + s.getBottom()) / 2, h = t.getCenterX() - o, T = t.getCenterY() - c, d = Math.abs(h) + t.getWidth() / 2, v = Math.abs(T) + t.getHeight() / 2, t.getOwner() == this.graphManager.getRoot() ? (L = s.getEstimatedSize() * this.gravityRangeFactor, (d > L || v > L) && (t.gravitationForceX = -this.gravityConstant * h, t.gravitationForceY = -this.gravityConstant * T)) : (L = s.getEstimatedSize() * this.compoundGravityRangeFactor, (d > L || v > L) && (t.gravitationForceX = -this.gravityConstant * h * this.compoundGravityConstant, t.gravitationForceY = -this.gravityConstant * T * this.compoundGravityConstant));
            }, i.prototype.isConverged = function() {
              var t, s = !1;
              return this.totalIterations > this.maxIterations / 3 && (s = Math.abs(this.totalDisplacement - this.oldTotalDisplacement) < 2), t = this.totalDisplacement < this.totalDisplacementThreshold, this.oldTotalDisplacement = this.totalDisplacement, t || s;
            }, i.prototype.animate = function() {
              this.animationDuringLayout && !this.isSubLayout && (this.notAnimatedIterations == this.animationPeriod ? (this.update(), this.notAnimatedIterations = 0) : this.notAnimatedIterations++);
            }, i.prototype.calcNoOfChildrenForAllNodes = function() {
              for (var t, s = this.graphManager.getAllNodes(), o = 0; o < s.length; o++)
                t = s[o], t.noOfChildren = t.getNoOfChildren();
            }, i.prototype.calcGrid = function(t) {
              var s = 0, o = 0;
              s = parseInt(Math.ceil((t.getRight() - t.getLeft()) / this.repulsionRange)), o = parseInt(Math.ceil((t.getBottom() - t.getTop()) / this.repulsionRange));
              for (var c = new Array(s), h = 0; h < s; h++)
                c[h] = new Array(o);
              for (var h = 0; h < s; h++)
                for (var T = 0; T < o; T++)
                  c[h][T] = new Array();
              return c;
            }, i.prototype.addNodeToGrid = function(t, s, o) {
              var c = 0, h = 0, T = 0, d = 0;
              c = parseInt(Math.floor((t.getRect().x - s) / this.repulsionRange)), h = parseInt(Math.floor((t.getRect().width + t.getRect().x - s) / this.repulsionRange)), T = parseInt(Math.floor((t.getRect().y - o) / this.repulsionRange)), d = parseInt(Math.floor((t.getRect().height + t.getRect().y - o) / this.repulsionRange));
              for (var v = c; v <= h; v++)
                for (var L = T; L <= d; L++)
                  this.grid[v][L].push(t), t.setGridCoordinates(c, h, T, d);
            }, i.prototype.updateGrid = function() {
              var t, s, o = this.getAllNodes();
              for (this.grid = this.calcGrid(this.graphManager.getRoot()), t = 0; t < o.length; t++)
                s = o[t], this.addNodeToGrid(s, this.graphManager.getRoot().getLeft(), this.graphManager.getRoot().getTop());
            }, i.prototype.calculateRepulsionForceOfANode = function(t, s, o, c) {
              if (this.totalIterations % a.GRID_CALCULATION_CHECK_PERIOD == 1 && o || c) {
                var h = /* @__PURE__ */ new Set();
                t.surrounding = new Array();
                for (var T, d = this.grid, v = t.startX - 1; v < t.finishX + 2; v++)
                  for (var L = t.startY - 1; L < t.finishY + 2; L++)
                    if (!(v < 0 || L < 0 || v >= d.length || L >= d[0].length)) {
                      for (var S = 0; S < d[v][L].length; S++)
                        if (T = d[v][L][S], !(t.getOwner() != T.getOwner() || t == T) && !s.has(T) && !h.has(T)) {
                          var C = Math.abs(t.getCenterX() - T.getCenterX()) - (t.getWidth() / 2 + T.getWidth() / 2), G = Math.abs(t.getCenterY() - T.getCenterY()) - (t.getHeight() / 2 + T.getHeight() / 2);
                          C <= this.repulsionRange && G <= this.repulsionRange && h.add(T);
                        }
                    }
                t.surrounding = [].concat(u(h));
              }
              for (v = 0; v < t.surrounding.length; v++)
                this.calcRepulsionForce(t, t.surrounding[v]);
            }, i.prototype.calcRepulsionRange = function() {
              return 0;
            }, A.exports = i;
          },
          /* 19 */
          /***/
          function(A, P, N) {
            var u = N(1), l = N(4);
            function a(r, f, i) {
              u.call(this, r, f, i), this.idealLength = l.DEFAULT_EDGE_LENGTH, this.edgeElasticity = l.DEFAULT_SPRING_STRENGTH;
            }
            a.prototype = Object.create(u.prototype);
            for (var e in u)
              a[e] = u[e];
            A.exports = a;
          },
          /* 20 */
          /***/
          function(A, P, N) {
            var u = N(3), l = N(4);
            function a(r, f, i, g) {
              u.call(this, r, f, i, g), this.nodeRepulsion = l.DEFAULT_REPULSION_STRENGTH, this.springForceX = 0, this.springForceY = 0, this.repulsionForceX = 0, this.repulsionForceY = 0, this.gravitationForceX = 0, this.gravitationForceY = 0, this.displacementX = 0, this.displacementY = 0, this.startX = 0, this.finishX = 0, this.startY = 0, this.finishY = 0, this.surrounding = [];
            }
            a.prototype = Object.create(u.prototype);
            for (var e in u)
              a[e] = u[e];
            a.prototype.setGridCoordinates = function(r, f, i, g) {
              this.startX = r, this.finishX = f, this.startY = i, this.finishY = g;
            }, A.exports = a;
          },
          /* 21 */
          /***/
          function(A, P, N) {
            function u(l, a) {
              this.width = 0, this.height = 0, l !== null && a !== null && (this.height = a, this.width = l);
            }
            u.prototype.getWidth = function() {
              return this.width;
            }, u.prototype.setWidth = function(l) {
              this.width = l;
            }, u.prototype.getHeight = function() {
              return this.height;
            }, u.prototype.setHeight = function(l) {
              this.height = l;
            }, A.exports = u;
          },
          /* 22 */
          /***/
          function(A, P, N) {
            var u = N(14);
            function l() {
              this.map = {}, this.keys = [];
            }
            l.prototype.put = function(a, e) {
              var r = u.createID(a);
              this.contains(r) || (this.map[r] = e, this.keys.push(a));
            }, l.prototype.contains = function(a) {
              return u.createID(a), this.map[a] != null;
            }, l.prototype.get = function(a) {
              var e = u.createID(a);
              return this.map[e];
            }, l.prototype.keySet = function() {
              return this.keys;
            }, A.exports = l;
          },
          /* 23 */
          /***/
          function(A, P, N) {
            var u = N(14);
            function l() {
              this.set = {};
            }
            l.prototype.add = function(a) {
              var e = u.createID(a);
              this.contains(e) || (this.set[e] = a);
            }, l.prototype.remove = function(a) {
              delete this.set[u.createID(a)];
            }, l.prototype.clear = function() {
              this.set = {};
            }, l.prototype.contains = function(a) {
              return this.set[u.createID(a)] == a;
            }, l.prototype.isEmpty = function() {
              return this.size() === 0;
            }, l.prototype.size = function() {
              return Object.keys(this.set).length;
            }, l.prototype.addAllTo = function(a) {
              for (var e = Object.keys(this.set), r = e.length, f = 0; f < r; f++)
                a.push(this.set[e[f]]);
            }, l.prototype.size = function() {
              return Object.keys(this.set).length;
            }, l.prototype.addAll = function(a) {
              for (var e = a.length, r = 0; r < e; r++) {
                var f = a[r];
                this.add(f);
              }
            }, A.exports = l;
          },
          /* 24 */
          /***/
          function(A, P, N) {
            function u() {
            }
            u.multMat = function(l, a) {
              for (var e = [], r = 0; r < l.length; r++) {
                e[r] = [];
                for (var f = 0; f < a[0].length; f++) {
                  e[r][f] = 0;
                  for (var i = 0; i < l[0].length; i++)
                    e[r][f] += l[r][i] * a[i][f];
                }
              }
              return e;
            }, u.transpose = function(l) {
              for (var a = [], e = 0; e < l[0].length; e++) {
                a[e] = [];
                for (var r = 0; r < l.length; r++)
                  a[e][r] = l[r][e];
              }
              return a;
            }, u.multCons = function(l, a) {
              for (var e = [], r = 0; r < l.length; r++)
                e[r] = l[r] * a;
              return e;
            }, u.minusOp = function(l, a) {
              for (var e = [], r = 0; r < l.length; r++)
                e[r] = l[r] - a[r];
              return e;
            }, u.dotProduct = function(l, a) {
              for (var e = 0, r = 0; r < l.length; r++)
                e += l[r] * a[r];
              return e;
            }, u.mag = function(l) {
              return Math.sqrt(this.dotProduct(l, l));
            }, u.normalize = function(l) {
              for (var a = [], e = this.mag(l), r = 0; r < l.length; r++)
                a[r] = l[r] / e;
              return a;
            }, u.multGamma = function(l) {
              for (var a = [], e = 0, r = 0; r < l.length; r++)
                e += l[r];
              e *= -1 / l.length;
              for (var f = 0; f < l.length; f++)
                a[f] = e + l[f];
              return a;
            }, u.multL = function(l, a, e) {
              for (var r = [], f = [], i = [], g = 0; g < a[0].length; g++) {
                for (var t = 0, s = 0; s < a.length; s++)
                  t += -0.5 * a[s][g] * l[s];
                f[g] = t;
              }
              for (var o = 0; o < e.length; o++) {
                for (var c = 0, h = 0; h < e.length; h++)
                  c += e[o][h] * f[h];
                i[o] = c;
              }
              for (var T = 0; T < a.length; T++) {
                for (var d = 0, v = 0; v < a[0].length; v++)
                  d += a[T][v] * i[v];
                r[T] = d;
              }
              return r;
            }, A.exports = u;
          },
          /* 25 */
          /***/
          function(A, P, N) {
            var u = /* @__PURE__ */ function() {
              function r(f, i) {
                for (var g = 0; g < i.length; g++) {
                  var t = i[g];
                  t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), Object.defineProperty(f, t.key, t);
                }
              }
              return function(f, i, g) {
                return i && r(f.prototype, i), g && r(f, g), f;
              };
            }();
            function l(r, f) {
              if (!(r instanceof f))
                throw new TypeError("Cannot call a class as a function");
            }
            var a = N(11), e = function() {
              function r(f, i) {
                l(this, r), (i !== null || i !== void 0) && (this.compareFunction = this._defaultCompareFunction);
                var g = void 0;
                f instanceof a ? g = f.size() : g = f.length, this._quicksort(f, 0, g - 1);
              }
              return u(r, [{
                key: "_quicksort",
                value: function(i, g, t) {
                  if (g < t) {
                    var s = this._partition(i, g, t);
                    this._quicksort(i, g, s), this._quicksort(i, s + 1, t);
                  }
                }
              }, {
                key: "_partition",
                value: function(i, g, t) {
                  for (var s = this._get(i, g), o = g, c = t; ; ) {
                    for (; this.compareFunction(s, this._get(i, c)); )
                      c--;
                    for (; this.compareFunction(this._get(i, o), s); )
                      o++;
                    if (o < c)
                      this._swap(i, o, c), o++, c--;
                    else return c;
                  }
                }
              }, {
                key: "_get",
                value: function(i, g) {
                  return i instanceof a ? i.get_object_at(g) : i[g];
                }
              }, {
                key: "_set",
                value: function(i, g, t) {
                  i instanceof a ? i.set_object_at(g, t) : i[g] = t;
                }
              }, {
                key: "_swap",
                value: function(i, g, t) {
                  var s = this._get(i, g);
                  this._set(i, g, this._get(i, t)), this._set(i, t, s);
                }
              }, {
                key: "_defaultCompareFunction",
                value: function(i, g) {
                  return g > i;
                }
              }]), r;
            }();
            A.exports = e;
          },
          /* 26 */
          /***/
          function(A, P, N) {
            function u() {
            }
            u.svd = function(l) {
              this.U = null, this.V = null, this.s = null, this.m = 0, this.n = 0, this.m = l.length, this.n = l[0].length;
              var a = Math.min(this.m, this.n);
              this.s = function(Tt) {
                for (var Ct = []; Tt-- > 0; )
                  Ct.push(0);
                return Ct;
              }(Math.min(this.m + 1, this.n)), this.U = function(Tt) {
                var Ct = function Bt(bt) {
                  if (bt.length == 0)
                    return 0;
                  for (var zt = [], St = 0; St < bt[0]; St++)
                    zt.push(Bt(bt.slice(1)));
                  return zt;
                };
                return Ct(Tt);
              }([this.m, a]), this.V = function(Tt) {
                var Ct = function Bt(bt) {
                  if (bt.length == 0)
                    return 0;
                  for (var zt = [], St = 0; St < bt[0]; St++)
                    zt.push(Bt(bt.slice(1)));
                  return zt;
                };
                return Ct(Tt);
              }([this.n, this.n]);
              for (var e = function(Tt) {
                for (var Ct = []; Tt-- > 0; )
                  Ct.push(0);
                return Ct;
              }(this.n), r = function(Tt) {
                for (var Ct = []; Tt-- > 0; )
                  Ct.push(0);
                return Ct;
              }(this.m), f = !0, i = Math.min(this.m - 1, this.n), g = Math.max(0, Math.min(this.n - 2, this.m)), t = 0; t < Math.max(i, g); t++) {
                if (t < i) {
                  this.s[t] = 0;
                  for (var s = t; s < this.m; s++)
                    this.s[t] = u.hypot(this.s[t], l[s][t]);
                  if (this.s[t] !== 0) {
                    l[t][t] < 0 && (this.s[t] = -this.s[t]);
                    for (var o = t; o < this.m; o++)
                      l[o][t] /= this.s[t];
                    l[t][t] += 1;
                  }
                  this.s[t] = -this.s[t];
                }
                for (var c = t + 1; c < this.n; c++) {
                  if (/* @__PURE__ */ function(Tt, Ct) {
                    return Tt && Ct;
                  }(t < i, this.s[t] !== 0)) {
                    for (var h = 0, T = t; T < this.m; T++)
                      h += l[T][t] * l[T][c];
                    h = -h / l[t][t];
                    for (var d = t; d < this.m; d++)
                      l[d][c] += h * l[d][t];
                  }
                  e[c] = l[t][c];
                }
                if (/* @__PURE__ */ function(Tt, Ct) {
                  return Ct;
                }(f, t < i))
                  for (var v = t; v < this.m; v++)
                    this.U[v][t] = l[v][t];
                if (t < g) {
                  e[t] = 0;
                  for (var L = t + 1; L < this.n; L++)
                    e[t] = u.hypot(e[t], e[L]);
                  if (e[t] !== 0) {
                    e[t + 1] < 0 && (e[t] = -e[t]);
                    for (var S = t + 1; S < this.n; S++)
                      e[S] /= e[t];
                    e[t + 1] += 1;
                  }
                  if (e[t] = -e[t], /* @__PURE__ */ function(Tt, Ct) {
                    return Tt && Ct;
                  }(t + 1 < this.m, e[t] !== 0)) {
                    for (var C = t + 1; C < this.m; C++)
                      r[C] = 0;
                    for (var G = t + 1; G < this.n; G++)
                      for (var K = t + 1; K < this.m; K++)
                        r[K] += e[G] * l[K][G];
                    for (var X = t + 1; X < this.n; X++)
                      for (var Q = -e[X] / e[t + 1], O = t + 1; O < this.m; O++)
                        l[O][X] += Q * r[O];
                  }
                  for (var rt = t + 1; rt < this.n; rt++)
                    this.V[rt][t] = e[rt];
                }
              }
              var n = Math.min(this.n, this.m + 1);
              i < this.n && (this.s[i] = l[i][i]), this.m < n && (this.s[n - 1] = 0), g + 1 < n && (e[g] = l[g][n - 1]), e[n - 1] = 0;
              {
                for (var m = i; m < a; m++) {
                  for (var p = 0; p < this.m; p++)
                    this.U[p][m] = 0;
                  this.U[m][m] = 1;
                }
                for (var E = i - 1; E >= 0; E--)
                  if (this.s[E] !== 0) {
                    for (var y = E + 1; y < a; y++) {
                      for (var R = 0, M = E; M < this.m; M++)
                        R += this.U[M][E] * this.U[M][y];
                      R = -R / this.U[E][E];
                      for (var F = E; F < this.m; F++)
                        this.U[F][y] += R * this.U[F][E];
                    }
                    for (var W = E; W < this.m; W++)
                      this.U[W][E] = -this.U[W][E];
                    this.U[E][E] = 1 + this.U[E][E];
                    for (var x = 0; x < E - 1; x++)
                      this.U[x][E] = 0;
                  } else {
                    for (var Z = 0; Z < this.m; Z++)
                      this.U[Z][E] = 0;
                    this.U[E][E] = 1;
                  }
              }
              for (var V = this.n - 1; V >= 0; V--) {
                if (/* @__PURE__ */ function(Tt, Ct) {
                  return Tt && Ct;
                }(V < g, e[V] !== 0))
                  for (var Y = V + 1; Y < a; Y++) {
                    for (var et = 0, z = V + 1; z < this.n; z++)
                      et += this.V[z][V] * this.V[z][Y];
                    et = -et / this.V[V + 1][V];
                    for (var w = V + 1; w < this.n; w++)
                      this.V[w][Y] += et * this.V[w][V];
                  }
                for (var H = 0; H < this.n; H++)
                  this.V[H][V] = 0;
                this.V[V][V] = 1;
              }
              for (var B = n - 1, _ = Math.pow(2, -52), ht = Math.pow(2, -966); n > 0; ) {
                var q = void 0, It = void 0;
                for (q = n - 2; q >= -1 && q !== -1; q--)
                  if (Math.abs(e[q]) <= ht + _ * (Math.abs(this.s[q]) + Math.abs(this.s[q + 1]))) {
                    e[q] = 0;
                    break;
                  }
                if (q === n - 2)
                  It = 4;
                else {
                  var Nt = void 0;
                  for (Nt = n - 1; Nt >= q && Nt !== q; Nt--) {
                    var vt = (Nt !== n ? Math.abs(e[Nt]) : 0) + (Nt !== q + 1 ? Math.abs(e[Nt - 1]) : 0);
                    if (Math.abs(this.s[Nt]) <= ht + _ * vt) {
                      this.s[Nt] = 0;
                      break;
                    }
                  }
                  Nt === q ? It = 3 : Nt === n - 1 ? It = 1 : (It = 2, q = Nt);
                }
                switch (q++, It) {
                  case 1:
                    {
                      var it = e[n - 2];
                      e[n - 2] = 0;
                      for (var gt = n - 2; gt >= q; gt--) {
                        var mt = u.hypot(this.s[gt], it), At = this.s[gt] / mt, Ot = it / mt;
                        this.s[gt] = mt, gt !== q && (it = -Ot * e[gt - 1], e[gt - 1] = At * e[gt - 1]);
                        for (var Et = 0; Et < this.n; Et++)
                          mt = At * this.V[Et][gt] + Ot * this.V[Et][n - 1], this.V[Et][n - 1] = -Ot * this.V[Et][gt] + At * this.V[Et][n - 1], this.V[Et][gt] = mt;
                      }
                    }
                    break;
                  case 2:
                    {
                      var Dt = e[q - 1];
                      e[q - 1] = 0;
                      for (var Rt = q; Rt < n; Rt++) {
                        var Ht = u.hypot(this.s[Rt], Dt), Ut = this.s[Rt] / Ht, Pt = Dt / Ht;
                        this.s[Rt] = Ht, Dt = -Pt * e[Rt], e[Rt] = Ut * e[Rt];
                        for (var Ft = 0; Ft < this.m; Ft++)
                          Ht = Ut * this.U[Ft][Rt] + Pt * this.U[Ft][q - 1], this.U[Ft][q - 1] = -Pt * this.U[Ft][Rt] + Ut * this.U[Ft][q - 1], this.U[Ft][Rt] = Ht;
                      }
                    }
                    break;
                  case 3:
                    {
                      var Yt = Math.max(Math.max(Math.max(Math.max(Math.abs(this.s[n - 1]), Math.abs(this.s[n - 2])), Math.abs(e[n - 2])), Math.abs(this.s[q])), Math.abs(e[q])), Vt = this.s[n - 1] / Yt, b = this.s[n - 2] / Yt, U = e[n - 2] / Yt, $ = this.s[q] / Yt, J = e[q] / Yt, k = ((b + Vt) * (b - Vt) + U * U) / 2, at = Vt * U * (Vt * U), ct = 0;
                      /* @__PURE__ */ (function(Tt, Ct) {
                        return Tt || Ct;
                      })(k !== 0, at !== 0) && (ct = Math.sqrt(k * k + at), k < 0 && (ct = -ct), ct = at / (k + ct));
                      for (var nt = ($ + Vt) * ($ - Vt) + ct, tt = $ * J, j = q; j < n - 1; j++) {
                        var ut = u.hypot(nt, tt), Mt = nt / ut, pt = tt / ut;
                        j !== q && (e[j - 1] = ut), nt = Mt * this.s[j] + pt * e[j], e[j] = Mt * e[j] - pt * this.s[j], tt = pt * this.s[j + 1], this.s[j + 1] = Mt * this.s[j + 1];
                        for (var xt = 0; xt < this.n; xt++)
                          ut = Mt * this.V[xt][j] + pt * this.V[xt][j + 1], this.V[xt][j + 1] = -pt * this.V[xt][j] + Mt * this.V[xt][j + 1], this.V[xt][j] = ut;
                        if (ut = u.hypot(nt, tt), Mt = nt / ut, pt = tt / ut, this.s[j] = ut, nt = Mt * e[j] + pt * this.s[j + 1], this.s[j + 1] = -pt * e[j] + Mt * this.s[j + 1], tt = pt * e[j + 1], e[j + 1] = Mt * e[j + 1], j < this.m - 1)
                          for (var lt = 0; lt < this.m; lt++)
                            ut = Mt * this.U[lt][j] + pt * this.U[lt][j + 1], this.U[lt][j + 1] = -pt * this.U[lt][j] + Mt * this.U[lt][j + 1], this.U[lt][j] = ut;
                      }
                      e[n - 2] = nt;
                    }
                    break;
                  case 4:
                    {
                      if (this.s[q] <= 0) {
                        this.s[q] = this.s[q] < 0 ? -this.s[q] : 0;
                        for (var ot = 0; ot <= B; ot++)
                          this.V[ot][q] = -this.V[ot][q];
                      }
                      for (; q < B && !(this.s[q] >= this.s[q + 1]); ) {
                        var Lt = this.s[q];
                        if (this.s[q] = this.s[q + 1], this.s[q + 1] = Lt, q < this.n - 1)
                          for (var ft = 0; ft < this.n; ft++)
                            Lt = this.V[ft][q + 1], this.V[ft][q + 1] = this.V[ft][q], this.V[ft][q] = Lt;
                        if (q < this.m - 1)
                          for (var st = 0; st < this.m; st++)
                            Lt = this.U[st][q + 1], this.U[st][q + 1] = this.U[st][q], this.U[st][q] = Lt;
                        q++;
                      }
                      n--;
                    }
                    break;
                }
              }
              var Xt = { U: this.U, V: this.V, S: this.s };
              return Xt;
            }, u.hypot = function(l, a) {
              var e = void 0;
              return Math.abs(l) > Math.abs(a) ? (e = a / l, e = Math.abs(l) * Math.sqrt(1 + e * e)) : a != 0 ? (e = l / a, e = Math.abs(a) * Math.sqrt(1 + e * e)) : e = 0, e;
            }, A.exports = u;
          },
          /* 27 */
          /***/
          function(A, P, N) {
            var u = /* @__PURE__ */ function() {
              function e(r, f) {
                for (var i = 0; i < f.length; i++) {
                  var g = f[i];
                  g.enumerable = g.enumerable || !1, g.configurable = !0, "value" in g && (g.writable = !0), Object.defineProperty(r, g.key, g);
                }
              }
              return function(r, f, i) {
                return f && e(r.prototype, f), i && e(r, i), r;
              };
            }();
            function l(e, r) {
              if (!(e instanceof r))
                throw new TypeError("Cannot call a class as a function");
            }
            var a = function() {
              function e(r, f) {
                var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1, g = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : -1, t = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : -1;
                l(this, e), this.sequence1 = r, this.sequence2 = f, this.match_score = i, this.mismatch_penalty = g, this.gap_penalty = t, this.iMax = r.length + 1, this.jMax = f.length + 1, this.grid = new Array(this.iMax);
                for (var s = 0; s < this.iMax; s++) {
                  this.grid[s] = new Array(this.jMax);
                  for (var o = 0; o < this.jMax; o++)
                    this.grid[s][o] = 0;
                }
                this.tracebackGrid = new Array(this.iMax);
                for (var c = 0; c < this.iMax; c++) {
                  this.tracebackGrid[c] = new Array(this.jMax);
                  for (var h = 0; h < this.jMax; h++)
                    this.tracebackGrid[c][h] = [null, null, null];
                }
                this.alignments = [], this.score = -1, this.computeGrids();
              }
              return u(e, [{
                key: "getScore",
                value: function() {
                  return this.score;
                }
              }, {
                key: "getAlignments",
                value: function() {
                  return this.alignments;
                }
                // Main dynamic programming procedure
              }, {
                key: "computeGrids",
                value: function() {
                  for (var f = 1; f < this.jMax; f++)
                    this.grid[0][f] = this.grid[0][f - 1] + this.gap_penalty, this.tracebackGrid[0][f] = [!1, !1, !0];
                  for (var i = 1; i < this.iMax; i++)
                    this.grid[i][0] = this.grid[i - 1][0] + this.gap_penalty, this.tracebackGrid[i][0] = [!1, !0, !1];
                  for (var g = 1; g < this.iMax; g++)
                    for (var t = 1; t < this.jMax; t++) {
                      var s = void 0;
                      this.sequence1[g - 1] === this.sequence2[t - 1] ? s = this.grid[g - 1][t - 1] + this.match_score : s = this.grid[g - 1][t - 1] + this.mismatch_penalty;
                      var o = this.grid[g - 1][t] + this.gap_penalty, c = this.grid[g][t - 1] + this.gap_penalty, h = [s, o, c], T = this.arrayAllMaxIndexes(h);
                      this.grid[g][t] = h[T[0]], this.tracebackGrid[g][t] = [T.includes(0), T.includes(1), T.includes(2)];
                    }
                  this.score = this.grid[this.iMax - 1][this.jMax - 1];
                }
                // Gets all possible valid sequence combinations
              }, {
                key: "alignmentTraceback",
                value: function() {
                  var f = [];
                  for (f.push({
                    pos: [this.sequence1.length, this.sequence2.length],
                    seq1: "",
                    seq2: ""
                  }); f[0]; ) {
                    var i = f[0], g = this.tracebackGrid[i.pos[0]][i.pos[1]];
                    g[0] && f.push({
                      pos: [i.pos[0] - 1, i.pos[1] - 1],
                      seq1: this.sequence1[i.pos[0] - 1] + i.seq1,
                      seq2: this.sequence2[i.pos[1] - 1] + i.seq2
                    }), g[1] && f.push({
                      pos: [i.pos[0] - 1, i.pos[1]],
                      seq1: this.sequence1[i.pos[0] - 1] + i.seq1,
                      seq2: "-" + i.seq2
                    }), g[2] && f.push({
                      pos: [i.pos[0], i.pos[1] - 1],
                      seq1: "-" + i.seq1,
                      seq2: this.sequence2[i.pos[1] - 1] + i.seq2
                    }), i.pos[0] === 0 && i.pos[1] === 0 && this.alignments.push({
                      sequence1: i.seq1,
                      sequence2: i.seq2
                    }), f.shift();
                  }
                  return this.alignments;
                }
                // Helper Functions
              }, {
                key: "getAllIndexes",
                value: function(f, i) {
                  for (var g = [], t = -1; (t = f.indexOf(i, t + 1)) !== -1; )
                    g.push(t);
                  return g;
                }
              }, {
                key: "arrayAllMaxIndexes",
                value: function(f) {
                  return this.getAllIndexes(f, Math.max.apply(null, f));
                }
              }]), e;
            }();
            A.exports = a;
          },
          /* 28 */
          /***/
          function(A, P, N) {
            var u = function() {
            };
            u.FDLayout = N(18), u.FDLayoutConstants = N(4), u.FDLayoutEdge = N(19), u.FDLayoutNode = N(20), u.DimensionD = N(21), u.HashMap = N(22), u.HashSet = N(23), u.IGeometry = N(8), u.IMath = N(9), u.Integer = N(10), u.Point = N(12), u.PointD = N(5), u.RandomSeed = N(16), u.RectangleD = N(13), u.Transform = N(17), u.UniqueIDGeneretor = N(14), u.Quicksort = N(25), u.LinkedList = N(11), u.LGraphObject = N(2), u.LGraph = N(6), u.LEdge = N(1), u.LGraphManager = N(7), u.LNode = N(3), u.Layout = N(15), u.LayoutConstants = N(0), u.NeedlemanWunsch = N(27), u.Matrix = N(24), u.SVD = N(26), A.exports = u;
          },
          /* 29 */
          /***/
          function(A, P, N) {
            function u() {
              this.listeners = [];
            }
            var l = u.prototype;
            l.addListener = function(a, e) {
              this.listeners.push({
                event: a,
                callback: e
              });
            }, l.removeListener = function(a, e) {
              for (var r = this.listeners.length; r >= 0; r--) {
                var f = this.listeners[r];
                f.event === a && f.callback === e && this.listeners.splice(r, 1);
              }
            }, l.emit = function(a, e) {
              for (var r = 0; r < this.listeners.length; r++) {
                var f = this.listeners[r];
                a === f.event && f.callback(e);
              }
            }, A.exports = u;
          }
          /******/
        ])
      );
    });
  }(de)), de.exports;
}
var Oe;
function gr() {
  return Oe || (Oe = 1, function(I, D) {
    (function(P, N) {
      I.exports = N(cr());
    })(me, function(A) {
      return (
        /******/
        (() => {
          var P = {
            /***/
            45: (
              /***/
              (a, e, r) => {
                var f = {};
                f.layoutBase = r(551), f.CoSEConstants = r(806), f.CoSEEdge = r(767), f.CoSEGraph = r(880), f.CoSEGraphManager = r(578), f.CoSELayout = r(765), f.CoSENode = r(991), f.ConstraintHandler = r(902), a.exports = f;
              }
            ),
            /***/
            806: (
              /***/
              (a, e, r) => {
                var f = r(551).FDLayoutConstants;
                function i() {
                }
                for (var g in f)
                  i[g] = f[g];
                i.DEFAULT_USE_MULTI_LEVEL_SCALING = !1, i.DEFAULT_RADIAL_SEPARATION = f.DEFAULT_EDGE_LENGTH, i.DEFAULT_COMPONENT_SEPERATION = 60, i.TILE = !0, i.TILING_PADDING_VERTICAL = 10, i.TILING_PADDING_HORIZONTAL = 10, i.TRANSFORM_ON_CONSTRAINT_HANDLING = !0, i.ENFORCE_CONSTRAINTS = !0, i.APPLY_LAYOUT = !0, i.RELAX_MOVEMENT_ON_CONSTRAINTS = !0, i.TREE_REDUCTION_ON_INCREMENTAL = !0, i.PURE_INCREMENTAL = i.DEFAULT_INCREMENTAL, a.exports = i;
              }
            ),
            /***/
            767: (
              /***/
              (a, e, r) => {
                var f = r(551).FDLayoutEdge;
                function i(t, s, o) {
                  f.call(this, t, s, o);
                }
                i.prototype = Object.create(f.prototype);
                for (var g in f)
                  i[g] = f[g];
                a.exports = i;
              }
            ),
            /***/
            880: (
              /***/
              (a, e, r) => {
                var f = r(551).LGraph;
                function i(t, s, o) {
                  f.call(this, t, s, o);
                }
                i.prototype = Object.create(f.prototype);
                for (var g in f)
                  i[g] = f[g];
                a.exports = i;
              }
            ),
            /***/
            578: (
              /***/
              (a, e, r) => {
                var f = r(551).LGraphManager;
                function i(t) {
                  f.call(this, t);
                }
                i.prototype = Object.create(f.prototype);
                for (var g in f)
                  i[g] = f[g];
                a.exports = i;
              }
            ),
            /***/
            765: (
              /***/
              (a, e, r) => {
                var f = r(551).FDLayout, i = r(578), g = r(880), t = r(991), s = r(767), o = r(806), c = r(902), h = r(551).FDLayoutConstants, T = r(551).LayoutConstants, d = r(551).Point, v = r(551).PointD, L = r(551).DimensionD, S = r(551).Layout, C = r(551).Integer, G = r(551).IGeometry, K = r(551).LGraph, X = r(551).Transform, Q = r(551).LinkedList;
                function O() {
                  f.call(this), this.toBeTiled = {}, this.constraints = {};
                }
                O.prototype = Object.create(f.prototype);
                for (var rt in f)
                  O[rt] = f[rt];
                O.prototype.newGraphManager = function() {
                  var n = new i(this);
                  return this.graphManager = n, n;
                }, O.prototype.newGraph = function(n) {
                  return new g(null, this.graphManager, n);
                }, O.prototype.newNode = function(n) {
                  return new t(this.graphManager, n);
                }, O.prototype.newEdge = function(n) {
                  return new s(null, null, n);
                }, O.prototype.initParameters = function() {
                  f.prototype.initParameters.call(this, arguments), this.isSubLayout || (o.DEFAULT_EDGE_LENGTH < 10 ? this.idealEdgeLength = 10 : this.idealEdgeLength = o.DEFAULT_EDGE_LENGTH, this.useSmartIdealEdgeLengthCalculation = o.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION, this.gravityConstant = h.DEFAULT_GRAVITY_STRENGTH, this.compoundGravityConstant = h.DEFAULT_COMPOUND_GRAVITY_STRENGTH, this.gravityRangeFactor = h.DEFAULT_GRAVITY_RANGE_FACTOR, this.compoundGravityRangeFactor = h.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR, this.prunedNodesAll = [], this.growTreeIterations = 0, this.afterGrowthIterations = 0, this.isTreeGrowing = !1, this.isGrowthFinished = !1);
                }, O.prototype.initSpringEmbedder = function() {
                  f.prototype.initSpringEmbedder.call(this), this.coolingCycle = 0, this.maxCoolingCycle = this.maxIterations / h.CONVERGENCE_CHECK_PERIOD, this.finalTemperature = 0.04, this.coolingAdjuster = 1;
                }, O.prototype.layout = function() {
                  var n = T.DEFAULT_CREATE_BENDS_AS_NEEDED;
                  return n && (this.createBendpoints(), this.graphManager.resetAllEdges()), this.level = 0, this.classicLayout();
                }, O.prototype.classicLayout = function() {
                  if (this.nodesWithGravity = this.calculateNodesToApplyGravitationTo(), this.graphManager.setAllNodesToApplyGravitation(this.nodesWithGravity), this.calcNoOfChildrenForAllNodes(), this.graphManager.calcLowestCommonAncestors(), this.graphManager.calcInclusionTreeDepths(), this.graphManager.getRoot().calcEstimatedSize(), this.calcIdealEdgeLengths(), this.incremental) {
                    if (o.TREE_REDUCTION_ON_INCREMENTAL) {
                      this.reduceTrees(), this.graphManager.resetAllNodesToApplyGravitation();
                      var m = new Set(this.getAllNodes()), p = this.nodesWithGravity.filter(function(R) {
                        return m.has(R);
                      });
                      this.graphManager.setAllNodesToApplyGravitation(p);
                    }
                  } else {
                    var n = this.getFlatForest();
                    if (n.length > 0)
                      this.positionNodesRadially(n);
                    else {
                      this.reduceTrees(), this.graphManager.resetAllNodesToApplyGravitation();
                      var m = new Set(this.getAllNodes()), p = this.nodesWithGravity.filter(function(E) {
                        return m.has(E);
                      });
                      this.graphManager.setAllNodesToApplyGravitation(p), this.positionNodesRandomly();
                    }
                  }
                  return Object.keys(this.constraints).length > 0 && (c.handleConstraints(this), this.initConstraintVariables()), this.initSpringEmbedder(), o.APPLY_LAYOUT && this.runSpringEmbedder(), !0;
                }, O.prototype.tick = function() {
                  if (this.totalIterations++, this.totalIterations === this.maxIterations && !this.isTreeGrowing && !this.isGrowthFinished)
                    if (this.prunedNodesAll.length > 0)
                      this.isTreeGrowing = !0;
                    else
                      return !0;
                  if (this.totalIterations % h.CONVERGENCE_CHECK_PERIOD == 0 && !this.isTreeGrowing && !this.isGrowthFinished) {
                    if (this.isConverged())
                      if (this.prunedNodesAll.length > 0)
                        this.isTreeGrowing = !0;
                      else
                        return !0;
                    this.coolingCycle++, this.layoutQuality == 0 ? this.coolingAdjuster = this.coolingCycle : this.layoutQuality == 1 && (this.coolingAdjuster = this.coolingCycle / 3), this.coolingFactor = Math.max(this.initialCoolingFactor - Math.pow(this.coolingCycle, Math.log(100 * (this.initialCoolingFactor - this.finalTemperature)) / Math.log(this.maxCoolingCycle)) / 100 * this.coolingAdjuster, this.finalTemperature), this.animationPeriod = Math.ceil(this.initialAnimationPeriod * Math.sqrt(this.coolingFactor));
                  }
                  if (this.isTreeGrowing) {
                    if (this.growTreeIterations % 10 == 0)
                      if (this.prunedNodesAll.length > 0) {
                        this.graphManager.updateBounds(), this.updateGrid(), this.growTree(this.prunedNodesAll), this.graphManager.resetAllNodesToApplyGravitation();
                        var n = new Set(this.getAllNodes()), m = this.nodesWithGravity.filter(function(y) {
                          return n.has(y);
                        });
                        this.graphManager.setAllNodesToApplyGravitation(m), this.graphManager.updateBounds(), this.updateGrid(), o.PURE_INCREMENTAL ? this.coolingFactor = h.DEFAULT_COOLING_FACTOR_INCREMENTAL / 2 : this.coolingFactor = h.DEFAULT_COOLING_FACTOR_INCREMENTAL;
                      } else
                        this.isTreeGrowing = !1, this.isGrowthFinished = !0;
                    this.growTreeIterations++;
                  }
                  if (this.isGrowthFinished) {
                    if (this.isConverged())
                      return !0;
                    this.afterGrowthIterations % 10 == 0 && (this.graphManager.updateBounds(), this.updateGrid()), o.PURE_INCREMENTAL ? this.coolingFactor = h.DEFAULT_COOLING_FACTOR_INCREMENTAL / 2 * ((100 - this.afterGrowthIterations) / 100) : this.coolingFactor = h.DEFAULT_COOLING_FACTOR_INCREMENTAL * ((100 - this.afterGrowthIterations) / 100), this.afterGrowthIterations++;
                  }
                  var p = !this.isTreeGrowing && !this.isGrowthFinished, E = this.growTreeIterations % 10 == 1 && this.isTreeGrowing || this.afterGrowthIterations % 10 == 1 && this.isGrowthFinished;
                  return this.totalDisplacement = 0, this.graphManager.updateBounds(), this.calcSpringForces(), this.calcRepulsionForces(p, E), this.calcGravitationalForces(), this.moveNodes(), this.animate(), !1;
                }, O.prototype.getPositionsData = function() {
                  for (var n = this.graphManager.getAllNodes(), m = {}, p = 0; p < n.length; p++) {
                    var E = n[p].rect, y = n[p].id;
                    m[y] = {
                      id: y,
                      x: E.getCenterX(),
                      y: E.getCenterY(),
                      w: E.width,
                      h: E.height
                    };
                  }
                  return m;
                }, O.prototype.runSpringEmbedder = function() {
                  this.initialAnimationPeriod = 25, this.animationPeriod = this.initialAnimationPeriod;
                  var n = !1;
                  if (h.ANIMATE === "during")
                    this.emit("layoutstarted");
                  else {
                    for (; !n; )
                      n = this.tick();
                    this.graphManager.updateBounds();
                  }
                }, O.prototype.moveNodes = function() {
                  for (var n = this.getAllNodes(), m, p = 0; p < n.length; p++)
                    m = n[p], m.calculateDisplacement();
                  Object.keys(this.constraints).length > 0 && this.updateDisplacements();
                  for (var p = 0; p < n.length; p++)
                    m = n[p], m.move();
                }, O.prototype.initConstraintVariables = function() {
                  var n = this;
                  this.idToNodeMap = /* @__PURE__ */ new Map(), this.fixedNodeSet = /* @__PURE__ */ new Set();
                  for (var m = this.graphManager.getAllNodes(), p = 0; p < m.length; p++) {
                    var E = m[p];
                    this.idToNodeMap.set(E.id, E);
                  }
                  var y = function w(H) {
                    for (var B = H.getChild().getNodes(), _, ht = 0, q = 0; q < B.length; q++)
                      _ = B[q], _.getChild() == null ? n.fixedNodeSet.has(_.id) && (ht += 100) : ht += w(_);
                    return ht;
                  };
                  if (this.constraints.fixedNodeConstraint) {
                    this.constraints.fixedNodeConstraint.forEach(function(B) {
                      n.fixedNodeSet.add(B.nodeId);
                    });
                    for (var m = this.graphManager.getAllNodes(), E, p = 0; p < m.length; p++)
                      if (E = m[p], E.getChild() != null) {
                        var R = y(E);
                        R > 0 && (E.fixedNodeWeight = R);
                      }
                  }
                  if (this.constraints.relativePlacementConstraint) {
                    var M = /* @__PURE__ */ new Map(), F = /* @__PURE__ */ new Map();
                    if (this.dummyToNodeForVerticalAlignment = /* @__PURE__ */ new Map(), this.dummyToNodeForHorizontalAlignment = /* @__PURE__ */ new Map(), this.fixedNodesOnHorizontal = /* @__PURE__ */ new Set(), this.fixedNodesOnVertical = /* @__PURE__ */ new Set(), this.fixedNodeSet.forEach(function(w) {
                      n.fixedNodesOnHorizontal.add(w), n.fixedNodesOnVertical.add(w);
                    }), this.constraints.alignmentConstraint) {
                      if (this.constraints.alignmentConstraint.vertical)
                        for (var W = this.constraints.alignmentConstraint.vertical, p = 0; p < W.length; p++)
                          this.dummyToNodeForVerticalAlignment.set("dummy" + p, []), W[p].forEach(function(H) {
                            M.set(H, "dummy" + p), n.dummyToNodeForVerticalAlignment.get("dummy" + p).push(H), n.fixedNodeSet.has(H) && n.fixedNodesOnHorizontal.add("dummy" + p);
                          });
                      if (this.constraints.alignmentConstraint.horizontal)
                        for (var x = this.constraints.alignmentConstraint.horizontal, p = 0; p < x.length; p++)
                          this.dummyToNodeForHorizontalAlignment.set("dummy" + p, []), x[p].forEach(function(H) {
                            F.set(H, "dummy" + p), n.dummyToNodeForHorizontalAlignment.get("dummy" + p).push(H), n.fixedNodeSet.has(H) && n.fixedNodesOnVertical.add("dummy" + p);
                          });
                    }
                    if (o.RELAX_MOVEMENT_ON_CONSTRAINTS)
                      this.shuffle = function(w) {
                        var H, B, _;
                        for (_ = w.length - 1; _ >= 2 * w.length / 3; _--)
                          H = Math.floor(Math.random() * (_ + 1)), B = w[_], w[_] = w[H], w[H] = B;
                        return w;
                      }, this.nodesInRelativeHorizontal = [], this.nodesInRelativeVertical = [], this.nodeToRelativeConstraintMapHorizontal = /* @__PURE__ */ new Map(), this.nodeToRelativeConstraintMapVertical = /* @__PURE__ */ new Map(), this.nodeToTempPositionMapHorizontal = /* @__PURE__ */ new Map(), this.nodeToTempPositionMapVertical = /* @__PURE__ */ new Map(), this.constraints.relativePlacementConstraint.forEach(function(w) {
                        if (w.left) {
                          var H = M.has(w.left) ? M.get(w.left) : w.left, B = M.has(w.right) ? M.get(w.right) : w.right;
                          n.nodesInRelativeHorizontal.includes(H) || (n.nodesInRelativeHorizontal.push(H), n.nodeToRelativeConstraintMapHorizontal.set(H, []), n.dummyToNodeForVerticalAlignment.has(H) ? n.nodeToTempPositionMapHorizontal.set(H, n.idToNodeMap.get(n.dummyToNodeForVerticalAlignment.get(H)[0]).getCenterX()) : n.nodeToTempPositionMapHorizontal.set(H, n.idToNodeMap.get(H).getCenterX())), n.nodesInRelativeHorizontal.includes(B) || (n.nodesInRelativeHorizontal.push(B), n.nodeToRelativeConstraintMapHorizontal.set(B, []), n.dummyToNodeForVerticalAlignment.has(B) ? n.nodeToTempPositionMapHorizontal.set(B, n.idToNodeMap.get(n.dummyToNodeForVerticalAlignment.get(B)[0]).getCenterX()) : n.nodeToTempPositionMapHorizontal.set(B, n.idToNodeMap.get(B).getCenterX())), n.nodeToRelativeConstraintMapHorizontal.get(H).push({ right: B, gap: w.gap }), n.nodeToRelativeConstraintMapHorizontal.get(B).push({ left: H, gap: w.gap });
                        } else {
                          var _ = F.has(w.top) ? F.get(w.top) : w.top, ht = F.has(w.bottom) ? F.get(w.bottom) : w.bottom;
                          n.nodesInRelativeVertical.includes(_) || (n.nodesInRelativeVertical.push(_), n.nodeToRelativeConstraintMapVertical.set(_, []), n.dummyToNodeForHorizontalAlignment.has(_) ? n.nodeToTempPositionMapVertical.set(_, n.idToNodeMap.get(n.dummyToNodeForHorizontalAlignment.get(_)[0]).getCenterY()) : n.nodeToTempPositionMapVertical.set(_, n.idToNodeMap.get(_).getCenterY())), n.nodesInRelativeVertical.includes(ht) || (n.nodesInRelativeVertical.push(ht), n.nodeToRelativeConstraintMapVertical.set(ht, []), n.dummyToNodeForHorizontalAlignment.has(ht) ? n.nodeToTempPositionMapVertical.set(ht, n.idToNodeMap.get(n.dummyToNodeForHorizontalAlignment.get(ht)[0]).getCenterY()) : n.nodeToTempPositionMapVertical.set(ht, n.idToNodeMap.get(ht).getCenterY())), n.nodeToRelativeConstraintMapVertical.get(_).push({ bottom: ht, gap: w.gap }), n.nodeToRelativeConstraintMapVertical.get(ht).push({ top: _, gap: w.gap });
                        }
                      });
                    else {
                      var Z = /* @__PURE__ */ new Map(), V = /* @__PURE__ */ new Map();
                      this.constraints.relativePlacementConstraint.forEach(function(w) {
                        if (w.left) {
                          var H = M.has(w.left) ? M.get(w.left) : w.left, B = M.has(w.right) ? M.get(w.right) : w.right;
                          Z.has(H) ? Z.get(H).push(B) : Z.set(H, [B]), Z.has(B) ? Z.get(B).push(H) : Z.set(B, [H]);
                        } else {
                          var _ = F.has(w.top) ? F.get(w.top) : w.top, ht = F.has(w.bottom) ? F.get(w.bottom) : w.bottom;
                          V.has(_) ? V.get(_).push(ht) : V.set(_, [ht]), V.has(ht) ? V.get(ht).push(_) : V.set(ht, [_]);
                        }
                      });
                      var Y = function(H, B) {
                        var _ = [], ht = [], q = new Q(), It = /* @__PURE__ */ new Set(), Nt = 0;
                        return H.forEach(function(vt, it) {
                          if (!It.has(it)) {
                            _[Nt] = [], ht[Nt] = !1;
                            var gt = it;
                            for (q.push(gt), It.add(gt), _[Nt].push(gt); q.length != 0; ) {
                              gt = q.shift(), B.has(gt) && (ht[Nt] = !0);
                              var mt = H.get(gt);
                              mt.forEach(function(At) {
                                It.has(At) || (q.push(At), It.add(At), _[Nt].push(At));
                              });
                            }
                            Nt++;
                          }
                        }), { components: _, isFixed: ht };
                      }, et = Y(Z, n.fixedNodesOnHorizontal);
                      this.componentsOnHorizontal = et.components, this.fixedComponentsOnHorizontal = et.isFixed;
                      var z = Y(V, n.fixedNodesOnVertical);
                      this.componentsOnVertical = z.components, this.fixedComponentsOnVertical = z.isFixed;
                    }
                  }
                }, O.prototype.updateDisplacements = function() {
                  var n = this;
                  if (this.constraints.fixedNodeConstraint && this.constraints.fixedNodeConstraint.forEach(function(z) {
                    var w = n.idToNodeMap.get(z.nodeId);
                    w.displacementX = 0, w.displacementY = 0;
                  }), this.constraints.alignmentConstraint) {
                    if (this.constraints.alignmentConstraint.vertical)
                      for (var m = this.constraints.alignmentConstraint.vertical, p = 0; p < m.length; p++) {
                        for (var E = 0, y = 0; y < m[p].length; y++) {
                          if (this.fixedNodeSet.has(m[p][y])) {
                            E = 0;
                            break;
                          }
                          E += this.idToNodeMap.get(m[p][y]).displacementX;
                        }
                        for (var R = E / m[p].length, y = 0; y < m[p].length; y++)
                          this.idToNodeMap.get(m[p][y]).displacementX = R;
                      }
                    if (this.constraints.alignmentConstraint.horizontal)
                      for (var M = this.constraints.alignmentConstraint.horizontal, p = 0; p < M.length; p++) {
                        for (var F = 0, y = 0; y < M[p].length; y++) {
                          if (this.fixedNodeSet.has(M[p][y])) {
                            F = 0;
                            break;
                          }
                          F += this.idToNodeMap.get(M[p][y]).displacementY;
                        }
                        for (var W = F / M[p].length, y = 0; y < M[p].length; y++)
                          this.idToNodeMap.get(M[p][y]).displacementY = W;
                      }
                  }
                  if (this.constraints.relativePlacementConstraint)
                    if (o.RELAX_MOVEMENT_ON_CONSTRAINTS)
                      this.totalIterations % 10 == 0 && (this.shuffle(this.nodesInRelativeHorizontal), this.shuffle(this.nodesInRelativeVertical)), this.nodesInRelativeHorizontal.forEach(function(z) {
                        if (!n.fixedNodesOnHorizontal.has(z)) {
                          var w = 0;
                          n.dummyToNodeForVerticalAlignment.has(z) ? w = n.idToNodeMap.get(n.dummyToNodeForVerticalAlignment.get(z)[0]).displacementX : w = n.idToNodeMap.get(z).displacementX, n.nodeToRelativeConstraintMapHorizontal.get(z).forEach(function(H) {
                            if (H.right) {
                              var B = n.nodeToTempPositionMapHorizontal.get(H.right) - n.nodeToTempPositionMapHorizontal.get(z) - w;
                              B < H.gap && (w -= H.gap - B);
                            } else {
                              var B = n.nodeToTempPositionMapHorizontal.get(z) - n.nodeToTempPositionMapHorizontal.get(H.left) + w;
                              B < H.gap && (w += H.gap - B);
                            }
                          }), n.nodeToTempPositionMapHorizontal.set(z, n.nodeToTempPositionMapHorizontal.get(z) + w), n.dummyToNodeForVerticalAlignment.has(z) ? n.dummyToNodeForVerticalAlignment.get(z).forEach(function(H) {
                            n.idToNodeMap.get(H).displacementX = w;
                          }) : n.idToNodeMap.get(z).displacementX = w;
                        }
                      }), this.nodesInRelativeVertical.forEach(function(z) {
                        if (!n.fixedNodesOnHorizontal.has(z)) {
                          var w = 0;
                          n.dummyToNodeForHorizontalAlignment.has(z) ? w = n.idToNodeMap.get(n.dummyToNodeForHorizontalAlignment.get(z)[0]).displacementY : w = n.idToNodeMap.get(z).displacementY, n.nodeToRelativeConstraintMapVertical.get(z).forEach(function(H) {
                            if (H.bottom) {
                              var B = n.nodeToTempPositionMapVertical.get(H.bottom) - n.nodeToTempPositionMapVertical.get(z) - w;
                              B < H.gap && (w -= H.gap - B);
                            } else {
                              var B = n.nodeToTempPositionMapVertical.get(z) - n.nodeToTempPositionMapVertical.get(H.top) + w;
                              B < H.gap && (w += H.gap - B);
                            }
                          }), n.nodeToTempPositionMapVertical.set(z, n.nodeToTempPositionMapVertical.get(z) + w), n.dummyToNodeForHorizontalAlignment.has(z) ? n.dummyToNodeForHorizontalAlignment.get(z).forEach(function(H) {
                            n.idToNodeMap.get(H).displacementY = w;
                          }) : n.idToNodeMap.get(z).displacementY = w;
                        }
                      });
                    else {
                      for (var p = 0; p < this.componentsOnHorizontal.length; p++) {
                        var x = this.componentsOnHorizontal[p];
                        if (this.fixedComponentsOnHorizontal[p])
                          for (var y = 0; y < x.length; y++)
                            this.dummyToNodeForVerticalAlignment.has(x[y]) ? this.dummyToNodeForVerticalAlignment.get(x[y]).forEach(function(H) {
                              n.idToNodeMap.get(H).displacementX = 0;
                            }) : this.idToNodeMap.get(x[y]).displacementX = 0;
                        else {
                          for (var Z = 0, V = 0, y = 0; y < x.length; y++)
                            if (this.dummyToNodeForVerticalAlignment.has(x[y])) {
                              var Y = this.dummyToNodeForVerticalAlignment.get(x[y]);
                              Z += Y.length * this.idToNodeMap.get(Y[0]).displacementX, V += Y.length;
                            } else
                              Z += this.idToNodeMap.get(x[y]).displacementX, V++;
                          for (var et = Z / V, y = 0; y < x.length; y++)
                            this.dummyToNodeForVerticalAlignment.has(x[y]) ? this.dummyToNodeForVerticalAlignment.get(x[y]).forEach(function(H) {
                              n.idToNodeMap.get(H).displacementX = et;
                            }) : this.idToNodeMap.get(x[y]).displacementX = et;
                        }
                      }
                      for (var p = 0; p < this.componentsOnVertical.length; p++) {
                        var x = this.componentsOnVertical[p];
                        if (this.fixedComponentsOnVertical[p])
                          for (var y = 0; y < x.length; y++)
                            this.dummyToNodeForHorizontalAlignment.has(x[y]) ? this.dummyToNodeForHorizontalAlignment.get(x[y]).forEach(function(B) {
                              n.idToNodeMap.get(B).displacementY = 0;
                            }) : this.idToNodeMap.get(x[y]).displacementY = 0;
                        else {
                          for (var Z = 0, V = 0, y = 0; y < x.length; y++)
                            if (this.dummyToNodeForHorizontalAlignment.has(x[y])) {
                              var Y = this.dummyToNodeForHorizontalAlignment.get(x[y]);
                              Z += Y.length * this.idToNodeMap.get(Y[0]).displacementY, V += Y.length;
                            } else
                              Z += this.idToNodeMap.get(x[y]).displacementY, V++;
                          for (var et = Z / V, y = 0; y < x.length; y++)
                            this.dummyToNodeForHorizontalAlignment.has(x[y]) ? this.dummyToNodeForHorizontalAlignment.get(x[y]).forEach(function(q) {
                              n.idToNodeMap.get(q).displacementY = et;
                            }) : this.idToNodeMap.get(x[y]).displacementY = et;
                        }
                      }
                    }
                }, O.prototype.calculateNodesToApplyGravitationTo = function() {
                  var n = [], m, p = this.graphManager.getGraphs(), E = p.length, y;
                  for (y = 0; y < E; y++)
                    m = p[y], m.updateConnected(), m.isConnected || (n = n.concat(m.getNodes()));
                  return n;
                }, O.prototype.createBendpoints = function() {
                  var n = [];
                  n = n.concat(this.graphManager.getAllEdges());
                  var m = /* @__PURE__ */ new Set(), p;
                  for (p = 0; p < n.length; p++) {
                    var E = n[p];
                    if (!m.has(E)) {
                      var y = E.getSource(), R = E.getTarget();
                      if (y == R)
                        E.getBendpoints().push(new v()), E.getBendpoints().push(new v()), this.createDummyNodesForBendpoints(E), m.add(E);
                      else {
                        var M = [];
                        if (M = M.concat(y.getEdgeListToNode(R)), M = M.concat(R.getEdgeListToNode(y)), !m.has(M[0])) {
                          if (M.length > 1) {
                            var F;
                            for (F = 0; F < M.length; F++) {
                              var W = M[F];
                              W.getBendpoints().push(new v()), this.createDummyNodesForBendpoints(W);
                            }
                          }
                          M.forEach(function(x) {
                            m.add(x);
                          });
                        }
                      }
                    }
                    if (m.size == n.length)
                      break;
                  }
                }, O.prototype.positionNodesRadially = function(n) {
                  for (var m = new d(0, 0), p = Math.ceil(Math.sqrt(n.length)), E = 0, y = 0, R = 0, M = new v(0, 0), F = 0; F < n.length; F++) {
                    F % p == 0 && (R = 0, y = E, F != 0 && (y += o.DEFAULT_COMPONENT_SEPERATION), E = 0);
                    var W = n[F], x = S.findCenterOfTree(W);
                    m.x = R, m.y = y, M = O.radialLayout(W, x, m), M.y > E && (E = Math.floor(M.y)), R = Math.floor(M.x + o.DEFAULT_COMPONENT_SEPERATION);
                  }
                  this.transform(new v(T.WORLD_CENTER_X - M.x / 2, T.WORLD_CENTER_Y - M.y / 2));
                }, O.radialLayout = function(n, m, p) {
                  var E = Math.max(this.maxDiagonalInTree(n), o.DEFAULT_RADIAL_SEPARATION);
                  O.branchRadialLayout(m, null, 0, 359, 0, E);
                  var y = K.calculateBounds(n), R = new X();
                  R.setDeviceOrgX(y.getMinX()), R.setDeviceOrgY(y.getMinY()), R.setWorldOrgX(p.x), R.setWorldOrgY(p.y);
                  for (var M = 0; M < n.length; M++) {
                    var F = n[M];
                    F.transform(R);
                  }
                  var W = new v(y.getMaxX(), y.getMaxY());
                  return R.inverseTransformPoint(W);
                }, O.branchRadialLayout = function(n, m, p, E, y, R) {
                  var M = (E - p + 1) / 2;
                  M < 0 && (M += 180);
                  var F = (M + p) % 360, W = F * G.TWO_PI / 360, x = y * Math.cos(W), Z = y * Math.sin(W);
                  n.setCenter(x, Z);
                  var V = [];
                  V = V.concat(n.getEdges());
                  var Y = V.length;
                  m != null && Y--;
                  for (var et = 0, z = V.length, w, H = n.getEdgesBetween(m); H.length > 1; ) {
                    var B = H[0];
                    H.splice(0, 1);
                    var _ = V.indexOf(B);
                    _ >= 0 && V.splice(_, 1), z--, Y--;
                  }
                  m != null ? w = (V.indexOf(H[0]) + 1) % z : w = 0;
                  for (var ht = Math.abs(E - p) / Y, q = w; et != Y; q = ++q % z) {
                    var It = V[q].getOtherEnd(n);
                    if (It != m) {
                      var Nt = (p + et * ht) % 360, vt = (Nt + ht) % 360;
                      O.branchRadialLayout(It, n, Nt, vt, y + R, R), et++;
                    }
                  }
                }, O.maxDiagonalInTree = function(n) {
                  for (var m = C.MIN_VALUE, p = 0; p < n.length; p++) {
                    var E = n[p], y = E.getDiagonal();
                    y > m && (m = y);
                  }
                  return m;
                }, O.prototype.calcRepulsionRange = function() {
                  return 2 * (this.level + 1) * this.idealEdgeLength;
                }, O.prototype.groupZeroDegreeMembers = function() {
                  var n = this, m = {};
                  this.memberGroups = {}, this.idToDummyNode = {};
                  for (var p = [], E = this.graphManager.getAllNodes(), y = 0; y < E.length; y++) {
                    var R = E[y], M = R.getParent();
                    this.getNodeDegreeWithChildren(R) === 0 && (M.id == null || !this.getToBeTiled(M)) && p.push(R);
                  }
                  for (var y = 0; y < p.length; y++) {
                    var R = p[y], F = R.getParent().id;
                    typeof m[F] > "u" && (m[F] = []), m[F] = m[F].concat(R);
                  }
                  Object.keys(m).forEach(function(W) {
                    if (m[W].length > 1) {
                      var x = "DummyCompound_" + W;
                      n.memberGroups[x] = m[W];
                      var Z = m[W][0].getParent(), V = new t(n.graphManager);
                      V.id = x, V.paddingLeft = Z.paddingLeft || 0, V.paddingRight = Z.paddingRight || 0, V.paddingBottom = Z.paddingBottom || 0, V.paddingTop = Z.paddingTop || 0, n.idToDummyNode[x] = V;
                      var Y = n.getGraphManager().add(n.newGraph(), V), et = Z.getChild();
                      et.add(V);
                      for (var z = 0; z < m[W].length; z++) {
                        var w = m[W][z];
                        et.remove(w), Y.add(w);
                      }
                    }
                  });
                }, O.prototype.clearCompounds = function() {
                  var n = {}, m = {};
                  this.performDFSOnCompounds();
                  for (var p = 0; p < this.compoundOrder.length; p++)
                    m[this.compoundOrder[p].id] = this.compoundOrder[p], n[this.compoundOrder[p].id] = [].concat(this.compoundOrder[p].getChild().getNodes()), this.graphManager.remove(this.compoundOrder[p].getChild()), this.compoundOrder[p].child = null;
                  this.graphManager.resetAllNodes(), this.tileCompoundMembers(n, m);
                }, O.prototype.clearZeroDegreeMembers = function() {
                  var n = this, m = this.tiledZeroDegreePack = [];
                  Object.keys(this.memberGroups).forEach(function(p) {
                    var E = n.idToDummyNode[p];
                    if (m[p] = n.tileNodes(n.memberGroups[p], E.paddingLeft + E.paddingRight), E.rect.width = m[p].width, E.rect.height = m[p].height, E.setCenter(m[p].centerX, m[p].centerY), E.labelMarginLeft = 0, E.labelMarginTop = 0, o.NODE_DIMENSIONS_INCLUDE_LABELS) {
                      var y = E.rect.width, R = E.rect.height;
                      E.labelWidth && (E.labelPosHorizontal == "left" ? (E.rect.x -= E.labelWidth, E.setWidth(y + E.labelWidth), E.labelMarginLeft = E.labelWidth) : E.labelPosHorizontal == "center" && E.labelWidth > y ? (E.rect.x -= (E.labelWidth - y) / 2, E.setWidth(E.labelWidth), E.labelMarginLeft = (E.labelWidth - y) / 2) : E.labelPosHorizontal == "right" && E.setWidth(y + E.labelWidth)), E.labelHeight && (E.labelPosVertical == "top" ? (E.rect.y -= E.labelHeight, E.setHeight(R + E.labelHeight), E.labelMarginTop = E.labelHeight) : E.labelPosVertical == "center" && E.labelHeight > R ? (E.rect.y -= (E.labelHeight - R) / 2, E.setHeight(E.labelHeight), E.labelMarginTop = (E.labelHeight - R) / 2) : E.labelPosVertical == "bottom" && E.setHeight(R + E.labelHeight));
                    }
                  });
                }, O.prototype.repopulateCompounds = function() {
                  for (var n = this.compoundOrder.length - 1; n >= 0; n--) {
                    var m = this.compoundOrder[n], p = m.id, E = m.paddingLeft, y = m.paddingTop, R = m.labelMarginLeft, M = m.labelMarginTop;
                    this.adjustLocations(this.tiledMemberPack[p], m.rect.x, m.rect.y, E, y, R, M);
                  }
                }, O.prototype.repopulateZeroDegreeMembers = function() {
                  var n = this, m = this.tiledZeroDegreePack;
                  Object.keys(m).forEach(function(p) {
                    var E = n.idToDummyNode[p], y = E.paddingLeft, R = E.paddingTop, M = E.labelMarginLeft, F = E.labelMarginTop;
                    n.adjustLocations(m[p], E.rect.x, E.rect.y, y, R, M, F);
                  });
                }, O.prototype.getToBeTiled = function(n) {
                  var m = n.id;
                  if (this.toBeTiled[m] != null)
                    return this.toBeTiled[m];
                  var p = n.getChild();
                  if (p == null)
                    return this.toBeTiled[m] = !1, !1;
                  for (var E = p.getNodes(), y = 0; y < E.length; y++) {
                    var R = E[y];
                    if (this.getNodeDegree(R) > 0)
                      return this.toBeTiled[m] = !1, !1;
                    if (R.getChild() == null) {
                      this.toBeTiled[R.id] = !1;
                      continue;
                    }
                    if (!this.getToBeTiled(R))
                      return this.toBeTiled[m] = !1, !1;
                  }
                  return this.toBeTiled[m] = !0, !0;
                }, O.prototype.getNodeDegree = function(n) {
                  n.id;
                  for (var m = n.getEdges(), p = 0, E = 0; E < m.length; E++) {
                    var y = m[E];
                    y.getSource().id !== y.getTarget().id && (p = p + 1);
                  }
                  return p;
                }, O.prototype.getNodeDegreeWithChildren = function(n) {
                  var m = this.getNodeDegree(n);
                  if (n.getChild() == null)
                    return m;
                  for (var p = n.getChild().getNodes(), E = 0; E < p.length; E++) {
                    var y = p[E];
                    m += this.getNodeDegreeWithChildren(y);
                  }
                  return m;
                }, O.prototype.performDFSOnCompounds = function() {
                  this.compoundOrder = [], this.fillCompexOrderByDFS(this.graphManager.getRoot().getNodes());
                }, O.prototype.fillCompexOrderByDFS = function(n) {
                  for (var m = 0; m < n.length; m++) {
                    var p = n[m];
                    p.getChild() != null && this.fillCompexOrderByDFS(p.getChild().getNodes()), this.getToBeTiled(p) && this.compoundOrder.push(p);
                  }
                }, O.prototype.adjustLocations = function(n, m, p, E, y, R, M) {
                  m += E + R, p += y + M;
                  for (var F = m, W = 0; W < n.rows.length; W++) {
                    var x = n.rows[W];
                    m = F;
                    for (var Z = 0, V = 0; V < x.length; V++) {
                      var Y = x[V];
                      Y.rect.x = m, Y.rect.y = p, m += Y.rect.width + n.horizontalPadding, Y.rect.height > Z && (Z = Y.rect.height);
                    }
                    p += Z + n.verticalPadding;
                  }
                }, O.prototype.tileCompoundMembers = function(n, m) {
                  var p = this;
                  this.tiledMemberPack = [], Object.keys(n).forEach(function(E) {
                    var y = m[E];
                    if (p.tiledMemberPack[E] = p.tileNodes(n[E], y.paddingLeft + y.paddingRight), y.rect.width = p.tiledMemberPack[E].width, y.rect.height = p.tiledMemberPack[E].height, y.setCenter(p.tiledMemberPack[E].centerX, p.tiledMemberPack[E].centerY), y.labelMarginLeft = 0, y.labelMarginTop = 0, o.NODE_DIMENSIONS_INCLUDE_LABELS) {
                      var R = y.rect.width, M = y.rect.height;
                      y.labelWidth && (y.labelPosHorizontal == "left" ? (y.rect.x -= y.labelWidth, y.setWidth(R + y.labelWidth), y.labelMarginLeft = y.labelWidth) : y.labelPosHorizontal == "center" && y.labelWidth > R ? (y.rect.x -= (y.labelWidth - R) / 2, y.setWidth(y.labelWidth), y.labelMarginLeft = (y.labelWidth - R) / 2) : y.labelPosHorizontal == "right" && y.setWidth(R + y.labelWidth)), y.labelHeight && (y.labelPosVertical == "top" ? (y.rect.y -= y.labelHeight, y.setHeight(M + y.labelHeight), y.labelMarginTop = y.labelHeight) : y.labelPosVertical == "center" && y.labelHeight > M ? (y.rect.y -= (y.labelHeight - M) / 2, y.setHeight(y.labelHeight), y.labelMarginTop = (y.labelHeight - M) / 2) : y.labelPosVertical == "bottom" && y.setHeight(M + y.labelHeight));
                    }
                  });
                }, O.prototype.tileNodes = function(n, m) {
                  var p = this.tileNodesByFavoringDim(n, m, !0), E = this.tileNodesByFavoringDim(n, m, !1), y = this.getOrgRatio(p), R = this.getOrgRatio(E), M;
                  return R < y ? M = E : M = p, M;
                }, O.prototype.getOrgRatio = function(n) {
                  var m = n.width, p = n.height, E = m / p;
                  return E < 1 && (E = 1 / E), E;
                }, O.prototype.calcIdealRowWidth = function(n, m) {
                  var p = o.TILING_PADDING_VERTICAL, E = o.TILING_PADDING_HORIZONTAL, y = n.length, R = 0, M = 0, F = 0;
                  n.forEach(function(z) {
                    R += z.getWidth(), M += z.getHeight(), z.getWidth() > F && (F = z.getWidth());
                  });
                  var W = R / y, x = M / y, Z = Math.pow(p - E, 2) + 4 * (W + E) * (x + p) * y, V = (E - p + Math.sqrt(Z)) / (2 * (W + E)), Y;
                  m ? (Y = Math.ceil(V), Y == V && Y++) : Y = Math.floor(V);
                  var et = Y * (W + E) - E;
                  return F > et && (et = F), et += E * 2, et;
                }, O.prototype.tileNodesByFavoringDim = function(n, m, p) {
                  var E = o.TILING_PADDING_VERTICAL, y = o.TILING_PADDING_HORIZONTAL, R = o.TILING_COMPARE_BY, M = {
                    rows: [],
                    rowWidth: [],
                    rowHeight: [],
                    width: 0,
                    height: m,
                    // assume minHeight equals to minWidth
                    verticalPadding: E,
                    horizontalPadding: y,
                    centerX: 0,
                    centerY: 0
                  };
                  R && (M.idealRowWidth = this.calcIdealRowWidth(n, p));
                  var F = function(w) {
                    return w.rect.width * w.rect.height;
                  }, W = function(w, H) {
                    return F(H) - F(w);
                  };
                  n.sort(function(z, w) {
                    var H = W;
                    return M.idealRowWidth ? (H = R, H(z.id, w.id)) : H(z, w);
                  });
                  for (var x = 0, Z = 0, V = 0; V < n.length; V++) {
                    var Y = n[V];
                    x += Y.getCenterX(), Z += Y.getCenterY();
                  }
                  M.centerX = x / n.length, M.centerY = Z / n.length;
                  for (var V = 0; V < n.length; V++) {
                    var Y = n[V];
                    if (M.rows.length == 0)
                      this.insertNodeToRow(M, Y, 0, m);
                    else if (this.canAddHorizontal(M, Y.rect.width, Y.rect.height)) {
                      var et = M.rows.length - 1;
                      M.idealRowWidth || (et = this.getShortestRowIndex(M)), this.insertNodeToRow(M, Y, et, m);
                    } else
                      this.insertNodeToRow(M, Y, M.rows.length, m);
                    this.shiftToLastRow(M);
                  }
                  return M;
                }, O.prototype.insertNodeToRow = function(n, m, p, E) {
                  var y = E;
                  if (p == n.rows.length) {
                    var R = [];
                    n.rows.push(R), n.rowWidth.push(y), n.rowHeight.push(0);
                  }
                  var M = n.rowWidth[p] + m.rect.width;
                  n.rows[p].length > 0 && (M += n.horizontalPadding), n.rowWidth[p] = M, n.width < M && (n.width = M);
                  var F = m.rect.height;
                  p > 0 && (F += n.verticalPadding);
                  var W = 0;
                  F > n.rowHeight[p] && (W = n.rowHeight[p], n.rowHeight[p] = F, W = n.rowHeight[p] - W), n.height += W, n.rows[p].push(m);
                }, O.prototype.getShortestRowIndex = function(n) {
                  for (var m = -1, p = Number.MAX_VALUE, E = 0; E < n.rows.length; E++)
                    n.rowWidth[E] < p && (m = E, p = n.rowWidth[E]);
                  return m;
                }, O.prototype.getLongestRowIndex = function(n) {
                  for (var m = -1, p = Number.MIN_VALUE, E = 0; E < n.rows.length; E++)
                    n.rowWidth[E] > p && (m = E, p = n.rowWidth[E]);
                  return m;
                }, O.prototype.canAddHorizontal = function(n, m, p) {
                  if (n.idealRowWidth) {
                    var E = n.rows.length - 1, y = n.rowWidth[E];
                    return y + m + n.horizontalPadding <= n.idealRowWidth;
                  }
                  var R = this.getShortestRowIndex(n);
                  if (R < 0)
                    return !0;
                  var M = n.rowWidth[R];
                  if (M + n.horizontalPadding + m <= n.width) return !0;
                  var F = 0;
                  n.rowHeight[R] < p && R > 0 && (F = p + n.verticalPadding - n.rowHeight[R]);
                  var W;
                  n.width - M >= m + n.horizontalPadding ? W = (n.height + F) / (M + m + n.horizontalPadding) : W = (n.height + F) / n.width, F = p + n.verticalPadding;
                  var x;
                  return n.width < m ? x = (n.height + F) / m : x = (n.height + F) / n.width, x < 1 && (x = 1 / x), W < 1 && (W = 1 / W), W < x;
                }, O.prototype.shiftToLastRow = function(n) {
                  var m = this.getLongestRowIndex(n), p = n.rowWidth.length - 1, E = n.rows[m], y = E[E.length - 1], R = y.width + n.horizontalPadding;
                  if (n.width - n.rowWidth[p] > R && m != p) {
                    E.splice(-1, 1), n.rows[p].push(y), n.rowWidth[m] = n.rowWidth[m] - R, n.rowWidth[p] = n.rowWidth[p] + R, n.width = n.rowWidth[instance.getLongestRowIndex(n)];
                    for (var M = Number.MIN_VALUE, F = 0; F < E.length; F++)
                      E[F].height > M && (M = E[F].height);
                    m > 0 && (M += n.verticalPadding);
                    var W = n.rowHeight[m] + n.rowHeight[p];
                    n.rowHeight[m] = M, n.rowHeight[p] < y.height + n.verticalPadding && (n.rowHeight[p] = y.height + n.verticalPadding);
                    var x = n.rowHeight[m] + n.rowHeight[p];
                    n.height += x - W, this.shiftToLastRow(n);
                  }
                }, O.prototype.tilingPreLayout = function() {
                  o.TILE && (this.groupZeroDegreeMembers(), this.clearCompounds(), this.clearZeroDegreeMembers());
                }, O.prototype.tilingPostLayout = function() {
                  o.TILE && (this.repopulateZeroDegreeMembers(), this.repopulateCompounds());
                }, O.prototype.reduceTrees = function() {
                  for (var n = [], m = !0, p; m; ) {
                    var E = this.graphManager.getAllNodes(), y = [];
                    m = !1;
                    for (var R = 0; R < E.length; R++)
                      if (p = E[R], p.getEdges().length == 1 && !p.getEdges()[0].isInterGraph && p.getChild() == null) {
                        if (o.PURE_INCREMENTAL) {
                          var M = p.getEdges()[0].getOtherEnd(p), F = new L(p.getCenterX() - M.getCenterX(), p.getCenterY() - M.getCenterY());
                          y.push([p, p.getEdges()[0], p.getOwner(), F]);
                        } else
                          y.push([p, p.getEdges()[0], p.getOwner()]);
                        m = !0;
                      }
                    if (m == !0) {
                      for (var W = [], x = 0; x < y.length; x++)
                        y[x][0].getEdges().length == 1 && (W.push(y[x]), y[x][0].getOwner().remove(y[x][0]));
                      n.push(W), this.graphManager.resetAllNodes(), this.graphManager.resetAllEdges();
                    }
                  }
                  this.prunedNodesAll = n;
                }, O.prototype.growTree = function(n) {
                  for (var m = n.length, p = n[m - 1], E, y = 0; y < p.length; y++)
                    E = p[y], this.findPlaceforPrunedNode(E), E[2].add(E[0]), E[2].add(E[1], E[1].source, E[1].target);
                  n.splice(n.length - 1, 1), this.graphManager.resetAllNodes(), this.graphManager.resetAllEdges();
                }, O.prototype.findPlaceforPrunedNode = function(n) {
                  var m, p, E = n[0];
                  if (E == n[1].source ? p = n[1].target : p = n[1].source, o.PURE_INCREMENTAL)
                    E.setCenter(p.getCenterX() + n[3].getWidth(), p.getCenterY() + n[3].getHeight());
                  else {
                    var y = p.startX, R = p.finishX, M = p.startY, F = p.finishY, W = 0, x = 0, Z = 0, V = 0, Y = [W, Z, x, V];
                    if (M > 0)
                      for (var et = y; et <= R; et++)
                        Y[0] += this.grid[et][M - 1].length + this.grid[et][M].length - 1;
                    if (R < this.grid.length - 1)
                      for (var et = M; et <= F; et++)
                        Y[1] += this.grid[R + 1][et].length + this.grid[R][et].length - 1;
                    if (F < this.grid[0].length - 1)
                      for (var et = y; et <= R; et++)
                        Y[2] += this.grid[et][F + 1].length + this.grid[et][F].length - 1;
                    if (y > 0)
                      for (var et = M; et <= F; et++)
                        Y[3] += this.grid[y - 1][et].length + this.grid[y][et].length - 1;
                    for (var z = C.MAX_VALUE, w, H, B = 0; B < Y.length; B++)
                      Y[B] < z ? (z = Y[B], w = 1, H = B) : Y[B] == z && w++;
                    if (w == 3 && z == 0)
                      Y[0] == 0 && Y[1] == 0 && Y[2] == 0 ? m = 1 : Y[0] == 0 && Y[1] == 0 && Y[3] == 0 ? m = 0 : Y[0] == 0 && Y[2] == 0 && Y[3] == 0 ? m = 3 : Y[1] == 0 && Y[2] == 0 && Y[3] == 0 && (m = 2);
                    else if (w == 2 && z == 0) {
                      var _ = Math.floor(Math.random() * 2);
                      Y[0] == 0 && Y[1] == 0 ? _ == 0 ? m = 0 : m = 1 : Y[0] == 0 && Y[2] == 0 ? _ == 0 ? m = 0 : m = 2 : Y[0] == 0 && Y[3] == 0 ? _ == 0 ? m = 0 : m = 3 : Y[1] == 0 && Y[2] == 0 ? _ == 0 ? m = 1 : m = 2 : Y[1] == 0 && Y[3] == 0 ? _ == 0 ? m = 1 : m = 3 : _ == 0 ? m = 2 : m = 3;
                    } else if (w == 4 && z == 0) {
                      var _ = Math.floor(Math.random() * 4);
                      m = _;
                    } else
                      m = H;
                    m == 0 ? E.setCenter(p.getCenterX(), p.getCenterY() - p.getHeight() / 2 - h.DEFAULT_EDGE_LENGTH - E.getHeight() / 2) : m == 1 ? E.setCenter(p.getCenterX() + p.getWidth() / 2 + h.DEFAULT_EDGE_LENGTH + E.getWidth() / 2, p.getCenterY()) : m == 2 ? E.setCenter(p.getCenterX(), p.getCenterY() + p.getHeight() / 2 + h.DEFAULT_EDGE_LENGTH + E.getHeight() / 2) : E.setCenter(p.getCenterX() - p.getWidth() / 2 - h.DEFAULT_EDGE_LENGTH - E.getWidth() / 2, p.getCenterY());
                  }
                }, a.exports = O;
              }
            ),
            /***/
            991: (
              /***/
              (a, e, r) => {
                var f = r(551).FDLayoutNode, i = r(551).IMath;
                function g(s, o, c, h) {
                  f.call(this, s, o, c, h);
                }
                g.prototype = Object.create(f.prototype);
                for (var t in f)
                  g[t] = f[t];
                g.prototype.calculateDisplacement = function() {
                  var s = this.graphManager.getLayout();
                  this.getChild() != null && this.fixedNodeWeight ? (this.displacementX += s.coolingFactor * (this.springForceX + this.repulsionForceX + this.gravitationForceX) / this.fixedNodeWeight, this.displacementY += s.coolingFactor * (this.springForceY + this.repulsionForceY + this.gravitationForceY) / this.fixedNodeWeight) : (this.displacementX += s.coolingFactor * (this.springForceX + this.repulsionForceX + this.gravitationForceX) / this.noOfChildren, this.displacementY += s.coolingFactor * (this.springForceY + this.repulsionForceY + this.gravitationForceY) / this.noOfChildren), Math.abs(this.displacementX) > s.coolingFactor * s.maxNodeDisplacement && (this.displacementX = s.coolingFactor * s.maxNodeDisplacement * i.sign(this.displacementX)), Math.abs(this.displacementY) > s.coolingFactor * s.maxNodeDisplacement && (this.displacementY = s.coolingFactor * s.maxNodeDisplacement * i.sign(this.displacementY)), this.child && this.child.getNodes().length > 0 && this.propogateDisplacementToChildren(this.displacementX, this.displacementY);
                }, g.prototype.propogateDisplacementToChildren = function(s, o) {
                  for (var c = this.getChild().getNodes(), h, T = 0; T < c.length; T++)
                    h = c[T], h.getChild() == null ? (h.displacementX += s, h.displacementY += o) : h.propogateDisplacementToChildren(s, o);
                }, g.prototype.move = function() {
                  var s = this.graphManager.getLayout();
                  (this.child == null || this.child.getNodes().length == 0) && (this.moveBy(this.displacementX, this.displacementY), s.totalDisplacement += Math.abs(this.displacementX) + Math.abs(this.displacementY)), this.springForceX = 0, this.springForceY = 0, this.repulsionForceX = 0, this.repulsionForceY = 0, this.gravitationForceX = 0, this.gravitationForceY = 0, this.displacementX = 0, this.displacementY = 0;
                }, g.prototype.setPred1 = function(s) {
                  this.pred1 = s;
                }, g.prototype.getPred1 = function() {
                  return pred1;
                }, g.prototype.getPred2 = function() {
                  return pred2;
                }, g.prototype.setNext = function(s) {
                  this.next = s;
                }, g.prototype.getNext = function() {
                  return next;
                }, g.prototype.setProcessed = function(s) {
                  this.processed = s;
                }, g.prototype.isProcessed = function() {
                  return processed;
                }, a.exports = g;
              }
            ),
            /***/
            902: (
              /***/
              (a, e, r) => {
                function f(c) {
                  if (Array.isArray(c)) {
                    for (var h = 0, T = Array(c.length); h < c.length; h++)
                      T[h] = c[h];
                    return T;
                  } else
                    return Array.from(c);
                }
                var i = r(806), g = r(551).LinkedList, t = r(551).Matrix, s = r(551).SVD;
                function o() {
                }
                o.handleConstraints = function(c) {
                  var h = {};
                  h.fixedNodeConstraint = c.constraints.fixedNodeConstraint, h.alignmentConstraint = c.constraints.alignmentConstraint, h.relativePlacementConstraint = c.constraints.relativePlacementConstraint;
                  for (var T = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Map(), v = [], L = [], S = c.getAllNodes(), C = 0, G = 0; G < S.length; G++) {
                    var K = S[G];
                    K.getChild() == null && (d.set(K.id, C++), v.push(K.getCenterX()), L.push(K.getCenterY()), T.set(K.id, K));
                  }
                  h.relativePlacementConstraint && h.relativePlacementConstraint.forEach(function(b) {
                    !b.gap && b.gap != 0 && (b.left ? b.gap = i.DEFAULT_EDGE_LENGTH + T.get(b.left).getWidth() / 2 + T.get(b.right).getWidth() / 2 : b.gap = i.DEFAULT_EDGE_LENGTH + T.get(b.top).getHeight() / 2 + T.get(b.bottom).getHeight() / 2);
                  });
                  var X = function(U, $) {
                    return { x: U.x - $.x, y: U.y - $.y };
                  }, Q = function(U) {
                    var $ = 0, J = 0;
                    return U.forEach(function(k) {
                      $ += v[d.get(k)], J += L[d.get(k)];
                    }), { x: $ / U.size, y: J / U.size };
                  }, O = function(U, $, J, k, at) {
                    function ct(lt, ot) {
                      var Lt = new Set(lt), ft = !0, st = !1, Xt = void 0;
                      try {
                        for (var Tt = ot[Symbol.iterator](), Ct; !(ft = (Ct = Tt.next()).done); ft = !0) {
                          var Bt = Ct.value;
                          Lt.add(Bt);
                        }
                      } catch (bt) {
                        st = !0, Xt = bt;
                      } finally {
                        try {
                          !ft && Tt.return && Tt.return();
                        } finally {
                          if (st)
                            throw Xt;
                        }
                      }
                      return Lt;
                    }
                    var nt = /* @__PURE__ */ new Map();
                    U.forEach(function(lt, ot) {
                      nt.set(ot, 0);
                    }), U.forEach(function(lt, ot) {
                      lt.forEach(function(Lt) {
                        nt.set(Lt.id, nt.get(Lt.id) + 1);
                      });
                    });
                    var tt = /* @__PURE__ */ new Map(), j = /* @__PURE__ */ new Map(), ut = new g();
                    nt.forEach(function(lt, ot) {
                      lt == 0 ? (ut.push(ot), J || ($ == "horizontal" ? tt.set(ot, d.has(ot) ? v[d.get(ot)] : k.get(ot)) : tt.set(ot, d.has(ot) ? L[d.get(ot)] : k.get(ot)))) : tt.set(ot, Number.NEGATIVE_INFINITY), J && j.set(ot, /* @__PURE__ */ new Set([ot]));
                    }), J && at.forEach(function(lt) {
                      var ot = [];
                      if (lt.forEach(function(st) {
                        J.has(st) && ot.push(st);
                      }), ot.length > 0) {
                        var Lt = 0;
                        ot.forEach(function(st) {
                          $ == "horizontal" ? (tt.set(st, d.has(st) ? v[d.get(st)] : k.get(st)), Lt += tt.get(st)) : (tt.set(st, d.has(st) ? L[d.get(st)] : k.get(st)), Lt += tt.get(st));
                        }), Lt = Lt / ot.length, lt.forEach(function(st) {
                          J.has(st) || tt.set(st, Lt);
                        });
                      } else {
                        var ft = 0;
                        lt.forEach(function(st) {
                          $ == "horizontal" ? ft += d.has(st) ? v[d.get(st)] : k.get(st) : ft += d.has(st) ? L[d.get(st)] : k.get(st);
                        }), ft = ft / lt.length, lt.forEach(function(st) {
                          tt.set(st, ft);
                        });
                      }
                    });
                    for (var Mt = function() {
                      var ot = ut.shift(), Lt = U.get(ot);
                      Lt.forEach(function(ft) {
                        if (tt.get(ft.id) < tt.get(ot) + ft.gap)
                          if (J && J.has(ft.id)) {
                            var st = void 0;
                            if ($ == "horizontal" ? st = d.has(ft.id) ? v[d.get(ft.id)] : k.get(ft.id) : st = d.has(ft.id) ? L[d.get(ft.id)] : k.get(ft.id), tt.set(ft.id, st), st < tt.get(ot) + ft.gap) {
                              var Xt = tt.get(ot) + ft.gap - st;
                              j.get(ot).forEach(function(Tt) {
                                tt.set(Tt, tt.get(Tt) - Xt);
                              });
                            }
                          } else
                            tt.set(ft.id, tt.get(ot) + ft.gap);
                        nt.set(ft.id, nt.get(ft.id) - 1), nt.get(ft.id) == 0 && ut.push(ft.id), J && j.set(ft.id, ct(j.get(ot), j.get(ft.id)));
                      });
                    }; ut.length != 0; )
                      Mt();
                    if (J) {
                      var pt = /* @__PURE__ */ new Set();
                      U.forEach(function(lt, ot) {
                        lt.length == 0 && pt.add(ot);
                      });
                      var xt = [];
                      j.forEach(function(lt, ot) {
                        if (pt.has(ot)) {
                          var Lt = !1, ft = !0, st = !1, Xt = void 0;
                          try {
                            for (var Tt = lt[Symbol.iterator](), Ct; !(ft = (Ct = Tt.next()).done); ft = !0) {
                              var Bt = Ct.value;
                              J.has(Bt) && (Lt = !0);
                            }
                          } catch (St) {
                            st = !0, Xt = St;
                          } finally {
                            try {
                              !ft && Tt.return && Tt.return();
                            } finally {
                              if (st)
                                throw Xt;
                            }
                          }
                          if (!Lt) {
                            var bt = !1, zt = void 0;
                            xt.forEach(function(St, kt) {
                              St.has([].concat(f(lt))[0]) && (bt = !0, zt = kt);
                            }), bt ? lt.forEach(function(St) {
                              xt[zt].add(St);
                            }) : xt.push(new Set(lt));
                          }
                        }
                      }), xt.forEach(function(lt, ot) {
                        var Lt = Number.POSITIVE_INFINITY, ft = Number.POSITIVE_INFINITY, st = Number.NEGATIVE_INFINITY, Xt = Number.NEGATIVE_INFINITY, Tt = !0, Ct = !1, Bt = void 0;
                        try {
                          for (var bt = lt[Symbol.iterator](), zt; !(Tt = (zt = bt.next()).done); Tt = !0) {
                            var St = zt.value, kt = void 0;
                            $ == "horizontal" ? kt = d.has(St) ? v[d.get(St)] : k.get(St) : kt = d.has(St) ? L[d.get(St)] : k.get(St);
                            var Kt = tt.get(St);
                            kt < Lt && (Lt = kt), kt > st && (st = kt), Kt < ft && (ft = Kt), Kt > Xt && (Xt = Kt);
                          }
                        } catch (ee) {
                          Ct = !0, Bt = ee;
                        } finally {
                          try {
                            !Tt && bt.return && bt.return();
                          } finally {
                            if (Ct)
                              throw Bt;
                          }
                        }
                        var he = (Lt + st) / 2 - (ft + Xt) / 2, Qt = !0, jt = !1, _t = void 0;
                        try {
                          for (var Jt = lt[Symbol.iterator](), oe; !(Qt = (oe = Jt.next()).done); Qt = !0) {
                            var te = oe.value;
                            tt.set(te, tt.get(te) + he);
                          }
                        } catch (ee) {
                          jt = !0, _t = ee;
                        } finally {
                          try {
                            !Qt && Jt.return && Jt.return();
                          } finally {
                            if (jt)
                              throw _t;
                          }
                        }
                      });
                    }
                    return tt;
                  }, rt = function(U) {
                    var $ = 0, J = 0, k = 0, at = 0;
                    if (U.forEach(function(j) {
                      j.left ? v[d.get(j.left)] - v[d.get(j.right)] >= 0 ? $++ : J++ : L[d.get(j.top)] - L[d.get(j.bottom)] >= 0 ? k++ : at++;
                    }), $ > J && k > at)
                      for (var ct = 0; ct < d.size; ct++)
                        v[ct] = -1 * v[ct], L[ct] = -1 * L[ct];
                    else if ($ > J)
                      for (var nt = 0; nt < d.size; nt++)
                        v[nt] = -1 * v[nt];
                    else if (k > at)
                      for (var tt = 0; tt < d.size; tt++)
                        L[tt] = -1 * L[tt];
                  }, n = function(U) {
                    var $ = [], J = new g(), k = /* @__PURE__ */ new Set(), at = 0;
                    return U.forEach(function(ct, nt) {
                      if (!k.has(nt)) {
                        $[at] = [];
                        var tt = nt;
                        for (J.push(tt), k.add(tt), $[at].push(tt); J.length != 0; ) {
                          tt = J.shift();
                          var j = U.get(tt);
                          j.forEach(function(ut) {
                            k.has(ut.id) || (J.push(ut.id), k.add(ut.id), $[at].push(ut.id));
                          });
                        }
                        at++;
                      }
                    }), $;
                  }, m = function(U) {
                    var $ = /* @__PURE__ */ new Map();
                    return U.forEach(function(J, k) {
                      $.set(k, []);
                    }), U.forEach(function(J, k) {
                      J.forEach(function(at) {
                        $.get(k).push(at), $.get(at.id).push({ id: k, gap: at.gap, direction: at.direction });
                      });
                    }), $;
                  }, p = function(U) {
                    var $ = /* @__PURE__ */ new Map();
                    return U.forEach(function(J, k) {
                      $.set(k, []);
                    }), U.forEach(function(J, k) {
                      J.forEach(function(at) {
                        $.get(at.id).push({ id: k, gap: at.gap, direction: at.direction });
                      });
                    }), $;
                  }, E = [], y = [], R = !1, M = !1, F = /* @__PURE__ */ new Set(), W = /* @__PURE__ */ new Map(), x = /* @__PURE__ */ new Map(), Z = [];
                  if (h.fixedNodeConstraint && h.fixedNodeConstraint.forEach(function(b) {
                    F.add(b.nodeId);
                  }), h.relativePlacementConstraint && (h.relativePlacementConstraint.forEach(function(b) {
                    b.left ? (W.has(b.left) ? W.get(b.left).push({ id: b.right, gap: b.gap, direction: "horizontal" }) : W.set(b.left, [{ id: b.right, gap: b.gap, direction: "horizontal" }]), W.has(b.right) || W.set(b.right, [])) : (W.has(b.top) ? W.get(b.top).push({ id: b.bottom, gap: b.gap, direction: "vertical" }) : W.set(b.top, [{ id: b.bottom, gap: b.gap, direction: "vertical" }]), W.has(b.bottom) || W.set(b.bottom, []));
                  }), x = m(W), Z = n(x)), i.TRANSFORM_ON_CONSTRAINT_HANDLING) {
                    if (h.fixedNodeConstraint && h.fixedNodeConstraint.length > 1)
                      h.fixedNodeConstraint.forEach(function(b, U) {
                        E[U] = [b.position.x, b.position.y], y[U] = [v[d.get(b.nodeId)], L[d.get(b.nodeId)]];
                      }), R = !0;
                    else if (h.alignmentConstraint)
                      (function() {
                        var b = 0;
                        if (h.alignmentConstraint.vertical) {
                          for (var U = h.alignmentConstraint.vertical, $ = function(tt) {
                            var j = /* @__PURE__ */ new Set();
                            U[tt].forEach(function(pt) {
                              j.add(pt);
                            });
                            var ut = new Set([].concat(f(j)).filter(function(pt) {
                              return F.has(pt);
                            })), Mt = void 0;
                            ut.size > 0 ? Mt = v[d.get(ut.values().next().value)] : Mt = Q(j).x, U[tt].forEach(function(pt) {
                              E[b] = [Mt, L[d.get(pt)]], y[b] = [v[d.get(pt)], L[d.get(pt)]], b++;
                            });
                          }, J = 0; J < U.length; J++)
                            $(J);
                          R = !0;
                        }
                        if (h.alignmentConstraint.horizontal) {
                          for (var k = h.alignmentConstraint.horizontal, at = function(tt) {
                            var j = /* @__PURE__ */ new Set();
                            k[tt].forEach(function(pt) {
                              j.add(pt);
                            });
                            var ut = new Set([].concat(f(j)).filter(function(pt) {
                              return F.has(pt);
                            })), Mt = void 0;
                            ut.size > 0 ? Mt = v[d.get(ut.values().next().value)] : Mt = Q(j).y, k[tt].forEach(function(pt) {
                              E[b] = [v[d.get(pt)], Mt], y[b] = [v[d.get(pt)], L[d.get(pt)]], b++;
                            });
                          }, ct = 0; ct < k.length; ct++)
                            at(ct);
                          R = !0;
                        }
                        h.relativePlacementConstraint && (M = !0);
                      })();
                    else if (h.relativePlacementConstraint) {
                      for (var V = 0, Y = 0, et = 0; et < Z.length; et++)
                        Z[et].length > V && (V = Z[et].length, Y = et);
                      if (V < x.size / 2)
                        rt(h.relativePlacementConstraint), R = !1, M = !1;
                      else {
                        var z = /* @__PURE__ */ new Map(), w = /* @__PURE__ */ new Map(), H = [];
                        Z[Y].forEach(function(b) {
                          W.get(b).forEach(function(U) {
                            U.direction == "horizontal" ? (z.has(b) ? z.get(b).push(U) : z.set(b, [U]), z.has(U.id) || z.set(U.id, []), H.push({ left: b, right: U.id })) : (w.has(b) ? w.get(b).push(U) : w.set(b, [U]), w.has(U.id) || w.set(U.id, []), H.push({ top: b, bottom: U.id }));
                          });
                        }), rt(H), M = !1;
                        var B = O(z, "horizontal"), _ = O(w, "vertical");
                        Z[Y].forEach(function(b, U) {
                          y[U] = [v[d.get(b)], L[d.get(b)]], E[U] = [], B.has(b) ? E[U][0] = B.get(b) : E[U][0] = v[d.get(b)], _.has(b) ? E[U][1] = _.get(b) : E[U][1] = L[d.get(b)];
                        }), R = !0;
                      }
                    }
                    if (R) {
                      for (var ht = void 0, q = t.transpose(E), It = t.transpose(y), Nt = 0; Nt < q.length; Nt++)
                        q[Nt] = t.multGamma(q[Nt]), It[Nt] = t.multGamma(It[Nt]);
                      var vt = t.multMat(q, t.transpose(It)), it = s.svd(vt);
                      ht = t.multMat(it.V, t.transpose(it.U));
                      for (var gt = 0; gt < d.size; gt++) {
                        var mt = [v[gt], L[gt]], At = [ht[0][0], ht[1][0]], Ot = [ht[0][1], ht[1][1]];
                        v[gt] = t.dotProduct(mt, At), L[gt] = t.dotProduct(mt, Ot);
                      }
                      M && rt(h.relativePlacementConstraint);
                    }
                  }
                  if (i.ENFORCE_CONSTRAINTS) {
                    if (h.fixedNodeConstraint && h.fixedNodeConstraint.length > 0) {
                      var Et = { x: 0, y: 0 };
                      h.fixedNodeConstraint.forEach(function(b, U) {
                        var $ = { x: v[d.get(b.nodeId)], y: L[d.get(b.nodeId)] }, J = b.position, k = X(J, $);
                        Et.x += k.x, Et.y += k.y;
                      }), Et.x /= h.fixedNodeConstraint.length, Et.y /= h.fixedNodeConstraint.length, v.forEach(function(b, U) {
                        v[U] += Et.x;
                      }), L.forEach(function(b, U) {
                        L[U] += Et.y;
                      }), h.fixedNodeConstraint.forEach(function(b) {
                        v[d.get(b.nodeId)] = b.position.x, L[d.get(b.nodeId)] = b.position.y;
                      });
                    }
                    if (h.alignmentConstraint) {
                      if (h.alignmentConstraint.vertical)
                        for (var Dt = h.alignmentConstraint.vertical, Rt = function(U) {
                          var $ = /* @__PURE__ */ new Set();
                          Dt[U].forEach(function(at) {
                            $.add(at);
                          });
                          var J = new Set([].concat(f($)).filter(function(at) {
                            return F.has(at);
                          })), k = void 0;
                          J.size > 0 ? k = v[d.get(J.values().next().value)] : k = Q($).x, $.forEach(function(at) {
                            F.has(at) || (v[d.get(at)] = k);
                          });
                        }, Ht = 0; Ht < Dt.length; Ht++)
                          Rt(Ht);
                      if (h.alignmentConstraint.horizontal)
                        for (var Ut = h.alignmentConstraint.horizontal, Pt = function(U) {
                          var $ = /* @__PURE__ */ new Set();
                          Ut[U].forEach(function(at) {
                            $.add(at);
                          });
                          var J = new Set([].concat(f($)).filter(function(at) {
                            return F.has(at);
                          })), k = void 0;
                          J.size > 0 ? k = L[d.get(J.values().next().value)] : k = Q($).y, $.forEach(function(at) {
                            F.has(at) || (L[d.get(at)] = k);
                          });
                        }, Ft = 0; Ft < Ut.length; Ft++)
                          Pt(Ft);
                    }
                    h.relativePlacementConstraint && function() {
                      var b = /* @__PURE__ */ new Map(), U = /* @__PURE__ */ new Map(), $ = /* @__PURE__ */ new Map(), J = /* @__PURE__ */ new Map(), k = /* @__PURE__ */ new Map(), at = /* @__PURE__ */ new Map(), ct = /* @__PURE__ */ new Set(), nt = /* @__PURE__ */ new Set();
                      if (F.forEach(function(Gt) {
                        ct.add(Gt), nt.add(Gt);
                      }), h.alignmentConstraint) {
                        if (h.alignmentConstraint.vertical)
                          for (var tt = h.alignmentConstraint.vertical, j = function(yt) {
                            $.set("dummy" + yt, []), tt[yt].forEach(function(wt) {
                              b.set(wt, "dummy" + yt), $.get("dummy" + yt).push(wt), F.has(wt) && ct.add("dummy" + yt);
                            }), k.set("dummy" + yt, v[d.get(tt[yt][0])]);
                          }, ut = 0; ut < tt.length; ut++)
                            j(ut);
                        if (h.alignmentConstraint.horizontal)
                          for (var Mt = h.alignmentConstraint.horizontal, pt = function(yt) {
                            J.set("dummy" + yt, []), Mt[yt].forEach(function(wt) {
                              U.set(wt, "dummy" + yt), J.get("dummy" + yt).push(wt), F.has(wt) && nt.add("dummy" + yt);
                            }), at.set("dummy" + yt, L[d.get(Mt[yt][0])]);
                          }, xt = 0; xt < Mt.length; xt++)
                            pt(xt);
                      }
                      var lt = /* @__PURE__ */ new Map(), ot = /* @__PURE__ */ new Map(), Lt = function(yt) {
                        W.get(yt).forEach(function(wt) {
                          var Zt = void 0, $t = void 0;
                          wt.direction == "horizontal" ? (Zt = b.get(yt) ? b.get(yt) : yt, b.get(wt.id) ? $t = { id: b.get(wt.id), gap: wt.gap, direction: wt.direction } : $t = wt, lt.has(Zt) ? lt.get(Zt).push($t) : lt.set(Zt, [$t]), lt.has($t.id) || lt.set($t.id, [])) : (Zt = U.get(yt) ? U.get(yt) : yt, U.get(wt.id) ? $t = { id: U.get(wt.id), gap: wt.gap, direction: wt.direction } : $t = wt, ot.has(Zt) ? ot.get(Zt).push($t) : ot.set(Zt, [$t]), ot.has($t.id) || ot.set($t.id, []));
                        });
                      }, ft = !0, st = !1, Xt = void 0;
                      try {
                        for (var Tt = W.keys()[Symbol.iterator](), Ct; !(ft = (Ct = Tt.next()).done); ft = !0) {
                          var Bt = Ct.value;
                          Lt(Bt);
                        }
                      } catch (Gt) {
                        st = !0, Xt = Gt;
                      } finally {
                        try {
                          !ft && Tt.return && Tt.return();
                        } finally {
                          if (st)
                            throw Xt;
                        }
                      }
                      var bt = m(lt), zt = m(ot), St = n(bt), kt = n(zt), Kt = p(lt), he = p(ot), Qt = [], jt = [];
                      St.forEach(function(Gt, yt) {
                        Qt[yt] = [], Gt.forEach(function(wt) {
                          Kt.get(wt).length == 0 && Qt[yt].push(wt);
                        });
                      }), kt.forEach(function(Gt, yt) {
                        jt[yt] = [], Gt.forEach(function(wt) {
                          he.get(wt).length == 0 && jt[yt].push(wt);
                        });
                      });
                      var _t = O(lt, "horizontal", ct, k, Qt), Jt = O(ot, "vertical", nt, at, jt), oe = function(yt) {
                        $.get(yt) ? $.get(yt).forEach(function(wt) {
                          v[d.get(wt)] = _t.get(yt);
                        }) : v[d.get(yt)] = _t.get(yt);
                      }, te = !0, ee = !1, Ne = void 0;
                      try {
                        for (var le = _t.keys()[Symbol.iterator](), Le; !(te = (Le = le.next()).done); te = !0) {
                          var fe = Le.value;
                          oe(fe);
                        }
                      } catch (Gt) {
                        ee = !0, Ne = Gt;
                      } finally {
                        try {
                          !te && le.return && le.return();
                        } finally {
                          if (ee)
                            throw Ne;
                        }
                      }
                      var $e = function(yt) {
                        J.get(yt) ? J.get(yt).forEach(function(wt) {
                          L[d.get(wt)] = Jt.get(yt);
                        }) : L[d.get(yt)] = Jt.get(yt);
                      }, ce = !0, Ce = !1, Ae = void 0;
                      try {
                        for (var ge = Jt.keys()[Symbol.iterator](), Me; !(ce = (Me = ge.next()).done); ce = !0) {
                          var fe = Me.value;
                          $e(fe);
                        }
                      } catch (Gt) {
                        Ce = !0, Ae = Gt;
                      } finally {
                        try {
                          !ce && ge.return && ge.return();
                        } finally {
                          if (Ce)
                            throw Ae;
                        }
                      }
                    }();
                  }
                  for (var Yt = 0; Yt < S.length; Yt++) {
                    var Vt = S[Yt];
                    Vt.getChild() == null && Vt.setCenter(v[d.get(Vt.id)], L[d.get(Vt.id)]);
                  }
                }, a.exports = o;
              }
            ),
            /***/
            551: (
              /***/
              (a) => {
                a.exports = A;
              }
            )
            /******/
          }, N = {};
          function u(a) {
            var e = N[a];
            if (e !== void 0)
              return e.exports;
            var r = N[a] = {
              /******/
              // no module.id needed
              /******/
              // no module.loaded needed
              /******/
              exports: {}
              /******/
            };
            return P[a](r, r.exports, u), r.exports;
          }
          var l = u(45);
          return l;
        })()
      );
    });
  }(ue)), ue.exports;
}
(function(I, D) {
  (function(P, N) {
    I.exports = N(gr());
  })(me, function(A) {
    return (
      /******/
      (() => {
        var P = {
          /***/
          658: (
            /***/
            (a) => {
              a.exports = Object.assign != null ? Object.assign.bind(Object) : function(e) {
                for (var r = arguments.length, f = Array(r > 1 ? r - 1 : 0), i = 1; i < r; i++)
                  f[i - 1] = arguments[i];
                return f.forEach(function(g) {
                  Object.keys(g).forEach(function(t) {
                    return e[t] = g[t];
                  });
                }), e;
              };
            }
          ),
          /***/
          548: (
            /***/
            (a, e, r) => {
              var f = /* @__PURE__ */ function() {
                function t(s, o) {
                  var c = [], h = !0, T = !1, d = void 0;
                  try {
                    for (var v = s[Symbol.iterator](), L; !(h = (L = v.next()).done) && (c.push(L.value), !(o && c.length === o)); h = !0)
                      ;
                  } catch (S) {
                    T = !0, d = S;
                  } finally {
                    try {
                      !h && v.return && v.return();
                    } finally {
                      if (T) throw d;
                    }
                  }
                  return c;
                }
                return function(s, o) {
                  if (Array.isArray(s))
                    return s;
                  if (Symbol.iterator in Object(s))
                    return t(s, o);
                  throw new TypeError("Invalid attempt to destructure non-iterable instance");
                };
              }(), i = r(140).layoutBase.LinkedList, g = {};
              g.getTopMostNodes = function(t) {
                for (var s = {}, o = 0; o < t.length; o++)
                  s[t[o].id()] = !0;
                var c = t.filter(function(h, T) {
                  typeof h == "number" && (h = T);
                  for (var d = h.parent()[0]; d != null; ) {
                    if (s[d.id()])
                      return !1;
                    d = d.parent()[0];
                  }
                  return !0;
                });
                return c;
              }, g.connectComponents = function(t, s, o, c) {
                var h = new i(), T = /* @__PURE__ */ new Set(), d = [], v = void 0, L = void 0, S = void 0, C = !1, G = 1, K = [], X = [], Q = function() {
                  var rt = t.collection();
                  X.push(rt);
                  var n = o[0], m = t.collection();
                  m.merge(n).merge(n.descendants().intersection(s)), d.push(n), m.forEach(function(y) {
                    h.push(y), T.add(y), rt.merge(y);
                  });
                  for (var p = function() {
                    n = h.shift();
                    var R = t.collection();
                    n.neighborhood().nodes().forEach(function(x) {
                      s.intersection(n.edgesWith(x)).length > 0 && R.merge(x);
                    });
                    for (var M = 0; M < R.length; M++) {
                      var F = R[M];
                      if (v = o.intersection(F.union(F.ancestors())), v != null && !T.has(v[0])) {
                        var W = v.union(v.descendants());
                        W.forEach(function(x) {
                          h.push(x), T.add(x), rt.merge(x), o.has(x) && d.push(x);
                        });
                      }
                    }
                  }; h.length != 0; )
                    p();
                  if (rt.forEach(function(y) {
                    s.intersection(y.connectedEdges()).forEach(function(R) {
                      rt.has(R.source()) && rt.has(R.target()) && rt.merge(R);
                    });
                  }), d.length == o.length && (C = !0), !C || C && G > 1) {
                    L = d[0], S = L.connectedEdges().length, d.forEach(function(y) {
                      y.connectedEdges().length < S && (S = y.connectedEdges().length, L = y);
                    }), K.push(L.id());
                    var E = t.collection();
                    E.merge(d[0]), d.forEach(function(y) {
                      E.merge(y);
                    }), d = [], o = o.difference(E), G++;
                  }
                };
                do
                  Q();
                while (!C);
                return c && K.length > 0 && c.set("dummy" + (c.size + 1), K), X;
              }, g.relocateComponent = function(t, s, o) {
                if (!o.fixedNodeConstraint) {
                  var c = Number.POSITIVE_INFINITY, h = Number.NEGATIVE_INFINITY, T = Number.POSITIVE_INFINITY, d = Number.NEGATIVE_INFINITY;
                  if (o.quality == "draft") {
                    var v = !0, L = !1, S = void 0;
                    try {
                      for (var C = s.nodeIndexes[Symbol.iterator](), G; !(v = (G = C.next()).done); v = !0) {
                        var K = G.value, X = f(K, 2), Q = X[0], O = X[1], rt = o.cy.getElementById(Q);
                        if (rt) {
                          var n = rt.boundingBox(), m = s.xCoords[O] - n.w / 2, p = s.xCoords[O] + n.w / 2, E = s.yCoords[O] - n.h / 2, y = s.yCoords[O] + n.h / 2;
                          m < c && (c = m), p > h && (h = p), E < T && (T = E), y > d && (d = y);
                        }
                      }
                    } catch (x) {
                      L = !0, S = x;
                    } finally {
                      try {
                        !v && C.return && C.return();
                      } finally {
                        if (L)
                          throw S;
                      }
                    }
                    var R = t.x - (h + c) / 2, M = t.y - (d + T) / 2;
                    s.xCoords = s.xCoords.map(function(x) {
                      return x + R;
                    }), s.yCoords = s.yCoords.map(function(x) {
                      return x + M;
                    });
                  } else {
                    Object.keys(s).forEach(function(x) {
                      var Z = s[x], V = Z.getRect().x, Y = Z.getRect().x + Z.getRect().width, et = Z.getRect().y, z = Z.getRect().y + Z.getRect().height;
                      V < c && (c = V), Y > h && (h = Y), et < T && (T = et), z > d && (d = z);
                    });
                    var F = t.x - (h + c) / 2, W = t.y - (d + T) / 2;
                    Object.keys(s).forEach(function(x) {
                      var Z = s[x];
                      Z.setCenter(Z.getCenterX() + F, Z.getCenterY() + W);
                    });
                  }
                }
              }, g.calcBoundingBox = function(t, s, o, c) {
                for (var h = Number.MAX_SAFE_INTEGER, T = Number.MIN_SAFE_INTEGER, d = Number.MAX_SAFE_INTEGER, v = Number.MIN_SAFE_INTEGER, L = void 0, S = void 0, C = void 0, G = void 0, K = t.descendants().not(":parent"), X = K.length, Q = 0; Q < X; Q++) {
                  var O = K[Q];
                  L = s[c.get(O.id())] - O.width() / 2, S = s[c.get(O.id())] + O.width() / 2, C = o[c.get(O.id())] - O.height() / 2, G = o[c.get(O.id())] + O.height() / 2, h > L && (h = L), T < S && (T = S), d > C && (d = C), v < G && (v = G);
                }
                var rt = {};
                return rt.topLeftX = h, rt.topLeftY = d, rt.width = T - h, rt.height = v - d, rt;
              }, g.calcParentsWithoutChildren = function(t, s) {
                var o = t.collection();
                return s.nodes(":parent").forEach(function(c) {
                  var h = !1;
                  c.children().forEach(function(T) {
                    T.css("display") != "none" && (h = !0);
                  }), h || o.merge(c);
                }), o;
              }, a.exports = g;
            }
          ),
          /***/
          816: (
            /***/
            (a, e, r) => {
              var f = r(548), i = r(140).CoSELayout, g = r(140).CoSENode, t = r(140).layoutBase.PointD, s = r(140).layoutBase.DimensionD, o = r(140).layoutBase.LayoutConstants, c = r(140).layoutBase.FDLayoutConstants, h = r(140).CoSEConstants, T = function(v, L) {
                var S = v.cy, C = v.eles, G = C.nodes(), K = C.edges(), X = void 0, Q = void 0, O = void 0, rt = {};
                v.randomize && (X = L.nodeIndexes, Q = L.xCoords, O = L.yCoords);
                var n = function(x) {
                  return typeof x == "function";
                }, m = function(x, Z) {
                  return n(x) ? x(Z) : x;
                }, p = f.calcParentsWithoutChildren(S, C), E = function W(x, Z, V, Y) {
                  for (var et = Z.length, z = 0; z < et; z++) {
                    var w = Z[z], H = null;
                    w.intersection(p).length == 0 && (H = w.children());
                    var B = void 0, _ = w.layoutDimensions({
                      nodeDimensionsIncludeLabels: Y.nodeDimensionsIncludeLabels
                    });
                    if (w.outerWidth() != null && w.outerHeight() != null)
                      if (Y.randomize)
                        if (!w.isParent())
                          B = x.add(new g(V.graphManager, new t(Q[X.get(w.id())] - _.w / 2, O[X.get(w.id())] - _.h / 2), new s(parseFloat(_.w), parseFloat(_.h))));
                        else {
                          var ht = f.calcBoundingBox(w, Q, O, X);
                          w.intersection(p).length == 0 ? B = x.add(new g(V.graphManager, new t(ht.topLeftX, ht.topLeftY), new s(ht.width, ht.height))) : B = x.add(new g(V.graphManager, new t(ht.topLeftX, ht.topLeftY), new s(parseFloat(_.w), parseFloat(_.h))));
                        }
                      else
                        B = x.add(new g(V.graphManager, new t(w.position("x") - _.w / 2, w.position("y") - _.h / 2), new s(parseFloat(_.w), parseFloat(_.h))));
                    else
                      B = x.add(new g(this.graphManager));
                    if (B.id = w.data("id"), B.nodeRepulsion = m(Y.nodeRepulsion, w), B.paddingLeft = parseInt(w.css("padding")), B.paddingTop = parseInt(w.css("padding")), B.paddingRight = parseInt(w.css("padding")), B.paddingBottom = parseInt(w.css("padding")), Y.nodeDimensionsIncludeLabels && (B.labelWidth = w.boundingBox({ includeLabels: !0, includeNodes: !1, includeOverlays: !1 }).w, B.labelHeight = w.boundingBox({ includeLabels: !0, includeNodes: !1, includeOverlays: !1 }).h, B.labelPosVertical = w.css("text-valign"), B.labelPosHorizontal = w.css("text-halign")), rt[w.data("id")] = B, isNaN(B.rect.x) && (B.rect.x = 0), isNaN(B.rect.y) && (B.rect.y = 0), H != null && H.length > 0) {
                      var q = void 0;
                      q = V.getGraphManager().add(V.newGraph(), B), W(q, H, V, Y);
                    }
                  }
                }, y = function(x, Z, V) {
                  for (var Y = 0, et = 0, z = 0; z < V.length; z++) {
                    var w = V[z], H = rt[w.data("source")], B = rt[w.data("target")];
                    if (H && B && H !== B && H.getEdgesBetween(B).length == 0) {
                      var _ = Z.add(x.newEdge(), H, B);
                      _.id = w.id(), _.idealLength = m(v.idealEdgeLength, w), _.edgeElasticity = m(v.edgeElasticity, w), Y += _.idealLength, et++;
                    }
                  }
                  v.idealEdgeLength != null && (et > 0 ? h.DEFAULT_EDGE_LENGTH = c.DEFAULT_EDGE_LENGTH = Y / et : n(v.idealEdgeLength) ? h.DEFAULT_EDGE_LENGTH = c.DEFAULT_EDGE_LENGTH = 50 : h.DEFAULT_EDGE_LENGTH = c.DEFAULT_EDGE_LENGTH = v.idealEdgeLength, h.MIN_REPULSION_DIST = c.MIN_REPULSION_DIST = c.DEFAULT_EDGE_LENGTH / 10, h.DEFAULT_RADIAL_SEPARATION = c.DEFAULT_EDGE_LENGTH);
                }, R = function(x, Z) {
                  Z.fixedNodeConstraint && (x.constraints.fixedNodeConstraint = Z.fixedNodeConstraint), Z.alignmentConstraint && (x.constraints.alignmentConstraint = Z.alignmentConstraint), Z.relativePlacementConstraint && (x.constraints.relativePlacementConstraint = Z.relativePlacementConstraint);
                };
                v.nestingFactor != null && (h.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = c.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = v.nestingFactor), v.gravity != null && (h.DEFAULT_GRAVITY_STRENGTH = c.DEFAULT_GRAVITY_STRENGTH = v.gravity), v.numIter != null && (h.MAX_ITERATIONS = c.MAX_ITERATIONS = v.numIter), v.gravityRange != null && (h.DEFAULT_GRAVITY_RANGE_FACTOR = c.DEFAULT_GRAVITY_RANGE_FACTOR = v.gravityRange), v.gravityCompound != null && (h.DEFAULT_COMPOUND_GRAVITY_STRENGTH = c.DEFAULT_COMPOUND_GRAVITY_STRENGTH = v.gravityCompound), v.gravityRangeCompound != null && (h.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = c.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = v.gravityRangeCompound), v.initialEnergyOnIncremental != null && (h.DEFAULT_COOLING_FACTOR_INCREMENTAL = c.DEFAULT_COOLING_FACTOR_INCREMENTAL = v.initialEnergyOnIncremental), v.tilingCompareBy != null && (h.TILING_COMPARE_BY = v.tilingCompareBy), v.quality == "proof" ? o.QUALITY = 2 : o.QUALITY = 0, h.NODE_DIMENSIONS_INCLUDE_LABELS = c.NODE_DIMENSIONS_INCLUDE_LABELS = o.NODE_DIMENSIONS_INCLUDE_LABELS = v.nodeDimensionsIncludeLabels, h.DEFAULT_INCREMENTAL = c.DEFAULT_INCREMENTAL = o.DEFAULT_INCREMENTAL = !v.randomize, h.ANIMATE = c.ANIMATE = o.ANIMATE = v.animate, h.TILE = v.tile, h.TILING_PADDING_VERTICAL = typeof v.tilingPaddingVertical == "function" ? v.tilingPaddingVertical.call() : v.tilingPaddingVertical, h.TILING_PADDING_HORIZONTAL = typeof v.tilingPaddingHorizontal == "function" ? v.tilingPaddingHorizontal.call() : v.tilingPaddingHorizontal, h.DEFAULT_INCREMENTAL = c.DEFAULT_INCREMENTAL = o.DEFAULT_INCREMENTAL = !0, h.PURE_INCREMENTAL = !v.randomize, o.DEFAULT_UNIFORM_LEAF_NODE_SIZES = v.uniformNodeDimensions, v.step == "transformed" && (h.TRANSFORM_ON_CONSTRAINT_HANDLING = !0, h.ENFORCE_CONSTRAINTS = !1, h.APPLY_LAYOUT = !1), v.step == "enforced" && (h.TRANSFORM_ON_CONSTRAINT_HANDLING = !1, h.ENFORCE_CONSTRAINTS = !0, h.APPLY_LAYOUT = !1), v.step == "cose" && (h.TRANSFORM_ON_CONSTRAINT_HANDLING = !1, h.ENFORCE_CONSTRAINTS = !1, h.APPLY_LAYOUT = !0), v.step == "all" && (v.randomize ? h.TRANSFORM_ON_CONSTRAINT_HANDLING = !0 : h.TRANSFORM_ON_CONSTRAINT_HANDLING = !1, h.ENFORCE_CONSTRAINTS = !0, h.APPLY_LAYOUT = !0), v.fixedNodeConstraint || v.alignmentConstraint || v.relativePlacementConstraint ? h.TREE_REDUCTION_ON_INCREMENTAL = !1 : h.TREE_REDUCTION_ON_INCREMENTAL = !0;
                var M = new i(), F = M.newGraphManager();
                return E(F.addRoot(), f.getTopMostNodes(G), M, v), y(M, F, K), R(M, v), M.runLayout(), rt;
              };
              a.exports = { coseLayout: T };
            }
          ),
          /***/
          212: (
            /***/
            (a, e, r) => {
              var f = /* @__PURE__ */ function() {
                function v(L, S) {
                  for (var C = 0; C < S.length; C++) {
                    var G = S[C];
                    G.enumerable = G.enumerable || !1, G.configurable = !0, "value" in G && (G.writable = !0), Object.defineProperty(L, G.key, G);
                  }
                }
                return function(L, S, C) {
                  return S && v(L.prototype, S), C && v(L, C), L;
                };
              }();
              function i(v, L) {
                if (!(v instanceof L))
                  throw new TypeError("Cannot call a class as a function");
              }
              var g = r(658), t = r(548), s = r(657), o = s.spectralLayout, c = r(816), h = c.coseLayout, T = Object.freeze({
                // 'draft', 'default' or 'proof' 
                // - 'draft' only applies spectral layout 
                // - 'default' improves the quality with subsequent CoSE layout (fast cooling rate)
                // - 'proof' improves the quality with subsequent CoSE layout (slow cooling rate) 
                quality: "default",
                // Use random node positions at beginning of layout
                // if this is set to false, then quality option must be "proof"
                randomize: !0,
                // Whether or not to animate the layout
                animate: !0,
                // Duration of animation in ms, if enabled
                animationDuration: 1e3,
                // Easing of animation, if enabled
                animationEasing: void 0,
                // Fit the viewport to the repositioned nodes
                fit: !0,
                // Padding around layout
                padding: 30,
                // Whether to include labels in node dimensions. Valid in "proof" quality
                nodeDimensionsIncludeLabels: !1,
                // Whether or not simple nodes (non-compound nodes) are of uniform dimensions
                uniformNodeDimensions: !1,
                // Whether to pack disconnected components - valid only if randomize: true
                packComponents: !0,
                // Layout step - all, transformed, enforced, cose - for debug purpose only
                step: "all",
                /* spectral layout options */
                // False for random, true for greedy
                samplingType: !0,
                // Sample size to construct distance matrix
                sampleSize: 25,
                // Separation amount between nodes
                nodeSeparation: 75,
                // Power iteration tolerance
                piTol: 1e-7,
                /* CoSE layout options */
                // Node repulsion (non overlapping) multiplier
                nodeRepulsion: function(L) {
                  return 4500;
                },
                // Ideal edge (non nested) length
                idealEdgeLength: function(L) {
                  return 50;
                },
                // Divisor to compute edge forces
                edgeElasticity: function(L) {
                  return 0.45;
                },
                // Nesting factor (multiplier) to compute ideal edge length for nested edges
                nestingFactor: 0.1,
                // Gravity force (constant)
                gravity: 0.25,
                // Maximum number of iterations to perform
                numIter: 2500,
                // For enabling tiling
                tile: !0,
                // The function that specifies the criteria for comparing nodes while sorting them during tiling operation.
                // Takes the node id as a parameter and the default tiling operation is perfomed when this option is not set.
                tilingCompareBy: void 0,
                // Represents the amount of the vertical space to put between the zero degree members during the tiling operation(can also be a function)
                tilingPaddingVertical: 10,
                // Represents the amount of the horizontal space to put between the zero degree members during the tiling operation(can also be a function)
                tilingPaddingHorizontal: 10,
                // Gravity range (constant) for compounds
                gravityRangeCompound: 1.5,
                // Gravity force (constant) for compounds
                gravityCompound: 1,
                // Gravity range (constant)
                gravityRange: 3.8,
                // Initial cooling factor for incremental layout  
                initialEnergyOnIncremental: 0.3,
                /* constraint options */
                // Fix required nodes to predefined positions
                // [{nodeId: 'n1', position: {x: 100, y: 200}, {...}]
                fixedNodeConstraint: void 0,
                // Align required nodes in vertical/horizontal direction
                // {vertical: [['n1', 'n2')], ['n3', 'n4']], horizontal: ['n2', 'n4']}
                alignmentConstraint: void 0,
                // Place two nodes relatively in vertical/horizontal direction 
                // [{top: 'n1', bottom: 'n2', gap: 100}, {left: 'n3', right: 'n4', gap: 75}]
                relativePlacementConstraint: void 0,
                /* layout event callbacks */
                ready: function() {
                },
                // on layoutready
                stop: function() {
                }
                // on layoutstop
              }), d = function() {
                function v(L) {
                  i(this, v), this.options = g({}, T, L);
                }
                return f(v, [{
                  key: "run",
                  value: function() {
                    var S = this, C = this.options, G = C.cy, K = C.eles, X = [], Q = [], O = void 0, rt = [];
                    C.fixedNodeConstraint && (!Array.isArray(C.fixedNodeConstraint) || C.fixedNodeConstraint.length == 0) && (C.fixedNodeConstraint = void 0), C.alignmentConstraint && (C.alignmentConstraint.vertical && (!Array.isArray(C.alignmentConstraint.vertical) || C.alignmentConstraint.vertical.length == 0) && (C.alignmentConstraint.vertical = void 0), C.alignmentConstraint.horizontal && (!Array.isArray(C.alignmentConstraint.horizontal) || C.alignmentConstraint.horizontal.length == 0) && (C.alignmentConstraint.horizontal = void 0)), C.relativePlacementConstraint && (!Array.isArray(C.relativePlacementConstraint) || C.relativePlacementConstraint.length == 0) && (C.relativePlacementConstraint = void 0);
                    var n = C.fixedNodeConstraint || C.alignmentConstraint || C.relativePlacementConstraint;
                    n && (C.tile = !1, C.packComponents = !1);
                    var m = void 0, p = !1;
                    if (G.layoutUtilities && C.packComponents && (m = G.layoutUtilities("get"), m || (m = G.layoutUtilities()), p = !0), K.nodes().length > 0)
                      if (p) {
                        var R = t.getTopMostNodes(C.eles.nodes());
                        if (O = t.connectComponents(G, C.eles, R), O.forEach(function(vt) {
                          var it = vt.boundingBox();
                          rt.push({ x: it.x1 + it.w / 2, y: it.y1 + it.h / 2 });
                        }), C.randomize && O.forEach(function(vt) {
                          C.eles = vt, X.push(o(C));
                        }), C.quality == "default" || C.quality == "proof") {
                          var M = G.collection();
                          if (C.tile) {
                            var F = /* @__PURE__ */ new Map(), W = [], x = [], Z = 0, V = { nodeIndexes: F, xCoords: W, yCoords: x }, Y = [];
                            if (O.forEach(function(vt, it) {
                              vt.edges().length == 0 && (vt.nodes().forEach(function(gt, mt) {
                                M.merge(vt.nodes()[mt]), gt.isParent() || (V.nodeIndexes.set(vt.nodes()[mt].id(), Z++), V.xCoords.push(vt.nodes()[0].position().x), V.yCoords.push(vt.nodes()[0].position().y));
                              }), Y.push(it));
                            }), M.length > 1) {
                              var et = M.boundingBox();
                              rt.push({ x: et.x1 + et.w / 2, y: et.y1 + et.h / 2 }), O.push(M), X.push(V);
                              for (var z = Y.length - 1; z >= 0; z--)
                                O.splice(Y[z], 1), X.splice(Y[z], 1), rt.splice(Y[z], 1);
                            }
                          }
                          O.forEach(function(vt, it) {
                            C.eles = vt, Q.push(h(C, X[it])), t.relocateComponent(rt[it], Q[it], C);
                          });
                        } else
                          O.forEach(function(vt, it) {
                            t.relocateComponent(rt[it], X[it], C);
                          });
                        var w = /* @__PURE__ */ new Set();
                        if (O.length > 1) {
                          var H = [], B = K.filter(function(vt) {
                            return vt.css("display") == "none";
                          });
                          O.forEach(function(vt, it) {
                            var gt = void 0;
                            if (C.quality == "draft" && (gt = X[it].nodeIndexes), vt.nodes().not(B).length > 0) {
                              var mt = {};
                              mt.edges = [], mt.nodes = [];
                              var At = void 0;
                              vt.nodes().not(B).forEach(function(Ot) {
                                if (C.quality == "draft")
                                  if (!Ot.isParent())
                                    At = gt.get(Ot.id()), mt.nodes.push({ x: X[it].xCoords[At] - Ot.boundingbox().w / 2, y: X[it].yCoords[At] - Ot.boundingbox().h / 2, width: Ot.boundingbox().w, height: Ot.boundingbox().h });
                                  else {
                                    var Et = t.calcBoundingBox(Ot, X[it].xCoords, X[it].yCoords, gt);
                                    mt.nodes.push({ x: Et.topLeftX, y: Et.topLeftY, width: Et.width, height: Et.height });
                                  }
                                else
                                  Q[it][Ot.id()] && mt.nodes.push({ x: Q[it][Ot.id()].getLeft(), y: Q[it][Ot.id()].getTop(), width: Q[it][Ot.id()].getWidth(), height: Q[it][Ot.id()].getHeight() });
                              }), vt.edges().forEach(function(Ot) {
                                var Et = Ot.source(), Dt = Ot.target();
                                if (Et.css("display") != "none" && Dt.css("display") != "none")
                                  if (C.quality == "draft") {
                                    var Rt = gt.get(Et.id()), Ht = gt.get(Dt.id()), Ut = [], Pt = [];
                                    if (Et.isParent()) {
                                      var Ft = t.calcBoundingBox(Et, X[it].xCoords, X[it].yCoords, gt);
                                      Ut.push(Ft.topLeftX + Ft.width / 2), Ut.push(Ft.topLeftY + Ft.height / 2);
                                    } else
                                      Ut.push(X[it].xCoords[Rt]), Ut.push(X[it].yCoords[Rt]);
                                    if (Dt.isParent()) {
                                      var Yt = t.calcBoundingBox(Dt, X[it].xCoords, X[it].yCoords, gt);
                                      Pt.push(Yt.topLeftX + Yt.width / 2), Pt.push(Yt.topLeftY + Yt.height / 2);
                                    } else
                                      Pt.push(X[it].xCoords[Ht]), Pt.push(X[it].yCoords[Ht]);
                                    mt.edges.push({ startX: Ut[0], startY: Ut[1], endX: Pt[0], endY: Pt[1] });
                                  } else
                                    Q[it][Et.id()] && Q[it][Dt.id()] && mt.edges.push({ startX: Q[it][Et.id()].getCenterX(), startY: Q[it][Et.id()].getCenterY(), endX: Q[it][Dt.id()].getCenterX(), endY: Q[it][Dt.id()].getCenterY() });
                              }), mt.nodes.length > 0 && (H.push(mt), w.add(it));
                            }
                          });
                          var _ = m.packComponents(H, C.randomize).shifts;
                          if (C.quality == "draft")
                            X.forEach(function(vt, it) {
                              var gt = vt.xCoords.map(function(At) {
                                return At + _[it].dx;
                              }), mt = vt.yCoords.map(function(At) {
                                return At + _[it].dy;
                              });
                              vt.xCoords = gt, vt.yCoords = mt;
                            });
                          else {
                            var ht = 0;
                            w.forEach(function(vt) {
                              Object.keys(Q[vt]).forEach(function(it) {
                                var gt = Q[vt][it];
                                gt.setCenter(gt.getCenterX() + _[ht].dx, gt.getCenterY() + _[ht].dy);
                              }), ht++;
                            });
                          }
                        }
                      } else {
                        var E = C.eles.boundingBox();
                        if (rt.push({ x: E.x1 + E.w / 2, y: E.y1 + E.h / 2 }), C.randomize) {
                          var y = o(C);
                          X.push(y);
                        }
                        C.quality == "default" || C.quality == "proof" ? (Q.push(h(C, X[0])), t.relocateComponent(rt[0], Q[0], C)) : t.relocateComponent(rt[0], X[0], C);
                      }
                    var q = function(it, gt) {
                      if (C.quality == "default" || C.quality == "proof") {
                        typeof it == "number" && (it = gt);
                        var mt = void 0, At = void 0, Ot = it.data("id");
                        return Q.forEach(function(Dt) {
                          Ot in Dt && (mt = { x: Dt[Ot].getRect().getCenterX(), y: Dt[Ot].getRect().getCenterY() }, At = Dt[Ot]);
                        }), C.nodeDimensionsIncludeLabels && (At.labelWidth && (At.labelPosHorizontal == "left" ? mt.x += At.labelWidth / 2 : At.labelPosHorizontal == "right" && (mt.x -= At.labelWidth / 2)), At.labelHeight && (At.labelPosVertical == "top" ? mt.y += At.labelHeight / 2 : At.labelPosVertical == "bottom" && (mt.y -= At.labelHeight / 2))), mt == null && (mt = { x: it.position("x"), y: it.position("y") }), {
                          x: mt.x,
                          y: mt.y
                        };
                      } else {
                        var Et = void 0;
                        return X.forEach(function(Dt) {
                          var Rt = Dt.nodeIndexes.get(it.id());
                          Rt != null && (Et = { x: Dt.xCoords[Rt], y: Dt.yCoords[Rt] });
                        }), Et == null && (Et = { x: it.position("x"), y: it.position("y") }), {
                          x: Et.x,
                          y: Et.y
                        };
                      }
                    };
                    if (C.quality == "default" || C.quality == "proof" || C.randomize) {
                      var It = t.calcParentsWithoutChildren(G, K), Nt = K.filter(function(vt) {
                        return vt.css("display") == "none";
                      });
                      C.eles = K.not(Nt), K.nodes().not(":parent").not(Nt).layoutPositions(S, C, q), It.length > 0 && It.forEach(function(vt) {
                        vt.position(q(vt));
                      });
                    } else
                      console.log("If randomize option is set to false, then quality option must be 'default' or 'proof'.");
                  }
                }]), v;
              }();
              a.exports = d;
            }
          ),
          /***/
          657: (
            /***/
            (a, e, r) => {
              var f = r(548), i = r(140).layoutBase.Matrix, g = r(140).layoutBase.SVD, t = function(o) {
                var c = o.cy, h = o.eles, T = h.nodes(), d = h.nodes(":parent"), v = /* @__PURE__ */ new Map(), L = /* @__PURE__ */ new Map(), S = /* @__PURE__ */ new Map(), C = [], G = [], K = [], X = [], Q = [], O = [], rt = [], n = [], m = void 0, p = 1e8, E = 1e-9, y = o.piTol, R = o.samplingType, M = o.nodeSeparation, F = void 0, W = function() {
                  for (var U = 0, $ = 0, J = !1; $ < F; ) {
                    U = Math.floor(Math.random() * m), J = !1;
                    for (var k = 0; k < $; k++)
                      if (X[k] == U) {
                        J = !0;
                        break;
                      }
                    if (!J)
                      X[$] = U, $++;
                    else
                      continue;
                  }
                }, x = function(U, $, J) {
                  for (var k = [], at = 0, ct = 0, nt = 0, tt = void 0, j = [], ut = 0, Mt = 1, pt = 0; pt < m; pt++)
                    j[pt] = p;
                  for (k[ct] = U, j[U] = 0; ct >= at; ) {
                    nt = k[at++];
                    for (var xt = C[nt], lt = 0; lt < xt.length; lt++)
                      tt = L.get(xt[lt]), j[tt] == p && (j[tt] = j[nt] + 1, k[++ct] = tt);
                    O[nt][$] = j[nt] * M;
                  }
                  if (J) {
                    for (var ot = 0; ot < m; ot++)
                      O[ot][$] < Q[ot] && (Q[ot] = O[ot][$]);
                    for (var Lt = 0; Lt < m; Lt++)
                      Q[Lt] > ut && (ut = Q[Lt], Mt = Lt);
                  }
                  return Mt;
                }, Z = function(U) {
                  var $ = void 0;
                  if (U) {
                    $ = Math.floor(Math.random() * m);
                    for (var k = 0; k < m; k++)
                      Q[k] = p;
                    for (var at = 0; at < F; at++)
                      X[at] = $, $ = x($, at, U);
                  } else {
                    W();
                    for (var J = 0; J < F; J++)
                      x(X[J], J, U);
                  }
                  for (var ct = 0; ct < m; ct++)
                    for (var nt = 0; nt < F; nt++)
                      O[ct][nt] *= O[ct][nt];
                  for (var tt = 0; tt < F; tt++)
                    rt[tt] = [];
                  for (var j = 0; j < F; j++)
                    for (var ut = 0; ut < F; ut++)
                      rt[j][ut] = O[X[ut]][j];
                }, V = function() {
                  for (var U = g.svd(rt), $ = U.S, J = U.U, k = U.V, at = $[0] * $[0] * $[0], ct = [], nt = 0; nt < F; nt++) {
                    ct[nt] = [];
                    for (var tt = 0; tt < F; tt++)
                      ct[nt][tt] = 0, nt == tt && (ct[nt][tt] = $[nt] / ($[nt] * $[nt] + at / ($[nt] * $[nt])));
                  }
                  n = i.multMat(i.multMat(k, ct), i.transpose(J));
                }, Y = function() {
                  for (var U = void 0, $ = void 0, J = [], k = [], at = [], ct = [], nt = 0; nt < m; nt++)
                    J[nt] = Math.random(), k[nt] = Math.random();
                  J = i.normalize(J), k = i.normalize(k);
                  for (var tt = E, j = E, ut = void 0; ; ) {
                    for (var Mt = 0; Mt < m; Mt++)
                      at[Mt] = J[Mt];
                    if (J = i.multGamma(i.multL(i.multGamma(at), O, n)), U = i.dotProduct(at, J), J = i.normalize(J), tt = i.dotProduct(at, J), ut = Math.abs(tt / j), ut <= 1 + y && ut >= 1)
                      break;
                    j = tt;
                  }
                  for (var pt = 0; pt < m; pt++)
                    at[pt] = J[pt];
                  for (j = E; ; ) {
                    for (var xt = 0; xt < m; xt++)
                      ct[xt] = k[xt];
                    if (ct = i.minusOp(ct, i.multCons(at, i.dotProduct(at, ct))), k = i.multGamma(i.multL(i.multGamma(ct), O, n)), $ = i.dotProduct(ct, k), k = i.normalize(k), tt = i.dotProduct(ct, k), ut = Math.abs(tt / j), ut <= 1 + y && ut >= 1)
                      break;
                    j = tt;
                  }
                  for (var lt = 0; lt < m; lt++)
                    ct[lt] = k[lt];
                  G = i.multCons(at, Math.sqrt(Math.abs(U))), K = i.multCons(ct, Math.sqrt(Math.abs($)));
                };
                f.connectComponents(c, h, f.getTopMostNodes(T), v), d.forEach(function(b) {
                  f.connectComponents(c, h, f.getTopMostNodes(b.descendants().intersection(h)), v);
                });
                for (var et = 0, z = 0; z < T.length; z++)
                  T[z].isParent() || L.set(T[z].id(), et++);
                var w = !0, H = !1, B = void 0;
                try {
                  for (var _ = v.keys()[Symbol.iterator](), ht; !(w = (ht = _.next()).done); w = !0) {
                    var q = ht.value;
                    L.set(q, et++);
                  }
                } catch (b) {
                  H = !0, B = b;
                } finally {
                  try {
                    !w && _.return && _.return();
                  } finally {
                    if (H)
                      throw B;
                  }
                }
                for (var It = 0; It < L.size; It++)
                  C[It] = [];
                d.forEach(function(b) {
                  for (var U = b.children().intersection(h); U.nodes(":childless").length == 0; )
                    U = U.nodes()[0].children().intersection(h);
                  var $ = 0, J = U.nodes(":childless")[0].connectedEdges().length;
                  U.nodes(":childless").forEach(function(k, at) {
                    k.connectedEdges().length < J && (J = k.connectedEdges().length, $ = at);
                  }), S.set(b.id(), U.nodes(":childless")[$].id());
                }), T.forEach(function(b) {
                  var U = void 0;
                  b.isParent() ? U = L.get(S.get(b.id())) : U = L.get(b.id()), b.neighborhood().nodes().forEach(function($) {
                    h.intersection(b.edgesWith($)).length > 0 && ($.isParent() ? C[U].push(S.get($.id())) : C[U].push($.id()));
                  });
                });
                var Nt = function(U) {
                  var $ = L.get(U), J = void 0;
                  v.get(U).forEach(function(k) {
                    c.getElementById(k).isParent() ? J = S.get(k) : J = k, C[$].push(J), C[L.get(J)].push(U);
                  });
                }, vt = !0, it = !1, gt = void 0;
                try {
                  for (var mt = v.keys()[Symbol.iterator](), At; !(vt = (At = mt.next()).done); vt = !0) {
                    var Ot = At.value;
                    Nt(Ot);
                  }
                } catch (b) {
                  it = !0, gt = b;
                } finally {
                  try {
                    !vt && mt.return && mt.return();
                  } finally {
                    if (it)
                      throw gt;
                  }
                }
                m = L.size;
                var Et = void 0;
                if (m > 2) {
                  F = m < o.sampleSize ? m : o.sampleSize;
                  for (var Dt = 0; Dt < m; Dt++)
                    O[Dt] = [];
                  for (var Rt = 0; Rt < F; Rt++)
                    n[Rt] = [];
                  return o.quality == "draft" || o.step == "all" ? (Z(R), V(), Y(), Et = { nodeIndexes: L, xCoords: G, yCoords: K }) : (L.forEach(function(b, U) {
                    G.push(c.getElementById(U).position("x")), K.push(c.getElementById(U).position("y"));
                  }), Et = { nodeIndexes: L, xCoords: G, yCoords: K }), Et;
                } else {
                  var Ht = L.keys(), Ut = c.getElementById(Ht.next().value), Pt = Ut.position(), Ft = Ut.outerWidth();
                  if (G.push(Pt.x), K.push(Pt.y), m == 2) {
                    var Yt = c.getElementById(Ht.next().value), Vt = Yt.outerWidth();
                    G.push(Pt.x + Ft / 2 + Vt / 2 + o.idealEdgeLength), K.push(Pt.y);
                  }
                  return Et = { nodeIndexes: L, xCoords: G, yCoords: K }, Et;
                }
              };
              a.exports = { spectralLayout: t };
            }
          ),
          /***/
          579: (
            /***/
            (a, e, r) => {
              var f = r(212), i = function(t) {
                t && t("layout", "fcose", f);
              };
              typeof cytoscape < "u" && i(cytoscape), a.exports = i;
            }
          ),
          /***/
          140: (
            /***/
            (a) => {
              a.exports = A;
            }
          )
          /******/
        }, N = {};
        function u(a) {
          var e = N[a];
          if (e !== void 0)
            return e.exports;
          var r = N[a] = {
            /******/
            // no module.id needed
            /******/
            // no module.loaded needed
            /******/
            exports: {}
            /******/
          };
          return P[a](r, r.exports, u), r.exports;
        }
        var l = u(579);
        return l;
      })()
    );
  });
})(Fe);
var ur = Fe.exports;
const dr = /* @__PURE__ */ fr(ur);
var De = {
  L: "left",
  R: "right",
  T: "top",
  B: "bottom"
}, xe = {
  L: /* @__PURE__ */ dt((I) => `${I},${I / 2} 0,${I} 0,0`, "L"),
  R: /* @__PURE__ */ dt((I) => `0,${I / 2} ${I},0 ${I},${I}`, "R"),
  T: /* @__PURE__ */ dt((I) => `0,0 ${I},0 ${I / 2},${I}`, "T"),
  B: /* @__PURE__ */ dt((I) => `${I / 2},0 ${I},${I} 0,${I}`, "B")
}, se = {
  L: /* @__PURE__ */ dt((I, D) => I - D + 2, "L"),
  R: /* @__PURE__ */ dt((I, D) => I - 2, "R"),
  T: /* @__PURE__ */ dt((I, D) => I - D + 2, "T"),
  B: /* @__PURE__ */ dt((I, D) => I - 2, "B")
}, vr = /* @__PURE__ */ dt(function(I) {
  return Wt(I) ? I === "L" ? "R" : "L" : I === "T" ? "B" : "T";
}, "getOppositeArchitectureDirection"), Ie = /* @__PURE__ */ dt(function(I) {
  const D = I;
  return D === "L" || D === "R" || D === "T" || D === "B";
}, "isArchitectureDirection"), Wt = /* @__PURE__ */ dt(function(I) {
  const D = I;
  return D === "L" || D === "R";
}, "isArchitectureDirectionX"), qt = /* @__PURE__ */ dt(function(I) {
  const D = I;
  return D === "T" || D === "B";
}, "isArchitectureDirectionY"), Te = /* @__PURE__ */ dt(function(I, D) {
  const A = Wt(I) && qt(D), P = qt(I) && Wt(D);
  return A || P;
}, "isArchitectureDirectionXY"), pr = /* @__PURE__ */ dt(function(I) {
  const D = I[0], A = I[1], P = Wt(D) && qt(A), N = qt(D) && Wt(A);
  return P || N;
}, "isArchitecturePairXY"), yr = /* @__PURE__ */ dt(function(I) {
  return I !== "LL" && I !== "RR" && I !== "TT" && I !== "BB";
}, "isValidArchitectureDirectionPair"), pe = /* @__PURE__ */ dt(function(I, D) {
  const A = `${I}${D}`;
  return yr(A) ? A : void 0;
}, "getArchitectureDirectionPair"), Er = /* @__PURE__ */ dt(function([I, D], A) {
  const P = A[0], N = A[1];
  return Wt(P) ? qt(N) ? [I + (P === "L" ? -1 : 1), D + (N === "T" ? 1 : -1)] : [I + (P === "L" ? -1 : 1), D] : Wt(N) ? [I + (N === "L" ? 1 : -1), D + (P === "T" ? 1 : -1)] : [I, D + (P === "T" ? 1 : -1)];
}, "shiftPositionByArchitectureDirectionPair"), mr = /* @__PURE__ */ dt(function(I) {
  return I === "LT" || I === "TL" ? [1, 1] : I === "BL" || I === "LB" ? [1, -1] : I === "BR" || I === "RB" ? [-1, -1] : [-1, 1];
}, "getArchitectureDirectionXYFactors"), Tr = /* @__PURE__ */ dt(function(I, D) {
  return Te(I, D) ? "bend" : Wt(I) ? "horizontal" : "vertical";
}, "getArchitectureDirectionAlignment"), Nr = /* @__PURE__ */ dt(function(I) {
  return I.type === "service";
}, "isArchitectureService"), Lr = /* @__PURE__ */ dt(function(I) {
  return I.type === "junction";
}, "isArchitectureJunction"), be = /* @__PURE__ */ dt((I) => I.data(), "edgeData"), ie = /* @__PURE__ */ dt((I) => I.data(), "nodeData"), Cr = ir.architecture, ae, Pe = (ae = class {
  constructor() {
    this.nodes = {}, this.groups = {}, this.edges = [], this.registeredIds = {}, this.elements = {}, this.setAccTitle = qe, this.getAccTitle = Qe, this.setDiagramTitle = Je, this.getDiagramTitle = Ke, this.getAccDescription = je, this.setAccDescription = _e, this.clear();
  }
  clear() {
    this.nodes = {}, this.groups = {}, this.edges = [], this.registeredIds = {}, this.dataStructures = void 0, this.elements = {}, tr();
  }
  addService({
    id: D,
    icon: A,
    in: P,
    title: N,
    iconText: u
  }) {
    if (this.registeredIds[D] !== void 0)
      throw new Error(
        `The service id [${D}] is already in use by another ${this.registeredIds[D]}`
      );
    if (P !== void 0) {
      if (D === P)
        throw new Error(`The service [${D}] cannot be placed within itself`);
      if (this.registeredIds[P] === void 0)
        throw new Error(
          `The service [${D}]'s parent does not exist. Please make sure the parent is created before this service`
        );
      if (this.registeredIds[P] === "node")
        throw new Error(`The service [${D}]'s parent is not a group`);
    }
    this.registeredIds[D] = "node", this.nodes[D] = {
      id: D,
      type: "service",
      icon: A,
      iconText: u,
      title: N,
      edges: [],
      in: P
    };
  }
  getServices() {
    return Object.values(this.nodes).filter(Nr);
  }
  addJunction({ id: D, in: A }) {
    this.registeredIds[D] = "node", this.nodes[D] = {
      id: D,
      type: "junction",
      edges: [],
      in: A
    };
  }
  getJunctions() {
    return Object.values(this.nodes).filter(Lr);
  }
  getNodes() {
    return Object.values(this.nodes);
  }
  getNode(D) {
    return this.nodes[D] ?? null;
  }
  addGroup({ id: D, icon: A, in: P, title: N }) {
    var u, l, a;
    if (((u = this.registeredIds) == null ? void 0 : u[D]) !== void 0)
      throw new Error(
        `The group id [${D}] is already in use by another ${this.registeredIds[D]}`
      );
    if (P !== void 0) {
      if (D === P)
        throw new Error(`The group [${D}] cannot be placed within itself`);
      if (((l = this.registeredIds) == null ? void 0 : l[P]) === void 0)
        throw new Error(
          `The group [${D}]'s parent does not exist. Please make sure the parent is created before this group`
        );
      if (((a = this.registeredIds) == null ? void 0 : a[P]) === "node")
        throw new Error(`The group [${D}]'s parent is not a group`);
    }
    this.registeredIds[D] = "group", this.groups[D] = {
      id: D,
      icon: A,
      title: N,
      in: P
    };
  }
  getGroups() {
    return Object.values(this.groups);
  }
  addEdge({
    lhsId: D,
    rhsId: A,
    lhsDir: P,
    rhsDir: N,
    lhsInto: u,
    rhsInto: l,
    lhsGroup: a,
    rhsGroup: e,
    title: r
  }) {
    if (!Ie(P))
      throw new Error(
        `Invalid direction given for left hand side of edge ${D}--${A}. Expected (L,R,T,B) got ${String(P)}`
      );
    if (!Ie(N))
      throw new Error(
        `Invalid direction given for right hand side of edge ${D}--${A}. Expected (L,R,T,B) got ${String(N)}`
      );
    if (this.nodes[D] === void 0 && this.groups[D] === void 0)
      throw new Error(
        `The left-hand id [${D}] does not yet exist. Please create the service/group before declaring an edge to it.`
      );
    if (this.nodes[A] === void 0 && this.groups[A] === void 0)
      throw new Error(
        `The right-hand id [${A}] does not yet exist. Please create the service/group before declaring an edge to it.`
      );
    const f = this.nodes[D].in, i = this.nodes[A].in;
    if (a && f && i && f == i)
      throw new Error(
        `The left-hand id [${D}] is modified to traverse the group boundary, but the edge does not pass through two groups.`
      );
    if (e && f && i && f == i)
      throw new Error(
        `The right-hand id [${A}] is modified to traverse the group boundary, but the edge does not pass through two groups.`
      );
    const g = {
      lhsId: D,
      lhsDir: P,
      lhsInto: u,
      lhsGroup: a,
      rhsId: A,
      rhsDir: N,
      rhsInto: l,
      rhsGroup: e,
      title: r
    };
    this.edges.push(g), this.nodes[D] && this.nodes[A] && (this.nodes[D].edges.push(this.edges[this.edges.length - 1]), this.nodes[A].edges.push(this.edges[this.edges.length - 1]));
  }
  getEdges() {
    return this.edges;
  }
  /**
   * Returns the current diagram's adjacency list, spatial map, & group alignments.
   * If they have not been created, run the algorithms to generate them.
   * @returns
   */
  getDataStructures() {
    if (this.dataStructures === void 0) {
      const D = {}, A = Object.entries(this.nodes).reduce((e, [r, f]) => (e[r] = f.edges.reduce((i, g) => {
        var o, c;
        const t = (o = this.getNode(g.lhsId)) == null ? void 0 : o.in, s = (c = this.getNode(g.rhsId)) == null ? void 0 : c.in;
        if (t && s && t !== s) {
          const h = Tr(g.lhsDir, g.rhsDir);
          h !== "bend" && (D[t] ?? (D[t] = {}), D[t][s] = h, D[s] ?? (D[s] = {}), D[s][t] = h);
        }
        if (g.lhsId === r) {
          const h = pe(g.lhsDir, g.rhsDir);
          h && (i[h] = g.rhsId);
        } else {
          const h = pe(g.rhsDir, g.lhsDir);
          h && (i[h] = g.lhsId);
        }
        return i;
      }, {}), e), {}), P = Object.keys(A)[0], N = { [P]: 1 }, u = Object.keys(A).reduce(
        (e, r) => r === P ? e : { ...e, [r]: 1 },
        {}
      ), l = /* @__PURE__ */ dt((e) => {
        const r = { [e]: [0, 0] }, f = [e];
        for (; f.length > 0; ) {
          const i = f.shift();
          if (i) {
            N[i] = 1, delete u[i];
            const g = A[i], [t, s] = r[i];
            Object.entries(g).forEach(([o, c]) => {
              N[c] || (r[c] = Er(
                [t, s],
                o
              ), f.push(c));
            });
          }
        }
        return r;
      }, "BFS"), a = [l(P)];
      for (; Object.keys(u).length > 0; )
        a.push(l(Object.keys(u)[0]));
      this.dataStructures = {
        adjList: A,
        spatialMaps: a,
        groupAlignments: D
      };
    }
    return this.dataStructures;
  }
  setElementForId(D, A) {
    this.elements[D] = A;
  }
  getElementById(D) {
    return this.elements[D];
  }
  getConfig() {
    return er({
      ...Cr,
      ...rr().architecture
    });
  }
  getConfigField(D) {
    return this.getConfig()[D];
  }
}, dt(ae, "ArchitectureDB"), ae), Ar = /* @__PURE__ */ dt((I, D) => {
  hr(I, D), I.groups.map((A) => D.addGroup(A)), I.services.map((A) => D.addService({ ...A, type: "service" })), I.junctions.map((A) => D.addJunction({ ...A, type: "junction" })), I.edges.map((A) => D.addEdge(A));
}, "populateDb"), Ge = {
  parser: {
    // @ts-expect-error - ArchitectureDB is not assignable to DiagramDB
    yy: void 0
  },
  parse: /* @__PURE__ */ dt(async (I) => {
    var P;
    const D = await lr("architecture", I);
    Re.debug(D);
    const A = (P = Ge.parser) == null ? void 0 : P.yy;
    if (!(A instanceof Pe))
      throw new Error(
        "parser.parser?.yy was not a ArchitectureDB. This is due to a bug within Mermaid, please report this issue at https://github.com/mermaid-js/mermaid/issues."
      );
    Ar(D, A);
  }, "parse")
}, Mr = /* @__PURE__ */ dt((I) => `
  .edge {
    stroke-width: ${I.archEdgeWidth};
    stroke: ${I.archEdgeColor};
    fill: none;
  }

  .arrow {
    fill: ${I.archEdgeArrowColor};
  }

  .node-bkg {
    fill: none;
    stroke: ${I.archGroupBorderColor};
    stroke-width: ${I.archGroupBorderWidth};
    stroke-dasharray: 8;
  }
  .node-icon-text {
    display: flex; 
    align-items: center;
  }
  
  .node-icon-text > div {
    color: #fff;
    margin: 1px;
    height: fit-content;
    text-align: center;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
  }
`, "getStyles"), wr = Mr, re = /* @__PURE__ */ dt((I) => `<g><rect width="80" height="80" style="fill: #087ebf; stroke-width: 0px;"/>${I}</g>`, "wrapIcon"), ne = {
  prefix: "mermaid-architecture",
  height: 80,
  width: 80,
  icons: {
    database: {
      body: re(
        '<path id="b" data-name="4" d="m20,57.86c0,3.94,8.95,7.14,20,7.14s20-3.2,20-7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path id="c" data-name="3" d="m20,45.95c0,3.94,8.95,7.14,20,7.14s20-3.2,20-7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path id="d" data-name="2" d="m20,34.05c0,3.94,8.95,7.14,20,7.14s20-3.2,20-7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse id="e" data-name="1" cx="40" cy="22.14" rx="20" ry="7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="20" y1="57.86" x2="20" y2="22.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="60" y1="57.86" x2="60" y2="22.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/>'
      )
    },
    server: {
      body: re(
        '<rect x="17.5" y="17.5" width="45" height="45" rx="2" ry="2" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="17.5" y1="32.5" x2="62.5" y2="32.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="17.5" y1="47.5" x2="62.5" y2="47.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><g><path d="m56.25,25c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: #fff; stroke-width: 0px;"/><path d="m56.25,25c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10;"/></g><g><path d="m56.25,40c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: #fff; stroke-width: 0px;"/><path d="m56.25,40c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10;"/></g><g><path d="m56.25,55c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: #fff; stroke-width: 0px;"/><path d="m56.25,55c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10;"/></g><g><circle cx="32.5" cy="25" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="27.5" cy="25" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="22.5" cy="25" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/></g><g><circle cx="32.5" cy="40" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="27.5" cy="40" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="22.5" cy="40" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/></g><g><circle cx="32.5" cy="55" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="27.5" cy="55" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="22.5" cy="55" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/></g>'
      )
    },
    disk: {
      body: re(
        '<rect x="20" y="15" width="40" height="50" rx="1" ry="1" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="24" cy="19.17" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="56" cy="19.17" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="24" cy="60.83" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="56" cy="60.83" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="40" cy="33.75" rx="14" ry="14.58" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="40" cy="33.75" rx="4" ry="4.17" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path d="m37.51,42.52l-4.83,13.22c-.26.71-1.1,1.02-1.76.64l-4.18-2.42c-.66-.38-.81-1.26-.33-1.84l9.01-10.8c.88-1.05,2.56-.08,2.09,1.2Z" style="fill: #fff; stroke-width: 0px;"/>'
      )
    },
    internet: {
      body: re(
        '<circle cx="40" cy="40" r="22.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="40" y1="17.5" x2="40" y2="62.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="17.5" y1="40" x2="62.5" y2="40" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path d="m39.99,17.51c-15.28,11.1-15.28,33.88,0,44.98" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path d="m40.01,17.51c15.28,11.1,15.28,33.88,0,44.98" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="19.75" y1="30.1" x2="60.25" y2="30.1" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="19.75" y1="49.9" x2="60.25" y2="49.9" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/>'
      )
    },
    cloud: {
      body: re(
        '<path d="m65,47.5c0,2.76-2.24,5-5,5H20c-2.76,0-5-2.24-5-5,0-1.87,1.03-3.51,2.56-4.36-.04-.21-.06-.42-.06-.64,0-2.6,2.48-4.74,5.65-4.97,1.65-4.51,6.34-7.76,11.85-7.76.86,0,1.69.08,2.5.23,2.09-1.57,4.69-2.5,7.5-2.5,6.1,0,11.19,4.38,12.28,10.17,2.14.56,3.72,2.51,3.72,4.83,0,.03,0,.07-.01.1,2.29.46,4.01,2.48,4.01,4.9Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/>'
      )
    },
    unknown: sr,
    blank: {
      body: re("")
    }
  }
}, Or = /* @__PURE__ */ dt(async function(I, D, A) {
  const P = A.getConfigField("padding"), N = A.getConfigField("iconSize"), u = N / 2, l = N / 6, a = l / 2;
  await Promise.all(
    D.edges().map(async (e) => {
      var K, X;
      const {
        source: r,
        sourceDir: f,
        sourceArrow: i,
        sourceGroup: g,
        target: t,
        targetDir: s,
        targetArrow: o,
        targetGroup: c,
        label: h
      } = be(e);
      let { x: T, y: d } = e[0].sourceEndpoint();
      const { x: v, y: L } = e[0].midpoint();
      let { x: S, y: C } = e[0].targetEndpoint();
      const G = P + 4;
      if (g && (Wt(f) ? T += f === "L" ? -G : G : d += f === "T" ? -G : G + 18), c && (Wt(s) ? S += s === "L" ? -G : G : C += s === "T" ? -G : G + 18), !g && ((K = A.getNode(r)) == null ? void 0 : K.type) === "junction" && (Wt(f) ? T += f === "L" ? u : -u : d += f === "T" ? u : -u), !c && ((X = A.getNode(t)) == null ? void 0 : X.type) === "junction" && (Wt(s) ? S += s === "L" ? u : -u : C += s === "T" ? u : -u), e[0]._private.rscratch) {
        const Q = I.insert("g");
        if (Q.insert("path").attr("d", `M ${T},${d} L ${v},${L} L${S},${C} `).attr("class", "edge"), i) {
          const O = Wt(f) ? se[f](T, l) : T - a, rt = qt(f) ? se[f](d, l) : d - a;
          Q.insert("polygon").attr("points", xe[f](l)).attr("transform", `translate(${O},${rt})`).attr("class", "arrow");
        }
        if (o) {
          const O = Wt(s) ? se[s](S, l) : S - a, rt = qt(s) ? se[s](C, l) : C - a;
          Q.insert("polygon").attr("points", xe[s](l)).attr("transform", `translate(${O},${rt})`).attr("class", "arrow");
        }
        if (h) {
          const O = Te(f, s) ? "XY" : Wt(f) ? "X" : "Y";
          let rt = 0;
          O === "X" ? rt = Math.abs(T - S) : O === "Y" ? rt = Math.abs(d - C) / 1.5 : rt = Math.abs(T - S) / 2;
          const n = Q.append("g");
          if (await Ee(
            n,
            h,
            {
              useHtmlLabels: !1,
              width: rt,
              classes: "architecture-service-label"
            },
            ye()
          ), n.attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "middle").attr("text-anchor", "middle"), O === "X")
            n.attr("transform", "translate(" + v + ", " + L + ")");
          else if (O === "Y")
            n.attr("transform", "translate(" + v + ", " + L + ") rotate(-90)");
          else if (O === "XY") {
            const m = pe(f, s);
            if (m && pr(m)) {
              const p = n.node().getBoundingClientRect(), [E, y] = mr(m);
              n.attr("dominant-baseline", "auto").attr("transform", `rotate(${-1 * E * y * 45})`);
              const R = n.node().getBoundingClientRect();
              n.attr(
                "transform",
                `
                translate(${v}, ${L - p.height / 2})
                translate(${E * R.width / 2}, ${y * R.height / 2})
                rotate(${-1 * E * y * 45}, 0, ${p.height / 2})
              `
              );
            }
          }
        }
      }
    })
  );
}, "drawEdges"), Dr = /* @__PURE__ */ dt(async function(I, D, A) {
  const N = A.getConfigField("padding") * 0.75, u = A.getConfigField("fontSize"), a = A.getConfigField("iconSize") / 2;
  await Promise.all(
    D.nodes().map(async (e) => {
      const r = ie(e);
      if (r.type === "group") {
        const { h: f, w: i, x1: g, y1: t } = e.boundingBox();
        I.append("rect").attr("x", g + a).attr("y", t + a).attr("width", i).attr("height", f).attr("class", "node-bkg");
        const s = I.append("g");
        let o = g, c = t;
        if (r.icon) {
          const h = s.append("g");
          h.html(
            `<g>${await ve(r.icon, { height: N, width: N, fallbackPrefix: ne.prefix })}</g>`
          ), h.attr(
            "transform",
            "translate(" + (o + a + 1) + ", " + (c + a + 1) + ")"
          ), o += N, c += u / 2 - 1 - 2;
        }
        if (r.label) {
          const h = s.append("g");
          await Ee(
            h,
            r.label,
            {
              useHtmlLabels: !1,
              width: i,
              classes: "architecture-service-label"
            },
            ye()
          ), h.attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "start").attr("text-anchor", "start"), h.attr(
            "transform",
            "translate(" + (o + a + 4) + ", " + (c + a + 2) + ")"
          );
        }
      }
    })
  );
}, "drawGroups"), xr = /* @__PURE__ */ dt(async function(I, D, A) {
  const P = ye();
  for (const N of A) {
    const u = D.append("g"), l = I.getConfigField("iconSize");
    if (N.title) {
      const f = u.append("g");
      await Ee(
        f,
        N.title,
        {
          useHtmlLabels: !1,
          width: l * 1.5,
          classes: "architecture-service-label"
        },
        P
      ), f.attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "middle").attr("text-anchor", "middle"), f.attr("transform", "translate(" + l / 2 + ", " + l + ")");
    }
    const a = u.append("g");
    if (N.icon)
      a.html(
        `<g>${await ve(N.icon, { height: l, width: l, fallbackPrefix: ne.prefix })}</g>`
      );
    else if (N.iconText) {
      a.html(
        `<g>${await ve("blank", { height: l, width: l, fallbackPrefix: ne.prefix })}</g>`
      );
      const g = a.append("g").append("foreignObject").attr("width", l).attr("height", l).append("div").attr("class", "node-icon-text").attr("style", `height: ${l}px;`).append("div").html(ar(N.iconText, P)), t = parseInt(
        window.getComputedStyle(g.node(), null).getPropertyValue("font-size").replace(/\D/g, "")
      ) ?? 16;
      g.attr("style", `-webkit-line-clamp: ${Math.floor((l - 2) / t)};`);
    } else
      a.append("path").attr("class", "node-bkg").attr("id", "node-" + N.id).attr(
        "d",
        `M0 ${l} v${-l} q0,-5 5,-5 h${l} q5,0 5,5 v${l} H0 Z`
      );
    u.attr("class", "architecture-service");
    const { width: e, height: r } = u._groups[0][0].getBBox();
    N.width = e, N.height = r, I.setElementForId(N.id, u);
  }
  return 0;
}, "drawServices"), Ir = /* @__PURE__ */ dt(function(I, D, A) {
  A.forEach((P) => {
    const N = D.append("g"), u = I.getConfigField("iconSize");
    N.append("g").append("rect").attr("id", "node-" + P.id).attr("fill-opacity", "0").attr("width", u).attr("height", u), N.attr("class", "architecture-junction");
    const { width: a, height: e } = N._groups[0][0].getBBox();
    N.width = a, N.height = e, I.setElementForId(P.id, N);
  });
}, "drawJunctions");
or([
  {
    name: ne.prefix,
    icons: ne
  }
]);
Se.use(dr);
function Ue(I, D, A) {
  I.forEach((P) => {
    D.add({
      group: "nodes",
      data: {
        type: "service",
        id: P.id,
        icon: P.icon,
        label: P.title,
        parent: P.in,
        width: A.getConfigField("iconSize"),
        height: A.getConfigField("iconSize")
      },
      classes: "node-service"
    });
  });
}
dt(Ue, "addServices");
function Ye(I, D, A) {
  I.forEach((P) => {
    D.add({
      group: "nodes",
      data: {
        type: "junction",
        id: P.id,
        parent: P.in,
        width: A.getConfigField("iconSize"),
        height: A.getConfigField("iconSize")
      },
      classes: "node-junction"
    });
  });
}
dt(Ye, "addJunctions");
function Xe(I, D) {
  D.nodes().map((A) => {
    const P = ie(A);
    if (P.type === "group")
      return;
    P.x = A.position().x, P.y = A.position().y, I.getElementById(P.id).attr("transform", "translate(" + (P.x || 0) + "," + (P.y || 0) + ")");
  });
}
dt(Xe, "positionNodes");
function He(I, D) {
  I.forEach((A) => {
    D.add({
      group: "nodes",
      data: {
        type: "group",
        id: A.id,
        icon: A.icon,
        label: A.title,
        parent: A.in
      },
      classes: "node-group"
    });
  });
}
dt(He, "addGroups");
function We(I, D) {
  I.forEach((A) => {
    const { lhsId: P, rhsId: N, lhsInto: u, lhsGroup: l, rhsInto: a, lhsDir: e, rhsDir: r, rhsGroup: f, title: i } = A, g = Te(A.lhsDir, A.rhsDir) ? "segments" : "straight", t = {
      id: `${P}-${N}`,
      label: i,
      source: P,
      sourceDir: e,
      sourceArrow: u,
      sourceGroup: l,
      sourceEndpoint: e === "L" ? "0 50%" : e === "R" ? "100% 50%" : e === "T" ? "50% 0" : "50% 100%",
      target: N,
      targetDir: r,
      targetArrow: a,
      targetGroup: f,
      targetEndpoint: r === "L" ? "0 50%" : r === "R" ? "100% 50%" : r === "T" ? "50% 0" : "50% 100%"
    };
    D.add({
      group: "edges",
      data: t,
      classes: g
    });
  });
}
dt(We, "addEdges");
function Ve(I, D, A) {
  const P = /* @__PURE__ */ dt((a, e) => Object.entries(a).reduce(
    (r, [f, i]) => {
      var s;
      let g = 0;
      const t = Object.entries(i);
      if (t.length === 1)
        return r[f] = t[0][1], r;
      for (let o = 0; o < t.length - 1; o++)
        for (let c = o + 1; c < t.length; c++) {
          const [h, T] = t[o], [d, v] = t[c];
          if (((s = A[h]) == null ? void 0 : s[d]) === e)
            r[f] ?? (r[f] = []), r[f] = [...r[f], ...T, ...v];
          else if (h === "default" || d === "default")
            r[f] ?? (r[f] = []), r[f] = [...r[f], ...T, ...v];
          else {
            const S = `${f}-${g++}`;
            r[S] = T;
            const C = `${f}-${g++}`;
            r[C] = v;
          }
        }
      return r;
    },
    {}
  ), "flattenAlignments"), N = D.map((a) => {
    const e = {}, r = {};
    return Object.entries(a).forEach(([f, [i, g]]) => {
      var s, o, c;
      const t = ((s = I.getNode(f)) == null ? void 0 : s.in) ?? "default";
      e[g] ?? (e[g] = {}), (o = e[g])[t] ?? (o[t] = []), e[g][t].push(f), r[i] ?? (r[i] = {}), (c = r[i])[t] ?? (c[t] = []), r[i][t].push(f);
    }), {
      horiz: Object.values(P(e, "horizontal")).filter(
        (f) => f.length > 1
      ),
      vert: Object.values(P(r, "vertical")).filter(
        (f) => f.length > 1
      )
    };
  }), [u, l] = N.reduce(
    ([a, e], { horiz: r, vert: f }) => [
      [...a, ...r],
      [...e, ...f]
    ],
    [[], []]
  );
  return {
    horizontal: u,
    vertical: l
  };
}
dt(Ve, "getAlignments");
function ze(I, D) {
  const A = [], P = /* @__PURE__ */ dt((u) => `${u[0]},${u[1]}`, "posToStr"), N = /* @__PURE__ */ dt((u) => u.split(",").map((l) => parseInt(l)), "strToPos");
  return I.forEach((u) => {
    const l = Object.fromEntries(
      Object.entries(u).map(([f, i]) => [P(i), f])
    ), a = [P([0, 0])], e = {}, r = {
      L: [-1, 0],
      R: [1, 0],
      T: [0, 1],
      B: [0, -1]
    };
    for (; a.length > 0; ) {
      const f = a.shift();
      if (f) {
        e[f] = 1;
        const i = l[f];
        if (i) {
          const g = N(f);
          Object.entries(r).forEach(([t, s]) => {
            const o = P([g[0] + s[0], g[1] + s[1]]), c = l[o];
            c && !e[o] && (a.push(o), A.push({
              [De[t]]: c,
              [De[vr(t)]]: i,
              gap: 1.5 * D.getConfigField("iconSize")
            }));
          });
        }
      }
    }
  }), A;
}
dt(ze, "getRelativeConstraints");
function Be(I, D, A, P, N, { spatialMaps: u, groupAlignments: l }) {
  return new Promise((a) => {
    const e = nr("body").append("div").attr("id", "cy").attr("style", "display:none"), r = Se({
      container: document.getElementById("cy"),
      style: [
        {
          selector: "edge",
          style: {
            "curve-style": "straight",
            label: "data(label)",
            "source-endpoint": "data(sourceEndpoint)",
            "target-endpoint": "data(targetEndpoint)"
          }
        },
        {
          selector: "edge.segments",
          style: {
            "curve-style": "segments",
            "segment-weights": "0",
            "segment-distances": [0.5],
            // @ts-ignore Incorrect library types
            "edge-distances": "endpoints",
            "source-endpoint": "data(sourceEndpoint)",
            "target-endpoint": "data(targetEndpoint)"
          }
        },
        {
          selector: "node",
          style: {
            // @ts-ignore Incorrect library types
            "compound-sizing-wrt-labels": "include"
          }
        },
        {
          selector: "node[label]",
          style: {
            "text-valign": "bottom",
            "text-halign": "center",
            "font-size": `${N.getConfigField("fontSize")}px`
          }
        },
        {
          selector: ".node-service",
          style: {
            label: "data(label)",
            width: "data(width)",
            height: "data(height)"
          }
        },
        {
          selector: ".node-junction",
          style: {
            width: "data(width)",
            height: "data(height)"
          }
        },
        {
          selector: ".node-group",
          style: {
            // @ts-ignore Incorrect library types
            padding: `${N.getConfigField("padding")}px`
          }
        }
      ],
      layout: {
        name: "grid",
        boundingBox: {
          x1: 0,
          x2: 100,
          y1: 0,
          y2: 100
        }
      }
    });
    e.remove(), He(A, r), Ue(I, r, N), Ye(D, r, N), We(P, r);
    const f = Ve(N, u, l), i = ze(u, N), g = r.layout({
      name: "fcose",
      quality: "proof",
      styleEnabled: !1,
      animate: !1,
      nodeDimensionsIncludeLabels: !1,
      // Adjust the edge parameters if it passes through the border of a group
      // Hacky fix for: https://github.com/iVis-at-Bilkent/cytoscape.js-fcose/issues/67
      idealEdgeLength(t) {
        const [s, o] = t.connectedNodes(), { parent: c } = ie(s), { parent: h } = ie(o);
        return c === h ? 1.5 * N.getConfigField("iconSize") : 0.5 * N.getConfigField("iconSize");
      },
      edgeElasticity(t) {
        const [s, o] = t.connectedNodes(), { parent: c } = ie(s), { parent: h } = ie(o);
        return c === h ? 0.45 : 1e-3;
      },
      alignmentConstraint: f,
      relativePlacementConstraint: i
    });
    g.one("layoutstop", () => {
      var s;
      function t(o, c, h, T) {
        let d, v;
        const { x: L, y: S } = o, { x: C, y: G } = c;
        v = (T - S + (L - h) * (S - G) / (L - C)) / Math.sqrt(1 + Math.pow((S - G) / (L - C), 2)), d = Math.sqrt(Math.pow(T - S, 2) + Math.pow(h - L, 2) - Math.pow(v, 2));
        const K = Math.sqrt(Math.pow(C - L, 2) + Math.pow(G - S, 2));
        d = d / K;
        let X = (C - L) * (T - S) - (G - S) * (h - L);
        switch (!0) {
          case X >= 0:
            X = 1;
            break;
          case X < 0:
            X = -1;
            break;
        }
        let Q = (C - L) * (h - L) + (G - S) * (T - S);
        switch (!0) {
          case Q >= 0:
            Q = 1;
            break;
          case Q < 0:
            Q = -1;
            break;
        }
        return v = Math.abs(v) * X, d = d * Q, {
          distances: v,
          weights: d
        };
      }
      dt(t, "getSegmentWeights"), r.startBatch();
      for (const o of Object.values(r.edges()))
        if ((s = o.data) != null && s.call(o)) {
          const { x: c, y: h } = o.source().position(), { x: T, y: d } = o.target().position();
          if (c !== T && h !== d) {
            const v = o.sourceEndpoint(), L = o.targetEndpoint(), { sourceDir: S } = be(o), [C, G] = qt(S) ? [v.x, L.y] : [L.x, v.y], { weights: K, distances: X } = t(v, L, C, G);
            o.style("segment-distances", X), o.style("segment-weights", K);
          }
        }
      r.endBatch(), g.run();
    }), g.run(), r.ready((t) => {
      Re.info("Ready", t), a(r);
    });
  });
}
dt(Be, "layoutArchitecture");
var Rr = /* @__PURE__ */ dt(async (I, D, A, P) => {
  const N = P.db, u = N.getServices(), l = N.getJunctions(), a = N.getGroups(), e = N.getEdges(), r = N.getDataStructures(), f = ke(D), i = f.append("g");
  i.attr("class", "architecture-edges");
  const g = f.append("g");
  g.attr("class", "architecture-services");
  const t = f.append("g");
  t.attr("class", "architecture-groups"), await xr(N, g, u), Ir(N, g, l);
  const s = await Be(u, l, a, e, N, r);
  await Or(i, s, N), await Dr(t, s, N), Xe(N, s), Ze(void 0, f, N.getConfigField("padding"), N.getConfigField("useMaxWidth"));
}, "draw"), Sr = { draw: Rr }, Yr = {
  parser: Ge,
  get db() {
    return new Pe();
  },
  renderer: Sr,
  styles: wr
};
export {
  Yr as diagram
};
