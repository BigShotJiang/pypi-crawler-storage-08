import { C as e, I as o } from "./Index-BpWUvslZ.js";
export {
  e as BaseChatBot,
  o as default
};
