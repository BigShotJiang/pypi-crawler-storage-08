<svg
	id="icon"
	xmlns="http://www.w3.org/2000/svg"
	viewBox="0 0 32 32"
	fill="none"
	><path fill="currentColor" d="M4,2H28l-5.8,9L28,20H6v10H4V2z" /></svg
>
