"""Command-line interface for OpenAgents."""
