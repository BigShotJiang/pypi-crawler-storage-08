"""A set of helper math functions."""
