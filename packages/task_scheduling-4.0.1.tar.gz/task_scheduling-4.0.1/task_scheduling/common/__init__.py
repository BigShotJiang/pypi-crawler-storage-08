# -*- coding: utf-8 -*-
# Author: fallingmeteorite
from .log_config import configure_logger, logger, set_log_level
