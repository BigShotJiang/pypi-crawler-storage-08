# -*- coding: utf-8 -*-
# Author: fallingmeteorite
from .tag_added import FunctionRunner, task_function_type
