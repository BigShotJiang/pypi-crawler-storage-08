from fastapi_module_loader.loader import ModuleLoader as ModuleLoader
from fastapi_module_loader.module import BaseModule as BaseModule
