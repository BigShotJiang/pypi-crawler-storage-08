class ImproperlyConfiguredModules(RuntimeError):
    """
    Raised when a module loaded by ModuleConfigLoader is not configured correctly.
    """

    pass
