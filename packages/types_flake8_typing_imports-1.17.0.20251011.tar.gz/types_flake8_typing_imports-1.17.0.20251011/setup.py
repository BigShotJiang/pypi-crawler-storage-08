
from setuptools import setup

setup(package_data={'flake8_typing_imports-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
