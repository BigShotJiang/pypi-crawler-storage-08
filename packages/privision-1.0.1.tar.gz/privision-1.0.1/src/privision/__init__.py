"""
Privision - 视频内容脱敏工具
基于OCR的内容识别与打码系统
"""

__version__ = '1.0.0'
__author__ = 'ProjectAn'
