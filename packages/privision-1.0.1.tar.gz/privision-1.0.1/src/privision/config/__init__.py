"""配置模块"""
from .args import ProcessConfig, parse_args

__all__ = ['ProcessConfig', 'parse_args']
