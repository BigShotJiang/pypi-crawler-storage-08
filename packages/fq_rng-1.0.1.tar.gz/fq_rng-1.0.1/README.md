[![PyPI version](https://badge.fury.io/py/FQ-RNG.svg)](https://pypi.org/project/FQ-RNG/)
[![Python versions](https://img.shields.io/pypi/pyversions/FQ-RNG.svg)](https://pypi.org/project/FQ-RNG/)

# FQ-RNG

**Quantum Random Number Generator using Bell Fractal Algorithms**

High-performance cryptographic RNG using Bell fractal quantum algorithms with automatic statistical validation. Generates cryptographically secure random numbers suitable for security applications, simulations, and research.

## Quick Start

```bash
pip install FQ-RNG
```

```python
from fqrng import QuantumRNG

# Generate cryptographically secure random bits
qrng = QuantumRNG(bits=10000, validate=True)
bits, validation_results, entropy = qrng.generate_bits()

print(f"Generated {len(bits)} bits with entropy: {entropy:.4f}")
print(f"Validation tests passed: {sum(r['passed'] for r in validation_results.values())}/6")

# Generate random numbers
random_int = qrng.generate_int(0, 100)
random_float = qrng.generate_float(0.0, 1.0)
```

## Architecture

```
FQ-RNG Core
├── QuantumRNG (Cython-accelerated)
│   ├── GHZ State Generation (Bell fractal quantum source)
│   └── Beam Splitter Simulation (vacuum fluctuations)
├── Statistical Validator
├── Von Neumann Post-processing (bias removal)
└── CLI Interface (ASCII tree visualization)
```

## Performance

- **Generation Speed**: ~1000 bits/ms (CPU), faster with GPU
- **Statistical Quality**: High entropy and randomness
- **Memory Efficient**: Minimal footprint
- **Cross-Platform**: Windows, Linux, macOS, ARM64
- **Thread-Safe**: Concurrent generation support

## Installation Options

### Standard Installation
```bash
pip install FQ-RNG
```

### With GPU Support
```bash
pip install FQ-RNG[gpu]  # CUDA acceleration
```

## API Reference

### QuantumRNG Class

```python
class QuantumRNG:
    def __init__(self, bits: int = 1000, validate: bool = True)
    def generate_bits(self) -> Union[np.ndarray, Tuple[np.ndarray, dict, float]]
    def generate_int(self, min_val: int = 0, max_val: int = 2**32-1) -> int
    def generate_float(self, min_val: float = 0.0, max_val: float = 1.0) -> float
```

### CLI Usage

```bash
# Generate and display random bits
fqrng --bits 1024

# With validation
fqrng --bits 10000 --validate

# Generate specific types
fqrng --output int --range 0 100
fqrng --output float
```

## Advanced Features

### GPU Acceleration
```python
# Automatic GPU detection and acceleration
qrng = QuantumRNG(bits=100000)  # Uses GPU if available
```

### Post-processing Options
- **Von Neumann**: Bias removal extraction
- **Entropy Pool**: Forward-secure reseeding
- **Statistical Validation**: Real-time quality checks

## License

MIT License - see LICENSE file for details.

---

**FQ-RNG**: Bridging quantum-inspired algorithms with practical applications.
```