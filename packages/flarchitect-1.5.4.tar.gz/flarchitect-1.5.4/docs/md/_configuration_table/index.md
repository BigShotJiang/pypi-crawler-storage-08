#  Configuration Table

 Configuration Table covers Core Settings, Optional Settings.

## Sections

- [Core Settings](core-settings.md)
- [Optional Settings](optional-settings.md)
