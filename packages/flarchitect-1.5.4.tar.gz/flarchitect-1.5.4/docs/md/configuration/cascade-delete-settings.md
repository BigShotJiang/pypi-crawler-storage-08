[← Back to Configuration index](index.md)

# Cascade delete settings
See cascade-deletes in the advanced configuration guide for usage examples of
API_ALLOW_CASCADE_DELETE, API_ALLOW_DELETE_RELATED and
API_ALLOW_DELETE_DEPENDENTS.

