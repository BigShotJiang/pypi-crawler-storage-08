[← Back to Installation index](index.md)

# Install Flarchitect
Once the environment is active, install with pip:
```
(.venv) $ pip install flarchitect
```

