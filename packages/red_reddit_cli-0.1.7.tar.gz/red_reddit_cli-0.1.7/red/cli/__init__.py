# Copyright 2025 George Kontridze

"""red CLI."""
