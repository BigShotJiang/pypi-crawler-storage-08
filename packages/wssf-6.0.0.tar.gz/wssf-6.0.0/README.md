# [JIANMOP/wss](https://github.com/JIANMOP/wss) 的构建版本。

## 使用方法：

`pip install wssf` 通过pip安装到虚拟环境中使用。

`uv tool install wssf` 通过uv全局安装使用。（推荐）

## 详细说明：

见仓库 [JIANMOP/wss](https://github.com/JIANMOP/wss)

