"""Exceptions."""


class IdentificationError(Exception):
    """Arbitrary error when trying to identify a user, given a token."""

    ...
