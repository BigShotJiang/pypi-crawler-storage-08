from importlib.metadata import version

__version__ = version("sandock")
__build_hash__ = "846acb535fb065056b695af01efd9938d3baf6fc"
