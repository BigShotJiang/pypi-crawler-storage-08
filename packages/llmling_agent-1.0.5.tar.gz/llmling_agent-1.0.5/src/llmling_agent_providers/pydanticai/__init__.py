"""PydanticAI provider."""

from __future__ import annotations

from llmling_agent_providers.pydanticai.provider import PydanticAIProvider

__all__ = ["PydanticAIProvider"]
