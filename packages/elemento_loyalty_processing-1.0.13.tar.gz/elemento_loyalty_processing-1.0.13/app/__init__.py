"""Project information."""

__author__ = "Anton Taraskin"
__email__ = "hel.nidhoggr@gmail.com"
__version__ = "1.0.11"
