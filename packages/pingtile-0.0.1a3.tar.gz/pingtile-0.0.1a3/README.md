# PINGTile
[![PyPI - Version](https://img.shields.io/pypi/v/pingtile?style=flat-square&label=Latest%20Version%20(PyPi))](https://pypi.org/project/pingtile/)

Utility to tile sonar mosaics and maps.

**UNDER CONSTRUCTION**

Check back soon....
