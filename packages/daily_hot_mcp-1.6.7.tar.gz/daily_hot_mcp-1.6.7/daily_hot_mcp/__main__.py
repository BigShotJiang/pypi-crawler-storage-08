"""Daily Hot MCP 主入口"""

from daily_hot_mcp.server import main

if __name__ == "__main__":
    main() 