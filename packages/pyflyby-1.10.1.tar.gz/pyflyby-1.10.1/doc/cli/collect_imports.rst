collect-imports CLI
===================
.. automodule:: collect-imports
   :members:
