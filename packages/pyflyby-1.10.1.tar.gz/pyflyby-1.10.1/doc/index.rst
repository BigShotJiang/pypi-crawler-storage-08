.. include:: ../README.rst

Table of Contents
=================

.. toctree::
   :maxdepth: -1

   ./api/api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
