_log module
===========
.. automodule:: pyflyby._log
   :members: