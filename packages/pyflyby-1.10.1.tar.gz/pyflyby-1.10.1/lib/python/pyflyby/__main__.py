# pyflyby/__main__.py
# Copyright (C) 2014, 2015 Karl Chen.
# License: MIT http://opensource.org/licenses/MIT



if __name__ == "__main__":
    from pyflyby._py import py_main
    py_main()
