# The following __mandatory_imports__ line makes tidy-imports add the
# mentioned imports to all files.
# You can also include imports other than __future__ imports.
#
# You can write this in any *.py file in your $PYFLYBY_PATH,
# e.g. ~/.pyflyby/mandatory.py.

# __mandatory_imports__ = [
#     'from __future__ import absolute_import, division',
# ]
