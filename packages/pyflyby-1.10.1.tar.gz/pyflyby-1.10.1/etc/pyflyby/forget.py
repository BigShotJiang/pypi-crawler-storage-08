# To remove imports from the set of known imports, write, for example:
#   __forget_imports__ = [
#      'numpy.sin',
#   ]
#
# You can write this in any *.py file in your $PYFLYBY_PATH,
# e.g. ~/.pyflyby/forget.py.
#
# This can be useful if you're inheriting somebody else's import database.
# You can inherit most of the parent database, but exclude certain imports.
