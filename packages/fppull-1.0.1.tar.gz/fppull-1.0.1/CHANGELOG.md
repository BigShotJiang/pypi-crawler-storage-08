# Changelog

All notable changes to **fantasy-public-pull** will be documented here.

## [Unreleased]
- Initial structured CI, hooks, and hygiene setup
