from enum import Enum

class MultimediaProvider(Enum):
    OPENAI = "OPENAI"
    GOOGLE = "GOOGLE"
    ALIBABA_QWEN = "ALIBABA_QWEN"
