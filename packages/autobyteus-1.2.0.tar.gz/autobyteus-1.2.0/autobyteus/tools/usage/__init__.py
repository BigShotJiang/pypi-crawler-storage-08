# file: autobyteus/autobyteus/tools/usage/__init__.py
"""
This package contains the framework for generating provider-specific
tool usage information (schemas and examples) and for parsing
tool usage from LLM responses.
"""
