"""OpenBB Federal Reserve Provider Assets."""
