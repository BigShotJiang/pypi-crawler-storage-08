#exonware/xwsystem/tests/core/performance/__init__.py
"""
Performance Core Tests Package

Tests for XSystem performance management including performance monitoring,
optimization, and resource management.
"""
