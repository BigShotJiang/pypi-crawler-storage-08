class PaymentException(Exception):
    pass


class ParseException(Exception):
    pass
