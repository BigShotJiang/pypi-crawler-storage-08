"""
API views for the enterprise app.
"""
