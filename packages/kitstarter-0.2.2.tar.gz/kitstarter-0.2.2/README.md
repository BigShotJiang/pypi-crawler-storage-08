# KitStarter

kitstarter is a Qt -based program you can use to "sketch in" a drumkit SFZ file.

