class VectorDbConstants:
    VECTOR_DB_NAME = "collection_name"
    EMBEDDING_DIMENSION = "embedding_dimension"
    DEFAULT_VECTOR_DB_NAME = "unstract"
    DEFAULT_EMBEDDING_SIZE = 2
    WAIT_TIME = "wait_time"
