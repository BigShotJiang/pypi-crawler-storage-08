# Unstract Azure OpenAI LLM Adapter
