# Unstract VertexAI LLM Adapter
Vertex AI is a machine learning (ML) platform that lets you train and deploy ML models and AI applications. Vertex AI combines data engineering, data science, and ML engineering workflows, enabling team collaboration using a common toolset.
