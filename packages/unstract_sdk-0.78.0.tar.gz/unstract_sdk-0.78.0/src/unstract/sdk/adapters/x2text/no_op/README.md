# Unstract NoOp x2text adapter for load testing

A x2text adapter that does not perform any operation. Waits for the configured time before returning a response. This can be useful to perform tests on the system
