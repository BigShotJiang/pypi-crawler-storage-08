from unstract.sdk.adapters.x2text.no_op.src.no_op_x2text import NoOpX2Text

metadata = {
    "name": NoOpX2Text.__name__,
    "version": "1.0.0",
    "adapter": NoOpX2Text,
    "description": "NoOpX2Text",
    "is_active": True,
}
