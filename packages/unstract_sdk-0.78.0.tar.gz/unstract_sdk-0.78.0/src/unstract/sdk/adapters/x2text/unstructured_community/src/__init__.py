from .unstructured_community import UnstructuredCommunity

metadata = {
    "name": UnstructuredCommunity.__name__,
    "version": "1.0.0",
    "adapter": UnstructuredCommunity,
    "description": "UnstructuredIO X2Text adapter",
    "is_active": True,
}
