# Unstract NoOp Embedding adapter for load testing

An embedding adapter that does not perform any operation. Waits for the configured time before returning a response. This can be useful to perform tests on the system
