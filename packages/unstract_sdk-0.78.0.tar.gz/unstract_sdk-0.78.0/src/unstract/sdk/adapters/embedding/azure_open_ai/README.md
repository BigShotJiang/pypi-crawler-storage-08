# Unstract Azure OpenAI Embedding Adapter

This package consists of the functionalities required to adapt with Azure OpenAI Embedding 
Version supported
