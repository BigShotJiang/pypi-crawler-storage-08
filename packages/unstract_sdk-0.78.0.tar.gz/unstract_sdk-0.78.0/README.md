<div align="center">
<img src="https://raw.githubusercontent.com/Zipstack/unstract-sdk/main/docs/assets/unstract_u_logo.png" style="height: 60px">

# Unstract

## No-code LLM Platform to launch APIs and ETL Pipelines to structure unstructured documents

</div>

# Unstract SDK

The `unstract-sdk` package helps with developing tools that are meant to be run on the Unstract platform. This includes
modules to help with tool development and execution, caching, making calls to LLMs / vectorDBs / embeddings .etc.
They also contain helper methods/classes to aid with other tasks such as indexing and auditing the LLM calls.

## Installation

- The below libraries need to be installed to run the SDK
  - Linux

    ```bash
    sudo apt install build-essential pkg-config libmagic-dev
    ```

  - Mac

    ```bash
    brew install pkg-config libmagic pandoc tesseract-ocr
    ```

## Tools

### Create a scaffolding for a new tool

Example

```bash
unstract-tool-gen --command NEW --tool-name <name of tool> \
 --location ~/path_to_repository/unstract-tools/ --overwrite false
```

Supported commands:

- `NEW` - Create a new tool

### Environment variables required for all Tools

| Variable                   | Description                                                           |
| -------------------------- | --------------------------------------------------------------------- |
| `PLATFORM_SERVICE_HOST`    | The host in which the platform service is running                     |
| `PLATFORM_SERVICE_PORT`    | The port in which the service is listening                            |
| `PLATFORM_SERVICE_API_KEY` | The API key for the platform                                          |
| `TOOL_DATA_DIR`            | The directory in the filesystem which has contents for tool execution |

### Llama Index support

Unstract SDK 0.3.2 uses the following version of Llama
Index Version **0.9.28** as on January 14th, 2024

### Developing with the SDK

Ensure that you have all the required dependencies and pre-commit hooks installed

```shell
uv sync
pre-commit install
```

Once the changes have been made, it can be tested with [Unstract](https://github.com/Zipstack/unstract) through the following means.

#### With UV

Specify the SDK as a dependency to a project using a tool like `uv` by adding the following to your `pyproject.toml`

```toml
dependencies = [
    "unstract-sdk"
]

[dependency-groups]
dev = [
"unstract-sdk"
]

[tool.uv.sources]
unstract-sdk = { path = "${UNSTRACT_SDK_PATH", editable = true  }
```

#### With pip

- If the project is using `pip` it might be possible to add it as a dependency in `requirements.txt`

```shell
-e /path/to/unstract-sdk
```

NOTE: Building locally might require the below section to be replaced in the `unstract-sdk`'s build system configuration

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
```

- Another option is to provide a git URL in `requirements.txt`, this can come in handy while building tool
docker images. Don't forget to run `apt install git` within the `Dockerfile` for this

```toml
[tool.uv.sources]
unstract-sdk = { git = "git+https://github.com/Zipstack/unstract-sdk@feature-branch" }
```

- Or try installing a [local PyPI server](https://pypi.org/project/pypiserver/) and upload / download your package from this server

#### Additonal dependencies for tool

Tools may need to be backed up by a file storage. `unstract.sdk.file_storage` contains the required interfaces for the
same. `fsspec` is being used underneath to implement these interfaces. Hence, one can choose to use a file system
supported by fsspec for this. However, the required dependencies need to be added in the tool dependency manager.
Eg. If the tool is using Minio as the underlying file storage, then `s3fs` can be added to support it.
Similarly, for Google Cloud Storage, `gcsfs` needs to be added.
The following versions are tested in the SDK using unit test cases for the above package.

```toml
  gcsfs==2024.10.0
  s3fs==2024.10.0
```

### Documentation generation

Follow [this README.md](https://github.com/Zipstack/unstract-sdk/blob/main/docs/README.md) for generating documentation.
