# Contentctl App Readme

This README file was automatically created by contentctl init. 
Please fill it with meaningful information that describes your app.  

Note that this file can contain Markdown and will be richly rendered in GitHub or most other Version Control Systems.


Note: This readme file is actually DIFFERENT from the one that will be packaged as part of your App.
That file is located at app_template/README.md.