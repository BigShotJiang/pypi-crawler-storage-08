from contentctl.objects.base_test_result import BaseTestResult


class ManualTestResult(BaseTestResult):
    """
    A manual test result
    """

    pass
