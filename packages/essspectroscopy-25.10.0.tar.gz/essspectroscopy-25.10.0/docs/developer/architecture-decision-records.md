# Architecture Decision Records

```{toctree}
---
maxdepth: 1
glob: true
---

adr/*
```