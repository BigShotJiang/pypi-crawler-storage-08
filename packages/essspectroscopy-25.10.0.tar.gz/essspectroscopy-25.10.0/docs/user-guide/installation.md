# Installation

To install ESSspectroscopy and all of its dependencies, use

`````{tab-set}
````{tab-item} pip
```sh
pip install essspectroscopy
```
````
````{tab-item} conda
```sh
conda install -c conda-forge essspectroscopy
```
````
`````
