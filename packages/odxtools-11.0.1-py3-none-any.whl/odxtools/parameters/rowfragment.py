# SPDX-License-Identifier: MIT
from enum import Enum


class RowFragment(Enum):
    KEY = "KEY"
    STRUCT = "STRUCT"
