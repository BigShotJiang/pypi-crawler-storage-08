# SPDX-License-Identifier: MIT
"""Subpackage containing odxtools' command line interface related code
"""
