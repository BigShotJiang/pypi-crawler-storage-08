This module depends on the
[python-jose](https://pypi.org/project/python-jose/) library, not to be
confused with `jose` which is also available on PyPI.
