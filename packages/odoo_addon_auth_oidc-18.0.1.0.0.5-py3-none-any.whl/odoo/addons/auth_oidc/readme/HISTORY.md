## 18.0.1.0.0 2024-10-09

- Odoo 18 migration

## 17.0.1.0.0 2024-03-20

- Odoo 17 migration

## 16.0.1.1.0 2024-02-28

- Forward port OpenID Connect fixes from 15.0 to 16.0

## 16.0.1.0.2 2023-11-16

- Readme link updates

## 16.0.1.0.1 2023-10-09

- Add AzureAD code flow provider

## 16.0.1.0.0 2023-01-27

- Odoo 16 migration

## 15.0.1.0.0 2023-01-06

- Odoo 15 migration

## 14.0.1.0.0 2021-12-10

- Odoo 14 migration

## 13.0.1.0.0 2020-04-10

- Odoo 13 migration, add authorization code flow.

## 10.0.1.0.0 2018-10-05

- Initial implementation
