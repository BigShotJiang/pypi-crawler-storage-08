- When going to the login screen, check for a existing token and do a
  direct login without the clicking on the SSO link
- When doing a logout an extra option to also logout at the SSO
  provider.
