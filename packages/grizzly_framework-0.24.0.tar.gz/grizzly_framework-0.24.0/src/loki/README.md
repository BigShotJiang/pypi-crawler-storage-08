Loki
====

Loki is a simple fuzzing library that provides basic data mutation capabilities. Loki can be helpful when creating basic fuzzers or proof-of-concepts by providing functionality that has been successfully used to find bugs in the past. It is by no means a complete fuzzing or data manipulation solution. There are other faster, more intelligent solutions out there.
