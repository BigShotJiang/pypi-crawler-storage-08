#!/usr/bin/env python3
"""
mem8 CLI package - Modular command-line interface.
"""

from .main import typer_app

__all__ = ["typer_app"]
