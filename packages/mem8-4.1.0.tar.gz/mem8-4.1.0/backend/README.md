# mem8 Backend API

FastAPI backend service for mem8 system.