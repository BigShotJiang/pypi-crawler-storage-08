
class UnknownError(Exception):
    pass

class ToManyRequestsOrSyntaxError(Exception):
    pass

class ConnectionError(Exception):
    pass