"""Core functionality for prompt-contracts."""
