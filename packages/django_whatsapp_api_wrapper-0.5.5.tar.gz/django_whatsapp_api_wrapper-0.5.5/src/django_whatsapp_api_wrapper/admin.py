from django.contrib import admin
from .models import WhatsAppCloudApiBusiness, WhatsAppEmbeddedSignUp, MetaApp
# Register your models here.

admin.site.register(WhatsAppCloudApiBusiness)
admin.site.register(WhatsAppEmbeddedSignUp)
admin.site.register(MetaApp)


    

    
