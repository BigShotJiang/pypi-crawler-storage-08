from django.apps import AppConfig


class DjangoWhatsappApiWrapperConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_whatsapp_api_wrapper'
