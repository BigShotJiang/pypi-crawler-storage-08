
## CATO-CLI - query.devices:
[Click here](https://api.catonetworks.com/documentation/#query-query.devices) for documentation on this operation.

### Usage for query.devices:

```bash
catocli query devices -h

catocli query devices <json>

catocli query devices "$(cat < query.devices.json)"

#### Operation Arguments for query.devices ####

`accountId` [ID] - (required) N/A    
