
## CATO-CLI - mutation.xdr:
[Click here](https://api.catonetworks.com/documentation/#mutation-xdr) for documentation on this operation.

### Usage for mutation.xdr:

`catocli mutation xdr -h`
