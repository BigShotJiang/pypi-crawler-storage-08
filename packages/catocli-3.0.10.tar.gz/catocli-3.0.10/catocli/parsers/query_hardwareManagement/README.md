
## CATO-CLI - query.hardwareManagement:
[Click here](https://api.catonetworks.com/documentation/#query-query.hardwareManagement) for documentation on this operation.

### Usage for query.hardwareManagement:

```bash
catocli query hardwareManagement -h

catocli query hardwareManagement <json>

catocli query hardwareManagement "$(cat < query.hardwareManagement.json)"

#### Operation Arguments for query.hardwareManagement ####

`accountId` [ID] - (required) N/A    
