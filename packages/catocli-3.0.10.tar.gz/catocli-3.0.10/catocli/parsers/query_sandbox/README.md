
## CATO-CLI - query.sandbox:
[Click here](https://api.catonetworks.com/documentation/#query-query.sandbox) for documentation on this operation.

### Usage for query.sandbox:

```bash
catocli query sandbox -h

catocli query sandbox <json>

catocli query sandbox "$(cat < query.sandbox.json)"

#### Operation Arguments for query.sandbox ####

`accountId` [ID] - (required) N/A    
