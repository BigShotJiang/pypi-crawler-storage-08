
## CATO-CLI - mutation.sandbox:
[Click here](https://api.catonetworks.com/documentation/#mutation-sandbox) for documentation on this operation.

### Usage for mutation.sandbox:

`catocli mutation sandbox -h`
