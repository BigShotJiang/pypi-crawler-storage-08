
## CATO-CLI - query.hardware:
[Click here](https://api.catonetworks.com/documentation/#query-query.hardware) for documentation on this operation.

### Usage for query.hardware:

```bash
catocli query hardware -h

catocli query hardware <json>

catocli query hardware "$(cat < query.hardware.json)"

#### Operation Arguments for query.hardware ####

`accountId` [ID] - (required) N/A    
