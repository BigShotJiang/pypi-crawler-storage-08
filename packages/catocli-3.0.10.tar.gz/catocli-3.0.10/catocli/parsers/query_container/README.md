
## CATO-CLI - query.container:
[Click here](https://api.catonetworks.com/documentation/#query-query.container) for documentation on this operation.

### Usage for query.container:

```bash
catocli query container -h

catocli query container <json>

catocli query container "$(cat < query.container.json)"

#### Operation Arguments for query.container ####

`accountId` [ID] - (required) N/A    
