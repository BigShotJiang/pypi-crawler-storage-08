
## CATO-CLI - query.enterpriseDirectory:
[Click here](https://api.catonetworks.com/documentation/#query-query.enterpriseDirectory) for documentation on this operation.

### Usage for query.enterpriseDirectory:

```bash
catocli query enterpriseDirectory -h

catocli query enterpriseDirectory <json>

catocli query enterpriseDirectory "$(cat < query.enterpriseDirectory.json)"

#### Operation Arguments for query.enterpriseDirectory ####

`accountId` [ID] - (required) N/A    
