
## CATO-CLI - query.popLocations:
[Click here](https://api.catonetworks.com/documentation/#query-query.popLocations) for documentation on this operation.

### Usage for query.popLocations:

```bash
catocli query popLocations -h

catocli query popLocations <json>

catocli query popLocations "$(cat < query.popLocations.json)"

#### Operation Arguments for query.popLocations ####

`accountId` [ID] - (required) N/A    
