
## CATO-CLI - query.policy.appTenantRestriction:
[Click here](https://api.catonetworks.com/documentation/#query-appTenantRestriction) for documentation on this operation.

### Usage for query.policy.appTenantRestriction:

`catocli query policy appTenantRestriction -h`
