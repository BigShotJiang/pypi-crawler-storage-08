
## CATO-CLI - query.catalogs:
[Click here](https://api.catonetworks.com/documentation/#query-query.catalogs) for documentation on this operation.

### Usage for query.catalogs:

```bash
catocli query catalogs -h

catocli query catalogs <json>

catocli query catalogs "$(cat < query.catalogs.json)"

#### Operation Arguments for query.catalogs ####

`accountId` [ID] - (required) N/A    
