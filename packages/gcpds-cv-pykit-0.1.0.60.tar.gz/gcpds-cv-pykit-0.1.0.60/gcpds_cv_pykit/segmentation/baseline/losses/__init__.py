from .CrossEntropy import CrossEntropyLoss
from .DICE import DICELoss
from .Focal import FocalLoss
from .Tversky import TverskyLoss