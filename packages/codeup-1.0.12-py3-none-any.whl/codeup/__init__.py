"""CodeUp - Intelligent git workflow automation tool."""

__version__ = "1.0.10"

from .main import main

__all__ = ["main"]
