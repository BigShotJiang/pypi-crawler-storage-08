- When print check automatically in the payment validation process, the
  wizard remains opened.
