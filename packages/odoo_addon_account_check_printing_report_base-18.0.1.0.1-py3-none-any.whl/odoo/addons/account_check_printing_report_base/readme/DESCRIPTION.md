This module provides the basic framework for check printing, and a
sample layout.
