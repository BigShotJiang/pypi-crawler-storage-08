- Jordi Ballester Alomar \<<jordi.ballester@forgeflow.com>\>

- Lois Rilo Antelo \<<lois.rilo@forgeflow.com>\>

- Sandip Mangukiya \<<smangukiya@ursainfosystems.com>\>

- Manuel Marquez \<<mmarquez@iterativo.do>\>

- [Tecnativa](https://www.tecnativa.com):

  > - Luis M. Ontalba
  > - Carlos Roca
