- Go to 'Invoicing / Vendors / Payments'. Select one of the payments
  with type 'Check' and print the check.
- For automatic check printing when validating payment, mark the field
  in the journal associated.
