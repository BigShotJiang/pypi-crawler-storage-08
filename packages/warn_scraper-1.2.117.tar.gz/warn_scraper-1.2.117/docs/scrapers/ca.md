---
orphan: true
---

# California

California provides historical data as PDFs and data for the current fiscal year as
an Excel file.

- [Home page](https://edd.ca.gov/Jobs_and_Training/Layoff_Services_WARN.htm)
