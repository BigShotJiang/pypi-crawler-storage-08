from .job_center.site import Site as JobCenterSite

__all__ = ("JobCenterSite",)
