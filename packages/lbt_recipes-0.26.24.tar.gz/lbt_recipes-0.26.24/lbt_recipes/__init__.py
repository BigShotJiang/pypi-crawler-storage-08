"""Collection of static Python recipes that ship with Ladybug Tools plugins."""
