def f():
    print("test")