from .bec_server_utils.launch import main
