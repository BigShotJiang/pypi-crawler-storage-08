# pydoc-markdown-havsalt

Plugin for `pydoc-markdown`

## Rational

I simply needed to extend some functionality of `pydoc-markdown`.
Thanks to `pydoc-markdown`'s brilliant interfaces
(and a lot of digging around in the docs and source code),
I could in an easy way add what I needed.

## Features

See [DOCS.md](./DOCS.md) for the full documentation.

- Function signature formatation like the one `ruff` uses
