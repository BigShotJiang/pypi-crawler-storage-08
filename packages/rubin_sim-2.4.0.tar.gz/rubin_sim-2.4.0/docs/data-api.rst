.. py:currentmodule:: rubin_sim.data

.. _data-api:

========
Data API
========

.. automodule:: rubin_sim.data
    :imported-members:
    :members:
    :show-inheritance: