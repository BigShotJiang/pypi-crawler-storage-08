.. py:currentmodule:: rubin_sim.maf

.. _maf-api-stackers:

========
Stackers
========

.. automodule:: rubin_sim.maf.stackers
    :imported-members:
    :members:
    :show-inheritance:
