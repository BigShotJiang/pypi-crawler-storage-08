.. py:currentmodule:: rubin_sim.maf

.. _maf-api-metrics:

=======
Metrics
=======

.. automodule:: rubin_sim.maf.metrics
    :imported-members:
    :members:
    :show-inheritance:
