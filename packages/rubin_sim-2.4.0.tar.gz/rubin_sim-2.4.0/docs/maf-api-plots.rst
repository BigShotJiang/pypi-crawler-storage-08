.. py:currentmodule:: rubin_sim.maf

.. _maf-api-plots:

=======
Plots
=======

.. automodule:: rubin_sim.maf.plots
    :imported-members:
    :members:
    :show-inheritance:
