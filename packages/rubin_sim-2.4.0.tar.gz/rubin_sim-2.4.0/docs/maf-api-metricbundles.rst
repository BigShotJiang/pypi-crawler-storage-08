.. py:currentmodule:: rubin_sim.maf

.. _maf-api-metricbundles:

==============
Metric Bundles
==============

.. automodule:: rubin_sim.maf.metric_bundles
    :imported-members:
    :members:
    :show-inheritance:
