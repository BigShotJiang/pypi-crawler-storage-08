"""tinyagent.tools.builtin package exports."""

from .web_search import web_search

__all__ = [
    "web_search",
]
