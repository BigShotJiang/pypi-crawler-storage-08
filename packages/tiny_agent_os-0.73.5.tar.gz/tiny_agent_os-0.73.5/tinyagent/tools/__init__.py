"""tinyagent.tools package exports."""

from .builtin import web_search

__all__ = [
    "web_search",
]
