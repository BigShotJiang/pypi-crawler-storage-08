import enum
from collections.abc import ValuesView
from typing import get_args, get_type_hints

import typer
from rich.console import Console
from rich.table import Table

from libresvip.core.config import save_settings, settings
from libresvip.extension.base import SVSConverter
from libresvip.extension.manager import plugin_manager
from libresvip.model.base import BaseComplexModel
from libresvip.utils.translation import gettext_lazy as _

app = typer.Typer()


@app.command()
def toggle(identifier: str) -> None:
    if identifier in plugin_manager.plugins.get("svs", {}):
        settings.disabled_plugins.append(identifier)
        save_settings()
        typer.secho(_("The plugin is successfully disabled."), fg="green")
    elif identifier in settings.disabled_plugins:
        settings.disabled_plugins.remove(identifier)
        save_settings()
        typer.secho(_("The plugin is successfully enabled."), fg="green")
    else:
        typer.secho(_("Unable to find the plugin."), fg="yellow")


@app.command("list")
def list_plugins() -> None:
    print_plugin_summary(plugin_manager.plugins.get("svs", {}).values())


@app.command()
def detail(plugin_name: str) -> None:
    if plugin_name in plugin_manager.plugins.get("svs", {}):
        print_plugin_details(plugin_manager.plugins.get("svs", {})[plugin_name])
    else:
        typer.echo(_("Cannot find plugin ") + f"{plugin_name}!", err=True)


def print_plugin_summary(
    plugins: ValuesView[SVSConverter],
) -> None:
    console = Console(color_system="256")
    if not plugins:
        console.print(_("No plugins are currently installed."))
    margin = " " * 2
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column(_("No."), justify="left", style="cyan")
    table.add_column(_("Name"), justify="left", style="cyan")
    table.add_column(_("Version"), justify="left", style="cyan")
    table.add_column(_("Author"), justify="left", style="cyan")
    table.add_column(_("Identifier"), justify="left", style="cyan")
    table.add_column(_("Applicable file format"), justify="left", style="cyan")
    for num, plugin in enumerate(plugins, start=1):
        if plugin.info is None:
            continue
        format_desc = f"{_(plugin.info.file_format)} (*.{plugin.info.suffix})"
        table.add_row(
            f"[{num}] ",
            plugin.info.name + margin,
            (plugin.version or "N/A") + margin,  # type: ignore[attr-defined]
            _(plugin.info.author) + margin,
            plugin.info.suffix + margin,
            format_desc + margin,
        )
    console.print(table)


def print_plugin_details(plugin: SVSConverter) -> None:
    if plugin.info is None:
        return
    typer.echo()
    typer.echo("--------------------------------------------------\n")
    typer.echo(
        f"{{}}{plugin.info.name}\t{{}}{plugin.version!s}\t{{}}{_(plugin.info.author)}".format(  # type: ignore[attr-defined]
            _("Plugin: "),
            _("Version: "),
            _("Author: "),
        )
    )
    if plugin.info.website:
        typer.echo("\n" + _("Website: ") + plugin.info.website)
    format_desc = f"{_(plugin.info.file_format)} (*.{plugin.info.suffix})"
    typer.echo("\n" + f"{_('This plugin is applicable to')} {format_desc}.")
    typer.echo(
        _(
            "If you want to use this plugin, please specify '-i {}' (input) or '-o {}' (output) when converting."
        ).format(plugin.info.suffix.lower(), plugin.info.suffix.lower())
    )
    if plugin.info.description:
        typer.echo(f"\n{_('Description: ')}\n{_(plugin.info.description)}")
    op_arr = [_("input"), _("output")]
    options_arr = [
        plugin.input_option_cls,
        plugin.output_option_cls,
    ]
    for op, options in zip(op_arr, options_arr):
        if options is None:
            continue
        typer.echo(_("This plugin supports the following {} conversion options:").format(op))
        for field_info in options.model_fields.values():
            if issubclass(field_info.annotation, bool | int | float | str | enum.Enum):
                typer.echo(
                    f"\n  {_(field_info.title)} = {field_info.annotation.__name__}    {_(field_info.description)}"
                )
                if field_info.default is not None:
                    typer.echo(f"\t{{}}{field_info.default}".format(_("Default: ")))
                if issubclass(field_info.annotation, enum.Enum):
                    type_hints = get_type_hints(field_info.annotation, include_extras=True)
                    annotations = None
                    if "_value_" in type_hints:
                        value_args = get_args(type_hints["_value_"])
                        if len(value_args) >= 2:
                            model = value_args[1]
                            if hasattr(model, "model_fields"):
                                annotations = model.model_fields
                    if annotations is None:
                        continue
                    typer.echo("  " + _("Available values:"))
                    for enum_item in field_info.annotation:
                        if enum_item.name in annotations:
                            enum_field = annotations[enum_item.name]
                            typer.echo(f"\t{enum_item.value}\t=>\t{_(enum_field.title)}")
            elif issubclass(field_info.annotation, BaseComplexModel):
                typer.echo(
                    f"\n  {_(field_info.title)} = {field_info.annotation.__name__}    {_(field_info.description)}"
                )
                typer.echo("  " + _("Available fields:"))
                for field in field_info.annotation.model_fields.values():
                    if hasattr(field.annotation, "__name__"):
                        typer.echo(f"    {field.title} = {field.annotation.__name__}")
                    else:
                        typer.echo(f"    {field.title} = {get_args(field.annotation)}")
                typer.echo("\t" + _("Default: ") + field_info.annotation.default_repr())
    typer.echo("\n--------------------------------------------------\n")
