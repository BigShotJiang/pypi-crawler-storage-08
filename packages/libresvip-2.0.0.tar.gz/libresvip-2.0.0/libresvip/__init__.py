import os

__version__ = "2.0.0"
os.environ.setdefault("LOGURU_AUTOINIT", "false")
