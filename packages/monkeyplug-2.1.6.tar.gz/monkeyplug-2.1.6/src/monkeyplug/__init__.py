"""monkeyplug is a little script to censor profanity in audio files."""

__version__ = "2.1.6"
__author__ = "Seth Grover <mero.mero.guero@gmail.com>"
__all__ = []

from monkeyplug.monkeyplug import *
