import os
import sys

# for dirpath in os.walk(os.path.dirname(os.path.abspath(__file__))):
#     if not dirpath[0].endswith('__pycache__'):
#         sys.path.append(dirpath[0])

from adparser.Parser import Parser

