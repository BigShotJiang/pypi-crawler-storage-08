# We can access HTMLScaner from this package

from adparser.AST.Scaners.HTMLScaner import HTMLScaner