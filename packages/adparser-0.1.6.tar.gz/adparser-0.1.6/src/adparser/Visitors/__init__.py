# from this package we can access all implemented visitors

from adparser.Visitors.Selectors import TextLineSelector, LinkSelector, \
    ParagraphSelector, HeadingSelector, ListSelector, \
    SourceSelector, TableSelector, AudioSelector, VideoSelector, \
    ImageSelector
from adparser.Visitors.Selectors import Selector
