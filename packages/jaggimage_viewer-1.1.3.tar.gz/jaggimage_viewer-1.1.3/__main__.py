# You can run the program with:
# $ python3 -m jaggimage_viewer [files]

import sys, jaggimage_viewer
if __name__ == '__main__':
	sys.exit(jaggimage_viewer.main())
