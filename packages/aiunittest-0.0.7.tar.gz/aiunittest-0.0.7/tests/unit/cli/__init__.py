"""Tests for CLI components."""
