"""Error messages."""

ERROR_MISSING_ENGINE = "Plover engine not provided to web socket server"
ERROR_SERVER_RUNNING: str = "A server is already running"
ERROR_NO_SERVER: str = "A server is not currently running"
