# Commodity Extension for OpenBB Platform

This extension provides a set of commands for commodity-related data.

## Installation

To install the extension, run the following command in this folder:

```bash
pip install openbb-commodity
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
