from graphs_submod.agent import graph  # noqa
from utils.greeter import greet

greet()
