"""Shared utilities package."""

from .utils import get_dummy_message

__all__ = ["get_dummy_message"]
