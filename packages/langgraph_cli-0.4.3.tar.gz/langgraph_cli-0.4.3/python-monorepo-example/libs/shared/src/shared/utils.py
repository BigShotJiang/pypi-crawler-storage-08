"""Shared utility functions."""


def get_dummy_message() -> str:
    """Get a dummy message for testing."""
    return "Hello from shared library!"
