"""Common helper functions."""


def get_common_prefix() -> str:
    """Get a common prefix for messages."""
    return "[COMMON]"
