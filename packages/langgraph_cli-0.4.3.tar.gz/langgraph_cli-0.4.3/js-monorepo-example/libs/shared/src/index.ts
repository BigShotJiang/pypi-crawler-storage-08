/**
 * Simple utility functions for monorepo testing
 */
export function getGreeting(): string {
  return "Hello from shared library!";
}
