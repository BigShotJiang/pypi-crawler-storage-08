__all__ = ['Client',  "Callback", "consts"]

from spankbang_api.spankbang_api import Client, Callback, Video
from spankbang_api.modules import consts