# ZSync Tech Studio SDK

SDK oficial da ZSync Tech para integração com o ZSync Tech Studio, uma plataforma de automação de processos. Este SDK permite que você desenvolva robôs de automação que se integram perfeitamente com o ecossistema ZSync Tech.

### Documentação em desenvolvimento