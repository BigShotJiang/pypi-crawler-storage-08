fn main() {
    arrowspace::init();
}
