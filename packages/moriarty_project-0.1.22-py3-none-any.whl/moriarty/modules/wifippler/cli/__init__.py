"""
Módulo CLI do WiFiPPLER.

Fornece a interface de linha de comando para interagir com as funcionalidades do WiFiPPLER.
"""

# Este arquivo é deixado intencionalmente vazio para marcar o diretório como um pacote Python.
# A implementação da CLI está em commands.py
