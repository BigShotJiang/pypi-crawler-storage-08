from .colors import ContinuousColorMap
from .colors import NamedColorMaps
