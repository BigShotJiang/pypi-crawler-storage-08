def mm_to_inch(x):
    return x * 0.0393701


def to_one_column(width):
    return width * 89 / 183  # Nature two:one column ratio
