# Stylia: decent scientific plot styles

This repository contains predefined [MatPlotLib](https://matplotlib.org/) styles to be used by all projects within the [Ersilia Open Source Initiative](https://ersilia.io).

Read Stylia's documentation in the [Ersilia Book](https://ersilia.gitbook.io/ersilia-book/styles/scientific-figures-with-stylia).

## About us
Learn more about the Ersilia Open Source Initiative [here](https://ersilia.io)!
