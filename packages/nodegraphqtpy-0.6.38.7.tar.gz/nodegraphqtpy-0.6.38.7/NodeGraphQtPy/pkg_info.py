#!/usr/bin/python
# -*- coding: utf-8 -*-
__version__ = '0.6.38'
__status__ = 'Work in Progress'
__license__ = 'MIT'

__author__ = 'Johnny Chan'

__module_name__ = 'NodeGraphQtPy'
__url__ = 'https://github.com/jchanvfx/NodeGraphQtPy'
