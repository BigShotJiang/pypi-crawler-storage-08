:hide-rtoc:

SubGraph
########

.. autosummary::
    NodeGraphQt.SubGraph

.. autoclass:: NodeGraphQt.SubGraph
    :members:
    :exclude-members: staticMetaObject, delete_node, delete_nodes, is_root, sub_graphs, widget
