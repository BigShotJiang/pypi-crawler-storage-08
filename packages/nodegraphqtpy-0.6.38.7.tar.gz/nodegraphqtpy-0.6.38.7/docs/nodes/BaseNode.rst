:hide-rtoc:

BaseNode
########

.. autoclass:: NodeGraphQt.BaseNode
    :members:
    :exclude-members: NODE_NAME, update_model, set_layout_direction, set_property
    :member-order: bysource

BaseNode (Circle)
#################

.. autoclass:: NodeGraphQt.BaseNodeCircle
    :members:
    :exclude-members: NODE_NAME, update_model, set_layout_direction
    :member-order: bysource