:hide-rtoc:

BackdropNode
############

.. autoclass:: NodeGraphQt.BackdropNode
    :members:
    :member-order: bysource
    :exclude-members: NODE_NAME
