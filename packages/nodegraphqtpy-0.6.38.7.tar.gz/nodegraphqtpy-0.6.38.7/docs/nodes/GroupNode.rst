:hide-rtoc:

GroupNode
#########

.. autoclass:: NodeGraphQt.GroupNode
    :members:
    :exclude-members: NODE_NAME, add_input, add_output, delete_input, delete_output
    :member-order: bysource