:hide-rtoc:

NodeObject
##########

.. autoclass:: NodeGraphQt.NodeObject
    :members:
    :member-order: bysource
    :special-members: __identifier__
