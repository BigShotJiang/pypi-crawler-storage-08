Constants
#########

.. automodule:: NodeGraphQt.constants
    :members:
    :member-order: bysource
