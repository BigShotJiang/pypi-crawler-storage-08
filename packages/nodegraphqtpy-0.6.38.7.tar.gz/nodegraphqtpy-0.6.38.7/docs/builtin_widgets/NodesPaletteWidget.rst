:hide-rtoc:

NodesPaletteWidget
##################

.. autosummary::
    NodeGraphQt.NodesPaletteWidget

.. autoclass:: NodeGraphQt.NodesPaletteWidget
    :members:
    :exclude-members: mimeData, staticMetaObject
