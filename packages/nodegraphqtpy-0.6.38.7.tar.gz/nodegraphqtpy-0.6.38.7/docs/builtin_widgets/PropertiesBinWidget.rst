:hide-rtoc:

PropertiesBinWidget
###################

.. autosummary::
    NodeGraphQt.PropertiesBinWidget

.. autoclass:: NodeGraphQt.PropertiesBinWidget
    :members:
    :exclude-members: staticMetaObject
