:hide-rtoc:

NodesTreeWidget
###############

.. autosummary::
    NodeGraphQt.NodesTreeWidget

.. autoclass:: NodeGraphQt.NodesTreeWidget
    :members:
    :exclude-members: mimeData, staticMetaObject
