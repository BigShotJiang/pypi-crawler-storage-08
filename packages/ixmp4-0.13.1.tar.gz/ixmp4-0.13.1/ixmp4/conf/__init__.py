from dotenv import load_dotenv

from ixmp4.conf.settingsmodel import Settings

load_dotenv()
settings: Settings = Settings()
