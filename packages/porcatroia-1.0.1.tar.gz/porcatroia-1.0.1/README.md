# porcatroia 🤬

Se ti si fanculizza il codice, questo programma sclera per te

```python
from porcatroia import porcatroia

@porcatroia
def test():
    1 / 0
