#########################
Account De Skr04 I Module
#########################

Chart of Account "SKR04" for tryton

- german account char srkr04 
- Enhanced version of package mds-account_de-skr04 bei mds GmbH, Berlin


.. to remove, see https://www.tryton.org/develop/guidelines/documentation#index.rst

.. toctree::
   :maxdepth: 2

   setup
   - can be installed in parallel to the mds-account_de-skr04 module
   usage
   configuration
   design
   reference
   releases
