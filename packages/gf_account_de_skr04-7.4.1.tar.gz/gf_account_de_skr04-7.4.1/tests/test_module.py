
from trytond.tests.test_tryton import ModuleTestCase


class AccountDeSkr04ITestCase(ModuleTestCase):
    "Test Account De Skr04 I module"
    module = 'account_de_skr04_I'


del ModuleTestCase
