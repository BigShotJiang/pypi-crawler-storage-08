"""
icclim's internal core module.

The structure of this module may change without warnings.
Avoid importing from this module directly.
"""
