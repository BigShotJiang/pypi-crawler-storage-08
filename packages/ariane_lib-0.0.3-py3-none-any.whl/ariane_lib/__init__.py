# -*- coding: utf-8 -*-

"""
A library to read Ariane Line Survey Software files
"""

__version__ = "0.0.3"
