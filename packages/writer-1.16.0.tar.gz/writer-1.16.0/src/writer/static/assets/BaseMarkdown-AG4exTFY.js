import{aS as f}from"./index-C_PMPwv4.js";export{f as default};
