import time


def test_sles_wait_30_seconds(host):
    time.sleep(30)
