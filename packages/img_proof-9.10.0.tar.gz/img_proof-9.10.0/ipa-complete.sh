#! /bin/sh -
_IPA_COMPLETE=source img-proof
