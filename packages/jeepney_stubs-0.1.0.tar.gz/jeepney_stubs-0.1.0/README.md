# jeepney-stubs

A collection of type stubs for [jeepney](https://gitlab.com/takluyver/jeepney)
