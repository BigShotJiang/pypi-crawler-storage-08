"""Shared helpers for metadata resources."""

from .format import read_format_metadata

__all__ = ["read_format_metadata"]
