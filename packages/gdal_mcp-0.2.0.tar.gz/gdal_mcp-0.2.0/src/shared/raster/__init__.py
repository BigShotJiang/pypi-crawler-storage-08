from .info import extract_raster_info
from .stats import stats

info = extract_raster_info

__all__ = ["info", "stats", "extract_raster_info"]
