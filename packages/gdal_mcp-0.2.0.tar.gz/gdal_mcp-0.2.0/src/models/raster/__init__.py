"""Raster models."""

from __future__ import annotations
