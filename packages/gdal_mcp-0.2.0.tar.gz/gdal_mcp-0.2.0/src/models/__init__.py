"""Models package for structured I/O."""

from __future__ import annotations
