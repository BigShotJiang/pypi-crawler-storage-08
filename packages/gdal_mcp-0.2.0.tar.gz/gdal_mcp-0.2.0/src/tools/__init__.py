from __future__ import annotations

"""Tool package placeholder.

Python-native tool modules (e.g., raster.info/convert/reproject, vector.info/reproject)
will register their @mcp.tool functions upon import when implemented.
"""

# Intentionally avoid eager imports until implementations are added.
