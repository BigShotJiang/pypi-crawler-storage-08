from .skycamera import Skycamera  # Import the client class

__all__ = ["Skycamera"]  # Make the client class available