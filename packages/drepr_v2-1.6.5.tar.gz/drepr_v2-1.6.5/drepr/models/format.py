from enum import Enum


class OutputFormat(str, Enum):
    TTL = "ttl"
