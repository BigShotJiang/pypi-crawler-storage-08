from enum import Enum


class CarDirection(str, Enum):
    A = "A"
    B = "B"
