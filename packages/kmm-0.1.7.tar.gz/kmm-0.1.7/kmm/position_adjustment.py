from enum import IntEnum


class PositionAdjustment(IntEnum):
    WIRE_CAMERA = 8
