#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
The vectorizer.
"""

from .polynomial import *