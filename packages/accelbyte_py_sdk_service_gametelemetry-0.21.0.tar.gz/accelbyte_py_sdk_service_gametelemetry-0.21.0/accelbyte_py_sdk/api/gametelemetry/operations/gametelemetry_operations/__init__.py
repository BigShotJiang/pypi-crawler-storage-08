# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the Analytics Game Telemetry."""

__version__ = "1.31.0"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .protected_get_playtime__9a0e17 import (
    ProtectedGetPlaytimeGameTelemetryV1ProtectedSteamIdsSteamIdPlaytimeGet,
)
from .protected_save_events_g_832bbb import (
    ProtectedSaveEventsGameTelemetryV1ProtectedEventsPost,
)
from .protected_update_playti_4b5b85 import (
    ProtectedUpdatePlaytimeGameTelemetryV1ProtectedSteamIdsSteamIdPlaytimePlaytimePut,
)
