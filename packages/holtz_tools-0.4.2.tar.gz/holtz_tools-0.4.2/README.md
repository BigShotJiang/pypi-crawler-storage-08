
The holtztools package provides some basic convenience tools that wrap
lower level Python routines:

- plots : routines for making and labeling plots with single line
commands. Also includes routines for plot interaction
- html : routines for making HTML files/tables, in particular,
for grids of plots
- match
- struct
- fit
