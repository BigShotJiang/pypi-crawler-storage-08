# Version file generated from include/version.h
# This is automatically updated by the build system

__version__ = "3.1.0"
