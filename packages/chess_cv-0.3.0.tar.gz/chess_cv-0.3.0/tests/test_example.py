def test_example():
    """A simple example test function."""
    assert True
