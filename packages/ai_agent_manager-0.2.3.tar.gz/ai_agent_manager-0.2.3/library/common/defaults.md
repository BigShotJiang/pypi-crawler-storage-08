think through the task step-by-step
document your thought process in thoughts.md
use git (e.g. initialize a repo, commit and push, if there is no remote, ask the user for advice)
if you use markdown files for Q&A with the user, make sure that you read the file again as the user might use an auto formatter like in VS Code
