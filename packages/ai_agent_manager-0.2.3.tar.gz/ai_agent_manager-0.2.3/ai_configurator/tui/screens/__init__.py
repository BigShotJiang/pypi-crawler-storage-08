"""TUI screen components."""
