def test_gui_imports():
    """
    Minimal test that we can import the items needed to run the gui
    """
    import pmpsdb_client.cli.run_gui  # noqa: F401
