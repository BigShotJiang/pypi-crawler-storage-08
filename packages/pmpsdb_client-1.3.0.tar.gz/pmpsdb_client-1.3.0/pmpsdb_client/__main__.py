from .cli import entrypoint

entrypoint()
