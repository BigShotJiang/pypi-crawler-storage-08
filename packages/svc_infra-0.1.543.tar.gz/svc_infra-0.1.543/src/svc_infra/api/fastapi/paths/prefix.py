AUTH_PREFIX = "/auth"
OAUTH_PREFIX = "/auth/oauth"
USER_PREFIX = "/users"
