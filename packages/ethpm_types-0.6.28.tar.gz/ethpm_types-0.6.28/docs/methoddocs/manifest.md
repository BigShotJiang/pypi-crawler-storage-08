# Package Manifest

```{eval-rst}
.. automodule:: ethpm_types.manifest
    :members:
```
