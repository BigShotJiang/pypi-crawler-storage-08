"""Core components of grimoire-model package."""
