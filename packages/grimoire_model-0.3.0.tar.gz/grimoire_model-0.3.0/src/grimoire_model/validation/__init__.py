"""Validation components for model data."""
