from osbot_utils.type_safe.Type_Safe import Type_Safe


class Client__Check__Target_Server__Auth(Type_Safe):
    found_key_name            : bool
    found_key_value           : bool
    key_valid_in_target_server: bool