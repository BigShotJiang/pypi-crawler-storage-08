from osbot_utils.type_safe.Type_Safe                             import Type_Safe
from mgraph_ai_service_cache_client.client.Cache__Client__Config import Cache__Client__Config


class Cache__Client(Type_Safe):
    config: Cache__Client__Config
