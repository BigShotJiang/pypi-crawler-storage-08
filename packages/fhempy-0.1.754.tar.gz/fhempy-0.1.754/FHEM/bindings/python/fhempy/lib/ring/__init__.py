# ring doorbell module
