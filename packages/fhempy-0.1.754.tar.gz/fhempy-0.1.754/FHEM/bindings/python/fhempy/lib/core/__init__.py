# init for core
