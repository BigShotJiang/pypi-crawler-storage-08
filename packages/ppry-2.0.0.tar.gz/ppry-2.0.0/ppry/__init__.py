import builtins

def ppry(*args, **kwargs):
    print(*args, **kwargs)
builtins.ppry = ppry
ppry("Programmer - Telegram: @LAEGER_MO - @sis_c")