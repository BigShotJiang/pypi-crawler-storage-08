"""
Base Integrated Channel application for specific integrated channels to use as a starting point.
"""

__version__ = "0.1.0"
