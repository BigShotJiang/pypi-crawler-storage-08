"""CLI module for SecureVibes"""

from securevibes.cli.main import cli

__all__ = ["cli"]
