"""SecureVibes agent definitions using proper Claude Agent SDK architecture"""

from securevibes.agents.definitions import SECUREVIBES_AGENTS

__all__ = [
    "SECUREVIBES_AGENTS",
]
