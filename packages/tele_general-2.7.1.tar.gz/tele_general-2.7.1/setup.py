import setuptools
setuptools.setup(
name = 'tele_general',
version = '2.7.1',
author = 'GENERAL:@GN_R7',
description = 'This library is from my programming for users-tele..general_Iraq_@GN_R7',
packages = setuptools.find_packages(),
classifiers = [
"Programming Language :: Python :: 3",
"Operating System :: OS Independent",
"License :: OSI Approved :: MIT License",

]
)