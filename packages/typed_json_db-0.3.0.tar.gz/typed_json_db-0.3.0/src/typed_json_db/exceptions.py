class JsonDBException(Exception):
    """Exception raised for errors in the JsonDB operations."""

    pass
