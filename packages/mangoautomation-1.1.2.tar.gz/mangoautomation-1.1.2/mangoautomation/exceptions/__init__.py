# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description:
# @Time   : 2023-07-07 10:14
# @Author : 毛鹏
import sys

from ._exceptions import MangoAutomationError



__all__ = ['MangoAutomationError']
