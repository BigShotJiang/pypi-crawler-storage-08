# lammps_parser/__init__.py

from .parser import parse_to_AST
from .sanitizer import sanitize

__version__ = "0.0.1"
__author__ = "Juan C. Verduzco, Ethan W. Holbrook"
