"""
Pre-calculated extended residue tables for common element sets

This speeds up MassDecomposer initialization for common element combinations
(i.e. "CHNOPS", the default)
"""