"""Analysis v1 service protobuf definitions."""
