"""Fast API Handler Exports"""

# *** exports

# ** app
from .fast import (
    FastApiHandler,
)