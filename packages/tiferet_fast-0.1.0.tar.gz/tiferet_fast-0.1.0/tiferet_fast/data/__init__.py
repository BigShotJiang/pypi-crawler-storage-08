"""Fast API Data Transfer Object Exports"""

# *** exports

# ** app
from .fast import (
    DataObject,
    FastRouteYamlData,
    FastRouterYamlData
)
