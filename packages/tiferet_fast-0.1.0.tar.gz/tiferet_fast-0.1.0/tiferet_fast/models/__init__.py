"""Fast API Model Exports"""

# *** exports

# ** app
from .fast import (
    FastRoute,
    FastRouter
)
