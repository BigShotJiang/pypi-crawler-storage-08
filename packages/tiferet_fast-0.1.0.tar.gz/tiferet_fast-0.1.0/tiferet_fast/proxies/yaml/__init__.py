"""Fast API YAML Proxy Exports"""

# *** exports

# ** app
from .fast import (
    FastYamlProxy,
)
