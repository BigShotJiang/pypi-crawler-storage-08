var ta = Object.defineProperty;
var Yn = (a) => {
  throw TypeError(a);
};
var na = (a, e, t) => e in a ? ta(a, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : a[e] = t;
var M = (a, e, t) => na(a, typeof e != "symbol" ? e + "" : e, t), ia = (a, e, t) => e.has(a) || Yn("Cannot " + t);
var Wn = (a, e, t) => e.has(a) ? Yn("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(a) : e.set(a, t);
var Wt = (a, e, t) => (ia(a, e, "access private method"), t);
const {
  SvelteComponent: la,
  append_hydration: Cn,
  assign: aa,
  attr: ne,
  binding_callbacks: oa,
  children: St,
  claim_element: wl,
  claim_space: kl,
  claim_svg_element: bn,
  create_slot: sa,
  detach: je,
  element: Fl,
  empty: Kn,
  get_all_dirty_from_scope: ra,
  get_slot_changes: ua,
  get_spread_update: _a,
  init: ca,
  insert_hydration: zt,
  listen: da,
  noop: fa,
  safe_not_equal: ha,
  set_dynamic_element_data: Qn,
  set_style: R,
  space: $l,
  svg_element: Dn,
  toggle_class: W,
  transition_in: Cl,
  transition_out: El,
  update_slot_base: pa
} = window.__gradio__svelte__internal;
function Jn(a) {
  let e, t, n, i, l;
  return {
    c() {
      e = Dn("svg"), t = Dn("line"), n = Dn("line"), this.h();
    },
    l(o) {
      e = bn(o, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var s = St(e);
      t = bn(s, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), St(t).forEach(je), n = bn(s, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), St(n).forEach(je), s.forEach(je), this.h();
    },
    h() {
      ne(t, "x1", "1"), ne(t, "y1", "9"), ne(t, "x2", "9"), ne(t, "y2", "1"), ne(t, "stroke", "gray"), ne(t, "stroke-width", "0.5"), ne(n, "x1", "5"), ne(n, "y1", "9"), ne(n, "x2", "9"), ne(n, "y2", "5"), ne(n, "stroke", "gray"), ne(n, "stroke-width", "0.5"), ne(e, "class", "resize-handle svelte-239wnu"), ne(e, "xmlns", "http://www.w3.org/2000/svg"), ne(e, "viewBox", "0 0 10 10");
    },
    m(o, s) {
      zt(o, e, s), Cn(e, t), Cn(e, n), i || (l = da(
        e,
        "mousedown",
        /*resize*/
        a[27]
      ), i = !0);
    },
    p: fa,
    d(o) {
      o && je(e), i = !1, l();
    }
  };
}
function ma(a) {
  var d;
  let e, t, n, i, l;
  const o = (
    /*#slots*/
    a[31].default
  ), s = sa(
    o,
    a,
    /*$$scope*/
    a[30],
    null
  );
  let r = (
    /*resizable*/
    a[19] && Jn(a)
  ), u = [
    { "data-testid": (
      /*test_id*/
      a[11]
    ) },
    { id: (
      /*elem_id*/
      a[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((d = a[7]) == null ? void 0 : d.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: i = /*rtl*/
      a[20] ? "rtl" : "ltr"
    }
  ], _ = {};
  for (let c = 0; c < u.length; c += 1)
    _ = aa(_, u[c]);
  return {
    c() {
      e = Fl(
        /*tag*/
        a[25]
      ), s && s.c(), t = $l(), r && r.c(), this.h();
    },
    l(c) {
      e = wl(
        c,
        /*tag*/
        (a[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var h = St(e);
      s && s.l(h), t = kl(h), r && r.l(h), h.forEach(je), this.h();
    },
    h() {
      Qn(
        /*tag*/
        a[25]
      )(e, _), W(
        e,
        "hidden",
        /*visible*/
        a[14] === !1
      ), W(
        e,
        "padded",
        /*padding*/
        a[10]
      ), W(
        e,
        "flex",
        /*flex*/
        a[1]
      ), W(
        e,
        "border_focus",
        /*border_mode*/
        a[9] === "focus"
      ), W(
        e,
        "border_contrast",
        /*border_mode*/
        a[9] === "contrast"
      ), W(e, "hide-container", !/*explicit_call*/
      a[12] && !/*container*/
      a[13]), W(
        e,
        "fullscreen",
        /*fullscreen*/
        a[0]
      ), W(
        e,
        "animating",
        /*fullscreen*/
        a[0] && /*preexpansionBoundingRect*/
        a[24] !== null
      ), W(
        e,
        "auto-margin",
        /*scale*/
        a[17] === null
      ), R(
        e,
        "height",
        /*fullscreen*/
        a[0] ? void 0 : (
          /*get_dimension*/
          a[26](
            /*height*/
            a[2]
          )
        )
      ), R(
        e,
        "min-height",
        /*fullscreen*/
        a[0] ? void 0 : (
          /*get_dimension*/
          a[26](
            /*min_height*/
            a[3]
          )
        )
      ), R(
        e,
        "max-height",
        /*fullscreen*/
        a[0] ? void 0 : (
          /*get_dimension*/
          a[26](
            /*max_height*/
            a[4]
          )
        )
      ), R(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        a[24] ? `${/*preexpansionBoundingRect*/
        a[24].top}px` : "0px"
      ), R(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        a[24] ? `${/*preexpansionBoundingRect*/
        a[24].left}px` : "0px"
      ), R(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        a[24] ? `${/*preexpansionBoundingRect*/
        a[24].width}px` : "0px"
      ), R(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        a[24] ? `${/*preexpansionBoundingRect*/
        a[24].height}px` : "0px"
      ), R(
        e,
        "width",
        /*fullscreen*/
        a[0] ? void 0 : typeof /*width*/
        a[5] == "number" ? `calc(min(${/*width*/
        a[5]}px, 100%))` : (
          /*get_dimension*/
          a[26](
            /*width*/
            a[5]
          )
        )
      ), R(
        e,
        "border-style",
        /*variant*/
        a[8]
      ), R(
        e,
        "overflow",
        /*allow_overflow*/
        a[15] ? (
          /*overflow_behavior*/
          a[16]
        ) : "hidden"
      ), R(
        e,
        "flex-grow",
        /*scale*/
        a[17]
      ), R(e, "min-width", `calc(min(${/*min_width*/
      a[18]}px, 100%))`), R(e, "border-width", "var(--block-border-width)");
    },
    m(c, h) {
      zt(c, e, h), s && s.m(e, null), Cn(e, t), r && r.m(e, null), a[32](e), l = !0;
    },
    p(c, h) {
      var g;
      s && s.p && (!l || h[0] & /*$$scope*/
      1073741824) && pa(
        s,
        o,
        c,
        /*$$scope*/
        c[30],
        l ? ua(
          o,
          /*$$scope*/
          c[30],
          h,
          null
        ) : ra(
          /*$$scope*/
          c[30]
        ),
        null
      ), /*resizable*/
      c[19] ? r ? r.p(c, h) : (r = Jn(c), r.c(), r.m(e, null)) : r && (r.d(1), r = null), Qn(
        /*tag*/
        c[25]
      )(e, _ = _a(u, [
        (!l || h[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          c[11]
        ) },
        (!l || h[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          c[6]
        ) },
        (!l || h[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((g = c[7]) == null ? void 0 : g.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!l || h[0] & /*rtl*/
        1048576 && i !== (i = /*rtl*/
        c[20] ? "rtl" : "ltr")) && { dir: i }
      ])), W(
        e,
        "hidden",
        /*visible*/
        c[14] === !1
      ), W(
        e,
        "padded",
        /*padding*/
        c[10]
      ), W(
        e,
        "flex",
        /*flex*/
        c[1]
      ), W(
        e,
        "border_focus",
        /*border_mode*/
        c[9] === "focus"
      ), W(
        e,
        "border_contrast",
        /*border_mode*/
        c[9] === "contrast"
      ), W(e, "hide-container", !/*explicit_call*/
      c[12] && !/*container*/
      c[13]), W(
        e,
        "fullscreen",
        /*fullscreen*/
        c[0]
      ), W(
        e,
        "animating",
        /*fullscreen*/
        c[0] && /*preexpansionBoundingRect*/
        c[24] !== null
      ), W(
        e,
        "auto-margin",
        /*scale*/
        c[17] === null
      ), h[0] & /*fullscreen, height*/
      5 && R(
        e,
        "height",
        /*fullscreen*/
        c[0] ? void 0 : (
          /*get_dimension*/
          c[26](
            /*height*/
            c[2]
          )
        )
      ), h[0] & /*fullscreen, min_height*/
      9 && R(
        e,
        "min-height",
        /*fullscreen*/
        c[0] ? void 0 : (
          /*get_dimension*/
          c[26](
            /*min_height*/
            c[3]
          )
        )
      ), h[0] & /*fullscreen, max_height*/
      17 && R(
        e,
        "max-height",
        /*fullscreen*/
        c[0] ? void 0 : (
          /*get_dimension*/
          c[26](
            /*max_height*/
            c[4]
          )
        )
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && R(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].top}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && R(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].left}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && R(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].width}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && R(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].height}px` : "0px"
      ), h[0] & /*fullscreen, width*/
      33 && R(
        e,
        "width",
        /*fullscreen*/
        c[0] ? void 0 : typeof /*width*/
        c[5] == "number" ? `calc(min(${/*width*/
        c[5]}px, 100%))` : (
          /*get_dimension*/
          c[26](
            /*width*/
            c[5]
          )
        )
      ), h[0] & /*variant*/
      256 && R(
        e,
        "border-style",
        /*variant*/
        c[8]
      ), h[0] & /*allow_overflow, overflow_behavior*/
      98304 && R(
        e,
        "overflow",
        /*allow_overflow*/
        c[15] ? (
          /*overflow_behavior*/
          c[16]
        ) : "hidden"
      ), h[0] & /*scale*/
      131072 && R(
        e,
        "flex-grow",
        /*scale*/
        c[17]
      ), h[0] & /*min_width*/
      262144 && R(e, "min-width", `calc(min(${/*min_width*/
      c[18]}px, 100%))`);
    },
    i(c) {
      l || (Cl(s, c), l = !0);
    },
    o(c) {
      El(s, c), l = !1;
    },
    d(c) {
      c && je(e), s && s.d(c), r && r.d(), a[32](null);
    }
  };
}
function ei(a) {
  let e;
  return {
    c() {
      e = Fl("div"), this.h();
    },
    l(t) {
      e = wl(t, "DIV", { class: !0 }), St(e).forEach(je), this.h();
    },
    h() {
      ne(e, "class", "placeholder svelte-239wnu"), R(
        e,
        "height",
        /*placeholder_height*/
        a[22] + "px"
      ), R(
        e,
        "width",
        /*placeholder_width*/
        a[23] + "px"
      );
    },
    m(t, n) {
      zt(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && R(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && R(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && je(e);
    }
  };
}
function ga(a) {
  let e, t, n, i = (
    /*tag*/
    a[25] && ma(a)
  ), l = (
    /*fullscreen*/
    a[0] && ei(a)
  );
  return {
    c() {
      i && i.c(), e = $l(), l && l.c(), t = Kn();
    },
    l(o) {
      i && i.l(o), e = kl(o), l && l.l(o), t = Kn();
    },
    m(o, s) {
      i && i.m(o, s), zt(o, e, s), l && l.m(o, s), zt(o, t, s), n = !0;
    },
    p(o, s) {
      /*tag*/
      o[25] && i.p(o, s), /*fullscreen*/
      o[0] ? l ? l.p(o, s) : (l = ei(o), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null);
    },
    i(o) {
      n || (Cl(i, o), n = !0);
    },
    o(o) {
      El(i, o), n = !1;
    },
    d(o) {
      o && (je(e), je(t)), i && i.d(o), l && l.d(o);
    }
  };
}
function va(a, e, t) {
  let { $$slots: n = {}, $$scope: i } = e, { height: l = void 0 } = e, { min_height: o = void 0 } = e, { max_height: s = void 0 } = e, { width: r = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: _ = [] } = e, { variant: d = "solid" } = e, { border_mode: c = "base" } = e, { padding: h = !0 } = e, { type: g = "normal" } = e, { test_id: p = void 0 } = e, { explicit_call: D = !1 } = e, { container: k = !0 } = e, { visible: m = !0 } = e, { allow_overflow: f = !0 } = e, { overflow_behavior: v = "auto" } = e, { scale: y = null } = e, { min_width: b = 0 } = e, { flex: F = !1 } = e, { resizable: A = !1 } = e, { rtl: E = !1 } = e, { fullscreen: q = !1 } = e, w = q, $, ge = g === "fieldset" ? "fieldset" : "div", _e = 0, Me = 0, ue = null;
  function nt(C) {
    q && C.key === "Escape" && t(0, q = !1);
  }
  const Z = (C) => {
    if (C !== void 0) {
      if (typeof C == "number")
        return C + "px";
      if (typeof C == "string")
        return C;
    }
  }, se = (C) => {
    let ee = C.clientY;
    const pt = (S) => {
      const mt = S.clientY - ee;
      ee = S.clientY, t(21, $.style.height = `${$.offsetHeight + mt}px`, $);
    }, ce = () => {
      window.removeEventListener("mousemove", pt), window.removeEventListener("mouseup", ce);
    };
    window.addEventListener("mousemove", pt), window.addEventListener("mouseup", ce);
  };
  function Se(C) {
    oa[C ? "unshift" : "push"](() => {
      $ = C, t(21, $);
    });
  }
  return a.$$set = (C) => {
    "height" in C && t(2, l = C.height), "min_height" in C && t(3, o = C.min_height), "max_height" in C && t(4, s = C.max_height), "width" in C && t(5, r = C.width), "elem_id" in C && t(6, u = C.elem_id), "elem_classes" in C && t(7, _ = C.elem_classes), "variant" in C && t(8, d = C.variant), "border_mode" in C && t(9, c = C.border_mode), "padding" in C && t(10, h = C.padding), "type" in C && t(28, g = C.type), "test_id" in C && t(11, p = C.test_id), "explicit_call" in C && t(12, D = C.explicit_call), "container" in C && t(13, k = C.container), "visible" in C && t(14, m = C.visible), "allow_overflow" in C && t(15, f = C.allow_overflow), "overflow_behavior" in C && t(16, v = C.overflow_behavior), "scale" in C && t(17, y = C.scale), "min_width" in C && t(18, b = C.min_width), "flex" in C && t(1, F = C.flex), "resizable" in C && t(19, A = C.resizable), "rtl" in C && t(20, E = C.rtl), "fullscreen" in C && t(0, q = C.fullscreen), "$$scope" in C && t(30, i = C.$$scope);
  }, a.$$.update = () => {
    a.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && q !== w && (t(29, w = q), q ? (t(24, ue = $.getBoundingClientRect()), t(22, _e = $.offsetHeight), t(23, Me = $.offsetWidth), window.addEventListener("keydown", nt)) : (t(24, ue = null), window.removeEventListener("keydown", nt))), a.$$.dirty[0] & /*visible*/
    16384 && (m || t(1, F = !1));
  }, [
    q,
    F,
    l,
    o,
    s,
    r,
    u,
    _,
    d,
    c,
    h,
    p,
    D,
    k,
    m,
    f,
    v,
    y,
    b,
    A,
    E,
    $,
    _e,
    Me,
    ue,
    ge,
    Z,
    se,
    g,
    w,
    i,
    n,
    Se
  ];
}
class ba extends la {
  constructor(e) {
    super(), ca(
      this,
      e,
      va,
      ga,
      ha,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function Nn() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let ht = Nn();
function Al(a) {
  ht = a;
}
const Sl = /[&<>"']/, Da = new RegExp(Sl.source, "g"), Bl = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, ya = new RegExp(Bl.source, "g"), wa = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, ti = (a) => wa[a];
function fe(a, e) {
  if (e) {
    if (Sl.test(a))
      return a.replace(Da, ti);
  } else if (Bl.test(a))
    return a.replace(ya, ti);
  return a;
}
const ka = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Fa(a) {
  return a.replace(ka, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const $a = /(^|[^\[])\^/g;
function O(a, e) {
  let t = typeof a == "string" ? a : a.source;
  e = e || "";
  const n = {
    replace: (i, l) => {
      let o = typeof l == "string" ? l : l.source;
      return o = o.replace($a, "$1"), t = t.replace(i, o), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function ni(a) {
  try {
    a = encodeURI(a).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return a;
}
const Bt = { exec: () => null };
function ii(a, e) {
  const t = a.replace(/\|/g, (l, o, s) => {
    let r = !1, u = o;
    for (; --u >= 0 && s[u] === "\\"; )
      r = !r;
    return r ? "|" : " |";
  }), n = t.split(/ \|/);
  let i = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; i < n.length; i++)
    n[i] = n[i].trim().replace(/\\\|/g, "|");
  return n;
}
function Kt(a, e, t) {
  const n = a.length;
  if (n === 0)
    return "";
  let i = 0;
  for (; i < n && a.charAt(n - i - 1) === e; )
    i++;
  return a.slice(0, n - i);
}
function Ca(a, e) {
  if (a.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < a.length; n++)
    if (a[n] === "\\")
      n++;
    else if (a[n] === e[0])
      t++;
    else if (a[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function li(a, e, t, n) {
  const i = e.href, l = e.title ? fe(e.title) : null, o = a[1].replace(/\\([\[\]])/g, "$1");
  if (a[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const s = {
      type: "link",
      raw: t,
      href: i,
      title: l,
      text: o,
      tokens: n.inlineTokens(o)
    };
    return n.state.inLink = !1, s;
  }
  return {
    type: "image",
    raw: t,
    href: i,
    title: l,
    text: fe(o)
  };
}
function Ea(a, e) {
  const t = a.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((i) => {
    const l = i.match(/^\s+/);
    if (l === null)
      return i;
    const [o] = l;
    return o.length >= n.length ? i.slice(n.length) : i;
  }).join(`
`);
}
class _n {
  // set by the lexer
  constructor(e) {
    M(this, "options");
    M(this, "rules");
    // set by the lexer
    M(this, "lexer");
    this.options = e || ht;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : Kt(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], i = Ea(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: i
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const i = Kt(n, "#");
        (this.options.pedantic || !i || / $/.test(i)) && (n = i.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = Kt(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const i = this.lexer.state.top;
      this.lexer.state.top = !0;
      const l = this.lexer.blockTokens(n);
      return this.lexer.state.top = i, {
        type: "blockquote",
        raw: t[0],
        tokens: l,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const i = n.length > 1, l = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = i ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = i ? n : "[*+-]");
      const o = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let s = "", r = "", u = !1;
      for (; e; ) {
        let _ = !1;
        if (!(t = o.exec(e)) || this.rules.block.hr.test(e))
          break;
        s = t[0], e = e.substring(s.length);
        let d = t[2].split(`
`, 1)[0].replace(/^\t+/, (k) => " ".repeat(3 * k.length)), c = e.split(`
`, 1)[0], h = 0;
        this.options.pedantic ? (h = 2, r = d.trimStart()) : (h = t[2].search(/[^ ]/), h = h > 4 ? 1 : h, r = d.slice(h), h += t[1].length);
        let g = !1;
        if (!d && /^ *$/.test(c) && (s += c + `
`, e = e.substring(c.length + 1), _ = !0), !_) {
          const k = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), m = new RegExp(`^ {0,${Math.min(3, h - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), f = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:\`\`\`|~~~)`), v = new RegExp(`^ {0,${Math.min(3, h - 1)}}#`);
          for (; e; ) {
            const y = e.split(`
`, 1)[0];
            if (c = y, this.options.pedantic && (c = c.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), f.test(c) || v.test(c) || k.test(c) || m.test(e))
              break;
            if (c.search(/[^ ]/) >= h || !c.trim())
              r += `
` + c.slice(h);
            else {
              if (g || d.search(/[^ ]/) >= 4 || f.test(d) || v.test(d) || m.test(d))
                break;
              r += `
` + c;
            }
            !g && !c.trim() && (g = !0), s += y + `
`, e = e.substring(y.length + 1), d = c.slice(h);
          }
        }
        l.loose || (u ? l.loose = !0 : /\n *\n *$/.test(s) && (u = !0));
        let p = null, D;
        this.options.gfm && (p = /^\[[ xX]\] /.exec(r), p && (D = p[0] !== "[ ] ", r = r.replace(/^\[[ xX]\] +/, ""))), l.items.push({
          type: "list_item",
          raw: s,
          task: !!p,
          checked: D,
          loose: !1,
          text: r,
          tokens: []
        }), l.raw += s;
      }
      l.items[l.items.length - 1].raw = s.trimEnd(), l.items[l.items.length - 1].text = r.trimEnd(), l.raw = l.raw.trimEnd();
      for (let _ = 0; _ < l.items.length; _++)
        if (this.lexer.state.top = !1, l.items[_].tokens = this.lexer.blockTokens(l.items[_].text, []), !l.loose) {
          const d = l.items[_].tokens.filter((h) => h.type === "space"), c = d.length > 0 && d.some((h) => /\n.*\n/.test(h.raw));
          l.loose = c;
        }
      if (l.loose)
        for (let _ = 0; _ < l.items.length; _++)
          l.items[_].loose = !0;
      return l;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), i = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", l = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: i,
        title: l
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = ii(t[1]), i = t[2].replace(/^\||\| *$/g, "").split("|"), l = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], o = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === i.length) {
      for (const s of i)
        /^ *-+: *$/.test(s) ? o.align.push("right") : /^ *:-+: *$/.test(s) ? o.align.push("center") : /^ *:-+ *$/.test(s) ? o.align.push("left") : o.align.push(null);
      for (const s of n)
        o.header.push({
          text: s,
          tokens: this.lexer.inline(s)
        });
      for (const s of l)
        o.rows.push(ii(s, o.header.length).map((r) => ({
          text: r,
          tokens: this.lexer.inline(r)
        })));
      return o;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: fe(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const o = Kt(n.slice(0, -1), "\\");
        if ((n.length - o.length) % 2 === 0)
          return;
      } else {
        const o = Ca(t[2], "()");
        if (o > -1) {
          const r = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + o;
          t[2] = t[2].substring(0, o), t[0] = t[0].substring(0, r).trim(), t[3] = "";
        }
      }
      let i = t[2], l = "";
      if (this.options.pedantic) {
        const o = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(i);
        o && (i = o[1], l = o[3]);
      } else
        l = t[3] ? t[3].slice(1, -1) : "";
      return i = i.trim(), /^</.test(i) && (this.options.pedantic && !/>$/.test(n) ? i = i.slice(1) : i = i.slice(1, -1)), li(t, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: l && l.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const i = (n[2] || n[1]).replace(/\s+/g, " "), l = t[i.toLowerCase()];
      if (!l) {
        const o = n[0].charAt(0);
        return {
          type: "text",
          raw: o,
          text: o
        };
      }
      return li(n, l, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let i = this.rules.inline.emStrongLDelim.exec(e);
    if (!i || i[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(i[1] || i[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const o = [...i[0]].length - 1;
      let s, r, u = o, _ = 0;
      const d = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (d.lastIndex = 0, t = t.slice(-1 * e.length + o); (i = d.exec(t)) != null; ) {
        if (s = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !s)
          continue;
        if (r = [...s].length, i[3] || i[4]) {
          u += r;
          continue;
        } else if ((i[5] || i[6]) && o % 3 && !((o + r) % 3)) {
          _ += r;
          continue;
        }
        if (u -= r, u > 0)
          continue;
        r = Math.min(r, r + u + _);
        const c = [...i[0]][0].length, h = e.slice(0, o + i.index + c + r);
        if (Math.min(o, r) % 2) {
          const p = h.slice(1, -1);
          return {
            type: "em",
            raw: h,
            text: p,
            tokens: this.lexer.inlineTokens(p)
          };
        }
        const g = h.slice(2, -2);
        return {
          type: "strong",
          raw: h,
          text: g,
          tokens: this.lexer.inlineTokens(g)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const i = /[^ ]/.test(n), l = /^ /.test(n) && / $/.test(n);
      return i && l && (n = n.substring(1, n.length - 1)), n = fe(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, i;
      return t[2] === "@" ? (n = fe(t[1]), i = "mailto:" + n) : (n = fe(t[1]), i = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: i,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let i, l;
      if (t[2] === "@")
        i = fe(t[0]), l = "mailto:" + i;
      else {
        let o;
        do
          o = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (o !== t[0]);
        i = fe(t[0]), t[1] === "www." ? l = "http://" + t[0] : l = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: i,
        href: l,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = fe(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Aa = /^(?: *(?:\n|$))+/, Sa = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Ba = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Gt = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, qa = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, ql = /(?:[*+-]|\d{1,9}[.)])/, Tl = O(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, ql).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), jn = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Ta = /^[^\n]+/, Hn = /(?!\s*\])(?:\\.|[^\[\]\\])+/, za = O(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", Hn).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Ia = O(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, ql).getRegex(), hn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", xn = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Ra = O("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", xn).replace("tag", hn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), zl = O(jn).replace("hr", Gt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", hn).getRegex(), La = O(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", zl).getRegex(), Vn = {
  blockquote: La,
  code: Sa,
  def: za,
  fences: Ba,
  heading: qa,
  hr: Gt,
  html: Ra,
  lheading: Tl,
  list: Ia,
  newline: Aa,
  paragraph: zl,
  table: Bt,
  text: Ta
}, ai = O("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Gt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", hn).getRegex(), Oa = {
  ...Vn,
  table: ai,
  paragraph: O(jn).replace("hr", Gt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", ai).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", hn).getRegex()
}, Pa = {
  ...Vn,
  html: O(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", xn).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Bt,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: O(jn).replace("hr", Gt).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Tl).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Il = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Ma = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Rl = /^( {2,}|\\)\n(?!\s*$)/, Na = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Zt = "\\p{P}\\p{S}", ja = O(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Zt).getRegex(), Ha = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, xa = O(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Zt).getRegex(), Va = O("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Zt).getRegex(), Ua = O("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Zt).getRegex(), Ga = O(/\\([punct])/, "gu").replace(/punct/g, Zt).getRegex(), Za = O(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Xa = O(xn).replace("(?:-->|$)", "-->").getRegex(), Ya = O("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Xa).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), cn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Wa = O(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", cn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), Ll = O(/^!?\[(label)\]\[(ref)\]/).replace("label", cn).replace("ref", Hn).getRegex(), Ol = O(/^!?\[(ref)\](?:\[\])?/).replace("ref", Hn).getRegex(), Ka = O("reflink|nolink(?!\\()", "g").replace("reflink", Ll).replace("nolink", Ol).getRegex(), Un = {
  _backpedal: Bt,
  // only used for GFM url
  anyPunctuation: Ga,
  autolink: Za,
  blockSkip: Ha,
  br: Rl,
  code: Ma,
  del: Bt,
  emStrongLDelim: xa,
  emStrongRDelimAst: Va,
  emStrongRDelimUnd: Ua,
  escape: Il,
  link: Wa,
  nolink: Ol,
  punctuation: ja,
  reflink: Ll,
  reflinkSearch: Ka,
  tag: Ya,
  text: Na,
  url: Bt
}, Qa = {
  ...Un,
  link: O(/^!?\[(label)\]\((.*?)\)/).replace("label", cn).getRegex(),
  reflink: O(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", cn).getRegex()
}, En = {
  ...Un,
  escape: O(Il).replace("])", "~|])").getRegex(),
  url: O(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Ja = {
  ...En,
  br: O(Rl).replace("{2,}", "*").getRegex(),
  text: O(En.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Qt = {
  normal: Vn,
  gfm: Oa,
  pedantic: Pa
}, Ct = {
  normal: Un,
  gfm: En,
  breaks: Ja,
  pedantic: Qa
};
class He {
  constructor(e) {
    M(this, "tokens");
    M(this, "options");
    M(this, "state");
    M(this, "tokenizer");
    M(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || ht, this.options.tokenizer = this.options.tokenizer || new _n(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: Qt.normal,
      inline: Ct.normal
    };
    this.options.pedantic ? (t.block = Qt.pedantic, t.inline = Ct.pedantic) : this.options.gfm && (t.block = Qt.gfm, this.options.breaks ? t.inline = Ct.breaks : t.inline = Ct.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Qt,
      inline: Ct
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new He(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new He(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (s, r, u) => r + "    ".repeat(u.length));
    let n, i, l, o;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((s) => (n = s.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (l = e, this.options.extensions && this.options.extensions.startBlock) {
          let s = 1 / 0;
          const r = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((_) => {
            u = _.call({ lexer: this }, r), typeof u == "number" && u >= 0 && (s = Math.min(s, u));
          }), s < 1 / 0 && s >= 0 && (l = e.substring(0, s + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(l))) {
          i = t[t.length - 1], o && i.type === "paragraph" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n), o = l.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && i.type === "text" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (e) {
          const s = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(s);
            break;
          } else
            throw new Error(s);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, i, l, o = e, s, r, u;
    if (this.tokens.links) {
      const _ = Object.keys(this.tokens.links);
      if (_.length > 0)
        for (; (s = this.tokenizer.rules.inline.reflinkSearch.exec(o)) != null; )
          _.includes(s[0].slice(s[0].lastIndexOf("[") + 1, -1)) && (o = o.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (s = this.tokenizer.rules.inline.blockSkip.exec(o)) != null; )
      o = o.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (s = this.tokenizer.rules.inline.anyPunctuation.exec(o)) != null; )
      o = o.slice(0, s.index) + "++" + o.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (r || (u = ""), r = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((_) => (n = _.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, o, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (l = e, this.options.extensions && this.options.extensions.startInline) {
          let _ = 1 / 0;
          const d = e.slice(1);
          let c;
          this.options.extensions.startInline.forEach((h) => {
            c = h.call({ lexer: this }, d), typeof c == "number" && c >= 0 && (_ = Math.min(_, c));
          }), _ < 1 / 0 && _ >= 0 && (l = e.substring(0, _ + 1));
        }
        if (n = this.tokenizer.inlineText(l)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), r = !0, i = t[t.length - 1], i && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const _ = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(_);
            break;
          } else
            throw new Error(_);
        }
      }
    return t;
  }
}
class dn {
  constructor(e) {
    M(this, "options");
    this.options = e || ht;
  }
  code(e, t, n) {
    var l;
    const i = (l = (t || "").match(/^\S*/)) == null ? void 0 : l[0];
    return e = e.replace(/\n$/, "") + `
`, i ? '<pre><code class="language-' + fe(i) + '">' + (n ? e : fe(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : fe(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const i = t ? "ol" : "ul", l = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + i + l + `>
` + e + "</" + i + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const i = ni(e);
    if (i === null)
      return n;
    e = i;
    let l = '<a href="' + e + '"';
    return t && (l += ' title="' + t + '"'), l += ">" + n + "</a>", l;
  }
  image(e, t, n) {
    const i = ni(e);
    if (i === null)
      return n;
    e = i;
    let l = `<img src="${e}" alt="${n}"`;
    return t && (l += ` title="${t}"`), l += ">", l;
  }
  text(e) {
    return e;
  }
}
class Gn {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class xe {
  constructor(e) {
    M(this, "options");
    M(this, "renderer");
    M(this, "textRenderer");
    this.options = e || ht, this.options.renderer = this.options.renderer || new dn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Gn();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new xe(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new xe(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const l = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[l.type]) {
        const o = l, s = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (s !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(o.type)) {
          n += s || "";
          continue;
        }
      }
      switch (l.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const o = l;
          n += this.renderer.heading(this.parseInline(o.tokens), o.depth, Fa(this.parseInline(o.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const o = l;
          n += this.renderer.code(o.text, o.lang, !!o.escaped);
          continue;
        }
        case "table": {
          const o = l;
          let s = "", r = "";
          for (let _ = 0; _ < o.header.length; _++)
            r += this.renderer.tablecell(this.parseInline(o.header[_].tokens), { header: !0, align: o.align[_] });
          s += this.renderer.tablerow(r);
          let u = "";
          for (let _ = 0; _ < o.rows.length; _++) {
            const d = o.rows[_];
            r = "";
            for (let c = 0; c < d.length; c++)
              r += this.renderer.tablecell(this.parseInline(d[c].tokens), { header: !1, align: o.align[c] });
            u += this.renderer.tablerow(r);
          }
          n += this.renderer.table(s, u);
          continue;
        }
        case "blockquote": {
          const o = l, s = this.parse(o.tokens);
          n += this.renderer.blockquote(s);
          continue;
        }
        case "list": {
          const o = l, s = o.ordered, r = o.start, u = o.loose;
          let _ = "";
          for (let d = 0; d < o.items.length; d++) {
            const c = o.items[d], h = c.checked, g = c.task;
            let p = "";
            if (c.task) {
              const D = this.renderer.checkbox(!!h);
              u ? c.tokens.length > 0 && c.tokens[0].type === "paragraph" ? (c.tokens[0].text = D + " " + c.tokens[0].text, c.tokens[0].tokens && c.tokens[0].tokens.length > 0 && c.tokens[0].tokens[0].type === "text" && (c.tokens[0].tokens[0].text = D + " " + c.tokens[0].tokens[0].text)) : c.tokens.unshift({
                type: "text",
                text: D + " "
              }) : p += D + " ";
            }
            p += this.parse(c.tokens, u), _ += this.renderer.listitem(p, g, !!h);
          }
          n += this.renderer.list(_, s, r);
          continue;
        }
        case "html": {
          const o = l;
          n += this.renderer.html(o.text, o.block);
          continue;
        }
        case "paragraph": {
          const o = l;
          n += this.renderer.paragraph(this.parseInline(o.tokens));
          continue;
        }
        case "text": {
          let o = l, s = o.tokens ? this.parseInline(o.tokens) : o.text;
          for (; i + 1 < e.length && e[i + 1].type === "text"; )
            o = e[++i], s += `
` + (o.tokens ? this.parseInline(o.tokens) : o.text);
          n += t ? this.renderer.paragraph(s) : s;
          continue;
        }
        default: {
          const o = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const l = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[l.type]) {
        const o = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (o !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(l.type)) {
          n += o || "";
          continue;
        }
      }
      switch (l.type) {
        case "escape": {
          const o = l;
          n += t.text(o.text);
          break;
        }
        case "html": {
          const o = l;
          n += t.html(o.text);
          break;
        }
        case "link": {
          const o = l;
          n += t.link(o.href, o.title, this.parseInline(o.tokens, t));
          break;
        }
        case "image": {
          const o = l;
          n += t.image(o.href, o.title, o.text);
          break;
        }
        case "strong": {
          const o = l;
          n += t.strong(this.parseInline(o.tokens, t));
          break;
        }
        case "em": {
          const o = l;
          n += t.em(this.parseInline(o.tokens, t));
          break;
        }
        case "codespan": {
          const o = l;
          n += t.codespan(o.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const o = l;
          n += t.del(this.parseInline(o.tokens, t));
          break;
        }
        case "text": {
          const o = l;
          n += t.text(o.text);
          break;
        }
        default: {
          const o = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return n;
  }
}
class qt {
  constructor(e) {
    M(this, "options");
    this.options = e || ht;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
M(qt, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var ft, An, Pl;
class eo {
  constructor(...e) {
    Wn(this, ft);
    M(this, "defaults", Nn());
    M(this, "options", this.setOptions);
    M(this, "parse", Wt(this, ft, An).call(this, He.lex, xe.parse));
    M(this, "parseInline", Wt(this, ft, An).call(this, He.lexInline, xe.parseInline));
    M(this, "Parser", xe);
    M(this, "Renderer", dn);
    M(this, "TextRenderer", Gn);
    M(this, "Lexer", He);
    M(this, "Tokenizer", _n);
    M(this, "Hooks", qt);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var i, l;
    let n = [];
    for (const o of e)
      switch (n = n.concat(t.call(this, o)), o.type) {
        case "table": {
          const s = o;
          for (const r of s.header)
            n = n.concat(this.walkTokens(r.tokens, t));
          for (const r of s.rows)
            for (const u of r)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const s = o;
          n = n.concat(this.walkTokens(s.items, t));
          break;
        }
        default: {
          const s = o;
          (l = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && l[s.type] ? this.defaults.extensions.childTokens[s.type].forEach((r) => {
            const u = s[r].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : s.tokens && (n = n.concat(this.walkTokens(s.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const i = { ...n };
      if (i.async = this.defaults.async || i.async || !1, n.extensions && (n.extensions.forEach((l) => {
        if (!l.name)
          throw new Error("extension name required");
        if ("renderer" in l) {
          const o = t.renderers[l.name];
          o ? t.renderers[l.name] = function(...s) {
            let r = l.renderer.apply(this, s);
            return r === !1 && (r = o.apply(this, s)), r;
          } : t.renderers[l.name] = l.renderer;
        }
        if ("tokenizer" in l) {
          if (!l.level || l.level !== "block" && l.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const o = t[l.level];
          o ? o.unshift(l.tokenizer) : t[l.level] = [l.tokenizer], l.start && (l.level === "block" ? t.startBlock ? t.startBlock.push(l.start) : t.startBlock = [l.start] : l.level === "inline" && (t.startInline ? t.startInline.push(l.start) : t.startInline = [l.start]));
        }
        "childTokens" in l && l.childTokens && (t.childTokens[l.name] = l.childTokens);
      }), i.extensions = t), n.renderer) {
        const l = this.defaults.renderer || new dn(this.defaults);
        for (const o in n.renderer) {
          if (!(o in l))
            throw new Error(`renderer '${o}' does not exist`);
          if (o === "options")
            continue;
          const s = o, r = n.renderer[s], u = l[s];
          l[s] = (..._) => {
            let d = r.apply(l, _);
            return d === !1 && (d = u.apply(l, _)), d || "";
          };
        }
        i.renderer = l;
      }
      if (n.tokenizer) {
        const l = this.defaults.tokenizer || new _n(this.defaults);
        for (const o in n.tokenizer) {
          if (!(o in l))
            throw new Error(`tokenizer '${o}' does not exist`);
          if (["options", "rules", "lexer"].includes(o))
            continue;
          const s = o, r = n.tokenizer[s], u = l[s];
          l[s] = (..._) => {
            let d = r.apply(l, _);
            return d === !1 && (d = u.apply(l, _)), d;
          };
        }
        i.tokenizer = l;
      }
      if (n.hooks) {
        const l = this.defaults.hooks || new qt();
        for (const o in n.hooks) {
          if (!(o in l))
            throw new Error(`hook '${o}' does not exist`);
          if (o === "options")
            continue;
          const s = o, r = n.hooks[s], u = l[s];
          qt.passThroughHooks.has(o) ? l[s] = (_) => {
            if (this.defaults.async)
              return Promise.resolve(r.call(l, _)).then((c) => u.call(l, c));
            const d = r.call(l, _);
            return u.call(l, d);
          } : l[s] = (..._) => {
            let d = r.apply(l, _);
            return d === !1 && (d = u.apply(l, _)), d;
          };
        }
        i.hooks = l;
      }
      if (n.walkTokens) {
        const l = this.defaults.walkTokens, o = n.walkTokens;
        i.walkTokens = function(s) {
          let r = [];
          return r.push(o.call(this, s)), l && (r = r.concat(l.call(this, s))), r;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return He.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return xe.parse(e, t ?? this.defaults);
  }
}
ft = new WeakSet(), An = function(e, t) {
  return (n, i) => {
    const l = { ...i }, o = { ...this.defaults, ...l };
    this.defaults.async === !0 && l.async === !1 && (o.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), o.async = !0);
    const s = Wt(this, ft, Pl).call(this, !!o.silent, !!o.async);
    if (typeof n > "u" || n === null)
      return s(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return s(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (o.hooks && (o.hooks.options = o), o.async)
      return Promise.resolve(o.hooks ? o.hooks.preprocess(n) : n).then((r) => e(r, o)).then((r) => o.hooks ? o.hooks.processAllTokens(r) : r).then((r) => o.walkTokens ? Promise.all(this.walkTokens(r, o.walkTokens)).then(() => r) : r).then((r) => t(r, o)).then((r) => o.hooks ? o.hooks.postprocess(r) : r).catch(s);
    try {
      o.hooks && (n = o.hooks.preprocess(n));
      let r = e(n, o);
      o.hooks && (r = o.hooks.processAllTokens(r)), o.walkTokens && this.walkTokens(r, o.walkTokens);
      let u = t(r, o);
      return o.hooks && (u = o.hooks.postprocess(u)), u;
    } catch (r) {
      return s(r);
    }
  };
}, Pl = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const i = "<p>An error occurred:</p><pre>" + fe(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(i) : i;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const _t = new eo();
function L(a, e) {
  return _t.parse(a, e);
}
L.options = L.setOptions = function(a) {
  return _t.setOptions(a), L.defaults = _t.defaults, Al(L.defaults), L;
};
L.getDefaults = Nn;
L.defaults = ht;
L.use = function(...a) {
  return _t.use(...a), L.defaults = _t.defaults, Al(L.defaults), L;
};
L.walkTokens = function(a, e) {
  return _t.walkTokens(a, e);
};
L.parseInline = _t.parseInline;
L.Parser = xe;
L.parser = xe.parse;
L.Renderer = dn;
L.TextRenderer = Gn;
L.Lexer = He;
L.lexer = He.lex;
L.Tokenizer = _n;
L.Hooks = qt;
L.parse = L;
L.options;
L.setOptions;
L.use;
L.walkTokens;
L.parseInline;
xe.parse;
He.lex;
const to = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, no = Object.hasOwnProperty;
class Ml {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let i = io(e, t === !0);
    const l = i;
    for (; no.call(n.occurrences, i); )
      n.occurrences[l]++, i = l + "-" + n.occurrences[l];
    return n.occurrences[i] = 0, i;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function io(a, e) {
  return typeof a != "string" ? "" : (e || (a = a.toLowerCase()), a.replace(to, "").replace(/ /g, "-"));
}
new Ml();
var oi = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, lo = { exports: {} };
(function(a) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var i = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, l = 0, o = {}, s = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function m(f) {
          return f instanceof r ? new r(f.type, m(f.content), f.alias) : Array.isArray(f) ? f.map(m) : f.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(m) {
          return Object.prototype.toString.call(m).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(m) {
          return m.__id || Object.defineProperty(m, "__id", { value: ++l }), m.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function m(f, v) {
          v = v || {};
          var y, b;
          switch (s.util.type(f)) {
            case "Object":
              if (b = s.util.objId(f), v[b])
                return v[b];
              y = /** @type {Record<string, any>} */
              {}, v[b] = y;
              for (var F in f)
                f.hasOwnProperty(F) && (y[F] = m(f[F], v));
              return (
                /** @type {any} */
                y
              );
            case "Array":
              return b = s.util.objId(f), v[b] ? v[b] : (y = [], v[b] = y, /** @type {Array} */
              /** @type {any} */
              f.forEach(function(A, E) {
                y[E] = m(A, v);
              }), /** @type {any} */
              y);
            default:
              return f;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(m) {
          for (; m; ) {
            var f = i.exec(m.className);
            if (f)
              return f[1].toLowerCase();
            m = m.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(m, f) {
          m.className = m.className.replace(RegExp(i, "gi"), ""), m.classList.add("language-" + f);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (y) {
            var m = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(y.stack) || [])[1];
            if (m) {
              var f = document.getElementsByTagName("script");
              for (var v in f)
                if (f[v].src == m)
                  return f[v];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(m, f, v) {
          for (var y = "no-" + f; m; ) {
            var b = m.classList;
            if (b.contains(f))
              return !0;
            if (b.contains(y))
              return !1;
            m = m.parentElement;
          }
          return !!v;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: o,
        plaintext: o,
        text: o,
        txt: o,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(m, f) {
          var v = s.util.clone(s.languages[m]);
          for (var y in f)
            v[y] = f[y];
          return v;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(m, f, v, y) {
          y = y || /** @type {any} */
          s.languages;
          var b = y[m], F = {};
          for (var A in b)
            if (b.hasOwnProperty(A)) {
              if (A == f)
                for (var E in v)
                  v.hasOwnProperty(E) && (F[E] = v[E]);
              v.hasOwnProperty(A) || (F[A] = b[A]);
            }
          var q = y[m];
          return y[m] = F, s.languages.DFS(s.languages, function(w, $) {
            $ === q && w != m && (this[w] = F);
          }), F;
        },
        // Traverse a language definition with Depth First Search
        DFS: function m(f, v, y, b) {
          b = b || {};
          var F = s.util.objId;
          for (var A in f)
            if (f.hasOwnProperty(A)) {
              v.call(f, A, f[A], y || A);
              var E = f[A], q = s.util.type(E);
              q === "Object" && !b[F(E)] ? (b[F(E)] = !0, m(E, v, null, b)) : q === "Array" && !b[F(E)] && (b[F(E)] = !0, m(E, v, A, b));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(m, f) {
        s.highlightAllUnder(document, m, f);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(m, f, v) {
        var y = {
          callback: v,
          container: m,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        s.hooks.run("before-highlightall", y), y.elements = Array.prototype.slice.apply(y.container.querySelectorAll(y.selector)), s.hooks.run("before-all-elements-highlight", y);
        for (var b = 0, F; F = y.elements[b++]; )
          s.highlightElement(F, f === !0, y.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(m, f, v) {
        var y = s.util.getLanguage(m), b = s.languages[y];
        s.util.setLanguage(m, y);
        var F = m.parentElement;
        F && F.nodeName.toLowerCase() === "pre" && s.util.setLanguage(F, y);
        var A = m.textContent, E = {
          element: m,
          language: y,
          grammar: b,
          code: A
        };
        function q($) {
          E.highlightedCode = $, s.hooks.run("before-insert", E), E.element.innerHTML = E.highlightedCode, s.hooks.run("after-highlight", E), s.hooks.run("complete", E), v && v.call(E.element);
        }
        if (s.hooks.run("before-sanity-check", E), F = E.element.parentElement, F && F.nodeName.toLowerCase() === "pre" && !F.hasAttribute("tabindex") && F.setAttribute("tabindex", "0"), !E.code) {
          s.hooks.run("complete", E), v && v.call(E.element);
          return;
        }
        if (s.hooks.run("before-highlight", E), !E.grammar) {
          q(s.util.encode(E.code));
          return;
        }
        if (f && n.Worker) {
          var w = new Worker(s.filename);
          w.onmessage = function($) {
            q($.data);
          }, w.postMessage(JSON.stringify({
            language: E.language,
            code: E.code,
            immediateClose: !0
          }));
        } else
          q(s.highlight(E.code, E.grammar, E.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(m, f, v) {
        var y = {
          code: m,
          grammar: f,
          language: v
        };
        if (s.hooks.run("before-tokenize", y), !y.grammar)
          throw new Error('The language "' + y.language + '" has no grammar.');
        return y.tokens = s.tokenize(y.code, y.grammar), s.hooks.run("after-tokenize", y), r.stringify(s.util.encode(y.tokens), y.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(m, f) {
        var v = f.rest;
        if (v) {
          for (var y in v)
            f[y] = v[y];
          delete f.rest;
        }
        var b = new d();
        return c(b, b.head, m), _(m, b, f, b.head, 0), g(b);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(m, f) {
          var v = s.hooks.all;
          v[m] = v[m] || [], v[m].push(f);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(m, f) {
          var v = s.hooks.all[m];
          if (!(!v || !v.length))
            for (var y = 0, b; b = v[y++]; )
              b(f);
        }
      },
      Token: r
    };
    n.Prism = s;
    function r(m, f, v, y) {
      this.type = m, this.content = f, this.alias = v, this.length = (y || "").length | 0;
    }
    r.stringify = function m(f, v) {
      if (typeof f == "string")
        return f;
      if (Array.isArray(f)) {
        var y = "";
        return f.forEach(function(q) {
          y += m(q, v);
        }), y;
      }
      var b = {
        type: f.type,
        content: m(f.content, v),
        tag: "span",
        classes: ["token", f.type],
        attributes: {},
        language: v
      }, F = f.alias;
      F && (Array.isArray(F) ? Array.prototype.push.apply(b.classes, F) : b.classes.push(F)), s.hooks.run("wrap", b);
      var A = "";
      for (var E in b.attributes)
        A += " " + E + '="' + (b.attributes[E] || "").replace(/"/g, "&quot;") + '"';
      return "<" + b.tag + ' class="' + b.classes.join(" ") + '"' + A + ">" + b.content + "</" + b.tag + ">";
    };
    function u(m, f, v, y) {
      m.lastIndex = f;
      var b = m.exec(v);
      if (b && y && b[1]) {
        var F = b[1].length;
        b.index += F, b[0] = b[0].slice(F);
      }
      return b;
    }
    function _(m, f, v, y, b, F) {
      for (var A in v)
        if (!(!v.hasOwnProperty(A) || !v[A])) {
          var E = v[A];
          E = Array.isArray(E) ? E : [E];
          for (var q = 0; q < E.length; ++q) {
            if (F && F.cause == A + "," + q)
              return;
            var w = E[q], $ = w.inside, ge = !!w.lookbehind, _e = !!w.greedy, Me = w.alias;
            if (_e && !w.pattern.global) {
              var ue = w.pattern.toString().match(/[imsuy]*$/)[0];
              w.pattern = RegExp(w.pattern.source, ue + "g");
            }
            for (var nt = w.pattern || w, Z = y.next, se = b; Z !== f.tail && !(F && se >= F.reach); se += Z.value.length, Z = Z.next) {
              var Se = Z.value;
              if (f.length > m.length)
                return;
              if (!(Se instanceof r)) {
                var C = 1, ee;
                if (_e) {
                  if (ee = u(nt, se, m, ge), !ee || ee.index >= m.length)
                    break;
                  var mt = ee.index, pt = ee.index + ee[0].length, ce = se;
                  for (ce += Z.value.length; mt >= ce; )
                    Z = Z.next, ce += Z.value.length;
                  if (ce -= Z.value.length, se = ce, Z.value instanceof r)
                    continue;
                  for (var S = Z; S !== f.tail && (ce < pt || typeof S.value == "string"); S = S.next)
                    C++, ce += S.value.length;
                  C--, Se = m.slice(se, ce), ee.index -= se;
                } else if (ee = u(nt, 0, Se, ge), !ee)
                  continue;
                var mt = ee.index, Xt = ee[0], mn = Se.slice(0, mt), Xn = Se.slice(mt + Xt.length), gn = se + Se.length;
                F && gn > F.reach && (F.reach = gn);
                var Yt = Z.prev;
                mn && (Yt = c(f, Yt, mn), se += mn.length), h(f, Yt, C);
                var ea = new r(A, $ ? s.tokenize(Xt, $) : Xt, Me, Xt);
                if (Z = c(f, Yt, ea), Xn && c(f, Z, Xn), C > 1) {
                  var vn = {
                    cause: A + "," + q,
                    reach: gn
                  };
                  _(m, f, v, Z.prev, se, vn), F && vn.reach > F.reach && (F.reach = vn.reach);
                }
              }
            }
          }
        }
    }
    function d() {
      var m = { value: null, prev: null, next: null }, f = { value: null, prev: m, next: null };
      m.next = f, this.head = m, this.tail = f, this.length = 0;
    }
    function c(m, f, v) {
      var y = f.next, b = { value: v, prev: f, next: y };
      return f.next = b, y.prev = b, m.length++, b;
    }
    function h(m, f, v) {
      for (var y = f.next, b = 0; b < v && y !== m.tail; b++)
        y = y.next;
      f.next = y, y.prev = f, m.length -= b;
    }
    function g(m) {
      for (var f = [], v = m.head.next; v !== m.tail; )
        f.push(v.value), v = v.next;
      return f;
    }
    if (!n.document)
      return n.addEventListener && (s.disableWorkerMessageHandler || n.addEventListener("message", function(m) {
        var f = JSON.parse(m.data), v = f.language, y = f.code, b = f.immediateClose;
        n.postMessage(s.highlight(y, s.languages[v], v)), b && n.close();
      }, !1)), s;
    var p = s.util.currentScript();
    p && (s.filename = p.src, p.hasAttribute("data-manual") && (s.manual = !0));
    function D() {
      s.manual || s.highlightAll();
    }
    if (!s.manual) {
      var k = document.readyState;
      k === "loading" || k === "interactive" && p && p.defer ? document.addEventListener("DOMContentLoaded", D) : window.requestAnimationFrame ? window.requestAnimationFrame(D) : window.setTimeout(D, 16);
    }
    return s;
  }(e);
  a.exports && (a.exports = t), typeof oi < "u" && (oi.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(i, l) {
      var o = {};
      o["language-" + l] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[l]
      }, o.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var s = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: o
        }
      };
      s["language-" + l] = {
        pattern: /[\s\S]+/,
        inside: t.languages[l]
      };
      var r = {};
      r[i] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return i;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: s
      }, t.languages.insertBefore("markup", "cdata", r);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, i) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [i, "language-" + i],
                inside: t.languages[i]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var i = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + i.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + i.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + i.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + i.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: i,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var l = n.languages.markup;
    l && (l.tag.addInlined("style", "css"), l.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", i = function(p, D) {
      return "✖ Error " + p + " while fetching file: " + D;
    }, l = "✖ Error: File does not exist or is empty", o = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, s = "data-src-status", r = "loading", u = "loaded", _ = "failed", d = "pre[data-src]:not([" + s + '="' + u + '"]):not([' + s + '="' + r + '"])';
    function c(p, D, k) {
      var m = new XMLHttpRequest();
      m.open("GET", p, !0), m.onreadystatechange = function() {
        m.readyState == 4 && (m.status < 400 && m.responseText ? D(m.responseText) : m.status >= 400 ? k(i(m.status, m.statusText)) : k(l));
      }, m.send(null);
    }
    function h(p) {
      var D = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(p || "");
      if (D) {
        var k = Number(D[1]), m = D[2], f = D[3];
        return m ? f ? [k, Number(f)] : [k, void 0] : [k, k];
      }
    }
    t.hooks.add("before-highlightall", function(p) {
      p.selector += ", " + d;
    }), t.hooks.add("before-sanity-check", function(p) {
      var D = (
        /** @type {HTMLPreElement} */
        p.element
      );
      if (D.matches(d)) {
        p.code = "", D.setAttribute(s, r);
        var k = D.appendChild(document.createElement("CODE"));
        k.textContent = n;
        var m = D.getAttribute("data-src"), f = p.language;
        if (f === "none") {
          var v = (/\.(\w+)$/.exec(m) || [, "none"])[1];
          f = o[v] || v;
        }
        t.util.setLanguage(k, f), t.util.setLanguage(D, f);
        var y = t.plugins.autoloader;
        y && y.loadLanguages(f), c(
          m,
          function(b) {
            D.setAttribute(s, u);
            var F = h(D.getAttribute("data-range"));
            if (F) {
              var A = b.split(/\r\n?|\n/g), E = F[0], q = F[1] == null ? A.length : F[1];
              E < 0 && (E += A.length), E = Math.max(0, Math.min(E - 1, A.length)), q < 0 && (q += A.length), q = Math.max(0, Math.min(q, A.length)), b = A.slice(E, q).join(`
`), D.hasAttribute("data-start") || D.setAttribute("data-start", String(E + 1));
            }
            k.textContent = b, t.highlightElement(k);
          },
          function(b) {
            D.setAttribute(s, _), k.textContent = b;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(D) {
        for (var k = (D || document).querySelectorAll(d), m = 0, f; f = k[m++]; )
          t.highlightElement(f);
      }
    };
    var g = !1;
    t.fileHighlight = function() {
      g || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), g = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(lo);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(a) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  a.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, a.languages.tex = a.languages.latex, a.languages.context = a.languages.latex;
})(Prism);
(function(a) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  a.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = a.languages.bash;
  for (var i = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], l = n.variable[1].inside, o = 0; o < i.length; o++)
    l[i[o]] = a.languages.bash[i[o]];
  a.languages.sh = a.languages.bash, a.languages.shell = a.languages.bash;
})(Prism);
new Ml();
const ao = (a) => {
  const e = {};
  for (let t = 0, n = a.length; t < n; t++) {
    const i = a[t];
    for (const l in i)
      e[l] ? e[l] = e[l].concat(i[l]) : e[l] = i[l];
  }
  return e;
}, oo = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], so = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], ro = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
ao([
  Object.fromEntries(oo.map((a) => [a, ["*"]])),
  Object.fromEntries(so.map((a) => [a, ["svg:*"]])),
  Object.fromEntries(ro.map((a) => [a, ["math:*"]]))
]);
const {
  HtmlTagHydration: Hr,
  SvelteComponent: xr,
  attr: Vr,
  binding_callbacks: Ur,
  children: Gr,
  claim_element: Zr,
  claim_html_tag: Xr,
  detach: Yr,
  element: Wr,
  init: Kr,
  insert_hydration: Qr,
  noop: Jr,
  safe_not_equal: eu,
  toggle_class: tu
} = window.__gradio__svelte__internal, { afterUpdate: nu, tick: iu, onMount: lu } = window.__gradio__svelte__internal, {
  SvelteComponent: au,
  attr: ou,
  children: su,
  claim_component: ru,
  claim_element: uu,
  create_component: _u,
  destroy_component: cu,
  detach: du,
  element: fu,
  init: hu,
  insert_hydration: pu,
  mount_component: mu,
  safe_not_equal: gu,
  transition_in: vu,
  transition_out: bu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Du,
  attr: yu,
  check_outros: wu,
  children: ku,
  claim_component: Fu,
  claim_element: $u,
  claim_space: Cu,
  create_component: Eu,
  create_slot: Au,
  destroy_component: Su,
  detach: Bu,
  element: qu,
  empty: Tu,
  get_all_dirty_from_scope: zu,
  get_slot_changes: Iu,
  group_outros: Ru,
  init: Lu,
  insert_hydration: Ou,
  mount_component: Pu,
  safe_not_equal: Mu,
  space: Nu,
  toggle_class: ju,
  transition_in: Hu,
  transition_out: xu,
  update_slot_base: Vu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uu,
  append_hydration: Gu,
  attr: Zu,
  children: Xu,
  claim_component: Yu,
  claim_element: Wu,
  claim_space: Ku,
  claim_text: Qu,
  create_component: Ju,
  destroy_component: e_,
  detach: t_,
  element: n_,
  init: i_,
  insert_hydration: l_,
  mount_component: a_,
  safe_not_equal: o_,
  set_data: s_,
  space: r_,
  text: u_,
  toggle_class: __,
  transition_in: c_,
  transition_out: d_
} = window.__gradio__svelte__internal, {
  SvelteComponent: uo,
  append_hydration: rn,
  attr: Xe,
  bubble: _o,
  check_outros: co,
  children: Sn,
  claim_component: fo,
  claim_element: Bn,
  claim_space: si,
  claim_text: ho,
  construct_svelte_component: ri,
  create_component: ui,
  create_slot: po,
  destroy_component: _i,
  detach: Tt,
  element: qn,
  get_all_dirty_from_scope: mo,
  get_slot_changes: go,
  group_outros: vo,
  init: bo,
  insert_hydration: Nl,
  listen: Do,
  mount_component: ci,
  safe_not_equal: yo,
  set_data: wo,
  set_style: Jt,
  space: di,
  text: ko,
  toggle_class: te,
  transition_in: yn,
  transition_out: wn,
  update_slot_base: Fo
} = window.__gradio__svelte__internal;
function fi(a) {
  let e, t;
  return {
    c() {
      e = qn("span"), t = ko(
        /*label*/
        a[1]
      ), this.h();
    },
    l(n) {
      e = Bn(n, "SPAN", { class: !0 });
      var i = Sn(e);
      t = ho(
        i,
        /*label*/
        a[1]
      ), i.forEach(Tt), this.h();
    },
    h() {
      Xe(e, "class", "svelte-qgco6m");
    },
    m(n, i) {
      Nl(n, e, i), rn(e, t);
    },
    p(n, i) {
      i & /*label*/
      2 && wo(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && Tt(e);
    }
  };
}
function $o(a) {
  let e, t, n, i, l, o, s, r, u = (
    /*show_label*/
    a[2] && fi(a)
  );
  var _ = (
    /*Icon*/
    a[0]
  );
  function d(g, p) {
    return {};
  }
  _ && (i = ri(_, d()));
  const c = (
    /*#slots*/
    a[14].default
  ), h = po(
    c,
    a,
    /*$$scope*/
    a[13],
    null
  );
  return {
    c() {
      e = qn("button"), u && u.c(), t = di(), n = qn("div"), i && ui(i.$$.fragment), l = di(), h && h.c(), this.h();
    },
    l(g) {
      e = Bn(g, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var p = Sn(e);
      u && u.l(p), t = si(p), n = Bn(p, "DIV", { class: !0 });
      var D = Sn(n);
      i && fo(i.$$.fragment, D), l = si(D), h && h.l(D), D.forEach(Tt), p.forEach(Tt), this.h();
    },
    h() {
      Xe(n, "class", "svelte-qgco6m"), te(
        n,
        "x-small",
        /*size*/
        a[4] === "x-small"
      ), te(
        n,
        "small",
        /*size*/
        a[4] === "small"
      ), te(
        n,
        "large",
        /*size*/
        a[4] === "large"
      ), te(
        n,
        "medium",
        /*size*/
        a[4] === "medium"
      ), e.disabled = /*disabled*/
      a[7], Xe(
        e,
        "aria-label",
        /*label*/
        a[1]
      ), Xe(
        e,
        "aria-haspopup",
        /*hasPopup*/
        a[8]
      ), Xe(
        e,
        "title",
        /*label*/
        a[1]
      ), Xe(e, "class", "svelte-qgco6m"), te(
        e,
        "pending",
        /*pending*/
        a[3]
      ), te(
        e,
        "padded",
        /*padded*/
        a[5]
      ), te(
        e,
        "highlight",
        /*highlight*/
        a[6]
      ), te(
        e,
        "transparent",
        /*transparent*/
        a[9]
      ), Jt(e, "color", !/*disabled*/
      a[7] && /*_color*/
      a[11] ? (
        /*_color*/
        a[11]
      ) : "var(--block-label-text-color)"), Jt(e, "--bg-color", /*disabled*/
      a[7] ? "auto" : (
        /*background*/
        a[10]
      ));
    },
    m(g, p) {
      Nl(g, e, p), u && u.m(e, null), rn(e, t), rn(e, n), i && ci(i, n, null), rn(n, l), h && h.m(n, null), o = !0, s || (r = Do(
        e,
        "click",
        /*click_handler*/
        a[15]
      ), s = !0);
    },
    p(g, [p]) {
      if (/*show_label*/
      g[2] ? u ? u.p(g, p) : (u = fi(g), u.c(), u.m(e, t)) : u && (u.d(1), u = null), p & /*Icon*/
      1 && _ !== (_ = /*Icon*/
      g[0])) {
        if (i) {
          vo();
          const D = i;
          wn(D.$$.fragment, 1, 0, () => {
            _i(D, 1);
          }), co();
        }
        _ ? (i = ri(_, d()), ui(i.$$.fragment), yn(i.$$.fragment, 1), ci(i, n, l)) : i = null;
      }
      h && h.p && (!o || p & /*$$scope*/
      8192) && Fo(
        h,
        c,
        g,
        /*$$scope*/
        g[13],
        o ? go(
          c,
          /*$$scope*/
          g[13],
          p,
          null
        ) : mo(
          /*$$scope*/
          g[13]
        ),
        null
      ), (!o || p & /*size*/
      16) && te(
        n,
        "x-small",
        /*size*/
        g[4] === "x-small"
      ), (!o || p & /*size*/
      16) && te(
        n,
        "small",
        /*size*/
        g[4] === "small"
      ), (!o || p & /*size*/
      16) && te(
        n,
        "large",
        /*size*/
        g[4] === "large"
      ), (!o || p & /*size*/
      16) && te(
        n,
        "medium",
        /*size*/
        g[4] === "medium"
      ), (!o || p & /*disabled*/
      128) && (e.disabled = /*disabled*/
      g[7]), (!o || p & /*label*/
      2) && Xe(
        e,
        "aria-label",
        /*label*/
        g[1]
      ), (!o || p & /*hasPopup*/
      256) && Xe(
        e,
        "aria-haspopup",
        /*hasPopup*/
        g[8]
      ), (!o || p & /*label*/
      2) && Xe(
        e,
        "title",
        /*label*/
        g[1]
      ), (!o || p & /*pending*/
      8) && te(
        e,
        "pending",
        /*pending*/
        g[3]
      ), (!o || p & /*padded*/
      32) && te(
        e,
        "padded",
        /*padded*/
        g[5]
      ), (!o || p & /*highlight*/
      64) && te(
        e,
        "highlight",
        /*highlight*/
        g[6]
      ), (!o || p & /*transparent*/
      512) && te(
        e,
        "transparent",
        /*transparent*/
        g[9]
      ), p & /*disabled, _color*/
      2176 && Jt(e, "color", !/*disabled*/
      g[7] && /*_color*/
      g[11] ? (
        /*_color*/
        g[11]
      ) : "var(--block-label-text-color)"), p & /*disabled, background*/
      1152 && Jt(e, "--bg-color", /*disabled*/
      g[7] ? "auto" : (
        /*background*/
        g[10]
      ));
    },
    i(g) {
      o || (i && yn(i.$$.fragment, g), yn(h, g), o = !0);
    },
    o(g) {
      i && wn(i.$$.fragment, g), wn(h, g), o = !1;
    },
    d(g) {
      g && Tt(e), u && u.d(), i && _i(i), h && h.d(g), s = !1, r();
    }
  };
}
function Co(a, e, t) {
  let n, { $$slots: i = {}, $$scope: l } = e, { Icon: o } = e, { label: s = "" } = e, { show_label: r = !1 } = e, { pending: u = !1 } = e, { size: _ = "small" } = e, { padded: d = !0 } = e, { highlight: c = !1 } = e, { disabled: h = !1 } = e, { hasPopup: g = !1 } = e, { color: p = "var(--block-label-text-color)" } = e, { transparent: D = !1 } = e, { background: k = "var(--block-background-fill)" } = e;
  function m(f) {
    _o.call(this, a, f);
  }
  return a.$$set = (f) => {
    "Icon" in f && t(0, o = f.Icon), "label" in f && t(1, s = f.label), "show_label" in f && t(2, r = f.show_label), "pending" in f && t(3, u = f.pending), "size" in f && t(4, _ = f.size), "padded" in f && t(5, d = f.padded), "highlight" in f && t(6, c = f.highlight), "disabled" in f && t(7, h = f.disabled), "hasPopup" in f && t(8, g = f.hasPopup), "color" in f && t(12, p = f.color), "transparent" in f && t(9, D = f.transparent), "background" in f && t(10, k = f.background), "$$scope" in f && t(13, l = f.$$scope);
  }, a.$$.update = () => {
    a.$$.dirty & /*highlight, color*/
    4160 && t(11, n = c ? "var(--color-accent)" : p);
  }, [
    o,
    s,
    r,
    u,
    _,
    d,
    c,
    h,
    g,
    D,
    k,
    n,
    p,
    l,
    i,
    m
  ];
}
class Eo extends uo {
  constructor(e) {
    super(), bo(this, e, Co, $o, yo, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: f_,
  append_hydration: h_,
  attr: p_,
  binding_callbacks: m_,
  children: g_,
  claim_element: v_,
  create_slot: b_,
  detach: D_,
  element: y_,
  get_all_dirty_from_scope: w_,
  get_slot_changes: k_,
  init: F_,
  insert_hydration: $_,
  safe_not_equal: C_,
  toggle_class: E_,
  transition_in: A_,
  transition_out: S_,
  update_slot_base: B_
} = window.__gradio__svelte__internal, {
  SvelteComponent: q_,
  append_hydration: T_,
  attr: z_,
  children: I_,
  claim_svg_element: R_,
  detach: L_,
  init: O_,
  insert_hydration: P_,
  noop: M_,
  safe_not_equal: N_,
  svg_element: j_
} = window.__gradio__svelte__internal, {
  SvelteComponent: H_,
  append_hydration: x_,
  attr: V_,
  children: U_,
  claim_svg_element: G_,
  detach: Z_,
  init: X_,
  insert_hydration: Y_,
  noop: W_,
  safe_not_equal: K_,
  svg_element: Q_
} = window.__gradio__svelte__internal, {
  SvelteComponent: J_,
  append_hydration: ec,
  attr: tc,
  children: nc,
  claim_svg_element: ic,
  detach: lc,
  init: ac,
  insert_hydration: oc,
  noop: sc,
  safe_not_equal: rc,
  svg_element: uc
} = window.__gradio__svelte__internal, {
  SvelteComponent: _c,
  append_hydration: cc,
  attr: dc,
  children: fc,
  claim_svg_element: hc,
  detach: pc,
  init: mc,
  insert_hydration: gc,
  noop: vc,
  safe_not_equal: bc,
  svg_element: Dc
} = window.__gradio__svelte__internal, {
  SvelteComponent: yc,
  append_hydration: wc,
  attr: kc,
  children: Fc,
  claim_svg_element: $c,
  detach: Cc,
  init: Ec,
  insert_hydration: Ac,
  noop: Sc,
  safe_not_equal: Bc,
  svg_element: qc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tc,
  append_hydration: zc,
  attr: Ic,
  children: Rc,
  claim_svg_element: Lc,
  detach: Oc,
  init: Pc,
  insert_hydration: Mc,
  noop: Nc,
  safe_not_equal: jc,
  svg_element: Hc
} = window.__gradio__svelte__internal, {
  SvelteComponent: xc,
  append_hydration: Vc,
  attr: Uc,
  children: Gc,
  claim_svg_element: Zc,
  detach: Xc,
  init: Yc,
  insert_hydration: Wc,
  noop: Kc,
  safe_not_equal: Qc,
  svg_element: Jc
} = window.__gradio__svelte__internal, {
  SvelteComponent: ed,
  append_hydration: td,
  attr: nd,
  children: id,
  claim_svg_element: ld,
  detach: ad,
  init: od,
  insert_hydration: sd,
  noop: rd,
  safe_not_equal: ud,
  svg_element: _d
} = window.__gradio__svelte__internal, {
  SvelteComponent: cd,
  append_hydration: dd,
  attr: fd,
  children: hd,
  claim_svg_element: pd,
  detach: md,
  init: gd,
  insert_hydration: vd,
  noop: bd,
  safe_not_equal: Dd,
  svg_element: yd
} = window.__gradio__svelte__internal, {
  SvelteComponent: wd,
  append_hydration: kd,
  attr: Fd,
  children: $d,
  claim_svg_element: Cd,
  detach: Ed,
  init: Ad,
  insert_hydration: Sd,
  noop: Bd,
  safe_not_equal: qd,
  svg_element: Td
} = window.__gradio__svelte__internal, {
  SvelteComponent: zd,
  append_hydration: Id,
  attr: Rd,
  children: Ld,
  claim_svg_element: Od,
  detach: Pd,
  init: Md,
  insert_hydration: Nd,
  noop: jd,
  safe_not_equal: Hd,
  svg_element: xd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vd,
  append_hydration: Ud,
  attr: Gd,
  children: Zd,
  claim_svg_element: Xd,
  detach: Yd,
  init: Wd,
  insert_hydration: Kd,
  noop: Qd,
  safe_not_equal: Jd,
  svg_element: ef
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ao,
  append_hydration: kn,
  attr: Be,
  children: en,
  claim_svg_element: tn,
  detach: Et,
  init: So,
  insert_hydration: Bo,
  noop: Fn,
  safe_not_equal: qo,
  set_style: Ne,
  svg_element: nn
} = window.__gradio__svelte__internal;
function To(a) {
  let e, t, n, i;
  return {
    c() {
      e = nn("svg"), t = nn("g"), n = nn("path"), i = nn("path"), this.h();
    },
    l(l) {
      e = tn(l, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var o = en(e);
      t = tn(o, "g", { transform: !0 });
      var s = en(t);
      n = tn(s, "path", { d: !0, style: !0 }), en(n).forEach(Et), s.forEach(Et), i = tn(o, "path", { d: !0, style: !0 }), en(i).forEach(Et), o.forEach(Et), this.h();
    },
    h() {
      Be(n, "d", "M18,6L6.087,17.913"), Ne(n, "fill", "none"), Ne(n, "fill-rule", "nonzero"), Ne(n, "stroke-width", "2px"), Be(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Be(i, "d", "M4.364,4.364L19.636,19.636"), Ne(i, "fill", "none"), Ne(i, "fill-rule", "nonzero"), Ne(i, "stroke-width", "2px"), Be(e, "width", "100%"), Be(e, "height", "100%"), Be(e, "viewBox", "0 0 24 24"), Be(e, "version", "1.1"), Be(e, "xmlns", "http://www.w3.org/2000/svg"), Be(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Be(e, "xml:space", "preserve"), Be(e, "stroke", "currentColor"), Ne(e, "fill-rule", "evenodd"), Ne(e, "clip-rule", "evenodd"), Ne(e, "stroke-linecap", "round"), Ne(e, "stroke-linejoin", "round");
    },
    m(l, o) {
      Bo(l, e, o), kn(e, t), kn(t, n), kn(e, i);
    },
    p: Fn,
    i: Fn,
    o: Fn,
    d(l) {
      l && Et(e);
    }
  };
}
class zo extends Ao {
  constructor(e) {
    super(), So(this, e, null, To, qo, {});
  }
}
const {
  SvelteComponent: tf,
  append_hydration: nf,
  attr: lf,
  children: af,
  claim_svg_element: of,
  detach: sf,
  init: rf,
  insert_hydration: uf,
  noop: _f,
  safe_not_equal: cf,
  svg_element: df
} = window.__gradio__svelte__internal, {
  SvelteComponent: ff,
  append_hydration: hf,
  attr: pf,
  children: mf,
  claim_svg_element: gf,
  detach: vf,
  init: bf,
  insert_hydration: Df,
  noop: yf,
  safe_not_equal: wf,
  svg_element: kf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ff,
  append_hydration: $f,
  attr: Cf,
  children: Ef,
  claim_svg_element: Af,
  detach: Sf,
  init: Bf,
  insert_hydration: qf,
  noop: Tf,
  safe_not_equal: zf,
  svg_element: If
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rf,
  append_hydration: Lf,
  attr: Of,
  children: Pf,
  claim_svg_element: Mf,
  detach: Nf,
  init: jf,
  insert_hydration: Hf,
  noop: xf,
  safe_not_equal: Vf,
  svg_element: Uf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gf,
  append_hydration: Zf,
  attr: Xf,
  children: Yf,
  claim_svg_element: Wf,
  detach: Kf,
  init: Qf,
  insert_hydration: Jf,
  noop: eh,
  safe_not_equal: th,
  svg_element: nh
} = window.__gradio__svelte__internal, {
  SvelteComponent: ih,
  append_hydration: lh,
  attr: ah,
  children: oh,
  claim_svg_element: sh,
  detach: rh,
  init: uh,
  insert_hydration: _h,
  noop: ch,
  safe_not_equal: dh,
  svg_element: fh
} = window.__gradio__svelte__internal, {
  SvelteComponent: hh,
  append_hydration: ph,
  attr: mh,
  children: gh,
  claim_svg_element: vh,
  detach: bh,
  init: Dh,
  insert_hydration: yh,
  noop: wh,
  safe_not_equal: kh,
  svg_element: Fh
} = window.__gradio__svelte__internal, {
  SvelteComponent: $h,
  append_hydration: Ch,
  attr: Eh,
  children: Ah,
  claim_svg_element: Sh,
  detach: Bh,
  init: qh,
  insert_hydration: Th,
  noop: zh,
  safe_not_equal: Ih,
  svg_element: Rh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lh,
  append_hydration: Oh,
  attr: Ph,
  children: Mh,
  claim_svg_element: Nh,
  detach: jh,
  init: Hh,
  insert_hydration: xh,
  noop: Vh,
  safe_not_equal: Uh,
  svg_element: Gh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zh,
  append_hydration: Xh,
  attr: Yh,
  children: Wh,
  claim_svg_element: Kh,
  detach: Qh,
  init: Jh,
  insert_hydration: ep,
  noop: tp,
  safe_not_equal: np,
  svg_element: ip
} = window.__gradio__svelte__internal, {
  SvelteComponent: lp,
  append_hydration: ap,
  attr: op,
  children: sp,
  claim_svg_element: rp,
  detach: up,
  init: _p,
  insert_hydration: cp,
  noop: dp,
  safe_not_equal: fp,
  svg_element: hp
} = window.__gradio__svelte__internal, {
  SvelteComponent: pp,
  append_hydration: mp,
  attr: gp,
  children: vp,
  claim_svg_element: bp,
  detach: Dp,
  init: yp,
  insert_hydration: wp,
  noop: kp,
  safe_not_equal: Fp,
  svg_element: $p
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cp,
  append_hydration: Ep,
  attr: Ap,
  children: Sp,
  claim_svg_element: Bp,
  detach: qp,
  init: Tp,
  insert_hydration: zp,
  noop: Ip,
  safe_not_equal: Rp,
  svg_element: Lp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Op,
  append_hydration: Pp,
  attr: Mp,
  children: Np,
  claim_svg_element: jp,
  detach: Hp,
  init: xp,
  insert_hydration: Vp,
  noop: Up,
  safe_not_equal: Gp,
  svg_element: Zp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xp,
  append_hydration: Yp,
  attr: Wp,
  children: Kp,
  claim_svg_element: Qp,
  detach: Jp,
  init: em,
  insert_hydration: tm,
  noop: nm,
  safe_not_equal: im,
  svg_element: lm
} = window.__gradio__svelte__internal, {
  SvelteComponent: am,
  append_hydration: om,
  attr: sm,
  children: rm,
  claim_svg_element: um,
  detach: _m,
  init: cm,
  insert_hydration: dm,
  noop: fm,
  safe_not_equal: hm,
  svg_element: pm
} = window.__gradio__svelte__internal, {
  SvelteComponent: mm,
  append_hydration: gm,
  attr: vm,
  children: bm,
  claim_svg_element: Dm,
  detach: ym,
  init: wm,
  insert_hydration: km,
  noop: Fm,
  safe_not_equal: $m,
  svg_element: Cm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Em,
  append_hydration: Am,
  attr: Sm,
  children: Bm,
  claim_svg_element: qm,
  detach: Tm,
  init: zm,
  insert_hydration: Im,
  noop: Rm,
  safe_not_equal: Lm,
  svg_element: Om
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pm,
  append_hydration: Mm,
  attr: Nm,
  children: jm,
  claim_svg_element: Hm,
  detach: xm,
  init: Vm,
  insert_hydration: Um,
  noop: Gm,
  safe_not_equal: Zm,
  svg_element: Xm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ym,
  append_hydration: Wm,
  attr: Km,
  children: Qm,
  claim_svg_element: Jm,
  detach: e0,
  init: t0,
  insert_hydration: n0,
  noop: i0,
  safe_not_equal: l0,
  svg_element: a0
} = window.__gradio__svelte__internal, {
  SvelteComponent: o0,
  append_hydration: s0,
  attr: r0,
  children: u0,
  claim_svg_element: _0,
  detach: c0,
  init: d0,
  insert_hydration: f0,
  noop: h0,
  safe_not_equal: p0,
  svg_element: m0
} = window.__gradio__svelte__internal, {
  SvelteComponent: g0,
  append_hydration: v0,
  attr: b0,
  children: D0,
  claim_svg_element: y0,
  detach: w0,
  init: k0,
  insert_hydration: F0,
  noop: $0,
  safe_not_equal: C0,
  svg_element: E0
} = window.__gradio__svelte__internal, {
  SvelteComponent: A0,
  append_hydration: S0,
  attr: B0,
  children: q0,
  claim_svg_element: T0,
  detach: z0,
  init: I0,
  insert_hydration: R0,
  noop: L0,
  safe_not_equal: O0,
  svg_element: P0
} = window.__gradio__svelte__internal, {
  SvelteComponent: M0,
  append_hydration: N0,
  attr: j0,
  children: H0,
  claim_svg_element: x0,
  detach: V0,
  init: U0,
  insert_hydration: G0,
  noop: Z0,
  safe_not_equal: X0,
  svg_element: Y0
} = window.__gradio__svelte__internal, {
  SvelteComponent: W0,
  append_hydration: K0,
  attr: Q0,
  children: J0,
  claim_svg_element: eg,
  detach: tg,
  init: ng,
  insert_hydration: ig,
  noop: lg,
  safe_not_equal: ag,
  svg_element: og
} = window.__gradio__svelte__internal, {
  SvelteComponent: sg,
  append_hydration: rg,
  attr: ug,
  children: _g,
  claim_svg_element: cg,
  detach: dg,
  init: fg,
  insert_hydration: hg,
  noop: pg,
  safe_not_equal: mg,
  svg_element: gg
} = window.__gradio__svelte__internal, {
  SvelteComponent: vg,
  append_hydration: bg,
  attr: Dg,
  children: yg,
  claim_svg_element: wg,
  detach: kg,
  init: Fg,
  insert_hydration: $g,
  noop: Cg,
  safe_not_equal: Eg,
  svg_element: Ag
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sg,
  append_hydration: Bg,
  attr: qg,
  children: Tg,
  claim_svg_element: zg,
  detach: Ig,
  init: Rg,
  insert_hydration: Lg,
  noop: Og,
  safe_not_equal: Pg,
  svg_element: Mg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ng,
  append_hydration: jg,
  attr: Hg,
  children: xg,
  claim_svg_element: Vg,
  detach: Ug,
  init: Gg,
  insert_hydration: Zg,
  noop: Xg,
  safe_not_equal: Yg,
  svg_element: Wg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kg,
  append_hydration: Qg,
  attr: Jg,
  children: e1,
  claim_svg_element: t1,
  detach: n1,
  init: i1,
  insert_hydration: l1,
  noop: a1,
  safe_not_equal: o1,
  svg_element: s1
} = window.__gradio__svelte__internal, {
  SvelteComponent: r1,
  append_hydration: u1,
  attr: _1,
  children: c1,
  claim_svg_element: d1,
  detach: f1,
  init: h1,
  insert_hydration: p1,
  noop: m1,
  safe_not_equal: g1,
  svg_element: v1
} = window.__gradio__svelte__internal, {
  SvelteComponent: b1,
  append_hydration: D1,
  attr: y1,
  children: w1,
  claim_svg_element: k1,
  detach: F1,
  init: $1,
  insert_hydration: C1,
  noop: E1,
  safe_not_equal: A1,
  svg_element: S1
} = window.__gradio__svelte__internal, {
  SvelteComponent: B1,
  append_hydration: q1,
  attr: T1,
  children: z1,
  claim_svg_element: I1,
  detach: R1,
  init: L1,
  insert_hydration: O1,
  noop: P1,
  safe_not_equal: M1,
  svg_element: N1
} = window.__gradio__svelte__internal, {
  SvelteComponent: j1,
  append_hydration: H1,
  attr: x1,
  children: V1,
  claim_svg_element: U1,
  detach: G1,
  init: Z1,
  insert_hydration: X1,
  noop: Y1,
  safe_not_equal: W1,
  set_style: K1,
  svg_element: Q1
} = window.__gradio__svelte__internal, {
  SvelteComponent: J1,
  append_hydration: ev,
  attr: tv,
  children: nv,
  claim_svg_element: iv,
  detach: lv,
  init: av,
  insert_hydration: ov,
  noop: sv,
  safe_not_equal: rv,
  svg_element: uv
} = window.__gradio__svelte__internal, {
  SvelteComponent: _v,
  append_hydration: cv,
  attr: dv,
  children: fv,
  claim_svg_element: hv,
  detach: pv,
  init: mv,
  insert_hydration: gv,
  noop: vv,
  safe_not_equal: bv,
  svg_element: Dv
} = window.__gradio__svelte__internal, {
  SvelteComponent: yv,
  append_hydration: wv,
  attr: kv,
  children: Fv,
  claim_svg_element: $v,
  detach: Cv,
  init: Ev,
  insert_hydration: Av,
  noop: Sv,
  safe_not_equal: Bv,
  svg_element: qv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tv,
  append_hydration: zv,
  attr: Iv,
  children: Rv,
  claim_svg_element: Lv,
  detach: Ov,
  init: Pv,
  insert_hydration: Mv,
  noop: Nv,
  safe_not_equal: jv,
  svg_element: Hv
} = window.__gradio__svelte__internal, {
  SvelteComponent: xv,
  append_hydration: Vv,
  attr: Uv,
  children: Gv,
  claim_svg_element: Zv,
  detach: Xv,
  init: Yv,
  insert_hydration: Wv,
  noop: Kv,
  safe_not_equal: Qv,
  svg_element: Jv
} = window.__gradio__svelte__internal, {
  SvelteComponent: eb,
  append_hydration: tb,
  attr: nb,
  children: ib,
  claim_svg_element: lb,
  detach: ab,
  init: ob,
  insert_hydration: sb,
  noop: rb,
  safe_not_equal: ub,
  svg_element: _b
} = window.__gradio__svelte__internal, {
  SvelteComponent: cb,
  append_hydration: db,
  attr: fb,
  children: hb,
  claim_svg_element: pb,
  detach: mb,
  init: gb,
  insert_hydration: vb,
  noop: bb,
  safe_not_equal: Db,
  svg_element: yb
} = window.__gradio__svelte__internal, {
  SvelteComponent: wb,
  append_hydration: kb,
  attr: Fb,
  children: $b,
  claim_svg_element: Cb,
  detach: Eb,
  init: Ab,
  insert_hydration: Sb,
  noop: Bb,
  safe_not_equal: qb,
  svg_element: Tb
} = window.__gradio__svelte__internal, {
  SvelteComponent: zb,
  append_hydration: Ib,
  attr: Rb,
  children: Lb,
  claim_svg_element: Ob,
  claim_text: Pb,
  detach: Mb,
  init: Nb,
  insert_hydration: jb,
  noop: Hb,
  safe_not_equal: xb,
  svg_element: Vb,
  text: Ub
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gb,
  append_hydration: Zb,
  attr: Xb,
  children: Yb,
  claim_svg_element: Wb,
  detach: Kb,
  init: Qb,
  insert_hydration: Jb,
  noop: eD,
  safe_not_equal: tD,
  svg_element: nD
} = window.__gradio__svelte__internal, {
  SvelteComponent: iD,
  append_hydration: lD,
  attr: aD,
  children: oD,
  claim_svg_element: sD,
  detach: rD,
  init: uD,
  insert_hydration: _D,
  noop: cD,
  safe_not_equal: dD,
  svg_element: fD
} = window.__gradio__svelte__internal, {
  SvelteComponent: hD,
  append_hydration: pD,
  attr: mD,
  children: gD,
  claim_svg_element: vD,
  detach: bD,
  init: DD,
  insert_hydration: yD,
  noop: wD,
  safe_not_equal: kD,
  svg_element: FD
} = window.__gradio__svelte__internal, {
  SvelteComponent: $D,
  append_hydration: CD,
  attr: ED,
  children: AD,
  claim_svg_element: SD,
  detach: BD,
  init: qD,
  insert_hydration: TD,
  noop: zD,
  safe_not_equal: ID,
  svg_element: RD
} = window.__gradio__svelte__internal, {
  SvelteComponent: LD,
  append_hydration: OD,
  attr: PD,
  children: MD,
  claim_svg_element: ND,
  detach: jD,
  init: HD,
  insert_hydration: xD,
  noop: VD,
  safe_not_equal: UD,
  svg_element: GD
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZD,
  append_hydration: XD,
  attr: YD,
  children: WD,
  claim_svg_element: KD,
  detach: QD,
  init: JD,
  insert_hydration: ey,
  noop: ty,
  safe_not_equal: ny,
  svg_element: iy
} = window.__gradio__svelte__internal, {
  SvelteComponent: ly,
  append_hydration: ay,
  attr: oy,
  children: sy,
  claim_svg_element: ry,
  detach: uy,
  init: _y,
  insert_hydration: cy,
  noop: dy,
  safe_not_equal: fy,
  svg_element: hy
} = window.__gradio__svelte__internal, {
  SvelteComponent: py,
  append_hydration: my,
  attr: gy,
  children: vy,
  claim_svg_element: by,
  claim_text: Dy,
  detach: yy,
  init: wy,
  insert_hydration: ky,
  noop: Fy,
  safe_not_equal: $y,
  svg_element: Cy,
  text: Ey
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ay,
  append_hydration: Sy,
  attr: By,
  children: qy,
  claim_svg_element: Ty,
  claim_text: zy,
  detach: Iy,
  init: Ry,
  insert_hydration: Ly,
  noop: Oy,
  safe_not_equal: Py,
  svg_element: My,
  text: Ny
} = window.__gradio__svelte__internal, {
  SvelteComponent: jy,
  append_hydration: Hy,
  attr: xy,
  children: Vy,
  claim_svg_element: Uy,
  claim_text: Gy,
  detach: Zy,
  init: Xy,
  insert_hydration: Yy,
  noop: Wy,
  safe_not_equal: Ky,
  svg_element: Qy,
  text: Jy
} = window.__gradio__svelte__internal, {
  SvelteComponent: e2,
  append_hydration: t2,
  attr: n2,
  children: i2,
  claim_svg_element: l2,
  detach: a2,
  init: o2,
  insert_hydration: s2,
  noop: r2,
  safe_not_equal: u2,
  svg_element: _2
} = window.__gradio__svelte__internal, {
  SvelteComponent: c2,
  append_hydration: d2,
  attr: f2,
  children: h2,
  claim_svg_element: p2,
  detach: m2,
  init: g2,
  insert_hydration: v2,
  noop: b2,
  safe_not_equal: D2,
  svg_element: y2
} = window.__gradio__svelte__internal, {
  SvelteComponent: w2,
  append_hydration: k2,
  attr: F2,
  children: $2,
  claim_svg_element: C2,
  detach: E2,
  init: A2,
  insert_hydration: S2,
  noop: B2,
  safe_not_equal: q2,
  svg_element: T2
} = window.__gradio__svelte__internal, {
  SvelteComponent: z2,
  append_hydration: I2,
  attr: R2,
  children: L2,
  claim_svg_element: O2,
  detach: P2,
  init: M2,
  insert_hydration: N2,
  noop: j2,
  safe_not_equal: H2,
  svg_element: x2
} = window.__gradio__svelte__internal, {
  SvelteComponent: V2,
  append_hydration: U2,
  attr: G2,
  children: Z2,
  claim_svg_element: X2,
  detach: Y2,
  init: W2,
  insert_hydration: K2,
  noop: Q2,
  safe_not_equal: J2,
  svg_element: ew
} = window.__gradio__svelte__internal, {
  SvelteComponent: tw,
  append_hydration: nw,
  attr: iw,
  children: lw,
  claim_svg_element: aw,
  detach: ow,
  init: sw,
  insert_hydration: rw,
  noop: uw,
  safe_not_equal: _w,
  svg_element: cw
} = window.__gradio__svelte__internal, {
  SvelteComponent: dw,
  append_hydration: fw,
  attr: hw,
  children: pw,
  claim_svg_element: mw,
  detach: gw,
  init: vw,
  insert_hydration: bw,
  noop: Dw,
  safe_not_equal: yw,
  svg_element: ww
} = window.__gradio__svelte__internal, {
  SvelteComponent: kw,
  append_hydration: Fw,
  attr: $w,
  children: Cw,
  claim_svg_element: Ew,
  detach: Aw,
  init: Sw,
  insert_hydration: Bw,
  noop: qw,
  safe_not_equal: Tw,
  svg_element: zw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Iw,
  append_hydration: Rw,
  attr: Lw,
  children: Ow,
  claim_svg_element: Pw,
  detach: Mw,
  init: Nw,
  insert_hydration: jw,
  noop: Hw,
  safe_not_equal: xw,
  svg_element: Vw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uw,
  append_hydration: Gw,
  attr: Zw,
  children: Xw,
  claim_svg_element: Yw,
  detach: Ww,
  init: Kw,
  insert_hydration: Qw,
  noop: Jw,
  safe_not_equal: ek,
  svg_element: tk
} = window.__gradio__svelte__internal, {
  SvelteComponent: nk,
  append_hydration: ik,
  attr: lk,
  children: ak,
  claim_svg_element: ok,
  detach: sk,
  init: rk,
  insert_hydration: uk,
  noop: _k,
  safe_not_equal: ck,
  svg_element: dk
} = window.__gradio__svelte__internal, Io = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], hi = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Io.reduce(
  (a, { color: e, primary: t, secondary: n }) => ({
    ...a,
    [e]: {
      primary: hi[e][t],
      secondary: hi[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: fk,
  claim_component: hk,
  create_component: pk,
  destroy_component: mk,
  init: gk,
  mount_component: vk,
  safe_not_equal: bk,
  transition_in: Dk,
  transition_out: yk
} = window.__gradio__svelte__internal, { createEventDispatcher: wk } = window.__gradio__svelte__internal, {
  SvelteComponent: kk,
  append_hydration: Fk,
  attr: $k,
  check_outros: Ck,
  children: Ek,
  claim_component: Ak,
  claim_element: Sk,
  claim_space: Bk,
  claim_text: qk,
  create_component: Tk,
  destroy_component: zk,
  detach: Ik,
  element: Rk,
  empty: Lk,
  group_outros: Ok,
  init: Pk,
  insert_hydration: Mk,
  mount_component: Nk,
  safe_not_equal: jk,
  set_data: Hk,
  space: xk,
  text: Vk,
  toggle_class: Uk,
  transition_in: Gk,
  transition_out: Zk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xk,
  attr: Yk,
  children: Wk,
  claim_element: Kk,
  create_slot: Qk,
  detach: Jk,
  element: eF,
  get_all_dirty_from_scope: tF,
  get_slot_changes: nF,
  init: iF,
  insert_hydration: lF,
  safe_not_equal: aF,
  toggle_class: oF,
  transition_in: sF,
  transition_out: rF,
  update_slot_base: uF
} = window.__gradio__svelte__internal, {
  SvelteComponent: _F,
  append_hydration: cF,
  attr: dF,
  check_outros: fF,
  children: hF,
  claim_component: pF,
  claim_element: mF,
  claim_space: gF,
  create_component: vF,
  destroy_component: bF,
  detach: DF,
  element: yF,
  empty: wF,
  group_outros: kF,
  init: FF,
  insert_hydration: $F,
  listen: CF,
  mount_component: EF,
  safe_not_equal: AF,
  space: SF,
  toggle_class: BF,
  transition_in: qF,
  transition_out: TF
} = window.__gradio__svelte__internal, {
  SvelteComponent: zF,
  attr: IF,
  children: RF,
  claim_element: LF,
  create_slot: OF,
  detach: PF,
  element: MF,
  get_all_dirty_from_scope: NF,
  get_slot_changes: jF,
  init: HF,
  insert_hydration: xF,
  null_to_empty: VF,
  safe_not_equal: UF,
  transition_in: GF,
  transition_out: ZF,
  update_slot_base: XF
} = window.__gradio__svelte__internal, {
  SvelteComponent: YF,
  check_outros: WF,
  claim_component: KF,
  create_component: QF,
  destroy_component: JF,
  detach: e$,
  empty: t$,
  group_outros: n$,
  init: i$,
  insert_hydration: l$,
  mount_component: a$,
  noop: o$,
  safe_not_equal: s$,
  transition_in: r$,
  transition_out: u$
} = window.__gradio__svelte__internal, { createEventDispatcher: _$ } = window.__gradio__svelte__internal;
function vt(a) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; a > 1e3 && t < e.length - 1; )
    a /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(a) ? a : a.toFixed(1)) + n;
}
function un() {
}
const jl = typeof window < "u";
let pi = jl ? () => window.performance.now() : () => Date.now(), Hl = jl ? (a) => requestAnimationFrame(a) : un;
const bt = /* @__PURE__ */ new Set();
function xl(a) {
  bt.forEach((e) => {
    e.c(a) || (bt.delete(e), e.f());
  }), bt.size !== 0 && Hl(xl);
}
function Ro(a) {
  let e;
  return bt.size === 0 && Hl(xl), { promise: new Promise((t) => {
    bt.add(e = { c: a, f: t });
  }), abort() {
    bt.delete(e);
  } };
}
const gt = [];
function Lo(a, e = un) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function i(o) {
    if (r = o, ((s = a) != s ? r == r : s !== r || s && typeof s == "object" || typeof s == "function") && (a = o, t)) {
      const u = !gt.length;
      for (const _ of n) _[1](), gt.push(_, a);
      if (u) {
        for (let _ = 0; _ < gt.length; _ += 2) gt[_][0](gt[_ + 1]);
        gt.length = 0;
      }
    }
    var s, r;
  }
  function l(o) {
    i(o(a));
  }
  return { set: i, update: l, subscribe: function(o, s = un) {
    const r = [o, s];
    return n.add(r), n.size === 1 && (t = e(i, l) || un), o(a), () => {
      n.delete(r), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function mi(a) {
  return Object.prototype.toString.call(a) === "[object Date]";
}
function Tn(a, e, t, n) {
  if (typeof t == "number" || mi(t)) {
    const i = n - t, l = (t - e) / (a.dt || 1 / 60), o = (l + (a.opts.stiffness * i - a.opts.damping * l) * a.inv_mass) * a.dt;
    return Math.abs(o) < a.opts.precision && Math.abs(i) < a.opts.precision ? n : (a.settled = !1, mi(t) ? new Date(t.getTime() + o) : t + o);
  }
  if (Array.isArray(t)) return t.map((i, l) => Tn(a, e[l], t[l], n[l]));
  if (typeof t == "object") {
    const i = {};
    for (const l in t) i[l] = Tn(a, e[l], t[l], n[l]);
    return i;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function gi(a, e = {}) {
  const t = Lo(a), { stiffness: n = 0.15, damping: i = 0.8, precision: l = 0.01 } = e;
  let o, s, r, u = a, _ = a, d = 1, c = 0, h = !1;
  function g(D, k = {}) {
    _ = D;
    const m = r = {};
    return a == null || k.hard || p.stiffness >= 1 && p.damping >= 1 ? (h = !0, o = pi(), u = D, t.set(a = _), Promise.resolve()) : (k.soft && (c = 1 / (60 * (k.soft === !0 ? 0.5 : +k.soft)), d = 0), s || (o = pi(), h = !1, s = Ro((f) => {
      if (h) return h = !1, s = null, !1;
      d = Math.min(d + c, 1);
      const v = { inv_mass: d, opts: p, settled: !0, dt: 60 * (f - o) / 1e3 }, y = Tn(v, u, a, _);
      return o = f, u = a, t.set(a = y), v.settled && (s = null), !v.settled;
    })), new Promise((f) => {
      s.promise.then(() => {
        m === r && f();
      });
    }));
  }
  const p = { set: g, update: (D, k) => g(D(_, a), k), subscribe: t.subscribe, stiffness: n, damping: i, precision: l };
  return p;
}
const {
  SvelteComponent: Oo,
  append_hydration: qe,
  attr: z,
  children: ve,
  claim_element: Po,
  claim_svg_element: Te,
  component_subscribe: vi,
  detach: de,
  element: Mo,
  init: No,
  insert_hydration: jo,
  noop: bi,
  safe_not_equal: Ho,
  set_style: ln,
  svg_element: ze,
  toggle_class: Di
} = window.__gradio__svelte__internal, { onMount: xo } = window.__gradio__svelte__internal;
function Vo(a) {
  let e, t, n, i, l, o, s, r, u, _, d, c;
  return {
    c() {
      e = Mo("div"), t = ze("svg"), n = ze("g"), i = ze("path"), l = ze("path"), o = ze("path"), s = ze("path"), r = ze("g"), u = ze("path"), _ = ze("path"), d = ze("path"), c = ze("path"), this.h();
    },
    l(h) {
      e = Po(h, "DIV", { class: !0 });
      var g = ve(e);
      t = Te(g, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var p = ve(t);
      n = Te(p, "g", { style: !0 });
      var D = ve(n);
      i = Te(D, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ve(i).forEach(de), l = Te(D, "path", { d: !0, fill: !0, class: !0 }), ve(l).forEach(de), o = Te(D, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ve(o).forEach(de), s = Te(D, "path", { d: !0, fill: !0, class: !0 }), ve(s).forEach(de), D.forEach(de), r = Te(p, "g", { style: !0 });
      var k = ve(r);
      u = Te(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ve(u).forEach(de), _ = Te(k, "path", { d: !0, fill: !0, class: !0 }), ve(_).forEach(de), d = Te(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ve(d).forEach(de), c = Te(k, "path", { d: !0, fill: !0, class: !0 }), ve(c).forEach(de), k.forEach(de), p.forEach(de), g.forEach(de), this.h();
    },
    h() {
      z(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), z(i, "fill", "#FF7C00"), z(i, "fill-opacity", "0.4"), z(i, "class", "svelte-43sxxs"), z(l, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), z(l, "fill", "#FF7C00"), z(l, "class", "svelte-43sxxs"), z(o, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), z(o, "fill", "#FF7C00"), z(o, "fill-opacity", "0.4"), z(o, "class", "svelte-43sxxs"), z(s, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), z(s, "fill", "#FF7C00"), z(s, "class", "svelte-43sxxs"), ln(n, "transform", "translate(" + /*$top*/
      a[1][0] + "px, " + /*$top*/
      a[1][1] + "px)"), z(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), z(u, "fill", "#FF7C00"), z(u, "fill-opacity", "0.4"), z(u, "class", "svelte-43sxxs"), z(_, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), z(_, "fill", "#FF7C00"), z(_, "class", "svelte-43sxxs"), z(d, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), z(d, "fill", "#FF7C00"), z(d, "fill-opacity", "0.4"), z(d, "class", "svelte-43sxxs"), z(c, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), z(c, "fill", "#FF7C00"), z(c, "class", "svelte-43sxxs"), ln(r, "transform", "translate(" + /*$bottom*/
      a[2][0] + "px, " + /*$bottom*/
      a[2][1] + "px)"), z(t, "viewBox", "-1200 -1200 3000 3000"), z(t, "fill", "none"), z(t, "xmlns", "http://www.w3.org/2000/svg"), z(t, "class", "svelte-43sxxs"), z(e, "class", "svelte-43sxxs"), Di(
        e,
        "margin",
        /*margin*/
        a[0]
      );
    },
    m(h, g) {
      jo(h, e, g), qe(e, t), qe(t, n), qe(n, i), qe(n, l), qe(n, o), qe(n, s), qe(t, r), qe(r, u), qe(r, _), qe(r, d), qe(r, c);
    },
    p(h, [g]) {
      g & /*$top*/
      2 && ln(n, "transform", "translate(" + /*$top*/
      h[1][0] + "px, " + /*$top*/
      h[1][1] + "px)"), g & /*$bottom*/
      4 && ln(r, "transform", "translate(" + /*$bottom*/
      h[2][0] + "px, " + /*$bottom*/
      h[2][1] + "px)"), g & /*margin*/
      1 && Di(
        e,
        "margin",
        /*margin*/
        h[0]
      );
    },
    i: bi,
    o: bi,
    d(h) {
      h && de(e);
    }
  };
}
function Uo(a, e, t) {
  let n, i;
  var l = this && this.__awaiter || function(h, g, p, D) {
    function k(m) {
      return m instanceof p ? m : new p(function(f) {
        f(m);
      });
    }
    return new (p || (p = Promise))(function(m, f) {
      function v(F) {
        try {
          b(D.next(F));
        } catch (A) {
          f(A);
        }
      }
      function y(F) {
        try {
          b(D.throw(F));
        } catch (A) {
          f(A);
        }
      }
      function b(F) {
        F.done ? m(F.value) : k(F.value).then(v, y);
      }
      b((D = D.apply(h, g || [])).next());
    });
  };
  let { margin: o = !0 } = e;
  const s = gi([0, 0]);
  vi(a, s, (h) => t(1, n = h));
  const r = gi([0, 0]);
  vi(a, r, (h) => t(2, i = h));
  let u;
  function _() {
    return l(this, void 0, void 0, function* () {
      yield Promise.all([s.set([125, 140]), r.set([-125, -140])]), yield Promise.all([s.set([-125, 140]), r.set([125, -140])]), yield Promise.all([s.set([-125, 0]), r.set([125, -0])]), yield Promise.all([s.set([125, 0]), r.set([-125, 0])]);
    });
  }
  function d() {
    return l(this, void 0, void 0, function* () {
      yield _(), u || d();
    });
  }
  function c() {
    return l(this, void 0, void 0, function* () {
      yield Promise.all([s.set([125, 0]), r.set([-125, 0])]), d();
    });
  }
  return xo(() => (c(), () => u = !0)), a.$$set = (h) => {
    "margin" in h && t(0, o = h.margin);
  }, [o, n, i, s, r];
}
class Go extends Oo {
  constructor(e) {
    super(), No(this, e, Uo, Vo, Ho, { margin: 0 });
  }
}
const {
  SvelteComponent: Zo,
  append_hydration: ut,
  attr: Re,
  binding_callbacks: yi,
  check_outros: zn,
  children: Ve,
  claim_component: Vl,
  claim_element: Ue,
  claim_space: ye,
  claim_text: x,
  create_component: Ul,
  create_slot: Gl,
  destroy_component: Zl,
  destroy_each: Xl,
  detach: B,
  element: Ge,
  empty: Ee,
  ensure_array_like: fn,
  get_all_dirty_from_scope: Yl,
  get_slot_changes: Wl,
  group_outros: In,
  init: Xo,
  insert_hydration: T,
  mount_component: Kl,
  noop: Rn,
  safe_not_equal: Yo,
  set_data: Ae,
  set_style: it,
  space: we,
  text: V,
  toggle_class: be,
  transition_in: Ie,
  transition_out: Ze,
  update_slot_base: Ql
} = window.__gradio__svelte__internal, { tick: Wo } = window.__gradio__svelte__internal, { onDestroy: Ko } = window.__gradio__svelte__internal, { createEventDispatcher: Qo } = window.__gradio__svelte__internal, Jo = (a) => ({}), wi = (a) => ({}), es = (a) => ({}), ki = (a) => ({});
function Fi(a, e, t) {
  const n = a.slice();
  return n[40] = e[t], n[42] = t, n;
}
function $i(a, e, t) {
  const n = a.slice();
  return n[40] = e[t], n;
}
function ts(a) {
  let e, t, n, i, l = (
    /*i18n*/
    a[1]("common.error") + ""
  ), o, s, r;
  t = new Eo({
    props: {
      Icon: zo,
      label: (
        /*i18n*/
        a[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    a[32]
  );
  const u = (
    /*#slots*/
    a[30].error
  ), _ = Gl(
    u,
    a,
    /*$$scope*/
    a[29],
    wi
  );
  return {
    c() {
      e = Ge("div"), Ul(t.$$.fragment), n = we(), i = Ge("span"), o = V(l), s = we(), _ && _.c(), this.h();
    },
    l(d) {
      e = Ue(d, "DIV", { class: !0 });
      var c = Ve(e);
      Vl(t.$$.fragment, c), c.forEach(B), n = ye(d), i = Ue(d, "SPAN", { class: !0 });
      var h = Ve(i);
      o = x(h, l), h.forEach(B), s = ye(d), _ && _.l(d), this.h();
    },
    h() {
      Re(e, "class", "clear-status svelte-17v219f"), Re(i, "class", "error svelte-17v219f");
    },
    m(d, c) {
      T(d, e, c), Kl(t, e, null), T(d, n, c), T(d, i, c), ut(i, o), T(d, s, c), _ && _.m(d, c), r = !0;
    },
    p(d, c) {
      const h = {};
      c[0] & /*i18n*/
      2 && (h.label = /*i18n*/
      d[1]("common.clear")), t.$set(h), (!r || c[0] & /*i18n*/
      2) && l !== (l = /*i18n*/
      d[1]("common.error") + "") && Ae(o, l), _ && _.p && (!r || c[0] & /*$$scope*/
      536870912) && Ql(
        _,
        u,
        d,
        /*$$scope*/
        d[29],
        r ? Wl(
          u,
          /*$$scope*/
          d[29],
          c,
          Jo
        ) : Yl(
          /*$$scope*/
          d[29]
        ),
        wi
      );
    },
    i(d) {
      r || (Ie(t.$$.fragment, d), Ie(_, d), r = !0);
    },
    o(d) {
      Ze(t.$$.fragment, d), Ze(_, d), r = !1;
    },
    d(d) {
      d && (B(e), B(n), B(i), B(s)), Zl(t), _ && _.d(d);
    }
  };
}
function ns(a) {
  let e, t, n, i, l, o, s, r, u, _ = (
    /*variant*/
    a[8] === "default" && /*show_eta_bar*/
    a[18] && /*show_progress*/
    a[6] === "full" && Ci(a)
  );
  function d(f, v) {
    if (
      /*progress*/
      f[7]
    ) return as;
    if (
      /*queue_position*/
      f[2] !== null && /*queue_size*/
      f[3] !== void 0 && /*queue_position*/
      f[2] >= 0
    ) return ls;
    if (
      /*queue_position*/
      f[2] === 0
    ) return is;
  }
  let c = d(a), h = c && c(a), g = (
    /*timer*/
    a[5] && Si(a)
  );
  const p = [us, rs], D = [];
  function k(f, v) {
    return (
      /*last_progress_level*/
      f[15] != null ? 0 : (
        /*show_progress*/
        f[6] === "full" ? 1 : -1
      )
    );
  }
  ~(l = k(a)) && (o = D[l] = p[l](a));
  let m = !/*timer*/
  a[5] && Li(a);
  return {
    c() {
      _ && _.c(), e = we(), t = Ge("div"), h && h.c(), n = we(), g && g.c(), i = we(), o && o.c(), s = we(), m && m.c(), r = Ee(), this.h();
    },
    l(f) {
      _ && _.l(f), e = ye(f), t = Ue(f, "DIV", { class: !0 });
      var v = Ve(t);
      h && h.l(v), n = ye(v), g && g.l(v), v.forEach(B), i = ye(f), o && o.l(f), s = ye(f), m && m.l(f), r = Ee(), this.h();
    },
    h() {
      Re(t, "class", "progress-text svelte-17v219f"), be(
        t,
        "meta-text-center",
        /*variant*/
        a[8] === "center"
      ), be(
        t,
        "meta-text",
        /*variant*/
        a[8] === "default"
      );
    },
    m(f, v) {
      _ && _.m(f, v), T(f, e, v), T(f, t, v), h && h.m(t, null), ut(t, n), g && g.m(t, null), T(f, i, v), ~l && D[l].m(f, v), T(f, s, v), m && m.m(f, v), T(f, r, v), u = !0;
    },
    p(f, v) {
      /*variant*/
      f[8] === "default" && /*show_eta_bar*/
      f[18] && /*show_progress*/
      f[6] === "full" ? _ ? _.p(f, v) : (_ = Ci(f), _.c(), _.m(e.parentNode, e)) : _ && (_.d(1), _ = null), c === (c = d(f)) && h ? h.p(f, v) : (h && h.d(1), h = c && c(f), h && (h.c(), h.m(t, n))), /*timer*/
      f[5] ? g ? g.p(f, v) : (g = Si(f), g.c(), g.m(t, null)) : g && (g.d(1), g = null), (!u || v[0] & /*variant*/
      256) && be(
        t,
        "meta-text-center",
        /*variant*/
        f[8] === "center"
      ), (!u || v[0] & /*variant*/
      256) && be(
        t,
        "meta-text",
        /*variant*/
        f[8] === "default"
      );
      let y = l;
      l = k(f), l === y ? ~l && D[l].p(f, v) : (o && (In(), Ze(D[y], 1, 1, () => {
        D[y] = null;
      }), zn()), ~l ? (o = D[l], o ? o.p(f, v) : (o = D[l] = p[l](f), o.c()), Ie(o, 1), o.m(s.parentNode, s)) : o = null), /*timer*/
      f[5] ? m && (In(), Ze(m, 1, 1, () => {
        m = null;
      }), zn()) : m ? (m.p(f, v), v[0] & /*timer*/
      32 && Ie(m, 1)) : (m = Li(f), m.c(), Ie(m, 1), m.m(r.parentNode, r));
    },
    i(f) {
      u || (Ie(o), Ie(m), u = !0);
    },
    o(f) {
      Ze(o), Ze(m), u = !1;
    },
    d(f) {
      f && (B(e), B(t), B(i), B(s), B(r)), _ && _.d(f), h && h.d(), g && g.d(), ~l && D[l].d(f), m && m.d(f);
    }
  };
}
function Ci(a) {
  let e, t = `translateX(${/*eta_level*/
  (a[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Ge("div"), this.h();
    },
    l(n) {
      e = Ue(n, "DIV", { class: !0 }), Ve(e).forEach(B), this.h();
    },
    h() {
      Re(e, "class", "eta-bar svelte-17v219f"), it(e, "transform", t);
    },
    m(n, i) {
      T(n, e, i);
    },
    p(n, i) {
      i[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && it(e, "transform", t);
    },
    d(n) {
      n && B(e);
    }
  };
}
function is(a) {
  let e;
  return {
    c() {
      e = V("processing |");
    },
    l(t) {
      e = x(t, "processing |");
    },
    m(t, n) {
      T(t, e, n);
    },
    p: Rn,
    d(t) {
      t && B(e);
    }
  };
}
function ls(a) {
  let e, t = (
    /*queue_position*/
    a[2] + 1 + ""
  ), n, i, l, o;
  return {
    c() {
      e = V("queue: "), n = V(t), i = V("/"), l = V(
        /*queue_size*/
        a[3]
      ), o = V(" |");
    },
    l(s) {
      e = x(s, "queue: "), n = x(s, t), i = x(s, "/"), l = x(
        s,
        /*queue_size*/
        a[3]
      ), o = x(s, " |");
    },
    m(s, r) {
      T(s, e, r), T(s, n, r), T(s, i, r), T(s, l, r), T(s, o, r);
    },
    p(s, r) {
      r[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      s[2] + 1 + "") && Ae(n, t), r[0] & /*queue_size*/
      8 && Ae(
        l,
        /*queue_size*/
        s[3]
      );
    },
    d(s) {
      s && (B(e), B(n), B(i), B(l), B(o));
    }
  };
}
function as(a) {
  let e, t = fn(
    /*progress*/
    a[7]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = Ai($i(a, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = Ee();
    },
    l(i) {
      for (let l = 0; l < n.length; l += 1)
        n[l].l(i);
      e = Ee();
    },
    m(i, l) {
      for (let o = 0; o < n.length; o += 1)
        n[o] && n[o].m(i, l);
      T(i, e, l);
    },
    p(i, l) {
      if (l[0] & /*progress*/
      128) {
        t = fn(
          /*progress*/
          i[7]
        );
        let o;
        for (o = 0; o < t.length; o += 1) {
          const s = $i(i, t, o);
          n[o] ? n[o].p(s, l) : (n[o] = Ai(s), n[o].c(), n[o].m(e.parentNode, e));
        }
        for (; o < n.length; o += 1)
          n[o].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && B(e), Xl(n, i);
    }
  };
}
function Ei(a) {
  let e, t = (
    /*p*/
    a[40].unit + ""
  ), n, i, l = " ", o;
  function s(_, d) {
    return (
      /*p*/
      _[40].length != null ? ss : os
    );
  }
  let r = s(a), u = r(a);
  return {
    c() {
      u.c(), e = we(), n = V(t), i = V(" | "), o = V(l);
    },
    l(_) {
      u.l(_), e = ye(_), n = x(_, t), i = x(_, " | "), o = x(_, l);
    },
    m(_, d) {
      u.m(_, d), T(_, e, d), T(_, n, d), T(_, i, d), T(_, o, d);
    },
    p(_, d) {
      r === (r = s(_)) && u ? u.p(_, d) : (u.d(1), u = r(_), u && (u.c(), u.m(e.parentNode, e))), d[0] & /*progress*/
      128 && t !== (t = /*p*/
      _[40].unit + "") && Ae(n, t);
    },
    d(_) {
      _ && (B(e), B(n), B(i), B(o)), u.d(_);
    }
  };
}
function os(a) {
  let e = vt(
    /*p*/
    a[40].index || 0
  ) + "", t;
  return {
    c() {
      t = V(e);
    },
    l(n) {
      t = x(n, e);
    },
    m(n, i) {
      T(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      128 && e !== (e = vt(
        /*p*/
        n[40].index || 0
      ) + "") && Ae(t, e);
    },
    d(n) {
      n && B(t);
    }
  };
}
function ss(a) {
  let e = vt(
    /*p*/
    a[40].index || 0
  ) + "", t, n, i = vt(
    /*p*/
    a[40].length
  ) + "", l;
  return {
    c() {
      t = V(e), n = V("/"), l = V(i);
    },
    l(o) {
      t = x(o, e), n = x(o, "/"), l = x(o, i);
    },
    m(o, s) {
      T(o, t, s), T(o, n, s), T(o, l, s);
    },
    p(o, s) {
      s[0] & /*progress*/
      128 && e !== (e = vt(
        /*p*/
        o[40].index || 0
      ) + "") && Ae(t, e), s[0] & /*progress*/
      128 && i !== (i = vt(
        /*p*/
        o[40].length
      ) + "") && Ae(l, i);
    },
    d(o) {
      o && (B(t), B(n), B(l));
    }
  };
}
function Ai(a) {
  let e, t = (
    /*p*/
    a[40].index != null && Ei(a)
  );
  return {
    c() {
      t && t.c(), e = Ee();
    },
    l(n) {
      t && t.l(n), e = Ee();
    },
    m(n, i) {
      t && t.m(n, i), T(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[40].index != null ? t ? t.p(n, i) : (t = Ei(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && B(e), t && t.d(n);
    }
  };
}
function Si(a) {
  let e, t = (
    /*eta*/
    a[0] ? `/${/*formatted_eta*/
    a[19]}` : ""
  ), n, i;
  return {
    c() {
      e = V(
        /*formatted_timer*/
        a[20]
      ), n = V(t), i = V("s");
    },
    l(l) {
      e = x(
        l,
        /*formatted_timer*/
        a[20]
      ), n = x(l, t), i = x(l, "s");
    },
    m(l, o) {
      T(l, e, o), T(l, n, o), T(l, i, o);
    },
    p(l, o) {
      o[0] & /*formatted_timer*/
      1048576 && Ae(
        e,
        /*formatted_timer*/
        l[20]
      ), o[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      l[0] ? `/${/*formatted_eta*/
      l[19]}` : "") && Ae(n, t);
    },
    d(l) {
      l && (B(e), B(n), B(i));
    }
  };
}
function rs(a) {
  let e, t;
  return e = new Go({
    props: { margin: (
      /*variant*/
      a[8] === "default"
    ) }
  }), {
    c() {
      Ul(e.$$.fragment);
    },
    l(n) {
      Vl(e.$$.fragment, n);
    },
    m(n, i) {
      Kl(e, n, i), t = !0;
    },
    p(n, i) {
      const l = {};
      i[0] & /*variant*/
      256 && (l.margin = /*variant*/
      n[8] === "default"), e.$set(l);
    },
    i(n) {
      t || (Ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ze(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Zl(e, n);
    }
  };
}
function us(a) {
  let e, t, n, i, l, o = `${/*last_progress_level*/
  a[15] * 100}%`, s = (
    /*progress*/
    a[7] != null && Bi(a)
  );
  return {
    c() {
      e = Ge("div"), t = Ge("div"), s && s.c(), n = we(), i = Ge("div"), l = Ge("div"), this.h();
    },
    l(r) {
      e = Ue(r, "DIV", { class: !0 });
      var u = Ve(e);
      t = Ue(u, "DIV", { class: !0 });
      var _ = Ve(t);
      s && s.l(_), _.forEach(B), n = ye(u), i = Ue(u, "DIV", { class: !0 });
      var d = Ve(i);
      l = Ue(d, "DIV", { class: !0 }), Ve(l).forEach(B), d.forEach(B), u.forEach(B), this.h();
    },
    h() {
      Re(t, "class", "progress-level-inner svelte-17v219f"), Re(l, "class", "progress-bar svelte-17v219f"), it(l, "width", o), Re(i, "class", "progress-bar-wrap svelte-17v219f"), Re(e, "class", "progress-level svelte-17v219f");
    },
    m(r, u) {
      T(r, e, u), ut(e, t), s && s.m(t, null), ut(e, n), ut(e, i), ut(i, l), a[31](l);
    },
    p(r, u) {
      /*progress*/
      r[7] != null ? s ? s.p(r, u) : (s = Bi(r), s.c(), s.m(t, null)) : s && (s.d(1), s = null), u[0] & /*last_progress_level*/
      32768 && o !== (o = `${/*last_progress_level*/
      r[15] * 100}%`) && it(l, "width", o);
    },
    i: Rn,
    o: Rn,
    d(r) {
      r && B(e), s && s.d(), a[31](null);
    }
  };
}
function Bi(a) {
  let e, t = fn(
    /*progress*/
    a[7]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = Ri(Fi(a, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = Ee();
    },
    l(i) {
      for (let l = 0; l < n.length; l += 1)
        n[l].l(i);
      e = Ee();
    },
    m(i, l) {
      for (let o = 0; o < n.length; o += 1)
        n[o] && n[o].m(i, l);
      T(i, e, l);
    },
    p(i, l) {
      if (l[0] & /*progress_level, progress*/
      16512) {
        t = fn(
          /*progress*/
          i[7]
        );
        let o;
        for (o = 0; o < t.length; o += 1) {
          const s = Fi(i, t, o);
          n[o] ? n[o].p(s, l) : (n[o] = Ri(s), n[o].c(), n[o].m(e.parentNode, e));
        }
        for (; o < n.length; o += 1)
          n[o].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && B(e), Xl(n, i);
    }
  };
}
function qi(a) {
  let e, t, n, i, l = (
    /*i*/
    a[42] !== 0 && _s()
  ), o = (
    /*p*/
    a[40].desc != null && Ti(a)
  ), s = (
    /*p*/
    a[40].desc != null && /*progress_level*/
    a[14] && /*progress_level*/
    a[14][
      /*i*/
      a[42]
    ] != null && zi()
  ), r = (
    /*progress_level*/
    a[14] != null && Ii(a)
  );
  return {
    c() {
      l && l.c(), e = we(), o && o.c(), t = we(), s && s.c(), n = we(), r && r.c(), i = Ee();
    },
    l(u) {
      l && l.l(u), e = ye(u), o && o.l(u), t = ye(u), s && s.l(u), n = ye(u), r && r.l(u), i = Ee();
    },
    m(u, _) {
      l && l.m(u, _), T(u, e, _), o && o.m(u, _), T(u, t, _), s && s.m(u, _), T(u, n, _), r && r.m(u, _), T(u, i, _);
    },
    p(u, _) {
      /*p*/
      u[40].desc != null ? o ? o.p(u, _) : (o = Ti(u), o.c(), o.m(t.parentNode, t)) : o && (o.d(1), o = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? s || (s = zi(), s.c(), s.m(n.parentNode, n)) : s && (s.d(1), s = null), /*progress_level*/
      u[14] != null ? r ? r.p(u, _) : (r = Ii(u), r.c(), r.m(i.parentNode, i)) : r && (r.d(1), r = null);
    },
    d(u) {
      u && (B(e), B(t), B(n), B(i)), l && l.d(u), o && o.d(u), s && s.d(u), r && r.d(u);
    }
  };
}
function _s(a) {
  let e;
  return {
    c() {
      e = V(" /");
    },
    l(t) {
      e = x(t, " /");
    },
    m(t, n) {
      T(t, e, n);
    },
    d(t) {
      t && B(e);
    }
  };
}
function Ti(a) {
  let e = (
    /*p*/
    a[40].desc + ""
  ), t;
  return {
    c() {
      t = V(e);
    },
    l(n) {
      t = x(n, e);
    },
    m(n, i) {
      T(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && Ae(t, e);
    },
    d(n) {
      n && B(t);
    }
  };
}
function zi(a) {
  let e;
  return {
    c() {
      e = V("-");
    },
    l(t) {
      e = x(t, "-");
    },
    m(t, n) {
      T(t, e, n);
    },
    d(t) {
      t && B(e);
    }
  };
}
function Ii(a) {
  let e = (100 * /*progress_level*/
  (a[14][
    /*i*/
    a[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = V(e), n = V("%");
    },
    l(i) {
      t = x(i, e), n = x(i, "%");
    },
    m(i, l) {
      T(i, t, l), T(i, n, l);
    },
    p(i, l) {
      l[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (i[14][
        /*i*/
        i[42]
      ] || 0)).toFixed(1) + "") && Ae(t, e);
    },
    d(i) {
      i && (B(t), B(n));
    }
  };
}
function Ri(a) {
  let e, t = (
    /*p*/
    (a[40].desc != null || /*progress_level*/
    a[14] && /*progress_level*/
    a[14][
      /*i*/
      a[42]
    ] != null) && qi(a)
  );
  return {
    c() {
      t && t.c(), e = Ee();
    },
    l(n) {
      t && t.l(n), e = Ee();
    },
    m(n, i) {
      t && t.m(n, i), T(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, i) : (t = qi(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && B(e), t && t.d(n);
    }
  };
}
function Li(a) {
  let e, t, n, i;
  const l = (
    /*#slots*/
    a[30]["additional-loading-text"]
  ), o = Gl(
    l,
    a,
    /*$$scope*/
    a[29],
    ki
  );
  return {
    c() {
      e = Ge("p"), t = V(
        /*loading_text*/
        a[9]
      ), n = we(), o && o.c(), this.h();
    },
    l(s) {
      e = Ue(s, "P", { class: !0 });
      var r = Ve(e);
      t = x(
        r,
        /*loading_text*/
        a[9]
      ), r.forEach(B), n = ye(s), o && o.l(s), this.h();
    },
    h() {
      Re(e, "class", "loading svelte-17v219f");
    },
    m(s, r) {
      T(s, e, r), ut(e, t), T(s, n, r), o && o.m(s, r), i = !0;
    },
    p(s, r) {
      (!i || r[0] & /*loading_text*/
      512) && Ae(
        t,
        /*loading_text*/
        s[9]
      ), o && o.p && (!i || r[0] & /*$$scope*/
      536870912) && Ql(
        o,
        l,
        s,
        /*$$scope*/
        s[29],
        i ? Wl(
          l,
          /*$$scope*/
          s[29],
          r,
          es
        ) : Yl(
          /*$$scope*/
          s[29]
        ),
        ki
      );
    },
    i(s) {
      i || (Ie(o, s), i = !0);
    },
    o(s) {
      Ze(o, s), i = !1;
    },
    d(s) {
      s && (B(e), B(n)), o && o.d(s);
    }
  };
}
function cs(a) {
  let e, t, n, i, l;
  const o = [ns, ts], s = [];
  function r(u, _) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = r(a)) && (n = s[t] = o[t](a)), {
    c() {
      e = Ge("div"), n && n.c(), this.h();
    },
    l(u) {
      e = Ue(u, "DIV", { class: !0 });
      var _ = Ve(e);
      n && n.l(_), _.forEach(B), this.h();
    },
    h() {
      Re(e, "class", i = "wrap " + /*variant*/
      a[8] + " " + /*show_progress*/
      a[6] + " svelte-17v219f"), be(e, "hide", !/*status*/
      a[4] || /*status*/
      a[4] === "complete" || /*show_progress*/
      a[6] === "hidden" || /*status*/
      a[4] == "streaming"), be(
        e,
        "translucent",
        /*variant*/
        a[8] === "center" && /*status*/
        (a[4] === "pending" || /*status*/
        a[4] === "error") || /*translucent*/
        a[11] || /*show_progress*/
        a[6] === "minimal"
      ), be(
        e,
        "generating",
        /*status*/
        a[4] === "generating" && /*show_progress*/
        a[6] === "full"
      ), be(
        e,
        "border",
        /*border*/
        a[12]
      ), it(
        e,
        "position",
        /*absolute*/
        a[10] ? "absolute" : "static"
      ), it(
        e,
        "padding",
        /*absolute*/
        a[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, _) {
      T(u, e, _), ~t && s[t].m(e, null), a[33](e), l = !0;
    },
    p(u, _) {
      let d = t;
      t = r(u), t === d ? ~t && s[t].p(u, _) : (n && (In(), Ze(s[d], 1, 1, () => {
        s[d] = null;
      }), zn()), ~t ? (n = s[t], n ? n.p(u, _) : (n = s[t] = o[t](u), n.c()), Ie(n, 1), n.m(e, null)) : n = null), (!l || _[0] & /*variant, show_progress*/
      320 && i !== (i = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Re(e, "class", i), (!l || _[0] & /*variant, show_progress, status, show_progress*/
      336) && be(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!l || _[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && be(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!l || _[0] & /*variant, show_progress, status, show_progress*/
      336) && be(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!l || _[0] & /*variant, show_progress, border*/
      4416) && be(
        e,
        "border",
        /*border*/
        u[12]
      ), _[0] & /*absolute*/
      1024 && it(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), _[0] & /*absolute*/
      1024 && it(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      l || (Ie(n), l = !0);
    },
    o(u) {
      Ze(n), l = !1;
    },
    d(u) {
      u && B(e), ~t && s[t].d(), a[33](null);
    }
  };
}
var ds = function(a, e, t, n) {
  function i(l) {
    return l instanceof t ? l : new t(function(o) {
      o(l);
    });
  }
  return new (t || (t = Promise))(function(l, o) {
    function s(_) {
      try {
        u(n.next(_));
      } catch (d) {
        o(d);
      }
    }
    function r(_) {
      try {
        u(n.throw(_));
      } catch (d) {
        o(d);
      }
    }
    function u(_) {
      _.done ? l(_.value) : i(_.value).then(s, r);
    }
    u((n = n.apply(a, e || [])).next());
  });
};
let an = [], $n = !1;
const fs = typeof window < "u", Jl = fs ? window.requestAnimationFrame : (a) => {
};
function hs(a) {
  return ds(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (an.push(e), !$n) $n = !0;
      else return;
      yield Wo(), Jl(() => {
        let n = [0, 0];
        for (let i = 0; i < an.length; i++) {
          const o = an[i].getBoundingClientRect();
          (i === 0 || o.top + window.scrollY <= n[0]) && (n[0] = o.top + window.scrollY, n[1] = i);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), $n = !1, an = [];
      });
    }
  });
}
function ps(a, e, t) {
  let n, { $$slots: i = {}, $$scope: l } = e;
  const o = Qo();
  let { i18n: s } = e, { eta: r = null } = e, { queue_position: u } = e, { queue_size: _ } = e, { status: d } = e, { scroll_to_output: c = !1 } = e, { timer: h = !0 } = e, { show_progress: g = "full" } = e, { message: p = null } = e, { progress: D = null } = e, { variant: k = "default" } = e, { loading_text: m = "Loading..." } = e, { absolute: f = !0 } = e, { translucent: v = !1 } = e, { border: y = !1 } = e, { autoscroll: b } = e, F, A = !1, E = 0, q = 0, w = null, $ = null, ge = 0, _e = null, Me, ue = null, nt = !0;
  const Z = () => {
    t(0, r = t(27, w = t(19, C = null))), t(25, E = performance.now()), t(26, q = 0), A = !0, se();
  };
  function se() {
    Jl(() => {
      t(26, q = (performance.now() - E) / 1e3), A && se();
    });
  }
  function Se() {
    t(26, q = 0), t(0, r = t(27, w = t(19, C = null))), A && (A = !1);
  }
  Ko(() => {
    A && Se();
  });
  let C = null;
  function ee(S) {
    yi[S ? "unshift" : "push"](() => {
      ue = S, t(16, ue), t(7, D), t(14, _e), t(15, Me);
    });
  }
  const pt = () => {
    o("clear_status");
  };
  function ce(S) {
    yi[S ? "unshift" : "push"](() => {
      F = S, t(13, F);
    });
  }
  return a.$$set = (S) => {
    "i18n" in S && t(1, s = S.i18n), "eta" in S && t(0, r = S.eta), "queue_position" in S && t(2, u = S.queue_position), "queue_size" in S && t(3, _ = S.queue_size), "status" in S && t(4, d = S.status), "scroll_to_output" in S && t(22, c = S.scroll_to_output), "timer" in S && t(5, h = S.timer), "show_progress" in S && t(6, g = S.show_progress), "message" in S && t(23, p = S.message), "progress" in S && t(7, D = S.progress), "variant" in S && t(8, k = S.variant), "loading_text" in S && t(9, m = S.loading_text), "absolute" in S && t(10, f = S.absolute), "translucent" in S && t(11, v = S.translucent), "border" in S && t(12, y = S.border), "autoscroll" in S && t(24, b = S.autoscroll), "$$scope" in S && t(29, l = S.$$scope);
  }, a.$$.update = () => {
    a.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (r === null && t(0, r = w), r != null && w !== r && (t(28, $ = (performance.now() - E) / 1e3 + r), t(19, C = $.toFixed(1)), t(27, w = r))), a.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, ge = $ === null || $ <= 0 || !q ? null : Math.min(q / $, 1)), a.$$.dirty[0] & /*progress*/
    128 && D != null && t(18, nt = !1), a.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (D != null ? t(14, _e = D.map((S) => {
      if (S.index != null && S.length != null)
        return S.index / S.length;
      if (S.progress != null)
        return S.progress;
    })) : t(14, _e = null), _e ? (t(15, Me = _e[_e.length - 1]), ue && (Me === 0 ? t(16, ue.style.transition = "0", ue) : t(16, ue.style.transition = "150ms", ue))) : t(15, Me = void 0)), a.$$.dirty[0] & /*status*/
    16 && (d === "pending" ? Z() : Se()), a.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && F && c && (d === "pending" || d === "complete") && hs(F, b), a.$$.dirty[0] & /*status, message*/
    8388624, a.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = q.toFixed(1));
  }, [
    r,
    s,
    u,
    _,
    d,
    h,
    g,
    D,
    k,
    m,
    f,
    v,
    y,
    F,
    _e,
    Me,
    ue,
    ge,
    nt,
    C,
    n,
    o,
    c,
    p,
    b,
    E,
    q,
    w,
    $,
    l,
    i,
    ee,
    pt,
    ce
  ];
}
class ms extends Zo {
  constructor(e) {
    super(), Xo(
      this,
      e,
      ps,
      cs,
      Yo,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: c$,
  SvelteComponent: d$,
  add_render_callback: f$,
  append_hydration: h$,
  attr: p$,
  bubble: m$,
  check_outros: g$,
  children: v$,
  claim_component: b$,
  claim_element: D$,
  claim_html_tag: y$,
  claim_space: w$,
  claim_text: k$,
  create_component: F$,
  create_in_transition: $$,
  create_out_transition: C$,
  destroy_component: E$,
  detach: A$,
  element: S$,
  get_svelte_dataset: B$,
  group_outros: q$,
  init: T$,
  insert_hydration: z$,
  listen: I$,
  mount_component: R$,
  run_all: L$,
  safe_not_equal: O$,
  set_data: P$,
  space: M$,
  stop_propagation: N$,
  text: j$,
  toggle_class: H$,
  transition_in: x$,
  transition_out: V$
} = window.__gradio__svelte__internal, { createEventDispatcher: U$, onMount: G$ } = window.__gradio__svelte__internal, {
  SvelteComponent: Z$,
  append_hydration: X$,
  attr: Y$,
  bubble: W$,
  check_outros: K$,
  children: Q$,
  claim_component: J$,
  claim_element: e4,
  claim_space: t4,
  create_animation: n4,
  create_component: i4,
  destroy_component: l4,
  detach: a4,
  element: o4,
  ensure_array_like: s4,
  fix_and_outro_and_destroy_block: r4,
  fix_position: u4,
  group_outros: _4,
  init: c4,
  insert_hydration: d4,
  mount_component: f4,
  noop: h4,
  safe_not_equal: p4,
  set_style: m4,
  space: g4,
  transition_in: v4,
  transition_out: b4,
  update_keyed_each: D4
} = window.__gradio__svelte__internal, {
  SvelteComponent: y4,
  attr: w4,
  children: k4,
  claim_element: F4,
  detach: $4,
  element: C4,
  empty: E4,
  init: A4,
  insert_hydration: S4,
  noop: B4,
  safe_not_equal: q4,
  set_style: T4
} = window.__gradio__svelte__internal, {
  SvelteComponent: gs,
  append_hydration: De,
  attr: Y,
  children: Ye,
  claim_element: We,
  claim_space: It,
  claim_text: Rt,
  destroy_each: vs,
  detach: Q,
  element: Ke,
  empty: Oi,
  ensure_array_like: Pi,
  init: bs,
  insert_hydration: lt,
  noop: Mi,
  safe_not_equal: Ds,
  set_data: Lt,
  set_style: on,
  space: Ot,
  text: Pt,
  toggle_class: ke
} = window.__gradio__svelte__internal;
function Ni(a, e, t) {
  const n = a.slice();
  return n[19] = e[t], n;
}
function ji(a) {
  let e, t = Pi(
    /*display_items*/
    a[11]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = xi(Ni(a, t, i));
  return {
    c() {
      e = Ke("div");
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      this.h();
    },
    l(i) {
      e = We(i, "DIV", { class: !0 });
      var l = Ye(e);
      for (let o = 0; o < n.length; o += 1)
        n[o].l(l);
      l.forEach(Q), this.h();
    },
    h() {
      Y(e, "class", "credits-container svelte-1t8lt48");
    },
    m(i, l) {
      lt(i, e, l);
      for (let o = 0; o < n.length; o += 1)
        n[o] && n[o].m(e, null);
    },
    p(i, l) {
      if (l & /*section_title_style, section_title_uppercase, display_items, swap_font_sizes_on_two_column, title_style, name_style, name_uppercase, title_uppercase, layout_style*/
      3964) {
        t = Pi(
          /*display_items*/
          i[11]
        );
        let o;
        for (o = 0; o < t.length; o += 1) {
          const s = Ni(i, t, o);
          n[o] ? n[o].p(s, l) : (n[o] = xi(s), n[o].c(), n[o].m(e, null));
        }
        for (; o < n.length; o += 1)
          n[o].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && Q(e), vs(n, i);
    }
  };
}
function ys(a) {
  let e, t, n = (
    /*item*/
    a[19].title + ""
  ), i, l, o, s, r = (
    /*item*/
    a[19].name && Hi(a)
  );
  return {
    c() {
      e = Ke("div"), t = Ke("h2"), i = Pt(n), o = Ot(), r && r.c(), s = Ot(), this.h();
    },
    l(u) {
      e = We(u, "DIV", { class: !0 });
      var _ = Ye(e);
      t = We(_, "H2", { style: !0, class: !0 });
      var d = Ye(t);
      i = Rt(d, n), d.forEach(Q), o = It(_), r && r.l(_), s = It(_), _.forEach(Q), this.h();
    },
    h() {
      Y(t, "style", l = /*title_style*/
      a[10](
        /*item*/
        a[19].is_intro
      )), Y(t, "class", "svelte-1t8lt48"), ke(
        t,
        "uppercase",
        /*title_uppercase*/
        a[3] && !/*item*/
        a[19].is_intro
      ), Y(e, "class", "credit svelte-1t8lt48"), ke(
        e,
        "intro-block",
        /*item*/
        a[19].is_intro
      );
    },
    m(u, _) {
      lt(u, e, _), De(e, t), De(t, i), De(e, o), r && r.m(e, null), De(e, s);
    },
    p(u, _) {
      _ & /*display_items*/
      2048 && n !== (n = /*item*/
      u[19].title + "") && Lt(i, n), _ & /*title_style, display_items*/
      3072 && l !== (l = /*title_style*/
      u[10](
        /*item*/
        u[19].is_intro
      )) && Y(t, "style", l), _ & /*title_uppercase, display_items*/
      2056 && ke(
        t,
        "uppercase",
        /*title_uppercase*/
        u[3] && !/*item*/
        u[19].is_intro
      ), /*item*/
      u[19].name ? r ? r.p(u, _) : (r = Hi(u), r.c(), r.m(e, s)) : r && (r.d(1), r = null), _ & /*display_items*/
      2048 && ke(
        e,
        "intro-block",
        /*item*/
        u[19].is_intro
      );
    },
    d(u) {
      u && Q(e), r && r.d();
    }
  };
}
function ws(a) {
  let e, t, n = (
    /*item*/
    a[19].title + ""
  ), i, l, o, s, r = (
    /*item*/
    a[19].name + ""
  ), u, _, d;
  return {
    c() {
      e = Ke("div"), t = Ke("div"), i = Pt(n), o = Ot(), s = Ke("div"), u = Pt(r), d = Ot(), this.h();
    },
    l(c) {
      e = We(c, "DIV", { class: !0 });
      var h = Ye(e);
      t = We(h, "DIV", { class: !0, style: !0 });
      var g = Ye(t);
      i = Rt(g, n), g.forEach(Q), o = It(h), s = We(h, "DIV", { class: !0, style: !0 });
      var p = Ye(s);
      u = Rt(p, r), p.forEach(Q), d = It(h), h.forEach(Q), this.h();
    },
    h() {
      Y(t, "class", "title svelte-1t8lt48"), Y(t, "style", l = /*swap_font_sizes_on_two_column*/
      a[6] ? (
        /*name_style*/
        a[9](!1)
      ) : (
        /*title_style*/
        a[10](!1)
      )), ke(
        t,
        "uppercase",
        /*title_uppercase*/
        a[3]
      ), Y(s, "class", "name svelte-1t8lt48"), Y(s, "style", _ = /*swap_font_sizes_on_two_column*/
      a[6] ? (
        /*title_style*/
        a[10](!1)
      ) : (
        /*name_style*/
        a[9](!1)
      )), ke(
        s,
        "uppercase",
        /*name_uppercase*/
        a[4]
      ), Y(e, "class", "credit-two-column svelte-1t8lt48");
    },
    m(c, h) {
      lt(c, e, h), De(e, t), De(t, i), De(e, o), De(e, s), De(s, u), De(e, d);
    },
    p(c, h) {
      h & /*display_items*/
      2048 && n !== (n = /*item*/
      c[19].title + "") && Lt(i, n), h & /*swap_font_sizes_on_two_column, name_style, title_style*/
      1600 && l !== (l = /*swap_font_sizes_on_two_column*/
      c[6] ? (
        /*name_style*/
        c[9](!1)
      ) : (
        /*title_style*/
        c[10](!1)
      )) && Y(t, "style", l), h & /*title_uppercase*/
      8 && ke(
        t,
        "uppercase",
        /*title_uppercase*/
        c[3]
      ), h & /*display_items*/
      2048 && r !== (r = /*item*/
      c[19].name + "") && Lt(u, r), h & /*swap_font_sizes_on_two_column, title_style, name_style*/
      1600 && _ !== (_ = /*swap_font_sizes_on_two_column*/
      c[6] ? (
        /*title_style*/
        c[10](!1)
      ) : (
        /*name_style*/
        c[9](!1)
      )) && Y(s, "style", _), h & /*name_uppercase*/
      16 && ke(
        s,
        "uppercase",
        /*name_uppercase*/
        c[4]
      );
    },
    d(c) {
      c && Q(e);
    }
  };
}
function ks(a) {
  let e, t = (
    /*item*/
    a[19].section_title + ""
  ), n, i;
  return {
    c() {
      e = Ke("div"), n = Pt(t), i = Ot(), this.h();
    },
    l(l) {
      e = We(l, "DIV", { class: !0, style: !0 });
      var o = Ye(e);
      n = Rt(o, t), o.forEach(Q), i = It(l), this.h();
    },
    h() {
      Y(e, "class", "section-title svelte-1t8lt48"), Y(
        e,
        "style",
        /*section_title_style*/
        a[8]
      ), ke(
        e,
        "uppercase",
        /*section_title_uppercase*/
        a[5]
      );
    },
    m(l, o) {
      lt(l, e, o), De(e, n), lt(l, i, o);
    },
    p(l, o) {
      o & /*display_items*/
      2048 && t !== (t = /*item*/
      l[19].section_title + "") && Lt(n, t), o & /*section_title_style*/
      256 && Y(
        e,
        "style",
        /*section_title_style*/
        l[8]
      ), o & /*section_title_uppercase*/
      32 && ke(
        e,
        "uppercase",
        /*section_title_uppercase*/
        l[5]
      );
    },
    d(l) {
      l && (Q(e), Q(i));
    }
  };
}
function Hi(a) {
  let e, t = (
    /*item*/
    a[19].name + ""
  ), n, i;
  return {
    c() {
      e = Ke("p"), n = Pt(t), this.h();
    },
    l(l) {
      e = We(l, "P", { style: !0, class: !0 });
      var o = Ye(e);
      n = Rt(o, t), o.forEach(Q), this.h();
    },
    h() {
      Y(e, "style", i = /*name_style*/
      a[9](
        /*item*/
        a[19].is_intro
      )), Y(e, "class", "svelte-1t8lt48"), ke(
        e,
        "uppercase",
        /*name_uppercase*/
        a[4] && !/*item*/
        a[19].is_intro
      );
    },
    m(l, o) {
      lt(l, e, o), De(e, n);
    },
    p(l, o) {
      o & /*display_items*/
      2048 && t !== (t = /*item*/
      l[19].name + "") && Lt(n, t), o & /*name_style, display_items*/
      2560 && i !== (i = /*name_style*/
      l[9](
        /*item*/
        l[19].is_intro
      )) && Y(e, "style", i), o & /*name_uppercase, display_items*/
      2064 && ke(
        e,
        "uppercase",
        /*name_uppercase*/
        l[4] && !/*item*/
        l[19].is_intro
      );
    },
    d(l) {
      l && Q(e);
    }
  };
}
function xi(a) {
  let e;
  function t(l, o) {
    return (
      /*item*/
      l[19].section_title ? ks : (
        /*layout_style*/
        l[2] === "two-column" && !/*item*/
        l[19].is_intro ? ws : ys
      )
    );
  }
  let n = t(a), i = n(a);
  return {
    c() {
      i.c(), e = Oi();
    },
    l(l) {
      i.l(l), e = Oi();
    },
    m(l, o) {
      i.m(l, o), lt(l, e, o);
    },
    p(l, o) {
      n === (n = t(l)) && i ? i.p(l, o) : (i.d(1), i = n(l), i && (i.c(), i.m(e.parentNode, e)));
    },
    d(l) {
      l && Q(e), i.d(l);
    }
  };
}
function Fs(a) {
  let e, t = `${/*speed*/
  a[0]}s`, n = !/*reset*/
  a[7] && ji(a);
  return {
    c() {
      e = Ke("div"), n && n.c(), this.h();
    },
    l(i) {
      e = We(i, "DIV", { class: !0 });
      var l = Ye(e);
      n && n.l(l), l.forEach(Q), this.h();
    },
    h() {
      Y(e, "class", "wrapper svelte-1t8lt48"), on(e, "--animation-duration", t), on(
        e,
        "background",
        /*background_color*/
        a[1] || "black"
      );
    },
    m(i, l) {
      lt(i, e, l), n && n.m(e, null);
    },
    p(i, [l]) {
      /*reset*/
      i[7] ? n && (n.d(1), n = null) : n ? n.p(i, l) : (n = ji(i), n.c(), n.m(e, null)), l & /*speed*/
      1 && t !== (t = `${/*speed*/
      i[0]}s`) && on(e, "--animation-duration", t), l & /*background_color*/
      2 && on(
        e,
        "background",
        /*background_color*/
        i[1] || "black"
      );
    },
    i: Mi,
    o: Mi,
    d(i) {
      i && Q(e), n && n.d();
    }
  };
}
function $s(a, e, t) {
  let n, i, l, o, { credits: s } = e, { speed: r } = e, { base_font_size: u = 1.5 } = e, { background_color: _ = null } = e, { title_color: d = null } = e, { name_color: c = null } = e, { intro_title: h = null } = e, { intro_subtitle: g = null } = e, { layout_style: p = "stacked" } = e, { title_uppercase: D = !1 } = e, { name_uppercase: k = !1 } = e, { section_title_uppercase: m = !0 } = e, { swap_font_sizes_on_two_column: f = !1 } = e, v = !1;
  function y() {
    t(7, v = !0), setTimeout(() => t(7, v = !1), 0);
  }
  return a.$$set = (b) => {
    "credits" in b && t(12, s = b.credits), "speed" in b && t(0, r = b.speed), "base_font_size" in b && t(13, u = b.base_font_size), "background_color" in b && t(1, _ = b.background_color), "title_color" in b && t(14, d = b.title_color), "name_color" in b && t(15, c = b.name_color), "intro_title" in b && t(16, h = b.intro_title), "intro_subtitle" in b && t(17, g = b.intro_subtitle), "layout_style" in b && t(2, p = b.layout_style), "title_uppercase" in b && t(3, D = b.title_uppercase), "name_uppercase" in b && t(4, k = b.name_uppercase), "section_title_uppercase" in b && t(5, m = b.section_title_uppercase), "swap_font_sizes_on_two_column" in b && t(6, f = b.swap_font_sizes_on_two_column);
  }, a.$$.update = () => {
    a.$$.dirty & /*intro_title, intro_subtitle, credits*/
    200704 && t(11, n = (() => {
      const b = [];
      return (h || g) && b.push({
        title: h || "",
        name: g || "",
        is_intro: !0
      }), [
        ...b,
        ...s.map((F) => Object.assign(Object.assign({}, F), { is_intro: !1 }))
      ];
    })()), a.$$.dirty & /*title_color, base_font_size*/
    24576 && t(10, i = (b) => `color: ${d || "white"}; font-size: ${b ? u * 1.5 : u}rem;`), a.$$.dirty & /*name_color, base_font_size*/
    40960 && t(9, l = (b) => `color: ${c || "white"}; font-size: ${b ? u * 0.9 : u * 0.8}rem;`), a.$$.dirty & /*title_color, base_font_size*/
    24576 && t(8, o = `color: ${d || "white"}; font-size: ${u * 1.2}rem;`), a.$$.dirty & /*credits, speed*/
    4097 && y();
  }, [
    r,
    _,
    p,
    D,
    k,
    m,
    f,
    v,
    o,
    l,
    i,
    n,
    s,
    u,
    d,
    c,
    h,
    g
  ];
}
class Cs extends gs {
  constructor(e) {
    super(), bs(this, e, $s, Fs, Ds, {
      credits: 12,
      speed: 0,
      base_font_size: 13,
      background_color: 1,
      title_color: 14,
      name_color: 15,
      intro_title: 16,
      intro_subtitle: 17,
      layout_style: 2,
      title_uppercase: 3,
      name_uppercase: 4,
      section_title_uppercase: 5,
      swap_font_sizes_on_two_column: 6
    });
  }
}
const {
  SvelteComponent: Es,
  append_hydration: U,
  attr: j,
  binding_callbacks: As,
  children: he,
  claim_element: pe,
  claim_space: Qe,
  claim_text: Mt,
  destroy_each: Ss,
  detach: X,
  element: me,
  empty: Vi,
  ensure_array_like: Ui,
  init: Bs,
  insert_hydration: ct,
  noop: Gi,
  safe_not_equal: qs,
  set_data: Nt,
  set_style: rt,
  space: Je,
  text: jt,
  toggle_class: Fe
} = window.__gradio__svelte__internal, { onMount: Ts, onDestroy: zs } = window.__gradio__svelte__internal;
function Zi(a, e, t) {
  const n = a.slice();
  return n[24] = e[t], n;
}
function Is(a) {
  let e, t, n = (
    /*item*/
    a[24].title + ""
  ), i, l, o, s, r = (
    /*item*/
    a[24].name && Xi(a)
  );
  return {
    c() {
      e = me("div"), t = me("h2"), i = jt(n), o = Je(), r && r.c(), s = Je(), this.h();
    },
    l(u) {
      e = pe(u, "DIV", { class: !0 });
      var _ = he(e);
      t = pe(_, "H2", { style: !0, class: !0 });
      var d = he(t);
      i = Mt(d, n), d.forEach(X), o = Qe(_), r && r.l(_), s = Qe(_), _.forEach(X), this.h();
    },
    h() {
      j(t, "style", l = /*title_style*/
      a[11](
        /*item*/
        a[24].is_intro
      )), j(t, "class", "svelte-upsott"), Fe(
        t,
        "uppercase",
        /*title_uppercase*/
        a[3] && !/*item*/
        a[24].is_intro
      ), j(e, "class", "credit svelte-upsott"), Fe(
        e,
        "intro-block",
        /*item*/
        a[24].is_intro
      );
    },
    m(u, _) {
      ct(u, e, _), U(e, t), U(t, i), U(e, o), r && r.m(e, null), U(e, s);
    },
    p(u, _) {
      _ & /*display_items*/
      256 && n !== (n = /*item*/
      u[24].title + "") && Nt(i, n), _ & /*title_style, display_items*/
      2304 && l !== (l = /*title_style*/
      u[11](
        /*item*/
        u[24].is_intro
      )) && j(t, "style", l), _ & /*title_uppercase, display_items*/
      264 && Fe(
        t,
        "uppercase",
        /*title_uppercase*/
        u[3] && !/*item*/
        u[24].is_intro
      ), /*item*/
      u[24].name ? r ? r.p(u, _) : (r = Xi(u), r.c(), r.m(e, s)) : r && (r.d(1), r = null), _ & /*display_items*/
      256 && Fe(
        e,
        "intro-block",
        /*item*/
        u[24].is_intro
      );
    },
    d(u) {
      u && X(e), r && r.d();
    }
  };
}
function Rs(a) {
  let e, t, n = (
    /*item*/
    a[24].title + ""
  ), i, l, o, s, r, u, _ = (
    /*item*/
    a[24].name + ""
  ), d, c, h;
  return {
    c() {
      e = me("div"), t = me("span"), i = jt(n), o = Je(), s = me("span"), r = Je(), u = me("span"), d = jt(_), h = Je(), this.h();
    },
    l(g) {
      e = pe(g, "DIV", { class: !0 });
      var p = he(e);
      t = pe(p, "SPAN", { style: !0, class: !0 });
      var D = he(t);
      i = Mt(D, n), D.forEach(X), o = Qe(p), s = pe(p, "SPAN", { class: !0 }), he(s).forEach(X), r = Qe(p), u = pe(p, "SPAN", { style: !0, class: !0 });
      var k = he(u);
      d = Mt(k, _), k.forEach(X), h = Qe(p), p.forEach(X), this.h();
    },
    h() {
      j(t, "style", l = /*swap_font_sizes_on_two_column*/
      a[6] ? (
        /*name_style*/
        a[10](!1)
      ) : (
        /*title_style*/
        a[11](!1)
      )), j(t, "class", "svelte-upsott"), Fe(
        t,
        "uppercase",
        /*title_uppercase*/
        a[3]
      ), j(s, "class", "spacer svelte-upsott"), j(u, "style", c = /*swap_font_sizes_on_two_column*/
      a[6] ? (
        /*title_style*/
        a[11](!1)
      ) : (
        /*name_style*/
        a[10](!1)
      )), j(u, "class", "svelte-upsott"), Fe(
        u,
        "uppercase",
        /*name_uppercase*/
        a[4]
      ), j(e, "class", "credit-two-column svelte-upsott");
    },
    m(g, p) {
      ct(g, e, p), U(e, t), U(t, i), U(e, o), U(e, s), U(e, r), U(e, u), U(u, d), U(e, h);
    },
    p(g, p) {
      p & /*display_items*/
      256 && n !== (n = /*item*/
      g[24].title + "") && Nt(i, n), p & /*swap_font_sizes_on_two_column, name_style, title_style*/
      3136 && l !== (l = /*swap_font_sizes_on_two_column*/
      g[6] ? (
        /*name_style*/
        g[10](!1)
      ) : (
        /*title_style*/
        g[11](!1)
      )) && j(t, "style", l), p & /*title_uppercase*/
      8 && Fe(
        t,
        "uppercase",
        /*title_uppercase*/
        g[3]
      ), p & /*display_items*/
      256 && _ !== (_ = /*item*/
      g[24].name + "") && Nt(d, _), p & /*swap_font_sizes_on_two_column, title_style, name_style*/
      3136 && c !== (c = /*swap_font_sizes_on_two_column*/
      g[6] ? (
        /*title_style*/
        g[11](!1)
      ) : (
        /*name_style*/
        g[10](!1)
      )) && j(u, "style", c), p & /*name_uppercase*/
      16 && Fe(
        u,
        "uppercase",
        /*name_uppercase*/
        g[4]
      );
    },
    d(g) {
      g && X(e);
    }
  };
}
function Ls(a) {
  let e, t = (
    /*item*/
    a[24].section_title + ""
  ), n, i;
  return {
    c() {
      e = me("div"), n = jt(t), i = Je(), this.h();
    },
    l(l) {
      e = pe(l, "DIV", { class: !0, style: !0 });
      var o = he(e);
      n = Mt(o, t), o.forEach(X), i = Qe(l), this.h();
    },
    h() {
      j(e, "class", "section-title svelte-upsott"), j(
        e,
        "style",
        /*section_title_style*/
        a[9]
      ), Fe(
        e,
        "uppercase",
        /*section_title_uppercase*/
        a[5]
      );
    },
    m(l, o) {
      ct(l, e, o), U(e, n), ct(l, i, o);
    },
    p(l, o) {
      o & /*display_items*/
      256 && t !== (t = /*item*/
      l[24].section_title + "") && Nt(n, t), o & /*section_title_style*/
      512 && j(
        e,
        "style",
        /*section_title_style*/
        l[9]
      ), o & /*section_title_uppercase*/
      32 && Fe(
        e,
        "uppercase",
        /*section_title_uppercase*/
        l[5]
      );
    },
    d(l) {
      l && (X(e), X(i));
    }
  };
}
function Xi(a) {
  let e, t = (
    /*item*/
    a[24].name + ""
  ), n, i;
  return {
    c() {
      e = me("p"), n = jt(t), this.h();
    },
    l(l) {
      e = pe(l, "P", { style: !0, class: !0 });
      var o = he(e);
      n = Mt(o, t), o.forEach(X), this.h();
    },
    h() {
      j(e, "style", i = /*name_style*/
      a[10](
        /*item*/
        a[24].is_intro
      )), j(e, "class", "svelte-upsott"), Fe(
        e,
        "uppercase",
        /*name_uppercase*/
        a[4] && !/*item*/
        a[24].is_intro
      );
    },
    m(l, o) {
      ct(l, e, o), U(e, n);
    },
    p(l, o) {
      o & /*display_items*/
      256 && t !== (t = /*item*/
      l[24].name + "") && Nt(n, t), o & /*name_style, display_items*/
      1280 && i !== (i = /*name_style*/
      l[10](
        /*item*/
        l[24].is_intro
      )) && j(e, "style", i), o & /*name_uppercase, display_items*/
      272 && Fe(
        e,
        "uppercase",
        /*name_uppercase*/
        l[4] && !/*item*/
        l[24].is_intro
      );
    },
    d(l) {
      l && X(e);
    }
  };
}
function Yi(a) {
  let e;
  function t(l, o) {
    return (
      /*item*/
      l[24].section_title ? Ls : (
        /*layout_style*/
        l[2] === "two-column" && !/*item*/
        l[24].is_intro ? Rs : Is
      )
    );
  }
  let n = t(a), i = n(a);
  return {
    c() {
      i.c(), e = Vi();
    },
    l(l) {
      i.l(l), e = Vi();
    },
    m(l, o) {
      i.m(l, o), ct(l, e, o);
    },
    p(l, o) {
      n === (n = t(l)) && i ? i.p(l, o) : (i.d(1), i = n(l), i && (i.c(), i.m(e.parentNode, e)));
    },
    d(l) {
      l && X(e), i.d(l);
    }
  };
}
function Os(a) {
  let e, t, n, i, l, o, s, r, u = Ui(
    /*display_items*/
    a[8]
  ), _ = [];
  for (let d = 0; d < u.length; d += 1)
    _[d] = Yi(Zi(a, u, d));
  return {
    c() {
      e = me("div"), t = me("div"), n = Je(), i = me("div"), l = Je(), o = me("div"), s = Je(), r = me("div");
      for (let d = 0; d < _.length; d += 1)
        _[d].c();
      this.h();
    },
    l(d) {
      e = pe(d, "DIV", { class: !0 });
      var c = he(e);
      t = pe(c, "DIV", { class: !0, style: !0 }), he(t).forEach(X), n = Qe(c), i = pe(c, "DIV", { class: !0, style: !0 }), he(i).forEach(X), l = Qe(c), o = pe(c, "DIV", { class: !0, style: !0 }), he(o).forEach(X), s = Qe(c), r = pe(c, "DIV", { class: !0, style: !0 });
      var h = he(r);
      for (let g = 0; g < _.length; g += 1)
        _[g].l(h);
      h.forEach(X), c.forEach(X), this.h();
    },
    h() {
      j(t, "class", "stars small svelte-upsott"), rt(
        t,
        "box-shadow",
        /*small_stars*/
        a[12]
      ), j(i, "class", "stars medium svelte-upsott"), rt(
        i,
        "box-shadow",
        /*medium_stars*/
        a[13]
      ), j(o, "class", "stars large svelte-upsott"), rt(
        o,
        "box-shadow",
        /*large_stars*/
        a[14]
      ), j(r, "class", "crawl svelte-upsott"), rt(
        r,
        "--animation-duration",
        /*speed*/
        a[0] + "s"
      ), j(e, "class", "viewport svelte-upsott"), rt(
        e,
        "background",
        /*background_color*/
        a[1] || "black"
      );
    },
    m(d, c) {
      ct(d, e, c), U(e, t), U(e, n), U(e, i), U(e, l), U(e, o), U(e, s), U(e, r);
      for (let h = 0; h < _.length; h += 1)
        _[h] && _[h].m(r, null);
      a[21](r);
    },
    p(d, [c]) {
      if (c & /*section_title_style, section_title_uppercase, display_items, swap_font_sizes_on_two_column, title_style, name_style, name_uppercase, title_uppercase, layout_style*/
      3964) {
        u = Ui(
          /*display_items*/
          d[8]
        );
        let h;
        for (h = 0; h < u.length; h += 1) {
          const g = Zi(d, u, h);
          _[h] ? _[h].p(g, c) : (_[h] = Yi(g), _[h].c(), _[h].m(r, null));
        }
        for (; h < _.length; h += 1)
          _[h].d(1);
        _.length = u.length;
      }
      c & /*speed*/
      1 && rt(
        r,
        "--animation-duration",
        /*speed*/
        d[0] + "s"
      ), c & /*background_color*/
      2 && rt(
        e,
        "background",
        /*background_color*/
        d[1] || "black"
      );
    },
    i: Gi,
    o: Gi,
    d(d) {
      d && X(e), Ss(_, d), a[21](null);
    }
  };
}
function Ps(a, e, t) {
  let n, i, l, o, { credits: s } = e, { speed: r = 40 } = e, { base_font_size: u = 1.5 } = e, { background_color: _ = null } = e, { title_color: d = null } = e, { name_color: c = null } = e, { intro_title: h = null } = e, { intro_subtitle: g = null } = e, { layout_style: p = "stacked" } = e, { title_uppercase: D = !1 } = e, { name_uppercase: k = !1 } = e, { section_title_uppercase: m = !0 } = e, { swap_font_sizes_on_two_column: f = !1 } = e, v;
  function y() {
    v && (t(7, v.style.animation = "none", v), v.offsetHeight, t(7, v.style.animation = "", v));
  }
  Ts(y), zs(() => {
    t(7, v = null);
  });
  const b = (w, $) => Array.from({ length: w }, () => `${Math.random() * 2e3}px ${Math.random() * 2e3}px ${$} white`).join(", "), F = b(200, "1px"), A = b(100, "2px"), E = b(50, "3px");
  function q(w) {
    As[w ? "unshift" : "push"](() => {
      v = w, t(7, v);
    });
  }
  return a.$$set = (w) => {
    "credits" in w && t(15, s = w.credits), "speed" in w && t(0, r = w.speed), "base_font_size" in w && t(16, u = w.base_font_size), "background_color" in w && t(1, _ = w.background_color), "title_color" in w && t(17, d = w.title_color), "name_color" in w && t(18, c = w.name_color), "intro_title" in w && t(19, h = w.intro_title), "intro_subtitle" in w && t(20, g = w.intro_subtitle), "layout_style" in w && t(2, p = w.layout_style), "title_uppercase" in w && t(3, D = w.title_uppercase), "name_uppercase" in w && t(4, k = w.name_uppercase), "section_title_uppercase" in w && t(5, m = w.section_title_uppercase), "swap_font_sizes_on_two_column" in w && t(6, f = w.swap_font_sizes_on_two_column);
  }, a.$$.update = () => {
    a.$$.dirty & /*title_color, base_font_size*/
    196608 && t(11, n = (w) => `color: ${d || "#feda4a"}; font-size: ${w ? u * 1.5 : u}rem;`), a.$$.dirty & /*name_color, base_font_size*/
    327680 && t(10, i = (w) => `color: ${c || "#feda4a"}; font-size: ${w ? u * 0.9 : u * 0.7}rem;`), a.$$.dirty & /*title_color, base_font_size*/
    196608 && t(9, l = `color: ${d || "#feda4a"}; font-size: ${u * 1.2}rem;`), a.$$.dirty & /*intro_title, intro_subtitle, credits*/
    1605632 && t(8, o = (() => {
      const w = [];
      return (h || g) && w.push({
        title: h || "",
        name: g || "",
        is_intro: !0
      }), [
        ...w,
        ...s.map(($) => Object.assign(Object.assign({}, $), { is_intro: !1 }))
      ];
    })()), a.$$.dirty & /*credits, speed, layout_style*/
    32773 && y();
  }, [
    r,
    _,
    p,
    D,
    k,
    m,
    f,
    v,
    o,
    l,
    i,
    n,
    F,
    A,
    E,
    s,
    u,
    d,
    c,
    h,
    g,
    q
  ];
}
class Ms extends Es {
  constructor(e) {
    super(), Bs(this, e, Ps, Os, qs, {
      credits: 15,
      speed: 0,
      base_font_size: 16,
      background_color: 1,
      title_color: 17,
      name_color: 18,
      intro_title: 19,
      intro_subtitle: 20,
      layout_style: 2,
      title_uppercase: 3,
      name_uppercase: 4,
      section_title_uppercase: 5,
      swap_font_sizes_on_two_column: 6
    });
  }
}
const {
  SvelteComponent: Ns,
  append_hydration: ie,
  attr: G,
  binding_callbacks: Wi,
  children: Le,
  claim_element: Oe,
  claim_space: Dt,
  claim_text: Ht,
  destroy_each: js,
  detach: K,
  element: Pe,
  empty: Ki,
  ensure_array_like: Qi,
  init: Hs,
  insert_hydration: dt,
  noop: Ji,
  safe_not_equal: xs,
  set_data: xt,
  set_style: el,
  space: yt,
  text: Vt,
  toggle_class: $e
} = window.__gradio__svelte__internal, { onMount: Vs, onDestroy: Us } = window.__gradio__svelte__internal;
function tl(a, e, t) {
  const n = a.slice();
  return n[25] = e[t], n;
}
function Gs(a) {
  let e, t, n = (
    /*item*/
    a[25].title + ""
  ), i, l, o, s, r = (
    /*item*/
    a[25].name && nl(a)
  );
  return {
    c() {
      e = Pe("div"), t = Pe("div"), i = Vt(n), o = yt(), r && r.c(), s = yt(), this.h();
    },
    l(u) {
      e = Oe(u, "DIV", { class: !0 });
      var _ = Le(e);
      t = Oe(_, "DIV", { style: !0, class: !0 });
      var d = Le(t);
      i = Ht(d, n), d.forEach(K), o = Dt(_), r && r.l(_), s = Dt(_), _.forEach(K), this.h();
    },
    h() {
      G(t, "style", l = /*title_style*/
      a[10](
        /*item*/
        a[25].is_intro
      )), G(t, "class", "title svelte-1851m15"), $e(
        t,
        "uppercase",
        /*title_uppercase*/
        a[2] && !/*item*/
        a[25].is_intro
      ), G(e, "class", "credit-block svelte-1851m15"), $e(
        e,
        "intro-block",
        /*item*/
        a[25].is_intro
      );
    },
    m(u, _) {
      dt(u, e, _), ie(e, t), ie(t, i), ie(e, o), r && r.m(e, null), ie(e, s);
    },
    p(u, _) {
      _ & /*display_items*/
      2048 && n !== (n = /*item*/
      u[25].title + "") && xt(i, n), _ & /*title_style, display_items*/
      3072 && l !== (l = /*title_style*/
      u[10](
        /*item*/
        u[25].is_intro
      )) && G(t, "style", l), _ & /*title_uppercase, display_items*/
      2052 && $e(
        t,
        "uppercase",
        /*title_uppercase*/
        u[2] && !/*item*/
        u[25].is_intro
      ), /*item*/
      u[25].name ? r ? r.p(u, _) : (r = nl(u), r.c(), r.m(e, s)) : r && (r.d(1), r = null), _ & /*display_items*/
      2048 && $e(
        e,
        "intro-block",
        /*item*/
        u[25].is_intro
      );
    },
    d(u) {
      u && K(e), r && r.d();
    }
  };
}
function Zs(a) {
  let e, t, n = (
    /*item*/
    a[25].title + ""
  ), i, l, o, s, r = (
    /*item*/
    a[25].name + ""
  ), u, _, d;
  return {
    c() {
      e = Pe("div"), t = Pe("div"), i = Vt(n), o = yt(), s = Pe("div"), u = Vt(r), d = yt(), this.h();
    },
    l(c) {
      e = Oe(c, "DIV", { class: !0 });
      var h = Le(e);
      t = Oe(h, "DIV", { class: !0, style: !0 });
      var g = Le(t);
      i = Ht(g, n), g.forEach(K), o = Dt(h), s = Oe(h, "DIV", { class: !0, style: !0 });
      var p = Le(s);
      u = Ht(p, r), p.forEach(K), d = Dt(h), h.forEach(K), this.h();
    },
    h() {
      G(t, "class", "title svelte-1851m15"), G(t, "style", l = /*swap_font_sizes_on_two_column*/
      a[5] ? (
        /*name_style*/
        a[9](!1)
      ) : (
        /*title_style*/
        a[10](!1)
      )), $e(
        t,
        "uppercase",
        /*title_uppercase*/
        a[2]
      ), G(s, "class", "name svelte-1851m15"), G(s, "style", _ = /*swap_font_sizes_on_two_column*/
      a[5] ? (
        /*title_style*/
        a[10](!1)
      ) : (
        /*name_style*/
        a[9](!1)
      )), $e(
        s,
        "uppercase",
        /*name_uppercase*/
        a[3]
      ), G(e, "class", "credit-two-column svelte-1851m15");
    },
    m(c, h) {
      dt(c, e, h), ie(e, t), ie(t, i), ie(e, o), ie(e, s), ie(s, u), ie(e, d);
    },
    p(c, h) {
      h & /*display_items*/
      2048 && n !== (n = /*item*/
      c[25].title + "") && xt(i, n), h & /*swap_font_sizes_on_two_column, name_style, title_style*/
      1568 && l !== (l = /*swap_font_sizes_on_two_column*/
      c[5] ? (
        /*name_style*/
        c[9](!1)
      ) : (
        /*title_style*/
        c[10](!1)
      )) && G(t, "style", l), h & /*title_uppercase*/
      4 && $e(
        t,
        "uppercase",
        /*title_uppercase*/
        c[2]
      ), h & /*display_items*/
      2048 && r !== (r = /*item*/
      c[25].name + "") && xt(u, r), h & /*swap_font_sizes_on_two_column, title_style, name_style*/
      1568 && _ !== (_ = /*swap_font_sizes_on_two_column*/
      c[5] ? (
        /*title_style*/
        c[10](!1)
      ) : (
        /*name_style*/
        c[9](!1)
      )) && G(s, "style", _), h & /*name_uppercase*/
      8 && $e(
        s,
        "uppercase",
        /*name_uppercase*/
        c[3]
      );
    },
    d(c) {
      c && K(e);
    }
  };
}
function Xs(a) {
  let e, t = (
    /*item*/
    a[25].section_title + ""
  ), n, i;
  return {
    c() {
      e = Pe("div"), n = Vt(t), i = yt(), this.h();
    },
    l(l) {
      e = Oe(l, "DIV", { class: !0, style: !0 });
      var o = Le(e);
      n = Ht(o, t), o.forEach(K), i = Dt(l), this.h();
    },
    h() {
      G(e, "class", "section-title svelte-1851m15"), G(
        e,
        "style",
        /*section_title_style*/
        a[8]
      ), $e(
        e,
        "uppercase",
        /*section_title_uppercase*/
        a[4]
      );
    },
    m(l, o) {
      dt(l, e, o), ie(e, n), dt(l, i, o);
    },
    p(l, o) {
      o & /*display_items*/
      2048 && t !== (t = /*item*/
      l[25].section_title + "") && xt(n, t), o & /*section_title_style*/
      256 && G(
        e,
        "style",
        /*section_title_style*/
        l[8]
      ), o & /*section_title_uppercase*/
      16 && $e(
        e,
        "uppercase",
        /*section_title_uppercase*/
        l[4]
      );
    },
    d(l) {
      l && (K(e), K(i));
    }
  };
}
function nl(a) {
  let e, t = (
    /*item*/
    a[25].name + ""
  ), n, i;
  return {
    c() {
      e = Pe("div"), n = Vt(t), this.h();
    },
    l(l) {
      e = Oe(l, "DIV", { style: !0, class: !0 });
      var o = Le(e);
      n = Ht(o, t), o.forEach(K), this.h();
    },
    h() {
      G(e, "style", i = /*name_style*/
      a[9](
        /*item*/
        a[25].is_intro
      )), G(e, "class", "name svelte-1851m15"), $e(
        e,
        "uppercase",
        /*name_uppercase*/
        a[3] && !/*item*/
        a[25].is_intro
      );
    },
    m(l, o) {
      dt(l, e, o), ie(e, n);
    },
    p(l, o) {
      o & /*display_items*/
      2048 && t !== (t = /*item*/
      l[25].name + "") && xt(n, t), o & /*name_style, display_items*/
      2560 && i !== (i = /*name_style*/
      l[9](
        /*item*/
        l[25].is_intro
      )) && G(e, "style", i), o & /*name_uppercase, display_items*/
      2056 && $e(
        e,
        "uppercase",
        /*name_uppercase*/
        l[3] && !/*item*/
        l[25].is_intro
      );
    },
    d(l) {
      l && K(e);
    }
  };
}
function il(a) {
  let e;
  function t(l, o) {
    return (
      /*item*/
      l[25].section_title ? Xs : (
        /*layout_style*/
        l[1] === "two-column" && !/*item*/
        l[25].is_intro ? Zs : Gs
      )
    );
  }
  let n = t(a), i = n(a);
  return {
    c() {
      i.c(), e = Ki();
    },
    l(l) {
      i.l(l), e = Ki();
    },
    m(l, o) {
      i.m(l, o), dt(l, e, o);
    },
    p(l, o) {
      n === (n = t(l)) && i ? i.p(l, o) : (i.d(1), i = n(l), i && (i.c(), i.m(e.parentNode, e)));
    },
    d(l) {
      l && K(e), i.d(l);
    }
  };
}
function Ys(a) {
  let e, t, n, i, l, o = Qi(
    /*display_items*/
    a[11]
  ), s = [];
  for (let r = 0; r < o.length; r += 1)
    s[r] = il(tl(a, o, r));
  return {
    c() {
      e = Pe("div"), t = Pe("canvas"), n = yt(), i = Pe("div"), l = Pe("div");
      for (let r = 0; r < s.length; r += 1)
        s[r].c();
      this.h();
    },
    l(r) {
      e = Oe(r, "DIV", { class: !0 });
      var u = Le(e);
      t = Oe(u, "CANVAS", { class: !0 }), Le(t).forEach(K), n = Dt(u), i = Oe(u, "DIV", { class: !0 });
      var _ = Le(i);
      l = Oe(_, "DIV", { class: !0, style: !0 });
      var d = Le(l);
      for (let c = 0; c < s.length; c += 1)
        s[c].l(d);
      d.forEach(K), _.forEach(K), u.forEach(K), this.h();
    },
    h() {
      G(t, "class", "svelte-1851m15"), G(l, "class", "credits-content svelte-1851m15"), el(
        l,
        "--animation-duration",
        /*speed*/
        a[0] + "s"
      ), G(i, "class", "credits-scroll-overlay svelte-1851m15"), G(e, "class", "matrix-container svelte-1851m15");
    },
    m(r, u) {
      dt(r, e, u), ie(e, t), a[16](t), ie(e, n), ie(e, i), ie(i, l);
      for (let _ = 0; _ < s.length; _ += 1)
        s[_] && s[_].m(l, null);
      a[17](l);
    },
    p(r, [u]) {
      if (u & /*section_title_style, section_title_uppercase, display_items, swap_font_sizes_on_two_column, title_style, name_style, name_uppercase, title_uppercase, layout_style*/
      3902) {
        o = Qi(
          /*display_items*/
          r[11]
        );
        let _;
        for (_ = 0; _ < o.length; _ += 1) {
          const d = tl(r, o, _);
          s[_] ? s[_].p(d, u) : (s[_] = il(d), s[_].c(), s[_].m(l, null));
        }
        for (; _ < s.length; _ += 1)
          s[_].d(1);
        s.length = o.length;
      }
      u & /*speed*/
      1 && el(
        l,
        "--animation-duration",
        /*speed*/
        r[0] + "s"
      );
    },
    i: Ji,
    o: Ji,
    d(r) {
      r && K(e), a[16](null), js(s, r), a[17](null);
    }
  };
}
const At = 16, ll = "アァカサタナハマヤャラワガザダバパイィキシチニヒミリヰギジヂビピウゥクスツヌフムユュルグズブヅプエェケセテネヘメレヱゲゼデベペオォコソトノホモヨョロヲゴゾドボポヴッン01";
function Ws(a, e, t) {
  let n, i, l, o, { credits: s } = e, { speed: r = 20 } = e, { base_font_size: u = 1 } = e, { intro_title: _ = null } = e, { intro_subtitle: d = null } = e, { layout_style: c = "stacked" } = e, { title_uppercase: h = !1 } = e, { name_uppercase: g = !1 } = e, { section_title_uppercase: p = !0 } = e, { swap_font_sizes_on_two_column: D = !1 } = e, k, m, f, v, y = [], b;
  function F() {
    if (!k) return;
    const $ = k.parentElement;
    $ && (t(6, k.width = $.clientWidth, k), t(6, k.height = $.clientHeight, k)), m = k.getContext("2d"), v = Math.floor(k.width / At), y = Array(v).fill(1);
  }
  function A() {
    if (m) {
      m.fillStyle = "rgba(0, 0, 0, 0.05)", m.fillRect(0, 0, k.width, k.height), m.fillStyle = "#0F0", m.font = `${At}px monospace`;
      for (let $ = 0; $ < y.length; $++) {
        const ge = ll.charAt(Math.floor(Math.random() * ll.length));
        m.fillText(ge, $ * At, y[$] * At), y[$] * At > k.height && Math.random() > 0.975 && (y[$] = 0), y[$]++;
      }
      b = requestAnimationFrame(A);
    }
  }
  function E() {
    f && (t(7, f.style.animation = "none", f), f.offsetHeight, t(7, f.style.animation = "", f));
  }
  Vs(() => {
    F(), A(), E();
    const $ = new ResizeObserver(() => {
      cancelAnimationFrame(b), F(), A();
    });
    return k.parentElement && $.observe(k.parentElement), () => {
      cancelAnimationFrame(b), k.parentElement && $.unobserve(k.parentElement);
    };
  }), Us(() => {
    t(7, f = null);
  });
  function q($) {
    Wi[$ ? "unshift" : "push"](() => {
      k = $, t(6, k);
    });
  }
  function w($) {
    Wi[$ ? "unshift" : "push"](() => {
      f = $, t(7, f);
    });
  }
  return a.$$set = ($) => {
    "credits" in $ && t(12, s = $.credits), "speed" in $ && t(0, r = $.speed), "base_font_size" in $ && t(13, u = $.base_font_size), "intro_title" in $ && t(14, _ = $.intro_title), "intro_subtitle" in $ && t(15, d = $.intro_subtitle), "layout_style" in $ && t(1, c = $.layout_style), "title_uppercase" in $ && t(2, h = $.title_uppercase), "name_uppercase" in $ && t(3, g = $.name_uppercase), "section_title_uppercase" in $ && t(4, p = $.section_title_uppercase), "swap_font_sizes_on_two_column" in $ && t(5, D = $.swap_font_sizes_on_two_column);
  }, a.$$.update = () => {
    a.$$.dirty & /*intro_title, intro_subtitle, credits*/
    53248 && t(11, n = (() => {
      const $ = [];
      return (_ || d) && $.push({
        title: _ || "",
        name: d || "",
        is_intro: !0
      }), [
        ...$,
        ...s.map((ge) => Object.assign(Object.assign({}, ge), { is_intro: !1 }))
      ];
    })()), a.$$.dirty & /*base_font_size*/
    8192 && t(10, i = ($) => `font-size: ${$ ? u * 1.5 : u}em;`), a.$$.dirty & /*base_font_size*/
    8192 && t(9, l = ($) => `font-size: ${$ ? u * 0.9 : u * 0.8}em;`), a.$$.dirty & /*base_font_size*/
    8192 && t(8, o = `font-size: ${u * 1.2}em;`), a.$$.dirty & /*credits, speed, intro_title, intro_subtitle, layout_style*/
    53251 && E();
  }, [
    r,
    c,
    h,
    g,
    p,
    D,
    k,
    f,
    o,
    l,
    i,
    n,
    s,
    u,
    _,
    d,
    q,
    w
  ];
}
class Ks extends Ns {
  constructor(e) {
    super(), Hs(this, e, Ws, Ys, xs, {
      credits: 12,
      speed: 0,
      base_font_size: 13,
      intro_title: 14,
      intro_subtitle: 15,
      layout_style: 1,
      title_uppercase: 2,
      name_uppercase: 3,
      section_title_uppercase: 4,
      swap_font_sizes_on_two_column: 5
    });
  }
}
const { setContext: z4, getContext: Qs } = window.__gradio__svelte__internal, Js = "WORKER_PROXY_CONTEXT_KEY";
function er() {
  return Qs(Js);
}
const tr = "lite.local";
function nr(a) {
  return a.host === window.location.host || a.host === "localhost:7860" || a.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  a.host === tr;
}
function ir(a, e) {
  const t = e.toLowerCase();
  for (const [n, i] of Object.entries(a))
    if (n.toLowerCase() === t)
      return i;
}
function lr(a) {
  const e = typeof window < "u";
  if (a == null || !e)
    return !1;
  const t = new URL(a, window.location.href);
  return !(!nr(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
let sn;
async function ar(a) {
  const e = typeof window < "u";
  if (a == null || !e || !lr(a))
    return a;
  if (sn == null)
    try {
      sn = er();
    } catch {
      return a;
    }
  if (sn == null)
    return a;
  const n = new URL(a, window.location.href).pathname;
  return sn.httpRequest({
    method: "GET",
    path: n,
    headers: {},
    query_string: ""
  }).then((i) => {
    if (i.status !== 200)
      throw new Error(`Failed to get file ${n} from the Wasm worker.`);
    const l = new Blob([i.body], {
      type: ir(i.headers, "content-type")
    });
    return URL.createObjectURL(l);
  });
}
const {
  SvelteComponent: I4,
  assign: R4,
  check_outros: L4,
  children: O4,
  claim_element: P4,
  compute_rest_props: M4,
  create_slot: N4,
  detach: j4,
  element: H4,
  empty: x4,
  exclude_internal_props: V4,
  get_all_dirty_from_scope: U4,
  get_slot_changes: G4,
  get_spread_update: Z4,
  group_outros: X4,
  init: Y4,
  insert_hydration: W4,
  listen: K4,
  prevent_default: Q4,
  safe_not_equal: J4,
  set_attributes: e5,
  set_style: t5,
  toggle_class: n5,
  transition_in: i5,
  transition_out: l5,
  update_slot_base: a5
} = window.__gradio__svelte__internal, { createEventDispatcher: o5, onMount: s5 } = window.__gradio__svelte__internal, {
  SvelteComponent: or,
  assign: Ln,
  bubble: sr,
  claim_element: rr,
  compute_rest_props: al,
  detach: ur,
  element: _r,
  exclude_internal_props: cr,
  get_spread_update: dr,
  init: fr,
  insert_hydration: hr,
  listen: pr,
  noop: ol,
  safe_not_equal: mr,
  set_attributes: sl,
  src_url_equal: gr,
  toggle_class: rl
} = window.__gradio__svelte__internal;
function vr(a) {
  let e, t, n, i, l = [
    {
      src: t = /*resolved_src*/
      a[0]
    },
    /*$$restProps*/
    a[1]
  ], o = {};
  for (let s = 0; s < l.length; s += 1)
    o = Ln(o, l[s]);
  return {
    c() {
      e = _r("img"), this.h();
    },
    l(s) {
      e = rr(s, "IMG", { src: !0 }), this.h();
    },
    h() {
      sl(e, o), rl(e, "svelte-kxeri3", !0);
    },
    m(s, r) {
      hr(s, e, r), n || (i = pr(
        e,
        "load",
        /*load_handler*/
        a[4]
      ), n = !0);
    },
    p(s, [r]) {
      sl(e, o = dr(l, [
        r & /*resolved_src*/
        1 && !gr(e.src, t = /*resolved_src*/
        s[0]) && { src: t },
        r & /*$$restProps*/
        2 && /*$$restProps*/
        s[1]
      ])), rl(e, "svelte-kxeri3", !0);
    },
    i: ol,
    o: ol,
    d(s) {
      s && ur(e), n = !1, i();
    }
  };
}
function br(a, e, t) {
  const n = ["src"];
  let i = al(e, n), { src: l = void 0 } = e, o, s;
  function r(u) {
    sr.call(this, a, u);
  }
  return a.$$set = (u) => {
    e = Ln(Ln({}, e), cr(u)), t(1, i = al(e, n)), "src" in u && t(2, l = u.src);
  }, a.$$.update = () => {
    if (a.$$.dirty & /*src, latest_src*/
    12) {
      t(0, o = l), t(3, s = l);
      const u = l;
      ar(u).then((_) => {
        s === u && t(0, o = _);
      });
    }
  }, [o, i, l, s, r];
}
class Dr extends or {
  constructor(e) {
    super(), fr(this, e, br, vr, mr, { src: 2 });
  }
}
const {
  SvelteComponent: r5,
  append_hydration: u5,
  attr: _5,
  binding_callbacks: c5,
  bubble: d5,
  check_outros: f5,
  children: h5,
  claim_component: p5,
  claim_element: m5,
  claim_space: g5,
  create_component: v5,
  destroy_component: b5,
  detach: D5,
  element: y5,
  empty: w5,
  group_outros: k5,
  init: F5,
  insert_hydration: $5,
  listen: C5,
  mount_component: E5,
  safe_not_equal: A5,
  space: S5,
  toggle_class: B5,
  transition_in: q5,
  transition_out: T5
} = window.__gradio__svelte__internal, { createEventDispatcher: z5, onMount: I5 } = window.__gradio__svelte__internal, {
  SvelteComponent: yr,
  append_hydration: re,
  attr: le,
  check_outros: at,
  children: Ce,
  claim_component: wt,
  claim_element: ae,
  claim_space: et,
  claim_text: On,
  create_component: kt,
  create_slot: wr,
  destroy_block: kr,
  destroy_component: Ft,
  detach: I,
  element: oe,
  empty: ot,
  ensure_array_like: ul,
  get_all_dirty_from_scope: Fr,
  get_slot_changes: $r,
  get_svelte_dataset: Zn,
  group_outros: st,
  head_selector: Cr,
  init: Er,
  insert_hydration: J,
  listen: Ar,
  mount_component: $t,
  noop: Ut,
  safe_not_equal: pn,
  set_data: Pn,
  set_style: N,
  space: tt,
  src_url_equal: _l,
  text: Mn,
  toggle_class: cl,
  transition_in: P,
  transition_out: H,
  update_keyed_each: Sr,
  update_slot_base: Br
} = window.__gradio__svelte__internal;
function dl(a, e, t) {
  const n = a.slice();
  return n[24] = e[t][0], n[25] = e[t][1], n;
}
function fl(a) {
  let e, t, n, i;
  const l = [Tr, qr], o = [];
  function s(r, u) {
    return (
      /*gradio*/
      r[7] ? 0 : 1
    );
  }
  return t = s(a), n = o[t] = l[t](a), {
    c() {
      e = oe("div"), n.c(), this.h();
    },
    l(r) {
      e = ae(r, "DIV", { class: !0 });
      var u = Ce(e);
      n.l(u), u.forEach(I), this.h();
    },
    h() {
      le(e, "class", "logo-panel svelte-1hawtr7"), N(
        e,
        "height",
        /*logo_panel_height*/
        a[12]
      ), N(e, "display", "flex"), N(
        e,
        "justify-content",
        /*logo_justify*/
        a[10]
      );
    },
    m(r, u) {
      J(r, e, u), o[t].m(e, null), i = !0;
    },
    p(r, u) {
      let _ = t;
      t = s(r), t === _ ? o[t].p(r, u) : (st(), H(o[_], 1, 1, () => {
        o[_] = null;
      }), at(), n = o[t], n ? n.p(r, u) : (n = o[t] = l[t](r), n.c()), P(n, 1), n.m(e, null)), u & /*logo_panel_height*/
      4096 && N(
        e,
        "height",
        /*logo_panel_height*/
        r[12]
      ), u & /*logo_justify*/
      1024 && N(
        e,
        "justify-content",
        /*logo_justify*/
        r[10]
      );
    },
    i(r) {
      i || (P(n), i = !0);
    },
    o(r) {
      H(n), i = !1;
    },
    d(r) {
      r && I(e), o[t].d();
    }
  };
}
function qr(a) {
  let e, t;
  return {
    c() {
      e = oe("img"), this.h();
    },
    l(n) {
      e = ae(n, "IMG", { src: !0, alt: !0, style: !0 }), this.h();
    },
    h() {
      _l(e.src, t = /*effectiveValue*/
      a[8].logo_path.url) || le(e, "src", t), le(e, "alt", "Logo"), N(
        e,
        "width",
        /*logo_width_style*/
        a[14]
      ), N(
        e,
        "height",
        /*logo_height_style*/
        a[13]
      ), N(
        e,
        "object-fit",
        /*object_fit*/
        a[11]
      );
    },
    m(n, i) {
      J(n, e, i);
    },
    p(n, i) {
      i & /*effectiveValue*/
      256 && !_l(e.src, t = /*effectiveValue*/
      n[8].logo_path.url) && le(e, "src", t), i & /*logo_width_style*/
      16384 && N(
        e,
        "width",
        /*logo_width_style*/
        n[14]
      ), i & /*logo_height_style*/
      8192 && N(
        e,
        "height",
        /*logo_height_style*/
        n[13]
      ), i & /*object_fit*/
      2048 && N(
        e,
        "object-fit",
        /*object_fit*/
        n[11]
      );
    },
    i: Ut,
    o: Ut,
    d(n) {
      n && I(e);
    }
  };
}
function Tr(a) {
  let e, t;
  return e = new Dr({
    props: {
      src: (
        /*effectiveValue*/
        a[8].logo_path.url
      ),
      alt: "Logo",
      loading: "lazy",
      gradio: (
        /*gradio*/
        a[7]
      ),
      style: "width: " + /*logo_width_style*/
      a[14] + "; height: " + /*logo_height_style*/
      a[13] + "; object-fit: " + /*object_fit*/
      a[11] + ";"
    }
  }), {
    c() {
      kt(e.$$.fragment);
    },
    l(n) {
      wt(e.$$.fragment, n);
    },
    m(n, i) {
      $t(e, n, i), t = !0;
    },
    p(n, i) {
      const l = {};
      i & /*effectiveValue*/
      256 && (l.src = /*effectiveValue*/
      n[8].logo_path.url), i & /*gradio*/
      128 && (l.gradio = /*gradio*/
      n[7]), i & /*logo_width_style, logo_height_style, object_fit*/
      26624 && (l.style = "width: " + /*logo_width_style*/
      n[14] + "; height: " + /*logo_height_style*/
      n[13] + "; object-fit: " + /*object_fit*/
      n[11] + ";"), e.$set(l);
    },
    i(n) {
      t || (P(e.$$.fragment, n), t = !0);
    },
    o(n) {
      H(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Ft(e, n);
    }
  };
}
function hl(a) {
  var i;
  let e, t, n = (
    /*effectiveValue*/
    a[8].show_logo && /*effectiveValue*/
    ((i = a[8].logo_path) == null ? void 0 : i.url) && fl(a)
  );
  return {
    c() {
      e = oe("div"), n && n.c(), this.h();
    },
    l(l) {
      e = ae(l, "DIV", { class: !0 });
      var o = Ce(e);
      n && n.l(o), o.forEach(I), this.h();
    },
    h() {
      le(e, "class", "outer-logo-wrapper svelte-1hawtr7"), N(
        e,
        "width",
        /*width_style*/
        a[15]
      );
    },
    m(l, o) {
      J(l, e, o), n && n.m(e, null), t = !0;
    },
    p(l, o) {
      var s;
      /*effectiveValue*/
      l[8].show_logo && /*effectiveValue*/
      ((s = l[8].logo_path) != null && s.url) ? n ? (n.p(l, o), o & /*effectiveValue*/
      256 && P(n, 1)) : (n = fl(l), n.c(), P(n, 1), n.m(e, null)) : n && (st(), H(n, 1, 1, () => {
        n = null;
      }), at()), o & /*width_style*/
      32768 && N(
        e,
        "width",
        /*width_style*/
        l[15]
      );
    },
    i(l) {
      t || (P(n), t = !0);
    },
    o(l) {
      H(n), t = !1;
    },
    d(l) {
      l && I(e), n && n.d();
    }
  };
}
function pl(a) {
  let e = (
    /*effectiveValue*/
    a[8].sidebar_position
  ), t, n, i = yl(a);
  return {
    c() {
      i.c(), t = ot();
    },
    l(l) {
      i.l(l), t = ot();
    },
    m(l, o) {
      i.m(l, o), J(l, t, o), n = !0;
    },
    p(l, o) {
      o & /*effectiveValue*/
      256 && pn(e, e = /*effectiveValue*/
      l[8].sidebar_position) ? (st(), H(i, 1, 1, Ut), at(), i = yl(l), i.c(), P(i, 1), i.m(t.parentNode, t)) : i.p(l, o);
    },
    i(l) {
      n || (P(i), n = !0);
    },
    o(l) {
      H(i), n = !1;
    },
    d(l) {
      l && I(t), i.d(l);
    }
  };
}
function ml(a) {
  let e = {
    effect: (
      /*effectiveValue*/
      a[8].effect
    ),
    speed: (
      /*effectiveValue*/
      a[8].speed
    )
  }, t, n, i = gl(a);
  return {
    c() {
      i.c(), t = ot();
    },
    l(l) {
      i.l(l), t = ot();
    },
    m(l, o) {
      i.m(l, o), J(l, t, o), n = !0;
    },
    p(l, o) {
      o & /*effectiveValue*/
      256 && pn(e, e = {
        effect: (
          /*effectiveValue*/
          l[8].effect
        ),
        speed: (
          /*effectiveValue*/
          l[8].speed
        )
      }) ? (st(), H(i, 1, 1, Ut), at(), i = gl(l), i.c(), P(i, 1), i.m(t.parentNode, t)) : i.p(l, o);
    },
    i(l) {
      n || (P(i), n = !0);
    },
    o(l) {
      H(i), n = !1;
    },
    d(l) {
      l && I(t), i.d(l);
    }
  };
}
function zr(a) {
  let e, t;
  return e = new Ks({
    props: {
      credits: (
        /*effectiveValue*/
        a[8].credits
      ),
      speed: (
        /*effectiveValue*/
        a[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        a[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        a[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        a[8].intro_subtitle
      ),
      layout_style: (
        /*effectiveValue*/
        a[8].layout_style
      ),
      title_uppercase: (
        /*effectiveValue*/
        a[8].title_uppercase
      ),
      name_uppercase: (
        /*effectiveValue*/
        a[8].name_uppercase
      ),
      section_title_uppercase: (
        /*effectiveValue*/
        a[8].section_title_uppercase
      ),
      swap_font_sizes_on_two_column: (
        /*effectiveValue*/
        a[8].swap_font_sizes_on_two_column
      )
    }
  }), {
    c() {
      kt(e.$$.fragment);
    },
    l(n) {
      wt(e.$$.fragment, n);
    },
    m(n, i) {
      $t(e, n, i), t = !0;
    },
    p(n, i) {
      const l = {};
      i & /*effectiveValue*/
      256 && (l.credits = /*effectiveValue*/
      n[8].credits), i & /*effectiveValue*/
      256 && (l.speed = /*effectiveValue*/
      n[8].speed), i & /*effectiveValue*/
      256 && (l.base_font_size = /*effectiveValue*/
      n[8].base_font_size), i & /*effectiveValue*/
      256 && (l.intro_title = /*effectiveValue*/
      n[8].intro_title), i & /*effectiveValue*/
      256 && (l.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), i & /*effectiveValue*/
      256 && (l.layout_style = /*effectiveValue*/
      n[8].layout_style), i & /*effectiveValue*/
      256 && (l.title_uppercase = /*effectiveValue*/
      n[8].title_uppercase), i & /*effectiveValue*/
      256 && (l.name_uppercase = /*effectiveValue*/
      n[8].name_uppercase), i & /*effectiveValue*/
      256 && (l.section_title_uppercase = /*effectiveValue*/
      n[8].section_title_uppercase), i & /*effectiveValue*/
      256 && (l.swap_font_sizes_on_two_column = /*effectiveValue*/
      n[8].swap_font_sizes_on_two_column), e.$set(l);
    },
    i(n) {
      t || (P(e.$$.fragment, n), t = !0);
    },
    o(n) {
      H(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Ft(e, n);
    }
  };
}
function Ir(a) {
  let e, t;
  return e = new Ms({
    props: {
      credits: (
        /*effectiveValue*/
        a[8].credits
      ),
      speed: (
        /*effectiveValue*/
        a[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        a[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        a[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        a[8].intro_subtitle
      ),
      layout_style: (
        /*effectiveValue*/
        a[8].layout_style
      ),
      title_uppercase: (
        /*effectiveValue*/
        a[8].title_uppercase
      ),
      name_uppercase: (
        /*effectiveValue*/
        a[8].name_uppercase
      ),
      section_title_uppercase: (
        /*effectiveValue*/
        a[8].section_title_uppercase
      ),
      swap_font_sizes_on_two_column: (
        /*effectiveValue*/
        a[8].swap_font_sizes_on_two_column
      )
    }
  }), {
    c() {
      kt(e.$$.fragment);
    },
    l(n) {
      wt(e.$$.fragment, n);
    },
    m(n, i) {
      $t(e, n, i), t = !0;
    },
    p(n, i) {
      const l = {};
      i & /*effectiveValue*/
      256 && (l.credits = /*effectiveValue*/
      n[8].credits), i & /*effectiveValue*/
      256 && (l.speed = /*effectiveValue*/
      n[8].speed), i & /*effectiveValue*/
      256 && (l.base_font_size = /*effectiveValue*/
      n[8].base_font_size), i & /*effectiveValue*/
      256 && (l.intro_title = /*effectiveValue*/
      n[8].intro_title), i & /*effectiveValue*/
      256 && (l.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), i & /*effectiveValue*/
      256 && (l.layout_style = /*effectiveValue*/
      n[8].layout_style), i & /*effectiveValue*/
      256 && (l.title_uppercase = /*effectiveValue*/
      n[8].title_uppercase), i & /*effectiveValue*/
      256 && (l.name_uppercase = /*effectiveValue*/
      n[8].name_uppercase), i & /*effectiveValue*/
      256 && (l.section_title_uppercase = /*effectiveValue*/
      n[8].section_title_uppercase), i & /*effectiveValue*/
      256 && (l.swap_font_sizes_on_two_column = /*effectiveValue*/
      n[8].swap_font_sizes_on_two_column), e.$set(l);
    },
    i(n) {
      t || (P(e.$$.fragment, n), t = !0);
    },
    o(n) {
      H(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Ft(e, n);
    }
  };
}
function Rr(a) {
  let e, t;
  return e = new Cs({
    props: {
      credits: (
        /*effectiveValue*/
        a[8].credits
      ),
      speed: (
        /*effectiveValue*/
        a[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        a[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        a[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        a[8].intro_subtitle
      ),
      background_color: (
        /*effectiveValue*/
        a[8].scroll_background_color
      ),
      title_color: (
        /*effectiveValue*/
        a[8].scroll_title_color
      ),
      name_color: (
        /*effectiveValue*/
        a[8].scroll_name_color
      ),
      layout_style: (
        /*effectiveValue*/
        a[8].layout_style
      ),
      title_uppercase: (
        /*effectiveValue*/
        a[8].title_uppercase
      ),
      name_uppercase: (
        /*effectiveValue*/
        a[8].name_uppercase
      ),
      section_title_uppercase: (
        /*effectiveValue*/
        a[8].section_title_uppercase
      ),
      swap_font_sizes_on_two_column: (
        /*effectiveValue*/
        a[8].swap_font_sizes_on_two_column
      )
    }
  }), {
    c() {
      kt(e.$$.fragment);
    },
    l(n) {
      wt(e.$$.fragment, n);
    },
    m(n, i) {
      $t(e, n, i), t = !0;
    },
    p(n, i) {
      const l = {};
      i & /*effectiveValue*/
      256 && (l.credits = /*effectiveValue*/
      n[8].credits), i & /*effectiveValue*/
      256 && (l.speed = /*effectiveValue*/
      n[8].speed), i & /*effectiveValue*/
      256 && (l.base_font_size = /*effectiveValue*/
      n[8].base_font_size), i & /*effectiveValue*/
      256 && (l.intro_title = /*effectiveValue*/
      n[8].intro_title), i & /*effectiveValue*/
      256 && (l.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), i & /*effectiveValue*/
      256 && (l.background_color = /*effectiveValue*/
      n[8].scroll_background_color), i & /*effectiveValue*/
      256 && (l.title_color = /*effectiveValue*/
      n[8].scroll_title_color), i & /*effectiveValue*/
      256 && (l.name_color = /*effectiveValue*/
      n[8].scroll_name_color), i & /*effectiveValue*/
      256 && (l.layout_style = /*effectiveValue*/
      n[8].layout_style), i & /*effectiveValue*/
      256 && (l.title_uppercase = /*effectiveValue*/
      n[8].title_uppercase), i & /*effectiveValue*/
      256 && (l.name_uppercase = /*effectiveValue*/
      n[8].name_uppercase), i & /*effectiveValue*/
      256 && (l.section_title_uppercase = /*effectiveValue*/
      n[8].section_title_uppercase), i & /*effectiveValue*/
      256 && (l.swap_font_sizes_on_two_column = /*effectiveValue*/
      n[8].swap_font_sizes_on_two_column), e.$set(l);
    },
    i(n) {
      t || (P(e.$$.fragment, n), t = !0);
    },
    o(n) {
      H(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Ft(e, n);
    }
  };
}
function gl(a) {
  let e, t, n, i;
  const l = [Rr, Ir, zr], o = [];
  function s(r, u) {
    return (
      /*effectiveValue*/
      r[8].effect === "scroll" ? 0 : (
        /*effectiveValue*/
        r[8].effect === "starwars" ? 1 : (
          /*effectiveValue*/
          r[8].effect === "matrix" ? 2 : -1
        )
      )
    );
  }
  return ~(t = s(a)) && (n = o[t] = l[t](a)), {
    c() {
      e = oe("div"), n && n.c(), this.h();
    },
    l(r) {
      e = ae(r, "DIV", { class: !0 });
      var u = Ce(e);
      n && n.l(u), u.forEach(I), this.h();
    },
    h() {
      le(e, "class", "main-credits-panel svelte-1hawtr7"), N(
        e,
        "height",
        /*height_style*/
        a[16]
      ), N(
        e,
        "width",
        /*effectiveValue*/
        a[8].sidebar_position === "right" && /*effectiveValue*/
        a[8].show_licenses ? "calc(100% - var(--sidebar-width, 400px))" : (
          /*width_style*/
          a[15]
        )
      );
    },
    m(r, u) {
      J(r, e, u), ~t && o[t].m(e, null), i = !0;
    },
    p(r, u) {
      let _ = t;
      t = s(r), t === _ ? ~t && o[t].p(r, u) : (n && (st(), H(o[_], 1, 1, () => {
        o[_] = null;
      }), at()), ~t ? (n = o[t], n ? n.p(r, u) : (n = o[t] = l[t](r), n.c()), P(n, 1), n.m(e, null)) : n = null), u & /*height_style*/
      65536 && N(
        e,
        "height",
        /*height_style*/
        r[16]
      ), u & /*effectiveValue, width_style*/
      33024 && N(
        e,
        "width",
        /*effectiveValue*/
        r[8].sidebar_position === "right" && /*effectiveValue*/
        r[8].show_licenses ? "calc(100% - var(--sidebar-width, 400px))" : (
          /*width_style*/
          r[15]
        )
      );
    },
    i(r) {
      i || (P(n), i = !0);
    },
    o(r) {
      H(n), i = !1;
    },
    d(r) {
      r && I(e), ~t && o[t].d();
    }
  };
}
function vl(a) {
  let e, t, n = "Licenses", i, l, o = [], s = /* @__PURE__ */ new Map(), r, u = ul(Object.entries(
    /*effectiveValue*/
    a[8].licenses
  ));
  const _ = (c) => (
    /*name*/
    c[24]
  );
  for (let c = 0; c < u.length; c += 1) {
    let h = dl(a, u, c), g = _(h);
    s.set(g, o[c] = bl(g, h));
  }
  let d = (
    /*selected_license_name*/
    a[9] && Dl(a)
  );
  return {
    c() {
      e = oe("div"), t = oe("h3"), t.textContent = n, i = tt(), l = oe("ul");
      for (let c = 0; c < o.length; c += 1)
        o[c].c();
      r = tt(), d && d.c(), this.h();
    },
    l(c) {
      e = ae(c, "DIV", { class: !0 });
      var h = Ce(e);
      t = ae(h, "H3", { class: !0, "data-svelte-h": !0 }), Zn(t) !== "svelte-1txs4lo" && (t.textContent = n), i = et(h), l = ae(h, "UL", {});
      var g = Ce(l);
      for (let p = 0; p < o.length; p += 1)
        o[p].l(g);
      g.forEach(I), r = et(h), d && d.l(h), h.forEach(I), this.h();
    },
    h() {
      le(t, "class", "svelte-1hawtr7"), le(e, "class", "licenses-sidebar svelte-1hawtr7");
    },
    m(c, h) {
      J(c, e, h), re(e, t), re(e, i), re(e, l);
      for (let g = 0; g < o.length; g += 1)
        o[g] && o[g].m(l, null);
      re(e, r), d && d.m(e, null);
    },
    p(c, h) {
      h & /*selected_license_name, Object, effectiveValue, show_license*/
      131840 && (u = ul(Object.entries(
        /*effectiveValue*/
        c[8].licenses
      )), o = Sr(o, h, _, 1, c, u, s, l, kr, bl, null, dl)), /*selected_license_name*/
      c[9] ? d ? d.p(c, h) : (d = Dl(c), d.c(), d.m(e, null)) : d && (d.d(1), d = null);
    },
    d(c) {
      c && I(e);
      for (let h = 0; h < o.length; h += 1)
        o[h].d();
      d && d.d();
    }
  };
}
function bl(a, e) {
  let t, n, i = (
    /*name*/
    e[24] + ""
  ), l, o, s, r;
  function u() {
    return (
      /*click_handler*/
      e[22](
        /*name*/
        e[24]
      )
    );
  }
  return {
    key: a,
    first: null,
    c() {
      t = oe("li"), n = oe("button"), l = Mn(i), o = tt(), this.h();
    },
    l(_) {
      t = ae(_, "LI", { class: !0 });
      var d = Ce(t);
      n = ae(d, "BUTTON", { type: !0, class: !0 });
      var c = Ce(n);
      l = On(c, i), c.forEach(I), o = et(d), d.forEach(I), this.h();
    },
    h() {
      le(n, "type", "button"), le(n, "class", "svelte-1hawtr7"), cl(
        n,
        "selected",
        /*selected_license_name*/
        e[9] === /*name*/
        e[24]
      ), le(t, "class", "svelte-1hawtr7"), this.first = t;
    },
    m(_, d) {
      J(_, t, d), re(t, n), re(n, l), re(t, o), s || (r = Ar(n, "click", u), s = !0);
    },
    p(_, d) {
      e = _, d & /*effectiveValue*/
      256 && i !== (i = /*name*/
      e[24] + "") && Pn(l, i), d & /*selected_license_name, Object, effectiveValue*/
      768 && cl(
        n,
        "selected",
        /*selected_license_name*/
        e[9] === /*name*/
        e[24]
      );
    },
    d(_) {
      _ && I(t), s = !1, r();
    }
  };
}
function Dl(a) {
  let e, t, n, i, l, o = (
    /*effectiveValue*/
    a[8].licenses[
      /*selected_license_name*/
      a[9]
    ] + ""
  ), s;
  return {
    c() {
      e = oe("div"), t = oe("h4"), n = Mn(
        /*selected_license_name*/
        a[9]
      ), i = tt(), l = oe("pre"), s = Mn(o), this.h();
    },
    l(r) {
      e = ae(r, "DIV", { class: !0 });
      var u = Ce(e);
      t = ae(u, "H4", { class: !0 });
      var _ = Ce(t);
      n = On(
        _,
        /*selected_license_name*/
        a[9]
      ), _.forEach(I), i = et(u), l = ae(u, "PRE", { class: !0 });
      var d = Ce(l);
      s = On(d, o), d.forEach(I), u.forEach(I), this.h();
    },
    h() {
      le(t, "class", "svelte-1hawtr7"), le(l, "class", "svelte-1hawtr7"), le(e, "class", "license-display svelte-1hawtr7");
    },
    m(r, u) {
      J(r, e, u), re(e, t), re(t, n), re(e, i), re(e, l), re(l, s);
    },
    p(r, u) {
      u & /*selected_license_name*/
      512 && Pn(
        n,
        /*selected_license_name*/
        r[9]
      ), u & /*effectiveValue, selected_license_name*/
      768 && o !== (o = /*effectiveValue*/
      r[8].licenses[
        /*selected_license_name*/
        r[9]
      ] + "") && Pn(s, o);
    },
    d(r) {
      r && I(e);
    }
  };
}
function yl(a) {
  let e, t, n, i = (
    /*effectiveValue*/
    a[8].show_licenses && Object.keys(
      /*effectiveValue*/
      a[8].licenses
    ).length > 0
  ), l, o = (
    /*effectiveValue*/
    a[8].show_credits && ml(a)
  ), s = i && vl(a);
  return {
    c() {
      e = oe("div"), t = oe("div"), o && o.c(), n = tt(), s && s.c(), this.h();
    },
    l(r) {
      e = ae(r, "DIV", { class: !0 });
      var u = Ce(e);
      t = ae(u, "DIV", { class: !0 });
      var _ = Ce(t);
      o && o.l(_), n = et(_), s && s.l(_), _.forEach(I), u.forEach(I), this.h();
    },
    h() {
      le(t, "class", "credits-panel-wrapper svelte-1hawtr7"), N(
        t,
        "width",
        /*width_style*/
        a[15]
      ), N(
        t,
        "height",
        /*effectiveValue*/
        a[8].sidebar_position === "right" ? (
          /*height_style*/
          a[16]
        ) : void 0
      ), N(t, "--main-panel-width", !/*effectiveValue*/
      a[8].show_credits && /*effectiveValue*/
      a[8].show_licenses ? "0px" : "auto"), le(e, "class", "outer-credits-wrapper svelte-1hawtr7"), N(
        e,
        "width",
        /*width_style*/
        a[15]
      );
    },
    m(r, u) {
      J(r, e, u), re(e, t), o && o.m(t, null), re(t, n), s && s.m(t, null), l = !0;
    },
    p(r, u) {
      /*effectiveValue*/
      r[8].show_credits ? o ? (o.p(r, u), u & /*effectiveValue*/
      256 && P(o, 1)) : (o = ml(r), o.c(), P(o, 1), o.m(t, n)) : o && (st(), H(o, 1, 1, () => {
        o = null;
      }), at()), u & /*effectiveValue*/
      256 && (i = /*effectiveValue*/
      r[8].show_licenses && Object.keys(
        /*effectiveValue*/
        r[8].licenses
      ).length > 0), i ? s ? s.p(r, u) : (s = vl(r), s.c(), s.m(t, null)) : s && (s.d(1), s = null), u & /*width_style*/
      32768 && N(
        t,
        "width",
        /*width_style*/
        r[15]
      ), u & /*effectiveValue, height_style*/
      65792 && N(
        t,
        "height",
        /*effectiveValue*/
        r[8].sidebar_position === "right" ? (
          /*height_style*/
          r[16]
        ) : void 0
      ), u & /*effectiveValue*/
      256 && N(t, "--main-panel-width", !/*effectiveValue*/
      r[8].show_credits && /*effectiveValue*/
      r[8].show_licenses ? "0px" : "auto"), u & /*width_style*/
      32768 && N(
        e,
        "width",
        /*width_style*/
        r[15]
      );
    },
    i(r) {
      l || (P(o), l = !0);
    },
    o(r) {
      H(o), l = !1;
    },
    d(r) {
      r && I(e), o && o.d(), s && s.d();
    }
  };
}
function Lr(a) {
  var c, h, g;
  let e, t, n, i = (
    /*effectiveValue*/
    a[8].logo_position
  ), l, o, s;
  e = new ms({
    props: {
      autoscroll: (
        /*gradio*/
        a[7].autoscroll
      ),
      i18n: (
        /*gradio*/
        a[7].i18n
      ),
      queue_position: (
        /*loading_status*/
        ((c = a[6]) == null ? void 0 : c.queue_position) ?? -1
      ),
      queue_size: (
        /*loading_status*/
        ((h = a[6]) == null ? void 0 : h.queue_size) ?? 0
      ),
      status: (
        /*loading_status*/
        ((g = a[6]) == null ? void 0 : g.status) ?? "complete"
      )
    }
  });
  const r = (
    /*#slots*/
    a[21].default
  ), u = wr(
    r,
    a,
    /*$$scope*/
    a[23],
    null
  );
  let _ = hl(a), d = (
    /*effectiveValue*/
    (a[8].show_licenses || /*effectiveValue*/
    a[8].show_credits) && pl(a)
  );
  return {
    c() {
      kt(e.$$.fragment), t = tt(), u && u.c(), n = tt(), _.c(), l = tt(), d && d.c(), o = ot();
    },
    l(p) {
      wt(e.$$.fragment, p), t = et(p), u && u.l(p), n = et(p), _.l(p), l = et(p), d && d.l(p), o = ot();
    },
    m(p, D) {
      $t(e, p, D), J(p, t, D), u && u.m(p, D), J(p, n, D), _.m(p, D), J(p, l, D), d && d.m(p, D), J(p, o, D), s = !0;
    },
    p(p, D) {
      var m, f, v;
      const k = {};
      D & /*gradio*/
      128 && (k.autoscroll = /*gradio*/
      p[7].autoscroll), D & /*gradio*/
      128 && (k.i18n = /*gradio*/
      p[7].i18n), D & /*loading_status*/
      64 && (k.queue_position = /*loading_status*/
      ((m = p[6]) == null ? void 0 : m.queue_position) ?? -1), D & /*loading_status*/
      64 && (k.queue_size = /*loading_status*/
      ((f = p[6]) == null ? void 0 : f.queue_size) ?? 0), D & /*loading_status*/
      64 && (k.status = /*loading_status*/
      ((v = p[6]) == null ? void 0 : v.status) ?? "complete"), e.$set(k), u && u.p && (!s || D & /*$$scope*/
      8388608) && Br(
        u,
        r,
        p,
        /*$$scope*/
        p[23],
        s ? $r(
          r,
          /*$$scope*/
          p[23],
          D,
          null
        ) : Fr(
          /*$$scope*/
          p[23]
        ),
        null
      ), D & /*effectiveValue*/
      256 && pn(i, i = /*effectiveValue*/
      p[8].logo_position) ? (st(), H(_, 1, 1, Ut), at(), _ = hl(p), _.c(), P(_, 1), _.m(l.parentNode, l)) : _.p(p, D), /*effectiveValue*/
      p[8].show_licenses || /*effectiveValue*/
      p[8].show_credits ? d ? (d.p(p, D), D & /*effectiveValue*/
      256 && P(d, 1)) : (d = pl(p), d.c(), P(d, 1), d.m(o.parentNode, o)) : d && (st(), H(d, 1, 1, () => {
        d = null;
      }), at());
    },
    i(p) {
      s || (P(e.$$.fragment, p), P(u, p), P(_), P(d), s = !0);
    },
    o(p) {
      H(e.$$.fragment, p), H(u, p), H(_), H(d), s = !1;
    },
    d(p) {
      p && (I(t), I(n), I(l), I(o)), Ft(e, p), u && u.d(p), _.d(p), d && d.d(p);
    }
  };
}
function Or(a) {
  let e, t = `.credits-panel-wrapper { 
              flex-direction: row !important; 
              --panel-direction: row; 
              --sidebar-width: 400px; 
              --border-left: 1px solid var(--border-color-primary); 
              --border-top: none; 
              --border: none;
              --sidebar-max-height: {height_style}; 
            }
            .licenses-sidebar { width: var(--sidebar-width, 400px) !important; border-left: 1px solid var(--border-color-primary) !important; border-top: none !important; }
            .main-credits-panel { width: calc(100% - var(--sidebar-width, 400px)) !important; }`;
  return {
    c() {
      e = oe("style"), e.textContent = t;
    },
    l(n) {
      e = ae(n, "STYLE", { "data-svelte-h": !0 }), Zn(e) !== "svelte-1hbm6cs" && (e.textContent = t);
    },
    m(n, i) {
      J(n, e, i);
    },
    d(n) {
      n && I(e);
    }
  };
}
function Pr(a) {
  let e, t = `.credits-panel-wrapper {
        flex-direction: column !important;
        --panel-direction: column;
        --sidebar-width: 100%;
        --border-left: none;
        --border-top: 1px solid var(--border-color-primary);
        --sidebar-max-height: 400px;
        --border: none;
      }
      .licenses-sidebar {
        width: 100% !important;
        border-left: none !important;
        border-top: 1px solid var(--border-color-primary) !important;
      }
      .main-credits-panel {
        width: 100% !important;
      }`;
  return {
    c() {
      e = oe("style"), e.textContent = t;
    },
    l(n) {
      e = ae(n, "STYLE", { "data-svelte-h": !0 }), Zn(e) !== "svelte-gyscx4" && (e.textContent = t);
    },
    m(n, i) {
      J(n, e, i);
    },
    d(n) {
      n && I(e);
    }
  };
}
function Mr(a) {
  let e, t, n, i;
  e = new ba({
    props: {
      visible: (
        /*visible*/
        a[2]
      ),
      elem_id: (
        /*elem_id*/
        a[0]
      ),
      elem_classes: (
        /*elem_classes*/
        a[1]
      ),
      container: (
        /*container*/
        a[3]
      ),
      scale: (
        /*scale*/
        a[4]
      ),
      min_width: (
        /*min_width*/
        a[5]
      ),
      padding: !1,
      $$slots: { default: [Lr] },
      $$scope: { ctx: a }
    }
  });
  function l(r, u) {
    return (
      /*effectiveValue*/
      r[8].sidebar_position === "bottom" ? Pr : Or
    );
  }
  let o = l(a), s = o(a);
  return {
    c() {
      kt(e.$$.fragment), t = tt(), s.c(), n = ot();
    },
    l(r) {
      wt(e.$$.fragment, r), t = et(r);
      const u = Cr("svelte-1lsh18a", document.head);
      s.l(u), n = ot(), u.forEach(I);
    },
    m(r, u) {
      $t(e, r, u), J(r, t, u), s.m(document.head, null), re(document.head, n), i = !0;
    },
    p(r, [u]) {
      const _ = {};
      u & /*visible*/
      4 && (_.visible = /*visible*/
      r[2]), u & /*elem_id*/
      1 && (_.elem_id = /*elem_id*/
      r[0]), u & /*elem_classes*/
      2 && (_.elem_classes = /*elem_classes*/
      r[1]), u & /*container*/
      8 && (_.container = /*container*/
      r[3]), u & /*scale*/
      16 && (_.scale = /*scale*/
      r[4]), u & /*min_width*/
      32 && (_.min_width = /*min_width*/
      r[5]), u & /*$$scope, effectiveValue, width_style, height_style, selected_license_name, logo_panel_height, logo_justify, gradio, logo_width_style, logo_height_style, object_fit, loading_status*/
      8519616 && (_.$$scope = { dirty: u, ctx: r }), e.$set(_), o !== (o = l(r)) && (s.d(1), s = o(r), s && (s.c(), s.m(n.parentNode, n)));
    },
    i(r) {
      i || (P(e.$$.fragment, r), i = !0);
    },
    o(r) {
      H(e.$$.fragment, r), i = !1;
    },
    d(r) {
      r && I(t), Ft(e, r), s.d(r), I(n);
    }
  };
}
function Nr(a, e, t) {
  let n, i, l, o, s, r, u, _, { $$slots: d = {}, $$scope: c } = e, { value: h = null } = e, { elem_id: g = "" } = e, { elem_classes: p = [] } = e, { visible: D = !0 } = e, { container: k = !0 } = e, { scale: m = null } = e, { min_width: f = void 0 } = e, { height: v = void 0 } = e, { width: y = void 0 } = e, { loading_status: b } = e, { gradio: F } = e, A = null;
  function E(w) {
    t(9, A = A === w ? null : w);
  }
  const q = (w) => E(w);
  return a.$$set = (w) => {
    "value" in w && t(18, h = w.value), "elem_id" in w && t(0, g = w.elem_id), "elem_classes" in w && t(1, p = w.elem_classes), "visible" in w && t(2, D = w.visible), "container" in w && t(3, k = w.container), "scale" in w && t(4, m = w.scale), "min_width" in w && t(5, f = w.min_width), "height" in w && t(19, v = w.height), "width" in w && t(20, y = w.width), "loading_status" in w && t(6, b = w.loading_status), "gradio" in w && t(7, F = w.gradio), "$$scope" in w && t(23, c = w.$$scope);
  }, a.$$.update = () => {
    a.$$.dirty & /*value*/
    262144 && t(8, n = h || {
      credits: [
        { section_title: "Default Team" },
        {
          title: "Lead Developer",
          name: "John Doe"
        },
        {
          title: "UI/UX Design",
          name: "Jane Smith"
        }
      ],
      licenses: {
        "Gradio Framework": "Apache License placeholder",
        "This Component": "MIT License placeholder"
      },
      effect: "scroll",
      speed: 40,
      base_font_size: 1.5,
      intro_title: "",
      intro_subtitle: "",
      sidebar_position: "right",
      logo_path: null,
      show_logo: !0,
      show_licenses: !0,
      show_credits: !0,
      logo_position: "center",
      logo_sizing: "resize",
      logo_width: null,
      logo_height: null,
      scroll_background_color: null,
      scroll_title_color: null,
      scroll_name_color: null,
      layout_style: "stacked",
      title_uppercase: !1,
      name_uppercase: !1,
      section_title_uppercase: !0,
      swap_font_sizes_on_two_column: !1
    }), a.$$.dirty & /*height*/
    524288 && t(16, i = typeof v == "number" ? `${v}px` : v || "500px"), a.$$.dirty & /*width*/
    1048576 && t(15, l = typeof y == "number" ? `${y}px` : y || "100%"), a.$$.dirty & /*effectiveValue*/
    256 && t(14, o = n.logo_width ? typeof n.logo_width == "number" ? `${n.logo_width}px` : n.logo_width : "auto"), a.$$.dirty & /*effectiveValue*/
    256 && t(13, s = n.logo_height ? typeof n.logo_height == "number" ? `${n.logo_height}px` : n.logo_height : "100px"), a.$$.dirty & /*effectiveValue*/
    256 && t(12, r = n.logo_height ? typeof n.logo_height == "number" ? `${n.logo_height}px` : n.logo_height : "100px"), a.$$.dirty & /*effectiveValue*/
    256 && t(11, u = n.logo_sizing === "stretch" ? "fill" : n.logo_sizing === "crop" ? "cover" : "contain"), a.$$.dirty & /*effectiveValue*/
    256 && t(10, _ = n.logo_position === "center" ? "center" : n.logo_position === "left" ? "flex-start" : "flex-end");
  }, [
    g,
    p,
    D,
    k,
    m,
    f,
    b,
    F,
    n,
    A,
    _,
    u,
    r,
    s,
    o,
    l,
    i,
    E,
    h,
    v,
    y,
    d,
    q,
    c
  ];
}
class R5 extends yr {
  constructor(e) {
    super(), Er(this, e, Nr, Mr, pn, {
      value: 18,
      elem_id: 0,
      elem_classes: 1,
      visible: 2,
      container: 3,
      scale: 4,
      min_width: 5,
      height: 19,
      width: 20,
      loading_status: 6,
      gradio: 7
    });
  }
}
export {
  R5 as default
};
