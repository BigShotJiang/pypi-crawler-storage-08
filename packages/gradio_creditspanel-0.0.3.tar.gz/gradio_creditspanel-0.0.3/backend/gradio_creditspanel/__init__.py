
from .creditspanel import CreditsPanel

__all__ = ['CreditsPanel']
