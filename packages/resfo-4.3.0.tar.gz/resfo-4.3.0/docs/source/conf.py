project = "resfo"
copyright = "2022, Equinor"
author = "Equinor"
release = "1.0.0"


extensions = ["sphinx.ext.autodoc", "sphinx.ext.doctest"]
language = "python"
html_theme = "sphinx_rtd_theme"
