"""
This module implements the read and write
functionality for unformatted res files
(see :ref:`unformatted-format`) and is not
part of the resfo public API.
"""
