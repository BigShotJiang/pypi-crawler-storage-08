# RFL: settings package

Manage configuration files settings.
