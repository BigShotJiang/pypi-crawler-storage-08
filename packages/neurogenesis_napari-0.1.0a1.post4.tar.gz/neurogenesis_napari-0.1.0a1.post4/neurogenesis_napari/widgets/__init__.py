from .normalize_and_denoise import (
    normalize_and_denoise_widget as normalize_and_denoise_widget,
)
from .segment import segment_widget as segment_widget
from .segment_and_classify import (
    segment_and_classify_widget as segment_and_classify_widget,
)
