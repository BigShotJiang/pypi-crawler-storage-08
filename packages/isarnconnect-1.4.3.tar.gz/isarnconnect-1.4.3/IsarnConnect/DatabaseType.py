from enum import Enum


class DatabaseType(Enum):
    MYSQL = "mysql"
    POSTGRE = "postgre"
