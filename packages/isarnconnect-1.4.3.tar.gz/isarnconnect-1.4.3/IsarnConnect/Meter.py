from enum import Enum

class Meter(Enum):
    ELS = "els"
    LGZ = "lgz"
    SLB = "slb"