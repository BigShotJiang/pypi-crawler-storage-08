Allows to retrieve main supplier product code on product level.
