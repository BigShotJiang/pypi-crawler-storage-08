from enum import Enum


class MetadataSourceFileFormat(Enum):
    """Supported metadata source file formats."""

    CSV = "csv"
