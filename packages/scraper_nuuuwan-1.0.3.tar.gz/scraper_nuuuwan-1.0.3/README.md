# 🇱🇰 #SriLanka `Datasets`

**1** datasets, with **1** documents (**12.3 kB**).

## 001 📄Mockdoc

![LastUpdated](https://img.shields.io/badge/last_updated-2024--10--01-green)

[http://mock.com/data](http://mock.com/data)

A mock document class for testing.

- [**1** documents](http://mock.com/data) (**12.3 kB**), from **2023-10-01** to **2023-10-01**, scraped from [http://mock.com](http://mock.com)

- In **JSON**, **PDF**, **TXT** & **🤗 Hugging Face**

- In **English**

- 🎓 Cite as **[arXiv:2510.04124](https://arxiv.org/abs/2510.04124) [cs.CL]**

![Chart](http://mock.com/chart.png)

---

![Maintainer](https://img.shields.io/badge/maintainer-nuuuwan-red)
![MadeWith](https://img.shields.io/badge/made_with-python-blue)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
