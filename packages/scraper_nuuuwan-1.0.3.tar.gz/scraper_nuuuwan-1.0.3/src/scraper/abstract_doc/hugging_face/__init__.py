# scraper.abstract_doc.hugging_face (auto generate by build_inits.py)
# flake8: noqa: F408

from scraper.abstract_doc.hugging_face.AbstractDocHuggingFaceMixin import \
    AbstractDocHuggingFaceMixin
