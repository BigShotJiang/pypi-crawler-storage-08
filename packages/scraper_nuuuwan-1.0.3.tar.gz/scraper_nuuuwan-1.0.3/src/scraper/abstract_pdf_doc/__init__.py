# scraper.abstract_pdf_doc (auto generate by build_inits.py)
# flake8: noqa: F408

from scraper.abstract_pdf_doc.AbstractPDFDoc import AbstractPDFDoc
