from subprocess import run

def pip_update_pypipr():
    run("pip install -U pypipr", shell=True)
    run("pip install -U pypipr", shell=True)
