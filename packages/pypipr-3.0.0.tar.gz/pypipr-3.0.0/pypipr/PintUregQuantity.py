from .PintUreg import PintUreg

""" Class untuk membuat Object Pint Quantity """
PintUregQuantity = PintUreg.Quantity
