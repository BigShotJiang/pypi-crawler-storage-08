from ayugespidertools.scraper.pipelines.es import AyuESPipeline

__all__ = ["AyuFtyESPipeline"]


class AyuFtyESPipeline(AyuESPipeline): ...
