# Define your message middleware here, such as mq, kafka, etc.,
# which are mainly used for message publishing in pipelines and do not consume data
