from ayugespidertools.scraper.spiders import AyuSpider
from ayugespidertools.scraper.spiders.crawl import AyuCrawlSpider

__all__ = [
    "AyuCrawlSpider",
    "AyuSpider",
]
