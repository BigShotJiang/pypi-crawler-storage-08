from ayugespidertools.scraper.http.request.aiohttp import AiohttpRequest

__all__ = [
    "AiohttpRequest",
]
