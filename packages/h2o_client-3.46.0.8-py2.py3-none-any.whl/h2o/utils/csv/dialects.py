# dialects.py - backport unix_dialect

import csv

__all__ = ['unix_dialect']

unix_dialect = csv.unix_dialect
