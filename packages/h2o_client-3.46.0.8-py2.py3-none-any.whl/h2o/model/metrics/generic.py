from h2o.model import MetricsBase


class H2ODefaultModelMetrics(MetricsBase):
    pass
