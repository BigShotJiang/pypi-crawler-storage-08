"""
PySubtrans.Providers.Clients - Translation client implementations

This module contains all client implementations for translation providers.
"""