"""Mock provider module for testing and development"""

from .provider import MockProvider

__all__ = ['MockProvider']