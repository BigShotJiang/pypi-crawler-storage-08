"""
Job advertisements py_models
"""

from .model import JobAd

__all__ = ["JobAd"]
