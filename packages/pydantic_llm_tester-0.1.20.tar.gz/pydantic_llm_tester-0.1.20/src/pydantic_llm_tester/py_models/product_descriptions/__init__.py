"""
Product descriptions module
"""

from .model import ProductDescription

__all__ = ["ProductDescription"]