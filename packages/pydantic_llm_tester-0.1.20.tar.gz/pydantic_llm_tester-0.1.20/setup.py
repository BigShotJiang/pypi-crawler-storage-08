from setuptools import setup

# This file is only needed for development installs (pip install -e .)
# and for tools that still expect it. Configuration is in setup.cfg.
setup()

