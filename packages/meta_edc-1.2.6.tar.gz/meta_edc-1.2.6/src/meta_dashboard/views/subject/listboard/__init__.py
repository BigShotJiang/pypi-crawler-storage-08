from .listboard_view import SubjectListboardView

__all__ = ["SubjectListboardView"]
