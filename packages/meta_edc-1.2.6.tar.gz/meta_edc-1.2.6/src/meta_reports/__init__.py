from .tasks import update_endpoints_table

__all__ = ["update_endpoints_table"]
