from .rx_admin import RxAdmin
from .substitutions_admin import SubstitutionsAdmin

__all__ = [
    "RxAdmin",
    "SubstitutionsAdmin",
]
