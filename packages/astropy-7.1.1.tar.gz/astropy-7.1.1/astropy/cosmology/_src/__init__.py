"""Astropy Cosmology. **NOT public API**.

The public API is provided by `astropy.cosmology`.
"""
# Licensed under a 3-clause BSD style license - see LICENSE.rst
