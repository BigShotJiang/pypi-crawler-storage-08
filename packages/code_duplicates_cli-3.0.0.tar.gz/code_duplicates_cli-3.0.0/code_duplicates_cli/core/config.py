DEFAULT_MODEL = "sentence-transformers/all-mpnet-base-v2"
SUPPORTED_EXTS = ["py", "js", "ts", "tsx", "jsx", "go", "rs", "c", "cpp", "java"]
DEFAULT_THRESHOLD = 0.90
DEFAULT_TOPK = 5
DEFAULT_MIN_LINES = 3
