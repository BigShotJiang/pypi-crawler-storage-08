"""HR tools package: PDF conversion and packaging utilities."""


