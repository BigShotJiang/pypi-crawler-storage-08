def main() -> None:
    print("Hello from laissez!")
