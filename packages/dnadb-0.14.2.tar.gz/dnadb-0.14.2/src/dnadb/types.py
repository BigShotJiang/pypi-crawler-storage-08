import numpy as np
from typing import Union

int_t = Union[int, np.int32, np.int64]
