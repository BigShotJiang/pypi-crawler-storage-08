from .df2tables import *
__version__ = "0.1.8"
__author__ = "Tomasz Slugocki"
__license__ = "MIT"

