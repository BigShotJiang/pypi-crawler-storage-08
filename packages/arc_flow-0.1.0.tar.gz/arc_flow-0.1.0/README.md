# Arc Framework

A professional hierarchical multi-agent framework built on Python.

## Overview

Arc is a powerful framework for building and orchestrating multi-agent systems with hierarchical structures. It provides a flexible and extensible architecture for creating sophisticated AI agent workflows.

## Features

- **Hierarchical Agent Architecture**: Build complex agent hierarchies with supervisors and coordinators
- **Multiple Workflow Patterns**: Support for sequential, concurrent, and graph-based workflows
- **Reinforcement Learning Integration**: Built-in RL capabilities for agent optimization
- **Agent Routing**: Intelligent routing between specialized agents
- **State Management**: Robust state handling for complex agent interactions
- **Extensible Design**: Easy to extend with custom agents and workflows

## Installation

Install Arc using pip:

```bash
pip install arc_flow
```

### Development Installation

For development, install with additional dependencies:

```bash
pip install arc_flow[dev]
```

### MCP Support

To use Model Context Protocol (MCP) features:

```bash
pip install arc_flow[mcp]
```

## Requirements

- Python >= 3.12

## Quick Start

```python
from arc_ai import Agent, Workflow

# Create your agents
agent = Agent(name="my_agent")

# Build your workflow
workflow = Workflow()
workflow.add_agent(agent)

# Execute
result = workflow.run()
```

## Documentation

For more detailed documentation, please visit our [GitHub repository](https://github.com/pinilDissanayaka/Arc-Framework-v2).

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Support

If you encounter any issues or have questions:

- Report bugs: [GitHub Issues](https://github.com/pinilDissanayaka/Arc-Framework-v2/issues)
- Source code: [GitHub Repository](https://github.com/pinilDissanayaka/Arc-Framework-v2)

## License

This project is licensed under the MIT License.

## Keywords

Multi-agent, AI, Framework, Hierarchical, Reinforcement Learning, Agent Orchestration

## Contact

For inquiries, please contact: info@azrianlabs.com
