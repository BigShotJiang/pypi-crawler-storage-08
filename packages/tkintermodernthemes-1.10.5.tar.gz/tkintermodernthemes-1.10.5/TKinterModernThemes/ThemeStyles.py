"""
Enums for widget styles
"""

class ThemeStyles:
    class ButtonStyles:
        AccentButton = "Accent.TButton" #colored by default button
    class CheckbuttonStyles:
        ToggleButton = "Toggle.TButton" #toggle
        SlideSwitch = "Switch.TCheckbutton" #slide switch