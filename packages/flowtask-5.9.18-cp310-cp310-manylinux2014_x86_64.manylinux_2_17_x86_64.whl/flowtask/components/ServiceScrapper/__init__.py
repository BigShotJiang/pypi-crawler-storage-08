from .scrapper import ServiceScrapper

__all__ = (
    'ServiceScrapper',
)
