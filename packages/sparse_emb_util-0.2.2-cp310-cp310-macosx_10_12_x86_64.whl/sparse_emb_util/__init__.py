from .sparse_emb_util import *

__doc__ = sparse_emb_util.__doc__
if hasattr(sparse_emb_util, "__all__"):
    __all__ = sparse_emb_util.__all__