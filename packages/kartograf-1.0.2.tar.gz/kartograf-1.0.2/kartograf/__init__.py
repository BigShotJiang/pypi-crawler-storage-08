print("This isn't the package you are looking for")
print("Please install kartograf from conda-forge")
print("conda install -c conda-forge kartograf")
