Please use conda-forge to install kartograf:

`conda install -c conda-forge kartograf`
