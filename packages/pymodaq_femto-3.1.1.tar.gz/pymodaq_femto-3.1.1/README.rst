PyMoDAQ Femto
#############
PyMoDAQ extension for femtosecond laser pulse characterization
Compatible with PyMoDAQ > 4.2.0

Published under the CeCILL-B FREE SOFTWARE LICENSE

GitHub repo: https://github.com/PyMoDAQ/pymodaq_femto

Documentation: https://pymodaq-femto.readthedocs.io/en/latest/index.html
