from airflow_mcp_server import main

main()
