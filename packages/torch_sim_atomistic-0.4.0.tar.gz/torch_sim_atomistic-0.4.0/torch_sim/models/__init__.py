"""Models integrated with TorchSim."""
