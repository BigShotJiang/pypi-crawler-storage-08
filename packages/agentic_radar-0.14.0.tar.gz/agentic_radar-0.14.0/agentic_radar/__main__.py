from .cli import app

app(prog_name="agentic-radar")
