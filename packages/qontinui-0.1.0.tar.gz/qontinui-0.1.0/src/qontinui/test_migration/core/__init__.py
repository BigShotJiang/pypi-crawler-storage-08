"""
Core interfaces and data models for the test migration system.
"""
