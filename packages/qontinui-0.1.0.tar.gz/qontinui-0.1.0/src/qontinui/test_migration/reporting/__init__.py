"""
Reporting module for test migration system.
"""

from .dashboard import MigrationReportingDashboard

__all__ = ["MigrationReportingDashboard"]
