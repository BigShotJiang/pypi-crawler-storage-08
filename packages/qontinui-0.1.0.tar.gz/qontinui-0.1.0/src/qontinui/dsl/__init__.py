"""Domain Specific Language for GUI automation."""

from .parser import QontinuiDSLParser

__all__ = ["QontinuiDSLParser"]
