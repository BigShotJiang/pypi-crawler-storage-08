"""Compare package - ported from Qontinui framework.

Image comparison utilities.
"""

from .size_comparator import SizeComparator

__all__ = [
    "SizeComparator",
]
