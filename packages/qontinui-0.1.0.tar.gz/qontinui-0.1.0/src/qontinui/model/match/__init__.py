"""Match model classes."""

from .match import Match

__all__ = ["Match"]
