"""Service package - ported from Qontinui framework."""

from .action_service import ActionService

__all__ = [
    "ActionService",
]
