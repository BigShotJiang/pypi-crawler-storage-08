"""API Tester MCP Server - Main module"""

__version__ = "1.2.1"
__author__ = "API Tester MCP"
__description__ = "Multi-language MCP server for API testing with TypeScript/Playwright, JavaScript/Jest, Python/pytest support"
