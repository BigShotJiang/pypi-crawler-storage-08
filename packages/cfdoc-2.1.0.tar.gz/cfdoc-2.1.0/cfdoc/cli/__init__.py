"""CLI package for cfdoc."""
