"""Miscellaneous utilities."""

__author__ = 'Murray Andrews'
