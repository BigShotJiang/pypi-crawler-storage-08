# hasss

Has ShadowSocks?

A command line tool to determine if a proxy list has shadowsocks proxies.