"""A79 SDK core module."""
