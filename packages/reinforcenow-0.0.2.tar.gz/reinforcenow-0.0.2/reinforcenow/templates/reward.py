# Template for reward function
# Define your custom reward logic here

def calculate_reward(state, action, next_state):
    """Calculate reward for the given transition"""
    return 0.0
