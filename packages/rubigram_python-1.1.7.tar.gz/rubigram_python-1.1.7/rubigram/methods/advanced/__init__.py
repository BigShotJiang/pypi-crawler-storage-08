
from .build import Builder


class Advanced(
    Builder,
):
    pass
