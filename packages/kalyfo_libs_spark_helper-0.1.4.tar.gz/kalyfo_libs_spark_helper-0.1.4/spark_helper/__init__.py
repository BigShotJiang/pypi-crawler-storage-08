"""Spark Helper - A utility package for creating and configuring optimized Spark sessions."""

from .spark_helper import SparkHelper

__version__ = "0.1.4"
__all__ = ["SparkHelper"]
