# LeRobot + starai motor Integration

## Getting Started

```bash
pip install lerobot-motor-starai
```

## Development

Install the package in editable mode:
```bash
git clone git@github.com:servodevelop/fashionstar-lerobot-motor-starai.git
cd lerobot-motor-starai
pip install -e .
```
