MODEL_NUMBER_TABLE = {
    "rx8-u50": 999,
    "ra8-u25": 888,
}
