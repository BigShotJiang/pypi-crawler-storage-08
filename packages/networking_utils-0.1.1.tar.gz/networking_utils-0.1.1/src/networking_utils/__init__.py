"""Networking utilities package.

Exposes add_two_number for demonstration.
"""
from .math_utils import add_two_number

__all__ = ["add_two_number"]

__version__ = "0.1.0"
