# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "bountylab"
__version__ = "0.4.0"  # x-release-please-version
