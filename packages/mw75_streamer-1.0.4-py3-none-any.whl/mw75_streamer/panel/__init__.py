"""
Panel module for MW75 EEG Streamer.

Provides web-based visualization and control interfaces.
"""
