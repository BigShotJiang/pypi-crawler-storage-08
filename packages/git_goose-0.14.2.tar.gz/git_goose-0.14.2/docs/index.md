<header align=center>
  <h1>Goose</h1>
  <p>The picky and eager Git hook runner
</header>
