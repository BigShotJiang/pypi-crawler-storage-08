from ._version import __version__
from ._version import __version_tuple__

__all__ = (
    "__version__",
    "__version_tuple__",
)
