__docformat__ = "restructuredtext en"
__author__ = "Dennis Piehl"
__email__ = "dennis.piehl@rcsb.org"
__license__ = "MIT"
__version__ = "1.4.1"

__path__ = __import__("pkgutil").extend_path(__path__, __name__)
