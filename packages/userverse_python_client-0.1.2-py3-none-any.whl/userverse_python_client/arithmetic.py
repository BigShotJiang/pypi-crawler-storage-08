"""Arithmetic helpers for userverse_python_client."""


def add_numbers(first: float, second: float) -> float:
    """Return the sum of two numbers."""
    return first + second


def subtract_numbers(first: float, second: float) -> float:
    """Return the difference of two numbers."""
    return first - second
