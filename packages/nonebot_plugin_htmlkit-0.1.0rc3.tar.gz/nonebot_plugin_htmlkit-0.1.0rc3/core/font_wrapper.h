#ifndef FONT_WRAPPER_H
#define FONT_WRAPPER_H

#include <pango/pangocairo.h>
#include <shared_mutex>

int init_fontconfig();

#endif // FONT_WRAPPER_H
