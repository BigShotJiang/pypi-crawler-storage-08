.. _sphinx-autoapi:

Sphinx AutoAPI
==============

This example shows how the Ansys Sphinx Theme renders API documentation using the Sphinx AutoAPI extension.

.. toctree::
   :titlesonly:
   :maxdepth: 1

   api/index
