"""Core componments for interacting with the diagnostics library."""

from google_cloud_mldiagnostics.src.google_cloud_mldiagnostics.core import xprof
