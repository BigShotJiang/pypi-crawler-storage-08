# OpenBB FRED Provider

This extension integrates the [FRED](https://fred.stlouisfed.org/docs/api/fred/) data provider into the OpenBB Platform.

## Installation

To install the extension:

```bash
pip install openbb-fred
```

Documentation available [here](https://docs.openbb.co/platform/developer_guide/contributing).
