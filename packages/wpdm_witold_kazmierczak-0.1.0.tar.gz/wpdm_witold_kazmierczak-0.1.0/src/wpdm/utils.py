def foo(x,y):
    """

    :param x:
    :param y:
    :return:
    """
    return x+y