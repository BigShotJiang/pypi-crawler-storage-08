# wpdm
Warsztat Praktyka Data Mining
