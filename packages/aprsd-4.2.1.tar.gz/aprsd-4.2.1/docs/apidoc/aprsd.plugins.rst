aprsd.plugins package
=====================

Submodules
----------

aprsd.plugins.fortune module
----------------------------

.. automodule:: aprsd.plugins.fortune
   :members:
   :undoc-members:
   :show-inheritance:

aprsd.plugins.notify module
---------------------------

.. automodule:: aprsd.plugins.notify
   :members:
   :undoc-members:
   :show-inheritance:

aprsd.plugins.ping module
-------------------------

.. automodule:: aprsd.plugins.ping
   :members:
   :undoc-members:
   :show-inheritance:

aprsd.plugins.time module
-------------------------

.. automodule:: aprsd.plugins.time
   :members:
   :undoc-members:
   :show-inheritance:

aprsd.plugins.version module
----------------------------

.. automodule:: aprsd.plugins.version
   :members:
   :undoc-members:
   :show-inheritance:

aprsd.plugins.weather module
----------------------------

.. automodule:: aprsd.plugins.weather
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: aprsd.plugins
   :members:
   :undoc-members:
   :show-inheritance:
