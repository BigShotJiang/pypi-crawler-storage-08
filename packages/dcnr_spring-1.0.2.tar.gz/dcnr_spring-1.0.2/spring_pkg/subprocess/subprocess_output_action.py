class SubprocessOutputAction:
    ACTION_LOG = 1
    ACTION_SAVE = 2