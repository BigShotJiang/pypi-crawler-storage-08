# Upflame Labs

[![PyPI version](https://badge.fury.io/py/upflame.svg)](https://badge.fury.io/py/upflame)
[![Python Version](https://img.shields.io/pypi/pyversions/upflame)](https://pypi.org/project/upflame/)
[![License](https://img.shields.io/pypi/l/upflame)](https://github.com/upflame/upflame/blob/main/LICENSE)

**Upflame Labs** is a powerful core package suite with advanced pretty print features designed for modern software development workflows. It provides intuitive tools for project initialization, system diagnostics, data processing, and presenting results in beautifully formatted output.

## Features

- 🚀 **Project Initialization**: Initialize new projects with predefined templates
- 📊 **System Diagnostics**: Comprehensive system health checks
- 🔄 **Data Processing**: Utilities for analyzing and transforming data
- 🎨 **Pretty Print Results**: Beautifully formatted output for easy analysis
- 📈 **Detailed Reporting**: Generate comprehensive reports in multiple formats
- ⚡ **High Performance**: Optimized for speed and efficiency
- 🛠️ **Easy Integration**: Simple API that integrates seamlessly with existing workflows
- 📦 **Lightweight**: Minimal dependencies with maximum functionality

## Installation

```bash
pip install upflame
```

## Quick Start

### Basic Usage

```python
from upflame import greet

# Simple greeting
print(greet("Developer"))
# Output: Hello, Developer! Welcome to Upflame Labs.
```

### Project Initialization

```python
from upflame import initialize_project, pretty_print_project_init

# Initialize a new web project
project = initialize_project("My Web App", "web")

# Pretty print the project initialization details
pretty_print_project_init(project)
```

### System Diagnostics

```python
from upflame import run_diagnostics, pretty_print_diagnostics

# Run system diagnostics
diagnostics = run_diagnostics()

# Pretty print the diagnostic results
pretty_print_diagnostics(diagnostics)
```

### Data Processing

```python
from upflame import process_data

# Sample data to process
data = [
    {"id": 1, "name": "Item 1", "value": 100},
    {"id": 2, "name": "Item 2", "value": 200}
]

# Process the data
result = process_data(data, "analyze")
print(f"Processed {result['data_points']} data points")
```

### Generating Reports

```python
from upflame import generate_report

# Sample data for report
report_data = {
    "project": "My Project",
    "status": "completed",
    "timestamp": "2025-10-11T10:00:00Z"
}

# Generate a JSON report
json_report = generate_report(report_data, format="json")
print(json_report)

# Generate a text report
text_report = generate_report(report_data, format="text")
print(text_report)
```

## API Reference

### Core Functions

#### `greet(name: str) -> str`
Returns a friendly greeting message.

#### `initialize_project(project_name: str, project_type: str = "default") -> Dict[str, Any]`
Initializes a new Upflame Labs project with the specified name and type.

#### `run_diagnostics() -> Dict[str, Any]`
Runs diagnostics on the Upflame Labs environment and returns detailed results.

#### `process_data(data: List[Dict[str, Any]], operation: str = "analyze") -> Dict[str, Any]`
Processes data using Upflame Labs core utilities.

#### `pretty_print_diagnostics(diagnostics: Dict[str, Any]) -> None`
Displays diagnostic results in a beautifully formatted way.

#### `pretty_print_project_init(initialization: Dict[str, Any]) -> None`
Displays project initialization details in a beautifully formatted way.

#### `generate_report(data: Dict[str, Any], format: str = "json") -> str`
Generates a report in the specified format (JSON or text).

### Project Information

#### `get_project_name() -> str`
Returns the project name.

#### `get_version() -> str`
Returns the current version.

#### `get_author() -> str`
Returns the author name.

#### `get_description() -> str`
Returns the project description.

#### `get_license() -> str`
Returns the project license.

#### `get_python_version() -> str`
Returns the minimum required Python version.

#### `get_project_url() -> str`
Returns the project homepage URL.

## Requirements

- Python >= 3.9
- No external dependencies

## Contributing

We welcome contributions to Upflame Labs! Please see our [Contributing Guide](CONTRIBUTING.md) for more details.

1. Fork the repository
2. Create a new branch for your feature
3. Add your feature or improvement
4. Write tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

If you encounter any issues or have questions, please [file an issue](https://github.com/upflame/upflame/issues) on our GitHub repository.