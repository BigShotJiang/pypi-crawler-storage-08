from pathlib import Path

import platformdirs

SF_CACHE_DIR = Path(platformdirs.user_cache_dir("simforge"))
