"""Main entrypoint if running as a module."""

from calkit.cli import run

if __name__ == "__main__":
    run()
