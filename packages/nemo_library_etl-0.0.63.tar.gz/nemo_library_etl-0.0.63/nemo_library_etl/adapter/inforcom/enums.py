from enum import Enum


class InforComTransformStep(Enum):
    JOINS = "10_joins"