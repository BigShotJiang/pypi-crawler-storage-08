"""Domain models for Team Pal."""

from .instruction import Instruction

__all__ = ["Instruction"]
