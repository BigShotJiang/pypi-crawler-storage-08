"""Internal core methods."""
