#!/usr/bin/env python3

from exploitfarm.xfarm import run

if __name__ == "__main__":
    run()
