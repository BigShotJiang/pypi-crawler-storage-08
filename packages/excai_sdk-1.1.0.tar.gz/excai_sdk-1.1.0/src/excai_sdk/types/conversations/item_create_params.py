# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List, Iterable
from typing_extensions import Required, TypedDict

from .includable import Includable
from .input_item_param import InputItemParam

__all__ = ["ItemCreateParams"]


class ItemCreateParams(TypedDict, total=False):
    items: Required[Iterable[InputItemParam]]
    """The items to add to the conversation. You may add up to 20 items at a time."""

    include: List[Includable]
    """Additional fields to include in the response.

    See the `include` parameter for
    [listing Conversation items above](https://main.excai.ai/docs/api-reference/conversations/list-items#conversations_list_items-include)
    for more information.
    """
