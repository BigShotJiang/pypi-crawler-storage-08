# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List
from typing_extensions import Required, TypedDict

from .includable import Includable

__all__ = ["ItemRetrieveParams"]


class ItemRetrieveParams(TypedDict, total=False):
    conversation_id: Required[str]

    include: List[Includable]
    """Additional fields to include in the response.

    See the `include` parameter for
    [listing Conversation items above](https://main.excai.ai/docs/api-reference/conversations/list-items#conversations_list_items-include)
    for more information.
    """
