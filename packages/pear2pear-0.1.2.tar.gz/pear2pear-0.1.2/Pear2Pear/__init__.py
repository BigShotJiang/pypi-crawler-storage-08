from Pear2Pear.GenHandler import genetic_algorithm

def startGeneration(): 
    givenData = [
        [["rsi", 2, ">", "rsi", 1], ["atr", 2, ">", "atr", 3], ["atr", 2, ">", "atr", 1]],
        [["dochiant_mid_5", 4, ">", "dochiant_mid_5", 3], ["dochiant_up_5", 3, ">", "dochiant_up", 2], ["atr", 2, "<", "atr", 1]]
    ]
    pipeline = [
        {
            "name": "Stock - test ( scalp ) ",
            "columns_list": [
                "ema",
                "dochiant_low_5",
                "dochiant_up_5",
                "dochiant_mid_5",
                "dochiant_low",
                "dochiant_up",
                "dochiant_mid",
                "obv",
                "atr",
                "rsi"
            ],
            "status": False,
            "isBellow": True
        }
    ]
    patternConfig = {
        "Open": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "High": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "Low": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "Close": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "Volume": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Volume"
            ]
        },
        "ma": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "ema": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "dema": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "kama": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "kama"
            ]
        },
        "sma": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "dochiant_low": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "dochiant_up": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "dochiant_mid": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "cci": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "cci"
            ]
        },
        "apo": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "apo"
            ]
        },
        "bop": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "bop"
            ]
        },
        "macd": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "macd"
            ]
        },
        "mfi": {
            "numberRange": {
                "hasRange": True,
                "min": 0,
                "max": 100
            },
            "comparativeRange": [
                "mfi"
            ]
        },
        "mom": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "mom"
            ]
        },
        "rsi": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "rsi"
            ]
        },
        "ad": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "ad"
            ]
        },
        "adosc": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "adosc"
            ]
        },
        "obv": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "obv"
            ]
        },
        "atr": {
            "numberRange": {
                "hasRange": True,
                "min": 0,
                "max": 1000
            },
            "comparativeRange": [
                "atr"
            ]
        },
        "Stock2": {
            "numberRange": {
                "hasRange": True,
                "min": 0,
                "max": 1
            },
            "comparativeRange": [
                "Stock2",
                "Stock21"
            ]
        },
        "Stock21": {
            "numberRange": {
                "hasRange": True,
                "min": 0,
                "max": 1
            },
            "comparativeRange": [
                "Stock2",
                "Stock21"
            ]
        },
        "dochiant_low_5": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "dochiant_up_5": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "dochiant_mid_5": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "Stock_fast_aroon": {
            "numberRange": {
                "hasRange": True,
                "min": 0,
                "max": 1
            },
            "comparativeRange": [
                "Stock_fast_aroon",
                "Stock_slow_aroon"
            ]
        },
        "Stock_slow_aroon": {
            "numberRange": {
                "hasRange": True,
                "min": 0,
                "max": 1
            },
            "comparativeRange": [
                "Stock_fast_aroon",
                "Stock_slow_aroon"
            ]
        },
        "sma_aroon": {
            "numberRange": {
                "hasRange": False,
                "min": 0,
                "max": 0
            },
            "comparativeRange": [
                "Open",
                "High",
                "Low",
                "Close",
                "ma",
                "sma",
                "ema",
                "dema",
                "dochiant_low",
                "dochiant_mid",
                "dochiant_up",
                "dochiant_low_5",
                "dochiant_mid_5",
                "dochiant_up_5",
                "sma_aroon"
            ]
        },
        "aroon_up": {
            "numberRange": {
                "hasRange": True,
                "min": 0,
                "max": 100
            },
            "comparativeRange": [
                "aroon_up",
                "aroon_down"
            ]
        },
        "aroon_down": {
            "numberRange": {
                "hasRange": True,
                "min": 0,
                "max": 100
            },
            "comparativeRange": [
                "aroon_up",
                "aroon_down"
            ]
        },
        "Wave_3": {
            "numberRange": {
                "hasRange": True,
                "min": 0,
                "max": 1
            },
            "comparativeRange": [
                "Wave_3",
                "Wave_5"

            ]
        },
        "Wave_5": {
            "numberRange": {
                "hasRange": True,
                "min": 0,
                "max": 1
            },
            "comparativeRange": [
                "Wave_3",
                "Wave_5"
            ]
        }
    }
    genetic_algorithm(pipeline, givenData, patternConfig)