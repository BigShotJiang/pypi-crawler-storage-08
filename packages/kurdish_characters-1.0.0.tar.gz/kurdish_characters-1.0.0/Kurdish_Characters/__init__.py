"""
Init file for the Kurdish Text Handler package
فایلی دەستپێکردن بۆ کتێبخانەی نامەی کوردی
"""

from .Kurdish_Characters import KurdishTextHandler, create_kurdish_window, display_kurdish_message, KURDISH_CHARS

__version__ = "1.0.0"
__author__ = "Kurdish Developer Community"
# کۆمەڵگەی پەرەپێدەرە کوردەکان