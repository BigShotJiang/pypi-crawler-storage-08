from mchnpkg._core import hello_from_bin
from mchnpkg.model import LinearRegression

def hello() -> str:
    return hello_from_bin()
