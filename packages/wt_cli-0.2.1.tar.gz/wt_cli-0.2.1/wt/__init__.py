"""wt - Zero-friction git worktree manager."""

__version__ = "0.1.0"
