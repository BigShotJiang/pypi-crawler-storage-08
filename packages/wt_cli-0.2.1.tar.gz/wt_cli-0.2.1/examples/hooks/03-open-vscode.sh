#!/bin/bash
# Open the new worktree in VS Code
#
# Automatically opens the worktree in a new VS Code window.
# Change 'code' to 'cursor' for Cursor editor, or 'nvim' for Neovim.

code .
