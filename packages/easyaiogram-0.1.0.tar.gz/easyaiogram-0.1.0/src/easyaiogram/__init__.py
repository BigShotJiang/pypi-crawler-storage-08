from .main import EasyAiogram
__version__ = "0.1"