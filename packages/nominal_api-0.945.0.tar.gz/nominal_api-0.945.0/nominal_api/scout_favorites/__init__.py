# coding=utf-8
from .._impl import (
    scout_favorites_FavoritesService as FavoritesService,
)

__all__ = [
    'FavoritesService',
]

