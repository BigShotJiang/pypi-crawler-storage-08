This project uses the following tools:

* uv for package installation and running of tools
* pytest for the implementation of tests

When implementing tests, try to use features from pytest where possible.
