from datahub import JianguoDownloader

data2 = JianguoDownloader('www.lka.com', './expspe')