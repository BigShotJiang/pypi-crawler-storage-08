try:
    from ._version import __version__, __version_tuple__
except ImportError:
    pass
