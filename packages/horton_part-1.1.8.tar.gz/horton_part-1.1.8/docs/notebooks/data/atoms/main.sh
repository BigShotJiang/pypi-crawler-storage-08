#!/bin/bash

# horton-atomdb.py input g09 1,5,6,8 template.com

## Step 2: run script on HPC
# ./run_g09.sh

## Step 3
horton-atomdb.py convert
