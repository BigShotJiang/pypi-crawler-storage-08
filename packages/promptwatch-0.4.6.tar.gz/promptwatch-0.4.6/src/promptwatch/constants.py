class EnvVariables:
    PROMPTWATCH_API_KEY="PROMPTWATCH_API_KEY"
    """ API key for accessing the PromptWatch API """
    PROMPTWATCH_TRACKING_PROJECT="PROMPTWATCH_TRACKING_PROJECT"
    """ Default tracking project to identify sessions from this codebase."""