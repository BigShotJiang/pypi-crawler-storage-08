# AsyncFlow

**Stop waiting for the slowest task. Start processing smarter.**

<p align="center">
  <img src="docs/images/worker-pool-concept.png" alt="AsyncFlow Worker Pool Concept" width="600">
</p>

<p align="center">
  <em>AsyncFlow: Modern async execution library with concurrent.futures-style API and advanced pipelines</em>
</p>

---

## The Problem I Had to Solve

I was processing massive amounts of data using OpenAI's Batch API. The workflow was complex:
1. Upload batches of data to OpenAI
2. Wait for processing to complete
3. Download the results
4. Save to database
5. Repeat for the next batch

Initially, I processed 10 batches at a time using basic async. But here's the problem: **I had to wait for ALL 10 batches to complete before starting the next group**.

### The Bottleneck

Imagine this scenario:
- 9 batches complete in 5 minutes
- 1 batch gets stuck and takes 30 minutes
- **I waste 25 minutes waiting** for that one slow batch while my system sits idle

With hundreds of batches to process, these delays accumulated into **hours of wasted time**. Even worse, one failed batch would block the entire pipeline.

### The Solution: AsyncFlow

I built AsyncFlow to solve this exact problem. Instead of batch-by-batch processing, **AsyncFlow uses worker pools** where:

- ✅ **Each worker handles tasks independently**
- ✅ **When a worker finishes, it immediately grabs the next task**
- ✅ **Slow tasks don't block fast ones**
- ✅ **Always maintain optimal concurrency (e.g., 10 tasks running simultaneously)**
- ✅ **Built-in retry logic for failed tasks**
- ✅ **Multi-stage pipelines for complex workflows**

**Result**: My OpenAI batch processing went from taking hours to completing in a fraction of the time, with automatic retry handling and zero idle time.

---

## Quick Example

```python
import asyncio
from asyncflow import Pipeline, Stage

# Your actual work
async def upload_batch(batch_data):
    # Upload to OpenAI API
    return batch_id

async def check_status(batch_id):
    # Check if batch is ready
    return result_url

async def download_results(result_url):
    # Download processed data
    return processed_data

async def save_to_db(processed_data):
    # Save results
    return "saved"

# Build the pipeline
upload_stage = Stage(name="Upload", workers=10, tasks=[upload_batch])
check_stage = Stage(name="Check", workers=10, tasks=[check_status])
download_stage = Stage(name="Download", workers=10, tasks=[download_results])
save_stage = Stage(name="Save", workers=5, tasks=[save_to_db])

pipeline = Pipeline(stages=[upload_stage, check_stage, download_stage, save_stage])

# Process 1000 batches efficiently
results = await pipeline.run(my_1000_batches)
```

**What happens**: 10 workers process uploads simultaneously. As soon as one finishes, it picks the next batch. No waiting. No idle time. Maximum throughput.

---

## Installation

```bash
pip install asyncflow
```

## Key Features

### 🚀 **Worker Pool Architecture**
- Independent workers that never block each other
- Automatic task distribution
- Optimal resource utilization

### 🔄 **Multi-Stage Pipelines**
- Chain operations with configurable worker pools per stage
- Each stage runs independently
- Data flows automatically between stages

### 💪 **Built-in Resilience**
- Per-task retry with exponential backoff
- Per-stage retry for transactional operations
- Failed tasks don't stop the pipeline

### 📊 **Real-time Monitoring**
- Track progress, failures, and queue sizes
- Callbacks at task and stage levels
- Pipeline statistics

### 🎯 **Familiar API**
- Drop-in async replacement for `concurrent.futures`
- `submit()`, `map()`, `as_completed()` methods
- Clean, intuitive interface

---

## Use Cases

### ✅ **Perfect for:**
- **Batch API Processing** - OpenAI, Anthropic, any batch API
- **ETL Pipelines** - Extract, transform, load at scale
- **Web Scraping** - Fetch, parse, store web data efficiently
- **Data Processing** - Process large datasets with retry logic
- **Microservices** - Chain async service calls with error handling

### ⚡ **Real-world Impact:**
- Process 1000+ items without bottlenecks
- Automatic retry for transient failures
- Zero idle time = maximum throughput
- Clear observability with metrics and callbacks

---

## AsyncExecutor: Simple Concurrent Execution

For straightforward parallel processing, AsyncExecutor provides a `concurrent.futures`-style API:

### Basic Usage

```python
import asyncio
from asyncflow import AsyncExecutor

async def process_item(x):
    await asyncio.sleep(0.1)
    return x * 2

async def main():
    async with AsyncExecutor(max_workers=10) as executor:
        # Using map() for parallel processing
        results = []
        async for result in executor.map(process_item, range(100)):
            results.append(result)
        print(f"Processed {len(results)} items")

asyncio.run(main())
```

### Racing Tasks with wait()

Get the fastest result from multiple concurrent operations:

```python
from asyncflow import AsyncExecutor, WaitStrategy

async def main():
    async with AsyncExecutor(max_workers=10) as executor:
        # Submit same request to multiple API regions
        futures = [
            executor.submit(call_api_region_1, query),
            executor.submit(call_api_region_2, query),
            executor.submit(call_api_region_3, query),
        ]

        # Get the first result
        done, pending = await executor.wait(
            futures,
            return_when=WaitStrategy.FIRST_COMPLETED
        )

        fastest_result = await list(done)[0].result()
        print(f"Got result from fastest region: {fastest_result}")
```

### Waiting for Multiple Futures

```python
from asyncflow import WaitStrategy

# Wait for all to complete
done, pending = await executor.wait(futures)

# Wait for first to complete
done, pending = await executor.wait(
    futures,
    return_when=WaitStrategy.FIRST_COMPLETED
)

# Wait for first exception
done, pending = await executor.wait(
    futures,
    return_when=WaitStrategy.FIRST_EXCEPTION
)

# Wait with timeout
done, pending = await executor.wait(
    futures,
    timeout=5.0
)
```

---

## Pipeline: Multi-Stage Processing

For complex workflows with multiple steps:

```python
import asyncio
from asyncflow import Pipeline, Stage

async def fetch(x):
    await asyncio.sleep(0.1)
    return f"data_{x}"

async def process(x):
    await asyncio.sleep(0.1)
    return x.upper()

async def save(x):
    await asyncio.sleep(0.1)
    return f"saved_{x}"

async def main():
    # Define stages with different worker counts
    fetch_stage = Stage(name="Fetch", workers=10, tasks=[fetch])
    process_stage = Stage(name="Process", workers=5, tasks=[process])
    save_stage = Stage(name="Save", workers=3, tasks=[save])

    # Build pipeline
    pipeline = Pipeline(stages=[fetch_stage, process_stage, save_stage])

    # Process 100 items through all stages
    results = await pipeline.run(range(100))

    print(f"Completed: {len(results)} items")
    print(f"Stats: {pipeline.get_stats()}")

asyncio.run(main())
```

**Why different worker counts?**
- **Fetch**: I/O bound, use more workers (10)
- **Process**: CPU bound, moderate workers (5)
- **Save**: Rate-limited API, fewer workers (3)

---

## Advanced Features

### Retry Strategies

**Per-Task Retry** (for independent operations):
```python
stage = Stage(
    name="APICall",
    workers=10,
    tasks=[call_api],
    retry="per_task",
    task_attempts=5,
    task_wait_seconds=2.0
)
```

**Per-Stage Retry** (for transactional operations):
```python
stage = Stage(
    name="Transaction",
    workers=3,
    tasks=[begin_tx, update_db, commit_tx],
    retry="per_stage",
    stage_attempts=3
)
```

### Callbacks for Monitoring

```python
async def on_success(payload):
    print(f"✅ Completed item {payload['id']}")

async def on_failure(payload):
    print(f"❌ Failed item {payload['id']}: {payload['error']}")
    # Log to monitoring system, send alert, etc.

async def on_retry(payload):
    print(f"🔄 Retrying item {payload['id']} (attempt {payload['attempt']})")

stage = Stage(
    name="Process",
    workers=10,
    tasks=[process_data],
    retry="per_task",
    task_attempts=5,
    on_success=on_success,
    on_failure=on_failure,
    on_retry=on_retry
)
```

### Order Preservation

```python
# Maintain input order in results
pipeline = Pipeline(stages=[stage1, stage2], preserve_order=True)

# Or allow reordering for better performance
pipeline = Pipeline(stages=[stage1, stage2], preserve_order=False)
```

### Real-time Statistics

```python
stats = pipeline.get_stats()
print(f"Processed: {stats.items_processed}")
print(f"Failed: {stats.items_failed}")
print(f"In-flight: {stats.items_in_flight}")
print(f"Queue sizes: {stats.queue_sizes}")
```

---

## Comparison: Before vs After

### Before AsyncFlow ❌
```python
# Process batches sequentially in groups
for batch_group in chunks(batches, 10):
    results = await asyncio.gather(*[process(b) for b in batch_group])
    # Wait for ALL 10 to complete before continuing
    # One slow task blocks 9 fast ones
```

**Problems:**
- Idle workers waiting for slowest task
- No automatic retry
- Difficult to monitor progress
- Hard to optimize worker counts per stage

### After AsyncFlow ✅
```python
# Workers continuously process available tasks
stage = Stage(name="Process", workers=10, tasks=[process])
pipeline = Pipeline(stages=[stage])
results = await pipeline.run(batches)
```

**Benefits:**
- Zero idle time
- Automatic retry with backoff
- Real-time monitoring
- Easy to tune performance

---

## Documentation

📚 **Full documentation available at:** [asyncflow.readthedocs.io](https://asyncflow.readthedocs.io)

- [Getting Started Guide](docs/getting-started/quickstart.md)
- [AsyncExecutor Guide](docs/user-guide/executor.md)
- [Pipeline Guide](docs/user-guide/pipeline.md)
- [Error Handling & Retries](docs/user-guide/error-handling.md)
- [API Reference](docs/api/index.md)
- [Examples & Patterns](docs/examples/basic.md)

---

## Requirements

- Python 3.9+
- tenacity >= 8.0.0

**Note**: For Python 3.9-3.10, the `taskgroup` backport is automatically installed.

---

## Contributing

Contributions are welcome! Please see our [Contributing Guidelines](CONTRIBUTING.md).

---

## License

MIT License - see [LICENSE](LICENSE) file for details.

---

## Why AsyncFlow?

I built AsyncFlow because I was tired of waiting for the slowest task in my batch processing pipelines. Every data engineer and ML engineer has faced this: you're processing hundreds or thousands of API calls, and one slow response blocks everything.

AsyncFlow solves this with a simple concept: **independent workers that never wait**. When a worker finishes a task, it immediately grabs the next one. No coordination overhead. No waiting. Just continuous, efficient processing.

If you're processing data through APIs, building ETL pipelines, or running any kind of batch async operations, AsyncFlow will save you time.

**Start processing smarter, not harder.** 🚀

---

<p align="center">
  Made with ❤️ to solve real problems in production
</p>
