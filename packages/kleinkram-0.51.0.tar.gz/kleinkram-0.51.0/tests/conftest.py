from __future__ import annotations

import pytest

pytest_plugins = [
    "testing.backend_fixtures",
]
