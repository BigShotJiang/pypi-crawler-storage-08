# plotlymap module

::: leafmap.plotlymap
