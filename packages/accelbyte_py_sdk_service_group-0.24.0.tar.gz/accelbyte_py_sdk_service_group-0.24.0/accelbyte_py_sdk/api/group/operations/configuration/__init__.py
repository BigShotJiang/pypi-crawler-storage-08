# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Group Service."""

__version__ = "2.22.0"
__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .create_group_configurat_f2dcd2 import CreateGroupConfigurationAdminV1
from .delete_group_configurat_db1475 import DeleteGroupConfigurationGlobalRuleAdminV1
from .delete_group_configuration_v1 import DeleteGroupConfigurationV1
from .get_group_configuration_f4178c import GetGroupConfigurationAdminV1
from .initiate_group_configur_384fb1 import InitiateGroupConfigurationAdminV1
from .list_group_configuratio_ada77c import ListGroupConfigurationAdminV1
from .update_group_configurat_745686 import UpdateGroupConfigurationAdminV1
from .update_group_configurat_3473ca import UpdateGroupConfigurationGlobalRuleAdminV1
