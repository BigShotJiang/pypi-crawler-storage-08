# Constants for path segments to avoid magic strings
DIRECTORY_PUBLIC = "public"
DIRECTORY_PRIVATE = "private"
DIRECTORY_DATASETS = "datasets"
