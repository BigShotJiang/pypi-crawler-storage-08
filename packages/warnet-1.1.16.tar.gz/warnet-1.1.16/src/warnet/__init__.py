from importlib.resources import files

SRC_DIR = files("warnet")
