from lilya.middleware.cors import CORSMiddleware  # noqa

__all__ = ["CORSMiddleware"]
