from lilya.contrib.security.scopes import Scopes as Scopes  # noqa
