from .pyqgen import *

__version__ = '0.4'

print ("PyQGen version", __version__)
    
