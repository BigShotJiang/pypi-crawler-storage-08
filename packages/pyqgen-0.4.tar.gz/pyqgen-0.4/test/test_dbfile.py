import pytest
import pyqgen

def test_question():
    assert 1
