- Implement new factors
- Reuse existing factor and modify them instead of always creating new
  ones.
- Add small graph view in buffer form as a way to overview DAFs.
