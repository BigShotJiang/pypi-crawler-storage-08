To plan buffer adjustments act as follows:

1.  Click on *Inventory \> Demand Planning \> Create Buffer
    Adjustments*.
2.  In the popup window fill the *Period* and *Date Range Type* to
    perform your planning.
3.  Check the boxes of the *Factor to Apply* in which you are
    interested.
4.  Select the DDMRP Buffers where to apply this factors.
5.  Under the title *Sheet* you will see a generated sheet in which you
    can fill the values for each period.
6.  Click *Validate* to confirm your planning and the system will end up
    showing you the newly created DDMRP adjustment records.
