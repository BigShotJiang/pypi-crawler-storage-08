**Português** Este módulo integra os módulos l10n_br_account e
l10n_br_nfe.

- Adicionando as informações de Pagamento e Duplicatas da Fatura, TAGs
  cobr, pag e dup da NF-e/NFC-e.

**English** This module integrates the l10n_br_account and l10n_br_nfe
modules.

- Adding Payment Information and Invoice Duplicates, TAGs cobr, pag and
  dup of NF-e/NFC-e.
