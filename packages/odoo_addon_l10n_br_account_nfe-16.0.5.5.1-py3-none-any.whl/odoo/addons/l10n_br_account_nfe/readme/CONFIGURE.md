**Português** Crie o Modo de Pagamento e informe o campo Meio de
Pagamento da NF: Faturamento \> Configuração \> Administração \> Modos
de Pagamento

**English** Create the Payment Mode and inform the field Meio de
Pagamento da NF: Invoicing \> Configuration \> Management \> Payment
Modes
