fastavro.json_read
==================

.. autofunction:: fastavro.json_read.json_reader
