fastavro.read
=============

.. autoclass:: fastavro._read_py.reader

.. autoclass:: fastavro._read_py.block_reader

.. autoclass:: fastavro._read_py.Block

.. autofunction:: fastavro._read_py.schemaless_reader

.. autofunction:: fastavro._read_py.is_avro
