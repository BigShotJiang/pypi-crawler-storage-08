fastavro.schema
===============

.. autofunction:: fastavro._schema_py.parse_schema
.. autofunction:: fastavro._schema_py.fullname
.. autofunction:: fastavro._schema_py.expand_schema
.. autofunction:: fastavro._schema_py.load_schema
.. autofunction:: fastavro._schema_py.load_schema_ordered
.. autofunction:: fastavro._schema_py.to_parsing_canonical_form
.. autofunction:: fastavro._schema_py.fingerprint
