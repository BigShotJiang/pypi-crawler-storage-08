fastavro.io.json_decoder
========================

.. autoclass:: fastavro.io.json_decoder.AvroJSONDecoder
