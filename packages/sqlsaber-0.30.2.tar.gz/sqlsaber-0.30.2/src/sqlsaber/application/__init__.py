"""Application layer for SQLsaber - shared business logic and interactive flows."""
