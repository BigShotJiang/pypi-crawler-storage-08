## Install it with

```sh
pip install git+ssh://git@github.com/kkristof200/kretriable.git@main
```

## Use it via

```python
from retriable import ...
```
