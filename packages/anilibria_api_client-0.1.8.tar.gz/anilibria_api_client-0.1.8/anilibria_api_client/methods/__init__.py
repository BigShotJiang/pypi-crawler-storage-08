from .accounts import AccountsMethod
from .ads import AdsMethod
from .anime import AnimeMethod
from .app import AppMethod
from .media import MediaMethod
from .teams import TeamsMethod