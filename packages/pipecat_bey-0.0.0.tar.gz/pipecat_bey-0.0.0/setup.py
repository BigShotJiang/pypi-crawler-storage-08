from setuptools import setup

setup(
    name="pipecat-bey",
    version="0.0.0",
    packages=["bey.pipecat.services"],
)
