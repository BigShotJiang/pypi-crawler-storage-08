DEFAULT_LOADER_DIR_NAME = "data"
PYTEST_DATA_LOADER_ATTR = "_pytest_data_loader"
